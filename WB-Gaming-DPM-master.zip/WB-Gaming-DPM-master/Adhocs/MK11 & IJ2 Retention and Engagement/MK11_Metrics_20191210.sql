----MK11 Retention 7,14,30,60----

  with MK11_retention as (
 with datedim as ( select event_dt YearMonthDay from seven11_prod_da.wba_fact_activity group by 1)


            select period, RetentionDate, newdate, count(c.player_id) retained_players, count(b.player_id) cohorts
            from
            (
              SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
                FROM datedim d
                JOIN datedim  d2 ON d.YearMonthDay < d2.YearMonthDay
                WHERE  (d.YearMonthDay>='2019-04-22' and d.YearMonthDay < '2019-12-10' )
                AND (d2.YearMonthDay>='2019-04-22' and  d2.YearMonthDay < '2019-12-10')
            ) A
            join
            (

              select player_id, min(event_dt) yearmonthday
              from seven11_prod_da.wba_player_daily a
        where event_dt >= '2019-04-22'
              group by 1

            )  B
            on a.NewDate = b.yearmonthday
            left join
            (

              select event_dt yearmonthday, player_id
              from seven11_prod_da.wba_player_daily a
              group by 1,2

            ) C
            on b.player_id = c.player_id
            and c.yearmonthday = a.retentiondate
            where b.yearmonthday >= '2019-04-22'
            group by 1,2,3
)


    Select a.*,Day_7,Day_14,Day_30,Day_60
    from(
    select NewDate,period, sum(retained_players::float) / sum(cohorts::float) Day_7
    from MK11_retention
    where period = 7
    group by 1,2) a
    left join(
    select NewDate,period, sum(retained_players::float) / sum(cohorts::float) Day_14
    from MK11_retention
    where period = 14
    group by 1,2) b
    on a.NewDate =b.NewDate
    left join(
    select NewDate,period, sum(retained_players::float) / sum(cohorts::float) Day_30
    from MK11_retention
    where period = 30
    group by 1,2) c
    on a.NewDate =c.NewDate
    left join(
    select NewDate,period, sum(retained_players::float) / sum(cohorts::float) Day_60
    from MK11_retention
    where period = 60
    group by 1,2) d
    on a.NewDate =d.NewDate;
	
---- Game Mode Retention----

----MK11

select a.date, DAU, new_players, sum(new_players) over (order by a.date rows unbounded preceding)
from
(select DATE(event_dt) date, count(distinct player_id) DAU
from seven11_prod_da.wba_fact_activity
where DATE(event_dt)  BETWEEN '2019-04-22' and '2019-12-10'
and activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER')
group by 1)a
left join
(select date, count(player_id) new_players
from(
select player_id, min(DATE(event_dt)) date
from seven11_prod_da.wba_fact_activity
where DATE(event_dt)  BETWEEN '2019-04-22' and '2019-12-10'
and activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER')
group by 1)
group by 1)b
on a.date = b.date

-----L 7,14 Retention----

--MK11
with datedim as ( select event_dt YearMonthDay from seven11_prod_da.wba_fact_activity group by 1),
 retention_period_table as (
 	SELECT d.YearMonthDay NewDate, (datediff(DAY,d2.YearMonthDay, d.YearMonthDay ))+1 Retentionperiod, d2.YearMonthDay RetentionDate
 	FROM datedim d
 	JOIN datedim  d2 ON d.YearMonthDay >= d2.YearMonthDay
 	WHERE  (d.YearMonthDay>='2019-04-22' and d.YearMonthDay < '2019-12-10')
 	AND (d2.YearMonthDay>='2019-04-22' and  d2.YearMonthDay < '2019-12-10')
 )
 
 
Select a.Newdate date,Day_7_Retention,COALESCE(Day_14_Retention,'') Day_14_Retention
from
(select Newdate, count(player_id)::float/count(distinct player_id) Day_7_Retention
from
(
	select *
	from retention_period_table A
	left join 
	(
		select event_dt yearmonthday, player_id
    	from seven11_prod_da.wba_player_daily a
		where event_dt >= '2019-04-22'
    	group by 1,2
	) B
	on A.retentiondate = B.yearmonthday
	where retentionperiod <= 7 and Newdate >= '2019-04-28'
	order by newdate,retentionperiod
) 
group by 1) a
left join 
(select Newdate, count(player_id)::float/count(distinct player_id) Day_14_Retention
from
(
	select *
	from retention_period_table A
	left join 
	(
		select event_dt yearmonthday, player_id
    	from seven11_prod_da.wba_player_daily a
		where event_dt >= '2019-04-22'
    	group by 1,2
	) B
	on A.retentiondate = B.yearmonthday
	where retentionperiod<=14 and Newdate >= '2019-05-05'
	order by newdate,retentionperiod
) 
group by 1) b
on a.Newdate = b.Newdate;
