----Lifetime hours per player----

Select Avg(Totalhours) Hours_Per_player
from (
select platformaccountid, sum(totaldurationminutes::float)/60 totalhours
from pachinko_prod_da.factactivity 
where DATE(starttimestamp)  BETWEEN '2017-05-14' and '2018-01-01'  
group by 1
); 

----Lifetime days per player----
select  sum(total_days)/count(platformaccountid) avg_days_per_player
from
(
select platformaccountid, count(distinct date(starttimestamp))::float total_days
from pachinko_prod_da.factactivity
where DATE(starttimestamp)  BETWEEN '2017-05-14' and '2018-01-01'  
group by  1
);

----Lifetime sessions per player---- 

select Avg(Sessions_played) Sessions_per_player
from(
select platformaccountid,Count(distinct sid)*1.0 Sessions_played
from pachinko_prod_da.factactivity
where DATE(starttimestamp)  BETWEEN '2017-05-14' and '2018-01-01' 
group by  1
);
----Average hours per player per day----

select Avg(Totalhours) Hours_Per_player_per_day
from(
select platformaccountid,dimdateid ,sum(totaldurationminutes::float)/60 totalhours
from pachinko_prod_da.factactivity
where DATE(starttimestamp)  BETWEEN '2017-05-14' and '2018-01-01' 
group by  1,2
);

----Average session length per day----

select Sum(totaldurationminutes)::float/(Count(distinct sid)*60) Avg_Session_Length_per_day
from pachinko_prod_da.factactivity
where DATE(starttimestamp)  BETWEEN '2017-05-14' and '2018-01-01';


----Average sessions per day----

select Avg(Sessions_played) Sessions_per_day
from(
select platformaccountid, date(starttimestamp),Count(distinct sid)*1.0 Sessions_played
from pachinko_prod_da.factactivity
where DATE(starttimestamp)  BETWEEN '2017-05-14' and '2018-01-01' 
group by  1,2
);

	
----IJ2 Retention 7,14,30,60----	

with IJ2_retention as (
select newdate, RetentionDate,period, count(c.platformaccountid) retained_players, count(b.platformaccountid) cohorts
from
(
	SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM pachinko_prod_da.DimDate d 
    JOIN pachinko_prod_da.DimDate d2 ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2017-05-14' and d.YearMonthDay <'2018-01-01')
    AND (d2.YearMonthDay>='2017-05-14' and  d2.YearMonthDay <'2018-01-01')
) A
join 
(

	select yearmonthday, a.platformaccountid
	from pachinko_prod_da.aggactivityplayerhours a 
	join pachinko_prod_da.dimplayer B
	on a.yearmonthday = b.firstsessiondate and b.current = true
	and a.platformaccountid = b.platformaccountid
	group by 1,2

)  B
on a.NewDate = b.yearmonthday 
left join
(

	select yearmonthday, platformaccountid
	from pachinko_prod_da.aggactivityplayerhours a 
	group by 1,2

) C
on b.platformaccountid = c.platformaccountid
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2017-05-14'
group by 1,2,3
)


    Select a.*,Day_7,Day_14,Day_30,Day_60
    from(
    select NewDate,period, sum(retained_players::float) / sum(cohorts::float) Day_7
    from IJ2_retention
    where period = 7
    group by 1,2) a
    left join(
    select NewDate,period, sum(retained_players::float) / sum(cohorts::float) Day_14
    from IJ2_retention
    where period = 14
    group by 1,2) b
    on a.NewDate =b.NewDate
    left join(
    select NewDate,period, sum(retained_players::float) / sum(cohorts::float) Day_30
    from IJ2_retention
    where period = 30
    group by 1,2) c
    on a.NewDate =c.NewDate
    left join(
    select NewDate,period, sum(retained_players::float) / sum(cohorts::float) Day_60
    from IJ2_retention
    where period = 60
    group by 1,2) d
    on a.NewDate =d.NewDate;
	
---- Game Mode Retention----

----IJ2
select a.date, DAU, new_players, sum(new_players) over (order by a.date rows unbounded preceding)
from
(select DATE(starttimestamp) date, count(distinct platformaccountid) DAU
from pachinko_prod_da.factactivity
join pachinko_prod_da.dimactivity
using (dimactivityid)
where DATE(starttimestamp)  BETWEEN '2017-05-14' and '2018-01-01'
and dimactivityid = 6
group by 1)a
left join
(select date, count(platformaccountid) new_players
from(
select platformaccountid, min(DATE(starttimestamp)) date
from pachinko_prod_da.factactivity
join pachinko_prod_da.dimactivity
using (dimactivityid)
where DATE(starttimestamp)  BETWEEN '2017-05-14' and '2018-01-01'
and dimactivityid = 6
group by 1)
group by 1)b
on a.date = b.date;

-----L 7,14 Retention----
---IJ2
with datedim as ( select date(starttimestamp) YearMonthDay from pachinko_prod_da.factactivity  group by 1),
 retention_period_table as (
 	SELECT d.YearMonthDay NewDate, (datediff(DAY,d2.YearMonthDay, d.YearMonthDay ))+1 Retentionperiod, d2.YearMonthDay RetentionDate
 	FROM datedim d
 	JOIN datedim  d2 ON d.YearMonthDay >= d2.YearMonthDay
 	WHERE  (d.YearMonthDay>='2017-05-14' and d.YearMonthDay < '2018-01-01')
 	AND (d2.YearMonthDay>='2017-05-14'and  d2.YearMonthDay < '2018-01-01')
 )
 
 
Select a.Newdate date,Day_7_Retention,COALESCE(Day_14_Retention,'') Day_14_Retention
from
(select Newdate, count(platformaccountid)::float/count(distinct platformaccountid) Day_7_Retention
from
(
	select *
	from retention_period_table A
	left join 
	(
		select date(starttimestamp) yearmonthday, platformaccountid
    	from pachinko_prod_da.factactivity a
		where date(starttimestamp) >= '2017-05-14'
    	group by 1,2
	) B
	on A.retentiondate = B.yearmonthday
	where retentionperiod <= 7 and Newdate >= '2017-05-20'
	order by newdate,retentionperiod
) 
group by 1) a
left join 
(select Newdate, count(platformaccountid)::float/count(distinct platformaccountid) Day_14_Retention
from
(
	select *
	from retention_period_table A
	left join 
	(
		select date(starttimestamp) yearmonthday, platformaccountid
    	from pachinko_prod_da.factactivity a
		where date(starttimestamp) >= '2017-05-14'
    	group by 1,2
	) B
	on A.retentiondate = B.yearmonthday
	where retentionperiod<=14 and Newdate >= '2017-05-27'
	order by newdate,retentionperiod
) 
group by 1) b
on a.Newdate = b.Newdate ;