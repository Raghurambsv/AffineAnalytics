 -----KL S1 Players

      select count(distinct _platform_account_id)
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-1') and ai_difficulty= -1 
	  and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16' ;

------------------VC Earned by KL S1 players after start of KL S1

 with  KL1_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-1') and ai_difficulty= -1 
	  and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1)
	  
Select Count(distinct _platform_account_id)	Players, Sum(Vc_earned) Total_vc_earned
from(
Select _platform_account_id,Sum(change_amount) Vc_earned
from(
select  _platform_account_id, _event_time_utc trans_ts,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source not in ('ENTITLEMENT','PREMIUM_SHOP','DEBUG')
and date(_event_time_utc) between '2019-06-18' and '2019-12-31'  
and _platform_account_id in (Select * from KL1_players))
group by 1) ;

------------------VC bought by KL S1 players after start of KL S1

 with  KL1_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-1') and ai_difficulty= -1 
	  and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1)
	  
Select Count(distinct _platform_account_id)	Players, Sum(Vc_bought) Total_vc_bought
from(
Select _platform_account_id,Sum(change_amount) Vc_bought
from(
select  _platform_account_id, _event_time_utc trans_ts,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source = 'ENTITLEMENT'
and date(_event_time_utc) between '2019-06-18' and '2019-12-31'  
and _platform_account_id in (Select * from KL1_players))
group by 1) ;

------------------VC Spent by KL S1 players after start of KL S1

 with  KL1_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-1') and ai_difficulty= -1 
	  and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1)
	  
Select Count(distinct _platform_account_id)	Players, Sum(Vc_spent) Total_vc_spent
from(
Select _platform_account_id,Sum(change_amount)*(-1) Vc_spent
from(
select  _platform_account_id, _event_time_utc trans_ts,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')
and date(_event_time_utc) between '2019-06-18' and '2019-12-31'  
and _platform_account_id in (Select * from KL1_players))
group by 1) ;

------------------VC bought BY KL S1 Players after end on kl S1

 with  KL1_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-1') and ai_difficulty= -1 
	  and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1)
	  

Select Sum(change_amount) Vc_bought
from(
select  _platform_account_id, _event_time_utc trans_ts,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source = 'ENTITLEMENT'
and date(_event_time_utc) between '2019-07-17' and '2019-12-31'  
and _platform_account_id in (Select * from KL1_players))
 ;
 
------------------DLC bought BY KL S1 Players after end on kl S1

 with  KL1_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-1') and ai_difficulty= -1 
	  and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1)
	  

select entitlement_name, count(distinct _platform_account_id) A_la_carte_payers 
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('terminator','sindel','nightwolf','shang_tsung','dlc4_skin_pack','dlc3_skin_pack','dlc2_skin_pack','klassic_arcade_ninja_skin_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) between '2019-07-17' and '2019-12-31' 
and _platform_account_id in (Select * from KL1_players)
group by 1 ;

---------------KP bought BY KL S1 Players after end on kl S1

 with  KL1_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-1') and ai_difficulty= -1 
	  and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1)
	  

select entitlement_name, count(distinct _platform_account_id) KP_payers 
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('kombat_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) between '2019-07-17' and '2019-12-31'  
and _platform_account_id in (Select * from KL1_players)
group by 1 ;

------Masquerade Skin pack bought BY KL S1 Players after end on kl S1

 with  KL1_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-1') and ai_difficulty= -1 
	  and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1)
	  
select entitlement_name, count(distinct _platform_account_id) A_la_carte_payers 
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('halloween_skin_pack')
and date(_event_time_utc) between '2019-07-17' and '2019-12-31'  
and _platform_account_id in (Select * from KL1_players)
group by 1 ;

-----Shao Kahn bought BY KL S1 Players after end on kl S1---- Didn't add these numbers as the numbers seem to be wrong

 with  KL1_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-1') and ai_difficulty= -1 
	  and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1)

select entitlement_name, count(distinct _platform_account_id) A_la_carte_payers 
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('shao_kahn')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('digital_preorder_premium_edition')
        )
and date(_event_time_utc) between '2019-07-17' and '2019-12-31'  
and _platform_account_id in (Select * from KL1_players)
group by 1 ;

