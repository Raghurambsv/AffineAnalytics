#!/usr/bin/env python
# coding: utf-8

# In[14]:


import pandas as pd
import numpy as np


# In[4]:


import json

with open('C:\\Users\\XHSINDHA\\Desktop\\WB\\Adhoc\\JSON Parse\\Retention_data_json.json') as f:
    data = json.load(f)
    print(data)


# In[7]:


app_data = data['app_data']
print(app_data)


# In[11]:


print(app_data[1])


# In[13]:


columns = ['app_id', 'confidence', 'corrected_retention']
final_df = pd.DataFrame(columns=columns)
print(final_df)


# In[54]:


for record in app_data:
    df_retention = record['corrected_retention']
    df_appid = [record['app_id']] * len(df_retention)
    df_confidence = [record['confidence']] * len(df_retention)
    df_listoflists = [df_appid, df_confidence, df_retention]
    df_temp = pd.DataFrame(df_listoflists)
    df_temp2 = df_temp.transpose()
    print(df_temp2)
    final_df = final_df.append(df_temp2)
    


# In[57]:


print(final_df)
final_df.to_excel("C:\\Users\\XHSINDHA\\Desktop\\WB\\Adhoc\\JSON Parse\\retention_file.xlsx")


# In[44]:


record = app_data[1]
df_retention = record['corrected_retention']
#print(df_retention)
df_appid = [record['app_id']] * len(df_retention)
#print(df_appid)
df_confidence = [record['confidence']] * len(df_retention)
#print(df_confidence)
df_listoflists = [df_appid, df_confidence, df_retention]
df_temp = pd.DataFrame(df_listoflists)
print(df_temp)
#final_df.append(df_temp)


# In[53]:


x=[1,2,3,4]
y=[5,6,7,8]
z=[2,3,4,4]

df = pd.DataFrame([x,y,z]).transpose()
print(df)
df2 = pd.DataFrame(columns = ['a','b','c'])
df2.append(df)


# In[26]:


x = 'ha' * 5
print(x)


# In[29]:


len(app_data[1]['corrected_retention'])


# In[33]:


[str(app_data[1]['app_id'])] * 2


# In[ ]:




