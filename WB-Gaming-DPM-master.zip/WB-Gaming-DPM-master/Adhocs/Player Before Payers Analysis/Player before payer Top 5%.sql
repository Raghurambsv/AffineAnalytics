----Top 5%

------------Sessions before purchasing


with players as (
select player_id 
from
(
select player_id, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select player_id, sum(total_hours) hrsplayed, sum(hrsplayed) over () totaltime,  sum(total_hours::float) / sum(hrsplayed) over () perc, 1::float / count(player_id) over ()  cum_players
		from seven11_prod_da.wba_player_daily
		where event_dt BETWEEN '2019-04-22' and dateadd(day,119,'2019-04-22')  
		group by 1
	)
)
where cumsumplayers > 0.95
group by 1
),

shang_tsung_purchase_date as(
select _platform_account_id, min(_event_time_utc) purchase_time
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('shang_tsung') and date(_event_time_utc) >= '2019-06-25'
and _platform_account_id in (select * from players)
group by 1) ,

Shang_Tsung_Purchase_gap as (
select _platform_account_id,count(distinct _session_id) sessions_ST,count(distinct date(_event_time_utc)) days_ST
from (select a.*,b.purchase_time
	  from seven11_prod.seven11_match_result_player a
	  join shang_tsung_purchase_date b
	  on a._platform_account_id= b._platform_account_id )
where date(_event_time_utc) >= '2019-06-25' 
and _event_time_utc <=purchase_time
group by 1) ,

nightwolf_purchase_date as(
select _platform_account_id, min(_event_time_utc) purchase_time
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('nightwolf') and date(_event_time_utc) >= '2019-08-20'
and _platform_account_id in (select * from players)
group by 1) ,

nightwolf_Purchase_gap as (
select _platform_account_id,count(distinct _session_id) sessions_NW,count(distinct date(_event_time_utc)) days_NW
from (select a.*,b.purchase_time
	  from seven11_prod.seven11_match_result_player a
	  join shang_tsung_purchase_date b
	  on a._platform_account_id= b._platform_account_id )
where date(_event_time_utc) >= '2019-08-20' 
and _event_time_utc <=purchase_time
group by 1)

Select *
from(
select sessions_ST,count(distinct _platform_account_id) players_ST
from Shang_Tsung_Purchase_gap
group by 1) a
left join(
select sessions_NW,count(distinct _platform_account_id) players_NW
from nightwolf_Purchase_gap
group by 1) b
on a.sessions_ST = b.sessions_NW
order by 1 ;

------------days before purchasing


with players as (
select player_id 
from
(
select player_id, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select player_id, sum(total_hours) hrsplayed, sum(hrsplayed) over () totaltime,  sum(total_hours::float) / sum(hrsplayed) over () perc, 1::float / count(player_id) over ()  cum_players
		from seven11_prod_da.wba_player_daily
		where event_dt BETWEEN '2019-04-22' and dateadd(day,119,'2019-04-22')  
		group by 1
	)
)
where cumsumplayers > 0.95
group by 1
),

shang_tsung_purchase_date as(
select _platform_account_id, min(_event_time_utc) purchase_time
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('shang_tsung') and date(_event_time_utc) >= '2019-06-25'
and _platform_account_id in (select * from players)
group by 1) ,

Shang_Tsung_Purchase_gap as (
select _platform_account_id,count(distinct _session_id) sessions_ST,count(distinct date(_event_time_utc)) days_ST
from (select a.*,b.purchase_time
	  from seven11_prod.seven11_match_result_player a
	  join shang_tsung_purchase_date b
	  on a._platform_account_id= b._platform_account_id )
where date(_event_time_utc) >= '2019-06-25' 
and _event_time_utc <=purchase_time
group by 1),

nightwolf_purchase_date as(
select _platform_account_id, min(_event_time_utc) purchase_time
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('nightwolf') and date(_event_time_utc) >= '2019-08-20'
and _platform_account_id in (select * from players)
group by 1) ,

nightwolf_Purchase_gap as (
select _platform_account_id,count(distinct _session_id) sessions_NW,count(distinct date(_event_time_utc)) days_NW
from (select a.*,b.purchase_time
	  from seven11_prod.seven11_match_result_player a
	  join shang_tsung_purchase_date b
	  on a._platform_account_id= b._platform_account_id )
where date(_event_time_utc) >= '2019-08-20' 
and _event_time_utc <=purchase_time
group by 1)

Select *
from(
select days_ST,count(distinct _platform_account_id) players_ST
from Shang_Tsung_Purchase_gap
group by 1) a
left join(
select days_NW,count(distinct _platform_account_id) players_NW
from nightwolf_Purchase_gap
group by 1) b
on a.days_ST = b.days_NW
order by 1 ;

-----Perc DLC owners in Top 5

with players as (
select player_id 
from
(
select player_id, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select player_id, sum(total_hours) hrsplayed, sum(hrsplayed) over () totaltime,  sum(total_hours::float) / sum(hrsplayed) over () perc, 1::float / count(player_id) over ()  cum_players
		from seven11_prod_da.wba_player_daily
		where event_dt BETWEEN '2019-04-22' and dateadd(day,119,'2019-04-22')  
		group by 1
	)
)
where cumsumplayers > 0.95
group by 1
),

 Kp_owners_Top_5 as(
select _platform_account_id
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
and _platform_account_id in (select * from players)
group by 1
),

shang_tsung_purchasers_Top_5 as(
select _platform_account_id
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('shang_tsung','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
and _platform_account_id in (select * from players)
group by 1) ,

nightwolf_purchasers_Top_5 as(
select _platform_account_id
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('nightwolf','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
and _platform_account_id in (select * from players)
group by 1) ,

 Kp_owners as(
select _platform_account_id
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
group by 1
),

shang_tsung_purchasers as(
select _platform_account_id
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('shang_tsung','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
group by 1) ,

nightwolf_purchasers as(
select _platform_account_id
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('nightwolf','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
group by 1)


select *
from(
select count(_platform_account_id) kp_owners_Top_5
from Kp_owners_Top_5)
cross join 
(select count(_platform_account_id) shang_tsung_owners_Top_5
from shang_tsung_purchasers_Top_5)
cross join 
(select count(_platform_account_id) nightwolf_owners_Top_5
from nightwolf_purchasers_Top_5)
cross join(
select count(_platform_account_id) kp_owners
from Kp_owners)
cross join 
(select count(_platform_account_id) shang_tsung_owners
from shang_tsung_purchasers)
cross join 
(select count(_platform_account_id) nightwolf_owners
from nightwolf_purchasers)  ;

----VC rev

with players as (
select player_id 
from
(
select player_id, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select player_id, sum(total_hours) hrsplayed, sum(hrsplayed) over () totaltime,  sum(total_hours::float) / sum(hrsplayed) over () perc, 1::float / count(player_id) over ()  cum_players
		from seven11_prod_da.wba_player_daily
		where event_dt BETWEEN '2019-04-22' and dateadd(day,119,'2019-04-22')  
		group by 1
	)
)
where cumsumplayers > 0.95
group by 1
)

select *
from(
select  count(_platform_account_id) Spenders,sum(VC) Total_VC, sum(VC_rev) Total_rev
from
	(
	select _platform_account_id, sum(change_amount) VC, sum(change_amount)*.008 VC_rev
	from seven11_prod.seven11_resource_flow
	where resource = 'Exp_PremiumCurrency' and source = 'ENTITLEMENT' and DATE(_event_time_utc)  >= '2019-04-22'   
	group by 1 
))
cross join 
(
select  count(_platform_account_id) Spenders_Top_5,sum(VC) VC_Top_5, sum(VC_rev) rev_Top_5
from
	(
	select _platform_account_id, sum(change_amount) VC, sum(change_amount)*.008 VC_rev
	from seven11_prod.seven11_resource_flow
	where resource = 'Exp_PremiumCurrency' and source = 'ENTITLEMENT' and DATE(_event_time_utc)  >= '2019-04-22'  
	and _platform_account_id in (select * from players)
	group by 1 
)) ;


-----Players_count

with players as (
select player_id 
from
(
select player_id, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select player_id, sum(total_hours) hrsplayed, sum(hrsplayed) over () totaltime,  sum(total_hours::float) / sum(hrsplayed) over () perc, 1::float / count(player_id) over ()  cum_players
		from seven11_prod_da.wba_player_daily
		where event_dt BETWEEN '2019-04-22' and dateadd(day,119,'2019-04-22')  
		group by 1
	)
)
where cumsumplayers > 0.95
group by 1
) ,

Total_players as(
select player_id
from seven11_prod_da.wba_player_daily
where event_dt BETWEEN '2019-04-22' and dateadd(day,119,'2019-04-22')  
group by 1)

select *
from 
(select count(*)
from players
)
cross join 
(select count(*)
from Total_players
)

