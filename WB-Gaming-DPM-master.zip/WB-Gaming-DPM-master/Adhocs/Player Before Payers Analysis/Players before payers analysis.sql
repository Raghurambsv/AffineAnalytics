
-------shang_Tsung---daily
with Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-06-17'
group by 1
having kombat_pack =1) ,

 returningplayers as (
select event_dt, player_id
from seven11_prod_da.wba_player_daily a
where a.event_dt  >= '2019-06-18' and event_dt <= '2019-06-24'
and player_id in (select distinct b.player_id from seven11_prod_da.wba_player_daily b
where player_id in (select _platform_account_id from Kp_owners)
and b.event_dt between dateadd(day,-14,a.event_dt ) and dateadd(day,-1,a.event_dt ) )
group by  1,2
order by 1,2
)
, reacquiredplayers as (
select event_dt, player_id
from seven11_prod_da.wba_player_daily a
where a.event_dt  >= '2019-06-18' and event_dt <= '2019-06-24'
and  a.event_dt!=install_dt
and player_id not in (select distinct b.player_id from returningplayers b
where b.event_dt = a.event_dt and a.player_id=b.player_id)
and player_id in (select _platform_account_id from Kp_owners)
group by  1,2
order by 1,2
)

select a.*,b.Total_players,c.Engaging_players
from
(select event_dt,count(distinct player_id) reacquired_players
from reacquiredplayers
where event_dt  between '2019-06-18' and  '2019-06-24'
group by 1) a
left join 
(select event_dt,count(distinct player_id) Total_players
from seven11_prod_da.wba_player_daily
where player_id in (select _platform_account_id from Kp_owners)
and event_dt  between '2019-06-18' and  '2019-06-24'
group by 1
) b
on a.event_dt = b.event_dt
left join 
(select date(_event_time_utc) event_dt,count(distinct _platform_account_id) Engaging_players
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Kp_owners)
and date(_event_time_utc)  between '2019-06-18' and  '2019-06-24'
and character in ('char_shangtsung')
and tower_id not like('Tutorial%')
group by 1
) c
on a.event_dt = c.event_dt
order by 1;

-------shang_Tsung---overall

with Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-06-17'
group by 1
having kombat_pack =1) ,

 returningplayers as (
select event_dt, player_id
from seven11_prod_da.wba_player_daily a
where a.event_dt  >= '2019-06-18' and event_dt <= '2019-06-24'
and player_id in (select distinct b.player_id from seven11_prod_da.wba_player_daily b
where player_id in (select _platform_account_id from Kp_owners)
and b.event_dt between dateadd(day,-14,a.event_dt ) and dateadd(day,-1,a.event_dt ) )
group by  1,2
order by 1,2
)
, reacquiredplayers as (
select event_dt, player_id
from seven11_prod_da.wba_player_daily a
where a.event_dt  >= '2019-06-18' and event_dt <= '2019-06-24'
and  a.event_dt!=install_dt
and player_id not in (select distinct b.player_id from returningplayers b
where b.event_dt = a.event_dt and a.player_id=b.player_id)
and player_id in (select _platform_account_id from Kp_owners)
group by  1,2
order by 1,2
)

select *
from
(select count(distinct player_id) reacquired_players
from reacquiredplayers
where event_dt  between '2019-06-18' and  '2019-06-24') 
cross join 
(select count(distinct player_id) Total_players
from seven11_prod_da.wba_player_daily
where player_id in (select _platform_account_id from Kp_owners)
and event_dt  between '2019-06-18' and  '2019-06-24'
)
cross join 
(select count(distinct _platform_account_id) Engaging_players
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Kp_owners)
and date(_event_time_utc)  between '2019-06-18' and  '2019-06-24'
and character in ('char_shangtsung')
and tower_id not like('Tutorial%')
)
order by 1 ;

----Converted after playing tutorial towers ---shang_Tsung

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-06-17'
group by 1
having kombat_pack =0) , 

Tutorial_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-06-24'
and character in ('char_shangtsung')
and tower_id like('Tutorial%')
group by 1)

select count(*) Tutorial_players_converted
from(
select _platform_account_id, 
			max(case when entitlement_name in ('shang_tsung','kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where _platform_account_id in (select * from Tutorial_engaged_players)
group by 1
having kombat_pack =1) ;


--------------Night wolf --daily

with Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-08-12'
group by 1
having kombat_pack =1) ,

 returningplayers as (
select event_dt, player_id
from seven11_prod_da.wba_player_daily a
where a.event_dt  >= '2019-08-13' and event_dt <= '2019-08-19'
and player_id in (select distinct b.player_id from seven11_prod_da.wba_player_daily b
where player_id in (select _platform_account_id from Kp_owners)
and b.event_dt between dateadd(day,-14,a.event_dt ) and dateadd(day,-1,a.event_dt ) )
group by  1,2
order by 1,2
)
, reacquiredplayers as (
select event_dt, player_id
from seven11_prod_da.wba_player_daily a
where a.event_dt  >= '2019-08-13' and event_dt <= '2019-08-19'
and  a.event_dt!=install_dt
and player_id not in (select distinct b.player_id from returningplayers b
where b.event_dt = a.event_dt and a.player_id=b.player_id)
and player_id in (select _platform_account_id from Kp_owners)
group by  1,2
order by 1,2
)

select a.*,b.Total_players,c.Engaging_players
from
(select event_dt,count(distinct player_id) reacquired_players
from reacquiredplayers
where event_dt  between '2019-08-13' and  '2019-08-19'
group by 1) a
left join 
(select event_dt,count(distinct player_id) Total_players
from seven11_prod_da.wba_player_daily
where player_id in (select _platform_account_id from Kp_owners)
and event_dt  between '2019-08-13' and  '2019-08-19'
group by 1
) b
on a.event_dt = b.event_dt
left join 
(select date(_event_time_utc) event_dt,count(distinct _platform_account_id) Engaging_players
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Kp_owners)
and date(_event_time_utc)  between '2019-08-13' and  '2019-08-19'
and character in ('char_nightwolf')
and tower_id not like('Tutorial%')
group by 1
) c
on a.event_dt = c.event_dt
order by 1;

-------Nightwolf---overall

with Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-08-12'
group by 1
having kombat_pack =1) ,

 returningplayers as (
select event_dt, player_id
from seven11_prod_da.wba_player_daily a
where a.event_dt  >= '2019-08-13' and event_dt <= '2019-08-19'
and player_id in (select distinct b.player_id from seven11_prod_da.wba_player_daily b
where player_id in (select _platform_account_id from Kp_owners)
and b.event_dt between dateadd(day,-14,a.event_dt ) and dateadd(day,-1,a.event_dt ) )
group by  1,2
order by 1,2
)
, reacquiredplayers as (
select event_dt, player_id
from seven11_prod_da.wba_player_daily a
where a.event_dt  >= '2019-08-13' and event_dt <= '2019-08-19'
and  a.event_dt!=install_dt
and player_id not in (select distinct b.player_id from returningplayers b
where b.event_dt = a.event_dt and a.player_id=b.player_id)
and player_id in (select _platform_account_id from Kp_owners)
group by  1,2
order by 1,2
)

select *
from
(select count(distinct player_id) reacquired_players
from reacquiredplayers
where event_dt  between '2019-08-13' and  '2019-08-19') 
cross join 
(select count(distinct player_id) Total_players
from seven11_prod_da.wba_player_daily
where player_id in (select _platform_account_id from Kp_owners)
and event_dt  between '2019-08-13' and  '2019-08-19'
)
cross join 
(select count(distinct _platform_account_id) Engaging_players
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Kp_owners)
and date(_event_time_utc)  between '2019-08-13' and  '2019-08-19'
and character in ('char_nightwolf')
and tower_id not like('Tutorial%')
)
order by 1 ;

----Converted after playing tutorial towers ---Nightwolf

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-08-12'
group by 1
having kombat_pack =0) , 

Tutorial_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-08-19'
and character in ('char_nightwolf')
and tower_id like('Tutorial%')
group by 1)

select count(*) Tutorial_players_converted
from(
select _platform_account_id, 
			max(case when entitlement_name in ('nightwolf','kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where _platform_account_id in (select * from Tutorial_engaged_players)
group by 1
having kombat_pack =1) ;

------------Sessions before purchasing


with shang_tsung_purchase_date as(
select _platform_account_id, min(_event_time_utc) purchase_time
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('shang_tsung') and date(_event_time_utc) >= '2019-06-25'
group by 1) ,

Shang_Tsung_Purchase_gap as (
select _platform_account_id,count(distinct _session_id) sessions_ST,count(distinct date(_event_time_utc)) days_ST
from (select a.*,b.purchase_time
	  from seven11_prod.seven11_match_result_player a
	  join shang_tsung_purchase_date b
	  on a._platform_account_id= b._platform_account_id )
where date(_event_time_utc) >= '2019-06-25' 
and _event_time_utc <=purchase_time
group by 1) ,

nightwolf_purchase_date as(
select _platform_account_id, min(_event_time_utc) purchase_time
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('nightwolf') and date(_event_time_utc) >= '2019-08-20'
group by 1) ,

nightwolf_Purchase_gap as (
select _platform_account_id,count(distinct _session_id) sessions_NW,count(distinct date(_event_time_utc)) days_NW
from (select a.*,b.purchase_time
	  from seven11_prod.seven11_match_result_player a
	  join shang_tsung_purchase_date b
	  on a._platform_account_id= b._platform_account_id )
where date(_event_time_utc) >= '2019-08-20' 
and _event_time_utc <=purchase_time
group by 1)

Select *
from(
select sessions_ST,count(distinct _platform_account_id) players_ST
from Shang_Tsung_Purchase_gap
group by 1) a
left join(
select sessions_NW,count(distinct _platform_account_id) players_NW
from nightwolf_Purchase_gap
group by 1) b
on a.sessions_ST = b.sessions_NW
order by 1 ;

------------days before purchasing


with shang_tsung_purchase_date as(
select _platform_account_id, min(_event_time_utc) purchase_time
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('shang_tsung') and date(_event_time_utc) >= '2019-06-25'
group by 1) ,

Shang_Tsung_Purchase_gap as (
select _platform_account_id,count(distinct _session_id) sessions_ST,count(distinct date(_event_time_utc)) days_ST
from (select a.*,b.purchase_time
	  from seven11_prod.seven11_match_result_player a
	  join shang_tsung_purchase_date b
	  on a._platform_account_id= b._platform_account_id )
where date(_event_time_utc) >= '2019-06-25' 
and _event_time_utc <=purchase_time
group by 1),

nightwolf_purchase_date as(
select _platform_account_id, min(_event_time_utc) purchase_time
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('nightwolf') and date(_event_time_utc) >= '2019-08-20'
group by 1) ,

nightwolf_Purchase_gap as (
select _platform_account_id,count(distinct _session_id) sessions_NW,count(distinct date(_event_time_utc)) days_NW
from (select a.*,b.purchase_time
	  from seven11_prod.seven11_match_result_player a
	  join shang_tsung_purchase_date b
	  on a._platform_account_id= b._platform_account_id )
where date(_event_time_utc) >= '2019-08-20' 
and _event_time_utc <=purchase_time
group by 1)

Select *
from(
select days_ST,count(distinct _platform_account_id) players_ST
from Shang_Tsung_Purchase_gap
group by 1) a
left join(
select days_NW,count(distinct _platform_account_id) players_NW
from nightwolf_Purchase_gap
group by 1) b
on a.days_ST = b.days_NW
order by 1 ;

