-----------------KP or Character------------------
----Converted after playing tutorial towers ---shang_Tsung

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-06-17'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-06-24'
and character in ('char_shangtsung')
and tower_id like('ShangTsungDLC_ShangTsungDLC%')
group by 1)

select *
from (
select  count(*) Tower_players_converted
from(
select _platform_account_id, 
			max(case when entitlement_name in ('shang_tsung','kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where _platform_account_id in (select * from Tower_engaged_players)
and date(wbanalyticssourcedate) between '2019-06-25' and '2019-07-01'
group by 1
having kombat_pack =1) 
)
cross join
(select count(*) Tower_engaged_players
from Tower_engaged_players
);

----Converted after playing tutorial towers ---Nightwolf

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-08-12'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-08-19'
and character in ('char_nightwolf')
and tower_id like('NightwolfDLC_NightwolfDLC%')
group by 1)

select *
from (
select  count(*) Tower_players_converted
from(
select _platform_account_id, 
			max(case when entitlement_name in ('nightwolf','kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where _platform_account_id in (select * from Tower_engaged_players)
and date(wbanalyticssourcedate) between '2019-08-20' and '2019-08-26'
group by 1
having kombat_pack =1) 
)
cross join
(select count(*) Tower_engaged_players
from Tower_engaged_players
);

----Converted after playing tutorial towers ---Terminator

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-10-07'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-10-14'
and character in ('char_terminator') and tower_id like ('%TerminatorDLC_TerminatorDLC%')
group by 1)

select *
from (
select  count(*) Tower_players_converted
from(
select _platform_account_id, 
			max(case when entitlement_name in ('terminator','kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where _platform_account_id in (select * from Tower_engaged_players)
and date(wbanalyticssourcedate) between '2019-10-15' and '2019-10-21'
group by 1
having kombat_pack =1) 
)
cross join
(select count(*) Tower_engaged_players
from Tower_engaged_players
);

----Converted after playing tutorial towers ---Sindel
with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-12-02'
group by 1
having kombat_pack =0) , 

Purchase_time as(
select _platform_account_id,min(_event_time_utc) time_stamp
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('sindel','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')   								 
group by 1) ,

Tower_engaged_players as(
select  a._platform_account_id
from seven11_prod.seven11_match_result_player a
left join Purchase_time b
on  a._platform_account_id = b._platform_account_id
where a._platform_account_id in (select _platform_account_id from Non_Kp_owners)
and (a._event_time_utc < b.time_stamp or b.time_stamp is NULL)
and date(_event_time_utc)  >=  '2019-12-03' 
and character in ('char_sindel')
and tower_id like ('%SindelDLC_SindelDLC%')
group by 1)

select *
from (
select  count(*) Tower_players_converted
from(
select _platform_account_id, 
			max(case when entitlement_name in ('sindel','kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where _platform_account_id in (select * from Tower_engaged_players)
and date(wbanalyticssourcedate) between '2019-12-03' and '2019-12-09'
group by 1
having kombat_pack =1) 
)
cross join
(select count(*) Tower_engaged_players
from Tower_engaged_players
);

----------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------
-----------------KP ------------------
----Converted after playing tutorial towers ---shang_Tsung

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-06-17'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-06-24'
and character in ('char_shangtsung')
and tower_id like('ShangTsungDLC_ShangTsungDLC%')
group by 1)

select *
from (
select  count(*) Tower_players_converted
from(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where _platform_account_id in (select * from Tower_engaged_players)
and date(wbanalyticssourcedate) between '2019-06-25' and '2019-07-01'
group by 1
having kombat_pack =1) 
)
cross join
(select count(*) Tower_engaged_players
from Tower_engaged_players
);

----Converted after playing tutorial towers ---Nightwolf

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-08-12'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-08-19'
and character in ('char_nightwolf')
and tower_id like('NightwolfDLC_NightwolfDLC%')
group by 1)

select *
from (
select  count(*) Tower_players_converted
from(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where _platform_account_id in (select * from Tower_engaged_players)
and date(wbanalyticssourcedate) between '2019-08-20' and '2019-08-26'
group by 1
having kombat_pack =1) 
)
cross join
(select count(*) Tower_engaged_players
from Tower_engaged_players
);

----Converted after playing tutorial towers ---Terminator

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-10-07'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-10-14'
and character in ('char_terminator') and tower_id like ('%TerminatorDLC_TerminatorDLC%')
group by 1)

select *
from (
select  count(*) Tower_players_converted
from(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where _platform_account_id in (select * from Tower_engaged_players)
and date(wbanalyticssourcedate) between '2019-10-15' and '2019-10-21'
group by 1
having kombat_pack =1) 
)
cross join
(select count(*) Tower_engaged_players
from Tower_engaged_players
);

----Converted after playing tutorial towers ---Sindel

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-12-02'
group by 1
having kombat_pack =0) , 

Purchase_time as(
select _platform_account_id,min(_event_time_utc) time_stamp
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('sindel','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')  								 
group by 1) ,

Tower_engaged_players as(
select  a._platform_account_id
from seven11_prod.seven11_match_result_player a
left join Purchase_time b
on  a._platform_account_id = b._platform_account_id
where a._platform_account_id in (select _platform_account_id from Non_Kp_owners)
and (a._event_time_utc < b.time_stamp or b.time_stamp is NULL)
and date(_event_time_utc)  >=  '2019-12-03' 
and character in ('char_sindel')
and tower_id like ('%SindelDLC_SindelDLC%')
group by 1)

select *
from (
select  count(*) Tower_players_converted
from(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where _platform_account_id in (select * from Tower_engaged_players)
and date(wbanalyticssourcedate) between '2019-12-03' and '2019-12-09'
group by 1
having kombat_pack =1) 
)
cross join
(select count(*) Tower_engaged_players
from Tower_engaged_players
);
----------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------
-----------------DLC Character------------------
----Converted after playing tutorial towers ---shang_Tsung

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-06-17'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-06-24'
and character in ('char_shangtsung')
and tower_id like('ShangTsungDLC_ShangTsungDLC%')
group by 1)

select *
from (
select  count(*) Tower_players_converted
from(
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('shang_tsung','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition',
						'digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
								and date(wbanalyticssourcedate) between '2019-06-25' and '2019-07-01'
                                 group by 1
                                 )
and _platform_account_id in (select * from Tower_engaged_players)
and date(wbanalyticssourcedate) between '2019-06-25' and '2019-07-01'
group by 1) 
)
cross join
(select count(*) Tower_engaged_players
from Tower_engaged_players
);

----Converted after playing tutorial towers ---Nightwolf

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-08-12'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-08-19'
and character in ('char_nightwolf')
and tower_id like('NightwolfDLC_NightwolfDLC%')
group by 1)

select *
from (
select  count(*) Tower_players_converted
from(
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('nightwolf','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition',
						'digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
								and date(wbanalyticssourcedate) between '2019-08-20' and '2019-08-26'
                                 group by 1
                           )
 and _platform_account_id in (select * from Tower_engaged_players)  
and date(wbanalyticssourcedate) between '2019-08-20' and '2019-08-26'
group by 1)  
)
cross join
(select count(*) Tower_engaged_players
from Tower_engaged_players
);

----Converted after playing tutorial towers ---Terminator

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-10-07'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-10-14'
and character in ('char_terminator') and tower_id like ('%TerminatorDLC_TerminatorDLC%')
group by 1)

select *
from (
select  count(*) Tower_players_converted
from(
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('terminator','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition',
						'digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
								 and date(wbanalyticssourcedate) between '2019-10-15' and '2019-10-21'
                                 group by 1
                        )
 and _platform_account_id in (select * from Tower_engaged_players)     		
 and date(wbanalyticssourcedate) between '2019-10-15' and '2019-10-21'
group by 1)
)
cross join
(select count(*) Tower_engaged_players
from Tower_engaged_players
);

----Converted after playing tutorial towers ---Sindel

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-12-02'
group by 1
having kombat_pack =0) , 

Purchase_time as(
select _platform_account_id,min(_event_time_utc) time_stamp
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('sindel','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')								 
group by 1) ,

Tower_engaged_players as(
select  a._platform_account_id
from seven11_prod.seven11_match_result_player a
left join Purchase_time b
on  a._platform_account_id = b._platform_account_id
where a._platform_account_id in (select _platform_account_id from Non_Kp_owners)
and (a._event_time_utc < b.time_stamp or b.time_stamp is NULL)
and date(_event_time_utc)  >=  '2019-12-03' 
and character in ('char_sindel')
and tower_id like ('%SindelDLC_SindelDLC%')
group by 1)

select *
from (
select  count(*) Tower_players_converted
from(
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('sindel','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition',
						'digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
						 		 and date(wbanalyticssourcedate) between '2019-12-03' and '2019-12-09'
                                 group by 1
                                 )
 and _platform_account_id in (select * from Tower_engaged_players)     	
 and date(wbanalyticssourcedate) between '2019-12-03' and '2019-12-09'
group by 1) 
)
cross join
(select count(*) Tower_engaged_players
from Tower_engaged_players
);


-----------------DLC Character Owners------------------
-----shang_Tsung owners

select  count(*) Shang_Tsung_Owners
from(
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('shang_tsung','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition',
						'digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
                                 group by 1
) 
and date(wbanalyticssourcedate) between '2019-06-25' and '2019-07-01'
group by 1)
;

----Nightwolf owners

select  count(*) Nightwolf_Owners
from(
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('nightwolf','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition',
						'digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
                                 group by 1
                                 )
and date(wbanalyticssourcedate) between '2019-08-20' and '2019-08-26'								 
group by 1)
;

-----Terminator owners

select  count(*) Terminator_Owners
from(
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('terminator','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition',
						'digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
                                 group by 1
                                 )
and date(wbanalyticssourcedate) between '2019-10-15' and '2019-10-21'								 
group by 1)
;

--Sindel owners

select  count(*) Sindel_Owners
from(
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('sindel','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition',
						'digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
                                 group by 1
                                 )
and date(wbanalyticssourcedate) between '2019-12-03' and '2019-12-09'								 
group by 1)
;

----Weekly Players in Tower weeks

Select *
from(
select count(distinct player_id) Weekly_Players_ShangTsung
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-06-18' and '2019-06-24')
cross join 
(
select count(distinct player_id) Weekly_Players_Nightwolf
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-08-13' and '2019-08-19')
cross join 
(
select count(distinct player_id) Weekly_Players_Terminator
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-10-08' and '2019-10-14')
cross join 
(
select count(distinct player_id) Weekly_Players_Sindel
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-12-03' and '2019-12-09')
;

