-----------------KP or Character------------------
----Players converted without playing towers ---shang_Tsung

with dlc_entitlement as(
select _platform_account_id,entitlement_name,min(_event_time_utc) _event_time_utc
from seven11_prod.seven11_dlc_entitlement
group by 1,2
),

Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where date(_event_time_utc) <= '2019-06-17'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-06-24'
and character in ('char_shangtsung')
and tower_id like('ShangTsungDLC_ShangTsungDLC%')
group by 1)


select  count(*) Player_count
from(
select _platform_account_id, 
			max(case when entitlement_name in ('shang_tsung','kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where _platform_account_id not in (select * from Tower_engaged_players)
and date(_event_time_utc) between '2019-06-25' and '2019-07-01'
group by 1
having kombat_pack =1) 
;

----Players converted without playing towers  ---Nightwolf

with dlc_entitlement as(
select _platform_account_id,entitlement_name,min(_event_time_utc) _event_time_utc
from seven11_prod.seven11_dlc_entitlement
group by 1,2
),

Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where date(_event_time_utc) <= '2019-08-12'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-08-19'
and character in ('char_nightwolf')
and tower_id like('NightwolfDLC_NightwolfDLC%')
group by 1)


select  count(*) Player_count
from(
select _platform_account_id, 
			max(case when entitlement_name in ('nightwolf','kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where _platform_account_id not in (select * from Tower_engaged_players)
and date(_event_time_utc) between '2019-08-20' and '2019-08-26'
group by 1
having kombat_pack =1) 
;

----Players converted without playing towers  ---Terminator

with dlc_entitlement as(
select _platform_account_id,entitlement_name,min(_event_time_utc) _event_time_utc
from seven11_prod.seven11_dlc_entitlement
group by 1,2
),

Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where date(_event_time_utc) <= '2019-10-07'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-10-14'
and character in ('char_terminator') and tower_id like ('%TerminatorDLC_TerminatorDLC%')
group by 1)


select  count(*) Player_count
from(
select _platform_account_id, 
			max(case when entitlement_name in ('terminator','kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where _platform_account_id not in (select * from Tower_engaged_players)
and date(_event_time_utc) between '2019-10-15' and '2019-10-21'
group by 1
having kombat_pack =1) 
;

----Players converted without playing towers ---Sindel

with dlc_entitlement as(
select _platform_account_id,entitlement_name,min(_event_time_utc) _event_time_utc
from seven11_prod.seven11_dlc_entitlement
group by 1,2
),

Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where date(_event_time_utc) <= '2019-12-02'
group by 1
having kombat_pack =0) , 

Purchase_time as(
select _platform_account_id,min(_event_time_utc) time_stamp
from dlc_entitlement
where entitlement_name in ('sindel','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')   								 
group by 1) ,

Tower_engaged_players as(
select  a._platform_account_id
from seven11_prod.seven11_match_result_player a
left join Purchase_time b
on  a._platform_account_id = b._platform_account_id
where a._platform_account_id in (select _platform_account_id from Non_Kp_owners)
and (a._event_time_utc < b.time_stamp or b.time_stamp is NULL)
and date(_event_time_utc)  >=  '2019-12-03' 
and character in ('char_sindel')
and tower_id like ('%SindelDLC_SindelDLC%')
group by 1)


select  count(*) Player_count
from(
select _platform_account_id, 
			max(case when entitlement_name in ('sindel','kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where _platform_account_id not in (select * from Tower_engaged_players)
and date(_event_time_utc) between '2019-12-03' and '2019-12-09'
group by 1
having kombat_pack =1) 
;

----------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------
-----------------KP ------------------
----Players converted without playing towers  ---shang_Tsung

with dlc_entitlement as(
select _platform_account_id,entitlement_name,min(_event_time_utc) _event_time_utc
from seven11_prod.seven11_dlc_entitlement
group by 1,2
),

Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where date(_event_time_utc) <= '2019-06-17'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-06-24'
and character in ('char_shangtsung')
and tower_id like('ShangTsungDLC_ShangTsungDLC%')
group by 1)


select  count(*) Player_count
from(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where _platform_account_id not in (select * from Tower_engaged_players)
and date(_event_time_utc) between '2019-06-25' and '2019-07-01'
group by 1
having kombat_pack =1) 
;

----Players converted without playing towers  ---Nightwolf

with dlc_entitlement as(
select _platform_account_id,entitlement_name,min(_event_time_utc) _event_time_utc
from seven11_prod.seven11_dlc_entitlement
group by 1,2
),

Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where date(_event_time_utc) <= '2019-08-12'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-08-19'
and character in ('char_nightwolf')
and tower_id like('NightwolfDLC_NightwolfDLC%')
group by 1)


select  count(*) Player_count
from(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where _platform_account_id not in (select * from Tower_engaged_players)
and date(_event_time_utc) between '2019-08-20' and '2019-08-26'
group by 1
having kombat_pack =1) 
;

----Players converted without playing towers ---Terminator

with dlc_entitlement as(
select _platform_account_id,entitlement_name,min(_event_time_utc) _event_time_utc
from seven11_prod.seven11_dlc_entitlement
group by 1,2
),

Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where date(_event_time_utc) <= '2019-10-07'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-10-14'
and character in ('char_terminator') and tower_id like ('%TerminatorDLC_TerminatorDLC%')
group by 1)


select  count(*) Player_count
from(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where _platform_account_id not in (select * from Tower_engaged_players)
and date(_event_time_utc) between '2019-10-15' and '2019-10-21'
group by 1
having kombat_pack =1) 
;

----Players converted without playing towers  ---Sindel

with dlc_entitlement as(
select _platform_account_id,entitlement_name,min(_event_time_utc) _event_time_utc
from seven11_prod.seven11_dlc_entitlement
group by 1,2
),

Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where date(_event_time_utc) <= '2019-12-02'
group by 1
having kombat_pack =0) , 

Purchase_time as(
select _platform_account_id,min(_event_time_utc) time_stamp
from dlc_entitlement
where entitlement_name in ('sindel','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')  								 
group by 1) ,

Tower_engaged_players as(
select  a._platform_account_id
from seven11_prod.seven11_match_result_player a
left join Purchase_time b
on  a._platform_account_id = b._platform_account_id
where a._platform_account_id in (select _platform_account_id from Non_Kp_owners)
and (a._event_time_utc < b.time_stamp or b.time_stamp is NULL)
and date(_event_time_utc)  >=  '2019-12-03' 
and character in ('char_sindel')
and tower_id like ('%SindelDLC_SindelDLC%')
group by 1)


select  count(*) Player_count
from(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from dlc_entitlement
where _platform_account_id not in (select * from Tower_engaged_players)
and date(_event_time_utc) between '2019-12-03' and '2019-12-09'
group by 1
having kombat_pack =1)
;
----------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------
-----------------DLC Character------------------
----Players converted without playing towers  ---shang_Tsung

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-06-17'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-06-24'
and character in ('char_shangtsung')
and tower_id like('ShangTsungDLC_ShangTsungDLC%')
group by 1)


select  count(*) Player_count
from(
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('shang_tsung','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition',
						'digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
								and date(wbanalyticssourcedate) between '2019-06-25' and '2019-07-01'
                                 group by 1
                                 )
and _platform_account_id not in (select * from Tower_engaged_players)
and date(wbanalyticssourcedate) between '2019-06-25' and '2019-07-01'
group by 1) 
;

----Players converted without playing towers ---Nightwolf

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-08-12'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-08-19'
and character in ('char_nightwolf')
and tower_id like('NightwolfDLC_NightwolfDLC%')
group by 1)


select  count(*) Player_count
from(
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('nightwolf','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition',
						'digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
								and date(wbanalyticssourcedate) between '2019-08-20' and '2019-08-26'
                                 group by 1
                           )
 and _platform_account_id not in (select * from Tower_engaged_players)  
and date(wbanalyticssourcedate) between '2019-08-20' and '2019-08-26'
group by 1)  
;

----Players converted without playing towers ---Terminator

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-10-07'
group by 1
having kombat_pack =0) , 

Tower_engaged_players as(
select  _platform_account_id
from seven11_prod.seven11_match_result_player
where _platform_account_id in (select _platform_account_id from Non_Kp_owners)
and date(_event_time_utc)  <=  '2019-10-14'
and character in ('char_terminator') and tower_id like ('%TerminatorDLC_TerminatorDLC%')
group by 1)


select  count(*) Player_count
from(
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('terminator','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition',
						'digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
								 and date(wbanalyticssourcedate) between '2019-10-15' and '2019-10-21'
                                 group by 1
                        )
 and _platform_account_id not in (select * from Tower_engaged_players)     		
 and date(wbanalyticssourcedate) between '2019-10-15' and '2019-10-21'
group by 1)
;

----Players converted without playing towers ---Sindel

with Non_Kp_owners as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version',
			'physical_premium_edition','digital_preorder_premium_edition',
			'digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-12-02'
group by 1
having kombat_pack =0) , 

Purchase_time as(
select _platform_account_id,min(_event_time_utc) time_stamp
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('sindel','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')								 
group by 1) ,

Tower_engaged_players as(
select  a._platform_account_id
from seven11_prod.seven11_match_result_player a
left join Purchase_time b
on  a._platform_account_id = b._platform_account_id
where a._platform_account_id in (select _platform_account_id from Non_Kp_owners)
and (a._event_time_utc < b.time_stamp or b.time_stamp is NULL)
and date(_event_time_utc)  >=  '2019-12-03' 
and character in ('char_sindel')
and tower_id like ('%SindelDLC_SindelDLC%')
group by 1)


select  count(*) Player_count
from(
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('sindel','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition',
						'digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
						 		 and date(wbanalyticssourcedate) between '2019-12-03' and '2019-12-09'
                                 group by 1
                                 )
 and _platform_account_id not in (select * from Tower_engaged_players)     	
 and date(wbanalyticssourcedate) between '2019-12-03' and '2019-12-09'
group by 1) 
;
