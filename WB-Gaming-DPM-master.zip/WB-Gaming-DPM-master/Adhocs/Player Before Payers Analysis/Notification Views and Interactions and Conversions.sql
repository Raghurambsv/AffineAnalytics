------------------Notification and PoP up Views and Interactions
----Notification and PoP up Views--Shang Tsung---

select source_index ,decision,count(distinct _platform_account_id) views
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-06-18' and '2019-06-26'
and (source_index like '%shang-tsung%' or source_index like '%klassic-ninja-skin-pack%' or source_index like '%kombat-pack%')
group by 1,2
order by 1,2 ;


select source_index ,count(distinct _platform_account_id) views
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-06-18' and '2019-06-26'
and (source_index like '%shang-tsung%' or source_index like '%klassic-ninja-skin-pack%' or source_index like '%kombat-pack%')
group by 1
order by 1;

----Notification and PoP up Views--Nightwolf---

select source_index ,decision,count(distinct _platform_account_id) views
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-08-13' and '2019-08-21'
and (source_index like '%klassic-arcade-fighter-pack%' or source_index like '%nightwolf%' or source_index like '%kombat-pack%')
group by 1,2
order by 1,2 ;

select source_index ,count(distinct _platform_account_id) views
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-08-13' and '2019-08-21'
and (source_index like '%klassic-arcade-fighter-pack%' or source_index like '%nightwolf%' or source_index like '%kombat-pack%')
group by 1
order by 1;

----Notification and PoP up Views--terminator---

select source_index ,decision,count(distinct _platform_account_id) views
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-10-08' and '2019-10-16'
and (source_index like '%double-feature-skin-pack%' or source_index like '%terminator%' or source_index like '%kombat-pack%')
group by 1,2
order by 1,2 ;


select source_index ,count(distinct _platform_account_id) views
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-10-08' and '2019-10-16'
and (source_index like '%double-feature-skin-pack%' or source_index like '%terminator%' or source_index like '%kombat-pack%')
group by 1
order by 1;

----Notification and PoP up Views--sindel---

select source_index ,decision,count(distinct _platform_account_id) views
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-12-03' and '2019-12-11'
and (source_index like '%gothic-horror-skin-pack%' or source_index like '%sindel%' or source_index like '%kombat-pack%')
group by 1,2
order by 1,2 ;

select source_index ,count(distinct _platform_account_id) views
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-12-03' and '2019-12-11'
and (source_index like '%gothic-horror-skin-pack%' or source_index like '%sindel%' or source_index like '%kombat-pack%')
group by 1
order by 1 ;

--------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------
---Notification and PoP up converters to KP during Trial tower period (9 days)
---Notification and PoP up converters to KP --------Shang Tsung WEEK--

with Notif_Viewers as(
select source_index , _platform_account_id,min(_event_time_utc) view_ts
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-06-18' and '2019-06-26'
and (source_index like '%shang-tsung%' or source_index like '%klassic-ninja-skin-pack%' or source_index like '%kombat-pack%')
group by 1,2)
,
KP_Owners as(
select _platform_account_id KP_owner,min(_event_time_utc) Purchase_ts
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('kombat_pack')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition',
								 'digital_premium_edition','kollectors_edition_skin')
                                 group by 1
                                 )
group by 1)


select  source_index ,count(distinct KP_owner) KP_Converted
from(
select *
from Notif_Viewers a
join KP_Owners b
on a._platform_account_id = b.KP_owner
where a.view_ts < b.Purchase_ts
and date(Purchase_ts) between '2019-06-18' and '2019-06-26'
)
group by 1
order by 1;

----Notification and PoP up converters to KP --Nightwolf WEEK---

with Notif_Viewers as(
select source_index , _platform_account_id,min(_event_time_utc) view_ts
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-08-13' and '2019-08-21'
and (source_index like '%klassic-arcade-fighter-pack%' or source_index like '%nightwolf%' or source_index like '%kombat-pack%')
group by 1,2)
,
KP_Owners as(
select _platform_account_id KP_owner,min(_event_time_utc) Purchase_ts
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('kombat_pack')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition',
								 'digital_premium_edition','kollectors_edition_skin')
                                 group by 1
                                 )
group by 1)


select  source_index ,count(distinct KP_owner) KP_Converted
from(
select *
from Notif_Viewers a
join KP_Owners b
on a._platform_account_id = b.KP_owner
where a.view_ts < b.Purchase_ts
and date(Purchase_ts) between '2019-08-13' and '2019-08-21'
)
group by 1
order by 1;

----Notification and PoP up converters to KP ---terminator  WEEK---

with Notif_Viewers as(
select source_index , _platform_account_id,min(_event_time_utc) view_ts
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-10-08' and '2019-10-16'
and (source_index like '%double-feature-skin-pack%' or source_index like '%terminator%' or source_index like '%kombat-pack%')
group by 1,2)
,
KP_Owners as(
select _platform_account_id KP_owner,min(_event_time_utc) Purchase_ts
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('kombat_pack')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition',
								 'digital_premium_edition','kollectors_edition_skin')
                                 group by 1
                                 )
group by 1)


select  source_index ,count(distinct KP_owner) KP_Converted
from(
select *
from Notif_Viewers a
join KP_Owners b
on a._platform_account_id = b.KP_owner
where a.view_ts < b.Purchase_ts
and date(Purchase_ts) between '2019-10-08' and '2019-10-16'
)
group by 1
order by 1;
----Notification and PoP up converters to KP ---sindel  WEEK---

with Notif_Viewers as(
select source_index , _platform_account_id,min(_event_time_utc) view_ts
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-12-03' and '2019-12-11'
and (source_index like '%gothic-horror-skin-pack%' or source_index like '%sindel%' or source_index like '%kombat-pack%')
group by 1,2)
,
KP_Owners as(
select _platform_account_id KP_owner,min(_event_time_utc) Purchase_ts
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('kombat_pack')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition',
								 'digital_premium_edition','kollectors_edition_skin')
                                 group by 1
                                 )
group by 1)


select  source_index ,count(distinct KP_owner) KP_Converted
from(
select *
from Notif_Viewers a
join KP_Owners b
on a._platform_account_id = b.KP_owner
where a.view_ts < b.Purchase_ts
and date(Purchase_ts) between '2019-12-03' and '2019-12-11'
)
group by 1
order by 1;

-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------
---Notification and PoP up converters to DLC during Trial tower period (9 days)
---Notification and PoP up converters to Shang Tsung 

with Notif_Viewers as(
select source_index , _platform_account_id,min(_event_time_utc) view_ts
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-06-18' and '2019-06-26'
and (source_index like '%shang-tsung%' or source_index like '%klassic-ninja-skin-pack%' or source_index like '%kombat-pack%')
group by 1,2)
,
DLC_Owners as(
select _platform_account_id DLC_owner,min(_event_time_utc) Purchase_ts
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('shang_tsung')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition',
								 'digital_premium_edition','kollectors_edition_skin')
                                 group by 1
                                 )
group by 1)


select  source_index ,count(distinct DLC_owner) DLC_Converted
from(
select *
from Notif_Viewers a
join DLC_Owners b
on a._platform_account_id = b.DLC_owner
where a.view_ts < b.Purchase_ts
and date(Purchase_ts) between '2019-06-18' and '2019-06-26'
)
group by 1
order by 1;

----Notification and PoP up converters to Nightwolf 

with Notif_Viewers as(
select source_index , _platform_account_id,min(_event_time_utc) view_ts
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-08-13' and '2019-08-21'
and (source_index like '%klassic-arcade-fighter-pack%' or source_index like '%nightwolf%' or source_index like '%kombat-pack%')
group by 1,2)
,
DLC_Owners as(
select _platform_account_id DLC_owner,min(_event_time_utc) Purchase_ts
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('nightwolf')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition',
								 'digital_premium_edition','kollectors_edition_skin')
                                 group by 1
                                 )
group by 1)


select  source_index ,count(distinct DLC_owner) DLC_Converted
from(
select *
from Notif_Viewers a
join DLC_Owners b
on a._platform_account_id = b.DLC_owner
where a.view_ts < b.Purchase_ts
and date(Purchase_ts) between '2019-08-13' and '2019-08-21'
)
group by 1
order by 1;

----Notification and PoP up converters to terminator  

with Notif_Viewers as(
select source_index , _platform_account_id,min(_event_time_utc) view_ts
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-10-08' and '2019-10-16'
and (source_index like '%double-feature-skin-pack%' or source_index like '%terminator%' or source_index like '%kombat-pack%')
group by 1,2)
,
DLC_Owners as(
select _platform_account_id DLC_owner,min(_event_time_utc) Purchase_ts
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('terminator')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition',
								 'digital_premium_edition','kollectors_edition_skin')
                                 group by 1
                                 )
group by 1)


select  source_index ,count(distinct DLC_owner) DLC_Converted
from(
select *
from Notif_Viewers a
join DLC_Owners b
on a._platform_account_id = b.DLC_owner
where a.view_ts < b.Purchase_ts
and date(Purchase_ts) between '2019-10-08' and '2019-10-16'
)
group by 1
order by 1;
----Notification and PoP up converters to sindel  

with Notif_Viewers as(
select source_index , _platform_account_id,min(_event_time_utc) view_ts
from seven11_prod.seven11_ui_decision
where date(_event_time_utc) between '2019-12-03' and '2019-12-11'
and (source_index like '%gothic-horror-skin-pack%' or source_index like '%sindel%' or source_index like '%kombat-pack%')
group by 1,2)
,
DLC_Owners as(
select _platform_account_id DLC_owner,min(_event_time_utc) Purchase_ts
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('sindel')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition',
								 'digital_premium_edition','kollectors_edition_skin')
                                 group by 1
                                 )
group by 1)


select  source_index ,count(distinct DLC_owner) DLC_Converted
from(
select *
from Notif_Viewers a
join DLC_Owners b
on a._platform_account_id = b.DLC_owner
where a.view_ts < b.Purchase_ts
and date(Purchase_ts) between '2019-12-03' and '2019-12-11'
)
group by 1
order by 1;