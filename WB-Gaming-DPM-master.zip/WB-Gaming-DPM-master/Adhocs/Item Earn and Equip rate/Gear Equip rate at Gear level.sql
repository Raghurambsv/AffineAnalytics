-----Equipment----At 'GEAR' LEVEL-----It's throwing an error but I could not figure out the mistake
-------Overall
with Gear_A as (select  _platform_account_id ,gear_1,Substring(gear_1,1, (POSITION('_L' In gear_1)-1)) AS Varchar Gear_name
from seven11_prod.seven11_gameplay_customization
group by 1,2),
Gear_B as (select  _platform_account_id ,gear_2,Substring(gear_2,1, (POSITION('_L' In gear_2)-1)) AS Varchar Gear_name
from seven11_prod.seven11_gameplay_customization
group by 1,2
),
Gear_C as (select  _platform_account_id ,gear_3,Substring(gear_3,1, (POSITION('_L' In gear_3)-1))AS Varchar Gear_name
from seven11_prod.seven11_gameplay_customization
group by 1,2
),
Skins_Equipped as (select  _platform_account_id ,skin, Substring(skin,1, (POSITION('_L' In skin)-1))AS Varchar Skin_name
from seven11_prod.seven11_gameplay_customization
group by 1,2
) ,
Gears as(
Select _platform_account_id,Gear_name from Gear_A
Union Select _platform_account_id,Gear_name from Gear_B
Union Select _platform_account_id,Gear_name from Gear_C
group by 1,2
) ,
Skins as(
Select _platform_account_id,Skin_name
from Skins_Equipped
group by 1,2)


Select *
from(
Select Count(Gear_name) Gears_Equipped
from Gears)
cross join 
(Select Count(Skin_name) Skins_Equipped
from Skins) 

;

-----Equipment----At 'GEAR' LEVEL-----It's throwing an error but I could not figure out the mistake
-------Top Characters

With Hours_Played_Top  as (
		Select Sum(Hrs_Played) Total_hrsplayed
from(
Select _platform_account_id,Kombatant,Hrs_Played,Rank()over(partition by _platform_account_id order by Hrs_Played desc) Rank
from(
Select _platform_account_id,Character Kombatant,Sum(match_length::float)/3600 Hrs_Played
from seven11_prod.seven11_match_result_player
where ai_difficulty =-1 and date(wbanalyticssourcedate) >= '2019-04-22'  
group by 1,2))
where Rank =1 
			---2
			----3
		),

Kombatant_Top as(Select _platform_account_id, Kombatant
from(
Select _platform_account_id,Kombatant,Hrs_Played,Rank()over(partition by _platform_account_id order by matches desc) Rank
from(
Select _platform_account_id,Character Kombatant,count(distinct match_id) matches,Sum(match_length::float)/3600 Hrs_Played
from seven11_prod.seven11_match_result_player
where ai_difficulty =-1 and date(wbanalyticssourcedate) >= '2019-04-22'  
group by 1,2))
where Rank =1 
			---2
			----3
			),

Gameplay_Cus as (select  a.*
from seven11_prod.seven11_gameplay_customization a
join Kombatant_Top b
on a._platform_account_id = b._platform_account_id
and a.character = b.kombatant) ,

Gear_A as (select  _platform_account_id ,gear_1,Substring(gear_1,1, (POSITION('_L' In gear_1)-1)) AS Varchar Gear_name
from Gameplay_Cus
group by 1,2),
Gear_B as (select  _platform_account_id ,gear_2,Substring(gear_2,1, (POSITION('_L' In gear_2)-1)) AS Varchar Gear_name
from Gameplay_Cus
group by 1,2
),
Gear_C as (select  _platform_account_id ,gear_3,Substring(gear_3,1, (POSITION('_L' In gear_3)-1))AS Varchar Gear_name
from Gameplay_Cus
group by 1,2
),
Skins_Equipped as (select  _platform_account_id ,skin, Substring(skin,1, (POSITION('_L' In skin)-1))AS Varchar Skin_name
from Gameplay_Cus
group by 1,2
) ,
Gears as(
Select _platform_account_id,Gear_name from Gear_A
Union Select _platform_account_id,Gear_name from Gear_B
Union Select _platform_account_id,Gear_name from Gear_C
group by 1,2
) ,
Skins as(
Select _platform_account_id,Skin_name
from Skins_Equipped
group by 1,2)


Select *
from(
Select Count(Gear_name) Gears_Equipped
from Gears)
cross join 
(Select Count(Skin_name) Skins_Equipped
from Skins) ;

