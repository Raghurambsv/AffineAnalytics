-------------------------------------------Overall-----------------------------
------Gear Earn rate---Overall

With Unlocks as(Select _platform_account_id,unlock_name, case when unlock_name LIKE ('%Gear%') Then 'Gear' 
				when unlock_name LIKE ('%Skin%') Then 'Skin' 
				When unlock_name LIKE ('%Brutality%') Then 'Brutality' 
				else 'Other' end as Category
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) >= '2019-04-22'
group by 1,2,3) ,

Hours_Played  as (
		select  sum(total_hours::float) Total_hrsplayed
		from seven11_prod_da.wba_player_daily
		where event_dt >= '2019-04-22'  and total_hours > 0 
		),
Total_Unlocks as(	
Select Category, Count(unlock_name) Items_earned
from Unlocks
group by 1)

Select Category,Items_earned,Total_hrsplayed,
Items_earned/Total_hrsplayed Earn_rate
FROM Total_Unlocks
CROSS JOIN Hours_Played ;

---Equipment---At 'Gear_level'  level (Not distinct)

with Gear_A as (select  _platform_account_id ,gear_1 Gear_name
from seven11_prod.seven11_gameplay_customization
),
Gear_B as (select  _platform_account_id ,gear_2 Gear_name
from seven11_prod.seven11_gameplay_customization
),
Gear_C as (select  _platform_account_id ,gear_3 Gear_name
from seven11_prod.seven11_gameplay_customization
),
Skins_Equipped as (select  _platform_account_id ,skin Skin_name
from seven11_prod.seven11_gameplay_customization
) ,
Gears_Equipped as(
Select *
from Gear_A
Union Select * from Gear_B
Union Select * from Gear_C)

Select *
from(
Select Count(Gear_name) Gears_Equipped
from Gears_Equipped)
cross join 
(Select Count(Skin_name) Skins_Equipped
from Skins_Equipped) ;

---Equipment---At 'Gear_level'  level ( distinct)

with Gear_A as (select  _platform_account_id ,gear_1 Gear_name
from seven11_prod.seven11_gameplay_customization
group by 1,2),
Gear_B as (select  _platform_account_id ,gear_2 Gear_name
from seven11_prod.seven11_gameplay_customization
group by 1,2),
Gear_C as (select  _platform_account_id ,gear_3 Gear_name
from seven11_prod.seven11_gameplay_customization
group by 1,2),
Skins_Equipped as (select  _platform_account_id ,skin Skin_name
from seven11_prod.seven11_gameplay_customization
group by 1,2) ,
Gears_Equipped as(
Select *
from Gear_A
Union Select * from Gear_B
Union Select * from Gear_C)

Select *
from(
Select Count(Gear_name) Gears_Equipped
from Gears_Equipped)
cross join 
(Select Count(Skin_name) Skins_Equipped
from Skins_Equipped) ;


-----Equipment----At 'GEAR' LEVEL-----It's throwing an error but I could not figure out the mistake

with Gear_A as (select  _platform_account_id ,gear_1,Substring(gear_1,1, (POSITION('_L' In gear_1)-1)) AS Varchar Gear_name
from seven11_prod.seven11_gameplay_customization
group by 1,2),
Gear_B as (select  _platform_account_id ,gear_2,Substring(gear_2,1, (POSITION('_L' In gear_2)-1)) AS Varchar Gear_name
from seven11_prod.seven11_gameplay_customization
group by 1,2
),
Gear_C as (select  _platform_account_id ,gear_3,Substring(gear_3,1, (POSITION('_L' In gear_3)-1))AS Varchar Gear_name
from seven11_prod.seven11_gameplay_customization
group by 1,2
),
Skins_Equipped as (select  _platform_account_id ,skin, Substring(skin,1, (POSITION('_L' In skin)-1))AS Varchar Skin_name
from seven11_prod.seven11_gameplay_customization
group by 1,2
) ,
Gears as(
Select _platform_account_id,Gear_name from Gear_A
Union Select _platform_account_id,Gear_name from Gear_B
Union Select _platform_account_id,Gear_name from Gear_C
group by 1,2
) ,
Skins as(
Select _platform_account_id,Skin_name
from Skins_Equipped
group by 1,2)


Select *
from(
Select Count(Gear_name) Gears_Equipped
from Gears)
cross join 
(Select Count(Skin_name) Skins_Equipped
from Skins) 

;
