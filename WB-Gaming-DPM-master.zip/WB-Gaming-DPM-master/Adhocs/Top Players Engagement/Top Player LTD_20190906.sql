
with players as (
select player_id 
from
(

	select a.event_dt dt,player_id, b.event_dt, next_dat,hrsplayed,cum , sum(cum) over(partition by a.event_dt) cum_daily_tot_mk11 , sum(cum) over(partition by dt order by cum asc rows between unbounded preceding and current row ) total, total::float/cum_daily_tot_mk11::float perc_fina
	from 
	(
	select event_dt
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22' 
	group by 1
	) a
	left join
	(
	select  player_id, event_dt, coalesce (lead(event_dt,1) over (partition by player_id order by event_dt),date(getdate ())) next_dat, sum(total_hours) hrsplayed, sum(hrsplayed) over (partition by player_id order by event_dt asc rows between unbounded preceding and current row) cum
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22' 
	group by 1,2

	) b
	on a.event_dt >= b.event_dt
	and a.event_dt < b.next_dat
)
where perc_fina > 0.2
and dt = '2019-06-05 00:00:00'
group by 1
),

  datedim as ( select event_dt YearMonthDay from seven11_prod_da.wba_fact_activity group by 1)


            select period, RetentionDate, newdate, count(c.player_id) retained_players, count(b.player_id) cohorts
            from
            (
              SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
                FROM datedim d
                JOIN datedim  d2 ON d.YearMonthDay < d2.YearMonthDay
                WHERE  (d.YearMonthDay>='2019-04-22' and d.YearMonthDay < CAST(getdate() as DATE))
                AND (d2.YearMonthDay>='2019-04-22' and  d2.YearMonthDay < CAST(getdate() as DATE))
            ) A
            join
            (

              select player_id, min(event_dt) yearmonthday
              from seven11_prod_da.wba_player_daily a
			  join players b
			  using(player_id)
			  where event_dt >= '2019-04-22'
              group by 1

            )  B
            on a.NewDate = b.yearmonthday
            left join
            (

              select event_dt yearmonthday, player_id
              from seven11_prod_da.wba_player_daily a
			  join players b
			  using(player_id)
              group by 1,2

            ) C
            on b.player_id = c.player_id
            and c.yearmonthday = a.retentiondate
            where b.yearmonthday >= '2019-04-22'
            group by 1,2,3
          order by 3,2 desc