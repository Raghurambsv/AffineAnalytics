--- Retention ----Top players---IJ2 ---

with players as (
select platformaccountid 
from
(
select platformaccountid, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select platformaccountid, sum(totaldurationminutes::float)/60  hrsplayed, sum(hrsplayed) over () totaltime,  hrsplayed/ sum(hrsplayed) over () perc, 1::float / count(platformaccountid) over ()  cum_players
		from pachinko_prod_da.factactivity 
		where DATE(starttimestamp) BETWEEN '2017-05-15' and dateadd(day,119,'2017-05-15')  
		group by 1
	)
)
where cumsumplayers > 0.99
	--cumsumplayers > 0.90
	--cumsumplayers > 0.75
	--cumsumplayers > 0.65
	--cumsumplayers > 0.55
	--cumsumplayers > 0.45
	--cumsumplayers > 0.35
	--cumsumplayers > 0.25
	--cumsumplayers > 0.15
	--cumsumplayers > 0.05
group by 1
),

datedim as ( select wbanalyticsprocessingdate YearMonthDay from pachinko_prod.pachinko_activitysession_begin group by 1) ,

Retention as (select period, RetentionDate, newdate, count(c.platformaccountid) retained_players, count(b.platformaccountid) cohorts
from
    (
        SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
        FROM datedim d
        JOIN datedim  d2 ON d.YearMonthDay < d2.YearMonthDay
        WHERE  (d.YearMonthDay BETWEEN '2017-05-15' and dateadd(day,119,'2017-05-15') )
        AND (d2.YearMonthDay BETWEEN '2017-05-15' and dateadd(day,119,'2017-05-15') )
    ) A
join
	(
		select platformaccountid, min(DATE(starttimestamp)) yearmonthday
        from pachinko_prod_da.factactivity  a
		join players b
		using( platformaccountid)
		where DATE(starttimestamp) BETWEEN '2017-05-15' and dateadd(day,119,'2017-05-15')
        group by 1

    )  B
on a.NewDate = b.yearmonthday
left join
    (
      select DATE(starttimestamp) yearmonthday, platformaccountid
 	  from pachinko_prod_da.factactivity a
	  join players b
	  using(platformaccountid)
	  where DATE(starttimestamp) BETWEEN '2017-05-15' and dateadd(day,119,'2017-05-15')
      group by 1,2
    ) C
on b.platformaccountid = c.platformaccountid
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2017-05-15'
group by 1,2,3
) 

Select Period,Sum(Retained_players)::float/Sum(cohorts) Retention
from Retention
group by 1
order by 1;

-----Engagement----Top players---IJ2
with players as (
select platformaccountid 
from
(
select platformaccountid, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select platformaccountid, sum(totaldurationminutes::float)/60  hrsplayed, sum(hrsplayed) over () totaltime,  hrsplayed/ sum(hrsplayed) over () perc, 1::float / count(platformaccountid) over ()  cum_players
		from pachinko_prod_da.factactivity 
		where DATE(starttimestamp) BETWEEN '2017-05-15' and dateadd(day,119,'2017-05-15')  
		group by 1
	)
)
where cumsumplayers > 0.99
	--cumsumplayers > 0.90
	--cumsumplayers > 0.75
	--cumsumplayers > 0.65
	--cumsumplayers > 0.55
	--cumsumplayers > 0.45
	--cumsumplayers > 0.35
	--cumsumplayers > 0.25
	--cumsumplayers > 0.15
	--cumsumplayers > 0.05
group by 1
)

select  Count(date)::float/count(distinct a.platformaccountid) Avg_days_played_per_player,
		Sum(sessions_per_day)/count(distinct a.platformaccountid) Avg_sessions_per_player,
		Sum(Hours_per_day)/count(distinct a.platformaccountid) Avg_hours_per_player,
		sum(Hours_per_day)/sum(sessions_per_day) Session_length_per_player,
		Avg(sessions_per_day) sessions_per_player_per_day,Avg(Hours_per_day) hours_per_player_per_day,
		count(distinct b.platformaccountid)::float/count(distinct a.platformaccountid) Perc_DLC_Owners,
		count(distinct b.platformaccountid) DLC_owners,count(distinct a.platformaccountid) Total_players
from(
		select platformaccountid,DATE(starttimestamp) date,Count(distinct sid)::float sessions_per_day,
		sum(totaldurationminutes::float)/60 Hours_per_day
		from pachinko_prod_da.factactivity 
		where DATE(starttimestamp) BETWEEN '2017-05-15' and dateadd(day,119,'2017-05-15')
		and platformaccountid in (select * from players)
		group by 1,2) a
left join (
select  platformaccountid
from pachinko_prod_da.factdlc
where (productname not in ('Injustice 2 Game','Injustice 2 Game Pre-Order')) 
and dimdateid BETWEEN '20170515' and '20170911'
group by 1) b
on a.platformaccountid = b.platformaccountid ;

