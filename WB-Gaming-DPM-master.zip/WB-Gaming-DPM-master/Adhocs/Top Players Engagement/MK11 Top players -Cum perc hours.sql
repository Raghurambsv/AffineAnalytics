----1%
with players as (
select player_id 
from
(

	select a.event_dt dt,player_id, b.event_dt, next_dat,hrsplayed,cum , sum(cum) over(partition by a.event_dt) cum_daily_tot_mk11 , sum(cum) over(partition by dt order by cum asc rows between unbounded preceding and current row ) total, total::float/cum_daily_tot_mk11::float perc_fina
	from 
	(
	select event_dt
	from seven11_prod_da.wba_player_daily
	where event_dt between '2019-04-22' and dateadd(day,97,'2019-04-22')
	group by 1
	) a
	left join
	(
	select  player_id, event_dt, coalesce (lead(event_dt,1) over (partition by player_id order by event_dt),date(getdate ())) next_dat, sum(total_hours) hrsplayed, sum(hrsplayed) over (partition by player_id order by event_dt asc rows between unbounded preceding and current row) cum
	from seven11_prod_da.wba_player_daily
	where event_dt between '2019-04-22' and dateadd(day,97,'2019-04-22')
	group by 1,2

	) b
	on a.event_dt >= b.event_dt
	and a.event_dt < b.next_dat
)
where perc_fina > 0.99
	--perc_fina > 0.90
	--perc_fina > 0.75
group by 1
),

datedim as ( select event_dt YearMonthDay from seven11_prod_da.wba_fact_activity group by 1)

select period, RetentionDate, newdate, count(c.player_id) retained_players, count(b.player_id) cohorts
from
    (
        SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
        FROM datedim d
        JOIN datedim  d2 ON d.YearMonthDay < d2.YearMonthDay
        WHERE  (d.YearMonthDay between '2019-04-22' and dateadd(day,97,'2019-04-22'))
        AND (d2.YearMonthDay between '2019-04-22' and  dateadd(day,97,'2019-04-22'))
    ) A
join
	(
		select player_id, min(event_dt) yearmonthday
        from seven11_prod_da.wba_player_daily a
		join players b
		using(player_id)
		where event_dt between '2019-04-22' and dateadd(day,97,'2019-04-22')
        group by 1

    )  B
on a.NewDate = b.yearmonthday
left join
    (
      select event_dt yearmonthday, player_id
 	  from seven11_prod_da.wba_player_daily a
	  join players b
	  using(player_id)
	  where event_dt between '2019-04-22' and dateadd(day,97,'2019-04-22')
      group by 1,2
    ) C
on b.player_id = c.player_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-04-22'
group by 1,2,3
order by 3,2 desc ;

with players as (
select player_id 
from
(

	select a.event_dt dt,player_id, b.event_dt, next_dat,hrsplayed,cum , sum(cum) over(partition by a.event_dt) cum_daily_tot_mk11 , sum(cum) over(partition by dt order by cum asc rows between unbounded preceding and current row ) total, total::float/cum_daily_tot_mk11::float perc_fina
	from 
	(
	select event_dt
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22' 
	group by 1
	) a
	left join
	(
	select  player_id, event_dt, coalesce (lead(event_dt,1) over (partition by player_id order by event_dt),date(getdate ())) next_dat, sum(total_hours) hrsplayed, sum(hrsplayed) over (partition by player_id order by event_dt asc rows between unbounded preceding and current row) cum
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22' 
	group by 1,2

	) b
	on a.event_dt >= b.event_dt
	and a.event_dt < b.next_dat
)
where perc_fina > 0.99
	--perc_fina > 0.90
	--perc_fina > 0.75
group by 1
)

select  Avg(days_played) Avg_days_played_per_player,Avg(no_of_sessions) Avg_sessions_per_player,
		Avg(Hours) Avg_hours_per_player,sum(Hours)/sum(no_of_sessions) Session_length_per_player,
		Avg(sessions_per_day) sessions_per_player_per_day,Avg(Hours_per_day) hours_per_player_per_day,
		count(distinct c._platform_account_id)::float/count(distinct a.player_id) Perc_DLC_Owners,
		count(distinct c._platform_account_id),count(distinct a.player_id)
from(
		select player_id,sum(session_count)::float no_of_sessions,Sum(total_hours)::float Hours,
		count(distinct date(event_dt) )::float days_played
		from seven11_prod_da.wba_player_daily 
		where date(event_dt) BETWEEN '2019-04-22' and dateadd(day,97,'2019-04-22') 
		and player_id in (select * from players)
		group by 1) a
join (
		select player_id,date(event_dt),sum(session_count)::float sessions_per_day,Sum(total_hours)::float Hours_per_day
		from seven11_prod_da.wba_player_daily 
		where date(event_dt) BETWEEN '2019-04-22' and dateadd(day,97,'2019-04-22') 
		and player_id in (select * from players)
		group by 1,2) b
on a.player_id = b.player_id 
left join (
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) BETWEEN '2019-04-22' and dateadd(day,97,'2019-04-22')  
and entitlement_name is Not Null
and _platform_account_id in (select * from players)
group by 1) c
on a.player_id = c._platform_account_id ;


