
---- Top 1%

with players as (
select platformaccountid 
from
(
select platformaccountid, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select platformaccountid, sum(totaldurationminutes::float)/60  hrsplayed, sum(hrsplayed) over () totaltime,  hrsplayed/ sum(hrsplayed) over () perc, 1::float / count(platformaccountid) over ()  cum_players
		from pachinko_prod_da.factactivity 
		where DATE(starttimestamp) BETWEEN '2017-05-15' and dateadd(day,97,'2017-05-15')  
		group by 1
	)
)
where ceiling (cumsumplayers/.01)*.01 = 1
	--ceiling (cumsumplayers/.1)*.1 = 1
	--ceiling (cumsumplayers/.25)*.25 = 1
group by 1
),

datedim as ( select wbanalyticsprocessingdate YearMonthDay from pachinko_prod.pachinko_activitysession_begin group by 1)

select period, RetentionDate, newdate, count(c.platformaccountid) retained_players, count(b.platformaccountid) cohorts
from
    (
        SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
        FROM datedim d
        JOIN datedim  d2 ON d.YearMonthDay < d2.YearMonthDay
        WHERE  (d.YearMonthDay BETWEEN '2017-05-15' and dateadd(day,97,'2017-05-15') )
        AND (d2.YearMonthDay BETWEEN '2017-05-15' and dateadd(day,97,'2017-05-15') )
    ) A
join
	(
		select platformaccountid, min(DATE(starttimestamp)) yearmonthday
        from pachinko_prod_da.factactivity  a
		join players b
		using( platformaccountid)
		where DATE(starttimestamp) BETWEEN '2017-05-15' and dateadd(day,97,'2017-05-15')
        group by 1

    )  B
on a.NewDate = b.yearmonthday
left join
    (
      select DATE(starttimestamp) yearmonthday, platformaccountid
 	  from pachinko_prod_da.factactivity a
	  join players b
	  using(platformaccountid)
	  where DATE(starttimestamp) BETWEEN '2017-05-15' and dateadd(day,97,'2017-05-15')
      group by 1,2
    ) C
on b.platformaccountid = c.platformaccountid
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2017-05-15'
group by 1,2,3
order by 3,2 desc ;

with players as (
select platformaccountid 
from
(
select platformaccountid, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select platformaccountid, sum(totaldurationminutes::float)/60  hrsplayed, sum(hrsplayed) over () totaltime,  hrsplayed/ sum(hrsplayed) over () perc, 1::float / count(platformaccountid) over ()  cum_players
		from pachinko_prod_da.factactivity 
		where DATE(starttimestamp) BETWEEN '2017-05-15' and dateadd(day,97,'2017-05-15')  
		group by 1
	)
)
where ceiling (cumsumplayers/.01)*.01 = 1
	--ceiling (cumsumplayers/.1)*.1 = 1
	--ceiling (cumsumplayers/.25)*.25 = 1
group by 1
)

select  Avg(days_played) Avg_days_played_per_player,Avg(no_of_sessions) Avg_sessions_per_player,
		Avg(Hours) Avg_hours_per_player,sum(Hours)/sum(no_of_sessions) Session_length_per_player,
		Avg(sessions_per_day) sessions_per_player_per_day,Avg(Hours_per_day) hours_per_player_per_day,
		count(distinct c.platformaccountid)::float/count(distinct a.platformaccountid) Perc_DLC_Owners,
		count(distinct c.platformaccountid),count(distinct a.platformaccountid)
from(
		select platformaccountid,count(distinct DATE(starttimestamp) )::float days_played,
		sum(totaldurationminutes::float)/60 Hours,Count(distinct sid)::float no_of_sessions
		from pachinko_prod_da.factactivity 
		where DATE(starttimestamp) BETWEEN '2017-05-15' and dateadd(day,97,'2017-05-15')
		and platformaccountid in (select * from players)
		group by 1) a
join (
		select platformaccountid,DATE(starttimestamp),Count(distinct sid)::float sessions_per_day,
		sum(totaldurationminutes::float)/60 Hours_per_day
		from pachinko_prod_da.factactivity 
		where DATE(starttimestamp) BETWEEN '2017-05-15' and dateadd(day,97,'2017-05-15')
		and platformaccountid in (select * from players)
		group by 1,2) b
on a.platformaccountid = b.platformaccountid
left join (
select  platformaccountid
from pachinko_prod_da.factdlc
where (productname not in ('Injustice 2 Game','Injustice 2 Game Pre-Order')) 
and dimdateid BETWEEN '20170515' and '20170820' ) c
on a.platformaccountid = c.platformaccountid ;

