-----KP Owners (including premium ed)
select count(distinct _platform_account_id)
 from  seven11_prod.seven11_dlc_entitlement
 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
 and date(_event_time_utc) between '2019-04-22' and '2020-01-26'
 ;

-----Number of downloads for each character

With KP_Premium_owners as
(select _platform_account_id
 from  seven11_prod.seven11_dlc_entitlement
 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
 and date(_event_time_utc) between '2019-04-22' and '2020-01-26'
 group by 1)
 

select entitlement_name,count(distinct _platform_account_id) players
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('terminator','sindel','nightwolf','shang_tsung')
and _platform_account_id in (select * from KP_Premium_owners)
and date(_event_time_utc) between '2019-04-22' and '2020-01-26'
group by 1 ;

---Players downloading 1,2,3 & 4 charcters
With KP_Premium_owners as
(select _platform_account_id
 from  seven11_prod.seven11_dlc_entitlement
 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
 and date(_event_time_utc) between '2019-04-22' and '2020-01-26'
 group by 1)

Select Num,count(distinct _platform_account_id)
from(
Select _platform_account_id,count(entitlement_name) Num
from(
select entitlement_name,_platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('terminator','sindel','nightwolf','shang_tsung')
and _platform_account_id in (select * from KP_Premium_owners)
and date(_event_time_utc) between '2019-04-22' and '2020-01-26'
group by 1,2) 
group by 1)
group by 1;

------Purchase dates of players not downloading DLC ShangTsung

With KP_Premium_owners as
(select _platform_account_id,min(date(_event_time_utc)) purchase_dt
 from  seven11_prod.seven11_dlc_entitlement
 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
 and date(_event_time_utc) between '2019-04-22' and '2020-01-26'
 group by 1) ,
 
DLC_owners as (
select entitlement_name,_platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('shang_tsung')
and _platform_account_id in (select _platform_account_id from KP_Premium_owners)
and date(_event_time_utc) between '2019-04-22' and '2020-01-26'
group by 1,2 )

Select purchase_dt,COUNT(Distinct _platform_account_id)
from KP_Premium_owners
where _platform_account_id not in (Select _platform_account_id from DLC_owners)
group by 1 ;

------Purchase dates of players not downloading DLC --Nightwolf

With KP_Premium_owners as
(select _platform_account_id,min(date(_event_time_utc)) purchase_dt
 from  seven11_prod.seven11_dlc_entitlement
 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
 and date(_event_time_utc) between '2019-04-22' and '2020-01-26'
 group by 1) ,
 
DLC_owners as (
select entitlement_name,_platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('nightwolf')
and _platform_account_id in (select _platform_account_id from KP_Premium_owners)
and date(_event_time_utc) between '2019-04-22' and '2020-01-26'
group by 1,2 )

Select purchase_dt,COUNT(Distinct _platform_account_id)
from KP_Premium_owners
where _platform_account_id not in (Select _platform_account_id from DLC_owners)
group by 1 ;

------Purchase dates of players not downloading DLC Terminator

With KP_Premium_owners as
(select _platform_account_id,min(date(_event_time_utc)) purchase_dt
 from  seven11_prod.seven11_dlc_entitlement
 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
 and date(_event_time_utc) between '2019-04-22' and '2020-01-26'
 group by 1) ,
 
DLC_owners as (
select entitlement_name,_platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('terminator')
and _platform_account_id in (select _platform_account_id from KP_Premium_owners)
and date(_event_time_utc) between '2019-04-22' and '2020-01-26'
group by 1,2 )

Select purchase_dt,COUNT(Distinct _platform_account_id)
from KP_Premium_owners
where _platform_account_id not in (Select _platform_account_id from DLC_owners)
group by 1 ;

------Purchase dates of players not downloading DLC Sindel

With KP_Premium_owners as
(select _platform_account_id,min(date(_event_time_utc)) purchase_dt
 from  seven11_prod.seven11_dlc_entitlement
 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
 and date(_event_time_utc) between '2019-04-22' and '2020-01-26'
 group by 1) ,
 
DLC_owners as (
select entitlement_name,_platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('sindel')
and _platform_account_id in (select _platform_account_id from KP_Premium_owners)
and date(_event_time_utc) between '2019-04-22' and '2020-01-26'
group by 1,2 )

Select purchase_dt,COUNT(Distinct _platform_account_id)
from KP_Premium_owners
where _platform_account_id not in (Select _platform_account_id from DLC_owners)
group by 1 ;