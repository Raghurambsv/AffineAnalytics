---------Using Active hours----Activity begin table

with activity_begin as(
Select _platform_account_id,_event_time_utc,total_playthrough_time,
case when lag(total_playthrough_time) over(partition by _platform_account_id,playthrough_id order by _event_time_utc asc) is NULL then 0
else lag(total_playthrough_time) over(partition by _platform_account_id,playthrough_id order by _event_time_utc asc) end as Previous_total_playthrough_time,
total_playthrough_time-Previous_total_playthrough_time active_time
from  seven11_prod.seven11_activity_begin
where date(_event_time_utc) >='2019-04-22' 
)

Select * into sandbox.TimeKrystals_Economy_ActivityPeriod
from(
Select _platform_account_id,hours_played,
sum (Vc_earned_progress_hr) over (partition by _platform_account_id order by hours_played asc rows unbounded preceding) Vc_earned_progress,
sum (VC_earned_Events_hr) over (partition by _platform_account_id order by hours_played asc rows unbounded preceding) VC_earned_Events,
sum (VC_earned_both_hr) over (partition by _platform_account_id order by hours_played asc rows unbounded preceding) VC_earned_both,
sum (VC_purchased_hr) over (partition by _platform_account_id order by hours_played asc rows unbounded preceding) VC_purchased,
sum (VC_Spent_hr) over (partition by _platform_account_id order by hours_played asc rows unbounded preceding) VC_Spent
from(
Select _platform_account_id,hours_played,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED','TUTORIAL_REWARD') then change_amount end),0) as Vc_earned_progress_hr,
Coalesce(Sum(case when change_amount > 0 and source in ('community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE','EMAIL_COLLECTION_SUBSCRIPTION') then change_amount end),0) as VC_earned_Events_hr,
Coalesce(Sum(case when change_amount > 0 and source in ('KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned_both_hr,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased_hr,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent_hr
from(
Select a.*,trans_ts,change_amount,source
from(
Select _platform_account_id, _event_time_utc start_ts,
case when lag(_event_time_utc) over(partition by _platform_account_id order by _event_time_utc asc) is NULL then '2019-04-22 00:00:00' 
else lag(_event_time_utc) over(partition by _platform_account_id order by _event_time_utc asc) end as Previous_ts,
ceiling(sum(active_time)over(partition by _platform_account_id order by _event_time_utc asc rows unbounded preceding)/3600) Hours_Played
from  activity_begin
where date(_event_time_utc) >='2019-04-22' 
) a
join(
select  _platform_account_id, _event_time_utc trans_ts,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and date(_event_time_utc) >='2019-04-22' ) b
on a._platform_account_id = b._platform_account_id
and b.trans_ts between Previous_ts and start_ts )
group by 1,2))

 ;
----Hrs Played Level 

Select hours_played,Sum(vc_earned_progress) vc_earned_progress,Sum(vc_earned_events) vc_earned_events,
Sum(vc_earned_both) vc_earned_both, Sum(vc_purchased) vc_purchased, Sum(vc_spent) vc_spent
from sandbox.TimeKrystals_Economy_ActivityPeriod
group by 1
order by 1;