
Select * into sandbox.TimeKrystals_Economy
from(
Select _platform_account_id,hours_played,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED','TUTORIAL_REWARD') then change_amount end),0) as Vc_earned_progress,
Coalesce(Sum(case when change_amount > 0 and source in ('','community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE','EMAIL_COLLECTION_SUBSCRIPTION') then change_amount end),0) as VC_earned_Events,
Coalesce(Sum(case when change_amount > 0 and source in ('KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned_both,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent
from(
Select a.*,trans_ts,change_amount,source
from(
Select _platform_account_id, _event_time_utc start_ts,
case when lag(_event_time_utc) over(partition by _platform_account_id order by _event_time_utc asc) is NULL then '2019-04-22 00:00:00' 
else lag(_event_time_utc) over(partition by _platform_account_id order by _event_time_utc asc) end as Previous_ts,
activity_session_time_s,ceiling(sum(activity_session_time_s)over(partition by _platform_account_id order by _event_time_utc asc rows unbounded preceding)/3600) Hours_Played
from  seven11_prod.seven11_activity_end  ae join seven11_prod_da.wba_fact_activity fa on ae._activity_guid = fa.activity_guid and ae._platform_account_id=fa.player_id
where date(_event_time_utc) >='2019-04-22' 
and fa.activity_hours is not NULL
------and _platform_account_id= 2535417779400143
) a
join(
select  _platform_account_id, _event_time_utc trans_ts,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
-------and _platform_account_id= 2535417779400143
and date(_event_time_utc) >='2019-04-22' ) b
on a._platform_account_id = b._platform_account_id
and b.trans_ts between Previous_ts and start_ts )
group by 1,2)
 ;
 
 -----At hours played level

Select hours_played,
sum (Vc_earned_progress) over (order by hours_played asc rows unbounded preceding) Vc_earned_progress,
sum (VC_earned_Events) over (order by hours_played asc rows unbounded preceding) VC_earned_Events,
sum (VC_earned_both) over (order by hours_played asc rows unbounded preceding) VC_earned_both,
sum (VC_purchased) over (order by hours_played asc rows unbounded preceding) VC_purchased,
sum (VC_Spent) over (order by hours_played asc rows unbounded preceding) VC_Spent
from(
Select hours_played,Sum(vc_earned_progress) vc_earned_progress,Sum(vc_earned_events) vc_earned_events,
Sum(vc_earned_both) vc_earned_both, Sum(vc_purchased) vc_purchased, Sum(vc_spent) vc_spent
from sandbox.TimeKrystals_Economy
where hours_played <= 3600
group by 1
)
order by 1
