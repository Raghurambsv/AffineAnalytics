----no. of messages sent out to players/distinct palyers for the major source types
select date(_event_time_utc) message_date, source_type, count(distinct _platform_account_id) dplayers, count(_platform_account_id) players 
from seven11_prod.seven11_ui_decision
where source_type in ('billboard', 'kombatkard', 'large_popup', 'mobile_link_popup', 'trial') and date(_event_time_utc) >= '2019-04-22'
group by 1,2
order by 1,2

----no. of messages sent out to players/distinct palyers for the major source types by decision taken
select date(_event_time_utc) message_date, source_type,decision, count(distinct _platform_account_id) dplayers, count(_platform_account_id) players, count(distinct _session_id) sessions 
from seven11_prod.seven11_ui_decision
where source_type in ('billboard', 'kombatkard', 'large_popup', 'mobile_link_popup', 'trial') and date(_event_time_utc) >= '2019-04-22'
group by 1,2,3
order by 1,2,3

-----------Notifications grouped into the 3 types
with ui_decision as (select _event_time_utc, case 
	when source_type in ('billboard') then 'Banner' 
	when source_type in ('kombatkard') then 'InGame' 
	when source_type in ('large_popup') then 'Interstitial' end as source_type,
	_platform_account_id, _session_id, source_index
	from seven11_prod.seven11_ui_decision
	where date(_event_time_utc) >= '2019-04-22' and source_type in ('billboard', 'kombatkard', 'large_popup')
)
----------
select date(_event_time_utc) message_date, source_type, count(distinct _platform_account_id) dplayers_messages_sent, count(_platform_account_id) total_sent , count(distinct _session_id) sessions, count(distinct source_index) distinct_messages_Sent
from ui_decision
group by 1,2
order by 1,2

----no. of views by players/distinct palyers for the major source types
select date(_event_time_utc) view_date, category, count(distinct _platform_account_id) dplayers_viewed, count(_platform_account_id) total_views, count(distinct _session_id) sessions 
from seven11_prod.seven11_ui_view a
where category in ('billboard', 'kombatkard', 'large_popup', 'mobile_link_popup', 'trial') 
and date(_event_time_utc) >= '2019-04-22' and a.view not like ('5%')
group by 1,2
order by 1,2

-----------Notifications grouped into the 3 types
with ui_view as (select _event_time_utc, case 
	when category in ('billboard') then 'Banner' 
	when category in ('kombatkard') then 'InGame' 
	when category in ('large_popup') then 'Interstitial' end as category,
	_platform_account_id, _session_id, a.view
	from seven11_prod.seven11_ui_view a
	where date(_event_time_utc) >= '2019-04-22' and category in ('billboard', 'kombatkard', 'large_popup')
	and a.view not like ('5%') --and a.view is not ' '
)
----------
select date(_event_time_utc) view_date, category, count(distinct _platform_account_id) dplayers_viewed, count(_platform_account_id) total_views, count(distinct _session_id) sessions, count(distinct view) distinct_messages_viewed  
from ui_view
group by 1,2
order by 1,2

