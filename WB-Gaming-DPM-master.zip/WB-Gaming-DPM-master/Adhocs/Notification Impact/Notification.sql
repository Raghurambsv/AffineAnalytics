With Kp_owners as(
    select _platform_account_id,min(date(_event_time_utc)) as Pur_Date,cast ('kombat_pack' as varchar(256)) as Notif
           from seven11_prod.seven11_dlc_entitlement
           where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
           and date(wbanalyticssourcedate) >= '2019-04-22'
           and _platform_account_id not in (select _platform_account_id
                                                                  from  seven11_prod.seven11_dlc_entitlement
                                                                  where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
                                                                  and date(wbanalyticssourcedate) >= '2019-04-22'
                                                                  group by 1
                                                                  )
    group by 1
    ),
    
    shang_tsung_purchasers as(
    select _platform_account_id,min(date(_event_time_utc)) as Pur_Date,cast ('shang_tsung' as varchar(256)) as Notif
           from seven11_prod.seven11_dlc_entitlement
           where entitlement_name in ('shang_tsung','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
           and date(wbanalyticssourcedate) >= '2019-04-22'
           and _platform_account_id not in (select _platform_account_id
                                                                  from  seven11_prod.seven11_dlc_entitlement
                                                                  where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
                                                                  and date(wbanalyticssourcedate) >= '2019-04-22'
                                                                  group by 1
                                                                  )
    group by 1) ,
    
    nightwolf_purchasers as(
    select _platform_account_id,min(date(_event_time_utc)) as Pur_Date,cast ('nightwolf' as varchar(256)) as Notif
           from seven11_prod.seven11_dlc_entitlement
           where entitlement_name in ('nightwolf','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
           and date(wbanalyticssourcedate) >= '2019-04-22'
           and _platform_account_id not in (select _platform_account_id
                                                                  from  seven11_prod.seven11_dlc_entitlement
                                                                  where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
                                                                  and date(wbanalyticssourcedate) >= '2019-04-22'
                                                                  group by 1
                                                                  )
    group by 1)
    
, All_Unlocks as (
select * from Kp_owners
union
select * from shang_tsung_purchasers
union
select * from nightwolf_purchasers
)


Select source_index,Count(_platform_account_id) players,Sum(Old_P) Old_Purchasers, Sum(New_P) New_Purchasers
from(
select source_index, a._platform_account_id,Pur_Date,notif_dt, a.Notif ,
Case when Pur_Date< notif_dt then 1 end as Old_P,
Case when Pur_Date >= notif_dt then 1 end as New_P
from
(select _platform_account_id,source_index,case when source_index like 'nightwolf%' then 'nightwolf'
                                              when source_index like 'shang%' then 'shang_tsung'
                                              when source_index like 'kombat%' then 'kombat_pack' end as Notif
,min(date(_event_time_utc)) notif_dt
from seven11_prod.seven11_ui_decision
where source_index in ('kombat-pack-revealed-non-owners-popup',
'shang-tsung-early-access-popup',
'kombat-pack-revealed-full-lineup-non-owners-popup',
'nightwolf-available-now-popup',
'nightwolf-early-access-popup',
'shang-tsung-available-now-popup',
'kombat-pack-revealed-owners-popup',
'kombat-pack-revealed-full-lineup-owners-popup',
'kombat-pack-sale-popup',
'nightwolf-early-access-with-segmentation-popup',
'kombat-pack-trailer-notification',
'shang-tsung-movie-skin-notification',
'shang-tsung-early-access-player-notification',
'nightwolf-gameplay-non-owners-notification',
'nightwolf-gameplay-owners-notification'
)
group by 1,2,3
)a
left join
All_Unlocks b
on a._platform_account_id= b._platform_account_id and a.Notif=b.Notif)
group by 1
;

With Kp_owners as(
    select _platform_account_id,min(date(_event_time_utc)) as Pur_Date,cast ('kombat_pack' as varchar(256)) as Notif
           from seven11_prod.seven11_dlc_entitlement
           where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
           and date(wbanalyticssourcedate) >= '2019-04-22'
           and _platform_account_id not in (select _platform_account_id
                                                                  from  seven11_prod.seven11_dlc_entitlement
                                                                  where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
                                                                  and date(wbanalyticssourcedate) >= '2019-04-22'
                                                                  group by 1
                                                                  )
    group by 1
    ),
    
    shang_tsung_purchasers as(
    select _platform_account_id,min(date(_event_time_utc)) as Pur_Date,cast ('shang_tsung' as varchar(256)) as Notif
           from seven11_prod.seven11_dlc_entitlement
           where entitlement_name in ('shang_tsung','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
           and date(wbanalyticssourcedate) >= '2019-04-22'
           and _platform_account_id not in (select _platform_account_id
                                                                  from  seven11_prod.seven11_dlc_entitlement
                                                                  where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
                                                                  and date(wbanalyticssourcedate) >= '2019-04-22'
                                                                  group by 1
                                                                  )
    group by 1) ,
    
    nightwolf_purchasers as(
    select _platform_account_id,min(date(_event_time_utc)) as Pur_Date,cast ('nightwolf' as varchar(256)) as Notif
           from seven11_prod.seven11_dlc_entitlement
           where entitlement_name in ('nightwolf','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
           and date(wbanalyticssourcedate) >= '2019-04-22'
           and _platform_account_id not in (select _platform_account_id
                                                                  from  seven11_prod.seven11_dlc_entitlement
                                                                  where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
                                                                  and date(wbanalyticssourcedate) >= '2019-04-22'
                                                                  group by 1
                                                                  )
    group by 1)
    
, All_Unlocks as (
select * from Kp_owners
union
select * from shang_tsung_purchasers
union
select * from nightwolf_purchasers
)


Select source_index,Count(_platform_account_id) converted,Avg(delta_days)
from(
select source_index, a._platform_account_id,Pur_Date,notif_dt, a.Notif ,
 Pur_Date - notif_dt delta_days,Rank()over(partition by a._platform_account_id,a.Notif order by delta_days asc) Rank
from
(select _platform_account_id,source_index,case when source_index like 'nightwolf%' then 'nightwolf'
                                              when source_index like 'shang%' then 'shang_tsung'
                                              when source_index like 'kombat%' then 'kombat_pack' end as Notif
,min(date(_event_time_utc)) notif_dt
from seven11_prod.seven11_ui_decision
where source_index in ('kombat-pack-revealed-non-owners-popup',
'shang-tsung-early-access-popup',
'kombat-pack-revealed-full-lineup-non-owners-popup',
'nightwolf-available-now-popup',
'nightwolf-early-access-popup',
'shang-tsung-available-now-popup',
'kombat-pack-revealed-owners-popup',
'kombat-pack-revealed-full-lineup-owners-popup',
'kombat-pack-sale-popup',
'nightwolf-early-access-with-segmentation-popup',
'kombat-pack-trailer-notification',
'shang-tsung-movie-skin-notification',
'shang-tsung-early-access-player-notification',
'nightwolf-gameplay-non-owners-notification',
'nightwolf-gameplay-owners-notification'
)
group by 1,2,3
)a
left join
All_Unlocks b
on a._platform_account_id= b._platform_account_id and a.Notif=b.Notif
where Pur_Date - notif_dt >=0)
where Rank =1
group by 1
;