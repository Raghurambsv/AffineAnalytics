
----- Summon Tower Players
select tower_id, count(distinct _platform_account_id) 
from seven11_prod.seven11_match_result_player
where tower_id like ('%Key%')
and wbanalyticssourcedate::DATE>='2019-04-22'
and wbanalyticssourcedate::DATE<= '2020-12-28'
group by 1;

----- Summon Players Match Based Participation
Select tower_id, Match_cohort,count(_platform_account_id) Summon_players
from(
Select tower_id, _platform_account_id,count(distinct match_id ) as matches,
case when matches = 1 then '1 match'
when matches > 1 and matches <=10 then '2-10 matches'
when matches > 10 and matches <=20 then '11-20 matches'
when matches > 20 and matches <=30 then '21-30 matches'
else '30+ matches' end as Match_cohort
from seven11_prod.seven11_match_result_player a 
where wbanalyticssourcedate::DATE>='2019-04-22'
and wbanalyticssourcedate::DATE<= '2019-12-28'
and ai_difficulty= -1 and ai_player = 0
and tower_id like ('%Key%')
group by 1,2 
having matches >=1)
group by 1,2 ;


----- Summon Tower Completers
With ST_Completions AS (select
        wbanalyticssourcedate::DATE date,
        tower_id,
        _platform_account_id,
        sum(tower_completed) as completions
        from seven11_prod.seven11_gameplay_towerend 
        where tower_id like ('%Key%')
		and wbanalyticssourcedate::DATE >='2019-04-22'
        and wbanalyticssourcedate::DATE <='2019-12-28'
        group by 1,2,3
		having completions>=1
		)
		
Select tower_id, count(distinct _platform_account_id) Players_Completed
from ST_Completions 
GROUP BY 1;

-----Summon Towers Matches
select 	tower_id, count(distinct match_id) as matches
from seven11_prod.seven11_match_result_player
where ai_difficulty =-1 and ai_player in (0,1)
	and wbanalyticssourcedate::DATE>='2019-04-22'
	and wbanalyticssourcedate::DATE<='2019-12-28'
	and tower_id like ('%Key%')
group by 1;
		

------Tower Keys Spent-----
  select  resource,  count(distinct _platform_account_id) players, sum(change_amount) totalkeys
 from seven11_prod.seven11_resource_flow
 where resource in ('PortalScorpionKey','PortalSouls1Key','PortalSyedKey','PortalSouls2Key','PortalPremiumKey','PortalKollectorKey','PortalKoins2Key','PortalKoins1Key','PortalHearts1Key','PortalFireKey','PortalXP1Key','PortalForgeMatsKey')
 and change_amount <0
 and date(_event_time_utc) between '2019-04-22'  and '2019-12-28' 
 group by 1
 
 
------Tower Keys Obtained-----
 select resource,  count(distinct _platform_account_id) players, sum(change_amount) totalkeys
 from seven11_prod.seven11_resource_flow
 where resource in ('PortalScorpionKey','PortalSouls1Key','PortalSyedKey','PortalSouls2Key','PortalPremiumKey','PortalKollectorKey','PortalKoins2Key','PortalKoins1Key','PortalHearts1Key','PortalFireKey','PortalXP1Key','PortalForgeMatsKey')
 and change_amount > 0
 and date(_event_time_utc) between '2019-04-22'  and '2019-12-28' 
 group by 1
 
 
 -----Summon Towers Wins----
select tower_id, count(distinct match_id) as matches, sum(win) wins 
from
(
	select tower_id, match_id, max(player_win) win
	from seven11_prod.seven11_match_result_player
	where ai_difficulty =-1 and ai_player in (0,1)
		and wbanalyticssourcedate::DATE>='2019-04-22'
		and wbanalyticssourcedate::DATE<='2019-12-28'
		and tower_id like ('%Key%')
	group by 1,2
)
group by 1;


------ Players in ToT Including Tutorial Towers
select count(distinct _platform_account_id ) includingtutorial--players
from seven11_prod.seven11_match_result_player
where ai_difficulty =-1 and wbanalyticssourcedate::DATE>='2019-04-22'
	and wbanalyticssourcedate::DATE<='2019-12-28'
	and activity_name in ('GM_TOWERS_OF_TIME_LADDER')


------ Players in ToT Excluding Tutorial Towers
select count(distinct _platform_account_id ) excludingtutorial
from seven11_prod.seven11_match_result_player
where ai_difficulty =-1 and wbanalyticssourcedate::DATE>='2019-04-22'
	and wbanalyticssourcedate::DATE<='2019-12-28'
	and activity_name in ('GM_TOWERS_OF_TIME_LADDER') 
	and tower_id not like ('Tutorial%')
 
