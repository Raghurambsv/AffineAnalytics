-----Klassic Towers--Matches	
Select Match_cohort,count(_platform_account_id) Klassic_players
from(
Select _platform_account_id,count(distinct match_id ) as matches,
case when matches = 1 then '1 match'
when matches > 1 and matches <=10 then '2-10 matches'
when matches > 10 and matches <=20 then '11-20 matches'
when matches > 20 and matches <=30 then '21-30 matches'
else '30+ matches' end as Match_cohort
from seven11_prod.seven11_match_result_player
where ai_difficulty =-1 
and wbanalyticssourcedate::DATE>='2019-04-22'
and wbanalyticssourcedate::DATE<= '2019-12-16'
and tower_id in ('KlassicTowers_Warrior', 'KlassicTowers_Survivor', 'KlassicTowers_Novice', 'KlassicTowers_Endless', 'KlassicTowers_Champion')
and "_platform_name" != 'nsw'
group by 1
having matches >=1)
group by 1;

-----Towers of Time--Matches

Select Match_cohort,count(_platform_account_id) ToT_players
from(
Select _platform_account_id,count(distinct match_id ) as matches,
case when matches = 1 then '1 match'
when matches > 1 and matches <=10 then '2-10 matches'
when matches > 10 and matches <=20 then '11-20 matches'
when matches > 20 and matches <=30 then '21-30 matches'
else '30+ matches' end as Match_cohort
from seven11_prod.seven11_match_result_player a 
where ai_difficulty =-1 
and wbanalyticssourcedate::DATE>='2019-04-22'
and wbanalyticssourcedate::DATE<= '2019-12-16'
and activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER')
and "_platform_name" != 'nsw'
group by 1
having matches >=1)
group by 1;