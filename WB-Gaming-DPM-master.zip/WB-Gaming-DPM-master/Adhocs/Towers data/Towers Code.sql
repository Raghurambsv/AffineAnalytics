		
	-----DAU
select event_dt, count(distinct player_id)
from seven11_prod_da.wba_player_daily 
where event_dt >= '2019-04-22'
group by 1
order by 1;
	
	-----Klassic Towers --Player
		
		select 
		wbanalyticssourcedate::DATE date,tower_id,
		COALESCE(count(distinct _platform_account_id ), 0) as players,
		COALESCE(count(distinct match_id ), 0) as matches
		from seven11_prod.seven11_match_result_player
		where ai_difficulty =-1 and ai_player = 0
		and wbanalyticssourcedate::DATE>='2019-04-22'
		and wbanalyticssourcedate::DATE<= CAST(GETDATE() - 2  AS DATE)
		and tower_id in ('KlassicTowers_Warrior', 'KlassicTowers_Survivor', 'KlassicTowers_Novice', 'KlassicTowers_Endless', 'KlassicTowers_Champion')
		and "_platform_name" != 'nsw'
		group by 1,2
		order by 1,2 ;
	-----Klassic Towers --Ai		
		select 
		wbanalyticssourcedate::DATE date,tower_id,
		COALESCE(count(distinct _platform_account_id ), 0) as players,
		COALESCE(count(distinct match_id ), 0) as matches
		from seven11_prod.seven11_match_result_player
		where ai_difficulty =-1 and ai_player = 1
		and wbanalyticssourcedate::DATE>='2019-04-22'
		and wbanalyticssourcedate::DATE<= CAST(GETDATE() - 2  AS DATE)
		and tower_id in ('KlassicTowers_Warrior', 'KlassicTowers_Survivor', 'KlassicTowers_Novice', 'KlassicTowers_Endless', 'KlassicTowers_Champion')
		and "_platform_name" != 'nsw'
		group by 1,2
		order by 1,2 ;
		
-----Towers of Time--Player		

With tower_types as (select
    tower_id , tower_type
    from sandbox.Toweridmapping
    group by 1,2
)

		select 
		wbanalyticssourcedate::DATE date,
		case when b.tower_type is not NULL  then b.tower_type else 'Other' end as tower_type,
		COALESCE(count(distinct _platform_account_id ), 0) as players,
		COALESCE(count(distinct match_id ), 0) as matches
		from seven11_prod.seven11_match_result_player a left join tower_types b on a.tower_id =  b.tower_id
		where ai_difficulty =-1 and ai_player = 0
		and wbanalyticssourcedate::DATE>='2019-04-22'
		and wbanalyticssourcedate::DATE<= CAST(GETDATE() - 2  AS DATE)
		and activity_name in ('GM_TOWERS_OF_TIME_LADDER')
		and "_platform_name" != 'nsw'
		group by 1,2
		order by 1,2 ;
	-----Towers of Time--Ai		
	
With tower_types as (select
    tower_id , tower_type
    from sandbox.Toweridmapping
    group by 1,2
)

		select 
		wbanalyticssourcedate::DATE date,
		case when b.tower_type is not NULL  then b.tower_type else 'Other' end as tower_type,
		COALESCE(count(distinct _platform_account_id ), 0) as players,
		COALESCE(count(distinct match_id ), 0) as matches
		from seven11_prod.seven11_match_result_player a left join tower_types b on a.tower_id =  b.tower_id
		where ai_difficulty =-1 and ai_player = 1
		and wbanalyticssourcedate::DATE>='2019-04-22'
		and wbanalyticssourcedate::DATE<= CAST(GETDATE() - 2  AS DATE)
		and activity_name in ('GM_TOWERS_OF_TIME_LADDER')
		and "_platform_name" != 'nsw'
		group by 1,2
		order by 1,2 ;
		
-------Starting Konsumables---Overall Game modes
With resource_types as (
		select curr_type, currency_resource
		from seven11_prod_da.economy_inflow_outflow
		where currency_resource = 'konsumable' 
		group by 1,2
		) ,
		
Konsumable_balances as ( Select wbanalyticssourcedate::date as date,_platform_account_id,_session_id,
		COALESCE(sum(case when resource = 'Exp_Koins'  then change_amount end),0) as "Koins"	,
		COALESCE(sum(case when resource = 'Exp_SoulFragments'  then change_amount end),0)  as "Souls"	,
		COALESCE(sum(case when resource = 'Exp_BrutalityHearts'  then change_amount end),0)  as "Hearts"	,
		COALESCE(sum(case when resource = 'EasyFatality'  then change_amount end),0)  as "Fatalities"	,
		COALESCE(sum(case when currency_resource = 'konsumable' and 
					resource not in ('Exp_Koins','Exp_SoulFragments','Exp_BrutalityHearts','EasyFatality')
					then change_amount end),0)  as "Other_Konsumables"
from  seven11_prod.seven11_resource_flow rf
left Join resource_types rt on rf.resource =rt.curr_type
where wbanalyticssourcedate::DATE >='2019-04-22'
        and wbanalyticssourcedate::DATE<= CAST(GETDATE() - 2  AS DATE) 
GROUP BY 1,2,3) ,

match_result as(
select wbanalyticssourcedate::DATE date,_platform_account_id,_session_id,min(_event_time_utc) Start_ts
from seven11_prod.seven11_match_result_player
where ai_difficulty =-1 and wbanalyticssourcedate::DATE>='2019-04-22'
and wbanalyticssourcedate::DATE<= CAST(GETDATE() - 2  AS DATE) 
group by 1,2,3) 

Select date,Sum(Koins_balance) Total_Starting_Koins, Avg(Koins_balance) Avg_Starting_Koins,
Sum(Souls_balance) Total_Starting_Souls,Avg(Souls_balance) Avg_Starting_Souls,
Sum(Hearts_balance) Total_Starting_Hearts, Avg(Hearts_balance) Avg_Starting_Hearts,
Sum(Fatalities_balance) Total_Starting_Fatalities, Avg(Fatalities_balance) Avg_Starting_Fatalities,
Sum(Other_Konsumables_balance) Total_Starting_Other_Konsumables, Avg(Other_Konsumables_balance) Avg_Starting_Other_Konsumables
from(
Select date,_platform_account_id,Avg(Opening_Koins_balance) Koins_balance,Avg(Opening_Souls_balance) Souls_balance,
Avg(Opening_Hearts_balance) Hearts_balance, Avg(Opening_Fatalities_balance) Fatalities_balance,
Avg(Opening_Other_Konsumables_balance) Other_Konsumables_balance
from(
Select date,_platform_account_id,_session_id,Start_ts,
		COALESCE(LAG (Koins_balance,1) OVER (partition by _platform_account_id order by Start_ts),0) AS Opening_Koins_balance,
		COALESCE(LAG (Souls_balance,1) OVER (partition by _platform_account_id order by Start_ts),0) AS Opening_Souls_balance,
        COALESCE(LAG (Hearts_balance,1) OVER (partition by _platform_account_id order by Start_ts),0) AS Opening_Hearts_balance,
		COALESCE(LAG (Fatalities_balance,1) OVER (partition by _platform_account_id order by Start_ts),0) AS Opening_Fatalities_balance,
		COALESCE(LAG (Other_Konsumables_balance,1) OVER (partition by _platform_account_id order by Start_ts),0) AS Opening_Other_Konsumables_balance
from(
Select a.date,a._platform_account_id,a._session_id,Start_ts,
COALESCE(Koins,0) as Ses_Koins 	,
		COALESCE(Souls,0)  as Ses_Souls	,
		COALESCE(Hearts,0)  as Ses_Hearts	,
		COALESCE(Fatalities,0)  as Ses_Fatalities	,
		COALESCE(Other_Konsumables,0)  as Ses_Other_Konsumables,
		sum (Ses_Koins) over (partition by a._platform_account_id order by Start_ts asc rows unbounded preceding) Koins_balance,
		sum (Ses_Souls) over (partition by a._platform_account_id order by Start_ts asc rows unbounded preceding) Souls_balance,
		sum (Ses_Hearts) over (partition by a._platform_account_id order by Start_ts asc rows unbounded preceding) Hearts_balance,
		sum (Ses_Fatalities) over (partition by a._platform_account_id order by Start_ts asc rows unbounded preceding) Fatalities_balance,
		sum (Ses_Other_Konsumables) over (partition by a._platform_account_id order by Start_ts asc rows unbounded preceding) Other_Konsumables_balance		
from match_result a
left join Konsumable_balances b
On a.date= b.date
and	a._platform_account_id = b._platform_account_id
and	a._session_id = b._session_id))
group by 1,2)
group by 1
order by 1 ;

------Konsumables purchased

With resource_types as (
		select curr_type, currency_resource
		from seven11_prod_da.economy_inflow_outflow
		where currency_resource = 'konsumable' 
		group by 1,2
		)
		
Select wbanalyticssourcedate::date,
		COALESCE(sum(case when resource = 'Exp_Koins'  then change_amount end),0) as "Koins_Purchased"	,
		COALESCE(sum(case when resource = 'Exp_SoulFragments'  then change_amount end),0)  as "Souls_Purchased"	,
		COALESCE(sum(case when resource = 'Exp_BrutalityHearts'  then change_amount end),0)  as "Hearts_Purchased"	,
		COALESCE(sum(case when resource = 'EasyFatality'  then change_amount end),0)  as "Fatalities_Purchased"	,
		COALESCE(sum(case when currency_resource = 'konsumable' and 
					resource not in ('Exp_Koins','Exp_SoulFragments','Exp_BrutalityHearts','EasyFatality')
					then change_amount end),0)  as "Other_Konsumables_Purchased"
from  seven11_prod.seven11_resource_flow rf
left Join resource_types rt on rf.resource =rt.curr_type
where change_amount > 0 and Source in ('PREMIUM_SHOP') and wbanalyticssourcedate::DATE >='2019-04-22'
        and wbanalyticssourcedate::DATE<= CAST(GETDATE() - 2  AS DATE) 
GROUP BY 1
order by 1 asc
;


------New Tower Attempts
with tower_ends AS (select
        wbanalyticssourcedate::DATE date,
        tower_id,
        _platform_account_id, _event_time_utc
        from seven11_prod.seven11_gameplay_towerend t
        where wbanalyticssourcedate::DATE >='2019-04-22'
        and wbanalyticssourcedate::DATE <= CAST(GETDATE() - 2  AS DATE)
		and "_platform_name" != 'nsw'
        group by 1,2,3,4)
, tower_attempts as (SELECT 
		date, _platform_account_id
		tower_id,
		Rank()over(partition by _platform_account_id,Tower_id order by _event_time_utc asc) Attempt_number
		FROM tower_ends 
		)

Select date,count(tower_id) New_Attempts
from tower_attempts
where Attempt_number =1
group by 1
;

-------ToT Tower Success
With TOT_Completitions AS (select
        wbanalyticssourcedate::DATE date,
        tower_id,
        _platform_account_id,
        sum(tower_completed) as completions
        from seven11_prod.seven11_gameplay_towerend t
        where tower_id not in ('KlassicTowers_Warrior', 'KlassicTowers_Survivor', 'KlassicTowers_Novice', 'KlassicTowers_Endless', 'KlassicTowers_Champion')
        and wbanalyticssourcedate::DATE >='2019-04-22'
        and wbanalyticssourcedate::DATE <= CAST(GETDATE() - 2  AS DATE)
		and "_platform_name" != 'nsw'
        group by 1,2,3
		)
		
Select date, Sum(completions) TOT_Completions
from TOT_Completitions 
GROUP BY 1;

-------Klassic Towers Tower Success

With KT_Completitions AS (select
        wbanalyticssourcedate::DATE date,
        tower_id,
        _platform_account_id,
        sum(tower_completed) as completions
        from seven11_prod.seven11_gameplay_towerend t
        where tower_id in ('KlassicTowers_Warrior', 'KlassicTowers_Survivor', 'KlassicTowers_Novice', 'KlassicTowers_Endless', 'KlassicTowers_Champion')
        and wbanalyticssourcedate::DATE >='2019-04-22'
        and wbanalyticssourcedate::DATE <= CAST(GETDATE() - 2  AS DATE)
		and "_platform_name" != 'nsw'
        group by 1,2,3
		)
		
Select date, Sum(completions) KT_Completions
from KT_Completitions 
GROUP BY 1;


-----Konsumables Earned and Spent
With  tower_ends AS (select
        wbanalyticssourcedate::DATE date,
        tower_id,
        _activity_guid,
        _platform_account_id
        from seven11_prod.seven11_gameplay_towerend t
        where wbanalyticssourcedate::DATE >='2019-04-22'
       and wbanalyticssourcedate::DATE<= CAST(GETDATE() - 2  AS DATE)
		and "_platform_name" != 'nsw'
        group by 1,2,3,4)
, resource_types as (select 
		curr_type, currency_resource
		from seven11_prod_da.economy_inflow_outflow
		group by 1,2
		order by 2
)
, tower_resources as (  select 
		te.Tower_id, 
		Date(rf.wbanalyticssourcedate) date,
		rf."_activity_guid", 
		rf.change_amount,
		rf.resource,
		rt.currency_resource
		from seven11_prod.seven11_resource_flow rf
		left join tower_ends te on rf."_activity_guid" = te."_activity_guid"
		left join resource_types rt on rf.resource =rt.curr_type
		where   wbanalyticssourcedate::DATE >='2019-04-22'
        and wbanalyticssourcedate::DATE<= CAST(GETDATE() - 2  AS DATE)
        )
, tower_resources_earned as (  select 
		date,Tower_id, 
		COALESCE(sum(case when resource = 'Exp_Koins'  then change_amount end),0) as "Koins_Earned"	,
		COALESCE(sum(case when resource = 'Exp_SoulFragments'  then change_amount end),0)  as "Souls_Earned"	,
		COALESCE(sum(case when resource = 'Exp_BrutalityHearts'  then change_amount end),0)  as "Hearts_Earned"	,
		COALESCE(sum(case when resource = 'EasyFatality'  then change_amount end),0)  as "Fatalities_Earned"	,
		COALESCE(sum(case when currency_resource = 'konsumable' and 
					resource not in ('Exp_Koins','Exp_SoulFragments','Exp_BrutalityHearts','EasyFatality')
					then change_amount end),0)  as "Other_Konsumables_Earned"
		from tower_resources
		where change_amount > 0
		group by 1,2)
, tower_resources_spent as (  select 
		date,Tower_id, 
		COALESCE(sum(case when resource = 'Exp_Koins'  then change_amount end),0) as "Koins_Spent"	,
		COALESCE(sum(case when resource = 'Exp_SoulFragments'  then change_amount end),0)  as "Souls_Spent"	,
		COALESCE(sum(case when resource = 'Exp_BrutalityHearts'  then change_amount end),0)  as "Hearts_Spent"	,
		COALESCE(sum(case when resource = 'EasyFatality'  then change_amount end),0)  as "Fatalities_Spent"	,
		COALESCE(sum(case when currency_resource = 'konsumable' and 
					resource not in ('Exp_Koins','Exp_SoulFragments','Exp_BrutalityHearts','EasyFatality')
					then change_amount end),0)  as "Other_Konsumables_Spent"
		from tower_resources
		where change_amount < 0
		group by 1,2)		
Select m.Date,
	Sum(COALESCE(m.Koins_Earned,0)) Total_Koins_Earned,
	Sum(COALESCE(m.Souls_Earned,0)) Total_Souls_Earned,
	Sum(COALESCE(m.Hearts_Earned,0)) Total_Hearts_Earned,
	Sum(COALESCE(m.Fatalities_Earned,0)) Total_Fatalities_Earned,
	Sum(COALESCE(m.Other_Konsumables_Earned,0)) Total_Other_Konsumables_Earned,
	Sum(COALESCE(n.Koins_Spent,0)) Total_Koins_Spent,
	Sum(COALESCE(n.Souls_Spent,0)) Total_Souls_Spent,
	Sum(COALESCE(n.Hearts_Spent,0)) Total_Hearts_Spent,
	Sum(COALESCE(n.Fatalities_Spent,0)) Total_Fatalities__Spent,
	Sum(COALESCE(n.Other_Konsumables_Spent,0)) Total_Other_Konsumables__Spent
	from tower_resources_earned m 
	left join tower_resources_spent n on m.Tower_id = n.Tower_id and m.Date = n.Date
	where m.Tower_id is not NULL
	group by 1
	order by 1 asc
	 
;

