------NURR
----returning new
with newplayers as (
select  install_dt event_dt,player_id 
from seven11_prod_da.wba_player_daily
where event_dt >= '2020-04-01'  
and platform='PC-Steam'
group by  1,2
),
players as (
select  event_dt,player_id 
from seven11_prod_da.wba_player_daily
where event_dt >= '2020-04-01' 
and platform='PC-Steam'
group by  1,2
)

select  a.event_dt,count(distinct a.player_id ) returning_new
from(Select a.event_dt,b.player_id 
from players a
join players b
on  b.event_dt between dateadd(day,-6,a.event_dt) and a.event_dt
group by 1,2) a
join newplayers c
on c.event_dt between dateadd(day,-13,a.event_dt) and dateadd(day,-7,a.event_dt)
and a.player_id = c.player_id
group by 1
order by a.event_dt;


-----Totalnew
with newplayers as (
select  install_dt event_dt,player_id 
from seven11_prod_da.wba_player_daily
where event_dt >= '2020-04-01' 
and platform='PC-Steam'
group by  1,2
),
players as (
select  event_dt,player_id 
from seven11_prod_da.wba_player_daily
where event_dt >= '2020-04-01' 
and platform='PC-Steam'
group by  1,2
)

select a.event_dt,count(distinct b.player_id ) total_new
from players a
join newplayers b
on  b.event_dt between dateadd(day,-13,a.event_dt) and dateadd(day,-7,a.event_dt)
group by 1
order by 1;
----------CURR
-----Total_current

with players as (
select  event_dt,player_id 
from seven11_prod_da.wba_player_daily
where event_dt >= '2020-04-01' 
and platform='PC-Steam'
group by  1,2
)

Select a.event_dt, count(distinct a.player_id) Total_Current
from(
select a.event_dt, b.player_id 
from players a
join players b
on  b.event_dt between dateadd(day,-20,a.event_dt) and dateadd(day,-14,a.event_dt)
group by 1,2) a
join players c
on c.event_dt between dateadd(day,-13,a.event_dt) and dateadd(day,-7,a.event_dt)
and a.player_id = c.player_id
group by 1
order by a.event_dt ;

-----returning_current

with players as (
select  event_dt,player_id 
from seven11_prod_da.wba_player_daily
where event_dt >= '2020-04-01' 
and platform='PC-Steam'
group by  1,2
)

Select a.event_dt, count(distinct a.player_id) returning_Current
from (
Select a.event_dt,  a.player_id
from(
select a.event_dt, b.player_id 
from players a
join players b
on  b.event_dt between dateadd(day,-20,a.event_dt) and dateadd(day,-14,a.event_dt)
group by 1,2) a
join players c
on c.event_dt between dateadd(day,-13,a.event_dt) and dateadd(day,-7,a.event_dt)
and a.player_id = c.player_id
group by 1,2) a
join players c
on c.event_dt between dateadd(day,-6,a.event_dt) and a.event_dt
and a.player_id = c.player_id
group by 1
order by 1 desc
;
--------------RURR
-----Total_ret

with players as (
select  event_dt,player_id 
from seven11_prod_da.wba_player_daily
where event_dt >= '2020-04-01' 
and platform='PC-Steam'
group by  1,2
)

Select a.event_dt, count(distinct a.player_id) Total_ret
from(
select a.event_dt, b.player_id 
from players a
join players b
on  b.event_dt < dateadd(day,-13,a.event_dt)
group by 1,2) a
where a.player_id not in (select player_id from players c
where c.event_dt between dateadd(day,-13,a.event_dt) and dateadd(day,-7,a.event_dt) 
group by 1)
group by 1
;

-----returning_ret

with players as (
select  event_dt,player_id 
from seven11_prod_da.wba_player_daily
where event_dt >= '2020-04-01' 
and platform='PC-Steam'
group by  1,2
)

Select a.event_dt, count(distinct a.player_id) returning_ret
from(
Select a.event_dt,  a.player_id
from(
select a.event_dt, b.player_id 
from players a
join players b
on  b.event_dt < dateadd(day,-13,a.event_dt)
group by 1,2) a
where a.player_id not in (select player_id from players c
where c.event_dt between dateadd(day,-13,a.event_dt) and dateadd(day,-7,a.event_dt) 
group by 1)
group by 1,2) a
join players c
on c.event_dt between dateadd(day,-6,a.event_dt) and a.event_dt
and a.player_id = c.player_id
group by 1

;
