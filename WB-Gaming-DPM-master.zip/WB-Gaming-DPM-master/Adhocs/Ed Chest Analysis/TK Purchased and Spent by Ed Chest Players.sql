---Ed Chest Players

with ed_players as
(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
when date(_event_time_utc) in ('2019-08-23','2019-08-24') then 'Ed Chest 2'
when date(_event_time_utc) in ('2019-08-29','2019-08-30') then 'Ed Chest 3'
when date(_event_time_utc) in ('2019-09-03','2019-09-04') then 'Ed Chest 4'
when date(_event_time_utc) in ('2019-09-11','2019-09-12') then 'Ed Chest 5'
when date(_event_time_utc) in ('2019-09-19','2019-09-20') then 'Ed Chest 6'
when date(_event_time_utc) in ('2019-09-23','2019-09-24') then 'Ed Chest 7'
when date(_event_time_utc) in ('2019-10-01','2019-10-02') then 'Ed Chest 8'
when date(_event_time_utc) in ('2019-10-09','2019-10-10') then 'Ed Chest 9'
when date(_event_time_utc) in ('2019-10-17','2019-10-18') then 'Ed Chest 10'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14','2019-08-23','2019-08-24','2019-08-29','2019-08-30',
'2019-09-03','2019-09-04','2019-09-11','2019-09-12','2019-09-19','2019-09-20','2019-09-23','2019-09-24',
'2019-10-01','2019-10-02','2019-10-09','2019-10-10','2019-10-17','2019-10-18')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4','LIU_GearA5','LIU_Skin4_Palette1',
'KIT_GearA18','KIT_Skin4_Palette1','SHA_Skin2_Palette1','SHA_GearB15','NOO_Skin6_Palette7',
'NOO_GearA22','SCO_Skin6_Palette6','SCO_GearA28','SUB_Skin4_Palette1','SUB_GearA2',
'KUN_Skin5_Palette1','KUN_GearA7','RAI_Skin6_Palette1','RAI_GearA16','KAN_GearA25','KAN_Skin4_Palette1')
and unlock_source = 'KRYPT'
group by 1,2
) 

Select Ed_chest_no,Count(distinct _platform_account_id)
from ed_players 
group by 1;


---- Vc Purchased----
with ed_players as
(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
when date(_event_time_utc) in ('2019-08-23','2019-08-24') then 'Ed Chest 2'
when date(_event_time_utc) in ('2019-08-29','2019-08-30') then 'Ed Chest 3'
when date(_event_time_utc) in ('2019-09-03','2019-09-04') then 'Ed Chest 4'
when date(_event_time_utc) in ('2019-09-11','2019-09-12') then 'Ed Chest 5'
when date(_event_time_utc) in ('2019-09-19','2019-09-20') then 'Ed Chest 6'
when date(_event_time_utc) in ('2019-09-23','2019-09-24') then 'Ed Chest 7'
when date(_event_time_utc) in ('2019-10-01','2019-10-02') then 'Ed Chest 8'
when date(_event_time_utc) in ('2019-10-09','2019-10-10') then 'Ed Chest 9'
when date(_event_time_utc) in ('2019-10-17','2019-10-18') then 'Ed Chest 10'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14','2019-08-23','2019-08-24','2019-08-29','2019-08-30',
'2019-09-03','2019-09-04','2019-09-11','2019-09-12','2019-09-19','2019-09-20','2019-09-23','2019-09-24',
'2019-10-01','2019-10-02','2019-10-09','2019-10-10','2019-10-17','2019-10-18')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4','LIU_GearA5','LIU_Skin4_Palette1',
'KIT_GearA18','KIT_Skin4_Palette1','SHA_Skin2_Palette1','SHA_GearB15','NOO_Skin6_Palette7',
'NOO_GearA22','SCO_Skin6_Palette6','SCO_GearA28','SUB_Skin4_Palette1','SUB_GearA2',
'KUN_Skin5_Palette1','KUN_GearA7','RAI_Skin6_Palette1','RAI_GearA16','KAN_GearA25','KAN_Skin4_Palette1')
and unlock_source = 'KRYPT'
group by 1,2
) ,
players as (
select player_id
from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES
where premiumcurrency >= 50000
group by 1
) 


Select Ed_chest_no,count(distinct _platform_account_id) TK_Purchasers,Sum(VC) TK_Purchased
from(
select Ed_chest_no,a._platform_account_id, sum(change_amount) VC
from seven11_prod.seven11_resource_flow a
join ed_players b
on a._platform_account_id = b._platform_account_id
where resource = 'Exp_PremiumCurrency' and a._platform_account_id not in (select * from players) 
and date(_event_time_utc) >='2019-04-22' and change_amount > 0 and source = 'ENTITLEMENT'
and _event_time_utc between chest_open_ts and dateadd(hour,48,chest_open_ts)
group by 1,2) 
group by 1
order by 1 ;

------VC Spenders

with ed_players as
(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
when date(_event_time_utc) in ('2019-08-23','2019-08-24') then 'Ed Chest 2'
when date(_event_time_utc) in ('2019-08-29','2019-08-30') then 'Ed Chest 3'
when date(_event_time_utc) in ('2019-09-03','2019-09-04') then 'Ed Chest 4'
when date(_event_time_utc) in ('2019-09-11','2019-09-12') then 'Ed Chest 5'
when date(_event_time_utc) in ('2019-09-19','2019-09-20') then 'Ed Chest 6'
when date(_event_time_utc) in ('2019-09-23','2019-09-24') then 'Ed Chest 7'
when date(_event_time_utc) in ('2019-10-01','2019-10-02') then 'Ed Chest 8'
when date(_event_time_utc) in ('2019-10-09','2019-10-10') then 'Ed Chest 9'
when date(_event_time_utc) in ('2019-10-17','2019-10-18') then 'Ed Chest 10'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14','2019-08-23','2019-08-24','2019-08-29','2019-08-30',
'2019-09-03','2019-09-04','2019-09-11','2019-09-12','2019-09-19','2019-09-20','2019-09-23','2019-09-24',
'2019-10-01','2019-10-02','2019-10-09','2019-10-10','2019-10-17','2019-10-18')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4','LIU_GearA5','LIU_Skin4_Palette1',
'KIT_GearA18','KIT_Skin4_Palette1','SHA_Skin2_Palette1','SHA_GearB15','NOO_Skin6_Palette7',
'NOO_GearA22','SCO_Skin6_Palette6','SCO_GearA28','SUB_Skin4_Palette1','SUB_GearA2',
'KUN_Skin5_Palette1','KUN_GearA7','RAI_Skin6_Palette1','RAI_GearA16','KAN_GearA25','KAN_Skin4_Palette1')
and unlock_source = 'KRYPT'
group by 1,2
) ,
players as (
select player_id
from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES
where premiumcurrency >= 50000
group by 1
) 


Select Ed_chest_no,count(distinct _platform_account_id) Spenders,Sum(VC) TK_Spent
from(
select Ed_chest_no,a._platform_account_id, sum(change_amount)*(-1) VC
from seven11_prod.seven11_resource_flow a
join ed_players b
on a._platform_account_id = b._platform_account_id
where resource = 'Exp_PremiumCurrency' and a._platform_account_id not in (select * from players) 
and date(_event_time_utc) >='2019-04-22' and change_amount < 0 and source = 'PREMIUM_SHOP'
and _event_time_utc between chest_open_ts and dateadd(hour,48,chest_open_ts)
group by 1,2) 
group by 1
order by 1 ;
