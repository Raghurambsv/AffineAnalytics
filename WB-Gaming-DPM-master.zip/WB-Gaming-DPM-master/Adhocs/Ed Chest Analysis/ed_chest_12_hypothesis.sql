with ed_players_six as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-09-19','2019-09-20') then 'Ed Chest 6'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-09-19','2019-09-20')
and unlock_name in ('SCO_Skin6_Palette6','SCO_GearA28')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_six_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-11-09','2019-11-10') then 'Ed Chest 12'
end as Ed_chest_no, min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  >= '2019-11-09' and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_six)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no,chest_open_ts
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-11-09','2019-11-10') then 'Ed Chest 12'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-11-09','2019-11-10')
and unlock_name in ('SCO_Skin6_Palette6','SCO_GearA28')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
Select *
from Ed_Players_six_Conv
group by 1,2,3),

equipped as (select _platform_account_id,gear_1,gear_2
from seven11_prod.seven11_gameplay_customization 
where gear_1 Like '%SCO_GearA28_%' or
gear_2 Like '%SCO_GearA28_%'
group by 1,2,3),

ed_players_equipped as ( 
select (a._platform_account_id) player_id
from ed_players a
join equipped b
on a._platform_account_id = b._platform_account_id
group by 1
),

ed_players_not_equipped as (
select(_platform_account_id) player_id
from ed_players
where _platform_account_id not in (select player_id from ed_players_equipped)
group by 1
)

--select count(distinct match_id)::float Total_matches
--from seven11_prod.seven11_match_result_player a
--where a._platform_account_id in (select distinct player_id from ed_players_equipped)
--and a._event_time_utc <'2019-11-09 00:00:00'

Select Sco_matches/Total_matches Before9th_equipped
from
(select count(distinct match_id)::float Total_matches  
from seven11_prod.seven11_match_result_player a
where a._platform_account_id in (select distinct player_id from ed_players_equipped)
and date(a._event_time_utc) between '2019-04-22' and '2019-11-08'
)
cross join
(
select count(distinct match_id) Sco_matches
from seven11_prod.seven11_match_result_player a
where a._platform_account_id in (select distinct player_id from ed_players_equipped)
and "character" ='char_scorpion' 
and date(a._event_time_utc) between '2019-04-22' and '2019-11-08'
);
-----------------------------------------------------------------------------------------

with ed_players_six as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-09-19','2019-09-20') then 'Ed Chest 6'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-09-19','2019-09-20')
and unlock_name in ('SCO_Skin6_Palette6','SCO_GearA28')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_six_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-11-09','2019-11-10') then 'Ed Chest 12'
end as Ed_chest_no, min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  >= '2019-11-09' and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_six)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no,chest_open_ts
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-11-09','2019-11-10') then 'Ed Chest 12'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-11-09','2019-11-10')
and unlock_name in ('SCO_Skin6_Palette6','SCO_GearA28')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
Select *
from Ed_Players_six_Conv
group by 1,2,3),

equipped as (select _platform_account_id,gear_1,gear_2
from seven11_prod.seven11_gameplay_customization 
where gear_1 Like '%SCO_GearA28_%' or
gear_2 Like '%SCO_GearA28_%'
group by 1,2,3),

ed_players_equipped as ( 
select (a._platform_account_id) player_id
from ed_players a
join equipped b
on a._platform_account_id = b._platform_account_id
group by 1
),

ed_players_not_equipped as (
select(_platform_account_id) player_id
from ed_players
where _platform_account_id not in (select player_id from ed_players_equipped)
group by 1
)

Select Sco_matches/Total_matches After9th_equipped 
from
(select count(distinct match_id)::float Total_matches
from seven11_prod.seven11_match_result_player a
where a._platform_account_id in (select distinct player_id from ed_players_equipped)
and date(a._event_time_utc) >= '2019-11-09'
)
cross join
(
select count(distinct match_id) Sco_matches
from seven11_prod.seven11_match_result_player a
where a._platform_account_id in (select distinct player_id from ed_players_equipped)
and "character" ='char_scorpion' 
and date(a._event_time_utc) >= '2019-11-09'
);

----------------------------------------------------------------------------------

with ed_players_six as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-09-19','2019-09-20') then 'Ed Chest 6'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-09-19','2019-09-20')
and unlock_name in ('SCO_Skin6_Palette6','SCO_GearA28')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_six_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-11-09','2019-11-10') then 'Ed Chest 12'
end as Ed_chest_no, min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  >= '2019-11-09' and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_six)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no,chest_open_ts
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-11-09','2019-11-10') then 'Ed Chest 12'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-11-09','2019-11-10')
and unlock_name in ('SCO_Skin6_Palette6','SCO_GearA28')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
Select *
from Ed_Players_six_Conv
group by 1,2,3),

equipped as (select _platform_account_id,gear_1,gear_2
from seven11_prod.seven11_gameplay_customization 
where gear_1 Like '%SCO_GearA28_%' or
gear_2 Like '%SCO_GearA28_%'
group by 1,2,3),

ed_players_equipped as ( 
select (a._platform_account_id) player_id
from ed_players a
join equipped b
on a._platform_account_id = b._platform_account_id
group by 1
),

ed_players_not_equipped as (
select(_platform_account_id) player_id
from ed_players
where _platform_account_id not in (select player_id from ed_players_equipped)
group by 1
)


Select Sco_matches/Total_matches Before9th_not_equipped
from
(select count(distinct match_id)::float Total_matches
from seven11_prod.seven11_match_result_player a
where a._platform_account_id in (select distinct player_id from ed_players_not_equipped)
and date(a._event_time_utc) between '2019-04-22' and '2019-11-08'
)
cross join
(
select count(distinct match_id) Sco_matches
from seven11_prod.seven11_match_result_player a
where a._platform_account_id in (select distinct player_id from ed_players_not_equipped)
and "character" ='char_scorpion' 
and date(a._event_time_utc) between '2019-04-22' and '2019-11-08'
);

------------------------------------------------------------------------------

with ed_players_six as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-09-19','2019-09-20') then 'Ed Chest 6'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-09-19','2019-09-20')
and unlock_name in ('SCO_Skin6_Palette6','SCO_GearA28')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_six_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-11-09','2019-11-10') then 'Ed Chest 12'
end as Ed_chest_no, min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  >= '2019-11-09' and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_six)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no,chest_open_ts
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-11-09','2019-11-10') then 'Ed Chest 12'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-11-09','2019-11-10')
and unlock_name in ('SCO_Skin6_Palette6','SCO_GearA28')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
Select *
from Ed_Players_six_Conv
group by 1,2,3),

equipped as (select _platform_account_id,gear_1,gear_2
from seven11_prod.seven11_gameplay_customization 
where gear_1 Like '%SCO_GearA28_%' or
gear_2 Like '%SCO_GearA28_%'
group by 1,2,3),

ed_players_equipped as ( 
select (a._platform_account_id) player_id
from ed_players a
join equipped b
on a._platform_account_id = b._platform_account_id
group by 1
),

ed_players_not_equipped as (
select(_platform_account_id) player_id
from ed_players
where _platform_account_id not in (select player_id from ed_players_equipped)
group by 1
)


Select Sco_matches/Total_matches After9th_not_equipped
from
(select count(distinct match_id)::float Total_matches
from seven11_prod.seven11_match_result_player a
where a._platform_account_id in (select distinct player_id from ed_players_not_equipped)
and date(a._event_time_utc) >= '2019-11-09'
)
cross join
(
select count(distinct match_id) Sco_matches
from seven11_prod.seven11_match_result_player a
where a._platform_account_id in (select distinct player_id from ed_players_not_equipped)
and "character" ='char_scorpion' 
and date(a._event_time_utc) >= '2019-11-09'
);




--select count(distinct player_id) from ed_players_not_equipped 

--select count(distinct player_id) from ed_players_equipped  
--
--select count(distinct _platform_account_id) from ed_players
--
--
--Select Ed_chest_no,Count(distinct a._platform_account_id) Gears_equipped
--from ed_players a
--join equipped b
--on a._platform_account_id = b._platform_account_id
--group by 1 
--order by 1;