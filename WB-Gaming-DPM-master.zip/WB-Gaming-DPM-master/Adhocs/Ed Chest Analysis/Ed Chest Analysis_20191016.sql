------Players, Spenders, New_players

with ed_players as
(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
when date(_event_time_utc) in ('2019-08-23','2019-08-24') then 'Ed Chest 2'
when date(_event_time_utc) in ('2019-08-29','2019-08-30') then 'Ed Chest 3'
when date(_event_time_utc) in ('2019-09-03','2019-09-04') then 'Ed Chest 4'
when date(_event_time_utc) in ('2019-09-11','2019-09-12') then 'Ed Chest 5'
when date(_event_time_utc) in ('2019-09-19','2019-09-20') then 'Ed Chest 6'
when date(_event_time_utc) in ('2019-09-23','2019-09-24') then 'Ed Chest 7'
when date(_event_time_utc) in ('2019-10-01','2019-10-02') then 'Ed Chest 8'
when date(_event_time_utc) in ('2019-10-09','2019-10-10') then 'Ed Chest 9'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14','2019-08-23','2019-08-24','2019-08-29','2019-08-30',
'2019-09-03','2019-09-04','2019-09-11','2019-09-12','2019-09-19','2019-09-20','2019-09-23','2019-09-24',
'2019-10-01','2019-10-02','2019-10-09','2019-10-10')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4','LIU_GearA5','LIU_Skin4_Palette1',
'KIT_GearA18','KIT_Skin4_Palette1','SHA_Skin2_Palette1','SHA_GearB15','NOO_Skin6_Palette7',
'NOO_GearA22','SCO_Skin6_Palette6','SCO_GearA28','SUB_Skin4_Palette1','SUB_GearA2',
'KUN_Skin5_Palette1','KUN_GearA7','RAI_Skin6_Palette1','RAI_GearA16')
and unlock_source = 'KRYPT'
group by 1,2
) ,

players as (
select player_id
from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES
where premiumcurrency >= 50000
group by 1
) ,

Spenders as (
select _platform_account_id,min(_event_time_utc) Spend_ts
from seven11_prod.seven11_progression_unlock
where unlock_source = 'PREMIUM_SHOP' and date(_event_time_utc) >= '2019-04-22' 
and _platform_account_id not in (select player_id from players)
group by 1)


Select Ed_chest_no,count(_platform_account_id) players,Sum(Old_S) Old_Spenders, Sum(New_S) New_Spenders
from(
Select Ed_chest_no,chest_open_ts,a._platform_account_id,Spend_ts,
case when Spend_ts < chest_open_ts then 1 else 0 end as Old_S,
case when Spend_ts > chest_open_ts then 1 else 0 end as New_S
from Ed_players a
left join Spenders b
on a._platform_account_id = b._platform_account_id)
group by 1
order by 1 ;

-----New Spenders

with ed_players as
(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
when date(_event_time_utc) in ('2019-08-23','2019-08-24') then 'Ed Chest 2'
when date(_event_time_utc) in ('2019-08-29','2019-08-30') then 'Ed Chest 3'
when date(_event_time_utc) in ('2019-09-03','2019-09-04') then 'Ed Chest 4'
when date(_event_time_utc) in ('2019-09-11','2019-09-12') then 'Ed Chest 5'
when date(_event_time_utc) in ('2019-09-19','2019-09-20') then 'Ed Chest 6'
when date(_event_time_utc) in ('2019-09-23','2019-09-24') then 'Ed Chest 7'
when date(_event_time_utc) in ('2019-10-01','2019-10-02') then 'Ed Chest 8'
when date(_event_time_utc) in ('2019-10-09','2019-10-10') then 'Ed Chest 9'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14','2019-08-23','2019-08-24','2019-08-29','2019-08-30',
'2019-09-03','2019-09-04','2019-09-11','2019-09-12','2019-09-19','2019-09-20','2019-09-23','2019-09-24',
'2019-10-01','2019-10-02','2019-10-09','2019-10-10')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4','LIU_GearA5','LIU_Skin4_Palette1',
'KIT_GearA18','KIT_Skin4_Palette1','SHA_Skin2_Palette1','SHA_GearB15','NOO_Skin6_Palette7',
'NOO_GearA22','SCO_Skin6_Palette6','SCO_GearA28','SUB_Skin4_Palette1','SUB_GearA2',
'KUN_Skin5_Palette1','KUN_GearA7','RAI_Skin6_Palette1','RAI_GearA16')
and unlock_source = 'KRYPT'
group by 1,2
) ,
players as (
select player_id
from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES
where premiumcurrency >= 50000
group by 1
) ,
Spenders as (
select _platform_account_id,min(_event_time_utc) Spend_ts
from seven11_prod.seven11_progression_unlock
where unlock_source = 'PREMIUM_SHOP' and date(_event_time_utc) >= '2019-04-22'
and _platform_account_id not in (select player_id from players)
group by 1)

Select Ed_chest_no, count(distinct _platform_account_id) Converted
from
(
	Select Ed_chest_no,chest_open_ts,a._platform_account_id,Spend_ts,
		Spend_ts - chest_open_ts delta_time,
		Rank()over(partition by a._platform_account_id order by delta_time asc) Rank
	from Ed_players a
	left join Spenders b
	on a._platform_account_id = b._platform_account_id
	where (Spend_ts - chest_open_ts) > 0 
)
where Rank = 1
group by 1
order by 1 ;

-----Total Spenders

with ed_players as
(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
when date(_event_time_utc) in ('2019-08-23','2019-08-24') then 'Ed Chest 2'
when date(_event_time_utc) in ('2019-08-29','2019-08-30') then 'Ed Chest 3'
when date(_event_time_utc) in ('2019-09-03','2019-09-04') then 'Ed Chest 4'
when date(_event_time_utc) in ('2019-09-11','2019-09-12') then 'Ed Chest 5'
when date(_event_time_utc) in ('2019-09-19','2019-09-20') then 'Ed Chest 6'
when date(_event_time_utc) in ('2019-09-23','2019-09-24') then 'Ed Chest 7'
when date(_event_time_utc) in ('2019-10-01','2019-10-02') then 'Ed Chest 8'
when date(_event_time_utc) in ('2019-10-09','2019-10-10') then 'Ed Chest 9'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14','2019-08-23','2019-08-24','2019-08-29','2019-08-30',
'2019-09-03','2019-09-04','2019-09-11','2019-09-12','2019-09-19','2019-09-20','2019-09-23','2019-09-24',
'2019-10-01','2019-10-02','2019-10-09','2019-10-10')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4','LIU_GearA5','LIU_Skin4_Palette1',
'KIT_GearA18','KIT_Skin4_Palette1','SHA_Skin2_Palette1','SHA_GearB15','NOO_Skin6_Palette7',
'NOO_GearA22','SCO_Skin6_Palette6','SCO_GearA28','SUB_Skin4_Palette1','SUB_GearA2',
'KUN_Skin5_Palette1','KUN_GearA7','RAI_Skin6_Palette1','RAI_GearA16')
and unlock_source = 'KRYPT'
group by 1,2
) ,
players as (
select player_id
from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES
where premiumcurrency >= 50000
group by 1
) ,
Spenders as (
select _platform_account_id,_event_time_utc Spend_ts
from seven11_prod.seven11_progression_unlock
where unlock_source = 'PREMIUM_SHOP' and date(_event_time_utc) >= '2019-04-22'
and _platform_account_id not in (select player_id from players)
)


Select Ed_chest_no, count(distinct _platform_account_id) Converted
from
(
	Select Ed_chest_no, chest_open_ts, a._platform_account_id,Spend_ts, case when 
	Lead(chest_open_ts, 1) OVER (partition by a._platform_account_id ORDER BY chest_open_ts) is null then '2030-04-22' else Lead(chest_open_ts, 1) OVER (partition by a._platform_account_id ORDER BY chest_open_ts) end AS Next_chest_open  
	from Ed_players a
	left join Spenders b
	on a._platform_account_id = b._platform_account_id    
	where (Spend_ts - chest_open_ts) > 0 
)
--where Rank = 1
where Spend_ts between chest_open_ts and Next_chest_open
group by 1
order by 1 ;


----- Time Krystal balances

with ed_players as
(
select _platform_account_id,Ed_chest_no, date
from
(
select date(_event_time_utc) date,_platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
when date(_event_time_utc) in ('2019-08-23','2019-08-24') then 'Ed Chest 2'
when date(_event_time_utc) in ('2019-08-29','2019-08-30') then 'Ed Chest 3'
when date(_event_time_utc) in ('2019-09-03','2019-09-04') then 'Ed Chest 4'
when date(_event_time_utc) in ('2019-09-11','2019-09-12') then 'Ed Chest 5'
when date(_event_time_utc) in ('2019-09-19','2019-09-20') then 'Ed Chest 6'
when date(_event_time_utc) in ('2019-09-23','2019-09-24') then 'Ed Chest 7'
when date(_event_time_utc) in ('2019-10-01','2019-10-02') then 'Ed Chest 8'
when date(_event_time_utc) in ('2019-10-09','2019-10-10') then 'Ed Chest 9'
end as Ed_chest_no
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14','2019-08-23','2019-08-24','2019-08-29','2019-08-30',
'2019-09-03','2019-09-04','2019-09-11','2019-09-12','2019-09-19','2019-09-20','2019-09-23','2019-09-24',
'2019-10-01','2019-10-02','2019-10-09','2019-10-10')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4','LIU_GearA5','LIU_Skin4_Palette1',
'KIT_GearA18','KIT_Skin4_Palette1','SHA_Skin2_Palette1','SHA_GearB15','NOO_Skin6_Palette7',
'NOO_GearA22','SCO_Skin6_Palette6','SCO_GearA28','SUB_Skin4_Palette1','SUB_GearA2',
'KUN_Skin5_Palette1','KUN_GearA7','RAI_Skin6_Palette1','RAI_GearA16')
and unlock_source = 'KRYPT'
group by 1,2,3
)
group by 1,2,3
)

select Ed_chest_no,count(player_id),Sum(premiumcurrency),Avg(premiumcurrency), min(premiumcurrency), max(premiumcurrency),median(premiumcurrency)
from
(
	select a.player_id,Ed_chest_no, a.play_date, cast(a.premiumcurrency as float) premiumcurrency
	from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES a
	join ed_players b
	on a.player_id = b._platform_account_id and date(a.play_date)= b.date
	where premiumcurrency<50000
)
group by 1
order by 1 ;

---select *
---from seven11_prod.seven11_gameplay_customization 
----limit 100


----Gears Equipped---------

with ed_players as
(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
when date(_event_time_utc) in ('2019-08-23','2019-08-24') then 'Ed Chest 2'
when date(_event_time_utc) in ('2019-08-29','2019-08-30') then 'Ed Chest 3'
when date(_event_time_utc) in ('2019-09-03','2019-09-04') then 'Ed Chest 4'
when date(_event_time_utc) in ('2019-09-11','2019-09-12') then 'Ed Chest 5'
when date(_event_time_utc) in ('2019-09-19','2019-09-20') then 'Ed Chest 6'
when date(_event_time_utc) in ('2019-09-23','2019-09-24') then 'Ed Chest 7'
when date(_event_time_utc) in ('2019-10-01','2019-10-02') then 'Ed Chest 8'
when date(_event_time_utc) in ('2019-10-09','2019-10-10') then 'Ed Chest 9'
end as Ed_chest_no
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14','2019-08-23','2019-08-24','2019-08-29','2019-08-30',
'2019-09-03','2019-09-04','2019-09-11','2019-09-12','2019-09-19','2019-09-20','2019-09-23','2019-09-24',
'2019-10-01','2019-10-02','2019-10-09','2019-10-10')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4','LIU_GearA5','LIU_Skin4_Palette1',
'KIT_GearA18','KIT_Skin4_Palette1','SHA_Skin2_Palette1','SHA_GearB15','NOO_Skin6_Palette7',
'NOO_GearA22','SCO_Skin6_Palette6','SCO_GearA28','SUB_Skin4_Palette1','SUB_GearA2',
'KUN_Skin5_Palette1','KUN_GearA7','RAI_Skin6_Palette1','RAI_GearA16')
and unlock_source = 'KRYPT'
group by 1,2
),

equipped as (select _platform_account_id,gear_1,gear_2
from seven11_prod.seven11_gameplay_customization 
where gear_1 Like '%JAX_GearA1_%' or
gear_1 Like '%KIT_GearA18_%' or
gear_1 Like '%KUN_GearA7_%' or
gear_1 Like '%LIU_GearA5_%' or
gear_1 Like '%NOO_GearA22_%' or
gear_1 Like '%RAI_GearA16_%' or
gear_1 Like '%SCO_GearA28_%' or
gear_1 Like '%SHA_GearB15_%' or
gear_1 Like '%SUB_GearA2_%' or
gear_2 Like '%JAX_GearA1_%' or
gear_2 Like '%KIT_GearA18_%' or
gear_2 Like '%KUN_GearA7_%' or
gear_2 Like '%LIU_GearA5_%' or
gear_2 Like '%NOO_GearA22_%' or
gear_2 Like '%RAI_GearA16_%' or
gear_2 Like '%SCO_GearA28_%' or
gear_2 Like '%SHA_GearB15_%' or
gear_2 Like '%SUB_GearA2_%' 
group by 1,2,3)


Select Ed_chest_no,Count(distinct a._platform_account_id)
from ed_players a
join equipped b
on a._platform_account_id = b._platform_account_id
group by 1 ;

with ed_players as
(
select _platform_account_id,Ed_chest_no
from
(
select date(_event_time_utc) date,_platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
when date(_event_time_utc) in ('2019-08-23','2019-08-24') then 'Ed Chest 2'
when date(_event_time_utc) in ('2019-08-29','2019-08-30') then 'Ed Chest 3'
when date(_event_time_utc) in ('2019-09-03','2019-09-04') then 'Ed Chest 4'
when date(_event_time_utc) in ('2019-09-11','2019-09-12') then 'Ed Chest 5'
when date(_event_time_utc) in ('2019-09-19','2019-09-20') then 'Ed Chest 6'
when date(_event_time_utc) in ('2019-09-23','2019-09-24') then 'Ed Chest 7'
when date(_event_time_utc) in ('2019-10-01','2019-10-02') then 'Ed Chest 8'
when date(_event_time_utc) in ('2019-10-09','2019-10-10') then 'Ed Chest 9'
end as Ed_chest_no
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14','2019-08-23','2019-08-24','2019-08-29','2019-08-30',
'2019-09-03','2019-09-04','2019-09-11','2019-09-12','2019-09-19','2019-09-20','2019-09-23','2019-09-24',
'2019-10-01','2019-10-02','2019-10-09','2019-10-10')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4','LIU_GearA5','LIU_Skin4_Palette1',
'KIT_GearA18','KIT_Skin4_Palette1','SHA_Skin2_Palette1','SHA_GearB15','NOO_Skin6_Palette7',
'NOO_GearA22','SCO_Skin6_Palette6','SCO_GearA28','SUB_Skin4_Palette1','SUB_GearA2',
'KUN_Skin5_Palette1','KUN_GearA7','RAI_Skin6_Palette1','RAI_GearA16')
and unlock_source = 'KRYPT'
group by 1,2,3
)
group by 1,2
),

equipped as (select _platform_account_id,skin
from seven11_prod.seven11_gameplay_customization 
where skin Like '%JAX_Skin5_Palette4%' or
skin Like '%KIT_Skin4_Palette1%' or
skin Like '%KUN_Skin5_Palette1%' or
skin Like '%LIU_Skin4_Palette1%' or
skin Like '%NOO_Skin6_Palette7%' or
skin Like '%RAI_Skin6_Palette1%' or
skin Like '%SCO_Skin6_Palette6%' or
skin Like '%SHA_Skin2_Palette1%' or
skin Like '%SUB_Skin4_Palette1%' 
group by 1,2)

Select Ed_chest_no,Count(distinct a._platform_account_id)
from ed_players a
join equipped b
on a._platform_account_id = b._platform_account_id
group by 1;

