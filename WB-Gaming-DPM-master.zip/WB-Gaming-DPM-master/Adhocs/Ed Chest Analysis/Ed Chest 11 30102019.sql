-----DAU
select event_dt, count(distinct player_id)
from seven11_prod_da.wba_player_daily 
where event_dt >= '2019-04-22'
group by 1
order by 1;

---Krypt Visitors
select event_dt,count(distinct(player_id)) Players_Visited
from seven11_prod_da.wba_fact_activity 
where activity_name = 'GM_KRYPT' 
and event_dt>='2019-04-22'
and activity_hours is NOT NULL 
group by 1 
order by 1;

---New Krypt Visitors
select first_date, count(distinct(player_id)) New_Visitors
from(
select player_id,min(event_dt) first_date
from seven11_prod_da.wba_fact_activity 
where activity_name = 'GM_KRYPT' 
and event_dt>='2019-04-22'
and activity_hours is NOT NULL 
group by 1)
group by 1
order by 1;

------Players---Ed Chest 11

with ed_players_one as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_one_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no, min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  >= '2019-10-27' and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_one)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no,chest_open_ts
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-10-27','2019-10-28')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
Select *
from Ed_Players_one_Conv
group by 1,2,3)

Select Ed_chest_no,count(_platform_account_id) players
from Ed_players 
group by 1
order by 1 ;

-----New Spenders---Ed Chest 11


with ed_players_one as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_one_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no, min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  >= '2019-10-27' and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_one)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no,chest_open_ts
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-10-27','2019-10-28')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
Select *
from Ed_Players_one_Conv
group by 1,2,3) ,

players as (
select player_id
from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES
where premiumcurrency >= 50000
group by 1
) ,
Spenders as (
select _platform_account_id,min(_event_time_utc) Spend_ts
from seven11_prod.seven11_progression_unlock
where unlock_source = 'PREMIUM_SHOP' and date(_event_time_utc) >= '2019-04-22'
and _platform_account_id not in (select player_id from players)
group by 1)

Select Ed_chest_no, count(distinct _platform_account_id) New_Spenders
from
(
	Select Ed_chest_no,chest_open_ts,a._platform_account_id,Spend_ts,
		Spend_ts - chest_open_ts delta_time,
		Rank()over(partition by a._platform_account_id order by delta_time asc) Rank
	from Ed_players a
	left join Spenders b
	on a._platform_account_id = b._platform_account_id
	where (Spend_ts - chest_open_ts) > 0 
)
where Rank = 1
group by 1
order by 1 ;

-----Total Spenders after chest unlock--Ed Chest 11


with ed_players_one as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_one_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no, min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  >= '2019-10-27' and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_one)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no,chest_open_ts
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-10-27','2019-10-28')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
select *
from Ed_Players_one_Conv
group by 1,2,3) ,

players as (
select player_id
from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES
where premiumcurrency >= 50000
group by 1
) ,
Spenders as (
select _platform_account_id,_event_time_utc Spend_ts
from seven11_prod.seven11_progression_unlock
where unlock_source = 'PREMIUM_SHOP' and date(_event_time_utc) >= '2019-04-22'
and _platform_account_id not in (select player_id from players)
)


Select Ed_chest_no, count(distinct _platform_account_id) Total_spenders
from
(
	Select Ed_chest_no, chest_open_ts, a._platform_account_id,Spend_ts, case when 
	Lead(chest_open_ts, 1) OVER (partition by a._platform_account_id ORDER BY chest_open_ts) is null then '2030-04-22' else Lead(chest_open_ts, 1) OVER (partition by a._platform_account_id ORDER BY chest_open_ts) end AS Next_chest_open  
	from Ed_players a
	left join Spenders b
	on a._platform_account_id = b._platform_account_id    
	where (Spend_ts - chest_open_ts) > 0 
)
--where Rank = 1
where Spend_ts between chest_open_ts and Next_chest_open
group by 1
order by 1 ;

-----Open Time Krystal balances--- Ed Chest 11

with ed_players_one as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_one_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no, min(date(_event_time_utc)) chest_open_ts
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  in ('2019-10-27','2019-10-28') and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_one)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no,date(chest_open_ts) date
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-10-27','2019-10-28')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
select *
from Ed_Players_one_Conv
group by 1,2,3)

select Ed_chest_no,count(player_id),Sum(premiumcurrency),Avg(premiumcurrency), min(premiumcurrency), max(premiumcurrency),median(premiumcurrency)
from
(
	select a.player_id,Ed_chest_no, a.play_date, cast(a.premiumcurrency as float) premiumcurrency
	from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES a
	join ed_players b
	on a.player_id = b._platform_account_id and date(a.play_date)= b.date
	where premiumcurrency<50000
)
group by 1
order by 1 ;

----Gears Equipped---------Ed Chest 11

with ed_players_one as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_one_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no, min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  >= '2019-10-27' and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_one)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no,chest_open_ts
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-10-27','2019-10-28')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
select *
from Ed_Players_one_Conv
group by 1,2,3),

equipped as (select _platform_account_id,gear_1,gear_2
from seven11_prod.seven11_gameplay_customization 
where gear_1 Like '%JAX_GearA1_%' or
gear_2 Like '%JAX_GearA1_%'
group by 1,2,3)


Select Ed_chest_no,Count(distinct a._platform_account_id)
from ed_players a
join equipped b
on a._platform_account_id = b._platform_account_id
group by 1 
order by 1;

-------Skins Equipped---Ed Chest 11

with ed_players_one as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_one_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  >= '2019-10-27' and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_one)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-10-27','2019-10-28')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
select *
from Ed_Players_one_Conv 
group by 1,2),

equipped as (select _platform_account_id,skin
from seven11_prod.seven11_gameplay_customization 
where skin Like '%JAX_Skin5_Palette4%'
group by 1,2)

Select Ed_chest_no,Count(distinct a._platform_account_id)
from ed_players a
join equipped b
on a._platform_account_id = b._platform_account_id
group by 1
order by 1;


---Popup Views

 with popup as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-popup')
	group by 1
),
notif as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-notification')
	group by 1
)

Select count(*) Popup_Viewed
from popup  ;


---Popup----Krypt Visitors

 with popup as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-popup')
	group by 1
),
notif as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-notification')
	group by 1
)

select count(distinct(player_id)) Players_Visited
from seven11_prod_da.wba_fact_activity 
where activity_name = 'GM_KRYPT' 
and date(event_dt) in ('2019-10-27','2019-10-28')
and activity_hours is not NULL 
and player_id in (select _platform_account_id from popup)
;

-------Popup_Converted--Ed Chest 11

with ed_players_one as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_one_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  >= '2019-10-27' and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_one)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-10-27','2019-10-28')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
select *
from Ed_Players_one_Conv 
group by 1,2) ,

popup as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-popup')
	group by 1
),
notif as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-notification')
	group by 1
)

select count(distinct _platform_account_id ) Opened
from ed_players
where _platform_account_id in (select _platform_account_id from popup) ;

----Notification Views

  with popup as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-popup')
	group by 1
),
notif as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-notification')
	group by 1
)

Select count(*) Notif_Viewed
from notif  ;


---notification----Krypt Visitors

 with popup as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-popup')
	group by 1
),
notif as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-notification')
	group by 1
)

select count(distinct(player_id)) Players_Visited
from seven11_prod_da.wba_fact_activity 
where activity_name = 'GM_KRYPT' 
and date(event_dt) in ('2019-10-27','2019-10-28')
and activity_hours is not NULL 
and player_id in (select _platform_account_id from notif)
;

 ------Notification_Converted to Ed Chest 11
 
with ed_players_one as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_one_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  >= '2019-10-27' and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_one)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-10-27','2019-10-28')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
select *
from Ed_Players_one_Conv 
group by 1,2) ,

popup as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-popup')
	group by 1
),
notif as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-notification')
	group by 1
)

select count(distinct _platform_account_id ) Opened
from ed_players
where _platform_account_id in (select _platform_account_id from notif ) ;

---- Ed Chest 1 Converted  to 11

with ed_players_one as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_one_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  >= '2019-10-27' and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_one)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-10-27','2019-10-28')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
select *
from Ed_Players_one_Conv 
group by 1,2) 



Select Count(distinct _platform_account_id) Converted
from(
select _platform_account_id
from ed_players
where _platform_account_id in  (Select * from ed_players_one)
group by 1
)
