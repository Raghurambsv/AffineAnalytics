
with popup as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-popup')
	group by 1
)

-------------------------------------------------------------
-- Players Visiting the Krypt first time after the pop up.

select krypt_event_status, count(distinct (Players_Visited))
from
(
select Players_Visited, 
case when FirstVisitAfterPopUP < '2019-10-27 19:00:00' then 'Before_Event'
     when FirstVisitAfterPopUP between '2019-10-27 19:00:00' and '2019-10-27 22:00:00' then 'During_Event'
	 when FirstVisitAfterPopUP > '2019-10-27 22:00:00' then 'After_Event'
     end as krypt_event_status
from
(select c.Players_Visited, min(c._event_time_utc) FirstVisitAfterPopUP,d._event_time_utc Popuptime from
(select a._platform_account_id Players_Visited,a._event_time_utc
from seven11_prod.seven11_activity_begin a
join seven11_prod_da.wba_fact_activity b
on a._platform_account_id = b.player_id and a._activity_guid = b.activity_guid
where b.activity_name = 'GM_KRYPT' 
and date(a._event_time_utc) in ('2019-10-27','2019-10-28')
and b.activity_hours is not NULL 
) c
join seven11_prod.seven11_ui_decision d
on c.Players_Visited=d._platform_account_id
where d._event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
and d.source_index in ('special-krypt-event-jax-arms-popup')
group by 1,3
)
)
group by 1
;

-------------------------------------------------------------
-- Players visiting before,then same players can also visit during the event and also after the event

select krypt_event_status, count(distinct Players_Visited),sum(activity_hours)
from
(select a._platform_account_id Players_Visited,b.activity_hours,
case when a._event_time_utc < '2019-10-27 19:00:00' then 'Before_Event'
when a._event_time_utc between '2019-10-27 19:00:00' and '2019-10-27 22:00:00' then 'During_Event'
when a._event_time_utc > '2019-10-27 22:00:00' then 'After_Event'
end as krypt_event_status
from seven11_prod.seven11_activity_begin a
join seven11_prod_da.wba_fact_activity b
on a._platform_account_id = b.player_id and a._activity_guid = b.activity_guid
where b.activity_name = 'GM_KRYPT' 
and date(a._event_time_utc) in ('2019-10-27','2019-10-28')
and b.activity_hours is not NULL 
and a._platform_account_id in (select _platform_account_id from popup)
)
group by 1
;
----------------------------------------------------------------------




--select count(distinct(_platform_account_id)) Players_Visited
--from seven11_prod.seven11_activity_begin 
--where activity_name = 'GM_KRYPT' 
--and date(_event_time_utc) in ('2019-10-27','2019-10-28')
--and activity_session_time_s is not NULL 
--and _platform_account_id in (select _platform_account_id from popup)
--;