
-------------------------------------------------------------------------------------------------
-- Players who visited krypt during the event and time spent during the event. Considered first visit of player after pop up.
select krypt_event_status, count(distinct (Players_Visited)),sum(hours_spent) total_time_spent from
(
	select player_id Players_Visited, 
	case when firstvistafterpopup < '2019-10-27 19:00:00' then 'Before_Event'
     	 when firstvistafterpopup between '2019-10-27 19:00:00' and '2019-10-27 22:00:00' then 'During_Event'
	     when firstvistafterpopup > '2019-10-27 22:00:00' then 'After_Event'
     	 end as krypt_event_status,
	hours_spent from
  	(
		select player_activity_popup.player_id,popuptime,min(player_activity_popup.activity_time) firstvistafterpopup,sum(fact_activity.activity_hours) hours_spent  from
		(
			select act_begin._platform_account_id player_id,act_begin._event_time_utc activity_time,ui_decision._event_time_utc popuptime,act_begin._activity_guid
			from seven11_prod.seven11_activity_begin act_begin
			join seven11_prod.seven11_ui_decision ui_decision
			on act_begin._platform_account_id = ui_decision._platform_account_id
			where ui_decision._event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
			and ui_decision.source_index in ('special-krypt-event-jax-arms-popup')
			and act_begin.activity_name = 'GM_KRYPT'
			and date(act_begin._event_time_utc) in ('2019-10-27','2019-10-28')
		) player_activity_popup
		join seven11_prod_da.wba_fact_activity fact_activity
		on player_activity_popup.player_id = fact_activity.player_id 
		and player_activity_popup._activity_guid = fact_activity.activity_guid
		where fact_activity.activity_name = 'GM_KRYPT'
		and fact_activity.activity_hours is not NULL
		and player_activity_popup.activity_time > popuptime
		group by 1,2
	)
) group by 1

----------------------------------------------------------------------------------------------------------
-- Players who visited during the event and opened/notopened ed chest.

with ed_players_one as
(
Select  _platform_account_id
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-08-13','2019-08-14') then 'Ed Chest 1'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-08-13','2019-08-14')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
group by 1) ,

Ed_Players_one_Conv as
(select _platform_account_id,case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no
from seven11_prod.seven11_resource_flow
where resource = 'Exp_Koins' and DATE(_event_time_utc)  >= '2019-10-27' and change_amount = 100000 and Source ='KRYPT'
and _platform_account_id in (select * from ed_players_one)
group by 1,2) ,

ed_players as
(
Select  _platform_account_id, Ed_chest_no
from(
select _platform_account_id,
case when date(_event_time_utc) in ('2019-10-27','2019-10-28') then 'Ed Chest 11'
end as Ed_chest_no,min(_event_time_utc) chest_open_ts
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-10-27','2019-10-28')
and unlock_name in ('JAX_GearA1','JAX_Skin5_Palette4')
and unlock_source = 'KRYPT'
group by 1,2
)
Union
select *
from Ed_Players_one_Conv 
group by 1,2) ,

popup as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-popup')
	group by 1
),
notif as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-notification')
	group by 1
)


select krypt_event_status,Edchest_Unlocked,count(distinct Players_Visited) player_count,sum(hours_spent) time_spent  
from
(
	select Players_Visited,krypt_event_status,hours_spent,
	case when edchest_players is NULL then 'Not Unlocked'
	else 'Unlocked'
	end as Edchest_Unlocked from
	(
		select Players_Visited,krypt_event_status,hours_spent,ed_players._platform_account_id edchest_players
		from
		(	
			select player_id Players_Visited, 
			case when firstvistafterpopup < '2019-10-27 19:00:00' then 'Before_Event'
     		when firstvistafterpopup between '2019-10-27 19:00:00' and '2019-10-27 22:00:00' then 'During_Event'
	    	when firstvistafterpopup > '2019-10-27 22:00:00' then 'After_Event'
     		end as krypt_event_status,
			hours_spent from
  			(
				select player_activity_popup.player_id,popuptime,min(player_activity_popup.activity_time) firstvistafterpopup,sum(fact_activity.activity_hours) hours_spent  from
				(
					select act_begin._platform_account_id player_id,act_begin._event_time_utc activity_time,ui_decision._event_time_utc popuptime,act_begin._activity_guid
					from seven11_prod.seven11_activity_begin act_begin
					join seven11_prod.seven11_ui_decision ui_decision
					on act_begin._platform_account_id = ui_decision._platform_account_id
					where ui_decision._event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
					and ui_decision.source_index in ('special-krypt-event-jax-arms-popup')
					and act_begin.activity_name = 'GM_KRYPT'
					and date(act_begin._event_time_utc) in ('2019-10-27','2019-10-28')
				) player_activity_popup
				join seven11_prod_da.wba_fact_activity fact_activity
				on player_activity_popup.player_id = fact_activity.player_id 
				and player_activity_popup._activity_guid = fact_activity.activity_guid
				where fact_activity.activity_name = 'GM_KRYPT'
				and fact_activity.activity_hours is not NULL
				and player_activity_popup.activity_time > popuptime
				group by 1,2
			)
		) player_krypt_event 
		left join ed_players 
		on player_krypt_event.Players_Visited = ed_players._platform_account_id
	)
) group by 1,2

--------------------------------------------------------------------------------------------------
---- For those who visited krypt during event,players who have unlocked the location(AreaPit) that the chest was in before the event


with player_areapit_location_unlock as
(
	select distinct (_platform_account_id) from
	seven11_prod.seven11_gameplay_kryptaction
	where location='AreaPit' 
	and _event_time_utc < '2019-10-27 22:00:00'  
),
popup as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-popup')
	group by 1
)

select krypt_event_status,location_access,count(distinct player_id)
from
(
	select player_id,krypt_event_status,
	case when area_pit_players is NULL then 'No Access'
	else 'Access'
	end as location_access
	from
	(
		select krypt_event_status,player_krypt_event.Players_Visited player_id,areapit_loc._platform_account_id area_pit_players
		from
		(
			select player_id Players_Visited, 
			case when firstvistafterpopup < '2019-10-27 19:00:00' then 'Before_Event'
     	 	when firstvistafterpopup between '2019-10-27 19:00:00' and '2019-10-27 22:00:00' then 'During_Event'
	     	when firstvistafterpopup > '2019-10-27 22:00:00' then 'After_Event'
     	 	end as krypt_event_status,
			hours_spent from
  			(
				select player_activity_popup.player_id,popuptime,min(player_activity_popup.activity_time) firstvistafterpopup,sum(fact_activity.activity_hours) hours_spent  from
				(
					select act_begin._platform_account_id player_id,act_begin._event_time_utc activity_time,ui_decision._event_time_utc popuptime,act_begin._activity_guid
					from seven11_prod.seven11_activity_begin act_begin
					join seven11_prod.seven11_ui_decision ui_decision
					on act_begin._platform_account_id = ui_decision._platform_account_id
					where ui_decision._event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
					and ui_decision.source_index in ('special-krypt-event-jax-arms-popup')
					and act_begin.activity_name = 'GM_KRYPT'
					and date(act_begin._event_time_utc) in ('2019-10-27','2019-10-28')
				) player_activity_popup
				join seven11_prod_da.wba_fact_activity fact_activity
				on player_activity_popup.player_id = fact_activity.player_id 
				and player_activity_popup._activity_guid = fact_activity.activity_guid
				where fact_activity.activity_name = 'GM_KRYPT'
				and fact_activity.activity_hours is not NULL
				and player_activity_popup.activity_time > popuptime
				group by 1,2
			)
		) player_krypt_event
		left join player_areapit_location_unlock areapit_loc
		on player_krypt_event.Players_Visited = areapit_loc._platform_account_id
	)
) group by 1,2

-----------------------------------------------------------------------------------------

------------------------------------------------------------------------------------------------------
 -- Players who saw pop up, did not visit krypt but have access to the area pit.

with player_areapit_location_unlock as
(
	select distinct (_platform_account_id) from
	seven11_prod.seven11_gameplay_kryptaction
	where location='AreaPit' 
	and _event_time_utc < '2019-10-27 22:00:00'  
),
popup as(
	select _platform_account_id
	from seven11_prod.seven11_ui_decision
	where _event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
	and source_index in ('special-krypt-event-jax-arms-popup')
	group by 1
),
popup_krypt_visitors as (
	select player_id from seven11_prod_da.wba_fact_activity
	where activity_name = 'GM_KRYPT'
	and date(event_dt) in ('2019-10-27','2019-10-28')
	and activity_hours is not NULL
	and player_id in (select _platform_account_id from popup)
	group by 1
)

select location_access,count(distinct popup_players) from
(
	select popup._platform_account_id as popup_players,
		case when (areapit_loc._platform_account_id) is NULL then 'No Access'
		else 'Access'
		end as location_access
	from popup
	left join player_areapit_location_unlock as areapit_loc
	on popup._platform_account_id = areapit_loc._platform_account_id
	where popup._platform_account_id not in (select distinct player_id from popup_krypt_visitors)
)
group by 1



-------------------------------------------------------------------------------------------
--- Get the Edchest 11 players who visited krypt on 10/27
with edchest11_cohort as (
	select distinct Players_Visited from 
	(
		select player_id Players_Visited, 
		case when firstvistafterpopup < '2019-10-27 19:00:00' then 'Before_Event'
     	 	 when firstvistafterpopup between '2019-10-27 19:00:00' and '2019-10-27 22:00:00' then 'During_Event'
	       	 when firstvistafterpopup > '2019-10-27 22:00:00' then 'After_Event'
     	end as krypt_event_status,
		hours_spent from
  		(
			select player_activity_popup.player_id,popuptime,min(player_activity_popup.activity_time) firstvistafterpopup,sum(fact_activity.activity_hours) hours_spent  from
			(
				select act_begin._platform_account_id player_id,act_begin._event_time_utc activity_time,ui_decision._event_time_utc popuptime,act_begin._activity_guid
				from seven11_prod.seven11_activity_begin act_begin
				join seven11_prod.seven11_ui_decision ui_decision
				on act_begin._platform_account_id = ui_decision._platform_account_id
				where ui_decision._event_time_utc between '2019-10-25 00:00:00' and '2019-10-28 00:00:00' 
				and ui_decision.source_index in ('special-krypt-event-jax-arms-popup')
				and act_begin.activity_name = 'GM_KRYPT'
				and date(act_begin._event_time_utc) in ('2019-10-27','2019-10-28')
			) player_activity_popup
			join seven11_prod_da.wba_fact_activity fact_activity
			on player_activity_popup.player_id = fact_activity.player_id 
			and player_activity_popup._activity_guid = fact_activity.activity_guid
			where fact_activity.activity_name = 'GM_KRYPT'
			and fact_activity.activity_hours is not NULL
			--and player_activity_popup.activity_time > popuptime
			group by 1,2
		) 
	)
)

--select count(distinct Players_Visited) from edchest11_cohort

-----------------------------------------------------------------------------------------------
-- Time spent per day per player
select avg(time_spent_per_day) time_spent_per_day_per_player 
from
(
	select player_id,avg(activity_hours) time_spent_per_day from
	(
		select player_id,date(event_dt) event_date,activity_hours 
		from seven11_prod_da.wba_fact_activity fact_activity
		where date(event_dt) not in ('2019-10-27','2019-10-28','2019-10-17','2019-10-09')
		and date(event_dt) > '2019-10-01'
		and fact_activity.activity_name = 'GM_KRYPT'
		and fact_activity.activity_hours is not NULL
		and fact_activity.player_id in (select distinct(Players_Visited) from edchest11_cohort)
	)  group by 1
)

-----------------------------------------------------------------------------------------------
-- Average time spent per day for the cohort
select avg(activity_hours) avg_time_spent_per_day from
(
	select player_id,date(event_dt) event_date,activity_hours 
	from seven11_prod_da.wba_fact_activity fact_activity
	where date(event_dt) not in ('2019-10-27','2019-10-28','2019-10-17','2019-10-09')
	and date(event_dt) > '2019-10-01'
	and fact_activity.activity_name = 'GM_KRYPT'
	and fact_activity.activity_hours is not NULL
	and fact_activity.player_id in (select distinct(Players_Visited) from edchest11_cohort)
)


