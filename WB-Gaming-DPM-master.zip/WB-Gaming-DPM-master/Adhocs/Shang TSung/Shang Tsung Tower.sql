



select tower_id, count(a._platform_account_id) tower_players, count(b._platform_account_id) Shang_Tsung_owner
from
(
select tower_id, _platform_account_id, min(wbanalyticssourcedate) tower_play_dt
from seven11_prod.seven11_match_result_player
where tower_id like '%ShangTsung%'
group by 1,2
) a

left join

(
select _platform_account_id, min(_event_time_local) DLC_dt
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('kombat_pack','shang_tsung','shang_tsung_kombat_pack_version')
group by 1
) b
using(_platform_account_id)
group by 1


---
select tower_id, count(case when tower_play_dt >= b.dlc_dt then a._platform_account_id end) prior_owner,
count(case when tower_play_dt < b.dlc_dt then a._platform_account_id end) after_tower_owner
from
(
select tower_id, _platform_account_id, min(wbanalyticssourcedate) tower_play_dt
from seven11_prod.seven11_match_result_player
where tower_id like '%ShangTsung%'
group by 1,2
) a
left join
(
select _platform_account_id, min(_event_time_local) DLC_dt
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('kombat_pack','shang_tsung','shang_tsung_kombat_pack_version')
group by 1
) b
using(_platform_account_id)
where b.dlc_dt is not null
group by 1


