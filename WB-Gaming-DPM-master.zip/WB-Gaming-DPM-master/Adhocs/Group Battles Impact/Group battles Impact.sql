---------------Daily Engagement in different activity modes

select a.game_mode,a.date,Players/DAU Perc_DAU,Hours_played_per_mode/Hours_played perc_time
from(select case when activity_name in ('GM_GROUP_BATTLES') then 'Group Battles'
		when activity_name in ('GM_TOWERS_OF_TIME') then 'Towers'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE') then 'Klassic Mode'
		when activity_name in ('GM_RANKED_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT','GM_PLAYER_MATCH_ON_KOTH' ) then 'Online Modes'
		else 'Others' END AS Game_mode,date(event_dt) date,count(distinct player_id)::float Players,
		 sum(activity_hours)::float Hours_played_per_mode
	from seven11_prod_da.wba_fact_activity
	where date(event_dt) between  '2019-04-22' and '2019-07-25'
	group by 1,2) a
join
	(select date(event_dt) date,count(distinct player_id)::float DAU,
		 sum(activity_hours)::float Hours_played
	from seven11_prod_da.wba_fact_activity
	where date(event_dt) between  '2019-04-22' and '2019-07-25'
	group by 1) b
On a.date = b.date 
where Game_mode not in ('Others');

---------------Daily Engagement in Group battles and Towers of time combined

select a.game_mode,a.date,Players/DAU Perc_DAU,Hours_played_per_mode/Hours_played perc_time
from(select case when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME') then 'Towers+Group'
		else 'Others' END AS Game_mode,date(event_dt) date,count(distinct player_id)::float Players,
		 sum(activity_hours)::float Hours_played_per_mode
	from seven11_prod_da.wba_fact_activity
	where date(event_dt) between  '2019-04-22' and '2019-07-25'
	group by 1,2) a
join
	(select date(event_dt) date,count(distinct player_id)::float DAU,
		 sum(activity_hours)::float Hours_played
	from seven11_prod_da.wba_fact_activity
	where date(event_dt) between  '2019-04-22' and '2019-07-25'
	group by 1) b
On a.date = b.date
where Game_mode not in ('Others')
 ;
