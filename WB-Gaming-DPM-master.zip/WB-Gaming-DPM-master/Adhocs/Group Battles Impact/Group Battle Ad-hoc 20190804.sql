----------

select event_dt, coalesce (GB_on_off::int,0) GB_on_off, tower_id, ty, avg_time_per_tower, avg_players, rank () over (partition by event_dt order by avg_time_per_tower desc ) rank_num, rank () over (partition by event_dt order by avg_players desc ) rank_num_players
from
(
	select event_dt, tower_id,'TOT' ty, avg(time_per_player) avg_time_per_tower, avg(players) avg_players
	from
	(
	select date(wbanalyticssourcedate) event_dt, tower_id,
	count(distinct _platform_account_id) players, count(distinct match_id) matches, sum(match_length::float) / 60 matchtime, matchtime/players time_per_player
	from seven11_prod.seven11_match_result_player
	where ai_difficulty = -1
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and activity_name = 'GM_TOWERS_OF_TIME_LADDER'
	group by 1,2
	having count(distinct _platform_account_id) >= 1000
	) a
	group by 1,2,3

union 

	select event_dt, tower_id,'GB' ty , avg(Groupbattle_time_player) Groupbattle_time_player, avg(players) Avg_GB_players
	from
	(
	select date(wbanalyticssourcedate) event_dt, tower_id,
	count(distinct _platform_account_id) players, count(distinct match_id) matches, sum(match_length::float) / 60 matchtime,
	matchtime / players Groupbattle_time_player
	from seven11_prod.seven11_match_result_player
	where ai_difficulty = -1
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and activity_name = 'GM_GROUP_BATTLES'
	group by 1,2
	having count(distinct _platform_account_id) >= 200
	)
	group by 1,2,3
) a
left join (
	select date(wbanalyticssourcedate) event_dt, '1' as GB_on_off from seven11_prod.seven11_match_result_player
	where ai_difficulty = -1
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and activity_name = 'GM_GROUP_BATTLES'
	group by 1,2
	having count(distinct _platform_account_id) >= 200
		  ) b
using(event_dt)

--------------------------------------

select *
from seven11_prod.seven11_match_result_player
limit 1000

select activity_name
from seven11_prod.seven11_match_result_player
group by 1

select date(wbanalyticssourcedate) event_dt, tower_id ty,
count(distinct _platform_account_id) players, count(distinct match_id) matches, sum(match_length::float) / 60 matchtime, count(ty) over (partition by event_dt) towers_ct
from seven11_prod.seven11_match_result_player
where ai_difficulty = -1
and date(wbanalyticssourcedate) >= '2019-04-22'
and activity_name = 'GM_GROUP_BATTLES'
group by 1,2
having count(distinct _platform_account_id) >= 200

select date(wbanalyticssourcedate) event_dt, tower_id ty,
count(distinct _platform_account_id) players, count(distinct match_id) matches, sum(match_length::float) / 60 matchtime, count(ty) over (partition by event_dt) towers_ct
from seven11_prod.seven11_match_result_player
where ai_difficulty = -1
and date(wbanalyticssourcedate) >= '2019-04-22'
and activity_name = 'GM_TOWERS_OF_TIME_LADDER'
group by 1,2
having count(distinct _platform_account_id) >= 200


select a.event_dt, a.players total_dau, a.matchtime total_match_time, b.players tower_only_players, b.matchtime tower_time
, c.players GB_players, c.matchtime GB_time, d.players Tower_GB_players, d.matchtime Tower_GB_players
from
(
select date(wbanalyticssourcedate) event_dt, count(distinct _platform_account_id) players, sum(match_length::float) / 60 matchtime
from seven11_prod.seven11_match_result_player
where ai_difficulty = -1
and date(wbanalyticssourcedate) >= '2019-04-22'
--and activity_name = 'GM_TOWERS_OF_TIME_LADDER'
group by 1
) a
left join
(
select date(wbanalyticssourcedate) event_dt, count(distinct _platform_account_id) players, sum(match_length::float) / 60 matchtime
from seven11_prod.seven11_match_result_player
where ai_difficulty = -1
and date(wbanalyticssourcedate) >= '2019-04-22'
and activity_name = 'GM_TOWERS_OF_TIME_LADDER'
group by 1
) b
using(event_dt)
left join
(
select date(wbanalyticssourcedate) event_dt, count(distinct _platform_account_id) players, sum(match_length::float) / 60 matchtime
from seven11_prod.seven11_match_result_player
where ai_difficulty = -1
and date(wbanalyticssourcedate) >= '2019-04-22'
and activity_name = 'GM_GROUP_BATTLES'
group by 1 
having count(distinct _platform_account_id) >= 200
) c
using(event_dt)
left join
(
select date(wbanalyticssourcedate) event_dt, count(distinct _platform_account_id) players, sum(match_length::float) / 60 matchtime
from seven11_prod.seven11_match_result_player
where ai_difficulty = -1
and date(wbanalyticssourcedate) >= '2019-04-22'
and activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER')
group by 1 
having count(distinct _platform_account_id) >= 200
) d
using(event_dt)

-------------------


select sum(days) total_days, sum(matchtime) matchtime, count(players) players
from
(
select _platform_account_id players, sum(match_length::float) / 60 matchtime, count(distinct date(wbanalyticssourcedate)) days
from seven11_prod.seven11_match_result_player
where ai_difficulty = -1
and date(wbanalyticssourcedate) not in	
	(
		select date(wbanalyticssourcedate) event_dt--, '1' as GB_on_off 
		from seven11_prod.seven11_match_result_player
		where ai_difficulty = -1
		and date(wbanalyticssourcedate) >= '2019-04-22'
		and activity_name = 'GM_GROUP_BATTLES'
		group by 1
		having count(distinct _platform_account_id) >= 200
	)
and activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER')
and _platform_account_id in 
	(
		select _platform_account_id
		from seven11_prod.seven11_match_result_player
		where ai_difficulty = -1
		and date(wbanalyticssourcedate) >= '2019-04-22'
		and activity_name = 'GM_GROUP_BATTLES'
		group by 1
	)
group by 1
)

	
	
	
	