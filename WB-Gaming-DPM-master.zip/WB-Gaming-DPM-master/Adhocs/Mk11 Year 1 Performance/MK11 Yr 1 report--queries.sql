------MK11 Game mode wise Weekly Retention
With game_modes as(
select case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode ,date(event_dt) play_dt,player_id
from seven11_prod_da.wba_fact_activity
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-19'
and activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1,2,3
),
datedim as ( select DATEDIFF(week, '2019-04-14', dateadd(DAY,-1,event_dt)) YearMonthweek from seven11_prod_da.wba_fact_activity group by 1)


            select b.Game_mode,period, Retentionweek, newweek, count(distinct c.player_id) retained_players, count(distinct b.player_id) cohorts
            from
            (
              SELECT d.YearMonthweek NewWeek, d2.YearMonthweek- d.YearMonthweek period, d2.YearMonthweek Retentionweek
                FROM datedim d
                JOIN datedim  d2 ON d.YearMonthweek < d2.YearMonthweek
                WHERE  (d.YearMonthweek>=1 and d.YearMonthweek < DATEDIFF(week, '2019-04-14', dateadd(DAY,-1,CAST(getdate() as DATE))))
                AND (d2.YearMonthweek>=1 and  d2.YearMonthweek < DATEDIFF(week, '2019-04-14', dateadd(DAY,-1,CAST(getdate() as DATE))))
            ) A
            join
            (

              select player_id,Game_mode, min(DATEDIFF(week, '2019-04-14', dateadd(DAY,-1,play_dt))) yearmonthweek
              from game_modes a
			  group by 1,2
            )  B
            on a.NewWeek = b.yearmonthweek
            left join
            (

              select DATEDIFF(week, '2019-04-14', dateadd(DAY,-1,play_dt)) yearmonthweek, player_id,Game_mode
              from game_modes a
			  group by 1,2,3
            ) C
            on b.player_id = c.player_id
	    and b.Game_mode = c.Game_mode
	    and c.yearmonthweek = a.retentionweek
            where b.yearmonthweek >= 1  
            group by 1,2,3,4
			order by 1,4,3,2	 ;
			
----Game mode distribution --Monthly level --MK11

select case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode ,datepart(year,DATE(event_dt)) YR,datepart(month,DATE(event_dt)) MON,
		sum(activity_hours) Total_Hours
from seven11_prod_da.wba_fact_activity
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
and activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1,2,3
order by 2,3,1;

----Game mode distribution --Overall level --MK11

select case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode ,sum(activity_hours) Total_Hours
from seven11_prod_da.wba_fact_activity
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
and activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1
order by 1;

---Avg Hrs Played

select AVG(LTD_hrs) Avg_hrs, Median(LTD_hrs) Median_hrs
from(
	select player_id,Sum(total_hours) LTD_hrs	
	from seven11_prod_da.wba_player_daily 
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	group by 1
	having LTD_hrs > 0)  ;

---Players distribution based on time played

select hrs,count(player_id) Players,Sum(Players)over(order by hrs asc rows unbounded preceding) Cum_players
from(
	select player_id,Sum(total_hours) LTD_hrs, ceiling(Sum(total_hours)) hrs
	from seven11_prod_da.wba_player_daily 
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
	group by 1
	having LTD_hrs > 0) 
group by 1
order by 1;


-----Mau by Platform
    select datepart(year,date(event_dt)) YR,datepart(month,date(event_dt)) MON,platform,count(distinct player_id) MAU
	from seven11_prod_da.wba_player_daily a
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	group by 1,2,3
	order by 1,2,3 ;
	
----Overall Mau
	select datepart(year,date(event_dt)) YR,datepart(month,date(event_dt)) MON,count(distinct player_id) MAU
	from seven11_prod_da.wba_player_daily a
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	group by 1,2
	order by 1,2 ;
	

------Daily New Players by Platform
     select install_dt,platform,count(distinct player_id)
	 from(
	 select player_id,platform,min(date(event_dt)) install_dt
              from seven11_prod_da.wba_player_daily a
			  where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	group by 1,2)
	group by 1,2
	order by 1,2 ;
	
------Monthly New Players
     select datepart(year,install_dt) YR,datepart(month,install_dt) MON,count(distinct player_id) New_Players
	 from(
	 select player_id,min(date(event_dt)) install_dt
     from seven11_prod_da.wba_player_daily a
	 where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	 group by 1)
	 group by 1,2
	 order by 1,2 ;
	 
	------Retention
with MK11_retention as (
 with datedim as ( select date(event_dt) YearMonthDay from seven11_prod_da.wba_fact_activity group by 1)

            select period, RetentionDate, newdate, count(c.player_id) retained_players, count(b.player_id) cohorts
            from
            (
              SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
                FROM datedim d
                JOIN datedim  d2 ON d.YearMonthDay < d2.YearMonthDay
                WHERE  (d.YearMonthDay>='2019-04-22' and d.YearMonthDay < '2020-04-19')
                AND (d2.YearMonthDay>='2019-04-22' and  d2.YearMonthDay < '2020-04-19')
            ) A
            join
            (

              select player_id, min(date(event_dt)) yearmonthday
              from seven11_prod_da.wba_player_daily a
        	  where date(event_dt) >= '2019-04-22' and date(event_dt) < '2020-04-19'
              group by 1

            )  B
            on a.NewDate = b.yearmonthday
            left join
            (

              select date(event_dt) yearmonthday, player_id
              from seven11_prod_da.wba_player_daily a
			  where date(event_dt) >= '2019-04-22' and date(event_dt) < '2020-04-19'
              group by 1,2

            ) C
            on b.player_id = c.player_id
            and c.yearmonthday = a.retentiondate
            where b.yearmonthday >= '2019-04-22'
            group by 1,2,3
)


    select NewDate,period, retained_players, Cohorts
    from MK11_retention
    where period in (1,15,30,60,90)
    group by 1,2,3,4
	order by 2,1 ;
	
	-----Ltd Hours Played & LTD days Played---Monthly
  
	  select datepart(year,install_dt) YR,datepart(month,install_dt) MON, Avg(LTD_Hours) LTD_hrs_per_player,Avg(LTD_Days) LTD_Days_per_Player
	 from(
	 select player_id,min(date(event_dt)) install_dt,Sum(total_hours) LTD_Hours,count(distinct(date(event_dt)))::float LTD_Days
     from seven11_prod_da.wba_player_daily a
	 where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	 group by 1)
	 group by 1,2
	 order by 1,2 ;
	 
	 -----KP ownership---Monthly

 with Cohorts as(
select datepart(year,install_dt) YR,datepart(month,install_dt) MON,player_id
from(
select player_id,min(date(event_dt)) install_dt
from seven11_prod_da.wba_player_daily a
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
group by 1)
group by 1,2,3)

select YR,MON,count(distinct _platform_account_id) KP_owners
from seven11_prod.seven11_dlc_entitlement a
join Cohorts b
on a._platform_account_id = b.player_id
where entitlement_name in ('kombat_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) between '2019-04-22'  and '2020-04-18' 
group by 1,2 
order by 1,2 ;
 
	 
---Players distribution based on time played ---  > 30 mins

select hrs,count(player_id) Players,Sum(Players)over(order by hrs asc rows unbounded preceding) Cum_players
from(
	select player_id,Sum(total_hours) hrsplayed, ceiling(Sum(total_hours)) hrs
	from seven11_prod_da.wba_player_daily 
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
	group by 1
	having hrsplayed > 0.5 and hrsplayed <= 500) 
group by 1
order by 1;

---- Avg and Median Hrs---  > 30 mins

select AVG(hrsplayed) Avg_hrs, Median(hrsplayed) Median_hrs
from(
	select player_id,Sum(total_hours) hrsplayed	
	from seven11_prod_da.wba_player_daily 
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	group by 1
	having hrsplayed > 0.5 and hrsplayed <= 500)  ;
	
---Quartiles---KPIs

with Quartiles as (
select player_id, 
	  case when cumsumplayers >= 0.75 then 'Q4'
		   when cumsumplayers >= 0.5 then 'Q3'
		   when cumsumplayers >= 0.25 then 'Q2' 
		   else 'Q1' end as Quartile 
from
(
select player_id, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select player_id, sum(total_hours) hrsplayed, sum(hrsplayed) over () totaltime,  sum(total_hours::float) / sum(hrsplayed) over () perc, 1::float / count(player_id) over ()  cum_players
		from seven11_prod_da.wba_player_daily
		where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
		group by 1
		having hrsplayed > 0.5 and hrsplayed <= 500
	)
)
group by 1,2
having Quartile is not NULL
)

Select a.*,KP_owners,TK_purchasers,Total_TK_purchased
from(
select Quartile,min(hrsplayed) Min_hrs,max(hrsplayed) Max_hrs,Avg(hrsplayed) Avg_hrs,Median(hrsplayed) Median_hrs,
count(player_id) Players,Avg(sessions) sessions_per_player,Sum(sessions)/Sum(days_played) Session_per_player_per_day,
Sum(hrsplayed)/Sum(days_played) Hrs_per_player_per_day,AVg(days_played) Avg_days_played
from(
	select player_id,Quartile,sum(session_count)::float sessions, count(distinct date(event_dt)) days_played,
	sum(total_hours) hrsplayed
    from seven11_prod_da.wba_player_daily 
	join Quartiles
	using(player_id)	
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
	group by 1,2
	) 
group by 1) a
join 
(
select Quartile,count(distinct _platform_account_id) KP_owners
from seven11_prod.seven11_dlc_entitlement a
join Quartiles b
on a._platform_account_id = b.player_id
where entitlement_name in ('kombat_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) between '2019-04-22'  and '2020-04-18' 
group by 1 ) b
using(quartile)
join 
(
select  Quartile,count(distinct _platform_account_id) TK_purchasers,Sum(change_amount) Total_TK_purchased
from seven11_prod.seven11_resource_flow a
join Quartiles b
on a._platform_account_id = b.player_id
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source = 'ENTITLEMENT'
and date(_event_time_utc) between '2019-04-22'  and '2020-04-18' 
group by 1) c
using(quartile)
order by 1 ;


----Game mode distribution --Quartiles

with Quartiles as (
select player_id, 
	  case when cumsumplayers >= 0.75 then 'Q4'
		   when cumsumplayers >= 0.5 then 'Q3'
		   when cumsumplayers >= 0.25 then 'Q2' 
		   else 'Q1' end as Quartile 
from
(
select player_id, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select player_id, sum(total_hours) hrsplayed, sum(hrsplayed) over () totaltime,  sum(total_hours::float) / sum(hrsplayed) over () perc, 1::float / count(player_id) over ()  cum_players
		from seven11_prod_da.wba_player_daily
		where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
		group by 1
		having hrsplayed > 0.5 and hrsplayed <= 500
	)
)
group by 1,2
having Quartile is not NULL
)

select case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode,Quartile ,sum(activity_hours) Total_Hours
from seven11_prod_da.wba_fact_activity
join Quartiles b
using(player_id)
where date(event_dt) BETWEEN '2019-04-22' and  '2020-04-18' 
and activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1,2
order by 2,1;


---MVP---kpis

with Quartiles as (
select player_id, 
	  case when cumsumplayers >= 0.9 then 'Top 10%'----------------cumsumplayers >= 0.95 then 'Top 5%'
		   else NULL end as perc
from
(
select player_id, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select player_id, sum(total_hours) hrsplayed, sum(hrsplayed) over () totaltime,  sum(total_hours::float) / sum(hrsplayed) over () perc, 1::float / count(player_id) over ()  cum_players
		from seven11_prod_da.wba_player_daily
		where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
		group by 1
		having hrsplayed > 0.5 and hrsplayed <= 500
	)
)
group by 1,2
having perc is not NULL
)

Select a.*,KP_owners,TK_purchasers,Total_TK_purchased
from(
select perc,min(hrsplayed) Min_hrs,max(hrsplayed) Max_hrs,Avg(hrsplayed) Avg_hrs,Median(hrsplayed) Median_hrs,
count(player_id) Players,Avg(sessions) sessions_per_player,Sum(sessions)/Sum(days_played) Session_per_player_per_day,
Sum(hrsplayed)/Sum(days_played) Hrs_per_player_per_day,AVg(days_played) Avg_days_played 
from(
	select player_id,perc,sum(session_count)::float sessions, count(distinct date(event_dt)) days_played,
	sum(total_hours) hrsplayed
    from seven11_prod_da.wba_player_daily 
	join Quartiles
	using(player_id)	
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
	group by 1,2
	) 
group by 1) a
join 
(
select perc,count(distinct _platform_account_id) KP_owners
from seven11_prod.seven11_dlc_entitlement a
join Quartiles b
on a._platform_account_id = b.player_id
where entitlement_name in ('kombat_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) between '2019-04-22'  and '2020-04-18' 
group by 1 ) b
using(perc)
join 
(
select  perc,count(distinct _platform_account_id) TK_purchasers,Sum(change_amount) Total_TK_purchased
from seven11_prod.seven11_resource_flow a
join Quartiles b
on a._platform_account_id = b.player_id
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source = 'ENTITLEMENT'
and date(_event_time_utc) between '2019-04-22'  and '2020-04-18' 
group by 1) c
using(perc) ;

----Game mode distribution ---MVP

with Quartiles as (
select player_id, 
	  case when cumsumplayers >= 0.95 then 'Top 5%'--------------cumsumplayers >= 0.9 then 'Top 10%'
		   else NULL end as perc
from
(
select player_id, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select player_id, sum(total_hours) hrsplayed, sum(hrsplayed) over () totaltime,  sum(total_hours::float) / sum(hrsplayed) over () perc, 1::float / count(player_id) over ()  cum_players
		from seven11_prod_da.wba_player_daily
		where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
		group by 1
		having hrsplayed > 0.5 and hrsplayed <= 500
	)
)
group by 1,2
having perc is not NULL
)

select case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode,perc ,sum(activity_hours) Total_Hours
from seven11_prod_da.wba_fact_activity
join Quartiles b
using(player_id)
where date(event_dt) BETWEEN '2019-04-22' and  '2020-04-18' 
and activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1,2
order by 2,1;

-------Country wise players ---Platform level
select platform, country_name, count(distinct Player_id) Players
from seven11_prod_da.wba_player_daily
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
group by 1,2
having country_name is not NULL
order by 1,2 ;

----Game mode distribution --Quartile 4 - Player journey

with Quartile_4 as (
select player_id, 
	  case when cumsumplayers >= 0.75 then 'Q4'
		   when cumsumplayers >= 0.5 then 'Q3'
		   when cumsumplayers >= 0.25 then 'Q2' 
		   else 'Q1' end as Quartile 
from
(
select player_id, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select player_id, sum(total_hours) hrsplayed, sum(hrsplayed) over () totaltime,  sum(total_hours::float) / sum(hrsplayed) over () perc, 1::float / count(player_id) over ()  cum_players
		from seven11_prod_da.wba_player_daily
		where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
		group by 1
		having hrsplayed > 0.5 and hrsplayed <= 500
	)
)
group by 1,2
having Quartile = 'Q4'
)


select case when Hours_Played <= 3 then 'Upto 3 hrs'
when Hours_Played <= 9 then '3 to 9 hrs'
when Hours_Played <= 27 then '9 to 27 hrs'
when Hours_Played > 27 then '27+ hrs' else NULL end as Time_Interval,
case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode,sum(activity_hours) Total_Hours
from(
Select _platform_account_id, _event_time_utc ,activity_name,activity_hours,
ceiling(sum(activity_hours)over(partition by _platform_account_id order by _event_time_utc asc rows unbounded preceding)) Hours_Played
from  seven11_prod.seven11_activity_end  ae join seven11_prod_da.wba_fact_activity fa 
on ae._activity_guid = fa.activity_guid and ae._platform_account_id=fa.player_id
where date(_event_time_utc)  BETWEEN '2019-04-22'  and '2020-04-18'
and player_id in (select player_id from Quartile_4)
and fa.activity_hours is not NULL and fa.activity_name is not NULL
and fa.activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF'))
group by 1,2 ;

-----Story players

select count(distinct Player_id), Sum(activity_hours)/count(distinct Player_id) Avg_hrs
from seven11_prod_da.wba_fact_activity
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
and activity_name in ('GM_STORY_OFF')
and activity_hours > 0 ;

----overall players

select count(distinct Player_id)
from seven11_prod_da.wba_fact_activity
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
and activity_hours > 0 ;

----Avg fights completed
Select Avg(Fights_completed) Avg_fights_completed
from(
 select _platform_account_id player_id, max(fight_number)::float Fights_completed
 from seven11_prod.seven11_progression_campaignprogress 
 where date(_event_time_utc) BETWEEN '2019-04-22'  and '2020-04-18'
 and player_win = 1
 group by 1) ;
 
----Story chapter completition rate
with players as
(select  Player_id
from seven11_prod_da.wba_fact_activity
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
and activity_name in ('GM_STORY_OFF')
and activity_hours > 0 
group by 1)


 Select case when Fights_completed = 50 then '12'
			 when Fights_completed >= 46 then '11'
			 when Fights_completed >= 41 then '10'
			 when Fights_completed >= 37 then '9'
		  	 when Fights_completed >= 32 then '8'
		   	 when Fights_completed >= 28 then '7'
			 when Fights_completed >= 24 then '6'
		 	 when Fights_completed >= 20 then '5'
			 when Fights_completed >= 16 then '4'
			 when Fights_completed >= 12 then '3'
	 		 when Fights_completed >= 8 then '2'
			 when Fights_completed >= 4 then '1'
else '0' end as chapters_completed, count(distinct player_id) players
 from(
 select _platform_account_id player_id, max(fight_number)::float Fights_completed
 from seven11_prod.seven11_progression_campaignprogress 
 where date(_event_time_utc) BETWEEN '2019-04-22'  and '2020-04-18'
 and player_win = 1 
 and _platform_account_id in (select Player_id from players)
 group by 1)
 group by 1
 order by 1 ;
 
 --------Language usage
 
 with players as(
	select player_id
	from seven11_prod_da.wba_fact_activity
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	group by 1)

Select text_language_name,count(distinct player_id) players_using
from seven11_prod_da.wba_dim_player
join players
using(player_id) 
group by 1
order by 2 desc;

--------Player Age distribution

 with players as(
	select player_id
	from seven11_prod_da.wba_fact_activity
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	group by 1)

Select age,count(distinct _platform_account_id) players
from seven11_prod.seven11_profile_etldata
where _platform_account_id in (select * from players)
group by 1 
order by 1
 ;

------TK Revenue Distribution  ----
With players as (
select player_id
from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES
where premiumcurrency >= 50000
group by 1
) 

select CEILING (LTD/2)*2 LTD, count(_platform_account_id) Players, sum(LTD) rev
from
	(
	select _platform_account_id, sum(change_amount)*.0062 LTD
	from seven11_prod.seven11_resource_flow
	where resource = 'Exp_PremiumCurrency' and change_amount > 0 and source = 'ENTITLEMENT' 
	and date(_event_time_utc) between '2019-04-22'  and '2020-04-18'  
	 and _platform_account_id not in (select * from players)
	group by 1 
)
group by 1
order by ltd ;


------ Days since install vs TK Revenue----------

With players as (
select player_id
from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES
where premiumcurrency >= 50000
group by 1
) 

select 	period,Sum(LTD) Rev
from(
	select a._platform_account_id,case when install_dt < '2019-04-22' then '2019-04-22' else install_dt end as join_date,
	DATE(_event_time_utc) transactiondate,datediff(DAY,join_date ,DATE(_event_time_utc) ) period,
	sum(change_amount)*.0062 LTD
	from seven11_prod.seven11_resource_flow a
	join seven11_prod_da.wba_dim_player b on a._platform_account_id = b.player_id
	where resource = 'Exp_PremiumCurrency' and change_amount > 0 and source = 'ENTITLEMENT' 
	and date(_event_time_utc) between '2019-04-22'  and '2020-04-18'  
	 and _platform_account_id not in (select * from players)
	group by 1,2,3,4
	)
group by 1
having period >= 0
order by 1 ;

----Game mode distribution participation

Select Game_mode,count(distinct Player_id) players
from(
select case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode,player_id,sum(activity_hours) GM_Hours
from seven11_prod_da.wba_fact_activity
where date(event_dt) BETWEEN '2019-04-22' and  '2020-04-18' 
and activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1,2)
where GM_hours > 0.25
group by 1
order by 1;

----KL players

select count(distinct _platform_account_id) KL_players
from seven11_prod.seven11_match_result_player
where match_season like ('ranked-_') and ai_difficulty= -1 and date(wbanalyticssourcedate) >= '2019-04-22'
;

----KL engagement Overall
Select Avg(KL_Hrs),Avg(KL_matches)
from(
select _platform_account_id,
Sum(match_length)::float/3600 KL_Hrs,
count(distinct match_id)::float KL_matches
from seven11_prod.seven11_match_result_player
where match_season like ('ranked-_') and ai_difficulty= -1 and date(wbanalyticssourcedate) >= '2019-04-22'
group by 1)
;

----KL engagement per season
Select Avg(KL_Hrs) Avg_KL_hrs_per_season,Avg(KL_matches) Avg_KL_matches_per_season
from(
select match_season,_platform_account_id,
Sum(match_length)::float/3600 KL_Hrs,
count(distinct match_id)::float KL_matches
from seven11_prod.seven11_match_result_player
where match_season like ('ranked-_') and ai_difficulty= -1 and date(wbanalyticssourcedate) >= '2019-04-22'
group by 1,2)
;


-----DAU by Platform
    select date(event_dt),platform,count(distinct player_id) DAU
	from seven11_prod_da.wba_player_daily a
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	group by 1,2
	order by 1,2 ;
	
------Daily New Players by Platform
     select install_dt,platform,count(distinct player_id) New_players
	 from(
	 select player_id,platform,min(date(event_dt)) install_dt
              from seven11_prod_da.wba_player_daily a
			  where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	group by 1,2)
	group by 1,2
	order by 1,2 ;
	

-----ToT players

select Sum(activity_hours)/count(distinct Player_id) Avg_hrs
from seven11_prod_da.wba_fact_activity
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
and activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') 
and activity_hours > 0 ;
 
 ----Retention by Platform
 with datedim as ( select event_dt YearMonthDay from seven11_prod_da.wba_fact_activity group by 1)


            select period,b.platform,  count(c.player_id) retained_players, count(b.player_id) cohorts
            from
            (
              SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
                FROM datedim d
                JOIN datedim  d2 ON d.YearMonthDay < d2.YearMonthDay
                WHERE  (d.YearMonthDay>='2019-04-22' and d.YearMonthDay < '2020-04-22')
                AND (d2.YearMonthDay>='2019-04-22' and  d2.YearMonthDay < '2020-04-22')
            ) A
            join
            (

              select player_id,platform, min(date(event_dt)) yearmonthday
              from seven11_prod_da.wba_player_daily
			  where date(event_dt) between '2019-04-22' and '2020-04-22'
              group by 1,2

            )  B
            on a.NewDate = b.yearmonthday
            left join
            (

              select date(event_dt) yearmonthday, player_id,platform
              from seven11_prod_da.wba_player_daily a
              group by 1,2,3

            ) C
            on b.player_id = c.player_id
            and c.yearmonthday = a.retentiondate
            where b.yearmonthday >= '2019-04-22'
            group by 1,2
          order by 2,1 asc
  ;
  
  -----MK11 Retention
   with datedim as ( select event_dt YearMonthDay from seven11_prod_da.wba_fact_activity group by 1)


            select period,  count(c.player_id) retained_players, count(b.player_id) cohorts
            from
            (
              SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
                FROM datedim d
                JOIN datedim  d2 ON d.YearMonthDay < d2.YearMonthDay
                WHERE  (d.YearMonthDay>='2019-04-22' and d.YearMonthDay < '2020-04-22')
                AND (d2.YearMonthDay>='2019-04-22' and  d2.YearMonthDay < '2020-04-22')
            ) A
            join
            (

              select player_id, min(date(event_dt)) yearmonthday
              from seven11_prod_da.wba_player_daily
			  where date(event_dt) between '2019-04-22' and '2020-04-22'
              group by 1

            )  B
            on a.NewDate = b.yearmonthday
            left join
            (

              select date(event_dt) yearmonthday, player_id
              from seven11_prod_da.wba_player_daily a
              group by 1,2

            ) C
            on b.player_id = c.player_id
            and c.yearmonthday = a.retentiondate
            where b.yearmonthday >= '2019-04-22'
            group by 1
          order by 1 asc
  ;


------IJ 2 Retention 


select period,  count(c.platform_account_id) retained_players, count(b.platform_account_id) cohorts
from
(
    SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
            select wbanalyticsprocessingdate YearMonthDay
            from pachinko_prod.pachinko_activitysession_begin
            where wbanalyticsprocessingdate  between '2017-05-15 00:00:00' and  '2018-05-15 00:00:00'
            group by 1
         ) d 
    JOIN (
            select wbanalyticsprocessingdate YearMonthDay
            from pachinko_prod.pachinko_activitysession_begin
            where wbanalyticsprocessingdate between '2017-05-15 00:00:00' and  '2018-05-15 00:00:00'
            group by 1
         ) d2 
    ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2017-05-15 00:00:00' and d.YearMonthDay < '2018-05-15 00:00:00')
    AND (d2.YearMonthDay>='2017-05-15 00:00:00' and  d2.YearMonthDay < '2018-05-15 00:00:00')
    order by 1,2
) A
join 
(
    select platform_account_id, min(wbanalyticsprocessingdate) yearmonthday
    from pachinko_prod.pachinko_match_matchresult a 
    where wbanalyticsprocessingdate between '2017-05-15 00:00:00' and  '2018-05-15 00:00:00'
    group by 1


)  B
on a.joinDate = b.yearmonthday 
left join
(

    select wbanalyticsprocessingdate yearmonthday, platform_account_id
    from pachinko_prod.pachinko_match_matchresult a 
    where wbanalyticsprocessingdate between '2017-05-15 00:00:00' and  '2018-05-15 00:00:00'
    group by 1,2

) C
on b.platform_account_id = c.platform_account_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2017-05-15 00:00:00'
group by 1
order by 1 ;

------Players by Platform
     select platform,count(distinct player_id) players
	 from(
	 select player_id,platform,min(date(event_dt)) install_dt
     from seven11_prod_da.wba_player_daily a
	 where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	group by 1,2)
	group by 1
	order by 1;
	
------KP owners

with platforms as(
	 select player_id,platform
     from seven11_prod_da.wba_player_daily a
	 where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	group by 1,2
	)

select platform,count(distinct _platform_account_id) KP_owners
from seven11_prod.seven11_dlc_entitlement a
join platforms b
on a._platform_account_id = b.player_id
where entitlement_name in ('kombat_pack')
and date(_event_time_utc) between '2019-04-22'  and '2020-04-18' 
group by 1
order by 1 ;

-----Overall KP owners

select count(distinct _platform_account_id) KP_owners
from seven11_prod.seven11_dlc_entitlement a
where entitlement_name in ('kombat_pack')
and date(_event_time_utc) between '2019-04-22'  and '2020-04-18' 
;

-------Country wise players  Kpis

with country as(
select case when country_name in ('United States','Russia','Brazil','United Kingdom','Mexico','Canada') 
then country_name else 'Others' end as Country,Player_id
from seven11_prod_da.wba_player_daily
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
and country_name is not NULL
group by 1,2)


Select a.*,KP_owners,TK_purchasers,Total_TK_purchased
from(
select Country,count(player_id) Players,min(hrsplayed) Min_hrs,max(hrsplayed) Max_hrs,Avg(hrsplayed) Avg_hrs,
Median(hrsplayed) Median_hrs,Sum(hrsplayed)/Sum(days_played) Hours_per_player_per_day,
Avg(sessions) sessions_per_player,Sum(sessions)/Sum(days_played) Session_per_player_per_day,
AVg(days_played) Avg_days_played
from(
	select player_id,country,sum(session_count)::float sessions, count(distinct date(event_dt)) days_played,
	sum(total_hours) hrsplayed
    from seven11_prod_da.wba_player_daily 
	join Country
	using(player_id)	
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
	group by 1,2
	) 
group by 1) a
join 
(
select Country,count(distinct _platform_account_id) KP_owners
from seven11_prod.seven11_dlc_entitlement a
join country b
on a._platform_account_id = b.player_id
where entitlement_name in ('kombat_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) between '2019-04-22'  and '2020-04-18' 
group by 1 ) b
using(country)
join 
(
select  Country,count(distinct _platform_account_id) TK_purchasers,Sum(change_amount) Total_TK_purchased
from seven11_prod.seven11_resource_flow a
join Country b
on a._platform_account_id = b.player_id
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source = 'ENTITLEMENT'
and date(_event_time_utc) between '2019-04-22'  and '2020-04-18' 
group by 1) c
using(country)
order by 1 ;

-------Overall players  Kpis

Select a.*,KP_owners,TK_purchasers,Total_TK_purchased
from(
select count(player_id) Players,min(hrsplayed) Min_hrs,max(hrsplayed) Max_hrs,Avg(hrsplayed) Avg_hrs,
Median(hrsplayed) Median_hrs,Sum(hrsplayed)/Sum(days_played) Hours_per_player_per_day,
Avg(sessions) sessions_per_player,Sum(sessions)/Sum(days_played) Session_per_player_per_day,
AVg(days_played) Avg_days_played
from(
	select player_id,sum(session_count)::float sessions, count(distinct date(event_dt)) days_played,
	sum(total_hours) hrsplayed
    from seven11_prod_da.wba_player_daily 
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
	group by 1
	) 
) a
cross join 
(
select count(distinct _platform_account_id) KP_owners
from seven11_prod.seven11_dlc_entitlement 
where entitlement_name in ('kombat_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) between '2019-04-22'  and '2020-04-18' 
 ) b
cross join 
(
select  count(distinct _platform_account_id) TK_purchasers,Sum(change_amount) Total_TK_purchased
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source = 'ENTITLEMENT'
and date(_event_time_utc) between '2019-04-22'  and '2020-04-18' 
) c
;

------Country wise Retention

with MK11_retention as (

with country as(
select case when country_name in ('United States','Russia','Brazil','United Kingdom','Mexico','Canada') 
then country_name else 'Others' end as Country,Player_id
from seven11_prod_da.wba_player_daily
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
and country_name is not NULL
group by 1,2) ,
 datedim as ( select date(event_dt) YearMonthDay from seven11_prod_da.wba_fact_activity group by 1)

            select period,b.country, RetentionDate, newdate, count(c.player_id) retained_players, count(b.player_id) cohorts
            from
            (
              SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
                FROM datedim d
                JOIN datedim  d2 ON d.YearMonthDay < d2.YearMonthDay
                WHERE  (d.YearMonthDay>='2019-04-22' and d.YearMonthDay < '2020-04-19')
                AND (d2.YearMonthDay>='2019-04-22' and  d2.YearMonthDay < '2020-04-19')
            ) A
            join
            (

              select player_id,country, min(date(event_dt)) yearmonthday
              from seven11_prod_da.wba_player_daily a
			  join Country
			  using(player_id)
        	  where date(event_dt) >= '2019-04-22' and date(event_dt) < '2020-04-19'
              group by 1,2

            )  B
            on a.NewDate = b.yearmonthday
            left join
            (

              select date(event_dt) yearmonthday, player_id,country
              from seven11_prod_da.wba_player_daily a
			  join Country
			  using(player_id)
			  where date(event_dt) >= '2019-04-22' and date(event_dt) < '2020-04-19'
              group by 1,2,3

            ) C
            on b.player_id = c.player_id
            and c.yearmonthday = a.retentiondate
            where b.yearmonthday >= '2019-04-22'
            group by 1,2,3,4
)


    select period,Country, sum(retained_players::float) / sum(cohorts::float) Retention
    from MK11_retention
    where period in (1,7,15,30,60,90)
    group by 1,2
	order by 2,1  ;
	
------Game Retention
	
with MK11_retention as (
 with datedim as ( select date(event_dt) YearMonthDay from seven11_prod_da.wba_fact_activity group by 1)

            select period, RetentionDate, newdate, count(c.player_id) retained_players, count(b.player_id) cohorts
            from
            (
              SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
                FROM datedim d
                JOIN datedim  d2 ON d.YearMonthDay < d2.YearMonthDay
                WHERE  (d.YearMonthDay>='2019-04-22' and d.YearMonthDay < '2020-04-19')
                AND (d2.YearMonthDay>='2019-04-22' and  d2.YearMonthDay < '2020-04-19')
            ) A
            join
            (

              select player_id, min(date(event_dt)) yearmonthday
              from seven11_prod_da.wba_player_daily a
        	  where date(event_dt) >= '2019-04-22' and date(event_dt) < '2020-04-19'
              group by 1

            )  B
            on a.NewDate = b.yearmonthday
            left join
            (

              select date(event_dt) yearmonthday, player_id
              from seven11_prod_da.wba_player_daily a
			  where date(event_dt) >= '2019-04-22' and date(event_dt) < '2020-04-19'
              group by 1,2

            ) C
            on b.player_id = c.player_id
            and c.yearmonthday = a.retentiondate
            where b.yearmonthday >= '2019-04-22'
            group by 1,2,3
)


    select period, sum(retained_players::float) / sum(cohorts::float) Retention
    from MK11_retention
    where period in (1,7,15,30,60,90)
    group by 1
	order by 2 ;
	
------Days Since install Vs Game mode distribution
with Join_date as(
	 select player_id,min(date(event_dt)) install_dt
     from seven11_prod_da.wba_player_daily a
	 where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	group by 1)
	
select case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode ,datediff(DAY,install_dt, DATE(event_dt)) period,sum(activity_hours) Total_Hours
from seven11_prod_da.wba_fact_activity
join join_date
using(player_id)
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18'
and activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1,2
having period >= 0
order by 2,1;

----Mk11 Month Over Month Return rate

with MAU as(
	select ((((datepart(year,date(event_dt)))-2019)*12)+((datepart(month,date(event_dt)))-3)) Mon,player_id
	from seven11_prod_da.wba_player_daily a
	where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
	group by 1,2
	)
	
Select Mon,(((datepart(year,date(event_dt)))-2019)*12)+((datepart(month,date(event_dt)))-3) next_mon,Count(distinct Player_id) Returning
from seven11_prod_da.wba_player_daily
join MAU
using(player_id)
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-18' 
group by 1,2
having ((((datepart(year,date(event_dt)))-2019)*12)+((datepart(month,date(event_dt)))-3))-Mon =1
order by 1
;

----Ij 2 MAU


	select ((((datepart(year,date(eventtimestamp)))-2017)*12)+((datepart(month,date(eventtimestamp)))-4)) Mon,
	count(distinct platform_account_id) MAU
	from pachinko_prod.pachinko_activitysession_begin 
	where DATE(eventtimestamp)  BETWEEN '2017-05-15'  and '2018-05-14' 
	group by 1
	order by 1
;
----Ij 2 Month Over Month Return rate

with MAU as(
	select ((((datepart(year,date(eventtimestamp)))-2017)*12)+((datepart(month,date(eventtimestamp)))-4)) Mon,platform_account_id
	from pachinko_prod.pachinko_activitysession_begin 
	where DATE(eventtimestamp)  BETWEEN '2017-05-15'  and '2018-05-14' 
	group by 1,2
	)

Select Mon,((((datepart(year,date(eventtimestamp)))-2017)*12)+((datepart(month,date(eventtimestamp)))-4)) next_mon,
Count(distinct platform_account_id) Returning
from pachinko_prod.pachinko_activitysession_begin 
join MAU
using(platform_account_id)
where DATE(eventtimestamp)  BETWEEN '2017-05-15'  and '2018-05-14' 
group by 1,2
having ((((datepart(year,date(eventtimestamp)))-2017)*12)+((datepart(month,date(eventtimestamp)))-4)) -Mon =1
order by 1

;

------MK11 Game mode wise daily Retention
With game_modes as(
select case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode ,date(event_dt) play_dt,player_id
from seven11_prod_da.wba_fact_activity
where DATE(event_dt) BETWEEN '2019-04-22'  and '2020-04-19'
and activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1,2,3
),
 datedim as ( select date(event_dt) YearMonthDay from seven11_prod_da.wba_fact_activity group by 1),

Game_mode_retention as(
            select b.Game_mode,period, RetentionDate, newdate, count(c.player_id) retained_players, count(b.player_id) cohorts
            from
            (
            SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
                FROM datedim d
                JOIN datedim  d2 ON d.YearMonthDay < d2.YearMonthDay
                WHERE  (d.YearMonthDay>='2019-04-22' and d.YearMonthDay < '2020-04-19')
                AND (d2.YearMonthDay>='2019-04-22' and  d2.YearMonthDay < '2020-04-19')) A
            join
            (

              select player_id,Game_mode, min(date(play_dt)) yearmonthday
              from game_modes a
			  group by 1,2
            )  B
            on a.NewDate = b.yearmonthday
            left join
            (

              select date(play_dt) yearmonthday, player_id,Game_mode
              from game_modes a
			  group by 1,2,3
            ) C
            on b.player_id = c.player_id
            and c.yearmonthday = a.retentiondate
            where b.yearmonthday >= '2019-04-22'
            group by 1,2,3,4
	 )
			
    select period,Game_mode,Sum(retained_players)::float/Sum(Cohorts)
    from Game_mode_retention
    where period in (1,15,30,60,90)
    group by 1,2
	order by 1,2 ;
	
---IJ2 LTD time Played
select  (sum(totaldurationminutes::float))/(60*count(distinct platformaccountid)) ltd_hrs
from pachinko_prod_da.factactivity 
where DATE(starttimestamp)  BETWEEN '2017-05-14' and '2018-05-13'  ;

