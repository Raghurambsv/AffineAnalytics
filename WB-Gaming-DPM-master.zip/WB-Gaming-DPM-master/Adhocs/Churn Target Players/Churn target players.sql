-----Players with churn > 0.9

Select date(inserted_ts) dt,count(distinct user_id) players
from seven11_prod_da.wba_score_churn
where churn_score > 0.9 
group by 1 ;

-------Players with SCORPION as Top 3 and Top 5 Kombatants

with churn_score as(
Select date(inserted_ts) dt,user_id
from seven11_prod_da.wba_score_churn
where churn_score > 0.9 
group by 1,2)

Select dt,count(distinct _platform_account_id) players,Sum(Top_3) Top_3_players,Sum(Top_5) Top_5_players
from(
Select _platform_account_id,dt,case when kombatant_Rank between 1 and 3 then 1 else 0 end as Top_3,
case when kombatant_Rank between 1 and 5 then 1 else 0 end as Top_5
from(
Select _platform_account_id,dt,Kombatant,max(cum_times) total_times_played, 
Rank() over(partition by _platform_account_id,dt order by total_times_played desc) Kombatant_Rank
from(
Select _platform_account_id,play_dt,dt,Kombatant,
Sum(times_used)over(partition by _platform_account_id,dt order by play_dt asc rows unbounded preceding) cum_times
from(
Select _platform_account_id,date(_event_time_utc) play_dt,dt,Character Kombatant,count(*) times_used
from seven11_prod.seven11_match_result_player
join churn_score
on _platform_account_id= user_id and  date(_event_time_utc) <= dt
where ai_difficulty =-1 and date(wbanalyticssourcedate) >= '2019-04-22'
group by 1,2,3,4))
group by 1,2,3)
where Kombatant = 'char_scorpion')
group by 1
;
-------Players with SKARLET as Top 3 and Top 5 Kombatants

with churn_score as(
Select date(inserted_ts) dt,user_id
from seven11_prod_da.wba_score_churn
where churn_score > 0.9 
group by 1,2)

Select dt,count(distinct _platform_account_id) players,Sum(Top_3) Top_3_players,Sum(Top_5) Top_5_players
from(
Select _platform_account_id,dt,case when kombatant_Rank between 1 and 3 then 1 else 0 end as Top_3,
case when kombatant_Rank between 1 and 5 then 1 else 0 end as Top_5
from(
Select _platform_account_id,dt,Kombatant,max(cum_times) total_times_played, 
Rank() over(partition by _platform_account_id,dt order by total_times_played desc) Kombatant_Rank
from(
Select _platform_account_id,play_dt,dt,Kombatant,
Sum(times_used)over(partition by _platform_account_id,dt order by play_dt asc rows unbounded preceding) cum_times
from(
Select _platform_account_id,date(_event_time_utc) play_dt,dt,Character Kombatant,count(*) times_used
from seven11_prod.seven11_match_result_player
join churn_score
on _platform_account_id= user_id and  date(_event_time_utc) <= dt
where ai_difficulty =-1 and date(wbanalyticssourcedate) >= '2019-04-22'
group by 1,2,3,4))
group by 1,2,3)
where Kombatant = 'char_skarlet')
group by 1
;
