with players as 
	(
		select player_id, min(event_dt) install_date
		from seven11_prod_da.wba_player_daily
		where event_dt >= '2019-04-22'--- and '2019-05-05'
		--		and player_id = '4171125453549405522'
		group by 1
	)


select activity_name, num, install_date, sum(player_win) wins, count(match_id) matches, count(_platform_account_id) players
from
	(
		select a._platform_account_id, activity_name, match_id,install_date, max(player_win) player_win, min(wbanalyticssourcedate) time_stamp, row_number() over (partition by _platform_account_id, activity_name order by time_stamp asc ) num 
		from seven11_prod.seven11_match_result_player a
		join (select match_id from seven11_prod.seven11_onlinempmatch_matchbegin group by 1)
		using(match_id)
		join players c
		on a._platform_account_id = c.player_id
	    where ai_difficulty =-1
	    and date(wbanalyticssourcedate) >='2019-04-22'
		--and _platform_account_id = '4171125453549405522'
		group by 1,2,3,4
	)
where num <= 15
group by 1,2,3

---- Online PvP Retention vs Win Loss Ratio--------------
with players as 
	(
		select player_id, min(event_dt) install_date
		from seven11_prod_da.wba_player_daily
		where event_dt between '2019-04-22' and '2019-05-05'
		--		and player_id = '4171125453549405522'
		group by 1
	),

	Online_days_as as
	(
		select 	_platform_account_id, COALESCE(count(distinct match_id ), 0) as matches,
	    COALESCE(SUM(player_win), 0) as wins,
		COALESCE((wins::float / matches::float)*100,0) win_perc,
		COALESCE((floor(win_perc/ 10 ))*10,0) bucket
		from
			(
				select a._platform_account_id, match_id, max(player_win) player_win, min(wbanalyticssourcedate) time_stamp, row_number() over (partition by _platform_account_id order by time_stamp asc ) num 
				from seven11_prod.seven11_match_result_player a
				join (select match_id from seven11_prod.seven11_onlinempmatch_matchbegin group by 1)
				using(match_id)
				join players c
				on a._platform_account_id = c.player_id
			    where ai_difficulty =-1
			    and date(wbanalyticssourcedate) >='2019-04-22'
				--and _platform_account_id = '4171125453549405522'
				group by 1,2
			)
		--where num between 3 and 10
		group by 1
	),
	
		
create table sandbox.online_winliss as
	(
		select 	_platform_account_id, COALESCE(count(distinct match_id ), 0) as matches,
	    COALESCE(SUM(player_win), 0) as wins,
		COALESCE((wins::float / matches::float)*100,0) win_perc,
		COALESCE((floor(win_perc/ 10 ))*10,0) bucket
		from
			(
				select a._platform_account_id, match_id, max(player_win) player_win, min(wbanalyticssourcedate) time_stamp, row_number() over (partition by _platform_account_id order by time_stamp asc ) num , count(match_id) over (partition by _platform_account_id) le
				from seven11_prod.seven11_match_result_player a
				--join (select match_id from seven11_prod.seven11_onlinempmatch_matchbegin group by 1)
				--using(match_id)
				join sandbox.early_players c
				on a._platform_account_id = c.player_id
			    where ai_difficulty =-1
			    and date(wbanalyticssourcedate) >='2019-04-22'
				and activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1')
				--and _platform_account_id = '4171125453549405522'
				group by 1,2
			)
		where num between 3 and 10
		and le>=10
		group by 1
	)
	
	
	with dummy as 
	(
		select *
		from 
		(
		SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
	    FROM 		(
					select event_dt YearMonthDay
					from seven11_prod_da.wba_player_daily
					where event_dt >='2019-04-22'
					group by 1
					) d 
	    JOIN 		(
					select event_dt YearMonthDay
					from seven11_prod_da.wba_player_daily
					where event_dt >='2019-04-22'
					group by 1
					) d2 
		ON d.YearMonthDay < d2.YearMonthDay
	    WHERE  (d.YearMonthDay>='2019-04-22' and d.YearMonthDay<='2019-05-05' )
	    AND (d2.YearMonthDay>='2019-04-22')
		) a
		cross join(
		select 0 as WinPercentile
		union 
		select 10
		union
		select 20
		union 
		select 30
		union 
		select 40
		union 
		select 50
		union 
		select 60
		union
		select 70
		union
		select 80
		union
		select 90
		union
		select 100 
		) b
	)

	
select period, newdate, a.WinPercentile, count(c._platform_account_id) retained_players, count(b._platform_account_id) cohorts
from dummy a
join ( select _platform_account_id,bucket, install_date 
	   from sandbox.early_players a
	   join sandbox.online_winliss b
	   on a.player_id = b._platform_account_id
	  ) b
on a.NewDate = b.install_date 
and a.WinPercentile = b.bucket
left join
(

	select date(wbanalyticssourcedate) yearmonthday, _platform_account_id
	from seven11_prod.seven11_onlinempmatch_matchbegin a 
	group by 1,2
) C
on b._platform_account_id = c._platform_account_id
and c.yearmonthday = a.retentiondate
group by 1,2,3
order by 2,3,1	

