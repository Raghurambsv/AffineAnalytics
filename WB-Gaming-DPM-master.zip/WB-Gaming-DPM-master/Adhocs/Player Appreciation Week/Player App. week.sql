---------Tower Engagement for Monday Towers
Select a.Date,
  a.Tower_id,
  COALESCE(a.Tower_Level,0) Tower_Level,
  COALESCE(a.Players,0) Players, ----use in completion rate%
  COALESCE(a.TimePlayed,0) TimePlayed,
  COALESCE(a.matches,0) matches,   -----match win rate
  COALESCE(a.wins,0) wins,         -----match win rate  
  COALESCE(a.rounds,0) rounds,
  COALESCE(a.Attempts,0) Attempts,
  COALESCE(a.Deaths,0) Deaths,
  COALESCE(a.Completed_Players,0) Completed_Players, ----use in completion rate%
  COALESCE(a.Completed_Players_TimePlayed,0) Completed_Players_TimePlayed,
  COALESCE(a.Completed_Players_Attempts,0) Completed_Players_Attempts,
  COALESCE(a.DAU,0) DAU,                 -----------engagement
  COALESCE(a.TowerPlayers,0) TowerPlayers,
  COALESCE(a.CompletedPlayers1Tower,0) CompletedPlayers1Tower,
  COALESCE(a.TowerPlayers_XTutorial,0) TowerPlayers_XTutorial,                -----------engagement% of dau,tower players
  COALESCE(a.CompletedPlayers_XTutorial,0) CompletedPlayers_XTutorial         -----------engagement% of dau
  from seven11_prod_da.tower_engagement a
  where tower_id in ('TagBoss_KIT_JAD_TagBoss_KIT_JAD','TagBoss_KUN_LIU_TagBoss_KUN_LIU'
	,'TagBoss_JAC_JAX_TagBoss_JAC_JAX','TagBoss_SKA_SHA_TagBoss_SKA_SHA','TagBoss_KAN_KAB_TagBoss_KAN_KAB'
	,'TagBoss_SUB_SCO_TagBoss_SUB_SCO','TagBoss_JOH_SON_TagBoss_JOH_SON')
	and Date in ('09/09/2019','09/10/2019')
  order by 1,2 DESC

---------Tower Engagement for Tuesday Towers
Select a.Date,
  a.Tower_id,
  COALESCE(a.Tower_Level,0) Tower_Level,
  COALESCE(a.Players,0) Players, ----use in completion rate%
  COALESCE(a.TimePlayed,0) TimePlayed,
  COALESCE(a.matches,0) matches,   -----match win rate
  COALESCE(a.wins,0) wins,         -----match win rate  
  COALESCE(a.rounds,0) rounds,
  COALESCE(a.Attempts,0) Attempts,
  COALESCE(a.Deaths,0) Deaths,
  COALESCE(a.Completed_Players,0) Completed_Players, ----use in completion rate%
  COALESCE(a.Completed_Players_TimePlayed,0) Completed_Players_TimePlayed,
  COALESCE(a.Completed_Players_Attempts,0) Completed_Players_Attempts,
  COALESCE(a.DAU,0) DAU,                 -----------engagement
  COALESCE(a.TowerPlayers,0) TowerPlayers,
  COALESCE(a.CompletedPlayers1Tower,0) CompletedPlayers1Tower,
  COALESCE(a.TowerPlayers_XTutorial,0) TowerPlayers_XTutorial,                -----------engagement% of dau,tower players
  COALESCE(a.CompletedPlayers_XTutorial,0) CompletedPlayers_XTutorial         -----------engagement% of dau
  from seven11_prod_da.tower_engagement a
  where tower_id in ('EndureBoss4_EndureBoss4','EndureBoss5_EndureBoss5','EndureBoss2_EndureBoss2',
	'EndureBoss8_EndureBoss8','EndureBoss6_EndureBoss6','BarakaBoss1_BarakaBoss1','JadeBoss1_JadeBoss1'
	,'DVorahBoss1_DVorahBoss1','CetrionBoss1_CetrionBoss1','JacquiBoss1_JacquiBoss1','CassieBoss1_CassieBoss1'
	,'NightwolfBoss1Fight_NightwolfBoss1')
	and Date in ('09/11/2019','09/10/2019')
  order by 1,2 DESC

--------Engagement KPIs for Monday Towers from Tower End 
select date, tower_id,count(distinct _platform_account_id) players, sum(Attempts) Attempts,
		sum(deaths) Deaths, sum(hrs_played) hrs_played,sum(sessions) Total_sessions, 
		sum(total_session_length)/sum(sessions) Avg_session_length, sum(completions) Total_Completed_Players
from
(
 	select _platform_account_id,wbanalyticssourcedate::DATE date, tower_id,
 		COUNT(DISTINCT _activity_guid)::float AS "Attempts", COALESCE(sum(number_deaths),0) ::float as deaths,
		sum(activity_session_time_s)::float/3600 as hrs_played,count(distinct _session_id)::float sessions,
		sum(activity_session_time_s)::float total_session_length, 
		COALESCE(sum(tower_completed),0) as completions
  	from seven11_prod.seven11_gameplay_towerend 
  	where  wbanalyticssourcedate::DATE in ('09/09/2019','09/10/2019') and
  	tower_id in ('TagBoss_KIT_JAD_TagBoss_KIT_JAD','TagBoss_KUN_LIU_TagBoss_KUN_LIU'
	,'TagBoss_JAC_JAX_TagBoss_JAC_JAX','TagBoss_SKA_SHA_TagBoss_SKA_SHA','TagBoss_KAN_KAB_TagBoss_KAN_KAB'
	,'TagBoss_SUB_SCO_TagBoss_SUB_SCO','TagBoss_JOH_SON_TagBoss_JOH_SON')
  	group by 1,2,3
)
group by 1,2

--------Engagement KPIs for Tuesday Towers from Tower End 
select date, tower_id,count(distinct _platform_account_id) players, sum(Attempts) Attempts,
		sum(deaths) Deaths, sum(hrs_played) hrs_played, sum(completions) Total_Completed_Players,
		sum(sessions) Total_sessions, sum(total_session_length)/sum(sessions) Avg_session_length
from
(
 	select _platform_account_id,wbanalyticssourcedate::DATE date, tower_id,
 		COUNT(DISTINCT _activity_guid)::float AS "Attempts", COALESCE(sum(number_deaths),0) ::float as deaths,
		sum(activity_session_time_s)::float/3600 as hrs_played,count(distinct _session_id)::float sessions,
		sum(activity_session_time_s)::float total_session_length, 
		COALESCE(sum(tower_completed),0) as completions
  	from seven11_prod.seven11_gameplay_towerend 
  	where  wbanalyticssourcedate::DATE in ('09/11/2019','09/10/2019') and
  	tower_id in ('EndureBoss4_EndureBoss4','EndureBoss5_EndureBoss5','EndureBoss2_EndureBoss2'
	,'EndureBoss8_EndureBoss8','EndureBoss6_EndureBoss6','BarakaBoss1_BarakaBoss1','JadeBoss1_JadeBoss1'
	,'DVorahBoss1_DVorahBoss1','CetrionBoss1_CetrionBoss1','JacquiBoss1_JacquiBoss1','CassieBoss1_CassieBoss1'
	,'NightwolfBoss1Fight_NightwolfBoss1')
  	group by 1,2,3
)
group by 1,2

-----Rewards for Monday Ladders
with players as(
	select distinct _platform_account_id
  	from seven11_prod.seven11_gameplay_towerend 
  	where  wbanalyticssourcedate::DATE in ('09/09/2019','09/10/2019') and
  	tower_id in ('TagBoss_KIT_JAD_TagBoss_KIT_JAD','TagBoss_KUN_LIU_TagBoss_KUN_LIU'
	,'TagBoss_JAC_JAX_TagBoss_JAC_JAX','TagBoss_SKA_SHA_TagBoss_SKA_SHA','TagBoss_KAN_KAB_TagBoss_KAN_KAB'
	,'TagBoss_SUB_SCO_TagBoss_SUB_SCO','TagBoss_JOH_SON_TagBoss_JOH_SON') and tower_completed = 1
)

select date(_event_time_utc) date, unlock_type, count(distinct _platform_account_id)
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-09-09','2019-09-10') AND unlock_source in ('LADDER_COMPLETED')
and _platform_account_id in (select * from players)
group by 1,2
order by 1,2

-----Rewards for Tuesday Ladders
with players as(
	select distinct _platform_account_id
  	from seven11_prod.seven11_gameplay_towerend 
  	where  wbanalyticssourcedate::DATE in ('09/11/2019','09/10/2019') and
  	tower_id in ('EndureBoss4_EndureBoss4','EndureBoss5_EndureBoss5','EndureBoss2_EndureBoss2'
	,'EndureBoss8_EndureBoss8','EndureBoss6_EndureBoss6','BarakaBoss1_BarakaBoss1','JadeBoss1_JadeBoss1'
	,'DVorahBoss1_DVorahBoss1','CetrionBoss1_CetrionBoss1','JacquiBoss1_JacquiBoss1','CassieBoss1_CassieBoss1'
	,'NightwolfBoss1Fight_NightwolfBoss1') and tower_completed = 1
)

select date(_event_time_utc) date, unlock_type, count(distinct _platform_account_id)
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) in ('2019-09-11','2019-09-10') AND unlock_source in ('PORTAL_QUEST_COMPLETED')
and _platform_account_id in (select * from players)
group by 1,2
order by 3 desc

-----Match engagement in towers
select date(wbanalyticssourcedate), count(distinct _platform_account_id) players, count(distinct match_id) matches,
	COALESCE(SUM(player_win), 0) as wins, COALESCE(SUM(rounds), 0) as rounds
from seven11_prod.seven11_match_result_player
where tower_id !=''  and ai_difficulty = -1-- and activity_name = 'GM_TOWERS_OF_TIME_LADDER'
and date(wbanalyticssourcedate) between '2019-09-02' and '2019-09-17'
--and tower_id in ('TagBoss_KIT_JAD_TagBoss_KIT_JAD','TagBoss_KUN_LIU_TagBoss_KUN_LIU'
--	,'TagBoss_JAC_JAX_TagBoss_JAC_JAX','TagBoss_SKA_SHA_TagBoss_SKA_SHA','TagBoss_KAN_KAB_TagBoss_KAN_KAB'
--	,'TagBoss_SUB_SCO_TagBoss_SUB_SCO','TagBoss_JOH_SON_TagBoss_JOH_SON')
group by 1


----new/returning/re-acquired/dau
select event_dt, sum(new_players) New_Players, sum(returning_players) Returning_Players
		, sum(reacquired_players) Reacquired_Players, sum(active_players) DAU
from seven11_prod_da.wba_daily_activity
where event_dt between '2019-09-02' and '2019-09-17'
group by 1
limit 5




