-------Total_Pints_of_blood,#ofPunishes,#of Krushing blows,matches,hours
Select Sum(total_blood_spilt) Total_Pints_of_blood,
Sum(mercy_actions) Number_of_mercies_given,
Sum(total_punishes) Number_of_Punishes,Sum(krushing_blows) Total_Krushing_blows,
Count(distinct match_id) Total_matches_played
from seven11_prod.seven11_match_result_player
where ai_difficulty =-1 and date(wbanalyticssourcedate) between '2019-04-22' and '2019-10-20' ;

----Total Hours Played
select Sum(total_hours)::float Hours
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-04-22' and '2019-10-20';

------Total_Respect_Points_Given
select Sum(respect_points) Total_Respect_Points_Given
from seven11_prod.seven11_ui_vote
where date(wbanalyticssourcedate) between '2019-04-22' and '2019-10-20' ;

-------# of Fatalities,brutalities,Quitalities
Select Finisher_used,Count(*)
from seven11_prod.seven11_match_result_player
where ai_difficulty =-1 and date(wbanalyticssourcedate) between '2019-04-22' and '2019-10-20'
group by 1;
 
-------Kombatant with most Fatalities performed on them
Select character Kombatant,Count(finisher_used) total
from seven11_prod.seven11_match_result_player
where finisher_used = 'fatality'
and ai_difficulty =-1 and date(wbanalyticssourcedate) between '2019-04-22' and '2019-10-20' 
group by 1;

-------Top 3 Kombatants used,Kombatant with most wins
Select Character Kombatant,count(*) total_times_used,Sum(Player_win) Wins
from seven11_prod.seven11_match_result_player
where ai_difficulty =-1 and date(wbanalyticssourcedate) between '2019-04-22' and '2019-10-20' 
group by 1
order by 2 ;

-------Top 3 Kombatants used,Kombatant with most wins in Ranked 1v1
Select Character Kombatant,count(*) total_times_used,Sum(Player_win) Wins
from seven11_prod.seven11_match_result_player
where activity_name in ('GM_RANKED_ON_1V1')
and ai_difficulty =-1 and date(wbanalyticssourcedate) between '2019-04-22' and '2019-10-20'
group by 1
order by 2 ;

-----# of Krypt chests opened
select count(*) chest_opened
from seven11_prod.seven11_resource_flow a
where source = 'KRYPT'
and change_amount < 0
and resource <> ''
and date(wbanalyticssourcedate) between '2019-04-22' and '2019-10-20' ;

-----# of flawless matches
Select count(distinct match_id)
from seven11_prod.seven11_match_result_player
where ai_difficulty =-1 and date(wbanalyticssourcedate) between '2019-04-22' and '2019-10-20'
and Avg_health_remaining = 1
and activity_name not in ('GM_TUTORIAL_OFFLINE') ;


-----Longest winning streak
Select max(winning_streak) longest_winning_streak
from(
select player_id, case when cum_sum =0 then streak 
						when cum_sum !=0 then streak-1 end as winning_streak				
from(
Select player_id,cum_sum,count(match_id) Streak
from(
Select player_id,match_id, player_win,case when player_win =1 then 0 else 1 end player_loss,time_stamp,
Sum (player_loss)over(partition by player_id order by time_stamp Rows Unbounded preceding) Cum_sum
from (
	select a._platform_account_id player_id, match_id, max(player_win) player_win,  min(wbanalyticssourcedate) time_stamp
	from seven11_prod.seven11_match_result_player a
	where ai_difficulty =-1 and date(wbanalyticssourcedate) between '2019-04-22' and '2019-10-20'
	group by 1,2
)
)
group by 1,2))  ;


-----Longest losing streak
Select max(losing_streak) longest_losing_streak
from(
select player_id, case when cum_sum =0 then streak 
						when cum_sum !=0 then streak-1 end as losing_streak				
from(
Select player_id,cum_sum,count(match_id) Streak
from(
Select player_id,match_id, player_win,time_stamp,
Sum (player_win)over(partition by player_id order by time_stamp Rows Unbounded preceding) Cum_sum
from (
	select a._platform_account_id player_id, match_id, max(player_win) player_win,  min(wbanalyticssourcedate) time_stamp
	from seven11_prod.seven11_match_result_player a
	where ai_difficulty =-1 and date(wbanalyticssourcedate) between '2019-04-22' and '2019-10-20'
	group by 1,2
)
)
group by 1,2)) ;


-----Highest winning streak in KOTH
Select max(winning_streak) longest_winning_streak
from(
select player_id, case when cum_sum =0 then streak 
						when cum_sum !=0 then streak-1 end as winning_streak				
from(
Select player_id,cum_sum,count(match_id) Streak
from(
Select player_id,match_id, player_win,case when player_win =1 then 0 else 1 end player_loss,time_stamp,
Sum (player_loss)over(partition by player_id order by time_stamp Rows Unbounded preceding) Cum_sum
from (
	select a._platform_account_id player_id, match_id, max(player_win) player_win,  min(wbanalyticssourcedate) time_stamp
	from seven11_prod.seven11_match_result_player a
	where ai_difficulty =-1 and date(wbanalyticssourcedate) between '2019-04-22' and '2019-10-20'
	and activity_name in ('GM_PLAYER_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_KOTH')
	group by 1,2
)
)
group by 1,2))  ;
