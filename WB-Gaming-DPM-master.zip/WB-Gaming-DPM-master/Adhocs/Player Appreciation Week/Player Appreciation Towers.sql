-----------  Unique players and matches of all towers -----------------
with matches as (
select dt, count(distinct match_id) matches,
	COALESCE(SUM(win), 0) as wins, COALESCE(SUM(round), 0) as rounds 
	from 
	(
	select date(wbanalyticssourcedate) dt , match_id, max(player_win) win, max(rounds) round
	from seven11_prod.seven11_match_result_player
	where tower_id !=''  and ai_difficulty = -1 and ai_player!=2
	and date(wbanalyticssourcedate) between '2019-08-12' and '2019-09-22'
	and activity_name in ('GM_TOWERS_OF_TIME', 'GM_TOWERS_OF_TIME_LADDER', 'GM_MULTIVERSE', 'GM_GROUP_BATTLES')
	group by 1,2
	)
group by 1
),
players as (
	select date(wbanalyticssourcedate) dt, count(distinct _platform_account_id) players
	from seven11_prod.seven11_match_result_player
	where tower_id !=''  and ai_difficulty = -1
	and date(wbanalyticssourcedate) between '2019-08-12' and '2019-09-22'
	and activity_name in ('GM_TOWERS_OF_TIME', 'GM_TOWERS_OF_TIME_LADDER', 'GM_MULTIVERSE', 'GM_GROUP_BATTLES')
	group by 1
)
select a.dt, players,  matches, wins, rounds
from players a join matches b on a.dt =b.dt


-----------  Unique players and matches of event towers -----------------

with matches as (
select dt, count(distinct match_id) matches,
	COALESCE(SUM(win), 0) as wins, COALESCE(SUM(round), 0) as rounds 
	from 
	(
	select date(wbanalyticssourcedate) dt , match_id, max(player_win) win, max(rounds) round
	from seven11_prod.seven11_match_result_player
	where tower_id !=''  and ai_difficulty = -1 and ai_player!=2
	and 	tower_id in ('TagBoss_KIT_JAD_TagBoss_KIT_JAD','TagBoss_KUN_LIU_TagBoss_KUN_LIU'
	,'TagBoss_JAC_JAX_TagBoss_JAC_JAX','TagBoss_SKA_SHA_TagBoss_SKA_SHA','TagBoss_KAN_KAB_TagBoss_KAN_KAB'
	,'TagBoss_SUB_SCO_TagBoss_SUB_SCO','TagBoss_JOH_SON_TagBoss_JOH_SON' ,'EndureBoss4_EndureBoss4','EndureBoss5_EndureBoss5','EndureBoss2_EndureBoss2'
	,'EndureBoss8_EndureBoss8','EndureBoss6_EndureBoss6','BarakaBoss1_BarakaBoss1','JadeBoss1_JadeBoss1'
	,'DVorahBoss1_DVorahBoss1','CetrionBoss1_CetrionBoss1','JacquiBoss1_JacquiBoss1','CassieBoss1_CassieBoss1'
	,'NightwolfBoss1Fight_NightwolfBoss1')
	and date(wbanalyticssourcedate) between '2019-09-09' and '2019-09-13'
	and activity_name in ('GM_TOWERS_OF_TIME', 'GM_TOWERS_OF_TIME_LADDER', 'GM_MULTIVERSE', 'GM_GROUP_BATTLES')
	group by 1,2
	)
group by 1
),
players as (
	select date(wbanalyticssourcedate) dt, count(distinct _platform_account_id) players
	from seven11_prod.seven11_match_result_player
	where tower_id !=''  and ai_difficulty = -1
	and 	tower_id in ('TagBoss_KIT_JAD_TagBoss_KIT_JAD','TagBoss_KUN_LIU_TagBoss_KUN_LIU'
	,'TagBoss_JAC_JAX_TagBoss_JAC_JAX','TagBoss_SKA_SHA_TagBoss_SKA_SHA','TagBoss_KAN_KAB_TagBoss_KAN_KAB'
	,'TagBoss_SUB_SCO_TagBoss_SUB_SCO','TagBoss_JOH_SON_TagBoss_JOH_SON' ,'EndureBoss4_EndureBoss4','EndureBoss5_EndureBoss5','EndureBoss2_EndureBoss2'
	,'EndureBoss8_EndureBoss8','EndureBoss6_EndureBoss6','BarakaBoss1_BarakaBoss1','JadeBoss1_JadeBoss1'
	,'DVorahBoss1_DVorahBoss1','CetrionBoss1_CetrionBoss1','JacquiBoss1_JacquiBoss1','CassieBoss1_CassieBoss1'
	,'NightwolfBoss1Fight_NightwolfBoss1')
	and date(wbanalyticssourcedate) between '2019-08-12' and '2019-09-22'
	and activity_name in ('GM_TOWERS_OF_TIME', 'GM_TOWERS_OF_TIME_LADDER', 'GM_MULTIVERSE', 'GM_GROUP_BATTLES')
	group by 1
)
select a.dt, players,  matches, wins, rounds
from players a join matches b on a.dt =b.dt



----------- Players, matches and completed players of all towers at tower_id level -----------------

with tower_matches as (
select date, tower_id, count(distinct match_id) matches,
	COALESCE(SUM(win), 0) as wins, COALESCE(SUM(round), 0) as rounds 
	from 
	(
	select date(wbanalyticssourcedate) date , tower_id, match_id, max(player_win) win, max(rounds) round
	from seven11_prod.seven11_match_result_player
	where tower_id !=''  and ai_difficulty = -1 and ai_player!=2
	and date(wbanalyticssourcedate) between '2019-08-26' and '2019-09-22'
	and activity_name in ('GM_TOWERS_OF_TIME', 'GM_TOWERS_OF_TIME_LADDER', 'GM_MULTIVERSE', 'GM_GROUP_BATTLES')
	group by 1,2,3
	)
group by 1,2
)
, tower_ends AS (select
        wbanalyticssourcedate::DATE date,
        tower_id,
        level_reached,
        _activity_guid,
        _platform_account_id,
        sum(number_deaths) as deaths,
        sum(activity_session_time_s) as time_seconds,
        sum(tower_completed) as completions,
        max(level_reached) as levelreached
        from seven11_prod.seven11_gameplay_towerend t
        where tower_id not in ('KlassicTowers_Warrior', 'KlassicTowers_Survivor', 'KlassicTowers_Novice', 'KlassicTowers_Endless', 'KlassicTowers_Champion')
	and date(wbanalyticssourcedate) between '2019-08-26' and '2019-09-22'
        group by 1,2,3,4,5)
, tower_attempts as (SELECT 
		a.date, 
		a.tower_id  AS "Tower_id",
		COUNT(DISTINCT a._activity_guid ) AS "Attempts",
		COUNT(DISTINCT a._platform_account_id ) AS "Players",
		COALESCE(SUM(a.deaths ), 0) AS "Deaths",
		COALESCE(SUM(a.time_seconds/60 ), 0) AS "TimePlayed"
		FROM tower_ends a
		GROUP BY 1,2
		ORDER BY 2 DESC
), tower_completions as (SELECT 
		b.date, 
		b.tower_id  AS "Tower_id",
		COUNT(DISTINCT b._activity_guid ) AS "Completed_Players_Attempts",
		COUNT(DISTINCT b._platform_account_id ) AS "Completed_Players",
		COALESCE(SUM(b.deaths ), 0) AS "Completed_Players_Deaths",
		COALESCE(SUM(b.time_seconds/60 ), 0) AS "Completed_Players_TimePlayed",
		Max(b.levelreached) as"Tower_Level"
		FROM tower_ends b
		WHERE  b.completions !=0 
		GROUP BY 1,2
		ORDER BY 2 DESC
)
Select e.Date,
	e.Tower_id,
	COALESCE(f.Tower_Level,0) Tower_Level,
	COALESCE(e.Players,0) Players,
	COALESCE(e.TimePlayed,0) TimePlayed,
	COALESCE(g.matches,0) matches,
	COALESCE(g.wins,0) wins,
	COALESCE(g.rounds,0) rounds,
	COALESCE(e.Attempts,0) Attempts,
	COALESCE(e.Deaths,0) Deaths,
	COALESCE(f.Completed_Players,0) Completed_Players,
	COALESCE(f.Completed_Players_TimePlayed,0) Completed_Players_TimePlayed,
	COALESCE(f.Completed_Players_Attempts,0) Completed_Players_Attempts
	from tower_attempts e 
	left join tower_completions f on e.Tower_id = f.Tower_id and e.Date = f.Date
	left join tower_matches g on e.Tower_id = g.Tower_id and e.Date = g.Date
order by 1,2 DESC


