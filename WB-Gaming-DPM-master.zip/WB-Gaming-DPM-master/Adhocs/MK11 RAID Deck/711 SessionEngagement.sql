select dt, sum(hrs)/count(distinct player_id) avghours, sum(hrs)/sum(sessions) sessionlength , sum(sessions)*1.0/count(distinct player_id) avgsessions
from(
	select player_id, event_dt dt , Sum(total_hours) hrs, sum(session_count) sessions, avg(session_count) avgsess
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22' and event_dt <= '2019-07-28' 
	group by 1,2
) a
group by 1
order by 1 ;


---LTD---

select sum(hrs)/count(distinct player_id) avghours, sum(hrs)/sum(sessions) sessionlength , sum(sessions)*1.0/count(distinct player_id) avgsessions, count(dt)*1.0/count(distinct player_id)  daysplayed
from(
	select player_id, event_dt dt , Sum(total_hours) hrs, sum(session_count) sessions, avg(session_count) avgsess
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22' and event_dt <= '2019-07-28' 
	group by 1,2
) a