	 	 
-----------------------------------------------------------------------------------------------------------
--------------Overall modes---aVG_sessions_per_day,hours_per_day,session_length for KL seasons 1&2 Players

with  KL1_players_overall as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
group by 1) ,

KL1_players_21_days as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-08'
group by 1) ,

 KL2_players as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-12'
group by 1)
	  

select *
from(
      select  Avg(no_of_sessions_per_day) Avg_sessions_per_day_KL1,Avg(Hours_per_day) Avg_hours_per_day_KL1,sum(Hours_per_day)/sum(no_of_sessions_per_day) Session_length_KL1
      from(
      select player_id,date(event_dt), sum(session_count)::float no_of_sessions_per_day,Sum(total_hours) Hours_per_day
      from seven11_prod_da.wba_player_daily
      where date(event_dt) between '2019-06-18' and '2019-07-16'
      and player_id in (select * from KL1_players_overall)
      group by 1,2)
      ) a
cross join
      (
      select  Avg(no_of_sessions_per_day) Avg_sessions_per_day_KL1_21days,Avg(Hours_per_day) Avg_hours_per_day_KL1_21days,sum(Hours_per_day)/sum(no_of_sessions_per_day) Session_length_KL1_21days
      from(
      select player_id,date(event_dt), sum(session_count)::float no_of_sessions_per_day,Sum(total_hours) Hours_per_day
      from seven11_prod_da.wba_player_daily
      where date(event_dt) between '2019-06-18' and '2019-07-08'
      and player_id in (select * from KL1_players_21_days)
      group by 1,2)
      ) b
cross join
      (
      select  Avg(no_of_sessions_per_day) Avg_sessions_per_day_KL2,Avg(Hours_per_day) Avg_hours_per_day_KL2,sum(Hours_per_day)/sum(no_of_sessions_per_day) Session_length_KL2
      from(
      select player_id,date(event_dt), sum(session_count)::float no_of_sessions_per_day,Sum(total_hours) Hours_per_day
      from seven11_prod_da.wba_player_daily
      where date(event_dt) between '2019-07-23' and '2019-08-12'
      and player_id in (select * from KL2_players)
      group by 1,2)
      ) c
;

-----------------------------------------------------------------------------------------------------------
--------------In Kombat League---aVG_sessions_per_day,hours_per_day,session_length for KL seasons 1&2 Players

select *
from(
      select COUNT(DISTINCT _platform_account_id) Players_KL1, Avg(matches) Matches_per_day_KL1, Avg(no_of_sessions_per_day) Avg_sessions_per_day_KL1,Avg(Hours_per_day) Avg_hours_per_day_KL1,sum(Hours_per_day)/sum(no_of_sessions_per_day) Session_length_KL1
      from(
      select _platform_account_id,date(wbanalyticssourcedate),count(distinct match_id)::float matches, count(distinct _session_id)::float no_of_sessions_per_day,Sum(match_length)::float/3600 Hours_per_day
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1,2)
      ) a
cross join
      (
     select COUNT(DISTINCT _platform_account_id) Players_KL1_21days,Avg(matches) Matches_per_day_KL1_21days, Avg(no_of_sessions_per_day) Avg_sessions_per_day_KL1_21days,Avg(Hours_per_day) Avg_hours_per_day_KL1_21days,sum(Hours_per_day)/sum(no_of_sessions_per_day) Session_length_KL1_21days
      from(
      select _platform_account_id,date(wbanalyticssourcedate),count(distinct match_id)::float matches, count(distinct _session_id)::float no_of_sessions_per_day,Sum(match_length)::float/3600 Hours_per_day
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-08'
      group by 1,2)
      ) b
cross join
      (
      select COUNT(DISTINCT _platform_account_id) Players_KL2,Avg(matches) Matches_per_day_KL2, Avg(no_of_sessions_per_day) Avg_sessions_per_day_KL2,Avg(Hours_per_day) Avg_hours_per_day_KL2,sum(Hours_per_day)/sum(no_of_sessions_per_day) Session_length_KL2
      from(
      select _platform_account_id,date(wbanalyticssourcedate),count(distinct match_id)::float matches, count(distinct _session_id)::float no_of_sessions_per_day,Sum(match_length)::float/3600 Hours_per_day
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-12'
      group by 1,2)
      ) c
;

------------------------------------------------------------------------------------------------------------
--------Avg days Played in KL Seasons 1& 2

with day_window as(
select datediff(day, '2019-07-23','2019-08-12') days
) ,

KL1_avg_days_played_overall as(
select avg(days_played) KL1_avg_days_played_overall
from(
select _platform_account_id,count(distinct date(wbanalyticssourcedate) )::float days_played
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
group by 1)),

KL1_avg_days_played_21days as(
select avg(days_played) KL1_avg_days_played_21days
from(
select _platform_account_id,count(distinct date(wbanalyticssourcedate) )::float days_played
from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18'  and dateadd(day,days,'2019-06-18')
group by 1)),

KL2_avg_days_played as(
select avg(days_played) KL2_avg_days_played
from(
select _platform_account_id,count(distinct date(wbanalyticssourcedate) )::float days_played
from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
where match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and dateadd(day,days,'2019-07-23')
group by 1))

select *
from KL1_avg_days_played_overall 
cross join KL1_avg_days_played_21days 
cross join KL2_avg_days_played ;
-----------------------------------------------------------------------------------------------------------
-----------perc players wrt DAU converted from season 1

with  KL1_players as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
group by 1) 


select  a.date,KL2_conv_from1,Total_KL2_Players,(KL2_conv_from1*1.0)/Total_KL2_Players perc_converted
from (
select date(wbanalyticssourcedate) date,count(distinct _platform_account_id) KL2_conv_from1
from seven11_prod.seven11_match_result_player 
where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-12'
and _platform_account_id in (Select * from kl1_players)
group by 1) a
join
(select date(wbanalyticssourcedate) date,count(distinct _platform_account_id) Total_KL2_Players
from seven11_prod.seven11_match_result_player
where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-12'
group by 1) b
on a.date=b.date ;


-----------perc season 1 players converted to Season 2

with  KL1_players as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
group by 1) 


select  Total_KL1_Players,Active_KL1_players,KL2_conv_from1,(KL2_conv_from1*1.0)/Total_KL1_Players perc_Total,
		(KL2_conv_from1*1.0)/Active_KL1_players perc_Active
from (
select count(distinct _platform_account_id) KL2_conv_from1
from seven11_prod.seven11_match_result_player 
where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-12'
and _platform_account_id in (Select * from kl1_players)
) 
cross join(
	select count(distinct _platform_account_id) Total_KL1_players
	from KL1_players) 
cross join(
	select count(distinct player_id) Active_KL1_players
	from seven11_prod_da.wba_fact_activity
	where date(event_dt) between '2019-07-23' and '2019-08-12' 
	and Player_id in (select * from KL1_players)
	 )
 ;
                                                                                     
--------------Kombat players,Kombat players as % of DAU,Avg_KL_matches for seasons 1&2 daily level


select a.days_since_start,Daily_KL1_players,Avg_KL1_hours_played_daily,
		(Daily_KL1_players)*1.0/ DAU_1 KL1_players_percent_of_DAU,Avg_KL1_matches_daily,
		Daily_KL2_players,Avg_KL2_hours_played_daily,
		(Daily_KL2_players)*1.0/ DAU_2 KL2_players_percent_of_DAU,Avg_KL2_matches_daily
from
      (
      SELECT datediff(day,'2019-06-17',event_dt) days_since_start,sum (active_players) DAU_1
      FROM seven11_prod_da.wba_daily_activity
      where event_dt between '2019-06-18' and '2019-07-16'
      group by 1
      ) a
left join
      (select datediff(day,'2019-06-17',date(wbanalyticssourcedate)) days_since_start 
        , count(distinct _platform_account_id) Daily_KL1_players
        , count(distinct match_id) KL1_matches,Sum(match_length) KL1_time_played
		,(KL1_time_played*1.0)/(Daily_KL1_players*3600) Avg_KL1_hours_played_daily
        , (KL1_matches*1.0)/Daily_KL1_players Avg_KL1_matches_daily
      from seven11_prod.seven11_match_result_player
      where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1
      ) b
on a.days_since_start=b.days_since_start
left join
      (
      SELECT datediff(day,'2019-07-22',event_dt) days_since_start,sum (active_players) DAU_2
      FROM seven11_prod_da.wba_daily_activity
      where event_dt between '2019-07-23' and '2019-08-12'
      group by 1
      ) c
on a.days_since_start=C.days_since_start
left join
      (select datediff(day,'2019-07-22',date(wbanalyticssourcedate)) days_since_start 
        , count(distinct _platform_account_id) Daily_KL2_players
        , count(distinct match_id) KL2_matches,Sum(match_length) KL2_time_played
		,(KL2_time_played*1.0)/(Daily_KL2_players*3600) Avg_KL2_hours_played_daily
        , (KL2_matches*1.0)/Daily_KL2_players Avg_KL2_matches_daily
      from seven11_prod.seven11_match_result_player
      where match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-12'
      group by 1
      )d
on a.days_since_start=d.days_since_start
;
	
-----------------------------------------------------------------------------------------------------------
--------------KL Retention Season 1 Vs 2

with day_window as(
select datediff(day, '2019-07-23','2019-08-12') days
),

KL1_retention_21days as(
select period, joindate, count(c._platform_account_id) retained_players, count(b._platform_account_id) cohorts
from
(
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from (select * 
				  from seven11_prod.seven11_activity_begin
				  cross join day_window)
			where date(wbanalyticsprocessingdate) between '2019-06-18 00:00:00' and dateadd(day,days,'2019-06-18')
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from (select * 
				  from seven11_prod.seven11_activity_begin
				  cross join day_window)
			where date(wbanalyticsprocessingdate) between '2019-06-18 00:00:00' and dateadd(day,days,'2019-06-18')
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-06-18 00:00:00')
    AND (d2.YearMonthDay>='2019-06-18 00:00:00')
	order by 1,2
) A
join 
(

	select _platform_account_id, min(wbanalyticsprocessingdate) yearmonthday
	from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
	where match_season = ('ranked-1')  and ai_difficulty= -1 and date(wbanalyticsprocessingdate)  between '2019-06-18 00:00:00' and dateadd(day,days,'2019-06-18')
	group by 1

)  B
on a.joinDate = b.yearmonthday 
left join
(

	select wbanalyticsprocessingdate yearmonthday, _platform_account_id
	from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
	where match_season  =  ('ranked-1')  and ai_difficulty= -1 and date(wbanalyticsprocessingdate)  between '2019-06-18 00:00:00' and dateadd(day,days,'2019-06-18')
	group by 1,2

) c
on b._platform_account_id = c._platform_account_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-06-18 00:00:00'
group by 1,2
order by 1,2 ),

KL1_retention_overall as(
select period, joindate, count(c._platform_account_id) retained_players, count(b._platform_account_id) cohorts
from
(
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-06-18 00:00:00' and '2019-07-16 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-06-18 00:00:00' and '2019-07-16 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-06-18 00:00:00')
    AND (d2.YearMonthDay>='2019-06-18 00:00:00')
	order by 1,2
) A
join 
(

	select _platform_account_id, min(wbanalyticsprocessingdate) yearmonthday
	from seven11_prod.seven11_match_result_player
	where match_season = ('ranked-1')  and ai_difficulty= -1 and wbanalyticsprocessingdate  between '2019-06-18 00:00:00' and '2019-07-16 00:00:00'
	group by 1

)  B
on a.joinDate = b.yearmonthday 
left join
(

	select wbanalyticsprocessingdate yearmonthday, _platform_account_id
	from seven11_prod.seven11_match_result_player a 
	where match_season  =  ('ranked-1')  and ai_difficulty= -1 and wbanalyticsprocessingdate between '2019-06-18 00:00:00' and '2019-07-16 00:00:00'
	group by 1,2

) c
on b._platform_account_id = c._platform_account_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-06-18 00:00:00'
group by 1,2
order by 1,2 ),

KL2_retention as(

select period, joindate, count(c._platform_account_id) retained_players, count(b._platform_account_id) cohorts
from
(
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-07-23 00:00:00' and '2019-08-12 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-07-23 00:00:00' and '2019-08-12 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-07-23 00:00:00')
    AND (d2.YearMonthDay>='2019-07-23 00:00:00')
	order by 1,2
) A
join 
(

	select _platform_account_id, min(wbanalyticsprocessingdate) yearmonthday
	from seven11_prod.seven11_match_result_player
	where match_season = ('ranked-2')  and ai_difficulty= -1 and wbanalyticsprocessingdate  between '2019-07-23 00:00:00' and '2019-08-12 00:00:00'
	group by 1

)  B
on a.joinDate = b.yearmonthday 
left join
(

	select wbanalyticsprocessingdate yearmonthday, _platform_account_id
	from seven11_prod.seven11_match_result_player a 
	where match_season  =  ('ranked-2')  and ai_difficulty= -1 and wbanalyticsprocessingdate between '2019-07-23 00:00:00' and '2019-08-12 00:00:00'
	group by 1,2

) c
on b._platform_account_id = c._platform_account_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-07-23 00:00:00'
group by 1,2
order by 1,2 )


select a.period, sum(a.retained_players::float) / sum(a.cohorts::float) KL1_retention_overall,
		sum(b.retained_players::float) / sum(b.cohorts::float) KL1_retention_21days,
		sum(c.retained_players::float) / sum(c.cohorts::float) KL2_retention
from KL1_retention_overall a
left join KL1_retention_21days b
on a.period =b.period
left join KL2_retention c
on a.period =c.period
group by 1 ;
