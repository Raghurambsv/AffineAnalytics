
------kp owners purchasing bundles

With KP_Owners as (
select _platform_account_id
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and date(_event_time_utc) >= '2019-04-22' )

select date(_event_time_utc) purchase_date,count(distinct _platform_account_id) bundle_purchasers
from seven11_prod.seven11_resource_flow
where resource = 'Exp_PremiumCurrency'
and change_amount <0
and date(_event_time_utc) >= '2019-04-22'
and lower(source_detail) like '%bundle%'
and _platform_account_id in (select * from kp_owners)
group by 1 ;

------Non kp owners purchasing themed Skin packs

Select purchase_date,entitlement_name,count(distinct _platform_account_id) Skin_pack_purchasers
from(
select entitlement_name,_platform_account_id,min(date(_event_time_utc)) purchase_date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('dlc4_skin_pack','dlc3_skin_pack','dlc2_skin_pack','klassic_arcade_ninja_skin_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) >= '2019-04-22' 
group by 1,2)
group by 1,2

