---MK11 Overall Paying Users
Select datepart(month,date), count(distinct _platform_account_id) paying_users
from(
select  _platform_account_id,DATE(_event_time_utc) date
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source = 'ENTITLEMENT'
and date(_event_time_utc) >= '2019-04-22' 
group by 1,2
Union(
Select _platform_account_id,date
from(
select entitlement_name,_platform_account_id,min(date(_event_time_utc)) date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('terminator','sindel','nightwolf','shang_tsung',
'dlc4_skin_pack','dlc3_skin_pack','dlc2_skin_pack','klassic_arcade_ninja_skin_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) >= '2019-04-22' 
group by 1,2)
group by 1,2
)
Union(
select _platform_account_id,min(date(_event_time_utc)) date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('kombat_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) >= '2019-04-22' 
group by 1)
Union(
select   _platform_account_id,min(date(_event_time_utc)) date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('halloween_skin_pack')
and date(_event_time_utc) >= '2019-04-22' 
group by 1)
)
group by 1 ;


------skins payers

select datepart(month,date), count(distinct _platform_account_id) Cosmetics_payers
from
(
Select _platform_account_id, date
from(
select entitlement_name,_platform_account_id,min(date(_event_time_utc)) date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('dlc4_skin_pack','dlc3_skin_pack','dlc2_skin_pack','klassic_arcade_ninja_skin_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) >= '2019-04-22' 
group by 1,2)
group by 1,2
Union(
select   _platform_account_id,min(date(_event_time_utc)) date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('halloween_skin_pack')
and date(_event_time_utc) >= '2019-04-22' 
group by 1)
union 
(
	select  a._platform_account_id,date(a._event_time_utc) date
	from
	(
	select *
	from seven11_prod.seven11_resource_flow
	where date(_event_time_utc) >= '2019-04-22' and resource = 'Exp_PremiumCurrency' and change_amount < 0 
	and source in ('PREMIUM_SHOP', 'PREMIUM_SHOP_IN_CUSTOMIZE') 
	) a
join 
	(
	select *
	from seven11_prod.seven11_progression_unlock
	where unlock_source in ('PREMIUM_SHOP', 'PREMIUM_SHOP_IN_CUSTOMIZE') 
	and (unlock_name like '%Gear%' or unlock_name like '%Skin%' or unlock_name like '%Icon%' )
	and date(_event_time_utc) >= '2019-04-22' 
	) b
on a.resource_flow_id = b.resource_flow_id and a._platform_account_id = b._platform_account_id
group by 1,2)
)
group by 1 ;

-----VC purchasers cosmetic ARPPU---------------------------------

----at monthly level 

--DLC SKin purchasers among VC purchasers

with VC_Purchasers as(
select  _platform_account_id
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source = 'ENTITLEMENT'
and date(_event_time_utc) >= '2019-04-22' 
group by 1)

select entitlement_name,datepart(month,date), count(distinct _platform_account_id) DLC_purchasers
from
(
select entitlement_name,_platform_account_id,min(date(_event_time_utc)) date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('dlc4_skin_pack','dlc3_skin_pack','dlc2_skin_pack','klassic_arcade_ninja_skin_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) >= '2019-04-22' 
group by 1,2
Union(
select   entitlement_name,_platform_account_id,min(date(_event_time_utc)) date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('halloween_skin_pack')
and date(_event_time_utc) >= '2019-04-22' 
group by 1,2))
where _platform_account_id in (select * from VC_Purchasers)
group by 1,2 ;

----Cosmetic purchasers among VC purchasers

with VC_Purchasers as(
select  _platform_account_id
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source = 'ENTITLEMENT'
and date(_event_time_utc) >= '2019-04-22' 
group by 1)



select datepart(month,date), count(distinct _platform_account_id) Cosmetics_payers
from
(
Select _platform_account_id, date
from(
select entitlement_name,_platform_account_id,min(date(_event_time_utc)) date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('dlc4_skin_pack','dlc3_skin_pack','dlc2_skin_pack','klassic_arcade_ninja_skin_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) >= '2019-04-22' 
group by 1,2)
group by 1,2
Union(
select   _platform_account_id,min(date(_event_time_utc)) date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('halloween_skin_pack')
and date(_event_time_utc) >= '2019-04-22' 
group by 1)
union 
(
	select  a._platform_account_id,date(a._event_time_utc) date
	from
	(
	select *
	from seven11_prod.seven11_resource_flow
	where date(_event_time_utc) >= '2019-04-22' and resource = 'Exp_PremiumCurrency' and change_amount < 0 
	and source in ('PREMIUM_SHOP', 'PREMIUM_SHOP_IN_CUSTOMIZE') 
	) a
join 
	(
	select *
	from seven11_prod.seven11_progression_unlock
	where unlock_source in ('PREMIUM_SHOP', 'PREMIUM_SHOP_IN_CUSTOMIZE') 
	and (unlock_name like '%Gear%' or unlock_name like '%Skin%' or unlock_name like '%Icon%' )
	and date(_event_time_utc) >= '2019-04-22' 
	) b
on a.resource_flow_id = b.resource_flow_id and a._platform_account_id = b._platform_account_id
group by 1,2)
)
where _platform_account_id in (select * from VC_Purchasers)
group by 1 ;

-----VC purchasers cosmetic ARPPU at Overall level
--DLC SKin purchasers among VC purchasers at Overall level

with VC_Purchasers as(
select  _platform_account_id
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source = 'ENTITLEMENT'
and date(_event_time_utc) >= '2019-04-22' 
group by 1)

select entitlement_name, count(distinct _platform_account_id) DLC_purchasers
from
(
select entitlement_name,_platform_account_id,min(date(_event_time_utc)) date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('dlc4_skin_pack','dlc3_skin_pack','dlc2_skin_pack','klassic_arcade_ninja_skin_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) >= '2019-04-22' 
group by 1,2
Union(
select   entitlement_name,_platform_account_id,min(date(_event_time_utc)) date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('halloween_skin_pack')
and date(_event_time_utc) >= '2019-04-22' 
group by 1,2))
where _platform_account_id in (select * from VC_Purchasers)
group by 1 ;

----Cosmetic purchasers among VC purchasers at Overall level

with VC_Purchasers as(
select  _platform_account_id
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source = 'ENTITLEMENT'
and date(_event_time_utc) >= '2019-04-22' 
group by 1)

select  count(distinct _platform_account_id) Cosmetics_payers
from
(
Select _platform_account_id, date
from(
select entitlement_name,_platform_account_id,min(date(_event_time_utc)) date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('dlc4_skin_pack','dlc3_skin_pack','dlc2_skin_pack','klassic_arcade_ninja_skin_pack')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) >= '2019-04-22' 
group by 1,2)
group by 1,2
Union(
select   _platform_account_id,min(date(_event_time_utc)) date
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('halloween_skin_pack')
and date(_event_time_utc) >= '2019-04-22' 
group by 1)
union 
(
	select  a._platform_account_id,date(a._event_time_utc) date
	from
	(
	select *
	from seven11_prod.seven11_resource_flow
	where date(_event_time_utc) >= '2019-04-22' and resource = 'Exp_PremiumCurrency' and change_amount < 0 
	and source in ('PREMIUM_SHOP', 'PREMIUM_SHOP_IN_CUSTOMIZE') 
	) a
join 
	(
	select *
	from seven11_prod.seven11_progression_unlock
	where unlock_source in ('PREMIUM_SHOP', 'PREMIUM_SHOP_IN_CUSTOMIZE') 
	and (unlock_name like '%Gear%' or unlock_name like '%Skin%' or unlock_name like '%Icon%' )
	and date(_event_time_utc) >= '2019-04-22' 
	) b
on a.resource_flow_id = b.resource_flow_id and a._platform_account_id = b._platform_account_id
group by 1,2)
)
where _platform_account_id in (select * from VC_Purchasers)
 ;

-----Revenue Spent in SHOP

select b.unlock_name, sum(change_amount) amt_spent
from
(
select source, sum(change_amount)
from seven11_prod.seven11_resource_flow
where resource = 'Exp_PremiumCurrency' and source in ('PREMIUM_SHOP', 'PREMIUM_SHOP_IN_CUSTOMIZE') 
and change_amount < 0
and date(_event_time_utc) >= '2019-04-22' 
--limit 5
) a
join 
(
select *
from seven11_prod.seven11_progression_unlock
where unlock_source in ('PREMIUM_SHOP', 'PREMIUM_SHOP_IN_CUSTOMIZE') --and unlock_name like '%Fatality%'
and date(_event_time_utc) >= '2019-04-22' 
--limit 5
) b
on a.resource_flow_id = b.resource_flow_id and a._platform_account_id = b._platform_account_id
group by 1




