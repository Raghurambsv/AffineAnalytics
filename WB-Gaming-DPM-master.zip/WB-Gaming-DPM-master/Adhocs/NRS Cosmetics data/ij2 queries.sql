--------------IJ2 overall Paying Users------


select datepart(month,date) mnth,datepart(year,date) yr, count(distinct platformaccountid) payers
from
(
	Select platformaccountid,  DATE
	from(
	select productname,a.platformaccountid, MIN(DATE(a.eventtime)) DATE
	from pachinko_prod_da.factdlc a
	join pachinko_prod_da.dimplayersegment b
	on a.platformaccountid = b.platformaccountid
	where productname not in ('Deluxe Edition Pre-Order', 'Injustice 2 Game',
		'Injustice 2 Game Pre-Order', 'Ultimate Edition Pre-Order','Power Girl',
		'John Stewart','Reverse Flash','Black Lightning')
	and a.platformaccountid not in 
	(
		select platformaccountid
		from pachinko_prod_da.factdlc 
		where productname  in ('Deluxe Edition Pre-Order', 'Ultimate Edition Pre-Order','Power Girl',
		'John Stewart','Reverse Flash','Black Lightning')
		group by 1
	)
	and b.seasonpassowner is null
	group by 1,2
	)
	group by 1,2
union 
	(
	select  platformaccountid,DATE(eventtime) DATE 
	from pachinko_prod_da.factactivityeconomy
	where currencytype = 'hard_bought' and totalearned >0
	and sourcetype = 'store'
	group by 1,2
	)
)
group by 1,2
order by 2,1 ;

-----IJ2 skin payers

select datepart(month,date) mnth, datepart(year,date) yr, count(distinct platformaccountid) cosmetic_payers
from
(	
	select date(eventtime) date, platformaccountid
	from pachinko_prod_da.factactivityeconomy
	where currencytype = 'hard_bought' and sourcetype in ('shader','skin','transmog') and totalspent >0
	group by 1,2
)
group by 1,2
order by 2,1 ;
-----VC purchasers cosmetic ARPPU---------------------------------

----at monthly level 

--Cosmetic purchasers among VC purchasers at monthly level

With VC_Purchasers as(
select  platformaccountid 
from pachinko_prod_da.factactivityeconomy
where currencytype = 'hard_bought' and totalearned >0
and sourcetype = 'store'
group by 1
)

select datepart(month,date) mnth, datepart(year,date) yr, count(distinct platformaccountid) cosmetic_payers
from
(	
	select date(eventtime) date, platformaccountid
	from pachinko_prod_da.factactivityeconomy
	where currencytype = 'hard_bought' and sourcetype in ('shader','skin','transmog') and totalspent >0
	group by 1,2
)
where platformaccountid in (Select * from VC_Purchasers)
group by 1,2
order by 2,1 ;

--Cosmetic purchasers among VC purchasers at Overall level

With VC_Purchasers as(
select  platformaccountid 
from pachinko_prod_da.factactivityeconomy
where currencytype = 'hard_bought' and totalearned >0
and sourcetype = 'store'
group by 1
)

select count(distinct platformaccountid) cosmetic_payers
from
(	
	select date(eventtime) date, platformaccountid
	from pachinko_prod_da.factactivityeconomy
	where currencytype = 'hard_bought' and sourcetype in ('shader','skin','transmog') and totalspent >0
	group by 1,2
)
where platformaccountid in (Select * from VC_Purchasers)
 ;
