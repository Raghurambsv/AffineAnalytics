-----------MK11 overall
Select country_name,count(distinct Player_id) Player_Count
from seven11_prod_da.wba_dim_player
where country_name in ('United States','Japan')
group by 1 ;

Select count(distinct Player_id) Total_Players
from seven11_prod_da.wba_dim_player ;

-----------MK11 digital
Select country_name,count(distinct Player_id) Player_Count
from seven11_prod_da.wba_dim_player
where country_name in ('United States','Japan')
and game_edition like ('%digital%')
group by 1 ;

Select count(distinct Player_id) Total_Players
from seven11_prod_da.wba_dim_player 
where game_edition like ('%digital%');

-----IJ2 Overall

Select count(distinct platformaccountid) US_Player_Count
from pachinko_prod_da.dimplayer
where countryname in ('United States','United States of America')
and Current = true ;

Select count(distinct platformaccountid) Japan_Player_Count
from pachinko_prod_da.dimplayer
where countryname in ('Japan') and Current = true ;

Select count(distinct platformaccountid) Total_Players
from pachinko_prod_da.dimplayer 
Where Current = true ;

-----------SOW overall
Select countryname,count(distinct platformaccountid) Player_Count
from kraken_prod_da.dim_player
where countryname in ('United States','Japan')
group by 1 ;

Select count(distinct platformaccountid) Total_Players
from kraken_prod_da.dim_player ;
