----------- KP purchase among a la carte owners (shang tsung, nightwolf and terminator)

With kp_owners as(
    select player_id, min(play_date) as Pur_Date
           from seven11_prod_da.player_monetization_panel
           where kombat_pack= 1
           and date(play_date) >= '2019-04-22'
		   and player_id not in (select _platform_account_id
                                                                  from seven11_prod.seven11_dlc_entitlement
                                                                  where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
                                                                  and date(wbanalyticssourcedate) >= '2019-04-22'
                                                                  group by 1
                                                                  )
    group by 1
    ),
	
	alacarte_purchasers as(
	select player_id, min(play_date) as Pur_Date
           from seven11_prod_da.player_monetization_panel
           where shang_tsung=1 or nightwolf=1 or terminator=1	------- Change for Individual ALC to KP upsell
           and date(play_date) >= '2019-04-22'
		   and player_id not in (select _platform_account_id
                                                                from  seven11_prod.seven11_dlc_entitlement
                                                                where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
                                                                and date(wbanalyticssourcedate) >= '2019-04-22'
                                                                group by 1
                                                                )
    group by 1)

select count(a.player_id) alacarte_to_kp
from alacarte_purchasers a join kp_owners b
on a.player_id= b.player_id
where datediff(day,a.Pur_Date, b.Pur_Date)>0 and
b.Pur_Date between '2019-10-08' and '2019-11-01'




