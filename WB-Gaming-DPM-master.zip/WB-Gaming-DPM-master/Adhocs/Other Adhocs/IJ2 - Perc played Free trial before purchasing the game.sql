select *,played_FT_1_before_Purchasing/Purchased_during_FT1 perc_played_FT1,
     played_FT_2_before_Purchasing/Purchased_during_FT2 perc_played_FT2
from
(
SELECT count(distinct platformaccountid)::float played_FT_1_before_Purchasing
from pachinko_prod_da.dimplayersegment
where trialdate between '2017-12-14' and '2017-12-19' and trialdate < retaildate
 and retaildate between '2017-12-14' and '2017-12-19' )
cross join
(
SELECT count(distinct platformaccountid)::float Purchased_during_FT1
from pachinko_prod_da.dimplayersegment
where retaildate between '2017-12-14' and '2017-12-19')
cross join
(
SELECT count(distinct platformaccountid)::float played_FT_2_before_Purchasing
from pachinko_prod_da.dimplayersegment
where trialdate between '2018-04-12' and '2018-04-16' and trialdate < retaildate
 and retaildate between '2018-04-12' and '2018-04-16' )
cross join
(
SELECT count(distinct platformaccountid)::float Purchased_during_FT2
from pachinko_prod_da.dimplayersegment
where retaildate between '2018-04-12' and '2018-04-16')


