--------Total Players

select  count(distinct platform_account_id) Total_players
from pachinko_prod.pachinko_activitysession_begin
where DATE(eventtimestamp)  BETWEEN '2017-05-15' and '2017-08-31' ;

---- hard bought currency spenders at sourcetype level 

select sourcetype,count(distinct platformaccountid) hard_bought_spenders
from pachinko_prod_da.factactivityeconomy_old
where date(eventtime)  BETWEEN '2017-05-15' and '2017-08-31'
 and currencytype ='hard_bought' and totalspent > 0
 group by 1;
 
---- hard bought currency spenders at overall level 

select count(distinct platformaccountid) hard_bought_spenders
from pachinko_prod_da.factactivityeconomy_old
where date(eventtime)  BETWEEN '2017-05-15' and '2017-08-31'
and currencytype ='hard_bought' and totalspent > 0;

---- hard bought currency spenders at overall level excluding level up

select count(distinct platformaccountid) hard_bought_spenders_exclu
from pachinko_prod_da.factactivityeconomy_old
where date(eventtime)  BETWEEN '2017-05-15' and '2017-08-31'
and currencytype ='hard_bought' and totalspent > 0
and sourcetype not in ('levelup_bought');

---- hard currency(hard earned and hard bought) spenders at sourcetype level 

select sourcetype,count(distinct platformaccountid) hard_curr_spenders
from pachinko_prod_da.factactivityeconomy_old
where date(eventtime)  BETWEEN '2017-05-15' and '2017-08-31'
 and currencytype in ('hard_earned','hard_bought') and totalspent > 0
 group by 1;

---- hard currency(hard earned and hard bought) spenders at overall level 

select count(distinct platformaccountid) hard_curr_spenders
from pachinko_prod_da.factactivityeconomy_old
where date(eventtime)  BETWEEN '2017-05-15' and '2017-08-31'
and currencytype in ('hard_earned','hard_bought') and totalspent > 0;

---- hard currency(hard earned and hard bought) spenders at sourcetype level excluding level up

select count(distinct platformaccountid) hard_curr_spenders_exclu
from pachinko_prod_da.factactivityeconomy_old
where date(eventtime)  BETWEEN '2017-05-15' and '2017-08-31'
and currencytype in ('hard_earned','hard_bought') and totalspent > 0
and sourcetype not in ('levelup_bought','levelup');

