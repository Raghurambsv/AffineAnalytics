------------Tower Players retention during KL Seasons--
with  Tower_Players_during_KL1 as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
	  and activity_name in ('GM_TOWERS_OF_TIME_LADDER') and tower_id not like ('Tutorial%')
      group by 1) ,

      Tower_Players_during_KL2 as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-20'
	  and activity_name in ('GM_TOWERS_OF_TIME_LADDER') and tower_id not like ('Tutorial%')
      group by 1),

      Tower_Players_during_KL3 as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-08-27' and '2019-09-24'
	  and activity_name in ('GM_TOWERS_OF_TIME_LADDER') and tower_id not like ('Tutorial%')
      group by 1),

      Tower_Players_during_KL4 as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-10-01' and '2019-10-29'
	  and activity_name in ('GM_TOWERS_OF_TIME_LADDER') and tower_id not like ('Tutorial%')
      group by 1),

      Tower_Players_during_KL5 as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-11-05' and '2019-12-03'
	  and activity_name in ('GM_TOWERS_OF_TIME_LADDER') and tower_id not like ('Tutorial%')
      group by 1),

      Tower_Players_during_KL6 as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-12-10' and '2020-01-07'
	  and activity_name in ('GM_TOWERS_OF_TIME_LADDER') and tower_id not like ('Tutorial%')
      group by 1)
	
---NOTE:-------Tower_KL1,KL2,KL3.... mean tower players during KL1,2,3 periods   
	  
Select *
from 
     (select Tower_Players_during_KL1,Active_tower_KL1_players_during_KL2, tower_KL1_players_conv_to_tower_KL2,
          (tower_KL1_players_conv_to_tower_KL2 * 1.0)/Active_tower_KL1_players_during_KL2 percent_conv_wrt_Active_tower_KL1_players
      from (
      select count(distinct _platform_account_id) tower_KL1_players_conv_to_tower_KL2
      from seven11_prod.seven11_match_result_player
      where  ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-20'
      and _platform_account_id in (Select * from Tower_Players_during_KL1) 
	  and activity_name in ('GM_TOWERS_OF_TIME_LADDER') and tower_id not like ('Tutorial%')
      )
	   cross join(
        select count(distinct _platform_account_id) Tower_Players_during_KL1
        from Tower_Players_during_KL1)
      cross join
      (
        select count(distinct player_id) Active_tower_KL1_players_during_KL2
        from seven11_prod_da.wba_fact_activity
        where date(event_dt) between '2019-07-23' and '2019-08-20'
        and Player_id in (select * from Tower_Players_during_KL1)
		 )    )
      cross join
      (
      select Tower_Players_during_KL2,Active_tower_KL2_players_during_KL3, tower_KL2_players_conv_to_tower_KL3,
          (tower_KL2_players_conv_to_tower_KL3 * 1.0)/Active_tower_KL2_players_during_KL3 percent_conv_wrt_Active_tower_KL2_players
      from (
      select count(distinct _platform_account_id) tower_KL2_players_conv_to_tower_KL3
      from seven11_prod.seven11_match_result_player
      where ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-08-27' and '2019-09-24'
      and _platform_account_id in (Select * from Tower_Players_during_KL2)
	  and activity_name in ('GM_TOWERS_OF_TIME_LADDER') and tower_id not like ('Tutorial%')
      )
       cross join(
        select count(distinct _platform_account_id) Tower_Players_during_KL2
        from Tower_Players_during_KL2)
      cross join
      (
        select count(distinct player_id) Active_tower_KL2_players_during_KL3
        from seven11_prod_da.wba_fact_activity
        where date(event_dt) between '2019-08-27' and '2019-09-24'
        and Player_id in (select * from Tower_Players_during_KL2)
      )    )
      cross join
      (
      select Tower_Players_during_KL3,Active_tower_KL3_players_during_KL4, tower_KL3_players_conv_to_tower_KL4,
          (tower_KL3_players_conv_to_tower_KL4 * 1.0)/Active_tower_KL3_players_during_KL4 percent_conv_wrt_Active_tower_KL3_players
      from (
      select count(distinct _platform_account_id) tower_KL3_players_conv_to_tower_KL4
      from seven11_prod.seven11_match_result_player
      where ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-10-01' and '2019-10-29'
      and _platform_account_id in (Select * from Tower_Players_during_KL3)
	  and activity_name in ('GM_TOWERS_OF_TIME_LADDER') and tower_id not like ('Tutorial%')
      )
	   cross join(
        select count(distinct _platform_account_id) Tower_Players_during_KL3
        from Tower_Players_during_KL3)
      cross join
      (
        select count(distinct player_id) Active_tower_KL3_players_during_KL4
        from seven11_prod_da.wba_fact_activity
        where date(event_dt) between '2019-10-01' and '2019-10-29'
        and Player_id in (select * from Tower_Players_during_KL3)
      )    )
      cross join
      (
      select Tower_Players_during_KL4,Active_tower_KL4_players_during_KL5, tower_KL4_players_conv_to_tower_KL5,
          (tower_KL4_players_conv_to_tower_KL5 * 1.0)/Active_tower_KL4_players_during_KL5 percent_conv_wrt_Active_tower_KL4_players
      from (
      select count(distinct _platform_account_id) tower_KL4_players_conv_to_tower_KL5
      from seven11_prod.seven11_match_result_player
      where ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-11-05' and '2019-12-03'
      and _platform_account_id in (Select * from Tower_Players_during_KL4)
	  and activity_name in ('GM_TOWERS_OF_TIME_LADDER') and tower_id not like ('Tutorial%')
      )
	   cross join(
        select count(distinct _platform_account_id) Tower_Players_during_KL4
        from Tower_Players_during_KL4)
      cross join
      (
        select count(distinct player_id) Active_tower_KL4_players_during_KL5
        from seven11_prod_da.wba_fact_activity
        where date(event_dt) between '2019-11-05' and '2019-12-03'
        and Player_id in (select * from Tower_Players_during_KL4)
      )    )
      cross join
      (
      select Tower_Players_during_KL5,Active_tower_KL5_players_during_KL6, tower_KL5_players_conv_to_tower_KL6,
          (tower_KL5_players_conv_to_tower_KL6 * 1.0)/Active_tower_KL5_players_during_KL6 percent_conv_wrt_Active_tower_KL5_players
      from (
      select count(distinct _platform_account_id) tower_KL5_players_conv_to_tower_KL6
      from seven11_prod.seven11_match_result_player
      where ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-12-10' and '2020-01-07'
      and _platform_account_id in (Select * from Tower_Players_during_KL5)
	  and activity_name in ('GM_TOWERS_OF_TIME_LADDER') and tower_id not like ('Tutorial%')
      )
	   cross join(
        select count(distinct _platform_account_id) Tower_Players_during_KL5
        from Tower_Players_during_KL5)
      cross join
      (
        select count(distinct player_id) Active_tower_KL5_players_during_KL6
        from seven11_prod_da.wba_fact_activity
        where date(event_dt) between '2019-12-10' and '2020-01-07'
        and Player_id in (select * from Tower_Players_during_KL5)
      )    )
      