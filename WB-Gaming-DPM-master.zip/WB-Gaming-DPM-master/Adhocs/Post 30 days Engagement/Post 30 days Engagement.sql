-----Overall post days------

With join_date as(
select player_id,min(date(event_dt)) join_date
from seven11_prod_da.wba_fact_activity
where date(event_dt) >= '2019-04-22' 
group by 1) ,

Played_30plus_days as(
Select *
from(
select a.*,b.join_date,datediff(day,join_date,date(event_dt))+1 Player_days
from seven11_prod_da.wba_fact_activity a
join join_date b
on a.player_id = b.player_id
where date(event_dt) >= '2019-04-22' 
)
where Player_days > 30
)


select case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode,count(distinct player_id) Players_post,
	 	sum(activity_hours) Hours_played_post,
	 	sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_post
from Played_30plus_days
where activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1
order by 1;

------Daily level post 30 days---

With join_date as(
select player_id,min(date(event_dt)) join_date
from seven11_prod_da.wba_fact_activity
where date(event_dt) >= '2019-04-22' 
group by 1) ,

Played_30plus_days as(
Select *
from(
select a.*,b.join_date,datediff(day,join_date,date(event_dt))+1 Player_days
from seven11_prod_da.wba_fact_activity a
join join_date b
on a.player_id = b.player_id
where date(event_dt) >= '2019-04-22' 
) 
where Player_days > 30
)


select Player_days,case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode,count(distinct player_id) Players_post,
	 	sum(activity_hours) Hours_played_post,
	 	sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_post
from Played_30plus_days
where activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1,2
order by 1,2;

-----Overall prior 30 days---

With join_date as(
select player_id,min(date(event_dt)) join_date
from seven11_prod_da.wba_fact_activity
where date(event_dt) >= '2019-04-22' 
group by 1) ,

players_cohort as(
Select player_id
from(
select a.*,b.join_date,datediff(day,join_date,date(event_dt))+1 Player_days
from seven11_prod_da.wba_fact_activity a
join join_date b
on a.player_id = b.player_id
where date(event_dt) >= '2019-04-22' 
) 
where Player_days > 30
group by 1
) ,

Played_30plus_days as(
Select *
from(
select a.*,b.join_date,datediff(day,join_date,date(event_dt))+1 Player_days
from seven11_prod_da.wba_fact_activity a
join join_date b
on a.player_id = b.player_id
where date(event_dt) >= '2019-04-22' and a.player_id in (select * from players_cohort)
) 
where Player_days <= 30
)


select case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode,count(distinct player_id) Players_post,
	 	sum(activity_hours) Hours_played_post,
	 	sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_post
from Played_30plus_days
where activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1
order by 1;

----Players cohort

With join_date as(
select player_id,min(date(event_dt)) join_date
from seven11_prod_da.wba_fact_activity
where date(event_dt) >= '2019-04-22' 
group by 1) 


Select count(distinct player_id) players
from(
select a.*,b.join_date,datediff(day,join_date,date(event_dt))+1 Player_days
from seven11_prod_da.wba_fact_activity a
join join_date b
on a.player_id = b.player_id
where date(event_dt) >= '2019-04-22' 
) 
where Player_days > 30 ;


----Players cohort daily post 30 days

With join_date as(
select player_id,min(date(event_dt)) join_date
from seven11_prod_da.wba_fact_activity
where date(event_dt) >= '2019-04-22' 
group by 1) 


Select Player_days,count(distinct player_id) players
from(
select a.*,b.join_date,datediff(day,join_date,date(event_dt))+1 Player_days
from seven11_prod_da.wba_fact_activity a
join join_date b
on a.player_id = b.player_id
where date(event_dt) >= '2019-04-22' 
) 
where Player_days > 30
group by 1
order by 1

;

------Daily level during 1st 30 days---

With join_date as(
select player_id,min(date(event_dt)) join_date
from seven11_prod_da.wba_fact_activity
where date(event_dt) >= '2019-04-22' 
group by 1) ,

Players as(
Select *
from(
select a.*,b.join_date,datediff(day,join_date,date(event_dt))+1 Player_days
from seven11_prod_da.wba_fact_activity a
join join_date b
on a.player_id = b.player_id
where date(event_dt) >= '2019-04-22' 
) 
where Player_days <= 30
)


select Player_days,case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode,count(distinct player_id) Players_post,
	 	sum(activity_hours) Hours_played_post,
	 	sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_post
from Players
where activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1,2
order by 1,2;

----Players cohort daily during 1st 30 days

With join_date as(
select player_id,min(date(event_dt)) join_date
from seven11_prod_da.wba_fact_activity
where date(event_dt) >= '2019-04-22' 
group by 1) 

Select Player_days,count(distinct player_id) players
from(
select a.*,b.join_date,datediff(day,join_date,date(event_dt))+1 Player_days
from seven11_prod_da.wba_fact_activity a
join join_date b
on a.player_id = b.player_id
where date(event_dt) >= '2019-04-22' 
) 
where Player_days <= 30
group by 1

;
