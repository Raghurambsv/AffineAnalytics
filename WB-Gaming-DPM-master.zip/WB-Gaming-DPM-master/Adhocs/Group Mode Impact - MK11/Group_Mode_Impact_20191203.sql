---- Team Raid Tower IDs----

select distinct tower_id, min(date(_event_time_utc))
from seven11_prod.seven11_gameplay_towerend
where tower_id like '%AFO_Generic%'
group by 1

--------------- distinct players and matches for Team Raid tower
select *
from
	(
	select dt, count(distinct player_id) DAU, sum(hrs)/count(distinct player_id) avghours, sum(hrs)/sum(sessions) sessionlength , sum(sessions)*1.0/count(distinct player_id) avgsessions
	from(
		select player_id, event_dt dt , Sum(total_hours) hrs, sum(session_count) sessions, avg(session_count) avgsess
		from seven11_prod_da.wba_player_daily
		where event_dt >= '2019-04-22'
		group by 1,2
		)
	group by 1
	) a
	left join
	(
	select date(_event_time_utc) date, 
			count(distinct _platform_account_id) dist_player_TR, 
			count(distinct match_id) matches_TR, 
			count(distinct _session_id) sessions_TR, 
			sum(time_played)::float/(3600*count(distinct _session_id)) avgSessionLength_TR, 
			count(distinct _session_id)::float/count(distinct _platform_account_id) avgSessionsperPlayer_TR, 
			sum(time_played)::float/(3600*count(distinct _platform_account_id)) avgHoursperPlayer_TR
	from seven11_prod.seven11_gameplay_towerend
	where tower_id like '%AFO_Generic%' and date(_event_time_utc)>= '2019-10-01'
	group by 1
	) b
	on b.date = a.dt
	
------- Group Battle--------

select *
from
	(
	select dt, count(distinct player_id) DAU, sum(hrs)/count(distinct player_id) avghours, sum(hrs)/sum(sessions) sessionlength , sum(sessions)*1.0/count(distinct player_id) avgsessions
	from(
		select player_id, event_dt dt , Sum(total_hours) hrs, sum(session_count) sessions, avg(session_count) avgsess
		from seven11_prod_da.wba_player_daily
		where event_dt >= '2019-04-22'
		group by 1,2
		)
	group by 1
	) a
	left join
	(
	select date(_event_time_utc) date, 
			count(distinct _platform_account_id) dist_player_GB, 
			count(distinct match_id) matches_GB, 
			count(distinct _session_id) sessions_GB, 
			sum(time_played)::float/(3600*count(distinct _session_id)) avgSessionLength_GB, 
			count(distinct _session_id)::float/count(distinct _platform_account_id) avgSessionsperPlayer_GB, 
			sum(time_played)::float/(3600*count(distinct _platform_account_id)) avgHoursperPlayer_GB
	from seven11_prod.seven11_gameplay_towerend
	where tower_id in (select tower_id
	from
	(
	select date(wbanalyticssourcedate) event_dt, tower_id
	from seven11_prod.seven11_match_result_player
	where ai_difficulty = -1
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and activity_name = 'GM_GROUP_BATTLES'
	group by 1,2
	having count(distinct _platform_account_id) >= 200
	)
	group by 1) and date(_event_time_utc)>= '2019-04-22'
	group by 1
	) b
	on b.date = a.dt
