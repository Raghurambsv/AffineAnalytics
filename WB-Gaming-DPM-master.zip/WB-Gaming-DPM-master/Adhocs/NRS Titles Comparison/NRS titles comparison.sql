
-----MK11 VC purchasers--daily
Select DATE(_event_time_utc) date,count(distinct _platform_account_id) vc_purchasers_daily
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source = 'ENTITLEMENT'
and date(_event_time_utc) between '2019-04-22' and '2020-01-31'
group by 1
order by 1 ;

----MK11 VC purchasers---Overall

Select count(distinct _platform_account_id) Total_VC_Purchasers
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and change_amount > 0 and source = 'ENTITLEMENT'
and date(_event_time_utc) between '2019-04-22' and '2020-01-31'
 ;
 
---- MK11 Ala carte purchasers---Overall
select count(distinct _platform_account_id) A_la_carte
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('terminator','sindel','nightwolf','shang_tsung','joker')
and _platform_account_id not  in 
(   select _platform_account_id
        from  seven11_prod.seven11_dlc_entitlement
        where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
        )
and date(_event_time_utc) between '2019-04-22' and '2020-01-31' ;

---- IJ 2 VC purchasers
	select  count(distinct platformaccountid) VC_purchasers
	from pachinko_prod_da.factactivityeconomy
	where currencytype = 'hard_bought' and totalearned >0
	and sourcetype = 'store'
	and DATE(eventtime) between '2017-05-15' and '2018-02-28'
	;
	
-------IJ2 A la carte purchasers------

	Select count(distinct platformaccountid) A_la_carte
	from(
	select productname,a.platformaccountid, MIN(DATE(a.eventtime)) DATE
	from pachinko_prod_da.factdlc a
	join pachinko_prod_da.dimplayersegment b
	on a.platformaccountid = b.platformaccountid
	where productname in ('Black Manta','Raiden','Red Hood','Starfire','Sub-Zero')
	and a.platformaccountid not in 
	(
		select platformaccountid
		from pachinko_prod_da.factdlc 
		where productname  in ('Ultimate Pack','Ultimate Edition Pre-Order','Fighter Pack 1','Deluxe Edition Pre-Order')
		group by 1
	)
	and DATE(a.eventtime) between '2017-05-15' and '2018-02-28'
	and b.seasonpassowner is null
	group by 1,2) ;
	
