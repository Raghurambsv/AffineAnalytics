
---MK11 Live Vs Beta
-----Beta engagement-- Onl PvP 1v1 game 

with beta_players as(
SELECT  player_id,min(event_dt) beta_join_date,datediff(day,min(event_dt),'2019-03-31') period
FROM seven11_prod_da.wba_fact_activity
where event_dt between '2019-03-28' and '2019-03-31'
group by 1) ,

beta_converted as(
select a.player_id ,period,min(event_dt) Game_join_date,dateadd(day,period,min(event_dt)) end_date
from seven11_prod_da.wba_fact_activity a
join beta_players b
on a.player_id = b.player_id
where event_dt >= '2019-04-22'
group by 1,2) ,

Conv_players_beta_data as
(select a.*
from seven11_prod.seven11_match_result_player a
join beta_converted b
on a._platform_account_id = b.player_id
where date(wbanalyticssourcedate) between '2019-03-28' and '2019-03-31'
and ai_difficulty= -1 
) ,

Conv_players_Main_game_data as(
select a.*,b.Game_join_date,b.end_date
from seven11_prod.seven11_match_result_player a
join beta_converted b
on a._platform_account_id = b.player_id
where date(wbanalyticssourcedate)  >= '2019-04-22'
and date(wbanalyticssourcedate) between Game_join_date and end_date
and ai_difficulty= -1 )

select  Count(date)::float/count(distinct _platform_account_id) Avg_days_played_per_player,
		Sum(sessions_per_day)/count(distinct _platform_account_id) Avg_sessions_per_player,
		Sum(Hours_per_day)/count(distinct _platform_account_id) Avg_hours_per_player,
		sum(Hours_per_day)/sum(sessions_per_day) Session_length_per_player,
		Sum(matches_per_day)/count(distinct _platform_account_id) Avg_matches_per_player,
		Sum(rounds_per_day)/count(distinct _platform_account_id) Avg_rounds_per_player,
		Avg(sessions_per_day) sessions_per_player_per_day,Avg(Hours_per_day) hours_per_player_per_day,
		Avg(matches_per_day) matches_per_player_per_day,Avg(rounds_per_day) rounds_per_player_per_day,
        count(distinct _platform_account_id) Total_players
from(
		select _platform_account_id,date(wbanalyticssourcedate) date,count(distinct _session_id)::float sessions_per_day,
		Sum(match_length)::float/3600 Hours_per_day,count(distinct match_id)::float matches_per_day,
		Sum(rounds)::float rounds_per_day
		from Conv_players_beta_data 
		where date(wbanalyticssourcedate) between '2019-03-28' and '2019-03-31'
		and activity_name in ('GM_PLAYER_MATCH_ON_1V1')
		group by 1,2) ;
		
-----Main game engagement-- Onl PvP 1v1 game  

with beta_players as(
SELECT  player_id,min(event_dt) beta_join_date,datediff(day,min(event_dt),'2019-03-31') period
FROM seven11_prod_da.wba_fact_activity
where event_dt between '2019-03-28' and '2019-03-31'
group by 1) ,

beta_converted as(
select a.player_id ,period,min(event_dt) Game_join_date,dateadd(day,period,min(event_dt)) end_date
from seven11_prod_da.wba_fact_activity a
join beta_players b
on a.player_id = b.player_id
where event_dt >= '2019-04-22'
group by 1,2) ,

Conv_players_beta_data as
(select a.*
from seven11_prod.seven11_match_result_player a
join beta_converted b
on a._platform_account_id = b.player_id
where date(wbanalyticssourcedate) between '2019-03-28' and '2019-03-31'
and ai_difficulty= -1 
) ,

Conv_players_Main_game_data as(
select a.*,b.Game_join_date,b.end_date
from seven11_prod.seven11_match_result_player a
join beta_converted b
on a._platform_account_id = b.player_id
where date(wbanalyticssourcedate)  >= '2019-04-22'
and date(wbanalyticssourcedate) between Game_join_date and end_date
and ai_difficulty= -1 )

select  Count(date)::float/count(distinct _platform_account_id) Avg_days_played_per_player,
		Sum(sessions_per_day)/count(distinct _platform_account_id) Avg_sessions_per_player,
		Sum(Hours_per_day)/count(distinct _platform_account_id) Avg_hours_per_player,
		sum(Hours_per_day)/sum(sessions_per_day) Session_length_per_player,
		Sum(matches_per_day)/count(distinct _platform_account_id) Avg_matches_per_player,
		Sum(rounds_per_day)/count(distinct _platform_account_id) Avg_rounds_per_player,
		Avg(sessions_per_day) sessions_per_player_per_day,Avg(Hours_per_day) hours_per_player_per_day,
		Avg(matches_per_day) matches_per_player_per_day,Avg(rounds_per_day) rounds_per_player_per_day,
        count(distinct _platform_account_id) Total_players
from(
		select _platform_account_id,date(wbanalyticssourcedate) date,count(distinct _session_id)::float sessions_per_day,
		Sum(match_length)::float/3600 Hours_per_day,count(distinct match_id)::float matches_per_day,
		Sum(rounds)::float rounds_per_day
		from Conv_players_Main_game_data  
		where date(wbanalyticssourcedate)  >= '2019-04-22'
		and activity_name in ('GM_PLAYER_MATCH_ON_1V1')
		group by 1,2) ;

-----Beta engagement-- Total game 

with beta_players as(
SELECT  player_id,min(event_dt) beta_join_date,datediff(day,min(event_dt),'2019-03-31') period
FROM seven11_prod_da.wba_fact_activity
where event_dt between '2019-03-28' and '2019-03-31'
group by 1) ,

beta_converted as(
select a.player_id ,period,min(event_dt) Game_join_date,dateadd(day,period,min(event_dt)) end_date
from seven11_prod_da.wba_fact_activity a
join beta_players b
on a.player_id = b.player_id
where event_dt >= '2019-04-22'
group by 1,2) ,

Conv_players_beta_data as
(select a.*
from seven11_prod.seven11_match_result_player a
join beta_converted b
on a._platform_account_id = b.player_id
where date(wbanalyticssourcedate) between '2019-03-28' and '2019-03-31'
and ai_difficulty= -1 
) ,

Conv_players_Main_game_data as(
select a.*,b.Game_join_date,b.end_date
from seven11_prod.seven11_match_result_player a
join beta_converted b
on a._platform_account_id = b.player_id
where date(wbanalyticssourcedate)  >= '2019-04-22'
and date(wbanalyticssourcedate) between Game_join_date and end_date
and ai_difficulty= -1 )

select  Count(date)::float/count(distinct _platform_account_id) Avg_days_played_per_player,
		Sum(sessions_per_day)/count(distinct _platform_account_id) Avg_sessions_per_player,
		Sum(Hours_per_day)/count(distinct _platform_account_id) Avg_hours_per_player,
		sum(Hours_per_day)/sum(sessions_per_day) Session_length_per_player,
		Sum(matches_per_day)/count(distinct _platform_account_id) Avg_matches_per_player,
		Sum(rounds_per_day)/count(distinct _platform_account_id) Avg_rounds_per_player,
		Avg(sessions_per_day) sessions_per_player_per_day,Avg(Hours_per_day) hours_per_player_per_day,
		Avg(matches_per_day) matches_per_player_per_day,Avg(rounds_per_day) rounds_per_player_per_day,
        count(distinct _platform_account_id) Total_players
from(
		select _platform_account_id,date(wbanalyticssourcedate) date,count(distinct _session_id)::float sessions_per_day,
		Sum(match_length)::float/3600 Hours_per_day,count(distinct match_id)::float matches_per_day,
		Sum(rounds)::float rounds_per_day
		from Conv_players_beta_data 
		where date(wbanalyticssourcedate) between '2019-03-28' and '2019-03-31'
		group by 1,2) ;
		
-----Main game engagement-- Total game 

with beta_players as(
SELECT  player_id,min(event_dt) beta_join_date,datediff(day,min(event_dt),'2019-03-31') period
FROM seven11_prod_da.wba_fact_activity
where event_dt between '2019-03-28' and '2019-03-31'
group by 1) ,

beta_converted as(
select a.player_id ,period,min(event_dt) Game_join_date,dateadd(day,period,min(event_dt)) end_date
from seven11_prod_da.wba_fact_activity a
join beta_players b
on a.player_id = b.player_id
where event_dt >= '2019-04-22'
group by 1,2) ,

Conv_players_beta_data as
(select a.*
from seven11_prod.seven11_match_result_player a
join beta_converted b
on a._platform_account_id = b.player_id
where date(wbanalyticssourcedate) between '2019-03-28' and '2019-03-31'
and ai_difficulty= -1 
) ,

Conv_players_Main_game_data as(
select a.*,b.Game_join_date,b.end_date
from seven11_prod.seven11_match_result_player a
join beta_converted b
on a._platform_account_id = b.player_id
where date(wbanalyticssourcedate)  >= '2019-04-22'
and date(wbanalyticssourcedate) between Game_join_date and end_date
and ai_difficulty= -1 )

select  Count(date)::float/count(distinct _platform_account_id) Avg_days_played_per_player,
		Sum(sessions_per_day)/count(distinct _platform_account_id) Avg_sessions_per_player,
		Sum(Hours_per_day)/count(distinct _platform_account_id) Avg_hours_per_player,
		sum(Hours_per_day)/sum(sessions_per_day) Session_length_per_player,
		Sum(matches_per_day)/count(distinct _platform_account_id) Avg_matches_per_player,
		Sum(rounds_per_day)/count(distinct _platform_account_id) Avg_rounds_per_player,
		Avg(sessions_per_day) sessions_per_player_per_day,Avg(Hours_per_day) hours_per_player_per_day,
		Avg(matches_per_day) matches_per_player_per_day,Avg(rounds_per_day) rounds_per_player_per_day,
        count(distinct _platform_account_id) Total_players
from(
		select _platform_account_id,date(wbanalyticssourcedate) date,count(distinct _session_id)::float sessions_per_day,
		Sum(match_length)::float/3600 Hours_per_day,count(distinct match_id)::float matches_per_day,
		Sum(rounds)::float rounds_per_day
		from Conv_players_Main_game_data  
		where date(wbanalyticssourcedate)  >= '2019-04-22'
		group by 1,2) ;
		
------Retention--


with beta_players as(
SELECT  player_id,min(event_dt) beta_join_date,datediff(day,min(event_dt),'2019-03-31') period
FROM seven11_prod_da.wba_fact_activity
where event_dt between '2019-03-28' and '2019-03-31'
group by 1) ,

beta_converted as(
select a.player_id ,period,min(event_dt) Game_join_date,dateadd(day,period,min(event_dt)) end_date
from seven11_prod_da.wba_fact_activity a
join beta_players b
on a.player_id = b.player_id
where event_dt >= '2019-04-22'
group by 1,2) ,

Conv_players_beta_data as
(select a.*
from seven11_prod.seven11_match_result_player a
join beta_converted b
on a._platform_account_id = b.player_id
where date(wbanalyticssourcedate) between '2019-03-28' and '2019-03-31'
and ai_difficulty= -1 
) ,

Conv_players_Main_game_data as(
select a.*,b.Game_join_date,b.end_date
from seven11_prod.seven11_match_result_player a
join beta_converted b
on a._platform_account_id = b.player_id
where date(wbanalyticssourcedate)  >= '2019-04-22'
and date(wbanalyticssourcedate) between Game_join_date and end_date
and ai_difficulty= -1 )

,

Beta_Retention_Total_game as(
select period, joindate, count(c._platform_account_id) retained_players, count(b._platform_account_id) cohorts
from
(
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-03-28 00:00:00' and '2019-03-31 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-03-28 00:00:00' and '2019-03-31 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-03-28 00:00:00')
    AND (d2.YearMonthDay>='2019-03-28 00:00:00')
	order by 1,2
) A
join 
(

	select _platform_account_id, min(wbanalyticsprocessingdate) yearmonthday
	from Conv_players_beta_data
	where wbanalyticsprocessingdate  between '2019-03-28 00:00:00' and '2019-03-31 00:00:00'
	group by 1

)  B
on a.joinDate = b.yearmonthday 
left join
(

	select wbanalyticsprocessingdate yearmonthday, _platform_account_id
	from Conv_players_beta_data a 
	where wbanalyticsprocessingdate between '2019-03-28 00:00:00' and '2019-03-31 00:00:00'
	group by 1,2

) c
on b._platform_account_id = c._platform_account_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-03-28 00:00:00'
group by 1,2
 ),

Main_game_Retention_Total_game as(
select period, joindate, count(c._platform_account_id) retained_players, count(b._platform_account_id) cohorts
from
(
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-08-29 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-08-29 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-04-22 00:00:00')
    AND (d2.YearMonthDay>='2019-04-22 00:00:00')
	order by 1,2
) A
join 
(

	select _platform_account_id, min(wbanalyticsprocessingdate) yearmonthday
	from Conv_players_Main_game_data
	where wbanalyticsprocessingdate  between '2019-04-22 00:00:00' and '2019-08-29 00:00:00'
	group by 1

)  B
on a.joinDate = b.yearmonthday 
left join
(

	select wbanalyticsprocessingdate yearmonthday, _platform_account_id
	from Conv_players_Main_game_data a 
	where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-08-29 00:00:00'
	group by 1,2

) c
on b._platform_account_id = c._platform_account_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-04-22 00:00:00'
group by 1,2
 ),

Beta_Retention_Onl_PvP as(
select period, joindate, count(c._platform_account_id) retained_players, count(b._platform_account_id) cohorts
from
(
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-03-28 00:00:00' and '2019-03-31 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-03-28 00:00:00' and '2019-03-31 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-03-28 00:00:00')
    AND (d2.YearMonthDay>='2019-03-28 00:00:00')
	order by 1,2
) A
join 
(

	select _platform_account_id, min(wbanalyticsprocessingdate) yearmonthday
	from Conv_players_beta_data
	where wbanalyticsprocessingdate  between '2019-03-28 00:00:00' and '2019-03-31 00:00:00'
	and activity_name in ('GM_PLAYER_MATCH_ON_1V1')
	group by 1

)  B
on a.joinDate = b.yearmonthday 
left join
(

	select wbanalyticsprocessingdate yearmonthday, _platform_account_id
	from Conv_players_beta_data a 
	where wbanalyticsprocessingdate between '2019-03-28 00:00:00' and '2019-03-31 00:00:00'
	and activity_name in ('GM_PLAYER_MATCH_ON_1V1')
	group by 1,2

) c
on b._platform_account_id = c._platform_account_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-03-28 00:00:00'
group by 1,2
),

Main_game_Retention_Onl_PvP as(
select period, joindate, count(c._platform_account_id) retained_players, count(b._platform_account_id) cohorts
from
(
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-08-29 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-08-29 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-04-22 00:00:00')
    AND (d2.YearMonthDay>='2019-04-22 00:00:00')
	order by 1,2
) A
join 
(

	select _platform_account_id, min(wbanalyticsprocessingdate) yearmonthday
	from Conv_players_Main_game_data
	where wbanalyticsprocessingdate  between '2019-04-22 00:00:00' and '2019-08-29 00:00:00'
	and activity_name in ('GM_PLAYER_MATCH_ON_1V1')
	group by 1

)  B
on a.joinDate = b.yearmonthday 
left join
(

	select wbanalyticsprocessingdate yearmonthday, _platform_account_id
	from Conv_players_Main_game_data a 
	where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-08-29 00:00:00'
	and activity_name in ('GM_PLAYER_MATCH_ON_1V1')
	group by 1,2

) c
on b._platform_account_id = c._platform_account_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-04-22 00:00:00'
group by 1,2
 ) 

select a.*,b.Main_game_Retention_Onl_PvP,c.Beta_Retention_Total_game ,d.Main_game_Retention_Total_game
from
(select period, sum(retained_players::float) / sum(cohorts::float) Beta_Retention_Onl_PvP
from Beta_Retention_Onl_PvP
group by 1) a
left join
(select period, sum(retained_players::float) / sum(cohorts::float) Main_game_Retention_Onl_PvP
from  Main_game_Retention_Onl_PvP
group by 1) b
on a.period = b.period
left join
(select period, sum(retained_players::float) / sum(cohorts::float) Beta_Retention_Total_game 
from  Beta_Retention_Total_game 
group by 1) c
on a.period = c.period
left join
(select period, sum(retained_players::float) / sum(cohorts::float) Main_game_Retention_Total_game
from Main_game_Retention_Total_game
group by 1) d
on a.period = d.period ;