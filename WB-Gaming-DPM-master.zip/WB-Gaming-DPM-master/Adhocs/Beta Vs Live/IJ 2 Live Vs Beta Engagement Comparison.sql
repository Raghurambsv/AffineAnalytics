
-----Matches Played

with beta_converted_players as(
select a.platform_account_id ,min(date(eventtimestamp)) Game_join_date,dateadd(day,13,min(date(eventtimestamp))) end_date
from pachinko_prod.pachinko_match_matchresult a
join sandbox.betaplayers b
on a.platform_account_id = b.platform_account_id
where date(eventtimestamp) >= '2017-05-15'
group by 1) ,

Conv_players_Main_game_data as(
select a.*,b.Game_join_date,b.end_date
from pachinko_prod.pachinko_match_matchresult a
join beta_converted_players b
on a.platform_account_id = b.platform_account_id
where date(eventtimestamp) >= '2017-05-15'
and date(eventtimestamp) between Game_join_date and end_date
)

select *
from
(select count(platform_account_id) Players, avg(matches) Avg_matches, median(matches) Median_matches
from (
select platform_account_id ,count(DISTINCT match_id) matches
from Conv_players_Main_game_data
where date(eventtimestamp) >= '2017-05-15' 
group by 1))
cross join 
(select count(platform_account_id) Onl_PvP_Players, avg(matches) Onl_PvP_Avg_matches, median(matches) Onl_PvP_Median_matches
from (
select platform_account_id ,count(DISTINCT match_id) matches
from Conv_players_Main_game_data
where date(eventtimestamp) >= '2017-05-15' 
 and UPPER(activity_type)='GM_PLAYER_MATCH_ON_1V1'
group by 1))  ;

----Retention

with beta_converted_players as(
select a.platform_account_id ,min(date(eventtimestamp)) Game_join_date,dateadd(day,13,min(date(eventtimestamp))) end_date
from pachinko_prod.pachinko_match_matchresult a
join sandbox.betaplayers b
on a.platform_account_id = b.platform_account_id
where date(eventtimestamp) >= '2017-05-15'
group by 1) ,

Conv_players_Main_game_data as(
select a.*,b.Game_join_date,b.end_date
from pachinko_prod.pachinko_match_matchresult a
join beta_converted_players b
on a.platform_account_id = b.platform_account_id
where date(eventtimestamp) >= '2017-05-15'
and date(eventtimestamp) between Game_join_date and end_date
) ,

Main_game_Retention_Onl_1v1 as(
select period, newdate, count(c.platform_account_id) retained_players, count(b.platform_account_id) cohorts
from
(
	SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from pachinko_prod.pachinko_activitysession_begin
			where wbanalyticsprocessingdate >='2017-05-15 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from pachinko_prod.pachinko_activitysession_begin
			where wbanalyticsprocessingdate >='2017-05-15 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2017-05-15 00:00:00' and d.YearMonthDay < '2019-08-30 00:00:00')
    AND (d2.YearMonthDay>='2017-05-15 00:00:00' and  d2.YearMonthDay < '2019-08-30 00:00:00')
	order by 1,2
) A
join 
(

	select platform_account_id, min(wbanalyticsprocessingdate) yearmonthday
	from Conv_players_Main_game_data a 
	where UPPER(activity_type)='GM_PLAYER_MATCH_ON_1V1' and date(eventtimestamp) >= '2017-05-15'
	group by 1

)  B
on a.NewDate = b.yearmonthday 
left join
(

	select wbanalyticsprocessingdate yearmonthday, platform_account_id
	from Conv_players_Main_game_data a 
	where UPPER(activity_type)='GM_PLAYER_MATCH_ON_1V1' and date(eventtimestamp) >= '2017-05-15'
	group by 1,2

) C
on b.platform_account_id = c.platform_account_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2017-05-15 00:00:00'
group by 1,2) ,

Main_game_Retention_all_modes as(
select period, newdate, count(c.platform_account_id) retained_players, count(b.platform_account_id) cohorts
from
(
	SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from pachinko_prod.pachinko_activitysession_begin
			where wbanalyticsprocessingdate >='2017-05-15 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from pachinko_prod.pachinko_activitysession_begin
			where wbanalyticsprocessingdate >='2017-05-15 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2017-05-15 00:00:00' and d.YearMonthDay < '2019-08-30 00:00:00')
    AND (d2.YearMonthDay>='2017-05-15 00:00:00' and  d2.YearMonthDay < '2019-08-30 00:00:00')
	order by 1,2
) A
join 
(

	select platform_account_id, min(wbanalyticsprocessingdate) yearmonthday
	from Conv_players_Main_game_data a 
	where  date(eventtimestamp) >= '2017-05-15'
	group by 1

)  B
on a.NewDate = b.yearmonthday 
left join
(

	select wbanalyticsprocessingdate yearmonthday, platform_account_id
	from Conv_players_Main_game_data a 
	where  date(eventtimestamp) >= '2017-05-15'
	group by 1,2

) C
on b.platform_account_id = c.platform_account_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2017-05-15 00:00:00'
group by 1,2) 

select a.*,b.Main_game_Retention_all_modes
from
(select period, sum(retained_players::float) / sum(cohorts::float) Main_game_Retention_Onl_1v1
from Main_game_Retention_Onl_1v1
group by 1) a
left join
(select period, sum(retained_players::float) / sum(cohorts::float) Main_game_Retention_all_modes
from  Main_game_Retention_all_modes
group by 1) b
on a.period = b.period
order by 1
