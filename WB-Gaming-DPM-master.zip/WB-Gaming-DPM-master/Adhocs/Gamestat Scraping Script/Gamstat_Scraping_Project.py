# -*- coding: utf-8 -*-
"""
Created on Wed Sep 18 16:09:31 2019

@author: Sayantan
"""

from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
import urllib
import numpy as np
import requests
from time import sleep
import pandas as pd
from datetime import date
from tqdm import tqdm_notebook as tqdm

def get_title_summary(soup):
    Summary_Table = soup.find('table', {'id' : 'games'})
    Games = Summary_Table.find_all('tr')
    
    all_Games = []
    for i in range(1,len(Games)):
        game_data = Games[i].find_all('td')
        elements = len(game_data)
        try:
            Game_URL = game_data[0].find('a')['href']
        except:
            Game_URL = ''
        try:
            Game_Name = game_data[1].find('a').text.strip()
        except:
            Game_Name = game_data[1].text.strip()
        try:
            Game_MAU = game_data[2].text.strip()
        except:
            Game_MAU = ''
        try:
            Game_New_Players = game_data[3].text.strip()
        except:
            Game_New_Players = ''
        try:
            Game_Player_Count = game_data[4].text.strip()
        except:
            Game_Player_Count = ''
        try:
            Platforms = game_data[5].find_all('span')
            Game_Platform = [p.text for p in Platforms]
        except:
            Game_Platform = ''
        
        Game_Details = [Game_Name, Game_URL, Game_MAU, Game_New_Players, Game_Player_Count,Game_Platform]
        all_Games.append(Game_Details)
    
    all_Games=pd.DataFrame(all_Games,columns=['Name', 'URL', 'MAU', 'New_Players',
                                              'Player_Count','Platforms'])
    all_Games['Extract_Date']=date.today().strftime("%B %d, %Y")

    return(all_Games)

# Set up Selenium Scraper
#driver_path = 'D:/Sayantan_C'C:/Users/rahuls/Documents/WB/Adhocs/GameStat Scrapping/chromedriver_win32
driver_path = 'C:/Users/rahuls/Documents/WB/Adhocs/GameStat Scrapping/chromedriver_win32'
#output_path = 'D:/Sayantan_C/Projects/10. Warner Bros - Gaming DPM/'
output_path = 'C:/Users/rahuls/Documents/WB/Adhocs/GameStat Scrapping/Scrapping_Output/'
driver = webdriver.Chrome(driver_path + '/chromedriver.exe')
driver.implicitly_wait(5)

# Browse to Page 1
driver.get('http://gamstat.com/games/')
sleep(10)
soup = BeautifulSoup(driver.page_source,'lxml')

# Get No. of Pages to paginate
# Currently limited to 5 pages only
buttons = soup.find_all('a', {'class':'paginate_button'})
buttons_list = [b.text.strip() for b in buttons]
#max_pages = buttons_list[len(buttons_list)-2]
max_pages = 11

# Blank Data Frame
all_Games=pd.DataFrame(columns=['Name', 'URL', 'MAU', 'New_Players',
                                              'Player_Count','Platforms','Extract_Date','Page_No'])

# Loop through all pages
for page in tqdm(range(1,int(max_pages))):
    subset_data = get_title_summary(soup)
    subset_data['Page_No'] = page
    all_Games = all_Games.append(subset_data, sort = True)
    
    next_page = driver.find_elements_by_xpath('//*[@id="games_next"]')[0]
    next_page.click()
    sleep(10)
    soup = BeautifulSoup(driver.page_source,'lxml')
    
driver.quit()

all_Games.reset_index()

#all_Games = all_Games[['Extract_Date','Page_No','Name', 'URL', 'MAU', 'New_Players', 'Player_Count','Platforms']]
all_Games = all_Games[['Extract_Date','Page_No','Name', 'URL', 'MAU', 'New_Players', 'Player_Count']]
all_Games.to_excel(output_path + 'Gamstat_Data_' + str(date.today().strftime("%B %d, %Y")) + '.xlsx', index = False)
#all_Games.to_excel(output_path + 'Gamstat_Data.xlsx', index = False)
