---KP
---New_Reengaged_Reacquired
with dlc_owners as(select _platform_account_id, min(wbanalyticssourcedate) purchasedatetime
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1) ,

Activity_data as(
select player_id, min_event_ts play_date_time
from seven11_prod_da.wba_player_daily
where event_dt >= '2019-04-22'
group by 1,2) ,

Player_type as(
select a._platform_account_id,date(purchasedatetime) purchasedate,max(date(play_date_time)) last_play_date,
case when purchasedate - last_play_date = 0 then 'New Players'
	 when purchasedate - last_play_date  between 1 and 14 then 'Re-engaged Players'
	 when purchasedate - last_play_date >= 14 then 'Re-acquired Players'
	 else 'Purchased before playing' end as Player_type
from dlc_owners a 
left join Activity_data b
on a._platform_account_id = b.player_id
and play_date_time <= purchasedatetime
group by 1,2)

select Player_Type,count(_platform_account_id) DLC_purchasers
from Player_type
group by 1

;

---Shang_Tsung

---New_Reengaged_Reacquired
with dlc_owners as(select _platform_account_id, min(wbanalyticssourcedate) purchasedatetime
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('shang_tsung','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1) ,

Activity_data as(
select player_id, min_event_ts play_date_time
from seven11_prod_da.wba_player_daily
where event_dt >= '2019-04-22'
group by 1,2) ,

Player_type as(
select a._platform_account_id,date(purchasedatetime) purchasedate,max(date(play_date_time)) last_play_date,
case when purchasedate - last_play_date = 0 then 'New Players'
	 when purchasedate - last_play_date  between 1 and 14 then 'Re-engaged Players'
	 when purchasedate - last_play_date >= 14 then 'Re-acquired Players'
	 else 'Purchased before playing' end as Player_type
from dlc_owners a 
left join Activity_data b
on a._platform_account_id = b.player_id
and play_date_time <= purchasedatetime
group by 1,2)

select Player_Type,count(_platform_account_id) DLC_purchasers
from Player_type
group by 1

;

--Nightwolf
---New_Reengaged_Reacquired
with dlc_owners as(select _platform_account_id, min(wbanalyticssourcedate) purchasedatetime
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('nightwolf','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1) ,

Activity_data as(
select player_id, min_event_ts play_date_time
from seven11_prod_da.wba_player_daily
where event_dt >= '2019-04-22'
group by 1,2) ,

Player_type as(
select a._platform_account_id,date(purchasedatetime) purchasedate,max(date(play_date_time)) last_play_date,
case when purchasedate - last_play_date = 0 then 'New Players'
	 when purchasedate - last_play_date  between 1 and 14 then 'Re-engaged Players'
	 when purchasedate - last_play_date >= 14 then 'Re-acquired Players'
	 else 'Purchased before playing' end as Player_type
from dlc_owners a 
left join Activity_data b
on a._platform_account_id = b.player_id
and play_date_time <= purchasedatetime
group by 1,2)

select Player_Type,count(_platform_account_id) DLC_purchasers
from Player_type
group by 1

;


