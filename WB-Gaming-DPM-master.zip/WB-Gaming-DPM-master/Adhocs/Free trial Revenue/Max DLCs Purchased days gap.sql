--KP
----Day level data--max dlc owners--day gap

with DLC_purchase_data as(select first_play_date, (playdate- first_play_date) days,count(player_id) joined_players,
sum (joined_players) over (partition by first_play_date )  join_cohort,count(_platform_account_id) DLC_owners,
sum (DLC_owners) over (partition by first_play_date ) Total_dlc_owners
from
(
	select player_id, min(date(event_dt)) first_play_date
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22'
	group by 1
) a
left join
(
	select _platform_account_id, min(date(wbanalyticssourcedate)) playdate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1
)b
on a.player_id = b._platform_account_id
where ((playdate- first_play_date >=0) or (playdate- first_play_date) is NULL )
group by 1,2)

select a.*,b.days, a.DLC_Owners::float/Total_dlc_owners perc
from(
select first_play_date,join_cohort,Total_dlc_owners,max(DLC_OWNERS) DLC_Owners
from DLC_purchase_data
where  days is not NULL 
group by 1,2,3) a
join(
select first_play_date,days,DLC_OWNERS
from DLC_purchase_data
where  days is not NULL 
group by 1,2,3) b
on a.first_play_date = b.first_play_date
and a.DLC_Owners = b.DLC_Owners
order by 1

;

--KP
----Day level data--max dlc owners--day gap---excl day 0

with DLC_purchase_data as(select first_play_date, (playdate- first_play_date) days,count(player_id) joined_players,
sum (joined_players) over (partition by first_play_date )  join_cohort,count(_platform_account_id) DLC_owners,
sum (DLC_owners) over (partition by first_play_date ) Total_dlc_owners
from
(
	select player_id, min(date(event_dt)) first_play_date
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22'
	group by 1
) a
left join
(
	select _platform_account_id, min(date(wbanalyticssourcedate)) playdate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1
)b
on a.player_id = b._platform_account_id
where ((playdate- first_play_date >=0) or (playdate- first_play_date) is NULL )
group by 1,2)

select a.*,b.days, a.DLC_Owners::float/Total_dlc_owners Perc
from(
select first_play_date,join_cohort,Total_dlc_owners,max(DLC_OWNERS) DLC_Owners
from DLC_purchase_data
where  days is not NULL and days<> 0
group by 1,2,3) a
join(
select first_play_date,days,DLC_OWNERS
from DLC_purchase_data
where  days is not NULL and days<> 0
group by 1,2,3) b
on a.first_play_date = b.first_play_date
and a.DLC_Owners = b.DLC_Owners
order by 1

;
-----Shang_Tsung--
----Day level data--max dlc owners--day gap

with DLC_purchase_data as(select first_play_date, (playdate- first_play_date) days,count(player_id) joined_players,
sum (joined_players) over (partition by first_play_date )  join_cohort,count(_platform_account_id) DLC_owners,
sum (DLC_owners) over (partition by first_play_date ) Total_dlc_owners
from
(
	select player_id, min(date(event_dt)) first_play_date
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22'
	group by 1
) a
left join
(
	select _platform_account_id, min(date(wbanalyticssourcedate)) playdate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('shang_tsung','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1
)b
on a.player_id = b._platform_account_id
where ((playdate- first_play_date >=0) or (playdate- first_play_date) is NULL )
group by 1,2)

select a.*,b.days, a.DLC_Owners::float/Total_dlc_owners perc
from(
select first_play_date,join_cohort,Total_dlc_owners,max(DLC_OWNERS) DLC_Owners
from DLC_purchase_data
where  days is not NULL 
group by 1,2,3) a
join(
select first_play_date,days,DLC_OWNERS
from DLC_purchase_data
where  days is not NULL 
group by 1,2,3) b
on a.first_play_date = b.first_play_date
and a.DLC_Owners = b.DLC_Owners
order by 1

;

--Shang Tsung
----Day level data--max dlc owners--day gap---excl day 0

with DLC_purchase_data as(select first_play_date, (playdate- first_play_date) days,count(player_id) joined_players,
sum (joined_players) over (partition by first_play_date )  join_cohort,count(_platform_account_id) DLC_owners,
sum (DLC_owners) over (partition by first_play_date ) Total_dlc_owners
from
(
	select player_id, min(date(event_dt)) first_play_date
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22'
	group by 1
) a
left join
(
	select _platform_account_id, min(date(wbanalyticssourcedate)) playdate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('shang_tsung','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1
)b
on a.player_id = b._platform_account_id
where ((playdate- first_play_date >=0) or (playdate- first_play_date) is NULL )
group by 1,2)

select a.*,b.days, a.DLC_Owners::float/Total_dlc_owners Perc
from(
select first_play_date,join_cohort,Total_dlc_owners,max(DLC_OWNERS) DLC_Owners
from DLC_purchase_data
where  days is not NULL and days<> 0
group by 1,2,3) a
join(
select first_play_date,days,DLC_OWNERS
from DLC_purchase_data
where  days is not NULL and days<> 0
group by 1,2,3) b
on a.first_play_date = b.first_play_date
and a.DLC_Owners = b.DLC_Owners
order by 1

;


-----Nightwolf--
----Day level data--max dlc owners--day gap

with DLC_purchase_data as(select first_play_date, (playdate- first_play_date) days,count(player_id) joined_players,
sum (joined_players) over (partition by first_play_date )  join_cohort,count(_platform_account_id) DLC_owners,
sum (DLC_owners) over (partition by first_play_date ) Total_dlc_owners
from
(
	select player_id, min(date(event_dt)) first_play_date
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22'
	group by 1
) a
left join
(
	select _platform_account_id, min(date(wbanalyticssourcedate)) playdate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('nightwolf','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1
)b
on a.player_id = b._platform_account_id
where ((playdate- first_play_date >=0) or (playdate- first_play_date) is NULL )
group by 1,2)

select a.*,b.days, a.DLC_Owners::float/Total_dlc_owners perc
from(
select first_play_date,join_cohort,Total_dlc_owners,max(DLC_OWNERS) DLC_Owners
from DLC_purchase_data
where  days is not NULL 
group by 1,2,3) a
join(
select first_play_date,days,DLC_OWNERS
from DLC_purchase_data
where  days is not NULL 
group by 1,2,3) b
on a.first_play_date = b.first_play_date
and a.DLC_Owners = b.DLC_Owners
order by 1

;

--Nightwolf
----Day level data--max dlc owners--day gap---excl day 0

with DLC_purchase_data as(select first_play_date, (playdate- first_play_date) days,count(player_id) joined_players,
sum (joined_players) over (partition by first_play_date )  join_cohort,count(_platform_account_id) DLC_owners,
sum (DLC_owners) over (partition by first_play_date ) Total_dlc_owners
from
(
	select player_id, min(date(event_dt)) first_play_date
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22'
	group by 1
) a
left join
(
	select _platform_account_id, min(date(wbanalyticssourcedate)) playdate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('nightwolf','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1
)b
on a.player_id = b._platform_account_id
where ((playdate- first_play_date >=0) or (playdate- first_play_date) is NULL )
group by 1,2)

select a.*,b.days, a.DLC_Owners::float/Total_dlc_owners Perc
from(
select first_play_date,join_cohort,Total_dlc_owners,max(DLC_OWNERS) DLC_Owners
from DLC_purchase_data
where  days is not NULL and days<> 0
group by 1,2,3) a
join(
select first_play_date,days,DLC_OWNERS
from DLC_purchase_data
where  days is not NULL and days<> 0
group by 1,2,3) b
on a.first_play_date = b.first_play_date
and a.DLC_Owners = b.DLC_Owners
order by 1

;
