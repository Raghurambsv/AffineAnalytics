---KP

with dlc_owners as( select _platform_account_id, min(date(wbanalyticssourcedate)) purchasedate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1 ) 
	

select purchasedate,count(_platform_account_id) KP_purchasers
from dlc_owners
group by 1
ORDER BY 1

;

---Shang_Tsung

with dlc_owners as(select _platform_account_id, min(date(wbanalyticssourcedate)) purchasedate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('shang_tsung','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1) 



select purchasedate, count(_platform_account_id) Shang_Tsung_purchasers
from dlc_owners
group by 1
order by 1

;


---Nightwolf

with dlc_owners as(select _platform_account_id, min(date(wbanalyticssourcedate)) purchasedate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('nightwolf','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1) 

select purchasedate,count(_platform_account_id) Nightwolf_purchasers
from dlc_owners
group by 1
order by 1

;


