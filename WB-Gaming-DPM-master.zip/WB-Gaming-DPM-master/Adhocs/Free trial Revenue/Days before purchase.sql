--KP
----Day level data

with DLC_purchase_data as(select first_play_date, (playdate- first_play_date) days,count(player_id) joined_players,
sum (joined_players) over (partition by first_play_date )  join_cohort,count(_platform_account_id) DLC_owners,
Sum(DLC_owners)over(partition by first_play_date order by days asc rows unbounded preceding) Running_dlc_total,
sum (DLC_owners) over (partition by first_play_date ) Total_dlc_owners,
DLC_owners::float/Total_dlc_owners::float perc_dlc,Running_dlc_total::float/Total_dlc_owners::float Cum_perc_DLC,
Case when Cum_perc_DLC >= 0.5 then 1 else 0 end as Reached_50_perc,Avg(days)over (partition by first_play_date ) Avg_days,
Median(days)over (partition by first_play_date ) Median_days
from
(
	select player_id, min(date(event_dt)) first_play_date
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22'
	group by 1
) a
left join
(
	select _platform_account_id, min(date(wbanalyticssourcedate)) playdate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1
)b
on a.player_id = b._platform_account_id
where ((playdate- first_play_date >=0) or (playdate- first_play_date) is NULL )
group by 1,2)

select first_play_date,Avg(join_cohort) joined_players,Avg(total_dlc_owners) DLC_owners,
Avg(total_dlc_owners)::float/Avg(join_cohort) Perc_DLC_owners,
min(days) Days_to_50perc,Avg(days)::float Avg_days_to_next_50_perc,
Median(days)::float Median_days_to_next_50_perc,Avg(avg_days)::float Avg_days,
Avg(median_days)::float Median_days
from DLC_purchase_data
where Reached_50_perc=1 and days is not NULL 
group by 1
order by 1
;


-----Overall level

with DLC_purchase_data as (select first_play_date, (playdate- first_play_date) days,count(player_id) joined_players,
sum (joined_players) over (partition by first_play_date )  join_cohort,count(_platform_account_id) DLC_owners,
Sum(DLC_owners)over(partition by first_play_date order by days asc rows unbounded preceding) Running_dlc_total,
sum (DLC_owners) over (partition by first_play_date ) Total_dlc_owners,
DLC_owners::float/Total_dlc_owners::float perc_dlc,Running_dlc_total::float/Total_dlc_owners::float Cum_perc_DLC,
Case when Cum_perc_DLC >= 0.5 then 1 else 0 end as Reached_50_perc,Avg(days)over (partition by first_play_date ) Avg_days,
Median(days)over (partition by first_play_date ) Median_days
from
(
	select player_id, min(date(event_dt)) first_play_date
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22'
	group by 1
) a
left join
(
	select _platform_account_id, min(date(wbanalyticssourcedate)) playdate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1
)b
on a.player_id = b._platform_account_id
where ((playdate- first_play_date >=0) or (playdate- first_play_date) is NULL )
group by 1,2) ,

day_level_data as(select first_play_date,Avg(join_cohort) joined_players,Avg(total_dlc_owners) DLC_owners,
Avg(total_dlc_owners)::float/Avg(join_cohort) Perc_DLC_owners,
min(days) Days_to_50perc,Avg(days)::float Avg_days_to_next_50_perc,
Median(days)::float Median_days_to_next_50_perc,Avg(avg_days)::float Avg_days,
Avg(median_days)::float Median_days
from DLC_purchase_data
where Reached_50_perc=1 and days is not NULL 
group by 1
order by 1
)

select Sum(joined_players) joined_players,Sum(DLC_owners) DLC_owners,
Sum(DLC_owners)::float/Sum(joined_players) Perc_DLC_owners,
Avg(Days_to_50perc)::float Avg_Days_to_50perc,Avg(Avg_days_to_next_50_perc)::float Avg_days_to_next_50_perc,
Avg(Median_days_to_next_50_perc)::float Median_days_to_next_50_perc,
Avg(avg_days)::float Avg_days,Avg(median_days)::float Median_days
from day_level_data
;

---Shang Tsung----

----Day level data

with DLC_purchase_data as(select first_play_date, (playdate- first_play_date) days,count(player_id) joined_players,
sum (joined_players) over (partition by first_play_date )  join_cohort,count(_platform_account_id) DLC_owners,
Sum(DLC_owners)over(partition by first_play_date order by days asc rows unbounded preceding) Running_dlc_total,
sum (DLC_owners) over (partition by first_play_date ) Total_dlc_owners,
DLC_owners::float/Total_dlc_owners::float perc_dlc,Running_dlc_total::float/Total_dlc_owners::float Cum_perc_DLC,
Case when Cum_perc_DLC >= 0.5 then 1 else 0 end as Reached_50_perc,Avg(days)over (partition by first_play_date ) Avg_days,
Median(days)over (partition by first_play_date ) Median_days
from
(
	select player_id, min(date(event_dt)) first_play_date
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22'
	group by 1
) a
left join
(
	select _platform_account_id, min(date(wbanalyticssourcedate)) playdate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('shang_tsung','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1
)b
on a.player_id = b._platform_account_id
where ((playdate- first_play_date >=0) or (playdate- first_play_date) is NULL )
group by 1,2)

select first_play_date,Avg(join_cohort) joined_players,Avg(total_dlc_owners) DLC_owners,
Avg(total_dlc_owners)::float/Avg(join_cohort) Perc_DLC_owners,
min(days) Days_to_50perc,Avg(days)::float Avg_days_to_next_50_perc,
Median(days)::float Median_days_to_next_50_perc,Avg(avg_days)::float Avg_days,
Avg(median_days)::float Median_days
from DLC_purchase_data
where Reached_50_perc=1 and days is not NULL 
group by 1
order by 1
;


-----Overall level

with DLC_purchase_data as (select first_play_date, (playdate- first_play_date) days,count(player_id) joined_players,
sum (joined_players) over (partition by first_play_date )  join_cohort,count(_platform_account_id) DLC_owners,
Sum(DLC_owners)over(partition by first_play_date order by days asc rows unbounded preceding) Running_dlc_total,
sum (DLC_owners) over (partition by first_play_date ) Total_dlc_owners,
DLC_owners::float/Total_dlc_owners::float perc_dlc,Running_dlc_total::float/Total_dlc_owners::float Cum_perc_DLC,
Case when Cum_perc_DLC >= 0.5 then 1 else 0 end as Reached_50_perc,Avg(days)over (partition by first_play_date ) Avg_days,
Median(days)over (partition by first_play_date ) Median_days
from
(
	select player_id, min(date(event_dt)) first_play_date
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22'
	group by 1
) a
left join
(
	select _platform_account_id, min(date(wbanalyticssourcedate)) playdate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('shang_tsung','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1
)b
on a.player_id = b._platform_account_id
where ((playdate- first_play_date >=0) or (playdate- first_play_date) is NULL )
group by 1,2) ,

day_level_data as(select first_play_date,Avg(join_cohort) joined_players,Avg(total_dlc_owners) DLC_owners,
Avg(total_dlc_owners)::float/Avg(join_cohort) Perc_DLC_owners,
min(days) Days_to_50perc,Avg(days)::float Avg_days_to_next_50_perc,
Median(days)::float Median_days_to_next_50_perc,Avg(avg_days)::float Avg_days,
Avg(median_days)::float Median_days
from DLC_purchase_data
where Reached_50_perc=1 and days is not NULL 
group by 1
order by 1
)

select Sum(joined_players) joined_players,Sum(DLC_owners) DLC_owners,
Sum(DLC_owners)::float/Sum(joined_players) Perc_DLC_owners,
Avg(Days_to_50perc)::float Avg_Days_to_50perc,Avg(Avg_days_to_next_50_perc)::float Avg_days_to_next_50_perc,
Avg(Median_days_to_next_50_perc)::float Median_days_to_next_50_perc,
Avg(avg_days)::float Avg_days,Avg(median_days)::float Median_days
from day_level_data
;

-----Nightwolf

----Day level data

with DLC_purchase_data as(select first_play_date, (playdate- first_play_date) days,count(player_id) joined_players,
sum (joined_players) over (partition by first_play_date )  join_cohort,count(_platform_account_id) DLC_owners,
Sum(DLC_owners)over(partition by first_play_date order by days asc rows unbounded preceding) Running_dlc_total,
sum (DLC_owners) over (partition by first_play_date ) Total_dlc_owners,
DLC_owners::float/Total_dlc_owners::float perc_dlc,Running_dlc_total::float/Total_dlc_owners::float Cum_perc_DLC,
Case when Cum_perc_DLC >= 0.5 then 1 else 0 end as Reached_50_perc,Avg(days)over (partition by first_play_date ) Avg_days,
Median(days)over (partition by first_play_date ) Median_days
from
(
	select player_id, min(date(event_dt)) first_play_date
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22'
	group by 1
) a
left join
(
	select _platform_account_id, min(date(wbanalyticssourcedate)) playdate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('nightwolf','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1
)b
on a.player_id = b._platform_account_id
where ((playdate- first_play_date >=0) or (playdate- first_play_date) is NULL )
group by 1,2)

select first_play_date,Avg(join_cohort) joined_players,Avg(total_dlc_owners) DLC_owners,
Avg(total_dlc_owners)::float/Avg(join_cohort) Perc_DLC_owners,
min(days) Days_to_50perc,Avg(days)::float Avg_days_to_next_50_perc,
Median(days)::float Median_days_to_next_50_perc,Avg(avg_days)::float Avg_days,
Avg(median_days)::float Median_days
from DLC_purchase_data
where Reached_50_perc=1 and days is not NULL 
group by 1
order by 1
;


-----Overall level

with DLC_purchase_data as (select first_play_date, (playdate- first_play_date) days,count(player_id) joined_players,
sum (joined_players) over (partition by first_play_date )  join_cohort,count(_platform_account_id) DLC_owners,
Sum(DLC_owners)over(partition by first_play_date order by days asc rows unbounded preceding) Running_dlc_total,
sum (DLC_owners) over (partition by first_play_date ) Total_dlc_owners,
DLC_owners::float/Total_dlc_owners::float perc_dlc,Running_dlc_total::float/Total_dlc_owners::float Cum_perc_DLC,
Case when Cum_perc_DLC >= 0.5 then 1 else 0 end as Reached_50_perc,Avg(days)over (partition by first_play_date ) Avg_days,
Median(days)over (partition by first_play_date ) Median_days
from
(
	select player_id, min(date(event_dt)) first_play_date
	from seven11_prod_da.wba_player_daily
	where event_dt >= '2019-04-22'
	group by 1
) a
left join
(
	select _platform_account_id, min(date(wbanalyticssourcedate)) playdate
	from seven11_prod.seven11_dlc_entitlement
	where entitlement_name in ('nightwolf','kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
	and date(wbanalyticssourcedate) >= '2019-04-22'
	and _platform_account_id not in (select _platform_account_id
									 from  seven11_prod.seven11_dlc_entitlement
									 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
									 and date(wbanalyticssourcedate) >= '2019-04-22'
									 group by 1
									 )
	group by 1
)b
on a.player_id = b._platform_account_id
where ((playdate- first_play_date >=0) or (playdate- first_play_date) is NULL )
group by 1,2) ,

day_level_data as(select first_play_date,Avg(join_cohort) joined_players,Avg(total_dlc_owners) DLC_owners,
Avg(total_dlc_owners)::float/Avg(join_cohort) Perc_DLC_owners,
min(days) Days_to_50perc,Avg(days)::float Avg_days_to_next_50_perc,
Median(days)::float Median_days_to_next_50_perc,Avg(avg_days)::float Avg_days,
Avg(median_days)::float Median_days
from DLC_purchase_data
where Reached_50_perc=1 and days is not NULL 
group by 1
order by 1
)

select Sum(joined_players) joined_players,Sum(DLC_owners) DLC_owners,
Sum(DLC_owners)::float/Sum(joined_players) Perc_DLC_owners,
Avg(Days_to_50perc)::float Avg_Days_to_50perc,Avg(Avg_days_to_next_50_perc)::float Avg_days_to_next_50_perc,
Avg(Median_days_to_next_50_perc)::float Median_days_to_next_50_perc,
Avg(avg_days)::float Avg_days,Avg(median_days)::float Median_days
from day_level_data
;
