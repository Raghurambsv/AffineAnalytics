---------------Converted players---Total Free trial players

select *
from(
SELECT count(distinct platformaccountid) FT_1_players_converted
from pachinko_prod_da.dimplayersegment
where trialdate between '2017-12-14' and '2017-12-19' and trialdate < retaildate
and retaildate is not Null and retaildate <= '2018-03-19')
cross join(
SELECT count(distinct platformaccountid) FT_1_players
from pachinko_prod_da.dimplayersegment
where trialdate between '2017-12-14' and '2017-12-19' 
)
cross join 
(
SELECT count(distinct platformaccountid) FT_2_players_converted
from pachinko_prod_da.dimplayersegment
where trialdate between '2018-04-12' and '2018-04-16' and trialdate < retaildate
and retaildate is not Null and retaildate <= '2018-07-16')
cross join(
SELECT count(distinct platformaccountid) FT_2_players
from pachinko_prod_da.dimplayersegment
where trialdate between '2018-04-12' and '2018-04-16' 
) ;

-----VC spent by free trial converters

with Players_converted_FT_1 as
(SELECT  platformaccountid
from pachinko_prod_da.dimplayersegment
where trialdate between '2017-12-14' and '2017-12-19' and trialdate < retaildate
and retaildate is not Null and retaildate <= '2018-03-19'
group by 1) ,

Players_converted_FT_2 as
(SELECT platformaccountid
from pachinko_prod_da.dimplayersegment
where trialdate between '2018-04-12' and '2018-04-16' and trialdate < retaildate
and retaildate is not Null and retaildate <= '2018-07-16'
group by 1)

select *
from(
select count(platformaccountid) FT1_spenders,sum(hard_currency) FT1_spenders_curr, sum(LTD) FT1_spenders_rev
from
(
	select a.platformaccountid, sum(totalearned) hard_currency , sum(totalearned)*.0003 LTD
	from pachinko_prod_da.factactivityeconomy_old a
	join pachinko_prod_da.dimplayer b on a.platformaccountid = b.platformaccountid
	where current = true 
	and currencytype in ('hard_bought')
	and a.platformaccountid in (select platformaccountid from Players_converted_FT_1 )
	group by 1
))
cross join
(select count(platformaccountid) FT2_spenders,sum(hard_currency) FT2_spenders_curr, sum(LTD) FT2_spenders_rev
from
(
	select a.platformaccountid, sum(totalearned) hard_currency , sum(totalearned)*.0003 LTD
	from pachinko_prod_da.factactivityeconomy_old a
	join pachinko_prod_da.dimplayer b on a.platformaccountid = b.platformaccountid
	where current = true 
	and currencytype in ('hard_bought')
	and a.platformaccountid in (select platformaccountid from Players_converted_FT_2 )
	group by 1
)) ;

-----DLCs owned by 'FREE TRIAL 1' converted players

------Ultimate pack and fighter pack owners ---from FT 1 Converted
with Players_converted_FT_1 as
(SELECT  platformaccountid
from pachinko_prod_da.dimplayersegment
where trialdate between '2017-12-14' and '2017-12-19' and trialdate < retaildate
and retaildate is not Null and retaildate <= '2018-03-19'
group by 1) ,
 
ultimate_pack_owners as(
select *
from (
select  platformaccountid
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and productname in ('Ultimate Pack') 
group by 1)
union 
(
select platformaccountid
from(
select  platformaccountid,count(distinct productname) num_chars
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and productname in ('Atom','Black Manta','Red Hood','Hellboy','Sub-Zero',
				'Enchantress','Raiden','Starfire','TMNT')
group by 1)
where num_chars = 9
group by 1)) ,

fighter_pack1_owners as(
select *
from (
select platformaccountid
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and productname in ('Fighter Pack 1') 
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
group by 1)
union 
(
select platformaccountid
from(
select  platformaccountid,count(distinct productname) num_chars
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and productname in ('Red Hood','Sub-Zero','Starfire')
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
group by 1)
where num_chars = 3
group by 1))

select *
from 
(select count(distinct platformaccountid) Ultimate_pack_owners_FT1
from ultimate_pack_owners)
cross join 
(select count(distinct platformaccountid) Fighter_pack1_owners_FT1
from fighter_pack1_owners)

;

------character owners(Excluding Ultimate pack and fighter pack) ---from FT 1 Converted--

with Players_converted_FT_1 as
(SELECT  platformaccountid
from pachinko_prod_da.dimplayersegment
where trialdate between '2017-12-14' and '2017-12-19' and trialdate < retaildate
and retaildate is not Null and retaildate <= '2018-03-19'
group by 1) ,

ultimate_pack_owners as(
select *
from (
select  platformaccountid
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and productname in ('Ultimate Pack') 
group by 1)
union 
(
select platformaccountid
from(
select  platformaccountid,count(distinct productname) num_chars
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and productname in ('Atom','Black Manta','Red Hood','Hellboy','Sub-Zero',
				'Enchantress','Raiden','Starfire','TMNT')
group by 1)
where num_chars = 9
group by 1)) ,

fighter_pack1_owners as(
select *
from (
select platformaccountid
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and productname in ('Fighter Pack 1') 
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
group by 1)
union 
(
select platformaccountid
from(
select  platformaccountid,count(distinct productname) num_chars
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and productname in ('Red Hood','Sub-Zero','Starfire')
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
group by 1)
where num_chars = 3
group by 1))

select productname,count(distinct platformaccountid) Owners
from (
select *
from(select *
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
and platformaccountid not in (select platformaccountid from fighter_pack1_owners )
and producttype in ('Character') )
union
(
select *
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from fighter_pack1_owners )
and producttype in ('Character') and productname not in ('Red Hood','Sub-Zero','Starfire')
))
group by 1
order by 2  ;

---player distribition by no of characters purchased(Excluding Ultimate pack and fighter pack)--from FT 1 Converted

with Players_converted_FT_1 as
(SELECT  platformaccountid
from pachinko_prod_da.dimplayersegment
where trialdate between '2017-12-14' and '2017-12-19' and trialdate < retaildate
and retaildate is not Null and retaildate <= '2018-03-19'
group by 1) ,

ultimate_pack_owners as(
select *
from (
select  platformaccountid
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and productname in ('Ultimate Pack') 
group by 1)
union 
(
select platformaccountid
from(
select  platformaccountid,count(distinct productname) num_chars
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and productname in ('Atom','Black Manta','Red Hood','Hellboy','Sub-Zero',
				'Enchantress','Raiden','Starfire','TMNT')
group by 1)
where num_chars = 9
group by 1)) ,

fighter_pack1_owners as(
select *
from (
select platformaccountid
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and productname in ('Fighter Pack 1') 
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
group by 1)
union 
(
select platformaccountid
from(
select  platformaccountid,count(distinct productname) num_chars
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and productname in ('Red Hood','Sub-Zero','Starfire')
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
group by 1)
where num_chars = 3
group by 1))

select no_of_chars,count(distinct platformaccountid) player_count
from(
select platformaccountid,count(distinct productname) no_of_chars
from (
select *
from(select *
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_1 )
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
and platformaccountid not in (select platformaccountid from fighter_pack1_owners )
and producttype in ('Character') 
)
union
(
select *
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from fighter_pack1_owners )
and producttype in ('Character') and productname not in ('Red Hood','Sub-Zero','Starfire')
))
group by 1)
group by 1
order by 2 ;

-----DLCs owned by 'FREE TRIAL 2' converted players

------Ultimate pack and fighter pack owners ---from FT 2 Converted

with Players_converted_FT_2 as
(SELECT platformaccountid
from pachinko_prod_da.dimplayersegment
where trialdate between '2018-04-12' and '2018-04-16' and trialdate < retaildate
and retaildate is not Null and retaildate <= '2018-07-16'
group by 1) ,

ultimate_pack_owners as(
select *
from (
select  platformaccountid
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and productname in ('Ultimate Pack') 
group by 1)
union 
(
select platformaccountid
from(
select  platformaccountid,count(distinct productname) num_chars
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and productname in ('Atom','Black Manta','Red Hood','Hellboy','Sub-Zero',
				'Enchantress','Raiden','Starfire','TMNT')
group by 1)
where num_chars = 9
group by 1)) ,

fighter_pack1_owners as(
select *
from (
select platformaccountid
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and productname in ('Fighter Pack 1') 
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
group by 1)
union 
(
select platformaccountid
from(
select  platformaccountid,count(distinct productname) num_chars
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and productname in ('Red Hood','Sub-Zero','Starfire')
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
group by 1)
where num_chars = 3
group by 1))

select *
from 
(select count(distinct platformaccountid) Ultimate_pack_owners_FT2
from ultimate_pack_owners)
cross join 
(select count(distinct platformaccountid) Fighter_pack1_ownerFT2
from fighter_pack1_owners)

;

------character owners(Excluding Ultimate pack and fighter pack) ---from FT 2 Converted--

with Players_converted_FT_2 as
(SELECT platformaccountid
from pachinko_prod_da.dimplayersegment
where trialdate between '2018-04-12' and '2018-04-16' and trialdate < retaildate
and retaildate is not Null and retaildate <= '2018-07-16'
group by 1) ,

ultimate_pack_owners as(
select *
from (
select  platformaccountid
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and productname in ('Ultimate Pack') 
group by 1)
union 
(
select platformaccountid
from(
select  platformaccountid,count(distinct productname) num_chars
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and productname in ('Atom','Black Manta','Red Hood','Hellboy','Sub-Zero',
				'Enchantress','Raiden','Starfire','TMNT')
group by 1)
where num_chars = 9
group by 1)) ,

fighter_pack1_owners as(
select *
from (
select platformaccountid
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and productname in ('Fighter Pack 1') 
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
group by 1)
union 
(
select platformaccountid
from(
select  platformaccountid,count(distinct productname) num_chars
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and productname in ('Red Hood','Sub-Zero','Starfire')
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
group by 1)
where num_chars = 3
group by 1))

select productname,count(distinct platformaccountid) owners
from (
select *
from(select *
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
and platformaccountid not in (select platformaccountid from fighter_pack1_owners )
and producttype in ('Character') )
union
(
select *
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from fighter_pack1_owners )
and producttype in ('Character') and productname not in ('Red Hood','Sub-Zero','Starfire')
))
group by 1
order by 2  ;

---player distribition by no of characters purchased(Excluding Ultimate pack and fighter pack)--from FT 2 Converted

with Players_converted_FT_2 as
(SELECT platformaccountid
from pachinko_prod_da.dimplayersegment
where trialdate between '2018-04-12' and '2018-04-16' and trialdate < retaildate
and retaildate is not Null and retaildate <= '2018-07-16'
group by 1) ,

ultimate_pack_owners as(
select *
from (
select  platformaccountid
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and productname in ('Ultimate Pack') 
group by 1)
union 
(
select platformaccountid
from(
select  platformaccountid,count(distinct productname) num_chars
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and productname in ('Atom','Black Manta','Red Hood','Hellboy','Sub-Zero',
				'Enchantress','Raiden','Starfire','TMNT')
group by 1)
where num_chars = 9
group by 1)) ,

fighter_pack1_owners as(
select *
from (
select platformaccountid
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and productname in ('Fighter Pack 1') 
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
group by 1)
union 
(
select platformaccountid
from(
select  platformaccountid,count(distinct productname) num_chars
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and productname in ('Red Hood','Sub-Zero','Starfire')
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
group by 1)
where num_chars = 3
group by 1))

select no_of_chars,count(distinct platformaccountid)
from(
select platformaccountid,count(distinct productname) no_of_chars
from (
select *
from(select *
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from Players_converted_FT_2 )
and platformaccountid not in (select platformaccountid from ultimate_pack_owners )
and platformaccountid not in (select platformaccountid from fighter_pack1_owners )
and producttype in ('Character') 
)
union
(
select *
from pachinko_prod_da.factdlc
where platformaccountid in (select platformaccountid from fighter_pack1_owners )
and producttype in ('Character') and productname not in ('Red Hood','Sub-Zero','Starfire')
))
group by 1)
group by 1
order by 2 ;