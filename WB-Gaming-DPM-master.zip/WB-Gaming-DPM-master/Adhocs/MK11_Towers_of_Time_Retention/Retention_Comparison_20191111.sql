--------------------------------- Retention Tower of Time---

with ToT_players as(
select _platform_account_id from
(
	select _platform_account_id, count(activity_name) matchcount
	from seven11_prod.seven11_match_result_player
	where ai_difficulty = -1
		and date(wbanalyticssourcedate) between '2019-04-22' and '2019-11-06'
		and activity_name = 'GM_TOWERS_OF_TIME_LADDER'
	 group by 1
)
where matchcount>=5
 ),

cohort_retention as(
select period, joindate, retentiondate, count(c.player_id) retained_players, count(b.player_id) cohorts
from
(	
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay retentiondate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-11-06 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-11-06 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-04-22 00:00:00')
    AND (d2.YearMonthDay>='2019-04-22 00:00:00')
	order by 1,2
) A
join 
(
		select player_id, min(event_dt) yearmonthday
        from seven11_prod_da.wba_fact_activity a
		where event_dt between '2019-04-22' and '2019-11-06' 
		and player_id in (select * from ToT_players)
		and activity_name = 'GM_TOWERS_OF_TIME_LADDER'
        group by 1

    )  B
on a.joinDate = b.yearmonthday 
left join
(
      select event_dt yearmonthday, player_id
 	  from seven11_prod_da.wba_fact_activity a
	  where event_dt between '2019-04-22' and '2019-11-06' 
	  and player_id in (select * from ToT_players)
	  and activity_name = 'GM_TOWERS_OF_TIME_LADDER'
      group by 1,2
    ) c
on b.player_id = c.player_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-04-22 00:00:00'
group by 1,2,3
order by 1,2
)


SELECT
	cohort_retention.period as period,
	DATE(cohort_retention.retentiondate ) AS "cohort_retention.retentiondate",
	DATE(cohort_retention.joindate ) AS "cohort_retention.joindate",
	COALESCE(SUM(cohort_retention.retained_players ), 0) AS "cohort_retention.retained_players",
	COALESCE(SUM(cohort_retention.cohorts ), 0) AS "cohort_retention.cohorts"
FROM cohort_retention
GROUP BY 1,2,3
ORDER BY 1, 2 DESC, 3 DESC


------------------------------------- Retention Online PvP---

with ToT_players as(
select _platform_account_id from
(
	select _platform_account_id, count(activity_name) matchcount
	from seven11_prod.seven11_match_result_player
	where ai_difficulty = -1
		and date(wbanalyticssourcedate) between '2019-04-22' and '2019-11-06'
		and activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT')
	 group by 1
)
where matchcount>=5
 ),

cohort_retention as(
select period, joindate, retentiondate, count(c.player_id) retained_players, count(b.player_id) cohorts
from
(	
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay retentiondate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-11-06 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-11-06 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-04-22 00:00:00')
    AND (d2.YearMonthDay>='2019-04-22 00:00:00')
	order by 1,2
) A
join 
(
		select player_id, min(event_dt) yearmonthday
        from seven11_prod_da.wba_fact_activity a
		where event_dt between '2019-04-22' and '2019-11-06' 
		and player_id in (select * from ToT_players)
		and activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT')
        group by 1

    )  B
on a.joinDate = b.yearmonthday 
left join
(
      select event_dt yearmonthday, player_id
 	  from seven11_prod_da.wba_fact_activity a
	  where event_dt between '2019-04-22' and '2019-11-06' 
	  and player_id in (select * from ToT_players)
	  and activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT')
      group by 1,2
    ) c
on b.player_id = c.player_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-04-22 00:00:00'
group by 1,2, 3
order by 1,2 
)


SELECT
	cohort_retention.period as period,
	DATE(cohort_retention.retentiondate ) AS "cohort_retention.retentiondate",
	DATE(cohort_retention.joindate ) AS "cohort_retention.joindate",
	COALESCE(SUM(cohort_retention.retained_players ), 0) AS "cohort_retention.retained_players",
	COALESCE(SUM(cohort_retention.cohorts ), 0) AS "cohort_retention.cohorts"
FROM cohort_retention
GROUP BY 1,2
ORDER BY 1, 2 DESC,3 DESC


---------------------------------- Retention Offline Mode---

with ToT_players as(
select _platform_account_id from
(
	select _platform_account_id, count(activity_name) matchcount
	from seven11_prod.seven11_match_result_player
	where ai_difficulty = -1
		and date(wbanalyticssourcedate) between '2019-04-22' and '2019-11-06'
		and activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF','GM_AI_FIGHTER')
	 group by 1
)
where matchcount>=5
 ),

cohort_retention as(
select period, joindate, retentiondate, count(c.player_id) retained_players, count(b.player_id) cohorts
from
(	
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay retentiondate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-11-06 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-11-06 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-04-22 00:00:00')
    AND (d2.YearMonthDay>='2019-04-22 00:00:00')
	order by 1,2
) A
join 
(
		select player_id, min(event_dt) yearmonthday
        from seven11_prod_da.wba_fact_activity a
		where event_dt between '2019-04-22' and '2019-11-06' 
		and player_id in (select * from ToT_players)
		and activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF','GM_AI_FIGHTER')
        group by 1

    )  B
on a.joinDate = b.yearmonthday 
left join
(
      select event_dt yearmonthday, player_id
 	  from seven11_prod_da.wba_fact_activity a
	  where event_dt between '2019-04-22' and '2019-11-06' 
	  and player_id in (select * from ToT_players)
	  and activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF','GM_AI_FIGHTER')
      group by 1,2
    ) c
on b.player_id = c.player_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-04-22 00:00:00'
group by 1,2
order by 1,2 
)


SELECT
	cohort_retention.period as period,
	DATE(cohort_retention.retentiondate ) AS "cohort_retention.retentiondate",
	DATE(cohort_retention.joindate ) AS "cohort_retention.joindate",
	COALESCE(SUM(cohort_retention.retained_players ), 0) AS "cohort_retention.retained_players",
	COALESCE(SUM(cohort_retention.cohorts ), 0) AS "cohort_retention.cohorts"
FROM cohort_retention
GROUP BY 1,2
ORDER BY 1, 2 DESC,3 DESC



