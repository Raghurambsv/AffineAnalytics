-----TK Spent/bought/earned by KL/non KL players during KL seasons
with  KL1_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1) ,

      KL2_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-20'
      group by 1),

      KL3_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-3') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-08-27' and '2019-09-24'
      group by 1),

      KL4_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-4') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-10-01' and '2019-10-29'
      group by 1),

      KL5_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-5') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-11-05' and '2019-12-03'
      group by 1),

      KL6_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-6') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-12-10' and '2020-01-07'
      group by 1)  
	  
Select *
from (
Select date(_event_time_utc) date,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED',
'TUTORIAL_REWARD','','community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE',
'EMAIL_COLLECTION_SUBSCRIPTION','KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned,
'Non KL S1' as Season
from(
select  _platform_account_id, _event_time_utc ,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and date(_event_time_utc) between '2019-05-20'  and '2019-07-16' 
and _platform_account_id NOT in (Select * from KL1_players)
group by 1,2,3,4)
group by 1) 
Union (
Select date(_event_time_utc) date,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED',
'TUTORIAL_REWARD','','community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE',
'EMAIL_COLLECTION_SUBSCRIPTION','KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned,
'KL S1' as Season
from(
select  _platform_account_id, _event_time_utc ,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and date(_event_time_utc) between '2019-05-20'  and '2019-07-16'   
and _platform_account_id in (Select * from KL1_players)
group by 1,2,3,4)
group by 1)
Union (
Select date(_event_time_utc) date,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED',
'TUTORIAL_REWARD','','community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE',
'EMAIL_COLLECTION_SUBSCRIPTION','KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned,
'Non KL S2' as Season
from(
select  _platform_account_id, _event_time_utc ,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and date(_event_time_utc) between '2019-07-23' and '2019-08-20'   
and _platform_account_id NOT in (Select * from KL2_players)
group by 1,2,3,4)
group by 1)
Union (
Select date(_event_time_utc) date,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED',
'TUTORIAL_REWARD','','community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE',
'EMAIL_COLLECTION_SUBSCRIPTION','KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned,
'KL S2' as Season
from(
select  _platform_account_id, _event_time_utc ,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and date(_event_time_utc) between '2019-07-23' and '2019-08-20'   
and _platform_account_id in (Select * from KL2_players)
group by 1,2,3,4)
group by 1)
Union (
Select date(_event_time_utc) date,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED',
'TUTORIAL_REWARD','','community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE',
'EMAIL_COLLECTION_SUBSCRIPTION','KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned,
'Non KL S3' as Season
from(
select  _platform_account_id, _event_time_utc ,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and date(_event_time_utc) between '2019-08-27' and '2019-09-24'   
and _platform_account_id NOT in (Select * from KL3_players)
group by 1,2,3,4)
group by 1)
Union (
Select date(_event_time_utc) date,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED',
'TUTORIAL_REWARD','','community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE',
'EMAIL_COLLECTION_SUBSCRIPTION','KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned,
'KL S3' as Season
from(
select  _platform_account_id, _event_time_utc ,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and date(_event_time_utc) between '2019-08-27' and '2019-09-24'   
and _platform_account_id in (Select * from KL3_players)
group by 1,2,3,4)
group by 1)
Union (
Select date(_event_time_utc) date,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED',
'TUTORIAL_REWARD','','community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE',
'EMAIL_COLLECTION_SUBSCRIPTION','KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned,
'Non KL S4' as Season
from(
select  _platform_account_id, _event_time_utc ,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and date(_event_time_utc) between '2019-10-01' and '2019-10-29'   
and _platform_account_id NOT in (Select * from KL4_players)
group by 1,2,3,4)
group by 1)
Union (
Select date(_event_time_utc) date,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED',
'TUTORIAL_REWARD','','community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE',
'EMAIL_COLLECTION_SUBSCRIPTION','KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned,
'KL S4' as Season
from(
select  _platform_account_id, _event_time_utc ,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and date(_event_time_utc) between '2019-10-01' and '2019-10-29'   
and _platform_account_id in (Select * from KL4_players)
group by 1,2,3,4)
group by 1)
Union (
Select date(_event_time_utc) date,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED',
'TUTORIAL_REWARD','','community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE',
'EMAIL_COLLECTION_SUBSCRIPTION','KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned,
'Non KL S5' as Season
from(
select  _platform_account_id, _event_time_utc ,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and date(_event_time_utc) between '2019-11-05' and '2019-12-03' 
and _platform_account_id NOT in (Select * from KL5_players)
group by 1,2,3,4)
group by 1)
Union (
Select date(_event_time_utc) date,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED',
'TUTORIAL_REWARD','','community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE',
'EMAIL_COLLECTION_SUBSCRIPTION','KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned,
'KL S5' as Season
from(
select  _platform_account_id, _event_time_utc ,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and date(_event_time_utc) between '2019-11-05' and '2019-12-03'   
and _platform_account_id in (Select * from KL5_players)
group by 1,2,3,4)
group by 1)
Union (
Select date(_event_time_utc) date,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED',
'TUTORIAL_REWARD','','community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE',
'EMAIL_COLLECTION_SUBSCRIPTION','KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned,
'Non KL S6' as Season
from(
select  _platform_account_id, _event_time_utc ,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and date(_event_time_utc) between '2019-12-10' and '2020-01-07'
and _platform_account_id NOT in (Select * from KL6_players)
group by 1,2,3,4)
group by 1)
Union (
Select date(_event_time_utc) date,
Coalesce(Sum(case when change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')then change_amount end),0)*(-1) as VC_Spent,
Coalesce(Sum(case when change_amount > 0 and source = 'ENTITLEMENT' then change_amount end),0) as VC_purchased,
Coalesce(Sum(case when change_amount > 0 and source in ('LEVELUP_PLAYER_EARNED','GM_STORY_OFF','LADDER_COMPLETED',
'TUTORIAL_REWARD','','community_tool_broadcast','Unknown','PORTAL_SEASON_COMPLETED','KOMBAT_LEAGUE',
'EMAIL_COLLECTION_SUBSCRIPTION','KRYPT','GM_RANKED_ON_1V1','ONLINE_PERFORMANCE_REWARD','PORTAL_QUEST_COMPLETED') then change_amount end),0) as VC_earned,
'KL S6' as Season
from(
select  _platform_account_id, _event_time_utc ,change_amount,source
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' 
and date(_event_time_utc) between '2019-12-10' and '2020-01-07'
and _platform_account_id in (Select * from KL6_players)
group by 1,2,3,4)
group by 1)
;
-------KL and Non KL players during KL seasons

with  KL1_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1) ,

      KL2_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-20'
      group by 1),

      KL3_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-3') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-08-27' and '2019-09-24'
      group by 1),

      KL4_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-4') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-10-01' and '2019-10-29'
      group by 1),

      KL5_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-5') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-11-05' and '2019-12-03'
      group by 1),

      KL6_players as(
      select _platform_account_id
      from seven11_prod.seven11_match_result_player
      where  match_season =  ('ranked-6') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-12-10' and '2020-01-07'
      group by 1)  
	  
Select *
from (
select  event_dt,count(distinct player_id) players,'Non KL S1' as Season
from seven11_prod_da.wba_player_daily
where date(event_dt) between '2019-05-20'  and '2019-07-16' 
and player_id NOT in (Select * from KL1_players)
group by 1)
Union (
Select event_dt,count(distinct player_id) players,'KL S1' as Season
from seven11_prod_da.wba_player_daily
where date(event_dt) between '2019-05-20'  and '2019-07-16'   
and player_id in (Select * from KL1_players)
group by 1)
Union (
Select event_dt,count(distinct player_id) players,'Non KL S2' as Season
from seven11_prod_da.wba_player_daily
where date(event_dt) between '2019-07-23' and '2019-08-20'   
and player_id NOT in (Select * from KL2_players)
group by 1)
Union (
Select event_dt,count(distinct player_id) players,'KL S2' as Season
from seven11_prod_da.wba_player_daily
where date(event_dt) between '2019-07-23' and '2019-08-20'   
and player_id in (Select * from KL2_players)
group by 1)
Union (
Select event_dt,count(distinct player_id) players,'Non KL S3' as Season
from seven11_prod_da.wba_player_daily
where date(event_dt) between '2019-08-27' and '2019-09-24'   
and player_id NOT in (Select * from KL3_players)
group by 1)
Union (
Select event_dt,count(distinct player_id) players,'KL S3' as Season
from seven11_prod_da.wba_player_daily
where date(event_dt) between '2019-08-27' and '2019-09-24'   
and player_id in (Select * from KL3_players)
group by 1)
Union (
Select event_dt,count(distinct player_id) players,'Non KL S4' as Season
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-10-01' and '2019-10-29'   
and player_id NOT in (Select * from KL4_players)
group by 1)
Union (
Select event_dt,count(distinct player_id) players,'KL S4' as Season
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-10-01' and '2019-10-29'   
and player_id in (Select * from KL4_players)
group by 1)
Union (
Select event_dt,count(distinct player_id) players,'Non KL S5' as Season
from seven11_prod_da.wba_player_daily
where date(event_dt) between '2019-11-05' and '2019-12-03' 
and player_id NOT in (Select * from KL5_players)
group by 1)
Union (
Select event_dt,count(distinct player_id) players,'KL S5' as Season
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-11-05' and '2019-12-03'   
and player_id in (Select * from KL5_players)
group by 1)
Union (
Select event_dt,count(distinct player_id) players,'Non KL S6' as Season
from seven11_prod_da.wba_player_daily
where date(event_dt) between '2019-12-10' and '2020-01-07'
and player_id NOT in (Select * from KL6_players)
group by 1)
Union (
Select event_dt,count(distinct player_id) players,'KL S6' as Season
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-12-10' and '2020-01-07'
and player_id in (Select * from KL6_players)
group by 1)

	  
	  