with players as(
select player_id
from seven11_prod_da.wba_player_daily
where event_dt between '2019-04-22' and '2019-05-05'
group by 1
)
,
----------
KL_players as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 and _platform_account_id in (select * from players)
group by 1
)
,
-----------
non_KL_players as(
select player_id
from players
where player_id not in (select * from KL_players)
group by 1
)
--------------------------------------------------------------------------------------------------------
-----------Time krystals Spent in Game-----------------------
select a.*,b.Time_Krystals_spent_by_non_KL_players_in_game
from
	(select date(_event_time_utc), sum(change_amount) Time_Krystals_spent_by_KL_players_in_game
	from seven11_prod.seven11_resource_flow
	where resource = 'Exp_PremiumCurrency' and source in ('PREMIUM_SHOP') and change_amount < 0 
	and date(_event_time_utc) >='2019-04-22' and _platform_account_id in (select * from KL_players)
	group by 1) a
join
	(select date(_event_time_utc), sum(change_amount) Time_Krystals_spent_by_non_KL_players_in_game
	from seven11_prod.seven11_resource_flow
	where resource = 'Exp_PremiumCurrency' and source in ('PREMIUM_SHOP') and change_amount < 0 
	and date(_event_time_utc) >='2019-04-22' and _platform_account_id in (select * from non_KL_players)
	group by 1) b
on a.date = b.date	
order by 1 ;
--------------TIme Krystals Bought by players-----------------
with players as(
select player_id
from seven11_prod_da.wba_player_daily
where event_dt between '2019-04-22' and '2019-05-05'
group by 1
)
,
----------
KL_players as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 and _platform_account_id in (select * from players)
group by 1
)
,
-----------
non_KL_players as(
select player_id
from players
where player_id not in (select * from KL_players)
group by 1
)

select a.*,b.Time_Krystals_bought_by_non_KL_players
from
	(select date(_event_time_utc), sum(change_amount) Time_Krystals_bought_by_KL_players
	from seven11_prod.seven11_resource_flow
	where resource = 'Exp_PremiumCurrency' and source in ('ENTITLEMENT') and change_amount > 0 
	and date(_event_time_utc) >='2019-04-22' and _platform_account_id in (select * from KL_players)
	group by 1) a
join
	(select date(_event_time_utc), sum(change_amount) Time_Krystals_bought_by_non_KL_players
	from seven11_prod.seven11_resource_flow
	where resource = 'Exp_PremiumCurrency' and source in ('ENTITLEMENT') and change_amount > 0 
	and date(_event_time_utc) >='2019-04-22' and _platform_account_id in (select * from non_KL_players)
	group by 1) b
on a.date = b.date	
order by 1 ;

--------------TIme Krystals Earned by players-----------------

with players as(
select player_id
from seven11_prod_da.wba_player_daily
where event_dt between '2019-04-22' and '2019-05-05'
group by 1
)
,
----------
KL_players as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 and _platform_account_id in (select * from players)
group by 1
)
,
-----------
non_KL_players as(
select player_id
from players
where player_id not in (select * from KL_players)
group by 1
)

select a.*,b.Time_Krystals_earned_by_non_KL_players
from
	(select date(_event_time_utc), sum(change_amount) Time_Krystals_earned_by_KL_players
	from seven11_prod.seven11_resource_flow
	where resource = 'Exp_PremiumCurrency' and source not in ('ENTITLEMENT','PREMIUM_SHOP') and change_amount > 0 
	and date(_event_time_utc) >='2019-04-22' and _platform_account_id in (select * from KL_players)
	group by 1) a
join
	(select date(_event_time_utc), sum(change_amount) Time_Krystals_earned_by_non_KL_players
	from seven11_prod.seven11_resource_flow
	where resource = 'Exp_PremiumCurrency' and source not in ('ENTITLEMENT','PREMIUM_SHOP') and change_amount > 0 
	and date(_event_time_utc) >='2019-04-22' and _platform_account_id in (select * from non_KL_players)
	group by 1) b
on a.date = b.date	
order by 1
;

--------------------------------------------------------------------------------------------
-----------Daily Active KL & non-KL Players-----------------------

with players as(
select player_id
from seven11_prod_da.wba_player_daily
where event_dt between '2019-04-22' and '2019-05-05'
group by 1
)
,
----------
KL_players as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and _platform_account_id in (select * from players)
group by 1)
,

daily_KL_players as(
select player_id,event_dt
from seven11_prod_da.wba_player_daily
where player_id in (select * from KL_players) 
group by 1,2
) ,

non_KL_players as(
select player_id
from players
where player_id not in (select * from KL_players)
group by 1
),

daily_Non_KL_players as(
select player_id,event_dt
from seven11_prod_da.wba_player_daily
where player_id in (select * from non_KL_players) 
group by 1,2
)

select a.*,b.non_KL_players
from
	(select event_dt, count(player_id) KL_players
	from daily_KL_players
	group by 1) a
join
	(select event_dt, count(player_id) non_KL_players
	from daily_Non_KL_players
	group by 1) b
on a.event_dt = b.event_dt	
order by 1 ;



