--- items table ----------
create table sandbox.shop_item_cleaned_names as
(
	select a.*, coalesce (b.name,'Krypt') charname
	from
	(
		select unlock_name, case when unlock_name = 'SHAWalkAway_3'  then 'SHA'  else split_part(unlock_name,'_',1) end charct, 
							case when unlock_name = 'SHAWalkAway_3'  then 'WalkAway' else split_part(unlock_name,'_',2) end itemname1,
							case when unlock_name like 'KryptUnlock%' then ('Krypt' || right(unlock_name, 4)) else left(itemname1,4) end item_name
		from seven11_prod.seven11_progression_unlock 
		where unlock_source = 'PREMIUM_SHOP' 
		and unlock_name is not null
		group by 1,2,3,4
	) a
	left join seven11_prod_da.character_lookup b
	on a.charct = b.id
)


create table sandbox.shop_currency as
(
 		select gain.item_name as item,
		gain.charname as charname,
        gain.wbanalyticssourcedate,
        spend._platform_account_id as player_id,
        spend.source,
        sum(spend.change_amount) as spend,
        count(*) as purchases
        from seven11_prod.seven11_resource_flow spend
        left join( 
				   select a.*, b.item_name, b.charname
				   from
					   (
					   select resource_flow_id, date(wbanalyticssourcedate) wbanalyticssourcedate, unlock_name
					   from seven11_prod.seven11_progression_unlock a
					   where unlock_source = 'PREMIUM_SHOP'
					   group by 1,2,3
					   ) a
				   join sandbox.shop_item_cleaned_names b
				   using(unlock_name)
				  ) gain
        on spend.resource_flow_id = gain.resource_flow_id
        where spend.resource = 'Exp_PremiumCurrency'
        --and spend.source ='PREMIUM_SHOP'
        and gain.unlock_name is not null
        and spend.change_amount <0
        group by 1,2,3,4,5

        UNION ALL

        select
        gain.resource as item,
		'Currency' as charname,
        date(gain.wbanalyticssourcedate) wbanalyticssourcedate ,
        spend._platform_account_id as player_id,
        spend.source,
        sum(spend.change_amount) as spend,
        count(*) as purchases
        from seven11_prod.seven11_resource_flow spend
        left join seven11_prod.seven11_resource_flow gain
        on spend.resource_flow_id = gain.resource_flow_id
        where spend.resource = 'Exp_PremiumCurrency'
       -- and spend.source ='PREMIUM_SHOP'
        and spend.change_amount <0
        and gain.resource is not null
        and gain.resource <> 'Exp_PremiumCurrency'
        group by 1,2,3,4,5
)



select item, charname, count(distinct player_id) players, sum(purchases) purchases, sum(spend) spends, sum(purchases)::float / players::float
from sandbox.shop_currency
where item not in ('Walk','GearXPBoost','Icon','Vict','SkipFight','TER_DamageChargedFistPunch_3','JOH_DMGNutPunch_3','SHA_DURTaunt_3','TER_DurationSandClone_3','JOH_DMGBrassKnuckles_3')
group by 1
--------
select charname,case when purchases = 1 then '1' 
					 when purchases = 2 then '2'
					 when purchases = 3 then '3'
					 when purchases = 4 then '4'
					 when purchases >= 5 then '5 and above'end, count(player_id) players,  sum(spends) spends
from
(
select charname, player_id, sum(purchases) purchases, sum(spend)::float*-1 spends
from sandbox.shop_currency
where item not in ('Walk','GearXPBoost','Icon','Vict','SkipFight','TER_DamageChargedFistPunch_3','JOH_DMGNutPunch_3','SHA_DURTaunt_3','TER_DurationSandClone_3','JOH_DMGBrassKnuckles_3')
and wbanalyticssourcedate >= '2019-04-22'
group by 1,2
)
group by 1,2
--------
select charname,case when purchases = 1 then '1' 
					 when purchases = 2 then '2'
					 when purchases = 3 then '3'
					 when purchases = 4 then '4'
					 when purchases >= 5 then '5 and above'end, count(player_id) players,  sum(spends) spends
from
(
	select charname, player_id, sum(purchases) purchases, sum(spend)::float*-1 spends
	from sandbox.shop_currency
	where item not in ('Walk','GearXPBoost','Icon','Vict','SkipFight','TER_DamageChargedFistPunch_3','JOH_DMGNutPunch_3','SHA_DURTaunt_3','TER_DurationSandClone_3','JOH_DMGBrassKnuckles_3')
	and wbanalyticssourcedate >= '2019-04-22'
	group by 1,2
)
group by 1,2
-----

select a.*, b.DAU
from
	(
		select item, wbanalyticssourcedate event_dt, count(distinct player_id) players, sum(purchases)purchases, sum(spend)::float*-1 spends
		from sandbox.shop_currency
		where item not in ('Walk','GearXPBoost','Icon','Vict','SkipFight','TER_DamageChargedFistPunch_3','JOH_DMGNutPunch_3','SHA_DURTaunt_3','TER_DurationSandClone_3','JOH_DMGBrassKnuckles_3')
		and wbanalyticssourcedate >= '2019-04-22'
		group by 1,2
	)a
	left join
	(
		select event_dt, count(player_id) DAU
		from seven11_prod_da.wba_player_daily
		where event_dt >= '2019-04-22'
		group by 1
	)b
using(event_dt)
-----

select a.*, b.DAU
from
	(
		select charname, wbanalyticssourcedate event_dt, count(distinct player_id) players, sum(purchases)purchases, sum(spend)::float*-1 spends
		from sandbox.shop_currency
		where item not in ('Walk','GearXPBoost','Icon','Vict','SkipFight','TER_DamageChargedFistPunch_3','JOH_DMGNutPunch_3','SHA_DURTaunt_3','TER_DurationSandClone_3','JOH_DMGBrassKnuckles_3')
		and wbanalyticssourcedate >= '2019-04-22'
		group by 1,2
	)a
	left join
	(
		select event_dt, count(player_id) DAU
		from seven11_prod_da.wba_player_daily
		where event_dt >= '2019-04-22'
		group by 1
	)b
using(event_dt)


