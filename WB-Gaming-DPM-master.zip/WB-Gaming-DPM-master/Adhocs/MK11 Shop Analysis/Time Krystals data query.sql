--------------TIme Krystals Bought by players-----------------
select date(_event_time_utc), sum(change_amount) Time_Krystals_bought_by_players
from seven11_prod.seven11_resource_flow
where resource = 'Exp_PremiumCurrency' and source in ('ENTITLEMENT') and change_amount > 0 and date(_event_time_utc) >='2019-04-22'
group by 1
order by 1

--------------TIme Krystals Earned by players-----------------
select date(_event_time_utc), sum(change_amount) Time_Krystals_earned_by_players
from seven11_prod.seven11_resource_flow
where resource = 'Exp_PremiumCurrency' and source not in ('ENTITLEMENT','PREMIUM_SHOP') and change_amount > 0 and date(_event_time_utc) >='2019-04-22'
group by 1
order by 1

-----------Time krystals Spent in Game-----------------------
select date(_event_time_utc), sum(change_amount) Time_Krystals_spent_in_game
from seven11_prod.seven11_resource_flow
where resource = 'Exp_PremiumCurrency' and source in ('PREMIUM_SHOP') and change_amount < 0 and date(_event_time_utc) >='2019-04-22'
group by 1
order by 1

---------------Time Krystals earned by each source----------- 
select date(_event_time_utc), source, sum(change_amount) Time_Krystals_earned_in_game
from seven11_prod.seven11_resource_flow
where resource = 'Exp_PremiumCurrency' and change_amount > 0 and date(_event_time_utc) >='2019-04-22'
group by 1,2
order by 1,2
