----------- - NoN Kombat pack owners Engagement for KL active players

with players as(
SELECT player_id
FROM seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-05-06' 
group by 1) ,

kombat_pack_Shang_tsung_players as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version','shang_tsung','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack_Shang_tsung
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
group by 1
having kombat_pack_Shang_tsung =1),

No_kombat_pack_Shang_tsung_players as(
select player_id
from players
where player_id not in (select _platform_account_id from kombat_pack_Shang_tsung_players)
group by 1)  ,

KL_Players_with_no_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select * from No_kombat_pack_Shang_tsung_players)
group by 1) ,

Non_KL_Players_with_no_kombat_pack as(
select player_id
from No_kombat_pack_Shang_tsung_players
where player_id not in (select * from KL_Players_with_no_kombat_pack)
group by 1),

week_num as (select date(event_dt) date,
		case when date(event_dt) between '2019-05-07' and '2019-05-13' then 'w1'
			when date(event_dt) between '2019-05-14' and '2019-05-20' then 'w2'
			when date(event_dt) between '2019-05-21' and '2019-05-27' then 'w3'
			when date(event_dt) between '2019-05-28' and '2019-06-03' then 'w4'
			when date(event_dt) between '2019-06-04' and '2019-06-10' then 'w5'
			when date(event_dt) between '2019-06-11' and '2019-06-17' then 'w6'
			when date(event_dt) between '2019-06-18' and '2019-06-24' then 'w7'
			when date(event_dt) between '2019-06-25' and '2019-07-01' then 'w8'
			when date(event_dt) between '2019-07-02' and '2019-07-08' then 'w9'
			when date(event_dt) between '2019-07-09' and '2019-07-15' then 'w10'
			when date(event_dt) between '2019-07-16' and '2019-07-22' then 'w11'
			when date(event_dt) between '2019-07-23' and '2019-07-29' then 'w12'
			else 'other' end as Week_number
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-05-07' and '2019-07-29'	
group by 1,2
having week_number not in ('other'))

select *
from(
	select  a.Week_number,Avg(Hours) Avg_hours,Avg(days_played) Avg_days_played
	from(
		select Week_number,player_id,Sum(total_hours)::float Hours
		from (select a.*,b. Week_number
		from seven11_prod_da.wba_player_daily a
		join week_num b
		on date(event_dt) = date)
		where player_id in (select * from KL_Players_with_no_kombat_pack)
		group by 1,2) a
	join (
		select Week_number,player_id,count(distinct date(event_dt) )::float days_played
		from (select a.*,b. Week_number
		from  seven11_prod_da.wba_fact_activity  a
		join week_num b
		on date(event_dt) = date)
		where player_id in (select * from KL_Players_with_no_kombat_pack)
		group by 1,2) b
	on a.player_id = b.player_id 
	and a.Week_number = b.Week_number
	group by 1
)
cross join
(
select count(distinct _platform_account_id) Total_players
from KL_Players_with_no_kombat_pack );

----------- - NoN Kombat pack owners Engagement for Non KL active players

with players as(
SELECT player_id
FROM seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-05-06' 
group by 1) ,

kombat_pack_Shang_tsung_players as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version','shang_tsung','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack_Shang_tsung
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
group by 1
having kombat_pack_Shang_tsung =1),

No_kombat_pack_Shang_tsung_players as(
select player_id
from players
where player_id not in (select _platform_account_id from kombat_pack_Shang_tsung_players)
group by 1) ,

KL_Players_with_no_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select * from No_kombat_pack_Shang_tsung_players)
group by 1) ,

Non_KL_Players_with_no_kombat_pack as(
select player_id
from No_kombat_pack_Shang_tsung_players
where player_id not in (select * from KL_Players_with_no_kombat_pack)
group by 1),

week_num as (select date(event_dt) date,
		case when date(event_dt) between '2019-05-07' and '2019-05-13' then 'w1'
			when date(event_dt) between '2019-05-14' and '2019-05-20' then 'w2'
			when date(event_dt) between '2019-05-21' and '2019-05-27' then 'w3'
			when date(event_dt) between '2019-05-28' and '2019-06-03' then 'w4'
			when date(event_dt) between '2019-06-04' and '2019-06-10' then 'w5'
			when date(event_dt) between '2019-06-11' and '2019-06-17' then 'w6'
			when date(event_dt) between '2019-06-18' and '2019-06-24' then 'w7'
			when date(event_dt) between '2019-06-25' and '2019-07-01' then 'w8'
			when date(event_dt) between '2019-07-02' and '2019-07-08' then 'w9'
			when date(event_dt) between '2019-07-09' and '2019-07-15' then 'w10'
			when date(event_dt) between '2019-07-16' and '2019-07-22' then 'w11'
			when date(event_dt) between '2019-07-23' and '2019-07-29' then 'w12'
			else 'other' end as Week_number
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-05-07' and '2019-07-29'	
group by 1,2
having week_number not in ('other'))

select *
from(
	select  a.Week_number,Avg(Hours) Avg_hours,Avg(days_played) Avg_days_played
	from(
		select Week_number,player_id,Sum(total_hours)::float Hours
		from (select a.*,b. Week_number
		from seven11_prod_da.wba_player_daily a
		join week_num b
		on date(event_dt) = date)
		where player_id in (select * from Non_KL_Players_with_no_kombat_pack)
		group by 1,2) a
	join (
		select Week_number,player_id,count(distinct date(event_dt) )::float days_played
		from (select a.*,b. Week_number
		from  seven11_prod_da.wba_fact_activity  a
		join week_num b
		on date(event_dt) = date)
		where player_id in (select * from Non_KL_Players_with_no_kombat_pack)
		group by 1,2) b
	on a.player_id = b.player_id 
	and a.Week_number = b.Week_number
	group by 1
)
cross join
(
select count(distinct player_id) Total_players
from Non_KL_Players_with_no_kombat_pack );
 ;

----------- Kombat pack owners Engagement for KL active players

with players as(
SELECT player_id
FROM seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-05-06' 
group by 1) ,

kombat_pack_players as(
select _platform_account_id player_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
and _platform_account_id in (select player_id from players)
group by 1
having kombat_pack =1),

KL_Players_with_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select player_id from kombat_pack_players)
group by 1) ,

Non_KL_Players_with_kombat_pack as(
select player_id
from kombat_pack_players
where player_id not in (select * from KL_Players_with_kombat_pack)
group by 1) ,

week_num as (select date(event_dt) date,
		case when date(event_dt) between '2019-05-07' and '2019-05-13' then 'w1'
			when date(event_dt) between '2019-05-14' and '2019-05-20' then 'w2'
			when date(event_dt) between '2019-05-21' and '2019-05-27' then 'w3'
			when date(event_dt) between '2019-05-28' and '2019-06-03' then 'w4'
			when date(event_dt) between '2019-06-04' and '2019-06-10' then 'w5'
			when date(event_dt) between '2019-06-11' and '2019-06-17' then 'w6'
			when date(event_dt) between '2019-06-18' and '2019-06-24' then 'w7'
			when date(event_dt) between '2019-06-25' and '2019-07-01' then 'w8'
			when date(event_dt) between '2019-07-02' and '2019-07-08' then 'w9'
			when date(event_dt) between '2019-07-09' and '2019-07-15' then 'w10'
			when date(event_dt) between '2019-07-16' and '2019-07-22' then 'w11'
			when date(event_dt) between '2019-07-23' and '2019-07-29' then 'w12'
			else 'other' end as Week_number
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-05-07' and '2019-07-29'	
group by 1,2
having week_number not in ('other'))

select *
from(
	select  a.Week_number,Avg(Hours) Avg_hours,Avg(days_played) Avg_days_played
	from(
		select Week_number,player_id,Sum(total_hours)::float Hours
		from (select a.*,b. Week_number
		from seven11_prod_da.wba_player_daily a
		join week_num b
		on date(event_dt) = date)
		where player_id in (select * from KL_Players_with_kombat_pack)
		group by 1,2) a
	join (
		select Week_number,player_id,count(distinct date(event_dt) )::float days_played
		from (select a.*,b. Week_number
		from  seven11_prod_da.wba_fact_activity  a
		join week_num b
		on date(event_dt) = date)
		where player_id in (select * from KL_Players_with_kombat_pack)
		group by 1,2) b
	on a.player_id = b.player_id 
	and a.Week_number = b.Week_number
	group by 1
)
cross join
(
select count(distinct _platform_account_id) Total_players
from KL_Players_with_kombat_pack );

----------- Kombat pack owners Engagement for Non KL active players

with players as(
SELECT player_id
FROM seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-05-06' 
group by 1) ,

kombat_pack_players as(
select _platform_account_id player_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
and _platform_account_id in (select player_id from players)
group by 1
having kombat_pack =1),

KL_Players_with_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select player_id from kombat_pack_players)
group by 1) ,

Non_KL_Players_with_kombat_pack as(
select player_id
from kombat_pack_players
where player_id not in (select * from KL_Players_with_kombat_pack)
group by 1),

week_num as (select date(event_dt) date,
		case when date(event_dt) between '2019-05-07' and '2019-05-13' then 'w1'
			when date(event_dt) between '2019-05-14' and '2019-05-20' then 'w2'
			when date(event_dt) between '2019-05-21' and '2019-05-27' then 'w3'
			when date(event_dt) between '2019-05-28' and '2019-06-03' then 'w4'
			when date(event_dt) between '2019-06-04' and '2019-06-10' then 'w5'
			when date(event_dt) between '2019-06-11' and '2019-06-17' then 'w6'
			when date(event_dt) between '2019-06-18' and '2019-06-24' then 'w7'
			when date(event_dt) between '2019-06-25' and '2019-07-01' then 'w8'
			when date(event_dt) between '2019-07-02' and '2019-07-08' then 'w9'
			when date(event_dt) between '2019-07-09' and '2019-07-15' then 'w10'
			when date(event_dt) between '2019-07-16' and '2019-07-22' then 'w11'
			when date(event_dt) between '2019-07-23' and '2019-07-29' then 'w12'
			else 'other' end as Week_number
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-05-07' and '2019-07-29'	
group by 1,2
having week_number not in ('other'))

select *
from(
	select  a.Week_number,Avg(Hours) Avg_hours,Avg(days_played) Avg_days_played
	from(
		select Week_number,player_id,Sum(total_hours)::float Hours
		from (select a.*,b. Week_number
		from seven11_prod_da.wba_player_daily a
		join week_num b
		on date(event_dt) = date)
		where player_id in (select * from Non_KL_Players_with_kombat_pack)
		group by 1,2) a
	join (
		select Week_number,player_id,count(distinct date(event_dt) )::float days_played
		from (select a.*,b. Week_number
		from  seven11_prod_da.wba_fact_activity  a
		join week_num b
		on date(event_dt) = date)
		where player_id in (select * from Non_KL_Players_with_kombat_pack)
		group by 1,2) b
	on a.player_id = b.player_id 
	and a.Week_number = b.Week_number
	group by 1
)
cross join
(
select count(distinct player_id) Total_players
from Non_KL_Players_with_kombat_pack )
 ;