------------ NoN Kombat pack owners Engagement for Non KL active players -Game mode level

with players as(
SELECT player_id
FROM seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-05-06' 
group by 1) ,

Active_Players  as (
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-06-18' and '2019-07-16' 
and Player_id in (select * from players)
group by 1 ) ,

kombat_pack_Shang_tsung_players as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version','shang_tsung','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack_Shang_tsung
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
group by 1
having kombat_pack_Shang_tsung =1),

No_kombat_pack_Shang_tsung_players as(
select player_id
from Active_Players
where player_id not in (select _platform_account_id from kombat_pack_Shang_tsung_players)
group by 1)  ,

KL_Players_with_no_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select * from No_kombat_pack_Shang_tsung_players)
group by 1) ,

Non_KL_Players_with_no_kombat_pack as(
select player_id
from No_kombat_pack_Shang_tsung_players
where player_id not in (select * from KL_Players_with_no_kombat_pack)
group by 1),

week_num as (select date(event_dt) date,
		case when date(event_dt) between '2019-05-07' and '2019-05-13' then 'w1'
			when date(event_dt) between '2019-05-14' and '2019-05-20' then 'w2'
			when date(event_dt) between '2019-05-21' and '2019-05-27' then 'w3'
			when date(event_dt) between '2019-05-28' and '2019-06-03' then 'w4'
			when date(event_dt) between '2019-06-04' and '2019-06-10' then 'w5'
			when date(event_dt) between '2019-06-11' and '2019-06-17' then 'w6'
			when date(event_dt) between '2019-06-18' and '2019-06-24' then 'w7'
			when date(event_dt) between '2019-06-25' and '2019-07-01' then 'w8'
			when date(event_dt) between '2019-07-02' and '2019-07-08' then 'w9'
			when date(event_dt) between '2019-07-09' and '2019-07-15' then 'w10'
			when date(event_dt) between '2019-07-16' and '2019-07-22' then 'w11'
			when date(event_dt) between '2019-07-23' and '2019-07-29' then 'w12'
			else 'other' end as Week_number
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-05-07' and '2019-07-29'	
group by 1,2
having week_number not in ('other'))


	select  a.Week_number,Game_mode,(Hours_played)/ players Avg_hours
	from(
		select Week_number,
		case when activity_name in ('GM_STORY_OFF') then 'story'
	 	when activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT') then 'PvP_Online'
	 	when activity_name in ('GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER','GM_KLASSIC_PORTAL_MODE','GM_KLASSIC_PORTAL_MODE_LADDER') then 'Towers'
	 	when activity_name in ('GM_FATALITY_TUTORIAL','GM_TUTORIAL_OFFLINE','GM_PRACTICE') then 'Tutorial'
	 	when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF') then 'PvP_Offline'
	 	when activity_name in ('GM_LOCAL_VERSUS_OFF','GM_AI_FIGHTER') then 'PvE_Offline'
	 	else 'Others' END AS Game_mode,sum(activity_hours)::float Hours_played
		from (select a.*,b. Week_number
		from  seven11_prod_da.wba_fact_activity  a
		join week_num b
		on date(event_dt) = date)
		where player_id in (select * from Non_KL_Players_with_no_kombat_pack)
		group by 1,2) a
left join
(
	select Week_number,count(distinct player_id)::float players
		from (select a.*,b. Week_number
		from  seven11_prod_da.wba_fact_activity  a
		join week_num b
		on date(event_dt) = date)
		where player_id in (select * from Non_KL_Players_with_no_kombat_pack)
		group by 1) b
on a.Week_number= b.Week_number
;

----------- - NoN Kombat pack owners Engagement for Non KL active players-- Weekly hours fact activity table

with players as(
SELECT player_id
FROM seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-05-06' 
group by 1) ,

Active_Players  as (
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-06-18' and '2019-07-16' 
and Player_id in (select * from players)
group by 1 ) ,

kombat_pack_Shang_tsung_players as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version','shang_tsung','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack_Shang_tsung
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
group by 1
having kombat_pack_Shang_tsung =1),

No_kombat_pack_Shang_tsung_players as(
select player_id
from Active_Players
where player_id not in (select _platform_account_id from kombat_pack_Shang_tsung_players)
group by 1)  ,

KL_Players_with_no_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select * from No_kombat_pack_Shang_tsung_players)
group by 1) ,

Non_KL_Players_with_no_kombat_pack as(
select player_id
from No_kombat_pack_Shang_tsung_players
where player_id not in (select * from KL_Players_with_no_kombat_pack)
group by 1),

week_num as (select date(event_dt) date,
		case when date(event_dt) between '2019-05-07' and '2019-05-13' then 'w1'
			when date(event_dt) between '2019-05-14' and '2019-05-20' then 'w2'
			when date(event_dt) between '2019-05-21' and '2019-05-27' then 'w3'
			when date(event_dt) between '2019-05-28' and '2019-06-03' then 'w4'
			when date(event_dt) between '2019-06-04' and '2019-06-10' then 'w5'
			when date(event_dt) between '2019-06-11' and '2019-06-17' then 'w6'
			when date(event_dt) between '2019-06-18' and '2019-06-24' then 'w7'
			when date(event_dt) between '2019-06-25' and '2019-07-01' then 'w8'
			when date(event_dt) between '2019-07-02' and '2019-07-08' then 'w9'
			when date(event_dt) between '2019-07-09' and '2019-07-15' then 'w10'
			when date(event_dt) between '2019-07-16' and '2019-07-22' then 'w11'
			when date(event_dt) between '2019-07-23' and '2019-07-29' then 'w12'
			else 'other' end as Week_number
from seven11_prod_da.wba_player_daily 
where date(event_dt) between '2019-05-07' and '2019-07-29'	
group by 1,2
having week_number not in ('other'))


	select  Week_number,Avg(Hours_played) weekly_hours
	from(
		select Week_number,player_id,sum(activity_hours)::float Hours_played
		from (select a.*,b. Week_number
		from  seven11_prod_da.wba_fact_activity  a
		join week_num b
		on date(event_dt) = date)
		where player_id in (select * from Non_KL_Players_with_no_kombat_pack)
		group by 1,2)
	group by 1

;
