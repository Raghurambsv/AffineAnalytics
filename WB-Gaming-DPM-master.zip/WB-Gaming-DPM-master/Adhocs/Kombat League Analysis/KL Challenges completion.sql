---------Total Completions
select count( _platform_account_id) players,
	Sum(case when pints_of_blood >= 10000 then 1 else 0 end )  blood_spilt ,
	Sum(case when Krushing_blows >= 10 then 1 else 0 end )  fatal_blows,
	Sum(case when Kombat_league_sets >= 15 then 1 else 0 end )  kl_sets,
	Sum(case when pints_of_blood >= 10000 and Krushing_blows >= 10 and Kombat_league_sets >= 15  then 1 else 0 end )  All_three
from(
select _platform_account_id, Sum(total_blood_spilt) Pints_of_blood,
Sum(krushing_blows) Krushing_blows,Sum(ranked_set_end) Kombat_league_sets
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and date(_event_time_utc) between '2019-06-18' and '2019-07-16'
group by 1)

;
---Pints of blood challenge completion ---------distribution by hours taken----------------------

with blood_challenge_completers as(
select _platform_account_id
from(
select _platform_account_id, Sum(total_blood_spilt) Pints_of_blood,
Sum(krushing_blows) Krushing_blows,Sum(ranked_set_end) Kombat_league_sets
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and date(_event_time_utc) between '2019-06-18' and '2019-07-16'
group by 1)
where pints_of_blood >= 10000 
group by 1)
	
select Ceiling(blood_spilt_Hours) blood_spilt_Hours,count(_platform_account_id) player_count
from (
select _platform_account_id,Sum(match_length)::float/3600 blood_spilt_Hours
from(
select _platform_account_id,match_length,cuml_blood_spilt,
case when cuml_blood_spilt >=10000 then 1 else 0 end as challenge_compl,
LAG(challenge_compl,0) OVER (partition by _platform_account_id ORDER BY _event_time_utc) previous_row,
previous_row+challenge_compl flag
from(
select  _platform_account_id,match_length,total_blood_spilt,_event_time_utc,Sum(total_blood_spilt)over( partition by _platform_account_id order by _event_time_utc Rows unbounded preceding) cuml_blood_spilt
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and date(_event_time_utc) between '2019-06-18' and '2019-07-16'
and _platform_account_id in (select * from blood_challenge_completers)
)
)
where flag <=1  
group by 1)
group by 1
order by 1 ;

---Fatal blows challenge completion ---------distribution by hours taken----------------------

with Krushing_blows_completers as(
select _platform_account_id
from(
select _platform_account_id, Sum(total_blood_spilt) Pints_of_blood,
Sum(krushing_blows) Krushing_blows,Sum(ranked_set_end) Kombat_league_sets
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and date(_event_time_utc) between '2019-06-18' and '2019-07-16'
group by 1)
where Krushing_blows >= 10
group by 1)

select Ceiling(Krushing_blows_Hours) Krushing_blows_Hours,count(_platform_account_id) player_count
from (
select _platform_account_id,Sum(match_length)::float/3600 Krushing_blows_Hours
from(
select _platform_account_id,match_length,Krushing_blows_count,
case when Krushing_blows_count >=10 then 1 else 0 end as challenge_compl,
LAG(challenge_compl,0) OVER (partition by _platform_account_id ORDER BY _event_time_utc) previous_row,
previous_row+challenge_compl flag
from(
select  _platform_account_id,match_length,Krushing_blows,_event_time_utc,Sum(Krushing_blows)over( partition by _platform_account_id order by _event_time_utc Rows unbounded preceding) Krushing_blows_count
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and date(_event_time_utc) between '2019-06-18' and '2019-07-16'
and _platform_account_id in (select * from Krushing_blows_completers)
)
)
where flag <=1 
group by 1)
group by 1
order by 1 ;

---KL Sets challenge completion ---------distribution by hours taken----------------------


with KL_Sets_completers as(
select _platform_account_id
from(
select _platform_account_id, Sum(total_blood_spilt) Pints_of_blood,
Sum(krushing_blows) Krushing_blows,Sum(ranked_set_end) Kombat_league_sets
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and date(_event_time_utc) between '2019-06-18' and '2019-07-16'
group by 1)
where Kombat_league_sets >= 15
group by 1)

select Ceiling(KL_Sets_Hours) KL_Sets_Hours,count(_platform_account_id) player_count
from (
select _platform_account_id,Sum(match_length)::float/3600 KL_Sets_Hours
from(
select _platform_account_id,match_length,KL_sets_Comp,
case when KL_sets_Comp >=15 then 1 else 0 end as challenge_compl,
LAG(challenge_compl,0) OVER (partition by _platform_account_id ORDER BY _event_time_utc) previous_row,
previous_row+challenge_compl flag
from(
select  _platform_account_id,match_length,ranked_set_end ,_event_time_utc,Sum(ranked_set_end )over( partition by _platform_account_id order by _event_time_utc Rows unbounded preceding) KL_sets_Comp
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and date(_event_time_utc) between '2019-06-18' and '2019-07-16'
and _platform_account_id in (select * from KL_Sets_completers)
)
)
where flag <=1 
group by 1)
group by 1
order by 1 ;
---------------------------------------------------------------------------------
---Pints of blood challenge completion ---------distribution by matches played----------------------

with blood_challenge_completers as(
select _platform_account_id
from(
select _platform_account_id, Sum(total_blood_spilt) Pints_of_blood,
Sum(krushing_blows) Krushing_blows,Sum(ranked_set_end) Kombat_league_sets
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and date(_event_time_utc) between '2019-06-18' and '2019-07-16'
group by 1)
where pints_of_blood >= 10000 
group by 1)
	
select ceiling(blood_spilt_matches/10)*10 blood_spilt_matches,count(_platform_account_id) player_count
from (
select _platform_account_id,count(distinct match_id)::float blood_spilt_matches
from(
select _platform_account_id,match_id,cuml_blood_spilt,
case when cuml_blood_spilt >=10000 then 1 else 0 end as challenge_compl,
LAG(challenge_compl,0) OVER (partition by _platform_account_id ORDER BY _event_time_utc) previous_row,
previous_row+challenge_compl flag
from(
select  _platform_account_id,match_id,total_blood_spilt,_event_time_utc,Sum(total_blood_spilt)over( partition by _platform_account_id order by _event_time_utc Rows unbounded preceding) cuml_blood_spilt
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and date(_event_time_utc) between '2019-06-18' and '2019-07-16'
and _platform_account_id in (select * from blood_challenge_completers)
)
)
where flag <=1  
group by 1)
group by 1
order by 1 ;

---Krushing blows challenge completion ---------distribution by matches played----------------------

with Krushing_blows_completers as(
select _platform_account_id
from(
select _platform_account_id, Sum(total_blood_spilt) Pints_of_blood,
Sum(krushing_blows) Krushing_blows,Sum(ranked_set_end) Kombat_league_sets
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and date(_event_time_utc) between '2019-06-18' and '2019-07-16'
group by 1)
where Krushing_blows >= 10
group by 1)

select ceiling(Krushing_blows_matches/10)*10 Krushing_blows_matches,count(_platform_account_id) player_count
from (
select _platform_account_id,count(distinct match_id)::float Krushing_blows_matches
from(
select _platform_account_id,match_id,Krushing_blows_count,
case when Krushing_blows_count >=10 then 1 else 0 end as challenge_compl,
LAG(challenge_compl,0) OVER (partition by _platform_account_id ORDER BY _event_time_utc) previous_row,
previous_row+challenge_compl flag
from(
select  _platform_account_id,match_id,Krushing_blows,_event_time_utc,Sum(Krushing_blows)over( partition by _platform_account_id order by _event_time_utc Rows unbounded preceding) Krushing_blows_count
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and date(_event_time_utc) between '2019-06-18' and '2019-07-16'
and _platform_account_id in (select * from Krushing_blows_completers)
)
)
where flag <=1 
group by 1)
group by 1
order by 1 ;

-- KL Sets  challenge completion ---------distribution by matches played----------------------


with KL_Sets_completers as(
select _platform_account_id
from(
select _platform_account_id, Sum(total_blood_spilt) Pints_of_blood,
Sum(krushing_blows) Krushing_blows,Sum(ranked_set_end) Kombat_league_sets
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and date(_event_time_utc) between '2019-06-18' and '2019-07-16'
group by 1)
where Kombat_league_sets >= 15
group by 1)

select ceiling(KL_Sets_matches/10)*10 KL_Sets_matches,count(_platform_account_id) player_count
from (
select _platform_account_id,count(distinct match_id)::float KL_Sets_matches
from(
select _platform_account_id,match_id,KL_sets_Comp,
case when KL_sets_Comp >=15 then 1 else 0 end as challenge_compl,
LAG(challenge_compl,0) OVER (partition by _platform_account_id ORDER BY _event_time_utc) previous_row,
previous_row+challenge_compl flag
from(
select  _platform_account_id,match_id,ranked_set_end ,_event_time_utc,Sum(ranked_set_end )over( partition by _platform_account_id order by _event_time_utc Rows unbounded preceding) KL_sets_Comp
from seven11_prod.seven11_match_result_player
where match_season = 'ranked-1' and ai_difficulty = -1 
and date(_event_time_utc) between '2019-06-18' and '2019-07-16'
and _platform_account_id in (select * from KL_Sets_completers)
)
)
where flag <=1 
group by 1)
group by 1
order by 1