--------- % of sessions in each bucket

with match_result as(
select _platform_account_id,_session_id, min(date(wbanalyticssourcedate)) date 
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
group by 1,2
)


select case when gap <=2 then '<=2'
			when gap in (3,4) then '3-4'
			when gap in (5,6,7) then '5-7'
			when gap > 7 then '7+'
			else '1st session' end as Day_gap,count( _session_id) sessions_count,
			sum(sessions_count) over () tot, count( _session_id)::float /  sum(sessions_count) over () perc
from(
select _session_id, date,LAG (date ) OVER (  partition by _platform_account_id   order by date ) previous_date,
		DATEDIFF(day,previous_date ,date) gap
from match_result
---where _platform_account_id in ('2535459402031476')
order by 3)
group by 1 ;



--------------Avg of percent times penalized

with match_result as(
select _platform_account_id,_session_id, min(date(wbanalyticssourcedate)) date 
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
group by 1,2
)

select Avg(perc)
from(
select _platform_account_id,Sum(penlz)::float /  count(penlz) perc
from(
select _platform_account_id,_session_id,case when gap >2 then 1
			else 0 end as penlz
from(
select _platform_account_id,_session_id, date,LAG (date ) OVER (  partition by _platform_account_id   order by date ) previous_date,
		DATEDIFF(day,previous_date ,date) gap
from match_result
)
group by 1,2,3)
group by 1);


--------------Player count,Avg Sessions played, Avg times penalized for % penalized buckets

with match_result as(
select _platform_account_id,_session_id, min(date(wbanalyticssourcedate)) date 
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
group by 1,2
)

select ceiling(perc*20)*5 perc_penlz,count(_platform_account_id),Avg(sessions) Avg_sessions, Avg(penlz) Avg_penlz
from(
select _platform_account_id,count(_session_id) sessions,Sum(penlz) penlz,Sum(penlz)::float /  count(penlz) perc
from(
select _platform_account_id,_session_id,case when gap >2 then 1
			else 0 end as penlz
from(
select _platform_account_id,_session_id, date,LAG (date ) OVER (  partition by _platform_account_id   order by date ) previous_date,
		DATEDIFF(day,previous_date ,date) gap
from match_result
)
group by 1,2,3)
group by 1)
group by 1;

