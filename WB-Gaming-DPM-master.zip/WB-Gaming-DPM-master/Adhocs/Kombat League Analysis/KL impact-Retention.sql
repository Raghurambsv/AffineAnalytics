----------- - NoN Kombat pack owners Engagement for KL active players

with players as(
SELECT player_id
FROM seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-05-06' 
group by 1) ,

kombat_pack_Shang_tsung_players as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version','shang_tsung','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack_Shang_tsung
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
group by 1
having kombat_pack_Shang_tsung =1),

No_kombat_pack_Shang_tsung_players as(
select player_id
from players
where player_id not in (select _platform_account_id from kombat_pack_Shang_tsung_players)
group by 1)  ,

KL_Players_with_no_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select * from No_kombat_pack_Shang_tsung_players)
group by 1) ,

Non_KL_Players_with_no_kombat_pack as(
select player_id
from No_kombat_pack_Shang_tsung_players
where player_id not in (select * from KL_Players_with_no_kombat_pack)
group by 1)

select period, joindate, count(c.player_id) retained_players, count(b.player_id) cohorts
from
(
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-05-06 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-08-06 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-04-22 00:00:00')
    AND (d2.YearMonthDay>='2019-04-22 00:00:00')
	order by 1,2
) A
join 
(
		select player_id, min(event_dt) yearmonthday
        from seven11_prod_da.wba_fact_activity a
		where event_dt between '2019-04-22' and '2019-05-06' 
		and player_id in (select * from KL_Players_with_no_kombat_pack)
        group by 1

    )  B
on a.joinDate = b.yearmonthday 
left join
(
      select event_dt yearmonthday, player_id
 	  from seven11_prod_da.wba_fact_activity a
	  where event_dt between '2019-04-22' and '2019-08-06' 
	  and player_id in (select * from KL_Players_with_no_kombat_pack)
      group by 1,2
    ) c
on b.player_id = c.player_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-04-22 00:00:00'
group by 1,2
order by 1,2 ;


----------- - NoN Kombat pack owners Engagement for Non KL active players

with players as(
SELECT player_id
FROM seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-05-06' 
group by 1) ,

kombat_pack_Shang_tsung_players as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version','shang_tsung','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack_Shang_tsung
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
group by 1
having kombat_pack_Shang_tsung =1),

No_kombat_pack_Shang_tsung_players as(
select player_id
from players
where player_id not in (select _platform_account_id from kombat_pack_Shang_tsung_players)
group by 1) ,

KL_Players_with_no_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select * from No_kombat_pack_Shang_tsung_players)
group by 1) ,

Non_KL_Players_with_no_kombat_pack as(
select player_id
from No_kombat_pack_Shang_tsung_players
where player_id not in (select * from KL_Players_with_no_kombat_pack)
group by 1)

select period, joindate, count(c.player_id) retained_players, count(b.player_id) cohorts
from
(
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-05-06 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-08-06 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-04-22 00:00:00')
    AND (d2.YearMonthDay>='2019-04-22 00:00:00')
	order by 1,2
) A
join 
(
		select player_id, min(event_dt) yearmonthday
        from seven11_prod_da.wba_fact_activity a
		where event_dt between '2019-04-22' and '2019-05-06' 
		and player_id in (select * from Non_KL_Players_with_no_kombat_pack)
        group by 1

    )  B
on a.joinDate = b.yearmonthday 
left join
(
      select event_dt yearmonthday, player_id
 	  from seven11_prod_da.wba_fact_activity a
	  where event_dt between '2019-04-22' and '2019-08-06' 
	  and player_id in (select * from Non_KL_Players_with_no_kombat_pack)
      group by 1,2
    ) c
on b.player_id = c.player_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-04-22 00:00:00'
group by 1,2
order by 1,2 ;


----------- Kombat pack owners Engagement for KL active players

with players as(
SELECT player_id
FROM seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-05-06' 
group by 1) ,

kombat_pack_players as(
select _platform_account_id player_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
and _platform_account_id in (select player_id from players)
group by 1
having kombat_pack =1),

KL_Players_with_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select player_id from kombat_pack_players)
group by 1) ,

Non_KL_Players_with_kombat_pack as(
select player_id
from kombat_pack_players
where player_id not in (select * from KL_Players_with_kombat_pack)
group by 1) 

select period, joindate, count(c.player_id) retained_players, count(b.player_id) cohorts
from
(
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-05-06 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-08-06 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-04-22 00:00:00')
    AND (d2.YearMonthDay>='2019-04-22 00:00:00')
	order by 1,2
) A
join 
(
		select player_id, min(event_dt) yearmonthday
        from seven11_prod_da.wba_fact_activity a
		where event_dt between '2019-04-22' and '2019-05-06' 
		and player_id in (select * from KL_Players_with_kombat_pack)
        group by 1

    )  B
on a.joinDate = b.yearmonthday 
left join
(
      select event_dt yearmonthday, player_id
 	  from seven11_prod_da.wba_fact_activity a
	  where event_dt between '2019-04-22' and '2019-08-06' 
	  and player_id in (select * from KL_Players_with_kombat_pack)
      group by 1,2
    ) c
on b.player_id = c.player_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-04-22 00:00:00'
group by 1,2
order by 1,2 ;


----------- Kombat pack owners Engagement for Non KL active players

with players as(
SELECT player_id
FROM seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-05-06' 
group by 1) ,

kombat_pack_players as(
select _platform_account_id player_id, 
			max(case when entitlement_name in ('kombat_pack','premium_edition_skin','shang_tsung_kombat_pack_version','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
and _platform_account_id in (select player_id from players)
group by 1
having kombat_pack =1),

KL_Players_with_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select player_id from kombat_pack_players)
group by 1) ,

Non_KL_Players_with_kombat_pack as(
select player_id
from kombat_pack_players
where player_id not in (select * from KL_Players_with_kombat_pack)
group by 1)

select period, joindate, count(c.player_id) retained_players, count(b.player_id) cohorts
from
(
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-05-06 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-04-22 00:00:00' and '2019-08-06 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-04-22 00:00:00')
    AND (d2.YearMonthDay>='2019-04-22 00:00:00')
	order by 1,2
) A
join 
(
		select player_id, min(event_dt) yearmonthday
        from seven11_prod_da.wba_fact_activity a
		where event_dt between '2019-04-22' and '2019-05-06' 
		and player_id in (select * from Non_KL_Players_with_kombat_pack)
        group by 1

    )  B
on a.joinDate = b.yearmonthday 
left join
(
      select event_dt yearmonthday, player_id
 	  from seven11_prod_da.wba_fact_activity a
	  where event_dt between '2019-04-22' and '2019-08-06' 
	  and player_id in (select * from Non_KL_Players_with_kombat_pack)
      group by 1,2
    ) c
on b.player_id = c.player_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-04-22 00:00:00'
group by 1,2
order by 1,2 ;
