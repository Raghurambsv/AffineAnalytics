----------- Non Kombat Pack and Shangtsung Players Engagement post and prior KL

----------- - NoN Kombat pack owners Engagement 15 days before and after KL Launch for KL active players

with day_window as(
select 14 days
),

Active_Players  as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-06-18' and '2019-07-16' 
group by 1 ) ,

kombat_pack_Shang_tsung_players as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','shang_tsung') 
			then 1 else 0 end) kombat_pack_Shang_tsung
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
group by 1
having kombat_pack_Shang_tsung =1),

No_kombat_pack_Shang_tsung_players as(
select player_id
from Active_Players
where player_id not in (select _platform_account_id from kombat_pack_Shang_tsung_players)
group by 1) ,

KL_Players_with_no_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select * from No_kombat_pack_Shang_tsung_players)
group by 1) ,

Non_KL_Players_with_no_kombat_pack as(
select player_id
from No_kombat_pack_Shang_tsung_players
where player_id not in (select * from KL_Players_with_no_kombat_pack)
group by 1)

select *
from(
	select  Avg(days_played) Avg_days_played_post_kl,Avg(no_of_sessions) Avg_sessions_post_kl,Avg(Hours) Avg_hours_post_kl,sum(Hours)/sum(no_of_sessions) Session_length_post_kl
	from(
		select player_id,sum(session_count)::float no_of_sessions,Sum(total_hours)::float Hours
		from 
			(select *
			 from seven11_prod_da.wba_player_daily 
			 cross join day_window)
		where date(event_dt) between '2019-06-18' and dateadd(day,days,'2019-06-18')
		and player_id in (select * from KL_Players_with_no_kombat_pack)
		group by 1) a
	join (
		select player_id,count(distinct date(event_dt) )::float days_played
		from 
			(select *
			 from seven11_prod_da.wba_fact_activity 
			 cross join day_window)
		where date(event_dt) between '2019-06-18' and dateadd(day,days,'2019-06-18')
		and player_id in (select * from KL_Players_with_no_kombat_pack)
		group by 1) b
	on a.player_id = b.player_id
)
cross join(
	select  Avg(days_played) Avg_days_played_prior_kl,Avg(no_of_sessions) Avg_sessions_prior_kl,Avg(Hours) Avg_hours_prior_kl,sum(Hours)/sum(no_of_sessions) Session_length_prior_kl
	from(
		select player_id,sum(session_count)::float no_of_sessions,Sum(total_hours)::float Hours
		from 
			(select *
			 from seven11_prod_da.wba_player_daily 
			 cross join day_window)
		where  date(event_dt) between dateadd(day,-days,'2019-06-17') and '2019-06-17' 
		and player_id in (select * from KL_Players_with_no_kombat_pack)
		group by 1) a
	join (
		select player_id,count(distinct date(event_dt) )::float days_played
		from 
			(select *
			 from seven11_prod_da.wba_fact_activity 
 			 cross join day_window)
		where date(event_dt) between dateadd(day,-days,'2019-06-17') and '2019-06-17' 
		and player_id in (select * from KL_Players_with_no_kombat_pack)
		group by 1) b
	on a.player_id = b.player_id
) ;

----------- - NoN Kombat pack owners Engagement 15 days before and after KL Launch for non KL active players

with day_window as(
select 14 days
),

Active_Players  as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-06-18' and '2019-07-16' 
group by 1 ) ,

kombat_pack_Shang_tsung_players as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','shang_tsung') 
			then 1 else 0 end) kombat_pack_Shang_tsung
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
group by 1
having kombat_pack_Shang_tsung =1),

No_kombat_pack_Shang_tsung_players as(
select player_id
from Active_Players
where player_id not in (select _platform_account_id from kombat_pack_Shang_tsung_players)
group by 1) ,

KL_Players_with_no_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select * from No_kombat_pack_Shang_tsung_players)
group by 1) ,

Non_KL_Players_with_no_kombat_pack as(
select player_id
from No_kombat_pack_Shang_tsung_players
where player_id not in (select * from KL_Players_with_no_kombat_pack)
group by 1)

select *
from(
	select  Avg(days_played) Avg_days_played_post_kl,Avg(no_of_sessions) Avg_sessions_post_kl,Avg(Hours) Avg_hours_post_kl,sum(Hours)/sum(no_of_sessions) Session_length_post_kl
	from(
		select player_id,sum(session_count)::float no_of_sessions,Sum(total_hours)::float Hours
		from 
			(select *
			 from seven11_prod_da.wba_player_daily 
			 cross join day_window)
		where date(event_dt) between '2019-06-18' and dateadd(day,days,'2019-06-18')
		and player_id in (select * from Non_KL_Players_with_no_kombat_pack)
		group by 1) a
	join (
		select player_id,count(distinct date(event_dt) )::float days_played
		from 
			(select *
			 from seven11_prod_da.wba_fact_activity 
			 cross join day_window)
		where date(event_dt) between '2019-06-18' and dateadd(day,days,'2019-06-18')
		and player_id in (select * from Non_KL_Players_with_no_kombat_pack)
		group by 1) b
	on a.player_id = b.player_id
)
cross join(
	select  Avg(days_played) Avg_days_played_prior_kl,Avg(no_of_sessions) Avg_sessions_prior_kl,Avg(Hours) Avg_hours_prior_kl,sum(Hours)/sum(no_of_sessions) Session_length_prior_kl
	from(
		select player_id,sum(session_count)::float no_of_sessions,Sum(total_hours)::float Hours
		from 
			(select *
			 from seven11_prod_da.wba_player_daily 
			 cross join day_window)
		where  date(event_dt) between dateadd(day,-days,'2019-06-17') and '2019-06-17'  
		and player_id in (select * from Non_KL_Players_with_no_kombat_pack)
		group by 1) a
	join (
		select player_id,count(distinct date(event_dt) )::float days_played
		from 
			(select *
			 from seven11_prod_da.wba_fact_activity 
 			 cross join day_window)
		where date(event_dt) between dateadd(day,-days,'2019-06-17') and '2019-06-17'  
		and player_id in (select * from Non_KL_Players_with_no_kombat_pack)
		group by 1) b
	on a.player_id = b.player_id
) ;

----------- - NoN Kombat pack owners Engagement 4 wk before and after KL Launch for KL active players

with day_window as(
select 28 days
),

Active_Players  as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-06-18' and '2019-07-16' 
group by 1 ) ,

kombat_pack_Shang_tsung_players as(
select _platform_account_id , 
			max(case when entitlement_name in ('kombat_pack','shang_tsung') 
			then 1 else 0 end) kombat_pack_Shang_tsung
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
group by 1
having kombat_pack_Shang_tsung =1),

No_kombat_pack_Shang_tsung_players as(
select player_id
from Active_Players
where player_id not in (select _platform_account_id from kombat_pack_Shang_tsung_players)
group by 1) ,

KL_Players_with_no_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select * from No_kombat_pack_Shang_tsung_players)
group by 1) ,

Non_KL_Players_with_no_kombat_pack as(
select player_id
from No_kombat_pack_Shang_tsung_players
where player_id not in (select * from KL_Players_with_no_kombat_pack)
group by 1)

select *
from(
	select  Avg(days_played) Avg_days_played_post_kl,Avg(no_of_sessions) Avg_sessions_post_kl,Avg(Hours) Avg_hours_post_kl,sum(Hours)/sum(no_of_sessions) Session_length_post_kl
	from(
		select player_id,sum(session_count)::float no_of_sessions,Sum(total_hours)::float Hours
		from 
			(select *
			 from seven11_prod_da.wba_player_daily 
			 cross join day_window)
		where date(event_dt) between '2019-06-18' and dateadd(day,days,'2019-06-18')
		and player_id in (select * from KL_Players_with_no_kombat_pack)
		group by 1) a
	join (
		select player_id,count(distinct date(event_dt) )::float days_played
		from 
			(select *
			 from seven11_prod_da.wba_fact_activity 
			 cross join day_window)
		where date(event_dt) between '2019-06-18' and dateadd(day,days,'2019-06-18')
		and player_id in (select * from KL_Players_with_no_kombat_pack)
		group by 1) b
	on a.player_id = b.player_id
)
cross join(
	select  Avg(days_played) Avg_days_played_prior_kl,Avg(no_of_sessions) Avg_sessions_prior_kl,Avg(Hours) Avg_hours_prior_kl,sum(Hours)/sum(no_of_sessions) Session_length_prior_kl
	from(
		select player_id,sum(session_count)::float no_of_sessions,Sum(total_hours)::float Hours
		from 
			(select *
			 from seven11_prod_da.wba_player_daily 
			 cross join day_window)
		where  date(event_dt) between dateadd(day,-days,'2019-06-17') and '2019-06-17' 
		and player_id in (select * from KL_Players_with_no_kombat_pack)
		group by 1) a
	join (
		select player_id,count(distinct date(event_dt) )::float days_played
		from 
			(select *
			 from seven11_prod_da.wba_fact_activity 
 			 cross join day_window)
		where date(event_dt) between dateadd(day,-days,'2019-06-17') and '2019-06-17' 
		and player_id in (select * from KL_Players_with_no_kombat_pack)
		group by 1) b
	on a.player_id = b.player_id
) ;

----------- - NoN Kombat pack owners Engagement 4 wk before and after KL Launch for non KL active players

with day_window as(
select 28 days
),

Active_Players  as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-06-18' and '2019-07-16' 
group by 1 ) ,

kombat_pack_Shang_tsung_players as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','shang_tsung') 
			then 1 else 0 end) kombat_pack_Shang_tsung
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
group by 1
having kombat_pack_Shang_tsung =1),

No_kombat_pack_Shang_tsung_players as(
select player_id
from Active_Players
where player_id not in (select _platform_account_id from kombat_pack_Shang_tsung_players)
group by 1) ,

KL_Players_with_no_kombat_pack as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) BETWEEN '2019-06-18' AND '2019-07-16'
and _platform_account_id in (select * from No_kombat_pack_Shang_tsung_players)
group by 1) ,

Non_KL_Players_with_no_kombat_pack as(
select player_id
from No_kombat_pack_Shang_tsung_players
where player_id not in (select * from KL_Players_with_no_kombat_pack)
group by 1)

select *
from(
	select  Avg(days_played) Avg_days_played_post_kl,Avg(no_of_sessions) Avg_sessions_post_kl,Avg(Hours) Avg_hours_post_kl,sum(Hours)/sum(no_of_sessions) Session_length_post_kl
	from(
		select player_id,sum(session_count)::float no_of_sessions,Sum(total_hours)::float Hours
		from 
			(select *
			 from seven11_prod_da.wba_player_daily 
			 cross join day_window)
		where date(event_dt) between '2019-06-18' and dateadd(day,days,'2019-06-18')
		and player_id in (select * from Non_KL_Players_with_no_kombat_pack)
		group by 1) a
	join (
		select player_id,count(distinct date(event_dt) )::float days_played
		from 
			(select *
			 from seven11_prod_da.wba_fact_activity 
			 cross join day_window)
		where date(event_dt) between '2019-06-18' and dateadd(day,days,'2019-06-18')
		and player_id in (select * from Non_KL_Players_with_no_kombat_pack)
		group by 1) b
	on a.player_id = b.player_id
)
cross join(
	select  Avg(days_played) Avg_days_played_prior_kl,Avg(no_of_sessions) Avg_sessions_prior_kl,Avg(Hours) Avg_hours_prior_kl,sum(Hours)/sum(no_of_sessions) Session_length_prior_kl
	from(
		select player_id,sum(session_count)::float no_of_sessions,Sum(total_hours)::float Hours
		from 
			(select *
			 from seven11_prod_da.wba_player_daily 
			 cross join day_window)
		where  date(event_dt) between dateadd(day,-days,'2019-06-17') and '2019-06-17' 
		and player_id in (select * from Non_KL_Players_with_no_kombat_pack)
		group by 1) a
	join (
		select player_id,count(distinct date(event_dt) )::float days_played
		from 
			(select *
			 from seven11_prod_da.wba_fact_activity 
 			 cross join day_window)
		where date(event_dt) between dateadd(day,-days,'2019-06-17') and '2019-06-17' 
		and player_id in (select * from Non_KL_Players_with_no_kombat_pack)
		group by 1) b
	on a.player_id = b.player_id
) ;

