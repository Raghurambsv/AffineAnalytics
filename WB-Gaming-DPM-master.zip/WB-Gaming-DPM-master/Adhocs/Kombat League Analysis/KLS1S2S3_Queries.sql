	 	 
-----------------------First 14 days-------------------------------------------------------------------------

--------------Overall modes---aVG_sessions_per_day,hours_per_day,session_length for KL seasons 1,2,3 Players

with day_window as(
select datediff(day,'2019-08-27','2019-09-09') days
) ,

KL1_players_14days as(
select _platform_account_id
from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and dateadd(day,days,'2019-06-18')
group by 1) ,

KL2_players_14days as(
select _platform_account_id
from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and dateadd(day,days,'2019-07-23')
group by 1) ,

 KL3_players_14days as(
select _platform_account_id
from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
where  match_season =  ('ranked-3') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-08-27' and dateadd(day,days,'2019-08-27')
group by 1)
	  

select *
from(
      select  Avg(no_of_sessions_per_day) Avg_sessions_per_day_KL1,Avg(Hours_per_day) Avg_hours_per_day_KL1,sum(Hours_per_day)/sum(no_of_sessions_per_day) Session_length_KL1
      from(
      select player_id,date(event_dt), sum(session_count)::float no_of_sessions_per_day,Sum(total_hours) Hours_per_day
      from (select * 
		  from seven11_prod_da.wba_player_daily
		  cross join day_window)
      where date(event_dt) between '2019-06-18' and dateadd(day,days,'2019-06-18')
      and player_id in (select * from KL1_players_14days)
      group by 1,2)
      ) a
cross join
      (
      select  Avg(no_of_sessions_per_day) Avg_sessions_per_day_KL2,Avg(Hours_per_day) Avg_hours_per_day_KL2,sum(Hours_per_day)/sum(no_of_sessions_per_day) Session_length_KL2
      from(
      select player_id,date(event_dt), sum(session_count)::float no_of_sessions_per_day,Sum(total_hours) Hours_per_day
      from (select * 
		  from seven11_prod_da.wba_player_daily
		  cross join day_window)
      where date(event_dt) between '2019-07-23' and dateadd(day,days,'2019-07-23')
      and player_id in (select * from KL2_players_14days)
      group by 1,2)
      ) b
cross join
      (
      select  Avg(no_of_sessions_per_day) Avg_sessions_per_day_KL3,Avg(Hours_per_day) Avg_hours_per_day_KL3,sum(Hours_per_day)/sum(no_of_sessions_per_day) Session_length_KL3
      from(
      select player_id,date(event_dt), sum(session_count)::float no_of_sessions_per_day,Sum(total_hours) Hours_per_day
      from (select * 
		  from seven11_prod_da.wba_player_daily
		  cross join day_window)
      where date(event_dt) between '2019-08-27' and dateadd(day,days,'2019-08-27')
      and player_id in (select * from KL3_players_14days)
      group by 1,2)
      ) c	  
;

-----------------------------------------------------------------------------------------------------------
--------------In Kombat League----14 days---aVG_sessions_per_day,hours_per_day,session_length for KL seasons 1,2,3 Players

with day_window as(
select datediff(day,'2019-08-27','2019-09-09') days
) 

select *
from(
      select COUNT(DISTINCT _platform_account_id) Players_KL1, Avg(matches) Matches_per_day_KL1, Avg(no_of_sessions_per_day) Avg_sessions_per_day_KL1,Avg(Hours_per_day) Avg_hours_per_day_KL1,sum(Hours_per_day)/sum(no_of_sessions_per_day) Session_length_KL1
      from(
      select _platform_account_id,date(wbanalyticssourcedate),count(distinct match_id)::float matches, count(distinct _session_id)::float no_of_sessions_per_day,Sum(match_length)::float/3600 Hours_per_day
      from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
      where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and dateadd(day,days,'2019-06-18')
      group by 1,2)
      ) a
cross join
      (
      select COUNT(DISTINCT _platform_account_id) Players_KL2,Avg(matches) Matches_per_day_KL2, Avg(no_of_sessions_per_day) Avg_sessions_per_day_KL2,Avg(Hours_per_day) Avg_hours_per_day_KL2,sum(Hours_per_day)/sum(no_of_sessions_per_day) Session_length_KL2
      from(
      select _platform_account_id,date(wbanalyticssourcedate),count(distinct match_id)::float matches, count(distinct _session_id)::float no_of_sessions_per_day,Sum(match_length)::float/3600 Hours_per_day
      from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
      where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and dateadd(day,days,'2019-07-23')
      group by 1,2)
      ) b
cross join
      (
      select COUNT(DISTINCT _platform_account_id) Players_KL3,Avg(matches) Matches_per_day_KL3, Avg(no_of_sessions_per_day) Avg_sessions_per_day_KL3,Avg(Hours_per_day) Avg_hours_per_day_KL3,sum(Hours_per_day)/sum(no_of_sessions_per_day) Session_length_KL3
      from(
      select _platform_account_id,date(wbanalyticssourcedate),count(distinct match_id)::float matches, count(distinct _session_id)::float no_of_sessions_per_day,Sum(match_length)::float/3600 Hours_per_day
      from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
      where  match_season =  ('ranked-3') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-08-27' and dateadd(day,days,'2019-08-27')
      group by 1,2)
      ) c
	  
;

------------------------------------------------------------------------------------------------------------
--------Avg days Played in KL Seasons 1,2,3

with day_window as(
select datediff(day,'2019-08-27','2019-09-09') days
) ,

KL1_avg_days_played_14days as(
select avg(days_played) KL1_avg_days_played
from(
select _platform_account_id,count(distinct date(wbanalyticssourcedate) )::float days_played
from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and dateadd(day,days,'2019-06-18')
group by 1)),

KL2_avg_days_played_14days as(
select avg(days_played) KL2_avg_days_played
from(
select _platform_account_id,count(distinct date(wbanalyticssourcedate) )::float days_played
from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
where match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and dateadd(day,days,'2019-07-23')
group by 1)) ,

KL3_avg_days_played_14days as(
select avg(days_played) KL3_avg_days_played
from(
select _platform_account_id,count(distinct date(wbanalyticssourcedate) )::float days_played
from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
where match_season =  ('ranked-3') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-08-27' and dateadd(day,days,'2019-08-27')
group by 1))

select *
from KL1_avg_days_played_14days 
cross join KL2_avg_days_played_14days
cross join KL3_avg_days_played_14days ;
-----------------------------------------------------------------------------------------------------------

-----------perc season 1&2 players converted to Season 3

with  KL1and2_players as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where  match_season in  ('ranked-1','ranked-2') and ai_difficulty= -1 
group by 1) 


select  Total_KL12_Players,Active_KL12_players,KL3_conv,(KL3_conv*1.0)/Total_KL12_Players perc_Total,
		(KL3_conv*1.0)/Active_KL12_players perc_Active
from (
select count(distinct _platform_account_id) KL3_conv
from seven11_prod.seven11_match_result_player 
where  match_season =  ('ranked-3') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-08-27' and '2019-09-09'
and _platform_account_id in (Select * from KL1and2_players)
) 
cross join(
	select count(distinct _platform_account_id) Total_KL12_players
	from KL1and2_players) 
cross join(
	select count(distinct player_id) Active_KL12_players
	from seven11_prod_da.wba_fact_activity
	where date(event_dt) between '2019-08-27' and '2019-09-09' 
	and Player_id in (select * from KL1and2_players)
	 )
 ;
                                                                                     
--------------Kombat players,Kombat players as % of DAU,Avg_KL_matches for seasons 1,2,3 daily level

with day_window as(
select datediff(day,'2019-08-27','2019-09-09') days
) 

select a.days_since_start,Daily_KL1_players,Avg_KL1_hours_played_daily,
		(Daily_KL1_players)*1.0/ DAU_1 KL1_players_percent_of_DAU,Avg_KL1_matches_daily,
		Daily_KL2_players,Avg_KL2_hours_played_daily,
		(Daily_KL2_players)*1.0/ DAU_2 KL2_players_percent_of_DAU,Avg_KL2_matches_daily,
		Daily_KL3_players,Avg_KL3_hours_played_daily,
		(Daily_KL3_players)*1.0/ DAU_3 KL3_players_percent_of_DAU,Avg_KL3_matches_daily
from
      (
      SELECT datediff(day,'2019-06-17',event_dt) days_since_start,sum (active_players) DAU_1
      FROM (select * 
		  from seven11_prod_da.wba_daily_activity
		  cross join day_window)
      where event_dt between '2019-06-18' and dateadd(day,days,'2019-06-18')
      group by 1
      ) a
left join
      (select datediff(day,'2019-06-17',date(wbanalyticssourcedate)) days_since_start 
        , count(distinct _platform_account_id) Daily_KL1_players
        , count(distinct match_id) KL1_matches,Sum(match_length) KL1_time_played
		,(KL1_time_played*1.0)/(Daily_KL1_players*3600) Avg_KL1_hours_played_daily
        , (KL1_matches*1.0)/Daily_KL1_players Avg_KL1_matches_daily
      from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
      where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and dateadd(day,days,'2019-06-18')
      group by 1
      ) b
on a.days_since_start=b.days_since_start
left join
      (
      SELECT datediff(day,'2019-07-22',event_dt) days_since_start,sum (active_players) DAU_2
      FROM (select * 
		  from seven11_prod_da.wba_daily_activity
		  cross join day_window)
      where event_dt between '2019-07-23' and dateadd(day,days,'2019-07-23')
      group by 1
      ) c
on a.days_since_start=C.days_since_start
left join
      (select datediff(day,'2019-07-22',date(wbanalyticssourcedate)) days_since_start 
        , count(distinct _platform_account_id) Daily_KL2_players
        , count(distinct match_id) KL2_matches,Sum(match_length) KL2_time_played
		,(KL2_time_played*1.0)/(Daily_KL2_players*3600) Avg_KL2_hours_played_daily
        , (KL2_matches*1.0)/Daily_KL2_players Avg_KL2_matches_daily
      from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
      where match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and dateadd(day,days,'2019-07-23')
      group by 1
      )d
on a.days_since_start=d.days_since_start
left join
      (
      SELECT datediff(day,'2019-08-26',event_dt) days_since_start,sum (active_players) DAU_3
      FROM (select * 
		  from seven11_prod_da.wba_daily_activity
		  cross join day_window)
      where event_dt between '2019-08-27' and dateadd(day,days,'2019-08-27')
      group by 1
      ) e
on a.days_since_start=e.days_since_start
left join
      (select datediff(day,'2019-08-26',date(wbanalyticssourcedate)) days_since_start 
        , count(distinct _platform_account_id) Daily_KL3_players
        , count(distinct match_id) KL3_matches,Sum(match_length) KL3_time_played
		,(KL3_time_played*1.0)/(Daily_KL3_players*3600) Avg_KL3_hours_played_daily
        , (KL3_matches*1.0)/Daily_KL3_players Avg_KL3_matches_daily
      from (select * 
		  from seven11_prod.seven11_match_result_player
		  cross join day_window)
      where match_season =  ('ranked-3') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-08-27' and dateadd(day,days,'2019-08-27')
      group by 1
      )f
on a.days_since_start=f.days_since_start
;
