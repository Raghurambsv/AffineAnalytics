------- Matches and Hrs played by players who completed all the seasonal challenges-----

with completed_All_challenges as
(
select _platform_account_id,min(wbanalyticssourcedate) date
from seven11_prod.seven11_progression_unlock
where date(wbanalyticssourcedate) >='2019-06-18'--- and _platform_account_id in ('2535462691147489','2535424289636784','4315288082523150383')
--and unlock_name like '%Blood%'
and unlock_name in ( 'SCO_Blood_Skin_Palette1', 'SCO_Blood_Skin_Palette2')
group by 1
) 

 select COUNT(DISTINCT _platform_account_id) Players_Compl_all_chal,Avg(matches) Avg_Matches, Avg(no_of_sessions) Avg_sessions,Avg(Hours) Avg_hours
 from(
      select _platform_account_id,count(distinct match_id)::float matches, count(distinct _session_id)::float no_of_sessions,Sum(match_length)::float/3600 Hours
      from (select a.*,b.date
			from seven11_prod.seven11_match_result_player a
			join completed_All_challenges b
			on a._platform_account_id = b._platform_account_id and a.wbanalyticssourcedate<=b.date)
      where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1)

------- Matches and Hrs played by players who completed the other 5 seasonal challenges-----

with completed_All_challenges as
(
select _platform_account_id,min(wbanalyticssourcedate) date
from seven11_prod.seven11_progression_unlock
where date(wbanalyticssourcedate) >='2019-06-18' --and _platform_account_id in ('2535462691147489','2535424289636784','4315288082523150383')
--and unlock_name like '%Blood%'
and unlock_name in ( 'JAX_GearB51','KOT_GearB51','KUN_Brutality9','SCO_VictoryE','TER_GearA51')
group by 1
) 

 select COUNT(DISTINCT _platform_account_id) Players_Compl_all_chal,Avg(matches) Avg_Matches, Avg(no_of_sessions) Avg_sessions,Avg(Hours) Avg_hours
 from(
      select _platform_account_id,count(distinct match_id)::float matches, count(distinct _session_id)::float no_of_sessions,Sum(match_length)::float/3600 Hours
      from (select a.*,b.date
			from seven11_prod.seven11_match_result_player a
			join completed_All_challenges b
			on a._platform_account_id = b._platform_account_id and a.wbanalyticssourcedate<=b.date)
      where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1)