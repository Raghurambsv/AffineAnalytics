with  KL1_players_15_days as(
SELECT *
FROM(
select _platform_account_id KL1_Players,count(distinct match_id)::float KL1_matches,Sum(match_length)::float/3600 KL1_Hours
from seven11_prod.seven11_match_result_player
where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-02'
group by 1)
lEFT JOIN
(
select  _platform_account_id Conv_to_KL2,count(distinct match_id)::float KL2_matches,Sum(match_length)::float/3600 KL2_Hours
from seven11_prod.seven11_match_result_player 
where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-06'
group by 1
)
On KL1_Players = Conv_to_KL2)

select KL1_matches,count(KL1_Players) Player_count,count(Conv_to_KL2) Conv_to_KL2,Sum(KL2_matches) Total_KL2_matches,
Avg(KL2_matches)::float Avg_KL2_matches
from KL1_players_15_days
group by 1
order by 1 ;

with  KL1_players_15_days as(
SELECT *
FROM(
select _platform_account_id KL1_Players,count(distinct match_id)::float KL1_matches,Sum(match_length)::float/3600 KL1_Hours
from seven11_prod.seven11_match_result_player
where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-02'
group by 1)
lEFT JOIN
(
select  _platform_account_id Conv_to_KL2,count(distinct match_id)::float KL2_matches,Sum(match_length)::float/3600 KL2_Hours
from seven11_prod.seven11_match_result_player 
where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-06'
group by 1
)
On KL1_Players = Conv_to_KL2)

select Ceiling(KL1_Hours),count(KL1_Players) Player_count,count(Conv_to_KL2) Conv_to_KL2,Sum(KL2_Hours) Total_KL2_Hours,
Avg(KL2_Hours)::float Avg_KL2_Hours
from KL1_players_15_days
group by 1
order by 1 ;