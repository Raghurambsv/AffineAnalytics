---------------Sheet NewReturn
--------------Charts Ranked Matches Participation by player type & KL Players Composition

select event_dt , sum(new_players) newp, sum(reacquired_players) reacq, sum(returning_players) retur, newp+reacq+retur total
from seven11_prod_da.wba_daily_activity
where event_dt > '2019-04-22' and event_dt <= '2019-07-16'
group by  1
order by 1 ;

---New Players Ranked Matches -----
with players as (
select player_id , min(event_dt) install_dt
from seven11_prod_da.wba_fact_activity
where event_dt between '2019-04-22' and '2019-07-16'
group by  1
order by 1
)
, newplayercount as (
select install_dt, count(distinct player_id) newplayers 
from players
where install_dt between '2019-04-22' and '2019-07-16'
group by  1
order by 1)
select date(wbanalyticssourcedate) date
        , count(distinct _platform_account_id) Daily_ranked_players
        , count(distinct match_id) ranked_matches
        , (ranked_matches*1.0)/Daily_ranked_players avg_ranked_matches_daily
      from seven11_prod.seven11_match_result_player a
      join players b on b.player_id = a._platform_account_id and b.install_dt =  date(a.wbanalyticssourcedate) 
      where activity_name ='GM_RANKED_ON_1V1' -- in ('GM_GROUP_BATTLES','GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_PRACTICE','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT','GM_PLAYER_MATCH_ON_KOTH') 
      and ai_difficulty= -1 and date(wbanalyticssourcedate)  between '2019-04-22' and '2019-07-16'
      group by 1;
	  

---Returning Players Ranked Matches -----

with fact_activity as (select event_dt, player_id
from seven11_prod_da.wba_fact_activity
group by 1,2) ,

 returningplayers as (
select event_dt, player_id
from fact_activity a
where a.event_dt  > '2019-04-22' and event_dt <= '2019-07-16'
and player_id in (select distinct b.player_id from fact_activity b
where b.event_dt between dateadd(day,-14,a.event_dt ) and dateadd(day,-1,a.event_dt ) )
group by  1,2
order by 1,2
)

select date(wbanalyticssourcedate) date
        , count(distinct _platform_account_id) Daily_ranked_players
        , count(distinct match_id) ranked_matches
        , (ranked_matches*1.0)/Daily_ranked_players avg_ranked_matches_daily
      from seven11_prod.seven11_match_result_player a
      join returningplayers b on b.player_id = a._platform_account_id and b.event_dt =  date(a.wbanalyticssourcedate) 
      where activity_name ='GM_RANKED_ON_1V1' -- in ('GM_GROUP_BATTLES','GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_PRACTICE','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT','GM_PLAYER_MATCH_ON_KOTH') 
      and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-04-22' and '2019-07-16'
      group by 1 ;
	  

---Reaquired Players Ranked Matches -----

with fact_activity as (select event_dt, player_id
from seven11_prod_da.wba_fact_activity
group by 1,2) ,

newplayers as (
select player_id , min(event_dt) install_dt
from fact_activity
where event_dt between '2019-04-22' and '2019-07-16'
group by  1
order by 1
),

returningplayers as (
select event_dt, player_id
from fact_activity a
where a.event_dt  > '2019-04-22' and event_dt <= '2019-07-16'
and player_id in (select distinct b.player_id from fact_activity b
where b.event_dt between dateadd(day,-14,a.event_dt ) and dateadd(day,-1,a.event_dt ) )
group by  1,2
order by 1,2
)
, reacquiredplayers as (
select event_dt, player_id
from fact_activity a
where a.event_dt  > '2019-04-22' and event_dt <= '2019-07-16'
and player_id not in (select distinct c.player_id from newplayers c
where a.event_dt= c.install_dt  and a.player_id=c.player_id)
and player_id not in (select distinct b.player_id from returningplayers b
where b.event_dt = a.event_dt and a.player_id=b.player_id)
group by  1,2
order by 1,2
)

select date(wbanalyticssourcedate) date
        , count(distinct _platform_account_id) Daily_ranked_players
        , count(distinct match_id) ranked_matches
        , (ranked_matches*1.0)/Daily_ranked_players avg_ranked_matches_daily
      from seven11_prod.seven11_match_result_player a
      join reacquiredplayers b on b.player_id = a._platform_account_id and b.event_dt =  date(a.wbanalyticssourcedate) 
      where activity_name ='GM_RANKED_ON_1V1' -- in ('GM_GROUP_BATTLES','GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_PRACTICE','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT','GM_PLAYER_MATCH_ON_KOTH') 
      and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-04-22' and '2019-07-16'
      group by 1 ;
      
