------- KL Gear Rewards to Figure out Tier Ranking-----
with  KL2_players as(
	select _platform_account_id
	from seven11_prod.seven11_match_result_player
	where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-20'
	group by 1
),
KL2_set_players as(
	select _platform_account_id
	from seven11_prod.seven11_match_result_player
	where  match_season =  ('ranked-2') and ai_difficulty= -1 and ranked_set_end=1 and  date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-20'
	group by 1
)
	 
	select count(distinct a._platform_account_id) KL_Players
		,  count(distinct s._platform_account_id) KL_set_Players
		, count(distinct player_id) KL_Players_Active
		, count(distinct c._platform_account_id) KL_Players_Redeemed
	from kL2_players a 
		LEFT join KL2_set_players s on a._platform_account_id = s._platform_account_id
		left join (select * from seven11_prod_da.wba_fact_activity where date(event_dt)>= '2019-08-20') b on s._platform_account_id = b.player_id
		left join (select distinct "_platform_account_id"
					from seven11_prod.seven11_progression_unlock
					where wbanalyticssourcedate >='2019-08-20'
					and unlock_name in ('JAC_Skin51_Palette1','JAC_Skin51_Palette2','KOL_Skin51_Palette1',
					'KOL_Skin51_Palette2','RAI_Skin51_Palette1','RAI_Skin51_Palette2')
		) c on a._platform_account_id = c._platform_account_id
;

------- KL Players Tier wise Hours and matches played-----
with  KL2_players as(
	select _platform_account_id
	from seven11_prod.seven11_match_result_player
	where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-20'
	group by 1
) ,

Player_Tiers as (
	select _platform_account_id, max(Tier) Player_Tier
	from (
	select unlock_name,c._platform_account_id,
			case when unlock_name in ('LIU_GearC51') then '9'
			when unlock_name in ('RAI_GearB51') then '8'
			when unlock_name in ('DVO_GearA51') then '7'
			when unlock_name in ('KOL_GearC51') then '6'
			when unlock_name in ('KUN_GearA51') then '5'
			when unlock_name in ('CAS_GearC51') then '4'
			when unlock_name in ('KAN_GearA51') then '3'
			when unlock_name in ('KIT_GearB51') then '2'
			when unlock_name in ('BAR_GearB51') then '1'
			else Null end as Tier
	from kL2_players a 
	left join (select unlock_name, "_platform_account_id"
				from seven11_prod.seven11_progression_unlock
				where wbanalyticssourcedate >='2019-08-18'
				and unlock_name in ('BAR_GearB51','CAS_GearC51','DVO_GearA51','KAN_GearA51','KIT_GearB51',
				'KOL_GearC51','KUN_GearA51','LIU_GearC51','RAI_GearB51')
				group by 1,2
	) c 
	on a._platform_account_id = c._platform_account_id
	group by 1,2,3
)
where Tier is Not Null
group by 1 
)

      select Player_tier,COUNT(DISTINCT _platform_account_id) Players,Avg(matches) Avg_Matches, Avg(no_of_sessions) Avg_sessions,Avg(Hours) Avg_hours
      from(
      select Player_tier,_platform_account_id,count(distinct match_id)::float matches, count(distinct _session_id)::float no_of_sessions,Sum(match_length)::float/3600 Hours
      from (select a.*,b.Player_tier
	from seven11_prod.seven11_match_result_player a
	join player_Tiers b
	on a._platform_account_id =b._platform_account_id
	)
      where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-20'
      group by 1,2)
	  group by 1
;
------- KL Rewards Redeemed-----
with  KL2_players as(
	select _platform_account_id
	from seven11_prod.seven11_match_result_player
	where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-20'
	group by 1
)
	select count(distinct a._platform_account_id) KL_Players
		, count(distinct player_id) KL_Players_Active
		, count(distinct c._platform_account_id) KL_Players_Redeemed
	from kL2_players a 
		left join (select * from seven11_prod_da.wba_fact_activity where date(event_dt)>= '2019-08-20') b on a._platform_account_id = b.player_id
		left join (select distinct "_platform_account_id"
					from seven11_prod.seven11_progression_unlock
					where wbanalyticssourcedate >='2019-08-20'
					and unlock_name in ('JAC_Skin51_Palette1','JAC_Skin51_Palette2','KOL_Skin51_Palette1',
					'KOL_Skin51_Palette2','RAI_Skin51_Palette1','RAI_Skin51_Palette2')
		) c on a._platform_account_id = c._platform_account_id
;

------- KL Rewards Redeemed based on Skin Rewards-----
with  KL2_players as(
	select _platform_account_id
	from seven11_prod.seven11_match_result_player
	where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-20'
	group by 1
) ,

Player_Tiers as (
	select _platform_account_id, max(Tier) Player_Tier
	from (
	select unlock_name,c._platform_account_id,
			case when unlock_name in ('JAC_Skin51_Palette1','JAC_Skin51_Palette2') then '3'
			when unlock_name in ('KOL_Skin51_Palette1','KOL_Skin51_Palette2') then '1'
			when unlock_name in ('RAI_Skin51_Palette1','RAI_Skin51_Palette2') then '2'			
			else Null end as Tier
		from kL2_players a 
	left join (select unlock_name, "_platform_account_id"
				from seven11_prod.seven11_progression_unlock
				where wbanalyticssourcedate >='2019-08-20'
				and unlock_name in ('JAC_Skin51_Palette1','JAC_Skin51_Palette2','KOL_Skin51_Palette1',
					'KOL_Skin51_Palette2','RAI_Skin51_Palette1','RAI_Skin51_Palette2')
				group by 1,2
	) c 
	on a._platform_account_id = c._platform_account_id
	group by 1,2,3
)
where Tier is Not Null
group by 1 
)

	select count(distinct a._platform_account_id) KL_Players
		, count(distinct c._platform_account_id) KL_Players_Redeemed, Player_Tier
	from kL2_players a 
	left join (select distinct "_platform_account_id"
				from seven11_prod.seven11_progression_unlock
				where wbanalyticssourcedate >='2019-08-20'
				and unlock_name in ('JAC_Skin51_Palette1','JAC_Skin51_Palette2','KOL_Skin51_Palette1',
				'KOL_Skin51_Palette2','RAI_Skin51_Palette1','RAI_Skin51_Palette2')
		       ) c on a._platform_account_id = c._platform_account_id
	join Player_Tiers d on a._platform_account_id = d._platform_account_id
	group by 3

------- Matches and Hrs played by players who completed all the seasonal challenges-----

with completed_All_challenges as
(
select _platform_account_id,min(wbanalyticssourcedate) date
from seven11_prod.seven11_progression_unlock
where date(wbanalyticssourcedate) >='2019-07-23'--- and _platform_account_id in ('2535462691147489','2535424289636784','4315288082523150383')
--and unlock_name like '%Blood%'
and unlock_name in ('ERR_Skin51_Palette1' , 'ERR_Skin51_Palette2')
group by 1
) 

 select COUNT(DISTINCT _platform_account_id) Players_Compl_all_chal,Avg(matches) Avg_Matches, Avg(no_of_sessions) Avg_sessions,Avg(Hours) Avg_hours
 from(
      select _platform_account_id,count(distinct match_id)::float matches, count(distinct _session_id)::float no_of_sessions,Sum(match_length)::float/3600 Hours
      from (select a.*,b.date
			from seven11_prod.seven11_match_result_player a
			join completed_All_challenges b
			on a._platform_account_id = b._platform_account_id and a.wbanalyticssourcedate<=b.date)
      where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-20'
      group by 1)

------- Matches and Hrs played by players who completed the other 5 seasonal challenges-----

with completed_All_challenges as
(
select _platform_account_id,unlock_name, min(wbanalyticssourcedate) date
from seven11_prod.seven11_progression_unlock
where date(wbanalyticssourcedate) >='2019-07-23' --and _platform_account_id in ('2535462691147489','2535424289636784','4315288082523150383')
--and unlock_name like '%Blood%'
and unlock_name in ('CAS_Brutality9','SCO_GearA51','ERR_GearB51','JAD_Brutality7','SKA_GearB51')
group by 1,2
) 

 select unlock_name,COUNT(DISTINCT _platform_account_id) Players_Compl_all_chal,Avg(matches) Avg_Matches, Avg(no_of_sessions) Avg_sessions,Avg(Hours) Avg_hours
 from(
      select _platform_account_id,unlock_name,count(distinct match_id)::float matches, count(distinct _session_id)::float no_of_sessions,Sum(match_length)::float/3600 Hours
      from (select a.*,b.unlock_name,b.date
			from seven11_prod.seven11_match_result_player a
			join completed_All_challenges b
			on a._platform_account_id = b._platform_account_id and a.wbanalyticssourcedate<=b.date)
      where  match_season =  ('ranked-2') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-07-23' and '2019-08-20'
      group by 1,2)
group by 1

