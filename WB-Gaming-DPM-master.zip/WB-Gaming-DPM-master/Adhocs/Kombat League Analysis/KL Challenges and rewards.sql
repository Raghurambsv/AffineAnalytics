------- KL Players Tier wise Hours and matches played-----
with  KL1_players as(
	select _platform_account_id
	from seven11_prod.seven11_match_result_player
	where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
	group by 1
) ,

Player_Tiers as (
	select _platform_account_id, max(Tier) Player_Tier
	from (
	select unlock_name,c._platform_account_id,
			case when unlock_name in ('KAB_GearB51') then '9'
			when unlock_name in ('CET_GearB51') then '8'
			when unlock_name in ('JAC_GearC51') then '7'
			when unlock_name in ('SON_GearC51') then '6'
			when unlock_name in ('JOH_GearA51') then '5'
			when unlock_name in ('NOO_GearA53') then '4'
			when unlock_name in ('JAD_GearC51') then '3'
			when unlock_name in ('FRO_GearC51') then '2'
			when unlock_name in ('SUB_GearA51') then '1'
			else Null end as Tier
	from kL1_players a 
	left join (select unlock_name, "_platform_account_id"
				from seven11_prod.seven11_progression_unlock
				where wbanalyticssourcedate >='2019-07-14'
				and unlock_name in ('CET_GearB51', 'FRO_GearC51', 'JAC_GearC51', 'JAD_GearC51', 'JOH_GearA51', 'KAB_GearB51', 'NOO_GearA53', 'SON_GearC51', 'SUB_GearA51')
				group by 1,2
	) c 
	on a._platform_account_id = c._platform_account_id
	group by 1,2,3
)
where Tier is Not Null
group by 1 
)

      select Player_tier,COUNT(DISTINCT _platform_account_id) Players,Avg(matches) Avg_Matches, Avg(no_of_sessions) Avg_sessions,Avg(Hours) Avg_hours
      from(
      select Player_tier,_platform_account_id,count(distinct match_id)::float matches, count(distinct _session_id)::float no_of_sessions,Sum(match_length)::float/3600 Hours
      from (select a.*,b.Player_tier
	from seven11_prod.seven11_match_result_player a
	join player_Tiers b
	on a._platform_account_id =b._platform_account_id
	)
      where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1,2)
	  group by 1
      
;

------- Matches and Hrs played by players who completed all the seasonal challenges-----

with completed_All_challenges as
(
select _platform_account_id
from seven11_prod.seven11_progression_unlock
where wbanalyticssourcedate >='2019-07-14'
--and unlock_name like '%Blood%'
and  unlock_name in ( 'SCO_Blood_Skin_Palette1', 'SCO_Blood_Skin_Palette2')
group by 1) 

 select COUNT(DISTINCT _platform_account_id) Players_Compl_all_chal,Avg(matches) Avg_Matches, Avg(no_of_sessions) Avg_sessions,Avg(Hours) Avg_hours
 from(
      select _platform_account_id,count(distinct match_id)::float matches, count(distinct _session_id)::float no_of_sessions,Sum(match_length)::float/3600 Hours
      from (select a.*
			from seven11_prod.seven11_match_result_player a
			join completed_All_challenges b
			on a._platform_account_id = b._platform_account_id)
      where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
      group by 1)
;


------- KL Rewards Redeemed-----
with  KL1_players as(
	select _platform_account_id
	from seven11_prod.seven11_match_result_player
	where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
	group by 1
)
	select count(distinct a._platform_account_id) KL_Players
		, count(distinct player_id) KL_Players_Active
		, count(distinct c._platform_account_id) KL_Players_Redeemed
	from kL1_players a 
		left join (select * from seven11_prod_da.wba_fact_activity where date(event_dt)>= '2019-07-16') b on a._platform_account_id = b.player_id
		left join (select distinct "_platform_account_id"
					from seven11_prod.seven11_progression_unlock
					where wbanalyticssourcedate >='2019-07-14'
					and unlock_name in ('ERR_Blood_Skin_Palette1', 'ERR_Blood_Skin_Palette2', 'KIT_Blood_Skin_Palette1', 'KIT_Blood_Skin_Palette2', 'SCO_Blood_Skin_Palette1', 'SCO_Blood_Skin_Palette2', 'SKA_Blood_Skin_Palette1', 'SKA_Blood_Skin_Palette2')
		) c on a._platform_account_id = c._platform_account_id

;

------- KL Gear Rewards to Figure out Tier Ranking-----
with  KL1_players as(
	select _platform_account_id
	from seven11_prod.seven11_match_result_player
	where  match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
	group by 1
)
	select unlock_name,   count(distinct c._platform_account_id) KL_Players_Redeemed
	from kL1_players a 
	left join (select unlock_name, "_platform_account_id"
				from seven11_prod.seven11_progression_unlock
				where wbanalyticssourcedate >='2019-07-14'
				and unlock_name in ('CET_GearB51', 'FRO_GearC51', 'JAC_GearC51', 'JAD_GearC51', 'JOH_GearA51', 'KAB_GearB51', 'NOO_GearA53', 'SON_GearC51', 'SUB_GearA51')
				group by 1,2
	) c on a._platform_account_id = c._platform_account_id
	where unlock_name is not NULL
	group by 1


;

------- KL Skin Rewards to Figure out Tier Ranking and players who completed all seasonal challenges-----
select unlock_name, count(distinct "_platform_account_id") Player_count
from seven11_prod.seven11_progression_unlock
where wbanalyticssourcedate >='2019-07-14'
--and unlock_name like '%Blood%'
and  unlock_name in ('ERR_Blood_Skin_Palette1', 'ERR_Blood_Skin_Palette2', 'KIT_Blood_Skin_Palette1', 'KIT_Blood_Skin_Palette2', 'SCO_Blood_Skin_Palette1', 'SCO_Blood_Skin_Palette2', 'SKA_Blood_Skin_Palette1', 'SKA_Blood_Skin_Palette2')
group by 1
limit 100
;