---------------Sheet NewReturn
--------------Charts Ranked Matches Participation by player type & KL Players Composition

select event_dt , sum(new_players) newp, sum(reacquired_players) reacq, sum(returning_players) retur, newp+reacq+retur total
from seven11_prod_da.wba_daily_activity
where event_dt > '2019-04-22' and event_dt <= '2019-07-16'
group by  1
order by 1 ;

---New Players Ranked Matches -----
with players as (
select player_id , install_dt
from seven11_prod_da.wba_player_daily
where install_dt between '2019-04-22' and '2019-07-16'
group by  1,2
order by 1
)
, newplayercount as (
select install_dt, count(distinct player_id) newplayers 
from players
where install_dt between '2019-04-22' and '2019-07-16'
group by  1
order by 1)
select date(wbanalyticssourcedate) date
        , count(distinct _platform_account_id) Daily_ranked_players
        , count(distinct match_id) ranked_matches
        , (ranked_matches*1.0)/Daily_ranked_players avg_ranked_matches_daily
      from seven11_prod.seven11_match_result_player a
      join players b on b.player_id = a._platform_account_id and b.install_dt =  date(a.wbanalyticssourcedate) 
      where activity_name ='GM_RANKED_ON_1V1' -- in ('GM_GROUP_BATTLES','GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_PRACTICE','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT','GM_PLAYER_MATCH_ON_KOTH') 
      and ai_difficulty= -1 and date(wbanalyticssourcedate)  between '2019-04-22' and '2019-07-16'
      group by 1;
	  
with players as (
select player_id , install_dt
from seven11_prod_da.wba_player_daily
where install_dt between '2019-04-22' and '2019-07-16'
group by  1,2
order by 1
)
, newplayercount as (
select install_dt, count(distinct player_id) newplayers 
from players
where install_dt between '2019-04-22' and '2019-07-16'
group by  1
order by 1)

select install_dt, count(distinct player_id) newp 
from seven11_prod_da.wba_player_daily
where install_dt >= '2019-04-22' and install_dt <= '2019-07-16'
group by  1
order by 1 ;



---Returning Players Ranked Matches -----

with returningplayers as (
select event_dt, player_id
from seven11_prod_da.wba_player_daily a
where a.event_dt  > '2019-04-22' and event_dt <= '2019-07-16'
and player_id in (select distinct b.player_id from seven11_prod_da.wba_player_daily b
where b.event_dt between dateadd(day,-14,a.event_dt ) and dateadd(day,-1,a.event_dt ) )
group by  1,2
order by 1,2
)

select date(wbanalyticssourcedate) date
        , count(distinct _platform_account_id) Daily_ranked_players
        , count(distinct match_id) ranked_matches
        , (ranked_matches*1.0)/Daily_ranked_players avg_ranked_matches_daily
      from seven11_prod.seven11_match_result_player a
      join returningplayers b on b.player_id = a._platform_account_id and b.event_dt =  date(a.wbanalyticssourcedate) 
      where activity_name ='GM_RANKED_ON_1V1' -- in ('GM_GROUP_BATTLES','GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_PRACTICE','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT','GM_PLAYER_MATCH_ON_KOTH') 
      and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-04-22' and '2019-07-16'
      group by 1 ;
	  
with returningplayers as (
select event_dt, player_id
from seven11_prod_da.wba_player_daily a
where a.event_dt  > '2019-04-22' and event_dt <= '2019-07-16'
and player_id in (select distinct b.player_id from seven11_prod_da.wba_player_daily b
where b.event_dt between dateadd(day,-14,a.event_dt ) and dateadd(day,-1,a.event_dt ) )
group by  1,2
order by 1,2
)


select event_dt, count(distinct player_id) retur
from seven11_prod_da.wba_player_daily a
where a.event_dt  > '2019-04-22' and event_dt <= '2019-07-16'
and player_id in (select distinct b.player_id from seven11_prod_da.wba_player_daily b
where b.event_dt between dateadd(day,-14,a.event_dt ) and dateadd(day,-1,a.event_dt ) )
group by  1
order by 1 ;



---Reaquired Players Ranked Matches -----

with returningplayers as (
select event_dt, player_id
from seven11_prod_da.wba_player_daily a
where a.event_dt  > '2019-04-22' and event_dt <= '2019-07-16'
and player_id in (select distinct b.player_id from seven11_prod_da.wba_player_daily b
where b.event_dt between dateadd(day,-14,a.event_dt ) and dateadd(day,-1,a.event_dt ) )
group by  1,2
order by 1,2
)
, reacquiredplayers as (
select event_dt, player_id
from seven11_prod_da.wba_player_daily a
where a.event_dt  > '2019-04-22' and event_dt <= '2019-07-16'
and  a.event_dt!=install_dt
and player_id not in (select distinct b.player_id from returningplayers b
where b.event_dt = a.event_dt and a.player_id=b.player_id)
group by  1,2
order by 1,2
)
select date(wbanalyticssourcedate) date
        , count(distinct _platform_account_id) Daily_ranked_players
        , count(distinct match_id) ranked_matches
        , (ranked_matches*1.0)/Daily_ranked_players avg_ranked_matches_daily
      from seven11_prod.seven11_match_result_player a
      join reacquiredplayers b on b.player_id = a._platform_account_id and b.event_dt =  date(a.wbanalyticssourcedate) 
      where activity_name ='GM_RANKED_ON_1V1' -- in ('GM_GROUP_BATTLES','GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_PRACTICE','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT','GM_PLAYER_MATCH_ON_KOTH') 
      and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-04-22' and '2019-07-16'
      group by 1 ;
      
      
with returningplayers as (
select event_dt, player_id
from seven11_prod_da.wba_player_daily a
where a.event_dt  > '2019-04-22' and event_dt <= '2019-07-16'
and player_id in (select distinct b.player_id from seven11_prod_da.wba_player_daily b
where b.event_dt between dateadd(day,-14,a.event_dt ) and dateadd(day,-1,a.event_dt ) )
group by  1,2
order by 1,2
)
select event_dt, count(distinct player_id) reacq
from seven11_prod_da.wba_player_daily a
where a.event_dt  >= '2019-04-22' and event_dt <= '2019-07-16'
and  a.event_dt!=install_dt
and player_id not in (select distinct b.player_id from returningplayers b
where b.event_dt = a.event_dt and a.player_id=b.player_id)
group by  1
order by 1 ;


select event_dt, count(distinct player_id) total 
from seven11_prod_da.wba_player_daily
where event_dt > '2019-04-22' and event_dt <= '2019-07-16'
group by  1
order by 1 ;

---------------Sheet Player Participation
--------Charts Online Players % to DAU and Avg Online matches per Day

select event_dt , sum(new_players) newp, sum(reacquired_players) reacq, sum(returning_players) retur, newp+reacq+retur total
from seven11_prod_da.wba_daily_activity
where event_dt between '2019-04-22' and  '2019-07-16'
group by  1
order by 1 ;

--- Ranked Matches -----

select date(wbanalyticssourcedate) date
        , count(distinct _platform_account_id) Daily_ranked_players
        , count(distinct match_id) ranked_matches
        , (ranked_matches*1.0)/Daily_ranked_players avg_ranked_matches_daily
      from seven11_prod.seven11_match_result_player a
      where activity_name ='GM_RANKED_ON_1V1' -- in ('GM_GROUP_BATTLES','GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_PRACTICE','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT','GM_PLAYER_MATCH_ON_KOTH') 
      and ai_difficulty= -1 and date(wbanalyticssourcedate)  between '2019-04-22' and  '2019-07-16'
      group by 1
	  order by 1;
	
	
	
--- other mode Matches -----

select date(wbanalyticssourcedate) date
        , count(distinct _platform_account_id) Daily_otheronlmode_players
        , count(distinct match_id) otheronlmode_matches
        , (otheronlmode_matches*1.0)/Daily_otheronlmode_players avg_otheronlmode_matches_daily
      from seven11_prod.seven11_match_result_player a
      where activity_name in ('GM_GROUP_BATTLES','GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_PRACTICE','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT','GM_PLAYER_MATCH_ON_KOTH') 
      and ai_difficulty= -1 and date(wbanalyticssourcedate)  between '2019-04-22' and  '2019-07-16'
      group by 1
	  order by 1;
	
	
--- Online mode Matches -----

select date(wbanalyticssourcedate) date
        , count(distinct _platform_account_id) Daily_online_players
        , count(distinct match_id) online_matches
        , (online_matches*1.0)/Daily_online_players avg_online_matches_daily
      from seven11_prod.seven11_match_result_player a
      where activity_name in ('GM_RANKED_ON_1V1','GM_GROUP_BATTLES','GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_PRACTICE','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT','GM_PLAYER_MATCH_ON_KOTH') 
      and ai_difficulty= -1 and date(wbanalyticssourcedate)  between '2019-04-22' and  '2019-07-16'
      group by 1
	  order by 1;
------------------------Chart Kombat League Players Funnel

--% Played - Kombat league---

select post_kl_players
	, total_players
	, one_and_above,two_and_above, three_and_above, four_and_above, five_and_above, above_five
from
( 
select Sum(played_one_match) one_and_above,Sum(played_two_match) two_and_above,Sum(played_three_match) three_and_above,
		Sum(played_four_match) four_and_above,Sum(played_five_match) five_and_above,Sum(played_more_than_five_matches) above_five
from(
select _platform_account_id,kl_matchescount,
		case when kl_matchescount >=1 then 1 else 0 end as played_one_match,
		case when kl_matchescount >=2 then 1 else 0 end as played_two_match,
		case when kl_matchescount >=3 then 1 else 0 end as played_three_match,
		case when kl_matchescount >=4 then 1 else 0 end as played_four_match,
		case when kl_matchescount >=5 then 1 else 0 end as played_five_match,
		case when kl_matchescount >=6 then 1 else 0 end as played_more_than_five_matches
from(
select _platform_account_id, count(distinct match_id) kl_matchescount
from seven11_prod.seven11_match_result_player
where match_season  =  ('ranked-1')  and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
group by 1))
) 
 cross join
(
SELECT count(distinct player_id) total_players
FROM seven11_prod_da.wba_fact_activity
where event_dt between '2019-04-22' and  '2019-07-16'
) 
 cross join
(
SELECT count(distinct player_id) post_kl_players
FROM seven11_prod_da.wba_fact_activity
where event_dt between '2019-06-18' and '2019-07-16'
) ;

--------------Sheet KL Players Comp
--------------Charts Engagement of KL Players (who played Online)(activity type and activity name level)

-----Kombat players---Played Online--Activity type level--21 days comparison before and after
with day_window as(
select 28 days
),

Played_Online_PvP as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-06-17'
	 and activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT')
group by 1 ),

kombat_league_players as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
and _platform_account_id in (select * from Played_Online_PvP)
group by 1)

select a.game_mode,Players_prior_kl,Avg_Hours_played_prior_kl,Players_post_kl,Avg_Hours_played_post_kl
from(
	select case when activity_name in ('GM_STORY_OFF') then 'story'
	 	when activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT') then 'PvP_Online'
	 	when activity_name in ('GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER','GM_KLASSIC_PORTAL_MODE','GM_KLASSIC_PORTAL_MODE_LADDER') then 'Towers'
	 	when activity_name in ('GM_FATALITY_TUTORIAL','GM_TUTORIAL_OFFLINE','GM_PRACTICE') then 'Tutorial'
	 	when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF') then 'PvP_Offline'
	 	when activity_name in ('GM_LOCAL_VERSUS_OFF','GM_AI_FIGHTER') then 'PvE_Offline'
	 	else 'Others' END AS Game_mode,count(distinct player_id) Players_prior_kl,
	 	sum(activity_hours) Hours_played_prior_kl,
	 	sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_prior_kl
	from 
 		(select *
	 	from seven11_prod_da.wba_fact_activity
 	 	cross join day_window)
	where date(event_dt) between dateadd(day,-days,'2019-06-17') and '2019-06-17' 
	and player_id in (select * from kombat_league_players)
	group by 1
	) a
join
	(
	select case when activity_name in ('GM_STORY_OFF') then 'story'
		 when activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT') then 'PvP_Online'
		 when activity_name in ('GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER','GM_KLASSIC_PORTAL_MODE','GM_KLASSIC_PORTAL_MODE_LADDER') then 'Towers'
		 when activity_name in ('GM_FATALITY_TUTORIAL','GM_TUTORIAL_OFFLINE','GM_PRACTICE') then 'Tutorial'
		 when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF') then 'PvP_Offline'
		 when activity_name in ('GM_LOCAL_VERSUS_OFF','GM_AI_FIGHTER') then 'PvE_Offline'
		 else 'Others' END AS Game_mode,count(distinct player_id) Players_post_kl,
		 sum(activity_hours) Hours_played_post_kl,
		 sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_post_kl
	from 
	(	
		select *
		from seven11_prod_da.wba_fact_activity
		cross join day_window)
	where date(event_dt) between  '2019-06-18' and dateadd(day,days,'2019-06-18') 
	and player_id in (select * from kombat_league_players)
	group by 1
	) b
on a.game_mode=b.game_mode ;

-----Kombat players---Played Online--Activity name level for Online PvP modes-- 21 days comparison before and after

with day_window as(
select 28 days
),

Played_Online_PvP as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-06-17'
	 and activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT')
group by 1 ),

kombat_league_players as(
select _platform_account_id
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
and _platform_account_id in (select * from Played_Online_PvP)
group by 1)

select a.Activity,Players_prior_kl,Avg_Hours_played_prior_kl,Players_post_kl,Avg_Hours_played_post_kl
from(
	select case when activity_name in ('GM_PLAYER_MATCH_ON_1V1') then 'GM_PLAYER_MATCH_ON_1V1'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1') then 'GM_PRIVATE_MATCH_ON_1V1'
	 	when activity_name in ('GM_RANKED_ON_1V1') then 'GM_RANKED_ON_1V1'
	 	when activity_name in ('GM_GROUP_BATTLES') then 'GM_GROUP_BATTLES'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_HOTSEAT') then 'GM_PRIVATE_MATCH_ON_HOTSEAT'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_KOTH') then 'GM_PRIVATE_MATCH_ON_KOTH'
		when activity_name in ( 'GM_PRIVATE_MATCH_ON_PRACTICE') then  'GM_PRIVATE_MATCH_ON_PRACTICE'
	 	when activity_name in ('GM_PLAYER_MATCH_ON_KOTH') then 'GM_PLAYER_MATCH_ON_KOTH'
	 	when activity_name in ('GM_PLAYER_MATCH_ON_HOT_SEAT') then 'GM_PLAYER_MATCH_ON_HOT_SEAT'
	 	else 'Others' END AS Activity,count(distinct player_id) Players_prior_kl,
	 	sum(activity_hours) Hours_played_prior_kl,
	 	sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_prior_kl
	from 
 		(select *
	 	from seven11_prod_da.wba_fact_activity
 	 	cross join day_window)
	where date(event_dt) between dateadd(day,-days,'2019-06-17') and '2019-06-17' 
	and player_id in (select * from kombat_league_players)
	group by 1
	) a
join
	(
	select case when activity_name in ('GM_PLAYER_MATCH_ON_1V1') then 'GM_PLAYER_MATCH_ON_1V1'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1') then 'GM_PRIVATE_MATCH_ON_1V1'
	 	when activity_name in ('GM_RANKED_ON_1V1') then 'GM_RANKED_ON_1V1'
	 	when activity_name in ('GM_GROUP_BATTLES') then 'GM_GROUP_BATTLES'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_HOTSEAT') then 'GM_PRIVATE_MATCH_ON_HOTSEAT'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_KOTH') then 'GM_PRIVATE_MATCH_ON_KOTH'
		when activity_name in ( 'GM_PRIVATE_MATCH_ON_PRACTICE') then  'GM_PRIVATE_MATCH_ON_PRACTICE'
	 	when activity_name in ('GM_PLAYER_MATCH_ON_KOTH') then 'GM_PLAYER_MATCH_ON_KOTH'
	 	when activity_name in ('GM_PLAYER_MATCH_ON_HOT_SEAT') then 'GM_PLAYER_MATCH_ON_HOT_SEAT'
	 	else 'Others' END AS Activity,count(distinct player_id) Players_post_kl,
		 sum(activity_hours) Hours_played_post_kl,
		 sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_post_kl
	from 
	(	
		select *
		from seven11_prod_da.wba_fact_activity
		cross join day_window)
	where date(event_dt) between  '2019-06-18' and dateadd(day,days,'2019-06-18') 
	and player_id in (select * from kombat_league_players)
	group by 1
	) b
on a.Activity=b.Activity 
where a.Activity != 'Others';

-----------Sheet Non Kombat Pack
-----------Chart - NoN Kombat pack owners Engagement 4 wk before and after KL Launch


with day_window as(
select 28 days
),

players as(
SELECT player_id
FROM seven11_prod_da.wba_fact_activity
where event_dt between '2019-04-22' and '2019-05-19'
group by 1),

Kombat_pack_players as(
select _platform_account_id, 
			max(case when entitlement_name in ('kombat_pack','digital_premium_edition','physical_premium_edition') 
			then 1 else 0 end) kombat_pack
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
group by 1
having kombat_pack =1),

No_kombat_pack_players as(
select player_id
from players
where player_id not in (select _platform_account_id from Kombat_pack_players)
group by 1)

select a.game_mode,Players_prior_kl,Avg_Hours_played_prior_kl,Players_post_kl,Avg_Hours_played_post_kl
from(
	select case when activity_name in ('GM_STORY_OFF') then 'story'
	 	when activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT') then 'PvP_Online'
	 	when activity_name in ('GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER','GM_KLASSIC_PORTAL_MODE','GM_KLASSIC_PORTAL_MODE_LADDER') then 'Towers'
	 	when activity_name in ('GM_FATALITY_TUTORIAL','GM_TUTORIAL_OFFLINE','GM_PRACTICE') then 'Tutorial'
	 	when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF') then 'PvP_Offline'
	 	when activity_name in ('GM_LOCAL_VERSUS_OFF','GM_AI_FIGHTER') then 'PvE_Offline'
	 	else 'Others' END AS Game_mode,count(distinct player_id) Players_prior_kl,
	 	sum(activity_hours) Hours_played_prior_kl,
	 	sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_prior_kl
	from 
 		(select *
	 	from seven11_prod_da.wba_fact_activity
 	 	cross join day_window)
	where date(event_dt) between dateadd(day,-days,'2019-06-17') and '2019-06-17' 
	and player_id in (select * from No_kombat_pack_players)
	group by 1
	) a
join
	(
	select case when activity_name in ('GM_STORY_OFF') then 'story'
		 when activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT') then 'PvP_Online'
		 when activity_name in ('GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER','GM_KLASSIC_PORTAL_MODE','GM_KLASSIC_PORTAL_MODE_LADDER') then 'Towers'
		 when activity_name in ('GM_FATALITY_TUTORIAL','GM_TUTORIAL_OFFLINE','GM_PRACTICE') then 'Tutorial'
		 when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF') then 'PvP_Offline'
		 when activity_name in ('GM_LOCAL_VERSUS_OFF','GM_AI_FIGHTER') then 'PvE_Offline'
		 else 'Others' END AS Game_mode,count(distinct player_id) Players_post_kl,
		 sum(activity_hours) Hours_played_post_kl,
		 sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_post_kl
	from 
	(	
		select *
		from seven11_prod_da.wba_fact_activity
		cross join day_window)
	where date(event_dt) between  '2019-06-18' and dateadd(day,days,'2019-06-18') 
	and player_id in (select * from No_kombat_pack_players)
	group by 1
	) b
on a.game_mode=b.game_mode ;



----------Retention in Kombat league for players who played and not played Online Pvp

With Played_Online_PvP as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-06-17'
	 and activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT')
group by 1 ),

Not_Played_Online_PvP as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-06-17'  and Player_id not in (Select player_id from Played_Online_PvP)
group by 1 )


-------Retention in KL for players who played Online Pvp

select period, joindate, count(c._platform_account_id) retained_players, count(b._platform_account_id) cohorts
from
(
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-06-18 00:00:00' and '2019-07-16 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-06-18 00:00:00' and '2019-07-16 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-06-18 00:00:00')
    AND (d2.YearMonthDay>='2019-06-18 00:00:00')
	order by 1,2
) A
join 
(

	select _platform_account_id, min(wbanalyticsprocessingdate) yearmonthday
	from seven11_prod.seven11_match_result_player
	where match_season = ('ranked-1')  and ai_difficulty= -1 and wbanalyticsprocessingdate  between '2019-06-18 00:00:00' and '2019-07-16 00:00:00'
	and _platform_account_id in (select player_id from Played_Online_PvP)
	group by 1

)  B
on a.joinDate = b.yearmonthday 
left join
(

	select wbanalyticsprocessingdate yearmonthday, _platform_account_id
	from seven11_prod.seven11_match_result_player a 
	where match_season  =  ('ranked-1')  and ai_difficulty= -1 and wbanalyticsprocessingdate between '2019-06-18 00:00:00' and '2019-07-16 00:00:00'
	and _platform_account_id in (select player_id from Played_Online_PvP)
	group by 1,2

) c
on b._platform_account_id = c._platform_account_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-06-18 00:00:00'
group by 1,2
order by 1,2 ;

-------Retention in KL for players who have not played Online PvP 

With Played_Online_PvP as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-06-17'
	 and activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT')
group by 1 ),

Not_Played_Online_PvP as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-06-17' and Player_id not in (Select player_id from Played_Online_PvP)
group by 1 )

select period, joindate, count(c._platform_account_id) retained_players, count(b._platform_account_id) cohorts
from
(
	SELECT d.YearMonthDay joinDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
    FROM (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-06-18 00:00:00' and '2019-07-16 00:00:00'
			group by 1
		 ) d 
    JOIN (
			select wbanalyticsprocessingdate YearMonthDay
			from seven11_prod.seven11_activity_begin
			where wbanalyticsprocessingdate between '2019-06-18 00:00:00' and '2019-07-16 00:00:00'
			group by 1
		 ) d2 
	ON d.YearMonthDay < d2.YearMonthDay
    WHERE  (d.YearMonthDay>='2019-06-18 00:00:00')
    AND (d2.YearMonthDay>='2019-06-18 00:00:00')
	order by 1,2
) A
join 
(

	select _platform_account_id, min(wbanalyticsprocessingdate) yearmonthday
	from seven11_prod.seven11_match_result_player
	where match_season = ('ranked-1')  and ai_difficulty= -1 and wbanalyticsprocessingdate  between '2019-06-18 00:00:00' and '2019-07-16 00:00:00'
	and _platform_account_id in (select player_id from Not_Played_Online_PvP)
	group by 1

)  B
on a.joinDate = b.yearmonthday 
left join
(

	select wbanalyticsprocessingdate yearmonthday, _platform_account_id
	from seven11_prod.seven11_match_result_player a 
	where match_season  =  ('ranked-1')  and ai_difficulty= -1 and wbanalyticsprocessingdate between '2019-06-18 00:00:00' and '2019-07-16 00:00:00'
	and _platform_account_id in (select player_id from Not_Played_Online_PvP)
	group by 1,2

) c
on b._platform_account_id = c._platform_account_id
and c.yearmonthday = a.retentiondate
where b.yearmonthday >= '2019-06-18 00:00:00'
group by 1,2
order by 1,2 ;

-----sheet % Played KL(Non Onl)

-------------------daily level % played and avg matches for players who have not played Online PVP

With Played_Online_PvP as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-06-17'
	 and activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT')
group by 1 ),

Not_Played_Online_PvP as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-06-17' and Player_id not in (Select player_id from Played_Online_PvP)
group by 1 )


select date,Daily_kombat_players,avg_kl_matches_daily,Total_Players,(Daily_kombat_players)*1.0/Total_Players Perc_played
from(
select date(wbanalyticssourcedate) date
	, count(distinct _platform_account_id) Daily_kombat_players
	, count(distinct match_id) kl_matches
	, (kl_matches*1.0)/Daily_kombat_players avg_kl_matches_daily
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
	  and _platform_account_id in (select * from Not_Played_Online_PvP)
group by 1) 
cross join 
(select count(*) Total_Players
from Not_Played_Online_PvP) 
order by 1;


-----total-active-Kl Players- who played online PvP
With Played_Online_PvP as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-06-17'
	 and activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT')
group by 1 ),

Not_Played_Online_PvP as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-06-17' and Player_id not in (Select player_id from Played_Online_PvP)
group by 1 ),

Active_Players_Onl  as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-06-18' and '2019-07-16'
and Player_id in (select * from Played_Online_PvP)
group by 1 ) 


select kombat_players,avg_kl_matches,Total_Players,active_Players
from(
select count(distinct _platform_account_id) kombat_players
	, count(distinct match_id) kl_matches
	, (kl_matches*1.0)/kombat_players avg_kl_matches
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
	  and _platform_account_id in (select * from Played_Online_PvP)
) 
cross join 
(select count(*) Total_Players
from Played_Online_PvP)
cross join 
(select count(*) active_Players
from Active_Players_Onl) ;


-----total-active-Kl Players- who did not play online PvP

With Played_Online_PvP as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-06-17'
	 and activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT')
group by 1 ),

Not_Played_Online_PvP as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-04-22' and '2019-06-17' and Player_id not in (Select player_id from Played_Online_PvP)
group by 1 ),

Active_Players_Non_Onl  as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-06-18' and '2019-07-16' 
and Player_id in (select * from Not_Played_Online_PvP)
group by 1 ) 


select kombat_players,avg_kl_matches,Total_Players,active_Players
from(
select count(distinct _platform_account_id) kombat_players
	, count(distinct match_id) kl_matches
	, (kl_matches*1.0)/kombat_players avg_kl_matches
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-1') and ai_difficulty= -1 and date(wbanalyticssourcedate) between '2019-06-18' and '2019-07-16'
	  and _platform_account_id in (select * from Not_Played_Online_PvP)
) 
cross join 
(select count(*) Total_Players
from Not_Played_Online_PvP)
cross join 
(select count(*) active_Players
from Active_Players_Non_Onl)


