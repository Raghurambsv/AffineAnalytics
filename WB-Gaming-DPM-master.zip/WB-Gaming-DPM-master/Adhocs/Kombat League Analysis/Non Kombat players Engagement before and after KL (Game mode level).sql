--------Non Kombat pack Players Engagement 15 days before and after KL launch

with day_window as(
select 14 days
),

Active_Players  as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-06-18' and '2019-07-16' 
group by 1 ),

kombat_pack_Shang_tsung_players as(
select _platform_account_id , 
			max(case when entitlement_name in ('kombat_pack','shang_tsung') 
			then 1 else 0 end) kombat_pack_Shang_tsung
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
group by 1
having kombat_pack_Shang_tsung =1),

No_kombat_pack_players as(
select player_id
from Active_Players
where player_id not in (select _platform_account_id from kombat_pack_Shang_tsung_players)
group by 1)

select a.game_mode,Players_prior_kl,Avg_Hours_played_prior_kl,Players_post_kl,Avg_Hours_played_post_kl
from(
	select case when activity_name in ('GM_STORY_OFF') then 'story'
	 	when activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT') then 'PvP_Online'
	 	when activity_name in ('GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER','GM_KLASSIC_PORTAL_MODE','GM_KLASSIC_PORTAL_MODE_LADDER') then 'Towers'
	 	when activity_name in ('GM_FATALITY_TUTORIAL','GM_TUTORIAL_OFFLINE','GM_PRACTICE') then 'Tutorial'
	 	when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF') then 'PvP_Offline'
	 	when activity_name in ('GM_LOCAL_VERSUS_OFF','GM_AI_FIGHTER') then 'PvE_Offline'
	 	else 'Others' END AS Game_mode,count(distinct player_id) Players_prior_kl,
	 	sum(activity_hours) Hours_played_prior_kl,
	 	sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_prior_kl
	from 
 		(select *
	 	from seven11_prod_da.wba_fact_activity
 	 	cross join day_window)
	where date(event_dt) between dateadd(day,-days,'2019-06-17') and '2019-06-17' 
	and player_id in (select * from No_kombat_pack_players)
	group by 1
	) a
join
	(
	select case when activity_name in ('GM_STORY_OFF') then 'story'
		 when activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT') then 'PvP_Online'
		 when activity_name in ('GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER','GM_KLASSIC_PORTAL_MODE','GM_KLASSIC_PORTAL_MODE_LADDER') then 'Towers'
		 when activity_name in ('GM_FATALITY_TUTORIAL','GM_TUTORIAL_OFFLINE','GM_PRACTICE') then 'Tutorial'
		 when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF') then 'PvP_Offline'
		 when activity_name in ('GM_LOCAL_VERSUS_OFF','GM_AI_FIGHTER') then 'PvE_Offline'
		 else 'Others' END AS Game_mode,count(distinct player_id) Players_post_kl,
		 sum(activity_hours) Hours_played_post_kl,
		 sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_post_kl
	from 
	(	
		select *
		from seven11_prod_da.wba_fact_activity
		cross join day_window)
	where date(event_dt) between  '2019-06-18' and dateadd(day,days,'2019-06-18') 
	and player_id in (select * from No_kombat_pack_players)
	group by 1
	) b
on a.game_mode=b.game_mode ;

-----------------------------------------------------------------------------------------------------------------

--------Non Kombat pack Players Engagement 4 weeks before and after KL launch
with day_window as(
select 28 days
),

Active_Players  as(
select player_id
from seven11_prod_da.wba_fact_activity
where date(event_dt) between '2019-06-18' and '2019-07-16' 
group by 1 ),

kombat_pack_Shang_tsung_players as(
select _platform_account_id , 
			max(case when entitlement_name in ('kombat_pack','shang_tsung') 
			then 1 else 0 end) kombat_pack_Shang_tsung
from seven11_prod.seven11_dlc_entitlement
where date(_event_time_utc) <= '2019-07-16'
group by 1
having kombat_pack_Shang_tsung =1),

No_kombat_pack_players as(
select player_id
from Active_Players
where player_id not in (select _platform_account_id from kombat_pack_Shang_tsung_players)
group by 1)

select a.game_mode,Players_prior_kl,Avg_Hours_played_prior_kl,Players_post_kl,Avg_Hours_played_post_kl
from(
	select case when activity_name in ('GM_STORY_OFF') then 'story'
	 	when activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT') then 'PvP_Online'
	 	when activity_name in ('GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER','GM_KLASSIC_PORTAL_MODE','GM_KLASSIC_PORTAL_MODE_LADDER') then 'Towers'
	 	when activity_name in ('GM_FATALITY_TUTORIAL','GM_TUTORIAL_OFFLINE','GM_PRACTICE') then 'Tutorial'
	 	when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF') then 'PvP_Offline'
	 	when activity_name in ('GM_LOCAL_VERSUS_OFF','GM_AI_FIGHTER') then 'PvE_Offline'
	 	else 'Others' END AS Game_mode,count(distinct player_id) Players_prior_kl,
	 	sum(activity_hours) Hours_played_prior_kl,
	 	sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_prior_kl
	from 
 		(select *
	 	from seven11_prod_da.wba_fact_activity
 	 	cross join day_window)
	where date(event_dt) between dateadd(day,-days,'2019-06-17') and '2019-06-17' 
	and player_id in (select * from No_kombat_pack_players)
	group by 1
	) a
join
	(
	select case when activity_name in ('GM_STORY_OFF') then 'story'
		 when activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT') then 'PvP_Online'
		 when activity_name in ('GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER','GM_KLASSIC_PORTAL_MODE','GM_KLASSIC_PORTAL_MODE_LADDER') then 'Towers'
		 when activity_name in ('GM_FATALITY_TUTORIAL','GM_TUTORIAL_OFFLINE','GM_PRACTICE') then 'Tutorial'
		 when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF') then 'PvP_Offline'
		 when activity_name in ('GM_LOCAL_VERSUS_OFF','GM_AI_FIGHTER') then 'PvE_Offline'
		 else 'Others' END AS Game_mode,count(distinct player_id) Players_post_kl,
		 sum(activity_hours) Hours_played_post_kl,
		 sum(activity_hours)*1.0/count(distinct player_id) Avg_Hours_played_post_kl
	from 
	(	
		select *
		from seven11_prod_da.wba_fact_activity
		cross join day_window)
	where date(event_dt) between  '2019-06-18' and dateadd(day,days,'2019-06-18') 
	and player_id in (select * from No_kombat_pack_players)
	group by 1
	) b
on a.game_mode=b.game_mode ;