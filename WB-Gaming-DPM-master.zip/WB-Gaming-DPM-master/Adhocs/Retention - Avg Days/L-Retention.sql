with datedim as ( select event_dt YearMonthDay from seven11_prod_da.wba_fact_activity group by 1),
 retention_period_table as (
 	SELECT d.YearMonthDay NewDate, (datediff(DAY,d2.YearMonthDay, d.YearMonthDay ))+1 Retentionperiod, d2.YearMonthDay RetentionDate
 	FROM datedim d
 	JOIN datedim  d2 ON d.YearMonthDay >= d2.YearMonthDay
 	WHERE  (d.YearMonthDay>='2019-04-22' and d.YearMonthDay < CAST(getdate() as DATE))
 	AND (d2.YearMonthDay>='2019-04-22' and  d2.YearMonthDay < CAST(getdate() as DATE))
 )
 , player_activity as (
		 select event_dt yearmonthday, player_id
    	from seven11_prod_da.wba_player_daily a
		where event_dt >= '2019-04-22'
    	group by 1,2
 )
 
Select a.Newdate date,Day_7_Retention,COALESCE(Day_14_Retention,'') Day_14_Retention,COALESCE(Day_30_Retention,'') Day_30_Retention,
COALESCE(Day_60_Retention,'') Day_60_Retention,COALESCE(Day_90_Retention,'') Day_90_Retention
from
(
select  Newdate, count(player_id)::float/count(distinct player_id) Day_7_Retention
	from retention_period_table A
	left join 
	player_activity B
	on A.retentiondate = B.yearmonthday
	where retentionperiod <= 7 and Newdate >= '2019-04-28'
	group by 1
	) a
left join 
(
	select  Newdate, count(player_id)::float/count(distinct player_id) Day_14_Retention
	from retention_period_table A
	left join 
	player_activity B
	on A.retentiondate = B.yearmonthday
	where retentionperiod<=14 and Newdate >= '2019-05-05'
	group by 1
)  b
on a.Newdate = b.Newdate
left join 
(
	select Newdate, count(player_id)::float/count(distinct player_id) Day_30_Retention
	from retention_period_table A
	left join 
	player_activity B
	on A.retentiondate = B.yearmonthday
	where retentionperiod<=30 and Newdate >= '2019-05-21'
	group by 1
)  c
on a.Newdate = c.Newdate
left join
(
	select  Newdate, count(player_id)::float/count(distinct player_id) Day_60_Retention
	from retention_period_table A
	left join 
	player_activity B
	on A.retentiondate = B.yearmonthday
	where retentionperiod<=60 and Newdate >= '2019-06-20'
	group by 1
)  d
on a.Newdate = d.Newdate
left join
(
	select Newdate, count(player_id)::float/count(distinct player_id) Day_90_Retention
	from retention_period_table A
	left join 
	player_activity B
	on A.retentiondate = B.yearmonthday
	where retentionperiod<=90 and Newdate >= '2019-07-20'
	group by 1
) e
on a.Newdate = e.Newdate
