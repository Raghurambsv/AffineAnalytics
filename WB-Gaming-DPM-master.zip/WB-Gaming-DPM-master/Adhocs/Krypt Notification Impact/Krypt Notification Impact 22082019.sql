
------------------------DAU---Players Viewed Notification----Players Opened chest -----avg chests ----daily

with players as(
select player_id
from seven11_prod_da.wba_player_daily
where event_dt between '2019-04-22' and '2019-05-31'
group by 1),

players_who_opened_chests as(
select _platform_account_id
from(
select _platform_account_id
from seven11_prod.seven11_gameplay_kryptaction
where action = 'CHEST' 
and date(_event_time_utc) between '2019-04-22' and '2019-07-15'
and _platform_account_id in (select * from players) 
group by 1)
group by 1) ,

Not_opened_chests_krypt as (
select *
from players
where player_id not in (select * from players_who_opened_chests) ) ,

Notification_sent as(
select player_id
from seven11_prod_da.wba_fact_activity
where activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES',
'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,
'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT','GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER') 
and activity_hours > 0 and activity_hours is not NULL
and event_dt between '2019-07-16' and '2019-07-30'
and player_id in (select * from Not_opened_chests_krypt)
group by 1) ,

viewed_Notification as(
select _platform_account_id ,_session_id viewed_session,_event_time_utc viewed_date
from(
select  _platform_account_id ,_session_id,_event_time_utc,Rank()over(partition by _platform_account_id order by _event_time_utc) Rank
from seven11_prod.seven11_ui_decision 
where _platform_account_id in (select * from Notification_sent)
and source_index = 'explore-the-krypt-notification'
)
where Rank = 1
group by 1,2,3),

Opened_chest_after_viewing_notf as(
select _platform_account_id ,_session_id opened_session, _event_time_utc opened_date
from(
select  _platform_account_id ,_session_id, _event_time_utc,Rank()over(partition by _platform_account_id order by _event_time_utc) Rank
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select _platform_account_id from viewed_Notification)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
)
where Rank = 1
group by 1,2,3)

select *
from (
select date,Avg(chests) avg_chests
from(
select _platform_account_id,date(_event_time_utc) date,count(action) chests
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select _platform_account_id from Opened_chest_after_viewing_notf)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
group by 1,2)
group by 1
) a
left join 
(
select chest_opened_dt,count(distinct  _platform_account_id) Players_opened_chest
from(
select _platform_account_id, date(_event_time_utc) chest_opened_dt
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select _platform_account_id from viewed_Notification)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
group by 1,2)
group by 1) b
on a.date = b.chest_opened_dt
left join(
select event_dt ,count(distinct player_id) DAU
from seven11_prod_da.wba_fact_activity
where player_id in (select * from Notification_sent)
group by 1
) c
on a.date = c.event_dt
left join (
select date(_event_time_utc) viewed_dt, count(distinct _platform_account_id ) Players_viewed
from seven11_prod.seven11_ui_decision 
where _platform_account_id in (select * from Notification_sent)
and source_index = 'explore-the-krypt-notification'
group by 1
) d
on a.date = d.viewed_dt ;

------------DAU---Players Viewed Notification----Players Opened chest -----avg chests ----overall

with players as(
select player_id
from seven11_prod_da.wba_player_daily
where event_dt between '2019-04-22' and '2019-05-31'
group by 1),

players_who_opened_chests as(
select _platform_account_id
from(
select _platform_account_id
from seven11_prod.seven11_gameplay_kryptaction
where action = 'CHEST' 
and date(_event_time_utc) between '2019-04-22' and '2019-07-15'
and _platform_account_id in (select * from players) 
group by 1)
group by 1) ,

Not_opened_chests_krypt as (
select *
from players
where player_id not in (select * from players_who_opened_chests) ) ,

Notification_sent as(
select player_id
from seven11_prod_da.wba_fact_activity
where activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES',
'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,
'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT','GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER') 
and activity_hours > 0 and activity_hours is not NULL
and event_dt between '2019-07-16' and '2019-07-30'
and player_id in (select * from Not_opened_chests_krypt)
group by 1) ,

viewed_Notification as(
select _platform_account_id ,_session_id viewed_session,_event_time_utc viewed_date
from(
select  _platform_account_id ,_session_id,_event_time_utc,Rank()over(partition by _platform_account_id order by _event_time_utc) Rank
from seven11_prod.seven11_ui_decision 
where _platform_account_id in (select * from Notification_sent)
and source_index = 'explore-the-krypt-notification'
)
where Rank = 1
group by 1,2,3),

Opened_chest_after_viewing_notf as(
select _platform_account_id ,_session_id opened_session, _event_time_utc opened_date
from(
select  _platform_account_id ,_session_id, _event_time_utc,Rank()over(partition by _platform_account_id order by _event_time_utc) Rank
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select _platform_account_id from viewed_Notification)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
)
where Rank = 1
group by 1,2,3)


select *
from
(select count(distinct player_id) DAU
from seven11_prod_da.wba_fact_activity
where event_dt between '2019-07-16' and '2019-07-30'
and player_id in (select * from Notification_sent) 
)
cross join 
(select  count(distinct _platform_account_id ) Players_Viewed
from seven11_prod.seven11_ui_decision 
where _platform_account_id in (select * from Notification_sent)
and date(_event_time_utc) >= '2019-07-16' 
and source_index = 'explore-the-krypt-notification' 
)
cross join 
(select count(distinct  _platform_account_id) Players_Opened_chest
from(
select _platform_account_id
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select _platform_account_id from viewed_Notification)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
group by 1)
)
cross join 
(select Avg(chests) avg_chests
from(
select _platform_account_id,date(_event_time_utc) date,count(action) chests
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select _platform_account_id from Opened_chest_after_viewing_notf)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
group by 1,2) 
) ;

---------- players opened chest in same session and players who didn't open chest

with players as(
select player_id
from seven11_prod_da.wba_player_daily
where event_dt between '2019-04-22' and '2019-05-31'
group by 1),

players_who_opened_chests as(
select _platform_account_id
from(
select _platform_account_id
from seven11_prod.seven11_gameplay_kryptaction
where action = 'CHEST' 
and date(_event_time_utc) between '2019-04-22' and '2019-07-15'
and _platform_account_id in (select * from players) 
group by 1)
group by 1) ,

Not_opened_chests_krypt as (
select *
from players
where player_id not in (select * from players_who_opened_chests) ) ,

Notification_sent as(
select player_id
from seven11_prod_da.wba_fact_activity
where activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES',
'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,
'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT','GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER') 
and activity_hours > 0 and activity_hours is not NULL
and event_dt between '2019-07-16' and '2019-07-30'
and player_id in (select * from Not_opened_chests_krypt)
group by 1) ,

viewed_Notification as(
select _platform_account_id ,_session_id viewed_session,_event_time_utc viewed_date
from(
select  _platform_account_id ,_session_id,_event_time_utc,Rank()over(partition by _platform_account_id order by _event_time_utc) Rank
from seven11_prod.seven11_ui_decision 
where _platform_account_id in (select * from Notification_sent)
and source_index = 'explore-the-krypt-notification'
)
where Rank = 1
group by 1,2,3),

Opened_chest_after_viewing_notf as(
select _platform_account_id ,_session_id opened_session, _event_time_utc opened_date
from(
select  _platform_account_id ,_session_id, _event_time_utc,Rank()over(partition by _platform_account_id order by _event_time_utc) Rank
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select _platform_account_id from viewed_Notification)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
)
where Rank = 1
group by 1,2,3),

player_view_chest_open_table as(
select a.*,b.opened_session,b.opened_date,case when viewed_session=opened_session then 1
												when opened_session is Null then -1
												else 0 end as chest_open_flag
from viewed_Notification a
left join Opened_chest_after_viewing_notf b
on a._platform_account_id = b._platform_account_id)

select same_session,count(_platform_account_id)
from player_view_chest_open_table 
group by 1;

--------session gap before opening chest

with players as(
select player_id
from seven11_prod_da.wba_player_daily
where event_dt between '2019-04-22' and '2019-05-31'
group by 1),

players_who_opened_chests as(
select _platform_account_id
from(
select _platform_account_id
from seven11_prod.seven11_gameplay_kryptaction
where action = 'CHEST' 
and date(_event_time_utc) between '2019-04-22' and '2019-07-15'
and _platform_account_id in (select * from players) 
group by 1)
group by 1) ,

Not_opened_chests_krypt as (
select *
from players
where player_id not in (select * from players_who_opened_chests) ) ,

Notification_sent as(
select player_id
from seven11_prod_da.wba_fact_activity
where activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES',
'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,
'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT','GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER') 
and activity_hours > 0 and activity_hours is not NULL
and event_dt between '2019-07-16' and '2019-07-30'
and player_id in (select * from Not_opened_chests_krypt)
group by 1) ,

viewed_Notification as(
select _platform_account_id ,_session_id viewed_session,_event_time_utc viewed_date
from(
select  _platform_account_id ,_session_id,_event_time_utc,Rank()over(partition by _platform_account_id order by _event_time_utc) Rank
from seven11_prod.seven11_ui_decision 
where _platform_account_id in (select * from Notification_sent)
and source_index = 'explore-the-krypt-notification'
)
where Rank = 1
group by 1,2,3),

Opened_chest_after_viewing_notf as(
select _platform_account_id ,_session_id opened_session, _event_time_utc opened_date
from(
select  _platform_account_id ,_session_id, _event_time_utc,Rank()over(partition by _platform_account_id order by _event_time_utc) Rank
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select _platform_account_id from viewed_Notification)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
)
where Rank = 1
group by 1,2,3),

player_view_chest_open_table as(
select a.*,b.opened_session,b.opened_date,case when viewed_session=opened_session then 1
												when opened_session is Null then -1
												else 0 end as chest_open_flag
from viewed_Notification a
left join Opened_chest_after_viewing_notf b
on a._platform_account_id = b._platform_account_id)

select sessions,count(distinct _platform_account_id) players
from(
select _platform_account_id,count(distinct _session_id) sessions 
from (
select a._platform_account_id,a.same_session, b._session_id
from player_view_chest_open_table a
left join seven11_prod.seven11_match_result_player b
on a._platform_account_id = b._platform_account_id
and _event_time_utc between viewed_date and opened_date
group by 1,2,3)
where same_session = 0
group by 1) 
group by 1
order by 1;

--------------------------Players not Viewed Notification----Players Opened chest -----avg chests ----daily

with players as(
select player_id
from seven11_prod_da.wba_player_daily
where event_dt between '2019-04-22' and '2019-05-31'
group by 1),

players_who_opened_chests as(
select _platform_account_id
from(
select _platform_account_id
from seven11_prod.seven11_gameplay_kryptaction
where action = 'CHEST' 
and date(_event_time_utc) between '2019-04-22' and '2019-07-15'
and _platform_account_id in (select * from players) 
group by 1)
group by 1) ,

Not_opened_chests_krypt as (
select *
from players
where player_id not in (select * from players_who_opened_chests) ) ,

Notification_sent as(
select player_id
from seven11_prod_da.wba_fact_activity
where activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES',
'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,
'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT','GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER') 
and activity_hours > 0 and activity_hours is not NULL
and event_dt between '2019-07-16' and '2019-07-30'
and player_id in (select * from Not_opened_chests_krypt)
group by 1) ,

viewed_Notification as(
select _platform_account_id ,_session_id viewed_session,_event_time_utc viewed_date
from(
select  _platform_account_id ,_session_id,_event_time_utc,Rank()over(partition by _platform_account_id order by _event_time_utc) Rank
from seven11_prod.seven11_ui_decision 
where _platform_account_id in (select * from Notification_sent)
and source_index = 'explore-the-krypt-notification'
)
where Rank = 1
group by 1,2,3),

Not_viewed_players as (
select player_id
from seven11_prod_da.wba_fact_activity
where player_id in (select * from Notification_sent)
and player_id not in (select _platform_account_id from viewed_Notification)
group by 1
) ,

Opened_chest_without_viewing_notf as(
select _platform_account_id ,_session_id opened_session, _event_time_utc opened_date
from(
select  _platform_account_id ,_session_id, _event_time_utc,Rank()over(partition by _platform_account_id order by _event_time_utc) Rank
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select player_id from Not_viewed_players)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
)
where Rank = 1
group by 1,2,3)

select *
from (
select date,Avg(chests) avg_chests
from(
select _platform_account_id,date(_event_time_utc) date,count(action) chests
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select _platform_account_id from Opened_chest_without_viewing_notf)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
group by 1,2)
group by 1
) a
left join 
(
select chest_opened_dt,count(distinct  _platform_account_id) Players_opened_chest
from(
select _platform_account_id, date(_event_time_utc) chest_opened_dt
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select player_id from Not_viewed_players)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
group by 1,2)
group by 1) b
on a.date = b.chest_opened_dt
left join(
select event_dt ,count(distinct player_id) Not_viewed_players
from seven11_prod_da.wba_fact_activity
where player_id in (select * from Notification_sent)
and player_id in (select player_id from Not_viewed_players)
and event_dt between '2019-07-16' and '2019-07-30'
group by 1
) c
on a.date = c.event_dt
;

--------------Players not Viewed Notification----Players Opened chest -----avg chests ----overall

with players as(
select player_id
from seven11_prod_da.wba_player_daily
where event_dt between '2019-04-22' and '2019-05-31'
group by 1),

players_who_opened_chests as(
select _platform_account_id
from(
select _platform_account_id
from seven11_prod.seven11_gameplay_kryptaction
where action = 'CHEST' 
and date(_event_time_utc) between '2019-04-22' and '2019-07-15'
and _platform_account_id in (select * from players) 
group by 1)
group by 1) ,

Not_opened_chests_krypt as (
select *
from players
where player_id not in (select * from players_who_opened_chests) ) ,

Notification_sent as(
select player_id
from seven11_prod_da.wba_fact_activity
where activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1','GM_GROUP_BATTLES',
'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,
'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT','GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER') 
and activity_hours > 0 and activity_hours is not NULL
and event_dt between '2019-07-16' and '2019-07-30'
and player_id in (select * from Not_opened_chests_krypt)
group by 1) ,

viewed_Notification as(
select _platform_account_id ,_session_id viewed_session,_event_time_utc viewed_date
from(
select  _platform_account_id ,_session_id,_event_time_utc,Rank()over(partition by _platform_account_id order by _event_time_utc) Rank
from seven11_prod.seven11_ui_decision 
where _platform_account_id in (select * from Notification_sent)
and source_index = 'explore-the-krypt-notification'
)
where Rank = 1
group by 1,2,3),

Not_viewed_players as (
select  player_id
from seven11_prod_da.wba_fact_activity
where player_id in (select * from Notification_sent)
and player_id not in (select _platform_account_id from viewed_Notification)
group by 1
) ,

Opened_chest_without_viewing_notf as(
select _platform_account_id ,_session_id opened_session, _event_time_utc opened_date
from(
select  _platform_account_id ,_session_id, _event_time_utc,Rank()over(partition by _platform_account_id order by _event_time_utc) Rank
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select player_id from Not_viewed_players)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
)
where Rank = 1
group by 1,2,3)


select *
from (
select Avg(chests) avg_chests
from(
select _platform_account_id,date(_event_time_utc) date,count(action) chests
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select _platform_account_id from Opened_chest_without_viewing_notf)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
group by 1,2)
)
cross join 
(
select count(distinct  _platform_account_id) Players_opened_chest
from(
select _platform_account_id, date(_event_time_utc) chest_opened_dt
from seven11_prod.seven11_gameplay_kryptaction
where _platform_account_id in (select player_id from Not_viewed_players)
and action = 'CHEST'
and date(_event_time_utc) >= '2019-07-16'
group by 1,2)
)
cross join(
select count(distinct player_id) Not_viewed_players
from seven11_prod_da.wba_fact_activity
where player_id in (select * from Notification_sent)
and event_dt between '2019-07-16' and '2019-07-30'
and player_id in (select player_id from Not_viewed_players)
) c
 ;

