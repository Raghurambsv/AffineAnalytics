---------Players_acquired_Skarlet_items

Select unlock_name, case when unlock_name LIKE ('%Gear%') Then 'Gear' 
				when unlock_name LIKE ('%Skin%') Then 'Skin' 
				When unlock_name LIKE ('%Brutality%') Then 'Brutality' 
				When unlock_name LIKE ('%Intro%') Then 'Intro' 
				When unlock_name LIKE ('%Victory%') Then 'Victory' 
				else 'Other' end as Category,count(distinct _platform_account_id) Players_acquired_Skarlet_items
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) >= '2019-04-22' and Substring(unlock_name,1,3) in ('SKA')
AND unlock_source NOT IN ('PREMIUM_SHOP')
group by 1,2 ;

-------Players_purchased_Skarlet_items

Select unlock_name, case when unlock_name LIKE ('%Gear%') Then 'Gear' 
				when unlock_name LIKE ('%Skin%') Then 'Skin' 
				When unlock_name LIKE ('%Brutality%') Then 'Brutality' 
				When unlock_name LIKE ('%Intro%') Then 'Intro' 
				When unlock_name LIKE ('%Victory%') Then 'Victory' 
				else 'Other' end as Category, count(distinct _platform_account_id) Players_purchased_Skarlet_items
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) >= '2019-04-22' and Substring(unlock_name,1,3) in ('SKA')
AND unlock_source IN ('PREMIUM_SHOP')
group by 1,2  ;


--------Players_acquired_Scorpion_items
 Select unlock_name, case when unlock_name LIKE ('%Gear%') Then 'Gear' 
				when unlock_name LIKE ('%Skin%') Then 'Skin' 
				When unlock_name LIKE ('%Brutality%') Then 'Brutality' 
				When unlock_name LIKE ('%Intro%') Then 'Intro' 
				When unlock_name LIKE ('%Victory%') Then 'Victory' 
				else 'Other' end as Category,count(distinct _platform_account_id) Players_acquired_Scorpion_items
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) >= '2019-04-22' and Substring(unlock_name,1,3) in ('SCO')
AND unlock_source NOT IN ('PREMIUM_SHOP')
group by 1,2  ;


-------Players_purchased_Scorpion_items
Select unlock_name, case when unlock_name LIKE ('%Gear%') Then 'Gear' 
				when unlock_name LIKE ('%Skin%') Then 'Skin' 
				When unlock_name LIKE ('%Brutality%') Then 'Brutality' 
				When unlock_name LIKE ('%Intro%') Then 'Intro' 
				When unlock_name LIKE ('%Victory%') Then 'Victory' 
				else 'Other' end as Category,count(distinct _platform_account_id) Players_purchased_Scorpion_items
from seven11_prod.seven11_progression_unlock
where date(_event_time_utc) >= '2019-04-22' and Substring(unlock_name,1,3) in ('SCO')
AND unlock_source IN ('PREMIUM_SHOP')
group by 1,2 ;

----Total_Players

select count(*)
from (
select player_id
from seven11_prod_da.wba_fact_activity
where event_dt >= '2019-04-22' 
group by 1 )  ;


------Scorpion_Players

select count(distinct _platform_account_id) Scorpion_Players
from seven11_prod.seven11_match_result_player
where character in ('char_scorpion','tagassist_scorpion')
and  ai_difficulty= -1 and date(wbanalyticssourcedate)  >= '2019-04-22' 
and activity_name not in ('GM_STORY_OFF')
 ;


------Skarlet_Players

select count(distinct _platform_account_id) Skarlet_Players
from seven11_prod.seven11_match_result_player
where character in ('char_skarlet','tagassist_skarlet')
and  ai_difficulty= -1 and date(wbanalyticssourcedate)  >= '2019-04-22' 
and activity_name not in ('GM_STORY_OFF')
;
