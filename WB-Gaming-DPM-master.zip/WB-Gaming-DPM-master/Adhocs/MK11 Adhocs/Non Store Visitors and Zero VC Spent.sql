
------------------------- Non Store Visitors
select count(distinct player_id) nonstorevisitors from seven11_prod_da.wba_player_daily
where player_id not in (select distinct _platform_account_id from seven11_prod.seven11_dlc_visitstore)
and date(event_dt) between '2019-04-22' and '2020-01-07';

------------------------- Non VC Spenders
with vc_spenders as
(
	select distinct _platform_account_id
	from
	(
		select _platform_account_id, Sum(change_amount) VC_Spent
		from seven11_prod.seven11_resource_flow
		where resource = 'Exp_PremiumCurrency'
		and change_amount < 0 and source in ('PREMIUM_SHOP' ,'PREMIUM_SHOP_IN_CUSTOMIZE')
		and date(_event_time_utc) between '2019-04-22' and '2020-01-07'
		group by 1
	)
	where VC_Spent!= 0
)
select count(distinct player_id) NoVCSpent
from seven11_prod_da.wba_player_daily
where date(event_dt) between '2019-04-22' and '2020-01-07'
and player_id not in (select * from vc_spenders);



