
------------------- Shang Tsung

with st_purchasers as
(
select player_id
           from seven11_prod_da.player_monetization_panel
           where shang_tsung=1
           and date(play_date) between '2019-06-25' and '2019-07-08'
		   and player_id in (select player_id
                                    from  seven11_prod_da.player_monetization_panel
                                    where shang_tsung=0
                                    and date(play_date) = '2019-06-24'
                                    group by 1
                                    )
    group by 1
),

st_active as
(
	select player_id
	from seven11_prod_da.wba_player_daily
	where date(event_dt) between '2019-06-25' and '2019-07-08'
	group by 1
)

select country_name STCountry, count(player_id) Total_Players, sum(stactive) Active_Players, sum(stpurchased) Purchases
from (
	select country_name, player_id, 
	case when player_id in (select * from st_active) then '1'
	else '0' end as stactive,
	case when player_id in (select * from st_purchasers) then '1'
	else '0' end as stpurchased
	from seven11_prod_da.wba_fact_activity
	where platform= 'XBoxOne'
	group by 1,2
)
group by 1;

------------------- Nightwolf
with nw_purchasers as 
(
select player_id
           from seven11_prod_da.player_monetization_panel
           where nightwolf=1
           and date(play_date) between '2019-08-20' and '2019-09-02'
		   and player_id in (select player_id
                                    from  seven11_prod_da.player_monetization_panel
                                    where nightwolf=0
                                    and date(play_date) = '2019-08-19'
                                    group by 1
                                    )
    group by 1
),

nw_active as
(
	select player_id
	from seven11_prod_da.wba_player_daily
	where date(event_dt) between '2019-08-20' and '2019-09-02'
	group by 1
)

select country_name NWCountry, count(player_id) NWTotal_Players, sum(stactive) Active_Players, sum(stpurchased) Purchases
from (
	select country_name, player_id, 
	case when player_id in (select * from nw_active) then '1'
	else '0' end as stactive,
	case when player_id in (select * from nw_purchasers) then '1'
	else '0' end as stpurchased
	from seven11_prod_da.wba_fact_activity
	where platform= 'XBoxOne'
	group by 1,2
)
group by 1;


------------------- Terminator
with ter_purchasers as 
(
select player_id
           from seven11_prod_da.player_monetization_panel
           where terminator=1
           and date(play_date) between '2019-10-15' and '2019-10-28'
		   and player_id in (select player_id
                                    from  seven11_prod_da.player_monetization_panel
                                    where terminator=0
                                    and date(play_date) = '2019-10-14'
                                    group by 1
                                    )
    group by 1
),

ter_active as
(
	select player_id
	from seven11_prod_da.wba_player_daily
	where date(event_dt) between '2019-10-15' and '2019-10-28'
	group by 1
)

select country_name TerCountry, count(player_id) TerTotal_Players, sum(stactive) Active_Players, sum(stpurchased) Purchases
from (
	select country_name, player_id, 
	case when player_id in (select * from ter_active) then '1'
	else '0' end as stactive,
	case when player_id in (select * from ter_purchasers) then '1'
	else '0' end as stpurchased
	from seven11_prod_da.wba_fact_activity
	where platform= 'XBoxOne'
	group by 1,2
)
group by 1;

------------------- Sindel
with sin_purchasers as 
(
select player_id
           from seven11_prod_da.player_monetization_panel
           where sindel=1
           and date(play_date) between '2019-12-03' and '2019-12-16'
		   and player_id in (select player_id
                                    from  seven11_prod_da.player_monetization_panel
                                    where sindel=0
                                    and date(play_date) = '2019-10-14'
                                    group by 1
                                    )
    group by 1
),

sin_active as
(
	select player_id
	from seven11_prod_da.wba_player_daily
	where date(event_dt) between '2019-12-03' and '2019-12-16'
	group by 1
)

select country_name SinCountry, count(player_id) SinTotal_Players, sum(stactive) Active_Players, sum(stpurchased) Purchases
from (
	select country_name, player_id, 
	case when player_id in (select * from sin_active) then '1'
	else '0' end as stactive,
	case when player_id in (select * from sin_purchasers) then '1'
	else '0' end as stpurchased
	from seven11_prod_da.wba_fact_activity
	where platform= 'XBoxOne'
	group by 1,2
)
group by 1;