
-----Brutalities used 

select brutality_used,count(players) player_count,Avg(matches_played) Avg_matches_played
from(
select _platform_account_id players,Sum(case when finisher_used = 'brutality' then 1 else 0 end) brutality_used,COUNT(DISTINCT match_id) matches_played
	   ---case when finisher_id = 'fatality' then 1 else 0 as fatality_used
from seven11_prod.seven11_match_result_player
where date(_event_time_utc) >= '2019-04-22' and ai_difficulty = -1 and ai_player = 0
group by 1)
group by 1 ;

-----Fatalities used

select fatality_used,count(players) player_count,Avg(matches_played) Avg_matches_played
from(
select _platform_account_id players,Sum(case when finisher_used = 'fatality' then 1 else 0  end) fatality_used,COUNT(DISTINCT match_id) matches_played
from seven11_prod.seven11_match_result_player
where date(_event_time_utc) >= '2019-04-22' and ai_difficulty = -1 and ai_player = 0
group by 1)
group by 1 ;

-----Krypt visits

select krypt_visits,count(player_id) player_count
from(
select player_id,Sum(activity_count) krypt_visits
from seven11_prod_da.wba_fact_activity
where activity_name = 'GM_KRYPT' and activity_hours > 0 and activity_hours is not NULL
and event_dt >= '2019-04-22'
group by 1)
group by 1