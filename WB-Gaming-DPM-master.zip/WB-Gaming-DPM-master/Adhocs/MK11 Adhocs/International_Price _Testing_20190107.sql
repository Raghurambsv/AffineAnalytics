
------------- Total, active and purchasing players-----Shang Tsung 
with st_purhasers as(
select _platform_account_id purchasers
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('shang_tsung')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition',
								 'digital_premium_edition','kollectors_edition_skin')
								 and date(wbanalyticssourcedate) <= '2019-07-08'
                                 group by 1
                                 )
and date(wbanalyticssourcedate) between '2019-06-25' and '2019-07-08'
group by 1
),

st_active_xone as
(
	select country_name,player_id active
	from seven11_prod_da.wba_player_daily
	where date(event_dt) between '2019-06-25' and '2019-07-08'
	and platform in ('XBoxOne')
	group by 1,2
),

st_total_xone as
(
	select country_name,player_id total
	from seven11_prod_da.wba_player_daily
	where date(event_dt) between '2019-04-22' and '2019-07-08'
	and platform in ('XBoxOne')
	group by 1,2
)

Select a.country_name ST Country,count(distinct total) Total,count(distinct active) Active_Players,Count(distinct purchasers) Purchased_players
from st_total_xone a
left join st_active_xone
on total = active
left join st_purhasers
on total = purchasers 
group by 1
order by 1;


------------- Total, active and purchasing players-----Nightwolf

with nw_purhasers as(
select _platform_account_id purchasers
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('nightwolf')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition',
								 'digital_premium_edition','kollectors_edition_skin')
								 and date(wbanalyticssourcedate) <= '2019-09-02'
                                 group by 1
                                 )
and date(wbanalyticssourcedate) between '2019-08-20' and '2019-09-02'
group by 1
),

nw_active_xone as
(
	select country_name,player_id active
	from seven11_prod_da.wba_player_daily
	where date(event_dt) between '2019-08-20' and '2019-09-02'
	and platform in ('XBoxOne')
	group by 1,2
),

nw_total_xone as
(
	select country_name,player_id total
	from seven11_prod_da.wba_player_daily
	where date(event_dt) between '2019-04-22' and '2019-09-02'
	and platform in ('XBoxOne')
	group by 1,2
)

Select a.country_name NWCountry,count(distinct total) Total,count(distinct active) Active_Players,Count(distinct purchasers) Purchased_players
from nw_total_xone a
left join nw_active_xone
on total = active
left join nw_purhasers
on total = purchasers 
group by 1
order by 1;


------------- Total, active and purchasing players-----Terminator

with tnt_purhasers as(
select _platform_account_id purchasers
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('terminator')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition',
								 'digital_premium_edition','kollectors_edition_skin')
								 and date(wbanalyticssourcedate) <= '2019-10-28'
                                 group by 1
                                 )
and date(wbanalyticssourcedate) between '2019-10-15' and '2019-10-28'
group by 1
),

tnt_active_xone as
(
	select country_name,player_id active
	from seven11_prod_da.wba_player_daily
	where date(event_dt) between '2019-10-15' and '2019-10-28'
	and platform in ('XBoxOne')
	group by 1,2
),

tnt_total_xone as
(
	select country_name,player_id total
	from seven11_prod_da.wba_player_daily
	where date(event_dt) between '2019-04-22' and '2019-10-28'
	and platform in ('XBoxOne')
	group by 1,2
)

Select a.country_name Ter_Country,count(distinct total) Total,count(distinct active) Active_Players,Count(distinct purchasers) Purchased_players
from tnt_total_xone a
left join tnt_active_xone
on total = active
left join tnt_purhasers
on total = purchasers 
group by 1
order by 1;

------------- Total, active and purchasing players-----Sindel

with sd_purhasers as(
select _platform_account_id purchasers
from seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('sindel')
and _platform_account_id not in (select _platform_account_id
                                 from  seven11_prod.seven11_dlc_entitlement
                                 where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition',
								 'digital_premium_edition','kollectors_edition_skin')
								 and date(wbanalyticssourcedate) <= '2019-12-16'
                                 group by 1
                                 )
and date(wbanalyticssourcedate) between '2019-12-03' and '2019-12-16'
group by 1
),

sd_active_xone as
(
	select country_name,player_id active
	from seven11_prod_da.wba_player_daily
	where date(event_dt) between '2019-12-03' and '2019-12-16'
	and platform in ('XBoxOne')
	group by 1,2
),

sd_total_xone as
(
	select country_name,player_id total
	from seven11_prod_da.wba_player_daily
	where date(event_dt) between '2019-04-22' and '2019-12-16'
	and platform in ('XBoxOne')
	group by 1,2
)

Select a.country_name SinCountry,count(distinct total) Total, count(distinct active) Active_Players,Count(distinct purchasers) Purchased_players
from sd_total_xone a
left join sd_active_xone
on total = active
left join sd_purhasers
on total = purchasers
group by 1
order by 1;

