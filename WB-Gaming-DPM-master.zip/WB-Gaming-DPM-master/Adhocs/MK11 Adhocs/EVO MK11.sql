--------------------FULL GAME DAUs----------------------------------
select date(event_dt) date, count(distinct player_id) DAU
FROM seven11_prod_da.wba_player_daily
where date(event_dt) between '2019-07-22' and '2019-08-04'
group by 1 ;

--------------------FULL GAME Weekend over Weekend DAUs----------------------------------
select *
from
(
       select count(distinct player_id) DAU_weekend1
       FROM seven11_prod_da.wba_player_daily
       where date(event_dt) between '2019-07-26' and '2019-07-28'
)
cross join 
(
       select count(distinct player_id) DAU_weekend2
       FROM seven11_prod_da.wba_player_daily
       where date(event_dt) between '2019-08-02' and '2019-08-04'
)
;
----------------------KL DAU----------------------------------
select date(_event_time_utc) date, count(distinct _platform_account_id) KL_DAU
from seven11_prod.seven11_match_result_player
where match_season =  ('ranked-2') and ai_difficulty= -1 and date(_event_time_utc) between '2019-07-22' and '2019-08-04'
group by 1
;
--------------------KL Weekend over Weekend DAUs----------------------------------
select *
from
(
       select count(distinct _platform_account_id) KL_DAU_weekend1
       FROM seven11_prod.seven11_match_result_player
       where match_season =  ('ranked-2') and ai_difficulty= -1 and date(_event_time_utc) between '2019-07-26' and '2019-07-28'
)
cross join 
(
       select count(distinct _platform_account_id) KL_DAU_weekend2
       FROM seven11_prod.seven11_match_result_player
       where match_season =  ('ranked-2') and ai_difficulty= -1 and date(_event_time_utc) between '2019-08-02' and '2019-08-04'
)
;

---Re-engaged Players weekend over weekend-----

with players as (select event_dt, player_id
from seven11_prod_da.wba_player_daily
where event_dt >='2019-07-19'
group by 1,2) ,

re_engaged_players1 as (
select event_dt, player_id
from players a
where a.event_dt  >= '2019-07-26' and event_dt <= '2019-07-28'
and player_id in (select distinct b.player_id from players b
where b.event_dt between '2019-07-19' and '2019-07-21' )
group by  1,2
order by 1,2
) ,

re_engaged_players2 as (
select event_dt, player_id
from players a
where a.event_dt  >= '2019-08-02' and event_dt <= '2019-08-04'
and player_id in (select distinct b.player_id from players b
where b.event_dt between '2019-07-26' and '2019-07-28' )
group by  1,2
order by 1,2
)
-----------
select *
from
(
       select count(distinct player_id) re_engaged_players_weekend1
    from re_engaged_players1
)      
cross join
(
       select count(distinct player_id) weekend0_players
    from players
       where event_dt between '2019-07-19' and '2019-07-21'
)      
cross join
(
       select count(distinct player_id) re_engaged_players_weekend2
    from re_engaged_players2
)      
cross join
(
       select count(distinct player_id) weekend1_players
    from players
       where event_dt between '2019-07-26' and '2019-07-28'
)      
cross join
(
       select count(distinct player_id) weekend2_players
    from players
       where event_dt between '2019-08-02' and '2019-08-04'
)      
cross join
(
       select count(distinct player_id) week1_players
    from players
       where event_dt between '2019-07-22' and '2019-07-28'
)      
cross join
(
       select count(distinct player_id) week2_players
    from players
       where event_dt between '2019-07-29' and '2019-08-04'
)      
;



