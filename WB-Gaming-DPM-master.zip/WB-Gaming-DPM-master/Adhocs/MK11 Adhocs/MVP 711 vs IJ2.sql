----MK11 MVP>9.5hrs ----
with  weekly_Players as (
	select event_week_dt, sum(active_players) WAU
	from seven11_prod_da.wba_weekly_activity
	group by 1
	order by 1
)
--------
select week_ending_date, WAU, count(distinct player_id) mvp_players
from 
(
	select  player_id, week_ending_date, Sum(total_hours) weeklyhrs
	from seven11_prod_da.wba_player_daily
	--where player_id in ( 6444982319503568736, 5690879074854825066)
	group by 1,2
	order by 2
) a right join weekly_Players b on a.week_ending_date = b.event_week_dt
where week_ending_date >='2019-04-22'
and weeklyhrs>=9.5  -- change this for MVP criteria
group by 1,2
order by 1

-------MK11 Weekly engagement break into the 3 Buckets----------------
with Players as (
select player_id , event_dt, activity_name, activity_hours
from seven11_prod_da.wba_fact_activity
where DATE(event_dt) >='2019-04-22' and activity_hours is not NULL and activity_name not in 
	('GM_KLASSIC_PORTAL_MODE_LADDER','GM_TOWERS_OF_TIME_LADDER','GM_MAINMENU_OPTIONS','GM_AI_FIGHTER_HUB',
	'GM_CHAT_LOBBY','GM_KOMBAT_KARD','GM_MATCH_REPLAY','GM_ONLINE_HUB','GM_STORE')
)
-------
select week_ending_date
, sum(case when activity_name in ('GM_TOURNAMENT_ONLINE_1V1', 'GM_PRIVATE_MATCH_ON_1V1', 'GM_PRIVATE_MATCH_ON_HOTSEAT'
, 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE', 'GM_RANKED_ON_1V1', 'GM_PLAYER_MATCH_ON_1V1'
, 'GM_PLAYER_MATCH_ON_HOT_SEAT', 'GM_PLAYER_MATCH_ON_KOTH') then activity_hours else 0 end) PvP
, sum(case when activity_name in ('GM_GROUP_BATTLES', 'GM_KLASSIC_PORTAL_MODE', 'GM_STORY_OFF', 'GM_LADDER_OFF'
, 'GM_TOWERS_OF_TIME') then activity_hours else 0 end) PvE
, sum(case when activity_name in ('GM_AI_FIGHTER', 'GM_ATTRACT', 'GM_CAP_CUSTOMIZATION', 'GM_CHARACTER_VIEWER'
, 'GM_FATALITY_TUTORIAL','GM_KOLLECTION', 'GM_MAINMENU', 'GM_PRACTICE', 'GM_PLAYER_MATCH_ON_PRACTICE'
, 'GM_MULTI_TOURNAMENT_OFF', 'GM_MULTI_VERSUS_OFF', 'GM_LOCAL_VERSUS_OFF', 'GM_TUTORIAL_OFFLINE'
, 'GM_KRYPT') then activity_hours else 0 end) Others											 
from
(	select  player_id, week_ending_date, Sum(total_hours) weeklyhrs
	from seven11_prod_da.wba_player_daily
	--where player_id in ( 6444982319503568736, 5690879074854825066)
	group by 1,2
) a 
join Players b 
on a.player_id = b.player_id and b.event_dt between dateadd(day, -6, week_ending_date) and week_ending_date
where week_ending_date >='2019-04-22'
and weeklyhrs>9.5  -- change this for MVP criteria
group by 1
order by 1

----------------------------IJ2 MVP>9.5hrs-----------------
with weekly_Players as (
	select week_ending_date, sum(active_players) WAU
	from pachinko_prod_da.agg_weekly_player
	group by 1
	order by 1
)
-------
select a.week_ending_date,WAU,count(distinct platformaccountid) mvp_players,sum(PvP) PvP,sum(PvE) PvE,sum(Others) Others
from
(	select a.platformaccountid, Date(Dateadd(day, 6, DATE_TRUNC('week', yearmonthday)))  week_ending_date   
	, sum(durationhours) weeklyhrs, sum(case when activityname in ('Online Player Match', 'Online Hot Seat'
	, 'Online King of the Hill', 'Online Practice Match', 'Online Private Player Match'
	, 'Online Private King of the Hill', 'Online Private Practice', 'Online Ranked Player Match'
	, 'Online Private Hot Seat', 'Online Player Match', 'Online Ranked Player Match') 
	then durationhours else 0 end) PvP
	, sum(case when activityname in ('Group Battles', 'Ladder Offline', 'Story Mode', 'Tower') 
	then durationhours else 0 end) PvE
	, sum(case when activityname in ('AI Fighter', 'Character Customization', 'Guilds', 'Lootchest Viewer'
	, 'Match Replay', 'Offline Tournament', 'Offline Player Match', 'Offline Practice', 'Single Fight'
	, 'Offline training', 'Menu', 'Pause', 'Multiverse', 'Demos', 'Unknown', 'Portal', 'Guild Portal') 
	then durationhours else 0 end) Others
	from pachinko_prod_da.aggactivityplayerhours a 
	--where platformaccountid in ('E4BF464A4E887401', 'CF47CCAE4E4C9732')
	group by 1,2
) a right join weekly_Players b on a.week_ending_date = b.week_ending_date
where a.week_ending_date >='2017-05-16'
and weeklyhrs>9.5  -- change this for MVP criteria
group by 1,2
order by 1
