select item_type_2, charname, unlock_name, (change_amount :: float)*-1 currency, count(_platform_account_id) players, count(resource_flow_id) resources
from
(
	select resource_flow_id, _platform_account_id,case when item_type_2 = 'Bundle' then bundle_name else unlock_name end unlock_name, change_amount, charname, item_type_2
	from
	(
	select resource_flow_id, change_amount, _platform_account_id
	from seven11_prod.seven11_resource_flow
	where resource = 'Exp_PremiumCurrency'
	and change_amount <0
	and date(wbanalyticssourcedate) >= '2019-09-30'
	group by 1,2,3
	) a
	left join
	(
	select resource_flow_id, unlock_name, bundle_name, charname,Item_Type, case when (count(unlock_name) over (partition by resource_flow_id)) > 1 then 'Bundle' else Item_Type end Item_Type_2,
	count(unlock_name) over (partition by resource_flow_id) unlocks
	from 
		(
		select a.*,b.item_name Item_Type,charname 
		from seven11_prod.seven11_progression_unlock a
		join sandbox.shop_item_cleaned_names b
		using(unlock_name)
		where unlock_source = 'PREMIUM_SHOP'
		and date(wbanalyticssourcedate) >= '2019-09-30'
		) a
	left join (select item_name,bundle_name from sandbox.bundle_item_list group by 1,2) c
	on lower(a.unlock_name) = lower(c.item_name)
	group by 1,2,3,4,5
	) b
	using(resource_flow_id)
	where b.unlock_name is not null
	group by 1,2,3,4,5,6
)
where item_type_2 = 'Bundle' and unlock_name is not null
group by 1,2,3,4