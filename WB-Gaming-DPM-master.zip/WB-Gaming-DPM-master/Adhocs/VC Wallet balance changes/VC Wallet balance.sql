-------VC Wallet balances ---Total Players
with players as(
select player_id
from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES
where premiumcurrency >= 50000
group by 1)

Select play_date, count(player_id) players, sum(premiumcurrency) VC_balance,sum(premiumcurrency)::float/count(player_id) Avg_VC_balance
from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES
where player_id not in (select * from players)
and play_date >='2019-04-22'
group by 1
order by 1  ;

-------VC Wallet balances ---Daily Active Players

With players as (
select player_id
from SEVEN11_PROD_DA.DAILY_PLAYER_BALANCES
where premiumcurrency >= 50000
group by 1
) ,
DAU as ( 
select event_dt, player_id
from seven11_prod_da.wba_player_daily 
where event_dt >= '2019-04-22'
group by 1,2)


Select date, count(player_id) players, sum(VC_balance) Total_VC_balance,sum(VC_balance)::float/count(player_id) Avg_VC_balance
from(
select date,player_id, sum(VC) over (partition by player_id order by date asc rows unbounded preceding) VC_balance
from
(Select a.event_dt date,player_id,COALESCE(VC,0) VC
from DAU a
left join (
select date(_event_time_utc) date, _platform_account_id, sum(change_amount) VC
from seven11_prod.seven11_resource_flow 
where resource = 'Exp_PremiumCurrency' and _platform_account_id not in (select * from players) 
and date(_event_time_utc) >='2019-04-22'
group by 1,2) b
on a.event_dt =b.date
and a.player_id = b._platform_account_id)
)
group by 1
order by 1
