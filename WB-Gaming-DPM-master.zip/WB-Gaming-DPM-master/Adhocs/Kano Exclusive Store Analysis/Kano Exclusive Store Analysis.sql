-----DAU
select count(distinct player_id)
from seven11_prod_da.wba_player_daily 
where (event_dt between '2019-11-27' and '2019-11-28') 
or (event_dt between '2020-01-28' and '2020-02-04') ;

---Views

select count(distinct _platform_account_id)
from seven11_prod.seven11_ui_decision
where source_index in ('cangaceiro-kano-bundle-billboard')
and ((date(_event_time_utc) between '2019-11-27' and '2019-11-28')
or (date(_event_time_utc) between '2020-01-28' and '2020-02-04')) 
;

---decision
select decision,count(distinct _platform_account_id)
from seven11_prod.seven11_ui_decision
where source_index in ('cangaceiro-kano-bundle-billboard')
and ((date(_event_time_utc) between '2019-11-27' and '2019-11-28')
or (date(_event_time_utc) between '2020-01-28' and '2020-02-04')) 
group by 1;

-----Billboard viewers conv to purchasers

With bbviewer as(
select _platform_account_id
from seven11_prod.seven11_ui_decision
where source_index in ('cangaceiro-kano-bundle-billboard')
and ((date(_event_time_utc) between '2019-11-27' and '2019-11-28') or
(date(_event_time_utc) between '2020-01-28' and '2020-02-04'))
group by 1)


Select count(distinct resource_flow_id) purchasers_conv
from seven11_prod.seven11_resource_flow
where resource = 'Exp_PremiumCurrency' AND source_detail = 'KanoBrazilBundle1'
and change_amount <0 and _platform_account_id in (Select * from bbviewer)
and ((date(wbanalyticssourcedate) between '2019-11-27' and '2019-11-28')
or (date(wbanalyticssourcedate) between '2020-01-28' and '2020-02-04'))
;

---% KP owners
With purchasers1 as
(
Select _platform_account_id 
from seven11_prod.seven11_resource_flow
where resource = 'Exp_PremiumCurrency' AND source_detail = 'KanoBrazilBundle1'
and change_amount <0
and (date(wbanalyticssourcedate) between '2019-11-27' and '2019-11-28' )),

purchasers2 as
(
Select _platform_account_id 
from seven11_prod.seven11_resource_flow
where resource = 'Exp_PremiumCurrency' AND source_detail = 'KanoBrazilBundle1'
and change_amount <0
and date(wbanalyticssourcedate) between '2020-01-28' and '2020-02-04')

Select *
from(
select count(distinct _platform_account_id) 
from  seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and date(_event_time_utc) >= '2019-04-22' 
and _platform_account_id in (select * from purchasers1))
cross join(
select count(distinct _platform_account_id) 
from  seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and date(_event_time_utc) >= '2019-04-22' 
and _platform_account_id in (select * from purchasers2))
cross join (
select count(distinct _platform_account_id) 
from  seven11_prod.seven11_dlc_entitlement
where entitlement_name in ('kombat_pack','physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
and date(_event_time_utc) >= '2019-04-22' 
and (_platform_account_id in (select * from purchasers1) or 
_platform_account_id in (select * from purchasers2)))

;
