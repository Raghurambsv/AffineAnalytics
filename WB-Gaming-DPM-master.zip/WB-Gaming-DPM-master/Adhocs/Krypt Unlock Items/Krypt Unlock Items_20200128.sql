---Time Distr.
select unlocks, avg(cum_hrs) Time_taken
from
(
	select _platform_account_id, cum_hrs, 
	row_number() over (partition by _platform_account_id order by unlock_rank) unlocks
	from
	(	
		select _platform_account_id, resource_flow_id, cum_hrs, activity_session_time_s, _activity_guid,
		dense_rank() over (partition by _platform_account_id order by _event_time_utc) unlock_rank,
		--lag(cum_hrs,1) over (partition by _platform_account_id order by _event_time_utc) previousunlocktime,  
		--case when previousunlocktime is null then 0 else previousunlocktime end previous_unlocktime,
		--(cum_hrs - previous_unlocktime) unlock_time
		lag(activity_session_time_s,1) over (partition by _activity_guid order by _event_time_utc) previousunlocktime,  
		case when previousunlocktime is null then 0 else previousunlocktime end previous_unlocktime,
		(activity_session_time_s - previous_unlocktime) unlock_time		
		from seven11_prod.seven11_resource_flow a
		join 
		( 
			select player_id, activity_guid, 
			sum(activity_hours) over (partition by player_id order by _event_time_utc rows unbounded preceding) cum_hrs  
			from seven11_prod_da.wba_fact_activity a1
			join seven11_prod.seven11_activity_begin b1
			on a1.player_id = b1._platform_account_id and a1.activity_guid = b1._activity_guid
			where activity_hours is not null and activity_hours>0 and event_dt >='2019-04-22' 
			and a1.activity_name not in ('GM_TOWERS_OF_TIME_LADDER', 'GM_KLASSIC_PORTAL_MODE_LADDER')
			--and player_id in ('3356836169883526912','253activity_guid, 5434563940362','2458764161222739787')
		) b
		on a._platform_account_id = b.player_id and a._activity_guid = b.activity_guid
		where date(_event_time_utc) >= '2019-04-22' AND source = 'KRYPT' and resource not in 
		('Exp_BrutalityHearts', 'Exp_Cetrion', 'Exp_ItemProgression', 'Exp_Koins', 'Exp_Player', 
		'Exp_PremiumCurrency', 'Exp_Skarlet', 'Exp_SoulFragments') 
	)
	where unlock_time>=1
)
group by 1


---Player Distr.
select unlocks, count(_platform_account_id)
from
(
	select _platform_account_id, max(unlocks) unlocks
	from
	(
		select _platform_account_id, cum_hrs, 
		row_number() over (partition by _platform_account_id order by unlock_rank) unlocks
		from
		(	
			select _platform_account_id, resource_flow_id, cum_hrs, activity_session_time_s, _activity_guid,
			dense_rank() over (partition by _platform_account_id order by _event_time_utc) unlock_rank,
			--lag(cum_hrs,1) over (partition by _platform_account_id order by _event_time_utc) previousunlocktime,  
			--case when previousunlocktime is null then 0 else previousunlocktime end previous_unlocktime,
			--(cum_hrs - previous_unlocktime) unlock_time
			lag(activity_session_time_s,1) over (partition by _activity_guid order by _event_time_utc) previousunlocktime,  
			case when previousunlocktime is null then 0 else previousunlocktime end previous_unlocktime,
			(activity_session_time_s - previous_unlocktime) unlock_time		
			from seven11_prod.seven11_resource_flow a
			join 
			( 
				select player_id, activity_guid, 
				sum(activity_hours) over (partition by player_id order by _event_time_utc rows unbounded preceding) cum_hrs  
				from seven11_prod_da.wba_fact_activity a1
				join seven11_prod.seven11_activity_begin b1
				on a1.player_id = b1._platform_account_id and a1.activity_guid = b1._activity_guid
				where activity_hours is not null and activity_hours>0 and event_dt >='2019-04-22' 
				and a1.activity_name not in ('GM_TOWERS_OF_TIME_LADDER', 'GM_KLASSIC_PORTAL_MODE_LADDER')
				--and player_id in ('3356836169883526912','253activity_guid, 5434563940362','2458764161222739787')
			) b
			on a._platform_account_id = b.player_id and a._activity_guid = b.activity_guid
			where date(_event_time_utc) >= '2019-04-22' AND source = 'KRYPT' and resource not in 
			('Exp_BrutalityHearts', 'Exp_Cetrion', 'Exp_ItemProgression', 'Exp_Koins', 'Exp_Player', 
			'Exp_PremiumCurrency', 'Exp_Skarlet', 'Exp_SoulFragments') 
		)
		where unlock_time>=1
	)
	group by 1
)
group by 1



