/*
select *
from 
limit 1000select wbanalyticssourcedate, activity_type, arm_index, arm_name, "character", chest_index, chest_name, gear_strength, gear_ability, gear_defense, gear_equip, gear_health, head_index, head_name, leg_index, leg_name, loadout_index, level_up, shader_index



select 
from pachinko_prod.pachinko_match_matchresult
where platform_account_id in 
							(--'BA63D8BF3D6AC87C'

	select yearmonthday, a.platformaccountid
	from pachinko_prod_da.aggactivityplayerhours a 
	join pachinko_prod_da.dimplayer B
	on a.yearmonthday = b.firstsessiondate and b.current = true
	and a.platformaccountid = b.platformaccountid
	where yearmonthday between '2017-05-15' and '2017-06-14'
	group by 1,2
							)
select *
from  pachinko_prod.pachinko_match_matchresult
where platform_account_id = 'BA63D8BF3D6AC87C'


select *
from pachinko_prod_da.itemtable
where item_index = 6217
limit 100
*/
---- Distinct stats upgraded-----
select distinct_stats, count(distinct platform_account_id)
from
(
	select platform_account_id, install_dt,"character", id, gear, min(wbanalyticssourcedate) fplay_dt, count(distinct match_id) matches, count(fplay_dt) over (partition by platform_account_id) distinct_stats
	from
	(
	select wbanalyticssourcedate, install_dt, a.platform_account_id, match_id, "character", (gear_ability || gear_defense || gear_health || gear_strength) ID, (gear_ability + gear_defense + gear_health + gear_strength) gear
	from pachinko_prod.pachinko_match_matchresult a
	join 
		(
			select yearmonthday install_dt, a.platformaccountid
			from pachinko_prod_da.aggactivityplayerhours a 
			join pachinko_prod_da.dimplayer B
			on a.yearmonthday = b.firstsessiondate and b.current = true
			and a.platformaccountid = b.platformaccountid
			where yearmonthday between '2017-05-14' and ('2017-05-14'+31) 
			group by 1,2
		) b
	on a.platform_account_id = b.platformaccountid
	where  date(wbanalyticssourcedate) between '2017-05-14' and ('2017-05-14'+100) 
	and (gear_ability + gear_defense + gear_health + gear_strength) > 0
	---and platform_account_id = 'BA63D8BF3D6AC87C'
	)
	group by 1,2,3,4,5
)
group by 1
---- Total Players---------
select count(distinct a.platform_account_id)
from pachinko_prod.pachinko_match_matchresult a
	join 
		(
			select yearmonthday install_dt, a.platformaccountid
			from pachinko_prod_da.aggactivityplayerhours a 
			join pachinko_prod_da.dimplayer B
			on a.yearmonthday = b.firstsessiondate and b.current = true
			and a.platformaccountid = b.platformaccountid
			where yearmonthday between '2017-05-14' and ('2017-05-14'+31) 
			group by 1,2
		) b
	on a.platform_account_id = b.platformaccountid
	where  date(wbanalyticssourcedate) between '2017-05-14' and ('2017-05-15'+100) 

----Time Played-------

with time_played as (
select platform_account_id, fplay_dt, row_number () over (partition by platform_account_id order by fplay_dt asc) num
from
	(
		select platform_account_id, install_dt,"character", id, gear, min(wbanalyticssourcedate) fplay_dt, count(distinct match_id) matches, count(fplay_dt) over (partition by platform_account_id) distinct_stats
		from
		(
		select wbanalyticssourcedate, install_dt, a.platform_account_id, match_id, "character", (gear_ability || gear_defense || gear_health || gear_strength) ID, (gear_ability + gear_defense + gear_health + gear_strength) gear
		from pachinko_prod.pachinko_match_matchresult a
		join 
			(
				select yearmonthday install_dt, a.platformaccountid
				from pachinko_prod_da.aggactivityplayerhours a 
				join pachinko_prod_da.dimplayer B
				on a.yearmonthday = b.firstsessiondate and b.current = true
				and a.platformaccountid = b.platformaccountid
				where yearmonthday between '2017-05-14' and ('2017-05-14'+31) 
				group by 1,2
			) b
		on a.platform_account_id = b.platformaccountid
		where  date(wbanalyticssourcedate) between '2017-05-14' and ('2017-05-14'+100) 
		and (gear_ability + gear_defense + gear_health + gear_strength) > 0
		--and platform_account_id = 'BA63D8BF3D6AC87C'
		)
		group by 1,2,3,4,5
   )
  group by 1,2
)

select num, sum(minutes_played) minutes_played, count(platformaccountid) players
from
(
	select a.platformaccountid, num, sum(totaldurationminutes::float) minutes_played
	from
	(
		select starttimestamp, platformaccountid, totaldurationminutes
		from pachinko_prod_da.factactivity a
		where date(starttimestamp) between '2017-05-14' and ('2017-05-14'+100) 
		--and platformaccountid = 'BA63D8BF3D6AC87C'
		group by 1,2,3
	)a 
	join time_played b
	on a.platformaccountid = b.platform_account_id
	and a.starttimestamp <= fplay_dt
	group by 1,2
)
group by 1



