with players as(
select player_id
from
	(
	SELECT player_id, min(event_dt) install
	FROM seven11_prod_da.wba_fact_activity
	where date(event_dt) >= '2019-04-22'  
	group by 1
	)
where install between '2019-04-22' and ('2019-04-22' + 31)
group by 1
),

--finding total player cohorts--
/*
select count(player_id)
from players
*/
--augments as (

--- Number of different augments equipped----
/*
select num, count(distinct _platform_account_id) players
from
(
		select _platform_account_id, gear, min(wbanalyticssourcedate) fdate, count(fdate) over (partition by _platform_account_id) num
		from
		(
			select _platform_account_id, wbanalyticssourcedate, custom_guid, 
			(g1_aug1 || g1_aug2 || g1_aug3 || g2_aug1 || g2_aug2 || g2_aug3 || g3_aug1 || g3_aug2 || g3_aug3) gear
			, sum(case when g1_aug1 = '' then 0 else 1 end) 
			+ sum(case when (g1_aug2) = '' then 0 else 1 end)
			+ sum(case when(g1_aug3) = '' then 0 else 1 end) 
			+ sum(case when (g2_aug1) = '' then 0 else 1 end) 
			+ sum(case when (g2_aug2) = '' then 0 else 1 end) 
			+ sum(case when (g2_aug3) = '' then 0 else 1 end) 
			+ sum(case when (g3_aug1) = '' then 0 else 1 end) 
			+ sum(case when (g3_aug2) = '' then 0 else 1 end) 
			+ sum(case when (g3_aug3) = '' then 0 else 1 end) as augment
			 from seven11_prod.seven11_gameplay_customization  a
			 join players b
			 on a._platform_account_id = b.player_id
			where date(wbanalyticssourcedate) between '2019-04-22' and ('2019-04-22'+100)
			----and _platform_account_id = '2535468036628078'--'2535417779400143'---
			group by 1,2,3,4
		) a
		where augment > 0
		group by 1,2
) a
group by 1
*/


augments as (

		select _platform_account_id, gear, min(wbanalyticssourcedate) fdate, row_number () over (partition by _platform_account_id order by fdate asc) num
		from
		(
			select _platform_account_id, wbanalyticssourcedate, custom_guid, 
			(g1_aug1 || g1_aug2 || g1_aug3 || g2_aug1 || g2_aug2 || g2_aug3 || g3_aug1 || g3_aug2 || g3_aug3) gear
			, sum(case when g1_aug1 = '' then 0 else 1 end) 
			+ sum(case when (g1_aug2) = '' then 0 else 1 end)
			+ sum(case when(g1_aug3) = '' then 0 else 1 end) 
			+ sum(case when (g2_aug1) = '' then 0 else 1 end) 
			+ sum(case when (g2_aug2) = '' then 0 else 1 end) 
			+ sum(case when (g2_aug3) = '' then 0 else 1 end) 
			+ sum(case when (g3_aug1) = '' then 0 else 1 end) 
			+ sum(case when (g3_aug2) = '' then 0 else 1 end) 
			+ sum(case when (g3_aug3) = '' then 0 else 1 end) as augment
			 from seven11_prod.seven11_gameplay_customization  a
			 join players b
			 on a._platform_account_id = b.player_id
			where date(wbanalyticssourcedate) between '2019-04-22' and ('2019-04-22'+100)
			--and _platform_account_id = '2535468036628078'--'2535417779400143'---
			group by 1,2,3,4
		) a
		where augment > 0
		group by 1,2
)


select num, sum(timeplayed) total_hours, count(player_id) players
from
(
	select player_id, num, sum(total_hours::float) timeplayed
	from
	(
		select player_id, min_event_ts, total_hours
		from seven11_prod_da.wba_player_daily
		where event_dt between '2019-04-22' and ('2019-04-22'+100)
		group by 1,2,3
	) a
	join augments b
	on b._platform_account_id = a.player_id
	and b.fdate >= a.min_event_ts
	group by 1,2
)
group by 1



