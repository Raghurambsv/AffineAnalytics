----Game mode distribution --Top5% and bottom 5% Players --MK11
with players as (
select player_id, 
	  case when cumsumplayers >= 0.95 then 'Top 5%'
	when cumsumplayers <= 0.05 then 'Bottom 5%' else NULL end as Percentile 
from
(
select player_id, hrsplayed, sum (cum_players) over (order by hrsplayed asc rows unbounded preceding) cumsumplayers
	from
	(
		select player_id, sum(total_hours) hrsplayed, sum(hrsplayed) over () totaltime,  sum(total_hours::float) / sum(hrsplayed) over () perc, 1::float / count(player_id) over ()  cum_players
		from seven11_prod_da.wba_player_daily
		where date(event_dt) BETWEEN '2019-04-22' and  '2020-04-02'
		group by 1
	)
)
group by 1,2
having Percentile is not NULL
)

select case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode,Percentile ,sum(activity_hours) Total_Hours
from seven11_prod_da.wba_fact_activity
join players b
using(player_id)
where date(event_dt) BETWEEN '2019-04-22' and  '2020-04-02' 
and activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1,2
order by 2,1;

----Game mode distribution --Overall Players --MK11

select case when activity_name in ('GM_KOLLECTION','GM_KOMBAT_KARD','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_MATCH_REPLAY') then 'Browsing'
		when activity_name in ('GM_CAP_CUSTOMIZATION') then 'Customization'
		when activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER') then 'Klassic Tower'
		when activity_name in ('GM_KRYPT') then 'Krypt'
		when activity_name in ('GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_LOCAL_VERSUS_OFF') then 'Offline Mode'
	 	when activity_name in ('GM_PRIVATE_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH',
		'GM_PRIVATE_MATCH_ON_PRACTICE','GM_RANKED_ON_1V1','GM_PLAYER_MATCH_ON_1V1','GM_PLAYER_MATCH_ON_HOT_SEAT',
		'GM_PLAYER_MATCH_ON_KOTH','GM_TOURNAMENT_ONLINE_1V1') then 'Online MP'
		when activity_name in ('GM_AI_FIGHTER','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_ONLINE_HUB') then 'Others'
	 	when activity_name in ('GM_STORE') then 'Store'
	 	when activity_name in ('GM_STORY_OFF') then 'Story Mode'
		when activity_name in ('GM_GROUP_BATTLES','GM_TOWERS_OF_TIME_LADDER') then 'Towers of Time'
		when activity_name in ('GM_FATALITY_TUTORIAL','GM_PRACTICE','GM_TUTORIAL_OFFLINE','GM_PLAYER_MATCH_ON_PRACTICE') then 'Tutorial'	
	 	else activity_name END AS Game_mode ,sum(activity_hours) Total_Hours
from seven11_prod_da.wba_fact_activity
where date(event_dt) BETWEEN '2019-04-22' and  '2020-04-02' 
and activity_name not in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE','GM_LADDER_OFF')
group by 1
order by 1;