------OVERALL------
----Overall Players distribution based on time played
select hrs,count(player_id) Players,Sum(Players)over(order by hrs asc rows unbounded preceding) Cum_players
from(
	select player_id,Sum(total_hours) LTD_hrs, ceiling(Sum(total_hours)) hrs
	from seven11_prod_da.wba_player_daily
	where date(event_dt) >= '2019-04-22' and date(event_dt) <= '2020-04-02' 
	group by 1
) 
where hrs>0
group by 1;

---Avg Hrs Played
select AVG(LTD_hrs) Avg_hrs, Median(LTD_hrs) Median_hrs
from(
	select player_id,Sum(total_hours) LTD_hrs	
	from seven11_prod_da.wba_player_daily
	where date(event_dt) >= '2019-04-22' and date(event_dt) <= '2020-04-02' 
	group by 1
) 
where LTD_hrs>0
;
----JOIN DATE COHORT
----join date distribution 
Select join_date,count(player_id) players
from(
Select player_id, case when date(install_dt) >= '2019-04-22' then date(install_dt) 
						else min_date end as join_date
from(
select player_id,install_dt,min(date(event_dt)) min_date
	from seven11_prod_da.wba_player_daily
	where date(event_dt) >= '2019-04-22' and date(event_dt) <= '2020-04-02'
	group by 1,2)
group by 1,2)
group by 1 ;

----Join date Cohort Players distribution based on time played 
with join_dates as(
Select player_id, case when date(install_dt) >= '2019-04-22' then date(install_dt) else min_date end as join_date,
			case when join_date <= '2019-05-06' then '1' when join_date <= '2019-08-19' then '2' else '3' end as Cohort					
from(
select player_id,install_dt,min(date(event_dt)) min_date
	from seven11_prod_da.wba_player_daily
	where date(event_dt) >= '2019-04-22' and date(event_dt) <= '2020-04-02'
	group by 1,2)
group by 1,2,3)

select Cohort,hrs,count(player_id) Players,Sum(Players)over(partition by Cohort order by hrs asc rows unbounded preceding) Cum_players
from(
	select player_id,Cohort,Sum(total_hours) LTD_hrs, ceiling(Sum(total_hours)) hrs
	from seven11_prod_da.wba_player_daily
	join join_dates
	using(player_id)
	where date(event_dt) >= '2019-04-22' and date(event_dt) <= '2020-04-02'
	group by 1,2
) 
where hrs>0
group by 1,2;

---Join date Cohorts Avg Hrs Played
with join_dates as(
Select player_id, case when date(install_dt) >= '2019-04-22' then date(install_dt) else min_date end as join_date,
			case when join_date <= '2019-05-06' then '1' when join_date <= '2019-08-19' then '2' else '3' end as Cohort					
from(
select player_id,install_dt,min(date(event_dt)) min_date
	from seven11_prod_da.wba_player_daily
	where date(event_dt) >= '2019-04-22' and date(event_dt) <= '2020-04-02'
	group by 1,2)
group by 1,2,3)

select Cohort,AVG(LTD_hrs) Avg_hrs, Median(LTD_hrs) Median_hrs
from(
	select player_id,Cohort,Sum(total_hours) LTD_hrs	
	from seven11_prod_da.wba_player_daily
	join join_dates
	using(player_id)
	where date(event_dt) >= '2019-04-22' and date(event_dt) <= '2020-04-02'
	group by 1,2
) 
where LTD_hrs>0
group by 1
;
---PRICE COHORT
----Price Cohort Players distribution based on time played 

With premium_owners as
(select _platform_account_id Premium_id
 from  seven11_prod.seven11_dlc_entitlement
 where entitlement_name in ('physical_premium_edition','digital_preorder_premium_edition','digital_premium_edition','kollectors_edition_skin')
 and date(_event_time_utc) <= '2020-04-02' 
 group by 1),

join_dates as(
Select player_id,Premium_id, case when date(install_dt) >= '2019-04-22' then date(install_dt) else min_date end as join_date,
			case when join_date <= '2019-05-06' then '1' when join_date <= '2019-08-19' then '2' else '3' end as Cohort,
			case when Premium_id is NULL then 0 else 1 end as Premium_edition
from(
select player_id,install_dt,min(date(event_dt)) min_date
	from seven11_prod_da.wba_player_daily
	where date(event_dt) >= '2019-04-22' and date(event_dt) <= '2020-04-02'
	group by 1,2)
left join premium_owners
on player_id= Premium_id
group by 1,2,3)

select Cohort,join_date,Premium_edition,hrs,count(player_id) Players,
Sum(Players)over(partition by Cohort,join_date  order by hrs asc rows unbounded preceding) Cum_players
from(
	select player_id,Cohort,join_date,Premium_edition,Sum(total_hours) LTD_hrs, ceiling(Sum(total_hours)) hrs
	from seven11_prod_da.wba_player_daily
	join join_dates
	using(player_id)
	where date(event_dt) >= '2019-04-22' and date(event_dt) <= '2020-04-02'
	group by 1,2,3,4
) 
where hrs>0
group by 1,2,3,4
order by 1,2,3,4;
