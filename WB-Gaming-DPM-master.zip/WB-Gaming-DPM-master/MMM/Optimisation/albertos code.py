#!/usr/bin/env python
# coding: utf-8

# In[ ]:


betas_df = pd.read_csv(directory+"/MK11 MMM/CSV outputs/betas_df.csv")
betas = list(betas_df["beta"])


def objective(x, sign = -1):
    return sign * (np.exp(betas[0])*(x[0]**betas[1])*(x[1]**betas[2])*(x[2]**betas[3])*(x[3]**betas[4])*(x[4]**betas[5])*(x[5]**betas[7])*(x[6]**betas[9]))# + 4.526041e-02*np.log(x[6]))


n = 7
x0 = np.zeros(n) 
x0[0] = np.sum(log_model_mk11_sales["fb_spend"])/1000000
x0[1] = np.sum(log_model_mk11_sales["sem_spend"])/1000000
x0[2] = np.sum(log_model_mk11_sales["video_spend"])/1000000
x0[3] = np.sum(log_model_mk11_sales["dv_display_spend"])/1000000
x0[4] = np.sum(log_model_mk11_sales["ispot_spend"])/1000000
#x0[5] = np.sum(log_model_mk11_sales["placement_spend"])/1000000
x0[5] = np.sum(log_model_mk11_sales["digital_media_spend"])/1000000 
x0[6] = np.sum(log_model_mk11_sales["ooh_spend"])/1000000 



outputs = []

for i in np.arange(0,60,5):
    
    def constraint1(x, sign = -1):
        return sign * (x[0] + x[1] + x[2] + x[3] + x[4] + x[5] + x[6] - (17.95) )
    
    def constraint2(x, sign = -1):
        """
        Facebook needs to be at most 17% of he budget
        """
        return sign * (x[0] - .17*x[0] - .17*x[1] - .17*x[2] - .17*x[3] - .17*x[4] - .17*x[5] - .17*x[6]) 
    
    def constraint3(x, sign = 1):
        """
        Facebook needs to be at least 8% of he budget
        """
        return sign * (x[0] - .08*x[0] - .08*x[1] - .08*x[2] - .08*x[3] - .08*x[4] - .08*x[5] - .08*x[6]) 
                       
    def constraint4(x, sign = -1):
        """
        Search can be at most 5% of the budget
        """
        return sign * (x[1] - .05*x[0] - .05*x[1] - .05*x[2] - .05*x[3] - .05*x[4] - .05*x[5] - .05*x[6])
    
    def constraint5(x, sign = 1):
        """
        Search can be at least .6% of the budget
        """
        return sign * (x[1] - .006*x[0] - .006*x[1] - .006*x[2] - .006*x[3] - .006*x[4] - .006*x[5] - .006*x[6])

    def constraint6(x, sign = -1):
        """
        Video can be at most 14% of the budget
        """
        return sign * (x[2] - .16*x[0] - .16*x[1] - .16*x[2] - .16*x[3] - .16*x[4] - .16*x[5] - .16*x[6])
    
    def constraint7(x, sign = 1):
        """
        Video can be at least 5% of the budget
        """
        return sign * (x[2] - .05*x[0] - .05*x[1] - .05*x[2] - .05*x[3] - .05*x[4] - .05*x[5] - .05*x[6])

    def constraint8(x, sign = -1):
        """
        Displat can be at most 6% of budget
        """
        return sign * (x[3] - .06*x[0] - .06*x[1] - .06*x[2] - .06*x[3] - .06*x[4] - .06*x[5] - .06*x[6])
    
    def constraint9(x, sign = 1):
        """
        Displat can be at least 1% of budget
        """
        return sign * (x[3] - .01*x[0] - .01*x[1] - .01*x[2] - .01*x[3] - .01*x[4] - .01*x[5] - .01*x[5] - .01*x[6])

    def constraint10(x, sign = -1):
        """
        TV can be at most 64.3% of the budget
        """
        return sign * (x[4] - .643*x[0] - .643*x[1] - .643*x[2] - .643*x[3] - .643*x[4] - .643*x[5] - .643*x[6])
    
    def constraint11(x, sign = 1):
        """
        TV can be at least 35% of the budget
        """
        return sign * (x[4] - .46*x[0] - .46*x[1] - .46*x[2] - .46*x[3] - .46*x[4] - .46*x[5] - .46*x[6])
    
    def constraint12(x, sign = -1):
        """
        OOH can be at most 9.25% of the budget
        """
        return sign * (x[6] - .09*x[0] - .09*x[1] - .09*x[2] - .09*x[3] - .09*x[4] - .09*x[5] - .09*x[6])

    def constraint13(x, sign = 1):
        """
        OOH can be at least 3.37% of the budget
        """
        return sign * (x[6] - .04*x[0] - .04*x[1] - .04*x[2] - .04*x[3] - .04*x[4] - .04*x[5] - .04*x[6])  
    #optomize
    b = (0, None)
    bnds = (b,b,b,b,b,b,b)
    con1 = {'type': 'eq', 'fun': constraint1}
    con2 = {'type': 'ineq', 'fun': constraint2}
    con3 = {'type': 'ineq', 'fun': constraint3}
    con4 = {'type': 'ineq', 'fun': constraint4}
    con5 = {'type': 'ineq', 'fun': constraint5}
    con6 = {'type': 'ineq', 'fun': constraint6}
    con7 = {'type': 'ineq', 'fun': constraint7}
    con8 = {'type': 'ineq', 'fun': constraint8}
    con9 = {'type': 'ineq', 'fun': constraint9}
    con10 = {'type': 'ineq', 'fun': constraint10}  
    con11 = {'type': 'ineq', 'fun': constraint11}  
    con12 = {'type': 'ineq', 'fun': constraint12}  
    con13 = {'type': 'ineq', 'fun': constraint13}  
     
    cons = [con1, con2, con3, con4, con5, con6, con7, con8, con9, con10, con11, con12, con13]

    solution = minimize(objective, x0, method = 'SLSQP', bounds = bnds, constraints = cons)#, options = {"maxiter":100 , "disp": True})

