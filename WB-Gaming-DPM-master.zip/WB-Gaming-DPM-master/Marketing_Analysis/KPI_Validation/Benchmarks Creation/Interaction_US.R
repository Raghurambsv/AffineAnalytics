#To see the post based on which this was done - 
#https://cran.r-project.org/web/packages/interactions/vignettes/interactions.html#simple_slopes_analysis_and_johnson-neyman_intervals

#Basic idea: See if the slope b/w the interaction variables is changing
#Test used: Simple slopes test

#Dataset level: At a weekly level for each title. 
#Create a linear regression model, with the dependent variable as US Revenue
#The independent variables are the outputs from the KPI Sales Prediction model

#Interaction was done b/w Weeks from Launch & one variable at a time
#For example: lm(US_Revenue ~ Weeks_from_launch + First_Choice + Weeks_from_launch*First_Choice)

#Installing packages as necessary.
my_packages <- c("dplyr", "data.table", "lubridate", "randomForest","mlbench",
                 "caret", "missForest", "MLmetrics", "vctrs", "readxl","sjPlot",
                 "sjmisc", "ggplot2", "mosaic", "jtools", "interactions", "sandwich",
                 "rcompanion", "e1071", "car", "MASS", "tidyr", "broom")
install.packages(my_packages, repos = "http://cran.rstudio.com")

#Add the package readxl
install.packages("readxl")
library(readxl)

#Loading the dataset.
read_excel_allsheets <- function(filename, tibble = FALSE) {
  # I prefer straight data.frames
  # but if you like tidyverse tibbles (the default with read_excel)
  # then just pass tibble = TRUE
  sheets <- readxl::excel_sheets(filename)
  x <- lapply(sheets, function(X) readxl::read_excel(filename, sheet = X))
  if(!tibble) x <- lapply(x, as.data.frame)
  names(x) <- sheets
  x
}

#Reading the dataset.
mySheets <- read_excel_allsheets("C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_New_Files/Final_AD.xlsx")
Raw_data_US <- mySheets$US_Fin
colnames(Raw_data_US)

#Significant variables come from the Python's list of important variables
sig_variables <- c("Title", "Weeks from Launch", "Nielsen - Metrics First Choice",
                   "Nielsen - Metrics Purchase interest - Def","Nielsen - Metrics Unaided Awareness",
                   "Google_US", "Tubular - Metrics Views", "Netbase - Metrics Impressions", "Netbase - Metrics Mentions")

#Subsetting for the above columns only.
US_Raw <- Raw_data_US[, (colnames(Raw_data_US) %in% sig_variables), drop = FALSE]

#Check the colnames.
colnames(US_Raw)

#Change the column names for readability
colnames(US_Raw) <- c("Title", "Weeks_from_Launch", "Nielsen_First_Choice",
                      "Nielsen_Def_Pur", "Nielsen_UA", "Google",
                      "Views", "Impressions", "Mentions")

#Filtering the Pre-launch file
prelaunch_filtered <- US_Raw %>% filter(Weeks_from_Launch >= -20 & Weeks_from_Launch <= 20)

#Use the summarized revenue at a title level.
library(dplyr)
sales_info <- mySheets$Sales_info
us_revenue <- sales_info %>% subset(select = c(Title,US_Revenue))

#Merging US_Raw with US_Revenue
us_final <- merge(US_Raw, us_revenue, by = "Title")
us_new <- na.omit(us_final)

#Checking if we have sufficient entries for each week.
weeks_check <- prelaunch_filtered %>% group_by(Weeks_from_Launch) %>% tally()

#From here: Checking for Interaction between individual variables
#I don't think a full model is appropriate. Let's try a model with just two variables at a time. 
#Model 1: Unaided awareness
install.packages("jtools")
install.packages("broom")
install.packages("tidyselect")

library(jtools)
library(interactions)
library(broom)
library(tidyselect)
View(us_new)

#For most accurate estimates, apply the same transformation for the variable that
#was in the KPI model

#First model for First Choice & Weeks from Launch
car::vif(model_1)

model_1 <- lm(US_Revenue ~ Weeks_from_Launch + Nielsen_First_Choice +
                Nielsen_Def_Pur + Nielsen_UA + Google + Views +
                + Impressions + Mentions + Nielsen_First_Choice:Weeks_from_Launch, data = us_new)
summ(model_1)
ss_1 <- sim_slopes(model_1, pred = Nielsen_First_Choice, modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_1
plot(ss_1)
johnson_neyman(model_1, pred = Nielsen_First_Choice, modx = Weeks_from_Launch, alpha = .05,
               title = "First Choice is significant from -20 to +6 weeks")

#Second model for Def. Pur & Weeks from Launch
model_2 <- lm(US_Revenue ~ Weeks_from_Launch + Nielsen_First_Choice +
                Nielsen_Def_Pur + Nielsen_UA + Google +
                Views + Mentions + Impressions + Nielsen_Def_Pur:Weeks_from_Launch, data = us_new)
summ(model_2)
ss_2 <- sim_slopes(model_2, pred = Nielsen_Def_Pur , modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_2
plot(ss_2)
johnson_neyman(model_2, pred = Nielsen_Def_Pur, modx = Weeks_from_Launch, alpha = .05,
               title = "Def. Interest to Purchase is significant throughout")

#Third model for UA & Weeks from Launch
model_3 <- lm(US_Revenue ~ Weeks_from_Launch + Nielsen_First_Choice +
                Nielsen_Def_Pur + Nielsen_UA + Google +
                Mentions + Views + Impressions + Nielsen_UA:Weeks_from_Launch, data = us_new)
summ(model_3)
ss_3 <- sim_slopes(model_3, pred = Nielsen_UA , modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_3
plot(ss_3)
johnson_neyman(model_3, pred = Nielsen_UA, modx = Weeks_from_Launch, alpha = .05,
               title = "Unaided Awareness is not sig. +7 to +20 weeks")

#Fourth model for Google & Weeks from Launch
model_4 <- lm(US_Revenue ~ Weeks_from_Launch + Nielsen_First_Choice +
                Nielsen_Def_Pur + Nielsen_UA + Google +
                + Mentions + Views + Impressions + Google:Weeks_from_Launch, data = us_new)
summ(model_4)
ss_4 <- sim_slopes(model_4, pred = Google , modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_4
plot(ss_4)
johnson_neyman(model_4, pred = Google, modx = Weeks_from_Launch, alpha = .05,
               title = "Google Index is significant from -17 weeks")

#Fifth model for Mentions & Weeks from Launch
#This would be a good example for trying out transformations.
model_5 <- lm(US_Revenue ~ Weeks_from_Launch + Nielsen_First_Choice +
                Nielsen_Def_Pur + Nielsen_UA + Google +
                Mentions + Views + Impressions + Mentions:Weeks_from_Launch, data = us_new)
summ(model_5)
ss_5 <- sim_slopes(model_5, pred = Mentions , modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_5
plot(ss_5)
johnson_neyman(model_5, pred = Mentions, modx = Weeks_from_Launch, alpha = .05,
               title = "Mentions is significant post-launch")

#Sixth model for Views & Weeks from Launch
model_6 <- lm(US_Revenue ~ Weeks_from_Launch + Nielsen_First_Choice +
                Nielsen_Def_Pur + Nielsen_UA + Google +
                Mentions + Views + Views:Weeks_from_Launch, data = us_new)
summ(model_6)
ss_6 <- sim_slopes(model_6, pred = Views, modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_6
plot(ss_6)
johnson_neyman(model_6, pred = Views, modx = Weeks_from_Launch, alpha = .05,
               title = "Views are only significant in a narrow range from -10 to +20 weeks")

#Seventh model for Impressions & Weeks from Launch
model_7 <- lm(US_Revenue ~ Weeks_from_Launch + Nielsen_First_Choice +
                Nielsen_Def_Pur + Nielsen_UA + Google + Views +
                + Impressions + Mentions + Impressions:Weeks_from_Launch, data = us_new)
summ(model_7)
ss_7 <- sim_slopes(model_7, pred = Impressions , modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_7
plot(ss_7)
johnson_neyman(model_7, pred = Impressions, modx = Weeks_from_Launch, alpha = .05,
               title = "Impressions is significant from -3 to +8 weeks")
