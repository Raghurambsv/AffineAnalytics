#To see the post based on which this was done - 
#https://cran.r-project.org/web/packages/interactions/vignettes/interactions.html#simple_slopes_analysis_and_johnson-neyman_intervals

#Basic idea: See if the slope b/w the interaction variables is changing
#Test used: Simple slopes test

#Dataset level: At a weekly level for each title. 
#Create a linear regression model, with the dependent variable as US Revenue
#The independent variables are the outputs from the KPI Sales Prediction model

#Interaction was done b/w Weeks from Launch & one variable at a time
#For example: lm(UK_Revenue ~ Weeks_from_launch + First_Choice + Weeks_from_launch*First_Choice)

#Checking for significant weeks in the new model -- UK

my_packages <- c("dplyr", "data.table", "lubridate", "randomForest","mlbench",
                 "caret", "missForest", "MLmetrics", "vctrs", "readxl","sjPlot",
                 "sjmisc", "ggplot2", "mosaic", "jtools", "interactions", "sandwich",
                 "rcompanion", "e1071", "car", "MASS", "tidyr", "broom")
install.packages(my_packages, repos = "http://cran.rstudio.com")

#Add the package readxl
install.packages("readxl")
library(readxl)

#Loading the dataset.

read_excel_allsheets <- function(filename, tibble = FALSE) {
  # I prefer straight data.frames
  # but if you like tidyverse tibbles (the default with read_excel)
  # then just pass tibble = TRUE
  sheets <- readxl::excel_sheets(filename)
  x <- lapply(sheets, function(X) readxl::read_excel(filename, sheet = X))
  if(!tibble) x <- lapply(x, as.data.frame)
  names(x) <- sheets
  x
}

mySheets <- read_excel_allsheets("C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_New_Files/Final_AD.xlsx")
Raw_data_UK <- mySheets$UK_Fin
Raw_data <- na.omit(Raw_data_UK)
colnames(Raw_data)

#Significant variables come from the Python's list of important variables
sig_variables <- c("Title", "Weeks from Launch", "Google_UK", "Nielsen - Metrics First Choice",
                   "Nielsen - Metrics Purchase interest - Def","Nielsen - Metrics Unaided Awareness",
                   "Tubular - Metrics Views", "Netbase - Metrics Mentions", "Netbase - Metrics Impressions")

UK_Raw <- Raw_data[, (colnames(Raw_data) %in% sig_variables), drop = FALSE]

colnames(UK_Raw)
colnames(UK_Raw) <- c("Title", "Weeks_from_Launch", "Nielsen_Def_Pur",
                      "Nielsen_FC", "Nielsen_UA","Google",
                      "Views", "Impressions", "Mentions")

#Filtering the Pre-launch file

prelaunch_filtered <- UK_Raw %>% filter(Weeks_from_Launch >= -20 & Weeks_from_Launch <= 20)

#Use the summarized revenue at a title level.
library(dplyr)
sales_info <- mySheets$Sales_info
uk_revenue <- sales_info %>% subset(select = c(Title,UK_Revenue))

uk_rev_fin <- uk_revenue %>% subset(UK_Revenue != '-')

#Merging US_Raw with US_Revenue
uk_final <- merge(UK_Raw, uk_rev_fin, by = "Title")

#Checking if we have sufficient entries for each week.
weeks_check <- prelaunch_filtered %>% group_by(Weeks_from_Launch) %>% tally()

#From here: Checking for Interaction between individual variables
#I don't think a full model is appropriate. Let's try a model with just two variables at a time. 
install.packages("jtools")
install.packages("broom")
install.packages("tidyselect")

library(jtools)
library(interactions)
library(broom)
library(tidyselect)

#First model for First Choice & Weeks from Launch

car::vif(model_1)

#Applying transformations to improve the weeks of significane by using the same
#transformation as seen in the KPI model

uk_final$sqrt_FC <- sqrt(uk_final$Nielsen_FC)
uk_final$sqrt_UA <- sqrt(uk_final$Nielsen_UA)
uk_final$Impressions_log <- log(uk_final$Impressions)

model_1 <- lm(UK_Revenue ~ Weeks_from_Launch + sqrt_FC +
                Nielsen_Def_Pur + Nielsen_UA  + Google + Views +
                + Mentions + Impressions_log + sqrt_FC:Weeks_from_Launch, data = uk_final)
summ(model_1)
ss_1 <- sim_slopes(model_1, pred = sqrt_FC , modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_1
plot(ss_1)
johnson_neyman(model_1, pred = sqrt_FC, modx = Weeks_from_Launch, alpha = .05,
               title = "Impressions is significant from -20 to -5 weeks")

#Second model for Def. Pur & Weeks from Launch
model_2 <- lm(UK_Revenue ~ Weeks_from_Launch + sqrt_FC +
                Nielsen_Def_Pur + Nielsen_UA + Google +
                Views + Mentions + Impressions_log + Nielsen_Def_Pur:Weeks_from_Launch, data = uk_final)
summ(model_2)
ss_2 <- sim_slopes(model_2, pred = Nielsen_Def_Pur , modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_2
plot(ss_2)
johnson_neyman(model_2, pred = Nielsen_Def_Pur, modx = Weeks_from_Launch, alpha = .05,
               title = "Def. Interest to Purchase is significant throughout")

#Third model for UA & Weeks from Launch
model_3 <- lm(UK_Revenue ~ Weeks_from_Launch + sqrt_FC +
                Nielsen_Def_Pur + sqrt_UA + Google +
                Mentions + Views + Impressions_log + sqrt_UA:Weeks_from_Launch, data = uk_final)
summ(model_3)
ss_3 <- sim_slopes(model_3, pred = sqrt_UA , modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_3
plot(ss_3)
johnson_neyman(model_3, pred = sqrt_UA, modx = Weeks_from_Launch, alpha = .05,
               title = "Unaided Awareness is only significant between -13 to +20 weeks")

#Fourth model for Google & Weeks from Launch
model_4 <- lm(UK_Revenue ~ Weeks_from_Launch + sqrt_FC +
                Nielsen_Def_Pur + Nielsen_UA + Google +
                + Mentions + Views + Impressions_log + Google:Weeks_from_Launch, data = uk_final)
summ(model_4)
ss_4 <- sim_slopes(model_4, pred = Google , modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_4
plot(ss_4)
johnson_neyman(model_4, pred = Google, modx = Weeks_from_Launch, alpha = .05,
               title = "Google Index is not sig. from -11 to -4 weeks")

#Fifth model for Mentions & Weeks from Launch
model_5 <- lm(UK_Revenue ~ Weeks_from_Launch + sqrt_FC +
                Nielsen_Def_Pur + Nielsen_UA + Youtube + Google +
                Mentions + Views + Impressions_log + Mentions:Weeks_from_Launch, data = uk_final)
summ(model_5)
ss_5 <- sim_slopes(model_5, pred = Mentions , modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_5
plot(ss_5)
johnson_neyman(model_5, pred = Mentions, modx = Weeks_from_Launch, alpha = .05,
               title = "Mentions is significant post-launch")

#Sixth model for Views & Weeks from Launch
model_6 <- lm(UK_Revenue ~ Weeks_from_Launch + sqrt_FC +
                Nielsen_Def_Pur + Nielsen_UA + Google +
                Mentions + Views + Views:Weeks_from_Launch, data = uk_final)
summ(model_6)
ss_6 <- sim_slopes(model_6, pred = Views, modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_6
plot(ss_6)
johnson_neyman(model_6, pred = Views, modx = Weeks_from_Launch, alpha = .05,
               title = "Views are significant from the 16th week of Pre-launch")

#Seventh model for Impressions& Weeks from launch
model_7 <- lm(UK_Revenue ~ Weeks_from_Launch + sqrt_FC +
                Nielsen_Def_Pur + Nielsen_UA  + Google + Views +
                + Mentions + Impressions_log + Impressions_log:Weeks_from_Launch, data = uk_final)
summ(model_7)
ss_7 <- sim_slopes(model_7, pred = Impressions_log , modx = Weeks_from_Launch, johnson_neyman = TRUE,
                   control.fdr = TRUE, cond.int = TRUE, robust = "HC3")
ss_7
plot(ss_7)
johnson_neyman(model_7, pred = Impressions_log, modx = Weeks_from_Launch, alpha = .05,
               title = "Impressions is significant from -30 to +8 weeks")

