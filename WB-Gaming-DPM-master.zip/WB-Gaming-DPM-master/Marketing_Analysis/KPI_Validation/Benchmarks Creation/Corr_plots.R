#Use this dataset to create Correlation plots
#Input dataset used: US Prelaunch aggregated dataset at a title level
#Correlation Plots

install.packages("ggcorrplot")
library(ggcorrplot)

#Adding the packages in the library. Do install them if missing from the system.
library(readxl)    

#Function to read the excel files
read_excel_allsheets <- function(filename, tibble = FALSE) {
  # I prefer straight data.frames
  # but if you like tidyverse tibbles (the default with read_excel)
  # then just pass tibble = TRUE
  sheets <- readxl::excel_sheets(filename)
  x <- lapply(sheets, function(X) readxl::read_excel(filename, sheet = X))
  if(!tibble) x <- lapply(x, as.data.frame)
  names(x) <- sheets
  x
}

#Reading the excel file obtained from US Pre-launch dataset
mySheets <- read_excel_allsheets("C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_New_Files/Datasets/Pre_launch_Corr_dataset_new.xlsx")
AD_Transformed <- mySheets$Sheet1

install.packages("ggplot2")
install.packages("ggcorrplot")

library(ggplot2)
library(ggcorrplot)

remove.packages("ggplot2")
remove.packages("ggcorrplot")
remove.packages("jtools")
remove.packages("interactions")

library(psych)

## Subsetting for Nielsen Metrics only to see correlations within the variables
Nielsen <- AD_Transformed[,c('Nielsen - Metrics First Choice_mean','Nielsen - Metrics Purchase interest - Def_mean',
                             'Nielsen - Metrics Purchase interest - Def not_mean','Nielsen - Metrics Purchase interest - Own/Preorder_mean',
                             'Nielsen - Metrics Purchase interest - Prob_mean','Nielsen - Metrics Unaided Awareness_mean',
                             'US_Revenue')]
colnames(Nielsen)

#Changing the column names for readability
colnames(Nielsen) <- c("First_Choice", "Def.Purchase Interest",
                       "Def. Not Purchase Interest", "Own/Pre-Order","Prob. Purchase",
                       "Unaided_Awareness","Revenue")

#Choose a correlation plot based on aesthetic choice.
corr <- round(cor(Nielsen),2)
ggcorrplot(corr, hc.order = TRUE, type = "lower",
           lab = TRUE, title = "Nielsen Variables", lab_size = 3, tl.cex = 8) 

chart.Correlation(Nielsen, histogram = TRUE, pch = 19)
pairs.panels(Nielsen, scale = TRUE)
GGally::ggpairs(Nielsen)

##Subsetting for Social Media Metrics only to see correlations within the variables

Netbase <- AD_Transformed[, c('Marketing Metrics Net Sentiment_mean', 
                                 'Netbase - Metrics Impressions_mean',
                                 'Netbase - Metrics Mentions_mean',
                                 'Netbase - Metrics Posts_mean',
                                 'Netbase - Metrics Totalreplies_mean',
                                 'Netbase - Metrics Totalreposts_mean',
                                 'Net Sentiment_mean','US_Revenue')]

#Change the column names for readability
colnames(Netbase) <- c("Net Sentiment%","Impressions", "Mentions",
                          "Posts", "Total Replies", "Total Reposts",
                          "Net Sentiment Posts", "Revenue")

#Choose a correlation plot based on aesthetic choice.
corr <- round(cor(Netbase,use="complete.obs"),2)
ggcorrplot(corr, hc.order = TRUE, type = "lower",
           lab = TRUE, title = "Social Media Variables", lab_size = 3, tl.cex = 8) 

chart.Correlation(Netbase, histogram = TRUE, pch = 19)


#Create correlation plots for Nielsen, Netbase & Tubular
colnames(AD_Transformed)
Tubular <- AD_Transformed[, c('Tubular - Metrics Engagements_mean',
                                 'Tubular - Metrics Uploads_mean',
                                 'Tubular - Metrics Views_mean',
                                 'US_Revenue',
                                 'Google_US_mean',
                                 'Metacritic Score', 'User Review Score')]
colnames(Tubular)
colnames(Tubular) <- c("Engagements", "Uploads", "Views", "Revenue", 
                           "Google", "Metacritic", "User Review")

corr <- round(cor(Tubular,use="complete.obs"),2)
ggcorrplot(corr, hc.order = TRUE, type = "lower",
           lab = TRUE, title = "Social Media Variables", lab_size = 3, tl.cex = 8) 

library(PerformanceAnalytics)
chart.Correlation(Tubular, histogram = TRUE, pch = 19)
