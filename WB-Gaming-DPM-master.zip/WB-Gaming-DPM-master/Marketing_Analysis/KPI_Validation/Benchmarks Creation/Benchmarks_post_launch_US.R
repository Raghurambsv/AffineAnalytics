#Objective of this dataset: Create benchmarks at a weekly level for titles falling
#in a revenue group 
#There are a total of 12 output files from this code for the territory: US
#First 6 files are for the entire group, week over week averages of the metric
#For example: the value of First Choice for a group at the 20th week from launch

#The second 6 files are for individual titles in a group. 
#Example: If CoD Modern Warfare, CoD Black Ops are part of Revenue Group 1
#Then we show week over week values of both the titles
#This is done for all the 6 revenue groups.

#Loading necessary packages.
library(dplyr)

#Function to read excel sheets
read_excel_allsheets <- function(filename, tibble = FALSE) {
  #   I prefer straight data.frames
  #   but if you like tidyverse tibbles (the default with read_excel)
  #   then just pass tibble = TRUE
  sheets <- readxl::excel_sheets(filename)
  x <- lapply(sheets, function(X) readxl::read_excel(filename, sheet = X))
  if(!tibble) x <- lapply(x, as.data.frame)
  names(x) <- sheets
  x
}

#Referring the raw data in Excel
mySheets <- read_excel_allsheets("C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_New_Files/Final_AD_WIP.xlsx")
Raw_data <- mySheets$US_Fin

#Filtering the raw data
launch_data <- Raw_data %>% filter(`Weeks from Launch` >= -20 & `Weeks from Launch` <= 40)
colnames(launch_data)

#Keeping the necessary columns
#The necessary columns are the variables which were significant from the earlier
#KPI sales prediction model.
keep_cols <- c("Title", "Weeks from Launch","Nielsen - Metrics First Choice",
               "Nielsen - Metrics Purchase interest - Def",
               "Nielsen - Metrics Unaided Awareness", "Youtube_US", "Google_US",
               "Tubular - Metrics Views", "Netbase - Metrics Mentions",
               "Netbase - Metrics Impressions")

#Subsetting the data w/these columns only
fin_dataset <- launch_data[, (colnames(launch_data) %in% keep_cols), drop = FALSE]
unique(fin_dataset$Title)
colnames(fin_dataset)

#Changing column names for readability
colnames(fin_dataset) <- c("Title", "Weeks_from_Launch","Nielsen_First_Choice",
                           "Nielsen_Def_Interest", "Nielsen_UA", 
                           "Youtube_US", "Google_US","Tubular_Views",
                           "Netbase_Impressions", "Netbase_Mentions")

#Summarizing the metrics - Mean, Max
#This step can be skipped. I included it in case the data is not at the desirable
#level
final_dataset <- fin_dataset %>% group_by(Title, Weeks_from_Launch) %>% 
  group_by(Title, Weeks_from_Launch) %>%
  summarise_if(.predicate = function(x) is.numeric(x),
               .funs = c(mean = "mean", max = "max"), na.rm = TRUE)

#Creating the revenue dataset
sales_info <- mySheets$Sales_info

#Only keep the title & post-launch 3Months Revenue
us_revenue <- sales_info %>% subset(select = c(Title, US_Revenue))

#Merging revenue info. with raw data
test_dataset <- merge(final_dataset, us_revenue, by = "Title")

#Summarize the dataset at a title level
test_val <- test_dataset %>% group_by(Title) %>%
  summarise_if(.predicate = function(x) is.numeric(x),
               .funs = (mean = "mean"), na.rm = TRUE) %>% arrange(desc(US_Revenue))

#Arranging test value dataset. 
test_val <- test_val %>% arrange(desc(US_Revenue))
rev_sorted <- us_revenue %>% arrange(desc(US_Revenue))
View(rev_sorted)
test_weeks_info <- test_dataset

#Top 56 titles
#Look at the exact number from the Final_AD_WIP file.
#If this is too manual, change the revenue groups by creating logical statements
final_group_1_ex <- test_val %>% slice(1:7) %>% mutate(Group_1 = "True") %>% select(Title, Group_1)
final_group_2_ex <- test_val %>% slice(8:13) %>% mutate(Group_2 = "True") %>% select(Title, Group_2)
final_group_3_ex <- test_val %>% slice(14:23) %>% mutate(Group_3 = "True") %>% select(Title, Group_3)
final_group_4_ex <- test_val %>% slice(24:33) %>% mutate(Group_4 = "True") %>% select(Title, Group_4)
final_group_5_ex <- test_val %>% slice(34:45) %>% mutate(Group_5 = "True") %>% select(Title, Group_5)
final_group_6_ex <- test_val %>% slice(46:56) %>% mutate(Group_6 = "True") %>% select(Title, Group_6)

#Merging with the original master dataset so that we can filter out later.
test_weeks_info <- left_join(test_weeks_info, final_group_1_ex, by = "Title")
test_weeks_info <- left_join(test_weeks_info, final_group_2_ex, by = "Title")
test_weeks_info <- left_join(test_weeks_info, final_group_3_ex, by = "Title")
test_weeks_info <- left_join(test_weeks_info, final_group_4_ex, by = "Title")
test_weeks_info <- left_join(test_weeks_info, final_group_5_ex, by = "Title")
test_weeks_info <- left_join(test_weeks_info, final_group_6_ex, by = "Title")

#Data pre-processing
#Removing NAs, NANs, Inf
test_weeks_info[which(is.nan(test_weeks_info))] = NA
test_weeks_info[which(test_weeks_info == Inf)] = NA
test_weeks_info[which(test_weeks_info == -Inf)] = NA

#Exclusive lists.
#First 6 datasets are weekly values for the entire group.
#Filter for a specific column & then subset it for the significant variables only.

Group1_dataset <- test_weeks_info %>%
                  arrange(desc(US_Revenue)) %>% 
                  filter(Group_1 == "True") %>% group_by(Weeks_from_Launch) %>%
                  summarise_if(.predicate = function(x) is.numeric(x),
                  .funs = c(mean = "mean", max = "max"), na.rm = TRUE) %>%
                  select(Weeks_from_Launch,Nielsen_First_Choice_mean_mean,
                         Nielsen_Def_Interest_mean_mean, Nielsen_UA_mean_mean,
                         Youtube_US_mean_mean, Google_US_mean_mean, Tubular_Views_mean_mean,
                         Netbase_Mentions_mean_mean, Netbase_Impressions_mean_mean)

Group2_dataset <- test_weeks_info %>%
                  arrange(desc(US_Revenue)) %>% 
                  filter(Group_2 == "True") %>% group_by(Weeks_from_Launch) %>%
                  summarise_if(.predicate = function(x) is.numeric(x),
                  .funs = c(mean = "mean", max = "max"), na.rm = TRUE) %>%
                  select(Weeks_from_Launch,Nielsen_First_Choice_mean_mean,
                         Nielsen_Def_Interest_mean_mean, Nielsen_UA_mean_mean,
                         Youtube_US_mean_mean, Google_US_mean_mean, Tubular_Views_mean_mean,
                         Netbase_Mentions_mean_mean, Netbase_Impressions_mean_mean)

Group3_dataset <- test_weeks_info %>%
                  arrange(desc(US_Revenue)) %>% 
                  filter(Group_3 == "True") %>% group_by(Weeks_from_Launch) %>%
                  summarise_if(.predicate = function(x) is.numeric(x),
                  .funs = c(mean = "mean", max = "max"), na.rm = TRUE) %>%
                  select(Weeks_from_Launch,Nielsen_First_Choice_mean_mean,
                  Nielsen_Def_Interest_mean_mean, Nielsen_UA_mean_mean,
                  Youtube_US_mean_mean, Google_US_mean_mean, Tubular_Views_mean_mean,
                  Netbase_Mentions_mean_mean, Netbase_Impressions_mean_mean)

Group4_dataset <- test_weeks_info %>%
                  arrange(desc(US_Revenue)) %>% 
                  filter(Group_4 == "True") %>% group_by(Weeks_from_Launch) %>%
                  summarise_if(.predicate = function(x) is.numeric(x),
                  .funs = c(mean = "mean", max = "max"), na.rm = TRUE) %>%
                  select(Weeks_from_Launch,Nielsen_First_Choice_mean_mean,
                  Nielsen_Def_Interest_mean_mean, Nielsen_UA_mean_mean,
                  Youtube_US_mean_mean, Google_US_mean_mean, Tubular_Views_mean_mean,
                  Netbase_Mentions_mean_mean, Netbase_Impressions_mean_mean)

Group5_dataset <- test_weeks_info %>%
                  arrange(desc(US_Revenue)) %>% 
                  filter(Group_5 == "True") %>% group_by(Weeks_from_Launch) %>%
                  summarise_if(.predicate = function(x) is.numeric(x),
                  .funs = c(mean = "mean", max = "max"), na.rm = TRUE) %>%
                  select(Weeks_from_Launch,Nielsen_First_Choice_mean_mean,
                  Nielsen_Def_Interest_mean_mean, Nielsen_UA_mean_mean,
                  Youtube_US_mean_mean, Google_US_mean_mean, Tubular_Views_mean_mean,
                  Netbase_Mentions_mean_mean, Netbase_Impressions_mean_mean)

Group6_dataset <- test_weeks_info %>%
                  arrange(desc(US_Revenue)) %>% 
                  filter(Group_6 == "True") %>% group_by(Weeks_from_Launch) %>%
                  summarise_if(.predicate = function(x) is.numeric(x),
                  .funs = c(mean = "mean", max = "max"), na.rm = TRUE) %>%
                  select(Weeks_from_Launch,Nielsen_First_Choice_mean_mean,
                  Nielsen_Def_Interest_mean_mean, Nielsen_UA_mean_mean,
                  Youtube_US_mean_mean, Google_US_mean_mean, Tubular_Views_mean_mean,
                  Netbase_Mentions_mean_mean, Netbase_Impressions_mean_mean)

#Exporting
library(openxlsx)
write.xlsx(Group1_dataset, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_Benchmarks/New Files/Group1_post_US_new_fin.xlsx')
write.xlsx(Group2_dataset, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_Benchmarks/New Files/Group2_post_US_new_fin.xlsx')
write.xlsx(Group3_dataset, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_Benchmarks/New Files/Group3_post_US_new_fin.xlsx')
write.xlsx(Group4_dataset, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_Benchmarks/New Files/Group4_post_US_new_fin.xlsx')
write.xlsx(Group5_dataset, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_Benchmarks/New Files/Group5_post_US_new_fin.xlsx')
write.xlsx(Group6_dataset, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_Benchmarks/New Files/Group6_post_US_new_fin.xlsx')

#This second set of 6 datasets are weekly values for the entire group.
#Filter for a specific column & then subset it for the significant variables only.
#Just getting info. for all the titles in the group at a weekly level.
Group1_full <- test_weeks_info %>%
               arrange(desc(US_Revenue)) %>% 
               filter(Group_1 == "True") %>% group_by(Title, Weeks_from_Launch) %>%
               summarise_if(.predicate = function(x) is.numeric(x),
               .funs = c(mean = "mean", max = "max"), na.rm = TRUE) %>%
               select(Title, Weeks_from_Launch,Nielsen_UA_mean_mean,
                      Nielsen_First_Choice_mean_mean,Nielsen_Def_Interest_mean_mean,
                      Netbase_Mentions_mean_mean,Tubular_Views_mean_mean,
                      Youtube_US_mean_mean, Google_US_mean_mean,
                      Netbase_Impressions_mean_mean)

Group2_full <- test_weeks_info %>%
               arrange(desc(US_Revenue)) %>% 
               filter(Group_2 == "True") %>% group_by(Title, Weeks_from_Launch) %>%
               summarise_if(.predicate = function(x) is.numeric(x),
               .funs = c(mean = "mean", max = "max"), na.rm = TRUE) %>%
               select(Title, Weeks_from_Launch,Nielsen_UA_mean_mean,
               Nielsen_First_Choice_mean_mean,Nielsen_Def_Interest_mean_mean,
               Netbase_Mentions_mean_mean,Tubular_Views_mean_mean,
               Youtube_US_mean_mean, Google_US_mean_mean, Netbase_Impressions_mean_mean)

Group3_full <- test_weeks_info %>%
               arrange(desc(US_Revenue)) %>% 
               filter(Group_3 == "True") %>% group_by(Title, Weeks_from_Launch) %>%
               summarise_if(.predicate = function(x) is.numeric(x),
               .funs = c(mean = "mean", max = "max"), na.rm = TRUE) %>%
               select(Title, Weeks_from_Launch,Nielsen_UA_mean_mean,
               Nielsen_First_Choice_mean_mean,Nielsen_Def_Interest_mean_mean,
               Netbase_Mentions_mean_mean,Tubular_Views_mean_mean,
               Youtube_US_mean_mean, Google_US_mean_mean, Netbase_Impressions_mean_mean)

Group4_full <- test_weeks_info %>%
               arrange(desc(US_Revenue)) %>% 
               filter(Group_4 == "True") %>% group_by(Title, Weeks_from_Launch) %>%
               summarise_if(.predicate = function(x) is.numeric(x),
               .funs = c(mean = "mean", max = "max"), na.rm = TRUE) %>%
               select(Title, Weeks_from_Launch,Nielsen_UA_mean_mean,
               Nielsen_First_Choice_mean_mean,Nielsen_Def_Interest_mean_mean,
               Netbase_Mentions_mean_mean,Tubular_Views_mean_mean,
               Youtube_US_mean_mean, Google_US_mean_mean, Netbase_Impressions_mean_mean)

Group5_full <- test_weeks_info %>%
               arrange(desc(US_Revenue)) %>% 
               filter(Group_5 == "True") %>% group_by(Title, Weeks_from_Launch) %>%
               summarise_if(.predicate = function(x) is.numeric(x),
               .funs = c(mean = "mean", max = "max"), na.rm = TRUE) %>%
               select(Title, Weeks_from_Launch,Nielsen_UA_mean_mean,
               Nielsen_First_Choice_mean_mean,Nielsen_Def_Interest_mean_mean,
               Netbase_Mentions_mean_mean,Tubular_Views_mean_mean,
               Youtube_US_mean_mean, Google_US_mean_mean, Netbase_Impressions_mean_mean)

Group6_full <- test_weeks_info %>%
               arrange(desc(US_Revenue)) %>% 
               filter(Group_6 == "True") %>% group_by(Title, Weeks_from_Launch) %>%
               summarise_if(.predicate = function(x) is.numeric(x),
               .funs = c(mean = "mean", max = "max"), na.rm = TRUE) %>%
               select(Title, Weeks_from_Launch,Nielsen_UA_mean_mean,
               Nielsen_First_Choice_mean_mean,Nielsen_Def_Interest_mean_mean,
         Netbase_Mentions_mean_mean,Tubular_Views_mean_mean,
         Youtube_US_mean_mean, Google_US_mean_mean, Netbase_Impressions_mean_mean)

#Exporting these weekly files.
library(openxlsx)
write.xlsx(Group1_full, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_Benchmarks/New files/Group1_full_post_US_new_fin.xlsx')
write.xlsx(Group2_full, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_Benchmarks/New files/Group2_full_post_US_new_fin.xlsx')
write.xlsx(Group3_full, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_Benchmarks/New files/Group3_full_post_US_new_fin.xlsx')
write.xlsx(Group4_full, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_Benchmarks/New files/Group4_full_post_US_new_fin.xlsx')
write.xlsx(Group5_full, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_Benchmarks/New files/Group5_full_post_US_new_fin.xlsx')
write.xlsx(Group6_full, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_Benchmarks/New files/Group6_full_post_US_new_fin.xlsx')
