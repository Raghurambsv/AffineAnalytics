##Code to modify the Cision dataset
##Initially the dataset was at 2 different levels
##We had daily level follower count, sentiment but the article count for each
##title was in columns

##This code was to create a dataset for Cision metrics at a weekly level for each
##title

##Modifying raw excel: Add a column to transpose the column value to a row
##Formula: INDEX(Row with column names, MATCH(TRUE, INDEX(Row with column names <> 0),0))

#Install the necessary packages
install.packages("tidyquant")
library(tidyquant)

#Install these packages if not already present in the system
library(readxl)    
library(tidyr)
library(dplyr)
library(tidyselect)

#Function to read the excel sheets
read_excel_allsheets <- function(filename, tibble = FALSE) {
  # I prefer straight data.frames
  # but if you like tidyverse tibbles (the default with read_excel)
  # then just pass tibble = TRUE
  sheets <- readxl::excel_sheets(filename)
  x <- lapply(sheets, function(X) readxl::read_excel(filename, sheet = X))
  if(!tibble) x <- lapply(x, as.data.frame)
  names(x) <- sheets
  x
}

#Reading the Cision 2017 raw dataset, present in local
mySheets <- read_excel_allsheets("C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/Raw_files/Cision/Cision 2017 data.xlsx")
Cision_2017_raw <- mySheets$`2017`

View(Cision_2017_raw)

#Dropping the unnecessary columns.
drop_cols <- c("Article ID", "Media name", "Title", "Content url")
Cision_2017_raw <- Cision_2017_raw[, !names(Cision_2017_raw) %in% drop_cols]

#First part, getting just the article counts.
#Changing every column to numeric
install.packages("taRifx")
library(taRifx)

cision_data <- japply(Cision_2017_raw, which(sapply(Cision_2017_raw, class) == "character"), as.numeric)

#Grouping data at a daily level.
cision_grouped <- cision_data %>% group_by(`Publication date`) %>% 
                    summarise_all(funs(sum(is.na(.))))

drop_cols <- c("Publication date", "Reach")
cision_v2 <- cision_grouped[, !names(cision_grouped) %in% drop_cols]

cision_trans <- cision_v2 %>% gather(Title, Count, `Back 4 Blood`:`Mario & Rabbids: Kingdom Battle`)
View(cision_trans)

#Now using gather to convert the dataset to long instead of wide
Cision_transposed <- cision_grouped %>% 
                      gather(Title, Count, `Back 4 Blood`:`Mario & Rabbids: Kingdom Battle`) %>%
                      select(Title, Count)

View(Cision_transposed)      

#Adding sequence of dates to the Cision dataset.
dates = seq(from = as.Date("2017-01-01"), to = as.Date("2017-12-31"), by = 'day')
cision_2017 <- cbind(Cision_transposed, Publication_date = rep(dates, each = 1))
View(cision_2017)

colnames(cision_2017) <- c("Title", "Count", "Date")
colnames(cision_2017)

#Modifying raw dataset
#Second part would be to get the daily level followers for each title
keep_cols <- c("Cision_Title","Publication date","Reach")
cision_title <- Cision_2017_raw[, names(Cision_2017_raw) %in% keep_cols]

colnames(cision_title)
colnames(cision_title) <- c("Date", "Reach", "Title")

cision_title$Date <- as.Date(cision_title$Date)
str(cision_2017)
str(cision_title)

#Performing an inner join
cision_2017_comb <- left_join(cision_2017, cision_title, by = c("Title","Date"))

#Cision - 2017 weekly
cision_weekly_count <- cision_2017_comb %>% group_by(Title) %>%
  tq_transmute(select = Count,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_reach <- cision_2017_comb %>% group_by(Title) %>%
  tq_transmute(select = Reach,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_2017_fin <- merge(x = cision_weekly_count, y = cision_weekly_reach, by = c("Title","Date") , all = TRUE)
View(cision_2017_fin)

###From here on - Cision 2018 dataset.
#Working on the 2018 Cision dataset
#Repeat the same process.

mySheets <- read_excel_allsheets("C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/Raw_files/Cision/Cision 2018.xlsx")
Cision_2018_raw <- mySheets$Sheet1
View(Cision_2018_raw)

#Dropping columns - Publication Date, Article ID, Content url, Title, Media name
drop_cols <- c("Publication date", "Article ID", "Content url", "Title", "Media name")
Cision_2018_raw <- Cision_2018_raw[, !names(Cision_2018_raw) %in% drop_cols]

Cision_2018_raw$`Article sentiment` <- as.factor(Cision_2018_raw$`Article sentiment`)
str(Cision_2018_raw$`Article sentiment`)

#Getting the Publication date column.
Cision_2018_raw$Date <- as.Date(Cision_2018_raw$`Publication date as timestamp`)

cision_2018_data <- japply(Cision_2018_raw, which(sapply(Cision_2018_raw, class) == "character"), as.numeric)
View(cision_2018_data)

cision_2018_grouped <- cision_2018_data %>% group_by(Date) %>% 
                       summarise_all(funs(sum(is.na(.))))

colnames(cision_2018_grouped)

drop_cols <- c("Date", "Article sentiment", "Publication date as timestamp",
               "#Followers", "Cision_Title")
cision_2018_v1 <- cision_2018_grouped[, !names(cision_2018_grouped) %in% drop_cols]

View(cision_2018_v1)
colnames(cision_2018_v1)

#Now using gather to convert the dataset to long instead of wide
Cision_transposed_2018 <- cision_2018_v1 %>% 
    gather(Title, Count, `Back 4 Blood`:`WWE 2K19`) %>%
  select(Title, Count)

View(Cision_transposed_2018)      

dates = seq(from = as.Date("2018-01-01"), to = as.Date("2018-12-31"), by = 'day')

cision_2018 <- cbind(Cision_transposed_2018, Date = rep(dates, each = 1))

#Modifying raw dataset
#Second part would be to get the daily level followers for each title

keep_cols <- c("Cision_Title","Date","#Followers", "Article sentiment")
cision_title <- Cision_2018_raw[, names(Cision_2018_raw) %in% keep_cols]

colnames(cision_title)
colnames(cision_title) <- c("Sentiment", "Reach", "Title", "Date")

str(cision_title)

#Performing an inner join
cision_2018_comb <- left_join(cision_2018, cision_title, by = c("Title","Date"))
View(cision_2018_comb)

#Making dummy variables for sentiment
install.packages("fastDummies")
library(fastDummies)

cision_2018_dummy <- fastDummies::dummy_cols(cision_2018_comb)
View(cision_2018_dummy)

cision_2018_dummy_mod <- cision_2018_dummy %>% select(-contains("Title_"))
View(cision_2018_dummy_mod)

#Cision - 2018 weekly
cision_weekly_count <- cision_2018_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Count,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_reach <- cision_2018_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Reach,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_sen_ambi <- cision_2018_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Sentiment_ambivalent,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_sen_neg <- cision_2018_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Sentiment_negative,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_sen_pos <- cision_2018_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Sentiment_positive,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_sen_neu <- cision_2018_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Sentiment_neutral,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_count <- as.data.frame(cision_weekly_count)
cision_weekly_reach <- as.data.frame(cision_weekly_reach)
cision_weekly_sen_ambi <- as.data.frame(cision_weekly_sen_ambi)
cision_weekly_sen_neg <- as.data.frame(cision_weekly_sen_neg)
cision_weekly_sen_neu <- as.data.frame(cision_weekly_sen_neu)
cision_weekly_sen_pos <- as.data.frame(cision_weekly_sen_pos)

require(plyr)

cision_2018_fin <- join_all(list(cision_weekly_count, cision_weekly_reach,
                                 cision_weekly_sen_ambi, cision_weekly_sen_neg,
                                 cision_weekly_sen_pos, cision_weekly_sen_neu), by = c("Title", "Date"), type = 'full')
View(cision_2018_fin)

###From here on - Cision 2019 dataset.
#Need to append both the Cision 2019 datasets before working on them
#I did this in Excel because there was a problem binding rows in R was throwing an error
#Working on the 2019 Cision dataset

mySheets <- read_excel_allsheets("C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/Raw_files/Cision/Cision 2019.xlsx")
Cision_2019_raw <- mySheets$Sheet1

#Dropping columns - Publication Date, Article ID, Content url, Title, Media name
drop_cols <- c("Publication date", "Article ID", "Content url", "Title", "Media name")
Cision_2019_raw <- Cision_2019_raw[, !names(Cision_2019_raw) %in% drop_cols]

Cision_2019_raw$`Article sentiment` <- as.factor(Cision_2019_raw$`Article sentiment`)
str(Cision_2019_raw$`Article sentiment`)

#Getting the Publication date column.
Cision_2019_raw$Date <- as.Date(Cision_2019_raw$`Publication date as timestamp`)

cision_2019_data <- japply(Cision_2019_raw, which(sapply(Cision_2019_raw, class) == "character"), as.numeric)
View(cision_2019_data)

cision_2019_grouped <- cision_2019_data %>% group_by(Date) %>% 
  summarise_all(funs(sum(is.na(.))))

colnames(cision_2019_grouped)

drop_cols <- c("Date", "Article sentiment", "Publication date as timestamp",
               "#Followers", "Cision_Title")

cision_2019_v1 <- cision_2019_grouped[, !names(cision_2019_grouped) %in% drop_cols]

View(cision_2019_v1)
colnames(cision_2019_v1)

#Now using gather to convert the dataset to long instead of wide
Cision_transposed_2019 <- cision_2019_v1 %>% 
  gather(Title, Count, `Back 4 Blood`:`WWE 2K19`) %>%
  select(Title, Count)

dates = seq(from = as.Date("2019-01-01"), to = as.Date("2019-12-31"), by = 'day')

cision_2019 <- cbind(Cision_transposed_2019, Date = rep(dates, each = 1))
View(cision_2019)

#Modifying raw dataset
#Second part would be to get the daily level followers for each title
keep_cols <- c("Cision_Title","Date","#Followers", "Article sentiment")
cision_title_2019 <- Cision_2019_raw[, names(Cision_2019_raw) %in% keep_cols]

colnames(cision_title_2019)
colnames(cision_title_2019) <- c("Sentiment", "Reach", "Title", "Date")

str(cision_title)

#Performing an inner join
cision_2019_comb <- left_join(cision_2019, cision_title_2019, by = c("Title","Date"))
View(cision_2019_comb)

#Making dummy variables for sentiment
install.packages("fastDummies")
library(fastDummies)

cision_2019_dummy <- fastDummies::dummy_cols(cision_2019_comb)
View(cision_2019_dummy)

cision_2019_dummy_mod <- cision_2019_dummy %>% select(-contains("Title_"))

#Cision - 2019 weekly
cision_weekly_count <- cision_2019_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Count,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_reach <- cision_2019_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Reach,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_sen_ambi <- cision_2019_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Sentiment_ambivalent,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_sen_neg <- cision_2019_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Sentiment_negative,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_sen_pos <- cision_2019_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Sentiment_positive,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_sen_neu <- cision_2019_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Sentiment_neutral,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_count <- as.data.frame(cision_weekly_count)
cision_weekly_reach <- as.data.frame(cision_weekly_reach)
cision_weekly_sen_ambi <- as.data.frame(cision_weekly_sen_ambi)
cision_weekly_sen_neg <- as.data.frame(cision_weekly_sen_neg)
cision_weekly_sen_neu <- as.data.frame(cision_weekly_sen_neu)
cision_weekly_sen_pos <- as.data.frame(cision_weekly_sen_pos)

require(plyr)

cision_2019_fin <- join_all(list(cision_weekly_count, cision_weekly_reach,
                                 cision_weekly_sen_ambi, cision_weekly_sen_neg,
                                 cision_weekly_sen_pos, cision_weekly_sen_neu), by = c("Title", "Date"), type = 'full')
View(cision_2019_fin)

###From here on - Cision 2020 dataset.
#Working on the 2020 Cision dataset

mySheets <- read_excel_allsheets("C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/Raw_files/Cision/Cision 2020.xlsx")
Cision_2020_raw <- mySheets$Sheet1

#Dropping columns - Publication Date, Article ID, Content url, Title, Media name
drop_cols <- c("Publication date", "Article ID", "Content url", "Title", "Media name")
Cision_2020_raw <- Cision_2020_raw[, !names(Cision_2020_raw) %in% drop_cols]

Cision_2020_raw$`Article sentiment` <- as.factor(Cision_2020_raw$`Article sentiment`)
str(Cision_2020_raw$`Article sentiment`)

#Getting the Publication date column.
Cision_2020_raw$Date <- as.Date(Cision_2020_raw$`Publication date as timestamp`)

cision_2020_data <- japply(Cision_2020_raw, which(sapply(Cision_2020_raw, class) == "character"), as.numeric)
View(cision_2020_data)

cision_2020_grouped <- cision_2020_data %>% group_by(Date) %>% 
  summarise_all(funs(sum(is.na(.))))

colnames(cision_2019_grouped)

drop_cols <- c("Date", "Article sentiment", "Publication date as timestamp",
               "#Followers", "Cision_Title")

cision_2020_v1 <- cision_2020_grouped[, !names(cision_2020_grouped) %in% drop_cols]

View(cision_2020_v1)
colnames(cision_2020_v1)

#Now using gather to convert the dataset to long instead of wide
Cision_transposed_2020 <- cision_2020_v1 %>% 
  gather(Title, Count, `Back 4 Blood`:`WWE 2K19`) %>%
  select(Title, Count)

dates = seq(from = as.Date("2020-01-01"), to = as.Date("2020-05-31"), by = 'day')

cision_2020 <- cbind(Cision_transposed_2020, Date = rep(dates, each = 1))
View(cision_2020)

#Modifying raw dataset
#Second part would be to get the daily level followers for each title
keep_cols <- c("Cision_Title","Date","#Followers", "Article sentiment")
cision_title_2020 <- Cision_2020_raw[, names(Cision_2020_raw) %in% keep_cols]

colnames(cision_title_2020)
colnames(cision_title_2020) <- c("Sentiment", "Reach", "Title", "Date")

str(cision_title)

#Performing an inner join
cision_2020_comb <- left_join(cision_2020, cision_title_2020, by = c("Title","Date"))
View(cision_2020_comb)

#Making dummy variables for sentiment
install.packages("fastDummies")
library(fastDummies)

cision_2020_dummy <- fastDummies::dummy_cols(cision_2020_comb)
View(cision_2020_dummy)

cision_2020_dummy_mod <- cision_2020_dummy %>% select(-contains("Title_"))

#Cision - 2019 weekly
cision_weekly_count <- cision_2020_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Count,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_reach <- cision_2020_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Reach,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_sen_ambi <- cision_2020_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Sentiment_ambivalent,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_sen_neg <- cision_2020_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Sentiment_negative,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_sen_pos <- cision_2020_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Sentiment_positive,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_sen_neu <- cision_2020_dummy_mod %>% group_by(Title) %>%
  tq_transmute(select = Sentiment_neutral,
               mutate_fun = apply.weekly,
               FUN = sum,
               na.rm = TRUE)

cision_weekly_count <- as.data.frame(cision_weekly_count)
cision_weekly_reach <- as.data.frame(cision_weekly_reach)
cision_weekly_sen_ambi <- as.data.frame(cision_weekly_sen_ambi)
cision_weekly_sen_neg <- as.data.frame(cision_weekly_sen_neg)
cision_weekly_sen_neu <- as.data.frame(cision_weekly_sen_neu)
cision_weekly_sen_pos <- as.data.frame(cision_weekly_sen_pos)

require(plyr)

cision_2020_fin <- join_all(list(cision_weekly_count, cision_weekly_reach,
                                 cision_weekly_sen_ambi, cision_weekly_sen_neg,
                                 cision_weekly_sen_pos, cision_weekly_sen_neu), by = c("Title", "Date"), type = 'full')

#Export the data from here on. 
library(openxlsx)
write.xlsx(cision_2017_fin, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/Raw_files/Cision/Cision_2017.xlsx')
write.xlsx(cision_2018_fin, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/Raw_files/Cision/Cision_2018.xlsx')
write.xlsx(cision_2019_fin, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/Raw_files/Cision/Cision_2019.xlsx')
write.xlsx(cision_2020_fin, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/Raw_files/Cision/Cision_2020.xlsx')
