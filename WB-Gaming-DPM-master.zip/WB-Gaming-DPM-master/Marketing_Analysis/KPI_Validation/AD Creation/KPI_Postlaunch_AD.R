#This code was used to build the dataset at a title level to be used in the file.
#A lot of pre-processsing is also done in Excel & then worked upon.

#Initial level of the dataset: Weekly metrics for each title.
#Output: Creating an AD at a title level for each of the territories
#Filters: Post-launch weeks 0 to 20 for each territory.

#Building the dataset. 
install.packages("readxl")
install.packages("plyr")
install.packages("tibble")

#Read the necessary packages for processing. If missing, install in the system as
#necessary.
library(readxl)
library(plyr)
library(tibble)
library(dplyr)

kpi_dataset <- "C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_New_Files/Final_AD_WIP.xlsx"
excel_sheets(kpi_dataset)

#Working with US dataset. 
us_dataset <- read_excel(path = kpi_dataset, sheet = "US_Fin")
uk_dataset <- read_excel(path = kpi_dataset, sheet = "UK_Fin")
ger_dataset <- read_excel(path = kpi_dataset, sheet = "Ger_Fin")
sales_info <- read_excel(path = kpi_dataset, sheet = "Sales_info")

#Working with the US dataset. 
#First, filter for 0 to 20 weeks & then merge with Revenue data.
colnames(us_dataset)

#Here summarize all the metrics, get the mean & the max value
us_metrics <- us_dataset %>% 
               filter(`Weeks from Launch` >= 0 & `Weeks from Launch` <= 20) %>%
               group_by(Title,`Weeks from Launch`) %>% group_by(Title) %>%
               subset(select = -`Weeks from Launch`) %>%
               summarise_if(.predicate = function(x) is.numeric(x),
                            .funs = c(mean = "mean", max = "max"), na.rm = TRUE)

#Drop the unnecessary columns - Ger, UK Revenue & their groups
us_revenue <- sales_info %>% subset(select = -c(UK_Revenue, Ger_Revenue, UK_Rev_Group, Ger_Rev_Group))

#Merge the earlier dataset with aggregated metrics + revenue to get the file at 
#a title level
us_final <- merge(us_metrics, us_revenue, by = "Title")

View(us_final)

#Working with the UK dataset. 
#First, filter for 0 to 20 weeks & then merge with Revenue data.
colnames(uk_dataset)

#Here summarize all the metrics, get the mean & the max value
uk_metrics <- uk_dataset %>% 
  filter(`Weeks from Launch` >= 0 & `Weeks from Launch` <= 20) %>%
  group_by(Title,`Weeks from Launch`) %>% group_by(Title) %>%
  subset(select = -`Weeks from Launch`) %>%
  summarise_if(.predicate = function(x) is.numeric(x),
               .funs = c(mean = "mean", max = "max"), na.rm = TRUE)

#Drop the unnecessary columns - Ger, US Revenue & their groups
uk_revenue <- sales_info %>% subset(select = -c(US_Revenue, Ger_Revenue, US_Rev_Group, Ger_Rev_Group))

#Merge the earlier dataset with aggregated metrics + revenue to get the file at 
#a title level
uk_final <- merge(uk_metrics, uk_revenue, by = "Title")

View(uk_final)

#Working with the Germany dataset. 
#First, filter for 0 to 20 weeks & then merge with Revenue data.
colnames(ger_dataset)

#Here summarize all the metrics, get the mean & the max value
ger_metrics <- ger_dataset %>% 
  filter(`Weeks from Launch` >= 0 & `Weeks from Launch` <= 20) %>%
  group_by(Title,`Weeks from Launch`) %>% group_by(Title) %>%
  subset(select = -`Weeks from Launch`) %>%
  summarise_if(.predicate = function(x) is.numeric(x),
               .funs = c(mean = "mean", max = "max"), na.rm = TRUE)

#Drop the unnecessary columns - UK, US Revenue & their groups
ger_revenue <- sales_info %>% subset(select = -c(US_Revenue, UK_Revenue, US_Rev_Group, UK_Rev_Group))

#Merge the earlier dataset with aggregated metrics + revenue to get the file at 
#a title level
ger_final <- merge(ger_metrics, ger_revenue, by = "Title")

View(ger_final)

#Export the files. 
library(openxlsx)

write.xlsx(us_final, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_New_Files/US_Fin_post_launch_Cis.xlsx')
write.xlsx(uk_final, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_New_Files/UK_Fin_post_launch.xlsx')
write.xlsx(ger_final, 'C:/Users/XABARBAD/Desktop/Work/KPI Validation & Importance/Model 2/KPI_New_Files/Ger_Fin_post_launch.xlsx')
