with temp_table1 as
(
       select a.player_id, start_date, end_date, date(event_dt) date
       from seven11_prod_da.wba_player_daily a
       join sandbox.churnAD_players_20190722 b
       on a.player_id = b.player_id ----and date(event_dt) between b.start_date and b.end_date
       where event_dt >= '2019-04-22' and total_hours > 0
       and total_hours<24 and session_count>0
       --and player_id in ('1006208687261604451','1044749861892041442')
),
------------------
temp_table_last_session as
(
       select player_id, start_date, end_date, session_id,date(event_timestamp) event_dt
       from
       (
              select "_platform_account_id" player_id, start_date, end_date, "_session_id"  session_id,event_timestamp
              , DENSE_RANK() over (partition by _platform_account_id, end_date order by event_timestamp desc) no_of_sessions
              from (
              select "_platform_account_id", start_date, end_date, "_session_id",  max(_event_time_utc) event_timestamp
              from seven11_prod.seven11_activity_end a
              join sandbox.churnAD_players_20190722 b
              on a._platform_account_id = b.player_id and date(a._event_time_utc) between b.start_date and b.end_date  
              --where date("_event_time_utc") >= '2019-04-22' and date("_event_time_utc") <= '2019-05-24' 
                           --and _platform_account_id in ('1006208687261604451','1044749861892041442')
              group by 1,2,3,4
              )
       ) 
       where no_of_sessions in (1)
),

------------

temp_table_last_two_sessions as
(
	select player_id, start_date, end_date, session_id,date(event_timestamp) event_dt
	from
	(
		select "_platform_account_id" player_id, start_date, end_date, "_session_id"  session_id,event_timestamp
		, DENSE_RANK() over (partition by _platform_account_id, end_date  order by event_timestamp desc) no_of_sessions
		from (
		select "_platform_account_id", b.start_date, b.end_date, "_session_id",  max(_event_time_utc) event_timestamp
		from seven11_prod.seven11_activity_end a
		join sandbox.churnAD_players_20190722 b
		on a._platform_account_id = b.player_id and date(a._event_time_utc) between b.start_date and b.end_date  
		--where date("_event_time_utc") >= '2019-04-22' and date("_event_time_utc") <= '2019-05-24' 
				--and _platform_account_id in ('1006208687261604451','1044749861892041442')
		group by 1,2,3,4
		)
	) 
	where no_of_sessions in (1,2)
),

----------

krypt_activity as
(
select a.player_id, start_date, end_date, sum(activity_hours) krypt_hours , sum(activity_count) krypt_visits
from seven11_prod_da.wba_fact_activity a
join sandbox.churnAD_players_20190722 b
on a.player_id = b.player_id and date(a.event_dt) between b.start_date and b.end_date
---where date(event_dt) >= '2019-04-22' and date(event_dt) <= '2019-05-24'
where activity_name ='GM_KRYPT' and activity_hours>0 and activity_hours is not null 
group by 1,2,3
)

--------------

select * into sandbox.churnAD_20190726
from
(
select *, row_number()over (order by player_id) as row_num
from
(
	select a.*, b.matches, b.matches_per_day, b.fraction_wins, b.player_level, b.xp_per_day, b.story_matches
	, b.Online_PvP_1v1_matches, b.Online_PvP_Other_matches, b.Towers_matches, b.Tutorial_matches
	, coalesce(b.combo_counts_per_match,0) combo_counts_per_match
	, coalesce(b.max_combo_moves_per_match,0) max_combo_moves_per_match
	, coalesce(b.avg_rounds_per_match,0) avg_rounds_per_match
	, coalesce(b.avg_health_remaining,0) avg_health_remaining
	, coalesce((cast(i.no_of_times_gears_equipped as float)/b.matches),0) gears_per_match
	, coalesce(b.grab_counts_per_match) grab_counts_per_match
	, coalesce(Brutalities_per_match,0) Brutalities_per_match
	, coalesce(Fatalities_per_match,0) Fatalities_per_match
	, b.local_matches, b.AI_fighter_matches, b.multi_Tournament_matches
	, datediff(day,h.event_dt,(a.end_date)) last_activity_before_scoring
	,datediff(day,join_date,(a.end_date+1)) max_possible_days, coalesce(g.krypt_hours,0) krypt_hours
	, coalesce(g.krypt_visits,0) krypt_visits, coalesce(c.LTD,0) money_spent
	, coalesce(d.time_per_fight_story_mode_sec,0) sec_per_fight_story_mode
	, coalesce(d.first_bucket_success_fraction,0) first_bucket_success_fraction
	, coalesce(d.second_bucket_success_fraction,0) second_bucket_success_fraction
	, coalesce(d.third_bucket_success_fraction,0) third_bucket_success_fraction
	, coalesce(d.fourth_bucket_success_fraction,0) fourth_bucket_success_fraction
	, coalesce(d.fifth_bucket_success_fraction,0) fifth_bucket_success_fraction
	, f.matches_recently, f.fraction_wins_recently, f.avg_match_length_recently, f.xp_gained_recently
	, f.xp_gained_per_day_recently, f.mins_played_recently, f.story_matches_recently
	, f.Online_PvP_1v1_matches_recently, f.Online_PvP_Other_matches_recently, f.Towers_matches_recently
	, f.Tutorial_matches_recently, f.local_matches_recently, f1.matches_recently_manual
	, f1.fraction_wins_manual_recently, b1.matches_manual, b1.fraction_wins_manual
	, e.churn_flag_days
       from          
       (
              select a.player_id, b.join_date, b.start_date, b.end_date, count(distinct event_dt) days
              , coalesce(cast(Sum(total_hours) as float)/nullif(count(distinct event_dt),0),0) hrs_per_day 
              , sum(session_count) sessions, coalesce(cast(Sum(total_hours) as float)/nullif(sum(session_count),0),0) hrs_per_session
              , coalesce(cast(sum(session_count) as float)/nullif(count(distinct event_dt),0),0) sessions_per_day
              from seven11_prod_da.wba_player_daily a
              join sandbox.churnAD_players_20190722 b
              on a.player_id = b.player_id and date(a.event_dt) between b.start_date and b.end_date 
              --where event_dt >= '2019-04-22' and event_dt <= '2019-05-24' and 
              where total_hours > 0 and total_hours<24 and session_count>0
              group by 1,2,3,4
       ) a
	   left join
	   (
    		select _platform_account_id player_id, a.start_date, a.end_date
        	, count(distinct match_id) as matches
        	, coalesce(cast(matches as float)/count(distinct date(match_date)),0) matches_per_day
        	, coalesce(cast(sum(total_rounds_played) as float)/matches,0) avg_rounds_per_match
        	, coalesce(cast(sum(total_health_remaining) as float)/sum(total_rounds_played),0) avg_health_remaining 
        	, coalesce(cast(sum(combo_counts) as float)/matches,0) combo_counts_per_match
        	, coalesce(cast(sum(max_combo_moves) as float)/matches,0) max_combo_moves_per_match
        	, coalesce(cast(sum(grab_counts) as float)/matches,0) grab_counts_per_match
        	, coalesce(cast(sum(Brutalities_Used) as float)/matches,0) Brutalities_per_match
        	, coalesce(cast(sum(Fatalities_Used) as float)/matches,0) Fatalities_per_match
        	, coalesce(cast(sum(player_win) as float)/count(player_win),0) fraction_wins
        	, avg(match_length) avg_match_length, max(profile_level) as player_level
        	, coalesce(cast(sum(a.profile_xp_gained) as float)/count(distinct date(match_date)),0) xp_per_day
        	, sum(case when activity_name in ('GM_STORY_OFF') then 1 else 0 end) story_matches
        	, sum(case when activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1') then 1 else 0 end ) Online_PvP_1v1_matches
        	, sum(case when activity_name in ('GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT') then 1 else 0 end ) Online_PvP_Other_matches
        	, sum(case when activity_name in ('GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER','GM_KLASSIC_PORTAL_MODE','GM_KLASSIC_PORTAL_MODE_LADDER') then 1 else 0 end) Towers_matches
        	, sum(case when activity_name in ('GM_FATALITY_TUTORIAL','GM_TUTORIAL_OFFLINE','GM_PRACTICE') then 1 else 0 end) Tutorial_matches
        	, sum(case when activity_name in ('GM_LOCAL_VERSUS_OFF','GM_MULTI_VERSUS_OFF') then 1 else 0 end) local_matches
        	, sum(case when activity_name in ('GM_AI_FIGHTER') then 1 else 0 end) AI_fighter_matches
        	, sum(case when activity_name in ('GM_MULTI_TOURNAMENT_OFF') then 1 else 0 end) multi_Tournament_matches
        	from sandbox.churn_playermatches_20190724 a
        	--where ai_player = 0
        	group by 1,2,3
    	) b
    	on a.player_id = b.player_id 
    	and a.end_date = b.end_date
		left join
    	(
    		select _platform_account_id, b.start_date, b.end_date, count(_session_id) no_of_times_gears_equipped
    		from seven11_prod.seven11_gameplay_customization a
    		join sandbox.churnAD_players_20190722 b
    		on a._platform_account_id = b.player_id and date(a._event_time_utc) between b.start_date and b.end_date
    		group by 1,2,3
    	) i
    	on a.player_id = i._platform_account_id
    	and a.end_date = i.end_date
	   left join 
       (
    		select _platform_account_id player_id, a.start_date, a.end_date
    		, count(distinct match_id) as matches_manual
    		, coalesce(cast(sum(player_win) as float)/count(player_win),0) fraction_wins_manual
    		from sandbox.churn_playermatches_20190724 a
    		where ai_player = 0
    		group by 1,2,3
        ) b1
    	on a.player_id = b1.player_id 
    	and a.end_date = b1.end_date
        left join
        (
              select a._platform_account_id player_id, b.start_date, b.end_date, sum(change_amount)*.008 LTD
              from seven11_prod.seven11_resource_flow a
              join sandbox.churnAD_players_20190722 b
              on a._platform_account_id = b.player_id and date(a._event_time_utc) between b.start_date and b.end_date
              where resource = 'Exp_PremiumCurrency' and source = 'ENTITLEMENT'
              --and date(_event_time_utc) >='2019-04-22' and date(_event_time_utc) <='2019-05-24'
              group by 1,2,3
       ) c
       on a.player_id = c.player_id 
       and a.end_date = c.end_date
       left join
       (
              select player_id, start_date, end_date
              , cast(max(total_time_played) as float)/max(fight_number) as time_per_fight_story_mode_sec
              , sum(first_bucket_success_fraction) first_bucket_success_fraction
              , sum(second_bucket_success_fraction) second_bucket_success_fraction
              , sum(third_bucket_success_fraction) third_bucket_success_fraction
              , sum(fourth_bucket_success_fraction) fourth_bucket_success_fraction
              , sum(fifth_bucket_success_fraction) fifth_bucket_success_fraction
              from
              (
                     select _platform_account_id player_id, b.start_date, b.end_date, (floor(fight_number/10)::float)*10 bucket
                     , case when bucket=0 then cast(sum(player_win) as float)/count(player_win) else 0 end as first_bucket_success_fraction
                     , case when bucket=10 then cast(sum(player_win) as float)/count(player_win) else 0 end as second_bucket_success_fraction
                     , case when bucket=20 then cast(sum(player_win) as float)/count(player_win) else 0 end as third_bucket_success_fraction
                     , case when bucket=30 then cast(sum(player_win) as float)/count(player_win) else 0 end as fourth_bucket_success_fraction
                     , case when bucket=40 then cast(sum(player_win) as float)/count(player_win) else 0 end as fifth_bucket_success_fraction
                     , max(total_time_played) as total_time_played
                     , max(fight_number) as fight_number     
                     from seven11_prod.seven11_progression_campaignprogress a
                     join sandbox.churnAD_players_20190722 b
                     on a._platform_account_id = b.player_id and date(a._event_time_utc) between b.start_date and b.end_date
                     --where date(_event_time_utc) >= '2019-04-22' and date(_event_time_utc) <= '2019-05-24'
                     group by 1,2,3,4
              )      
              group by 1,2,3
       ) d
       on a.player_id = d.player_id
       and a.end_date = d.end_date
	   ------------DEPENDENT VARIABLE----------------
	   join
       (
        	select player_id, start_date, end_date,
            case when days_in_week_one<=2 and days_in_week_two = 0 then 1 else 0 end churn_flag_days
            from
            (
            	select a.player_id, a.start_date, a.end_date, days_in_week_one, days_in_week_two
                from
                (
                	select player_id, start_date, end_date
                    , SUM(case when date<=end_date OR date>dateadd(day,7,end_date) THEN 0 ELSE 1 end) AS days_in_week_one
                    from temp_table1
                    group by 1,2,3
                ) a
                join
                (
                	select player_id, start_date, end_date
                    , sum(case when date<=dateadd(day,7,end_date) OR date>dateadd(day,14,end_date) THEN 0 else 1 end) days_in_week_two
                    from temp_table1
                    group by 1,2,3
                ) b
                on a.player_id = b.player_id and a.end_date = b.end_date                  
            ) c
       ) e    
       on a.player_id=e.player_id
       and a.end_date = e.end_date
	   left join
	   (
	    	select a._platform_account_id player_id, b.start_date, b.end_date
			, count(distinct match_id) matches_recently
			, cast(sum(player_win) as float)/count(player_win) fraction_wins_recently
			, avg(match_length) avg_match_length_recently
			, sum(a.profile_xp_gained) xp_gained_recently
			, cast(sum(a.profile_xp_gained) as float)/count(distinct date(match_date)) xp_gained_per_day_recently
			, sum(cast(match_length as float))/60 mins_played_recently
			, sum(case when activity_name in ('GM_STORY_OFF') then 1 else 0 end) story_matches_recently
			, sum(case when activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1') then 1 else 0 end ) Online_PvP_1v1_matches_recently
			, sum(case when activity_name in ('GM_GROUP_BATTLES', 'GM_PRIVATE_MATCH_ON_HOTSEAT', 'GM_PRIVATE_MATCH_ON_KOTH', 'GM_PRIVATE_MATCH_ON_PRACTICE' ,'GM_PLAYER_MATCH_ON_KOTH' ,'GM_PLAYER_MATCH_ON_HOT_SEAT') then 1 else 0 end ) Online_PvP_Other_matches_recently
			, sum(case when activity_name in ('GM_TOWERS_OF_TIME','GM_TOWERS_OF_TIME_LADDER','GM_KLASSIC_PORTAL_MODE','GM_KLASSIC_PORTAL_MODE_LADDER') then 1 else 0 end) Towers_matches_recently
			, sum(case when activity_name in ('GM_FATALITY_TUTORIAL','GM_TUTORIAL_OFFLINE','GM_PRACTICE') then 1 else 0 end) Tutorial_matches_recently
			, sum(case when activity_name in ('GM_LOCAL_VERSUS_OFF','GM_MULTI_VERSUS_OFF') then 1 else 0 end) local_matches_recently
			from sandbox.churn_playermatches_20190724 a
			join temp_table_last_two_sessions b
			on a._platform_account_id = b.player_id
			and date(a.match_date) = date(b.event_dt)
			and a.session_id = b.session_id
			--where ai_player = 0
			group by 1,2,3
		) f
		on a.player_id = f.player_id and a.end_date = f.end_date
		left join
		(
			select a._platform_account_id player_id, b.start_date, b.end_date
			, count(distinct match_id) matches_recently_manual
			, cast(sum(player_win) as float)/count(player_win) fraction_wins_manual_recently
			from sandbox.churn_playermatches_20190724 a
			join temp_table_last_two_sessions b
			on a._platform_account_id = b.player_id
			and date(a.match_date) = date(b.event_dt)
			and a.session_id = b.session_id
			where ai_player = 0
			group by 1,2,3
		) f1
		on a.player_id = f1.player_id and a.end_date = f1.end_date
        left join krypt_activity g
        on a.player_id = g.player_id and a.end_date = g.end_date
	    join temp_table_last_session h
        on a.player_id = h.player_id and a.end_date = h.end_date
        --where a.player_id in ('1006208687261604451','1044749861892041442')     
)
)