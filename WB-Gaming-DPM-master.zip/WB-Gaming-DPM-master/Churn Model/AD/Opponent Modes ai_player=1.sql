select * into sandbox.churn_playermatches_opponent_modes_aiplayer1_20190724
from
(
select _platform_account_id
, match_id
, "_session_id" session_id
, activity_name
, date(_event_time_utc)  match_date
, player_win, start_date, end_date, ai_player
, max(profile_xp_gained) profile_xp_gained
, max(match_length) match_length
, max(profile_level) profile_level
, sum(rounds) total_rounds_played
, sum(avg_health_remaining) total_health_remaining
, sum(combo_count) combo_counts
, sum(combo_max_hits) max_combo_moves
, sum(grab_count) grab_counts
, sum(case when finisher_used = 'brutality' then 1 else 0 end) Brutalities_Used
, sum(case when finisher_used = 'fatality' then 1 else 0 end) Fatalities_Used
from sandbox.churnAD_players_20190722 a
left join
( 
	(
		(
			select *
			from seven11_prod.seven11_match_result_player
			where ai_difficulty = -1 and ai_player in (0) and match_length>0 and activity_name in ('GM_AI_FIGHTER') and 
			((date(_event_time_utc)>='2019-04-22' and date(_event_time_utc)<= '2019-05-13') or (date(_event_time_utc) between '2019-05-17' and '2019-05-20') or
			(date(_event_time_utc) between '2019-05-22' and '2019-05-27'))
		)
	)
	UNION ALL
	(
		(
			select *
			from seven11_prod.seven11_match_result_player
			where ai_difficulty = -1 and ai_player in (0) and match_length>0 and activity_name in ('GM_FATALITY_TUTORIAL') and 
			((date(_event_time_utc)>='2019-04-22' and date(_event_time_utc) <= '2019-05-02') or (date(_event_time_utc) between '2019-05-04' and '2019-05-12') or
			(date(_event_time_utc) between '2019-05-18' and '2019-05-27'))
		)
	)
	UNION ALL
	(
		(
			select *
			from seven11_prod.seven11_match_result_player
			where ai_difficulty = -1 and ai_player in (0) and match_length>0 and activity_name in ('GM_GROUP_BATTLES') and 
			((date(_event_time_utc)>='2019-04-22' and date(_event_time_utc) <= '2019-05-28') or (date(_event_time_utc) >= '2019-06-22' and
			date(_event_time_utc) <='2019-07-10'))
		)
	)
	UNION ALL
	(
		(
			select *
			from seven11_prod.seven11_match_result_player
			where ai_difficulty = -1 and ai_player in (0) and match_length>0 and activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER')
			and 
			((date(_event_time_utc)>='2019-04-22' and date(_event_time_utc) <= '2019-06-08') or (date(_event_time_utc) >= '2019-06-10' and
			date(_event_time_utc) <= '2019-07-16'))
		)
	)
	UNION ALL
	(
		(
			select *
			from seven11_prod.seven11_match_result_player
			where ai_difficulty = -1 and ai_player in (0) and match_length>0 and activity_name in ('GM_STORY_OFF') and 
			((date(_event_time_utc)>='2019-04-22' and date(_event_time_utc) <= '2019-04-30') or 
			(date(_event_time_utc) in ('2019-05-02')) or
			(date(_event_time_utc) between '2019-05-04' and '2019-05-07') or 
			(date(_event_time_utc) between '2019-05-09' and '2019-05-13') or
			(date(_event_time_utc) between '2019-05-18' and '2019-05-20') or 
			(date(_event_time_utc) between '2019-05-23' and '2019-05-26'))
		)
	)
	UNION ALL
	(
		(
			select *
			from seven11_prod.seven11_match_result_player
			where ai_difficulty = -1 and ai_player in (0) and match_length>0 and activity_name in ('GM_TUTORIAL_OFFLINE') and
			((date(_event_time_utc)>='2019-04-22' and date(_event_time_utc) <= '2019-05-02') or
			(date(_event_time_utc) between '2019-05-04' and '2019-05-13') or
			(date(_event_time_utc) between '2019-05-19' and '2019-05-23') or 
			(date(_event_time_utc) in ('2019-05-25','2019-05-26')))
		) 
	)
) b	
on a.player_id = b._platform_account_id and date(b._event_time_utc) between a.start_date and a.end_date
group by 1,2,3,4,5,6,7,8,9
)