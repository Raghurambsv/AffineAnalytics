select * into sandbox.churnAD_players_20190722
from
(
select player_id, start_date, end_date, join_date
from
(
	(
		select player_id, min(event_dt) join_date, date('2019-04-22') start_date, date('2019-04-30') end_date
		from seven11_prod_da.wba_player_daily
		where event_dt between '2019-04-22' and '2019-04-29' and total_hours > 0
		and total_hours<24 and session_count>0
		group by 1
	)	
	UNION ALL
	(	select player_id, min(event_dt) join_date, date('2019-04-22') start_date, date('2019-05-22') end_date
		from seven11_prod_da.wba_player_daily
		where event_dt between '2019-04-22' and '2019-05-21' and total_hours > 0
		and total_hours<24 and session_count>0
		group by 1
	)
	UNION ALL
	(	select player_id, min(event_dt) join_date, date('2019-04-22') start_date, date('2019-06-15') end_date
		from seven11_prod_da.wba_player_daily
		where event_dt between '2019-04-22' and '2019-06-14' and total_hours > 0
		and total_hours<24 and session_count>0
		group by 1
	)	
)
group by 1,2,3,4
)