select * into sandbox.churn_playermatches_no_opponent_modes_20190723
from
(
select _platform_account_id
, match_id
, "_session_id" session_id
, activity_name
, date(a._event_time_utc)  match_date
, player_win, b.start_date, b.end_date, ai_player
, max(profile_xp_gained) profile_xp_gained
, max(match_length) match_length
, max(profile_level) profile_level
, sum(rounds) total_rounds_played
, sum(avg_health_remaining) total_health_remaining
, sum(combo_count) combo_counts
, sum(combo_max_hits) max_combo_moves
, sum(grab_count) grab_counts
, sum(case when finisher_used = 'brutality' then 1 else 0 end) Brutalities_Used
, sum(case when finisher_used = 'fatality' then 1 else 0 end) Fatalities_Used
from seven11_prod.seven11_match_result_player a
join sandbox.churnAD_players_20190722 b
on a._platform_account_id = b.player_id and date(a._event_time_utc) between b.start_date and b.end_date
--where date(a._event_time_utc) >= '2019-04-22' and date(a._event_time_utc) <= '2019-05-24'
where ai_difficulty = -1 and ai_player in (0,1) and match_length>0 and activity_name not in ('GM_AI_FIGHTER',
'GM_FATALITY_TUTORIAL','GM_GROUP_BATTLES','GM_KLASSIC_PORTAL_MODE_LADDER','GM_STORY_OFF','GM_TUTORIAL_OFFLINE')
group by 1,2,3,4,5,6,7,8,9
)