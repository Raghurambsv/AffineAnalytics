select * into sandbox.churn_playermatches_opponent_modes_aiplayer2_20190724
from
(
select _platform_account_id
, match_id
, "_session_id" session_id
, activity_name
, date(_event_time_utc)  match_date
, player_win, start_date, end_date, ai_player
, max(profile_xp_gained) profile_xp_gained
, max(match_length) match_length
, max(profile_level) profile_level
, sum(rounds) total_rounds_played
, sum(avg_health_remaining) total_health_remaining
, sum(combo_count) combo_counts
, sum(combo_max_hits) max_combo_moves
, sum(grab_count) grab_counts
, sum(case when finisher_used = 'brutality' then 1 else 0 end) Brutalities_Used
, sum(case when finisher_used = 'fatality' then 1 else 0 end) Fatalities_Used
from sandbox.churnAD_players_20190722 a
left join
( 
	(
		(
			select *
			from seven11_prod.seven11_match_result_player
			where ai_difficulty = -1 and ai_player in (0,1) and match_length>0 and activity_name in ('GM_AI_FIGHTER') and 
			(
			(date(_event_time_utc) >= '2019-05-14' and date(_event_time_utc)<='2019-05-16') or
			(date(_event_time_utc) in ('2019-05-21')) or
			(date(_event_time_utc) >= '2019-05-28')
			)
		)
	)
	UNION ALL
	(
		(
			select *
			from seven11_prod.seven11_match_result_player
			where ai_difficulty = -1 and ai_player in (0,1) and match_length>0 and activity_name in ('GM_FATALITY_TUTORIAL') and 
			(
			(date(_event_time_utc) in ('2019-05-03')) or
			(date(_event_time_utc) >= '2019-05-13' and date(_event_time_utc) <= '2019-05-17') or
			(date(_event_time_utc) >= '2019-05-28')
			)
		)
	)
	UNION ALL
	(
		(
			select *
			from seven11_prod.seven11_match_result_player
			where ai_difficulty = -1 and ai_player in (0,1) and match_length>0 and activity_name in ('GM_GROUP_BATTLES') and 
			(
			(date(_event_time_utc) >= '2019-05-29' and date(_event_time_utc) <= '2019-06-21') or
			(date(_event_time_utc) >= '2019-07-11')
			)
		)
	)
	UNION ALL
	(
		(
			select *
			from seven11_prod.seven11_match_result_player
			where ai_difficulty = -1 and ai_player in (0,1) and match_length>0 and activity_name in ('GM_KLASSIC_PORTAL_MODE_LADDER')
			and (date(_event_time_utc) in ('2019-06-09','2019-07-17'))
		)
	)
	UNION ALL
	(
		(
			select *
			from seven11_prod.seven11_match_result_player
			where ai_difficulty = -1 and ai_player in (0,1) and match_length>0 and activity_name in ('GM_STORY_OFF') and 
			(
			(date(_event_time_utc) in ('2019-05-01','2019-05-03','2019-05-08','2019-05-21','2019-05-22')) or
			(date(_event_time_utc) >= '2019-05-14' and date(_event_time_utc) <= '2019-05-17') or
			(date(_event_time_utc) >= '2019-05-27')
			)
		)
	)
	UNION ALL
	(
		(
			select *
			from seven11_prod.seven11_match_result_player
			where ai_difficulty = -1 and ai_player in (0,1) and match_length>0 and activity_name in ('GM_TUTORIAL_OFFLINE') and
			(
			(date(_event_time_utc) in ('2019-05-03','2019-05-24')) or
			(date(_event_time_utc) >= '2019-05-14' and date(_event_time_utc) <= '2019-05-18') or
			(date(_event_time_utc) >= '2019-05-27')
			)
		) 
	)
) b	
on a.player_id = b._platform_account_id and date(b._event_time_utc) between a.start_date and a.end_date
group by 1,2,3,4,5,6,7,8,9
)

