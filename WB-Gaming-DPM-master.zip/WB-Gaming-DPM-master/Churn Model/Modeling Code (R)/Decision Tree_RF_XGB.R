library(ggplot2)
library(ROCR)
library(corrplot)
library(gridExtra)
library(caret)
library(e1071)
library(Hmisc)
library(party)
library(randomForest)
library(caTools)
library(xgboost)

sampleplayers <- read.csv('C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/20190613/Model_iteration_AD.csv')
colnames(sampleplayers)

######Modeling Variables
model_col <- sampleplayers[,-c(1,2,5,27,32,33,35,43,44)]   ######Removig avg match length recently, fraction wns recently, multi-versus matches recently bec. very less correlation with churn flag
colnames(model_col)

independent_variables <- model_col[c(1:22,24:35)]
Dependednt_Variable <- "churn_flag_days"
Independent_Variables <- names(independent_variables)
model_equtn <- reformulate(Independent_Variables,Dependednt_Variable)
model_equtn
Reg1<- lm(model_equtn,na.action=na.pass,data=model_col)
print(summary(Reg1))

#vif
vif <- function(object, ...)
  UseMethod("vif")
vif.lm <- function(object, ...) {
  V <- summary(object)$cov.unscaled
  Vi <- crossprod(model.matrix(object))
  nam <- names(coef(object))
  if(k <- match("(Intercept)", nam, nomatch = F)) {
    v1 <- diag(V)[-k]
    v2 <- (diag(Vi)[-k] - Vi[k, -k]^2/Vi[k,k])
    nam <- nam[-k]
  } else {
    v1 <- diag(V)
    
    v2 <- diag(Vi)
    warning("No intercept term detected. Results may surprise.")
  }
  nam__mod <- nam[nam %in% colnames(V)]
  v3 <- v2[c(nam__mod)]
  structure(v1*v3, names = nam__mod)
}


vfit1 <- data.frame(vif(Reg1))
vfit1 <- cbind(Variables=row.names(vfit1),vfit1)
row.names(vfit1) <- NULL
names(vfit1)[2] <- "VIF"
vfit1 <- vfit1[order(-vfit1$VIF),]


while(vfit1[,2][1]>10)
{
  vars <- vfit1[,1]
  vars <- vars[-c(1)]
  formula <- paste(Dependednt_Variable,paste(vars,sep="",collapse="+"),sep="~")
  reg<- lm(formula,na.action=na.pass,data=test2_online)
  print(summary(reg))
  vfit1 <- data.frame(vif(reg))
  vfit1 <- cbind(Variables=row.names(vfit1),vfit1)
  row.names(vfit1) <- NULL
  names(vfit1)[2] <- "VIF"
  vfit1 <- vfit1[order(-vfit1$VIF),]
  print(vfit1)
}

#########Selecting variables post vif
colnames(model_col)
post_vif_data <- model_col[,-c(20,21,24,26,33)]
colnames(post_vif_data)
independent_variables <- post_vif_data[c(1:9,12:20,22:29,31,32)]  ######xp gained recently, first bucket success fraction, multi-versus matches & sec per fight story mode removed
Independent_Variables <- names(independent_variables)
model_equtn <- reformulate(Independent_Variables,Dependednt_Variable)


##################################################################################################
##Split into train and validation datasets
set.seed(101)
sample = sample.split(post_vif_data, SplitRatio =.80)
train = subset(post_vif_data, sample == TRUE)
test  = subset(post_vif_data, sample == FALSE)


## Decision Tree
test2_fact <- train
test2_fact$churn_flag_days <- as.factor(test2_fact$churn_flag_days )
tree1 <- ctree(model_equtn, data=test2_fact)

print(tree1)
pred_tree <- predict(tree1, test2_fact, type="response")
print("Confusion Matrix for Decision Tree"); table(Predicted = pred_tree, Actual = test2_fact$churn_flag_days)

p1 <- predict(tree1, test, type="response")
print("Confusion Matrix for Decision Tree"); table(Predicted = p1, Actual = test$churn_flag_days)


################################################################################################
## Random Forest

test2_fact <- train
test2_fact$churn_flag_days <- as.factor(test2_fact$churn_flag_days )
set.seed(2018)
for(i in 5:7)
{
  rfModel <- randomForest(model_equtn, data=test2_fact , ntree =2000 , mtry = 6)
  print(rfModel)
  fitted.results <- predict(rfModel  ,newdata= test2_fact   ,type='response')
  tab <- table(Predicted = fitted.results, Actual = test2_fact$churn_flag_days)
  validationresults <- predict(rfModel, test ,type='response')
  tab1 <- table(Predicted = validationresults, Actual = test$churn_flag_days)
  print(tab1)
  out_of_time_results <- predict(rfModel, out_of_time1 ,type='response')
  tab2 <- table(Predicted = out_of_time_results, Actual = out_of_time1$churn_flag_days)
  print(tab2)
}

rf <- foreach(ntree=rep(25000, 6), .combine=combine, .multicombine=TRUE, .packages='randomForest') %dopar% { randomForest(x, y, ntree=ntree) }



##################################################################################################################
###########XGBOOST
colnames(train)
x=train[,c(1:9,12:20,22:29,31,32)]

##########OUT OF SAMPLE VALIDATION
y=test[,c(1:9,12:20,22:29,31,32)]

#############Out Of Time Validation
out_of_time_players <- read.csv('C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/20190624/out of time AD.csv')
colnames(out_of_time_players)
oot= out_of_time_players[,-c(1,2,5,8,9,11,20,21,28,29,31,32,34,39,41,42,44)]
colnames(oot)
z=oot[,c(1:4,7:11,14,15,12,13,16,17:20,5,6,21:26,28,29)]

##########XGB Copied
dtrain <- xgb.DMatrix(data = data.matrix(x), label = train$churn_flag_days)
dval <- xgb.DMatrix(data = data.matrix(y), label = test$churn_flag_days)
dval1 <- xgb.DMatrix(data = data.matrix(z), label = oot$churn_flag_days)

watchlist <- list(train=dtrain, validation1=dval, validation2=dval1)

xgb2 <- xgb.train(data=dtrain,
                  max.depth=12,
                  eta=0.2,
                  nthread = 8,
                  objective = "binary:logistic",
                  nround=40,
                  subsample = 0.8,
                  colsample_bytree = 0.5,
                  eval.metric = "error",
                  watchlist=watchlist)

#get optimum threshold
p_tr <- predict(xgb2, data.matrix(x) , type="response")
p_val <- predict(xgb2, data.matrix(y) , type="response")
p_oot <- predict(xgb2, data.matrix(z) , type="response")

i = 0.3
df=NULL
while(i < 0.60 )
{
  train$response <- as.factor(ifelse(p_tr>i, 1, 0))
  confusion_matrix <-confusionMatrix(train$response , as.factor(train$churn_flag_days), positive = "1")
  results <- confusion_matrix
  results1 <- as.matrix(results, what = "classes")
  results2 <- as.matrix(results,what="overall")
  result_final <- data.frame(t(rbind(results1,results2)))
  result_final$Cutoff=i
  df <- rbind(result_final,df)
  i = i + 0.01
}
write.csv(df,file="C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/20190624/xgb Simulation Results_1.csv")


train$response <- as.factor(ifelse(p_tr>.45, 1, 0))
confusion_matrix <-confusionMatrix(train$response , as.factor(train$churn_flag_days), positive = "1")
results <- confusion_matrix


test$response <- as.factor(ifelse(p_val>.45, 1, 0))
confusion_matrix <-confusionMatrix(test$response , as.factor(test$churn_flag_days), positive = "1")
results <- confusion_matrix

oot$response <- as.factor(ifelse(p_oot>.45, 1, 0))
confusion_matrix <-confusionMatrix(oot$response , as.factor(oot$churn_flag_days), positive = "1")
results <- confusion_matrix


pred <- prediction(p_tr , train$churn_flag_days)
perf <- performance(pred, measure = "tpr", x.measure = "fpr")
plot(perf,print.cutoffs.at=seq(0,1,by=0.1), text.adj=c(-0.2,1.7))
perf <- performance(pred, "tpr", "fpr")
x1 = seq(-0.1,1.1,0.1)
y1 = seq(-0.1,1.1,0.1)
plot(perf,main = "ROC Curve for XGB",col = "blue", xlab= "1-Specificity", ylab= "Sensitivity")
lines(x1,y1,col='green')

auc <- performance(pred,"auc")@y.values[[1]]
auc




#view variable importance plot
mat <- xgb.importance (feature_names = colnames(dtrain),model = xgb2)
xgb.plot.importance (importance_matrix = mat[1:27]) 
mat$Gain

library(ROCR)
pred <- prediction(p, l)
perf <- performance(pred, "acc")
max(perf@y.values[[1]])
perf@x.values[[1]]

