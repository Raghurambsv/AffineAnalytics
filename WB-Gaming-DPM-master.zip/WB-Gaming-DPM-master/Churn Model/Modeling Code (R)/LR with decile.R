library(caTools)
library(OneR)
library(ROCR)

sampleplayers <- read.csv('C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/20190613/Model_iteration_AD.csv')
colnames(sampleplayers)

#####Correlation Table
df <- sampleplayers[,-c(1,2,44)]
a=cor(df,method=c("spearman"))
write.csv(a,'C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/20190613/churn_model_correlation.csv')
colnames(df)

######Modeling Variables
model_col <- sampleplayers[,-c(1,2,5,27,32,33,35,43,44)]   ######Removing avg match length recently, fraction wns recently, multi-versus matches recently bec. very less correlation with churn flag
colnames(model_col)

independent_variables <- model_col[c(1:22,24:35)]
Dependednt_Variable <- "churn_flag_days"
Independent_Variables <- names(independent_variables)
model_equtn <- reformulate(Independent_Variables,Dependednt_Variable)
model_equtn
Reg1<- lm(model_equtn,na.action=na.pass,data=model_col)
print(summary(Reg1))


#vif
vif <- function(object, ...)
  UseMethod("vif")
vif.lm <- function(object, ...) {
  V <- summary(object)$cov.unscaled
  Vi <- crossprod(model.matrix(object))
  nam <- names(coef(object))
  if(k <- match("(Intercept)", nam, nomatch = F)) {
    v1 <- diag(V)[-k]
    v2 <- (diag(Vi)[-k] - Vi[k, -k]^2/Vi[k,k])
    nam <- nam[-k]
  } else {
    v1 <- diag(V)
    
    v2 <- diag(Vi)
    warning("No intercept term detected. Results may surprise.")
  }
  nam__mod <- nam[nam %in% colnames(V)]
  v3 <- v2[c(nam__mod)]
  structure(v1*v3, names = nam__mod)
}


vfit1 <- data.frame(vif(Reg1))
vfit1 <- cbind(Variables=row.names(vfit1),vfit1)
row.names(vfit1) <- NULL
names(vfit1)[2] <- "VIF"
vfit1 <- vfit1[order(-vfit1$VIF),]

while(vfit1[,2][1]>10)
{
  vars <- vfit1[,1]
  vars <- vars[-c(1)]
  formula <- paste(Dependednt_Variable,paste(vars,sep="",collapse="+"),sep="~")
  reg<- lm(formula,na.action=na.pass,data=model_col)
  print(summary(reg))
  vfit1 <- data.frame(vif(reg))
  vfit1 <- cbind(Variables=row.names(vfit1),vfit1)
  row.names(vfit1) <- NULL
  names(vfit1)[2] <- "VIF"
  vfit1 <- vfit1[order(-vfit1$VIF),]
  print(vfit1)
}

#########Selecting variables post vif
colnames(model_col)
post_vif_data <- model_col[,-c(21,24,26,33)]
colnames(post_vif_data)
########krypt visits, fr. wins, ai fighter,third bucket success fr., online pvp other matches
independent_variables <- post_vif_data[c(1,5:6,13,16,19,26:30,32)]  ######xp gained recently, first bucket success fraction, multi-versus matches & sec per fight story mode removed
Independent_Variables <- names(independent_variables)
model_equtn <- reformulate(Independent_Variables,Dependednt_Variable)


#####Scaling
scaled_data<- data.frame(apply(post_vif_data,2, function(x) {(x - min(x))/(max(x)-min(x))}))

### Check the missing value in each coulmn
sapply(scaled_data,function(x) sum(is.na(x)))

##################################################################################################
##Split into train and validation datasets
set.seed(101)
sample = sample.split(post_data, SplitRatio =.80)
train = subset(scaled_data, sample == TRUE)
test  = subset(scaled_data, sample == FALSE)


## Logistic Reg

LogReg1 <- glm(model_equtn,  , family = binomial, data = train)
print(summary(LogReg1))
colnames(train)
#LogReg2<-LogReg1[order(LogReg1$coefficients)]
saveRDS(LogReg1, "C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/LogisticRegressionmodel_20190626.rds")
a=summary(LogReg1)

write.csv(a$coefficients,file="C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 churn model/LR coefficients_26062019.csv")


## Confusion Matrix 
train$pred_prob <- NULL
train$pred_prob <- predict(LogReg1  ,newdata= train   ,type='response')
library(caret)
i = 0.3
df=NULL
while(i < 0.70 )
{
  train$response <- as.factor(ifelse(train$pred_prob>i, 1, 0))
  confusion_matrix <-confusionMatrix(train$response , as.factor(train$churn_flag_days), positive = "1")
  results <- confusion_matrix
  results1 <- as.matrix(results, what = "classes")
  results2 <- as.matrix(results,what="overall")
  result_final <- data.frame(t(rbind(results1,results2)))
  result_final$Cutoff=i
  df <- rbind(result_final,df)
  i = i + 0.01
}

write.csv(df,file="C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/20190626/LR Simulation Results_26062019.csv")


## Confusion Matrix 

train$response <- as.factor(ifelse(train$pred_prob>.40, 1, 0))
confusion_matrix <-confusionMatrix(train$response , as.factor(train$churn_flag_days), positive = "1")
results <- confusion_matrix

## ROC Curve

fitted.results <- predict(LogReg1  ,newdata= scaled_data   ,type='response')
pred <- prediction(train$pred_prob, train$churn_flag_days)
perf <- performance(pred, "tpr", "fpr")
x = seq(-0.1,1.1,0.1)
y = seq(-0.1,1.1,0.1)
plot(perf,main = "ROC Curve for Logistic Regression",col = "blue", xlab= "1-Specificity", ylab= "Sensitivity")
lines(x,y,col='green')


AUC <- performance(pred, "auc")@y.values[[1]]
AUC


######Load the trained model
LogReg1=readRDS("C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/LogisticRegressionmodel_20190624.rds")
a=summary(LogReg)

## Confusion Matrix 
test$pred_prob <- NULL
test$pred_prob <- predict(LogReg1  ,newdata= test   ,type='response')

test$response <- as.factor(ifelse(test$pred_prob>.40, 1, 0))
confusion_matrix <-confusionMatrix(test$response , as.factor(test$churn_flag_days), positive = "1")
results <- confusion_matrix

#######OUT OF TIME
oot <- read.csv("C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/20190624/out of time AD.csv")
colnames(oot)

val <- oot[,c(3,13,14,23,24,27,35,36,37,38,40,43,45)]
val1 <- val
val <- data.frame(apply(val,2, function(x) {(x - min(x))/(max(x)-min(x))}))
## Confusion Matrix 
val$pred_prob <- NULL
val$pred_prob <- predict(LogReg1  ,newdata= val   ,type='response')

val$response <- as.factor(ifelse(val$pred_prob>.40, 1, 0))
confusion_matrix <-confusionMatrix(val$response , as.factor(val$churn_flag_days), positive = "1")
results <- confusion_matrix

###########DECILE PLOT
ordered <- train[order(-train$pred_prob),]
n <- 10
nr <- nrow(ordered)
ordered$decile <- rep(1:10, each = ceiling(nr/n), length.out=nr)
colnames(ordered)
write.csv(ordered[,c(35,34,22,36)],file="C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/20190626/Train DataSet Results.csv")
write.csv(ordered[,c(35,34,22,1)],file="C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/20190626/Train DataSet Results players.csv")


ordered_test <- test[order(-test$pred_prob),]
n <- 10
nr <- nrow(ordered_test)
ordered_test$decile <- rep(1:10, each = ceiling(nr/n), length.out=nr)
colnames(ordered_test)
write.csv(ordered_test[,c(35,34,22,36)],file="C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/20190626/Test DataSet Results.csv")

ordered_val <- val[order(-val$pred_prob),]
n <- 10
nr <- nrow(ordered_val)
ordered_val$decile <- rep(1:10, each = ceiling(nr/n), length.out=nr)
colnames(ordered_val)
write.csv(ordered_val[,c(15,14,12,16)],file="C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/20190626/OutOfTime DataSet Results.csv")

val1 <- oot[,c(3,13,14,23,24,27,35,36,37,38,40,43,45)]
val2 <- cbind(val1,val[,c(15,14,12)])
colnames(val2)
write.csv(val2[,c(15,14,12,1)],file="C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/20190626/OutOfTime DataSet Results_new.csv")
scaled_train$response
t <- cbind(train1,scaled_train$response)
colnames(t)
write.csv(t[,c(34,22,1)],file="C:/Users/prateek/Desktop/WB/WB POST DEVELOPMENT CHURN MODEL/Churn Model/MK11 Churn Model/20190626/Train DataSet Results unscaled players.csv")
