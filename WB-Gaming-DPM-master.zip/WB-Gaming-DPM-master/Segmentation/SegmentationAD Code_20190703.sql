---- General Table----

with initial_players as (
select player_id, join_date
from
(
	select player_id, min(event_dt) join_date
	from seven11_prod_da.wba_player_daily
	where event_dt between '2019-04-22' and '2019-05-05'
	group by 1
)
group by 1,2
),

players as (
select player_id, join_date,dateadd(day,3,join_date) day_3,dateadd(day,7,join_date) day_7,dateadd(day,15,join_date) day_15
from
(
	select player_id, min(event_dt) join_date
	from seven11_prod_da.wba_player_daily
	where event_dt between '2019-05-06' and '2019-06-15' 
	and player_id not in (select player_id from initial_players)
	group by 1
)
group by 1,2
)

--------------
select * into sandbox.new_segmentationAD_20190703
from
(
select *,row_number()over (order by player_id) as row_num
from
(
select a.player_id, a.join_date, story, Online_PvP, Towers_of_Time, Tutorial_Ladder,krypt
            , offline_modes, other_activities
			, COALESCE(e.timeplayed_3days / NULLIF(d.timeplayed,0), 0) first_3days_fraction,coalesce (f.timeplayed_7days/NULLIF(d.timeplayed,0),0) first_7days_fraction
			, coalesce (max_reached,0)  Story_completers
			, coalesce (LTD,0) vc_revenue
			, cat, d.timeplayed
			, g.shaokahn_entitlement,(g.kombat_pack_premium_digital+g.physical_premium) kombat_pack_ownership
from	
	(
		select player_id, join_date,tot, sum(case when activity_name in ('GM_STORY_OFF') then coalesce (timeplayed::float/NULLIF(tot::float,0), 0) else 0 end) story
											 , sum(case when activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1') then coalesce (timeplayed::float/NULLIF(tot::float,0), 0) else 0 end ) Online_PvP
											 , sum(case when activity_name in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE') then coalesce (timeplayed::float/NULLIF(tot::float,0), 0) else 0 end) Towers_of_Time
											 , sum(case when activity_name in ('GM_FATALITY_TUTORIAL','GM_TUTORIAL_OFFLINE','GM_PRACTICE') then coalesce (timeplayed::float/NULLIF(tot::float,0), 0) else 0 end) Tutorial_Ladder
											 , sum(case when activity_name in ('GM_KRYPT') then coalesce (timeplayed::float/NULLIF(tot::float,0), 0) else 0 end) krypt
											 , sum(case when activity_name in ('GM_LOCAL_VERSUS_OFF','GM_MULTI_VERSUS_OFF','GM_MULTI_TOURNAMENT_OFF','GM_AI_FIGHTER') then coalesce (timeplayed::float/NULLIF(tot::float,0), 0) else 0 end) offline_modes
											 , sum(case when activity_name in ('GM_CAP_CUSTOMIZATION','GM_GROUP_BATTLES','GM_KOLLECTION','GM_LADDER_OFF','GM_PLAYER_MATCH_ON_HOT_SEAT','GM_PLAYER_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_PRACTICE') then coalesce (timeplayed::float/NULLIF(tot::float,0), 0) else 0 end) other_activities											 
		from
		(
			select a.player_id , join_date, activity_name, sum(activity_hours) timeplayed, sum(timeplayed) over (partition by a.player_id) tot
			from seven11_prod_da.wba_fact_activity a
			join players c
			on a.player_id = c.player_id
			where DATE(event_dt) between c.join_date and c.day_15 and activity_name not in ('GM_KLASSIC_PORTAL_MODE_LADDER','GM_TOWERS_OF_TIME_LADDER','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_KOMBAT_KARD','GM_MATCH_REPLAY','GM_ONLINE_HUB','GM_STORE')
			group by 1,2,3
		)
		group by 1,2,3
	) a
	left join 
	(
		select _platform_account_id, ceiling (max(fight_number)::float/2)*2 max_reached
		from seven11_prod.seven11_progression_campaignprogress a
		join players b
		on a._platform_account_id = b.player_id
		where player_win = TRUE
		and date(_event_time_utc) between b.join_date and b.day_15
		group by 1
	) b
	on a.player_id=b._platform_account_id
	left join
	(
		select a._platform_account_id, sum(change_amount)*.008 LTD
		from seven11_prod.seven11_resource_flow a
		join players c
		on a._platform_account_id = c.player_id
		where resource = 'Exp_PremiumCurrency' and source = 'ENTITLEMENT'
		and date(_event_time_utc) between c.join_date and c.day_15
		group by 1
	)c
	on a.player_id=c._platform_account_id 
	left join
	(		
			select player_id,tot::float/ total_sum ::float cat,timeplayed
			from
		(							
			select  a.player_id, sum(activity_hours) timeplayed, sum(timeplayed) over(order by timeplayed asc rows unbounded preceding) tot, sum(timeplayed) over () total_sum
			from seven11_prod_da.wba_fact_activity a
			join players c
			on a.player_id = c.player_id
			where DATE(event_dt) between c.join_date and c.day_15 and activity_name not in ('GM_KLASSIC_PORTAL_MODE_LADDER','GM_TOWERS_OF_TIME_LADDER','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_KOMBAT_KARD','GM_MATCH_REPLAY','GM_ONLINE_HUB','GM_STORE')
			group by 1 
		)
	) d
	using(player_id)
	left join
	(		
			select a.player_id, sum(activity_hours)*1.0 timeplayed_3days
			from seven11_prod_da.wba_fact_activity a
			join players c
			on a.player_id = c.player_id
			where DATE(event_dt) between c.join_date and c.day_3 and activity_name not in ('GM_KLASSIC_PORTAL_MODE_LADDER','GM_TOWERS_OF_TIME_LADDER','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_KOMBAT_KARD','GM_MATCH_REPLAY','GM_ONLINE_HUB','GM_STORE')
			group by 1 
	) e
	using(player_id)
	left join
	(		
								
			select a.player_id, sum(activity_hours)*1.0 timeplayed_7days
			from seven11_prod_da.wba_fact_activity a
			join players c
			on a.player_id = c.player_id
			where DATE(event_dt) between c.join_date and c.day_7 and activity_name not in ('GM_KLASSIC_PORTAL_MODE_LADDER','GM_TOWERS_OF_TIME_LADDER','GM_MAINMENU','GM_MAINMENU_OPTIONS','GM_AI_FIGHTER_HUB','GM_CHAT_LOBBY','GM_KOMBAT_KARD','GM_MATCH_REPLAY','GM_ONLINE_HUB','GM_STORE')
			group by 1 
	) f
	using(player_id)
	left join
	(
		select a._platform_account_id,
				max(case when entitlement_name in ('shao_kahn') then 1 else 0 end) shaokahn_entitlement,
				max(case when entitlement_name in ('kombat_pack','digital_premium_edition') then 1 else 0 end) kombat_pack_premium_digital,
				max(case when entitlement_name in ('physical_premium_edition') then 1 else 0 end) physical_premium
		from seven11_prod.seven11_dlc_entitlement a
		join players c
		on a._platform_account_id = c.player_id
		where date(_event_time_utc) between c.join_date and c.day_15
		group by 1
	) g
	on a.player_id = g._platform_account_id
)
)
--where a.player_id in('2533274800814711','2535417779400143')
	---where a._platform_account_id = '1010419900541856420'