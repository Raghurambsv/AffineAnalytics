 with datedim as ( select event_dt YearMonthDay from seven11_prod_da.wba_fact_activity group by 1)

select weeknum, segment_name, count(player_id) cohorts, sum(retainers) retained
from
	(
            select weeknum, b.player_id, a.segment_name, case when count(c.player_id) >0 then 1 else 0 end retainers--*--period, RetentionDate, newdate, count(c.player_id) retained_players, count(b.player_id) cohorts
            from
            (  select *
			   from
			   (
              SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate, ceiling(period::float/7) weeknum
                FROM datedim d
                JOIN datedim  d2 ON d.YearMonthDay < d2.YearMonthDay
                WHERE  (d.YearMonthDay>='2019-04-22' and d.YearMonthDay < CAST(getdate() as DATE))
                AND (d2.YearMonthDay>='2019-04-22' and  d2.YearMonthDay < CAST(getdate() as DATE))
				)
				cross join (select segment_name from shared_ga_mk11_segments_final group by 1 )
			) A
            join
            (

              select player_id, segment_name, min(event_dt) yearmonthday
              from seven11_prod_da.wba_player_daily a
			  join (select player_id, segment_name from shared_ga_mk11_segments_final group by 1,2) b
			  using(player_id)
			  where event_dt >= '2019-04-22'
			  ---and player_id = '1185784859539717906'
              group by 1,2
			 -- having min(event_dt) = '2019-05-03 00:00:00'
			  --limit 100


            )  B
            on a.NewDate = b.yearmonthday
			and a.segment_name = b.segment_name
            left join
            (

              select event_dt yearmonthday, player_id
              from seven11_prod_da.wba_player_daily a
              group by 1,2

            ) C
            on b.player_id = c.player_id
            and c.yearmonthday = a.retentiondate
            where b.yearmonthday >= '2019-04-22'
            group by 1,2,3
	)
group by 1,2
		  
		  
	