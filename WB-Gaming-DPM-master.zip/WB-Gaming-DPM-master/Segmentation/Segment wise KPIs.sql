---- final table creation-----
create table shared_ga_mk11_segments_final as
select player_id, b.segment,case when b.segment = 1 then 'Dabblers'
								 when b.segment = 2 then 'Connoisseurs'
								 when b.segment = 3 then 'Tower Players'
								 when b.segment = 4 then 'Casual Players'
								 when b.segment = 5 then 'Local AI Players'
								 when b.segment = 6 then 'Campaigners'
								 when b.segment = 7 then 'Online Players' end as segment_name 
, join_date, couch_1v1, story, online_pvp, towers_of_time, tutorial_ladder, krypt
, local_versus,multi_tournament_offline, local_ai,  other_activities, first_3days_fraction, first_7days_fraction, story_completers, payers vc_revenue
, cat playtime_percentile, timeplayed, shaokahn_entitlement, kombat_pack_premium_digital, physical_premium
,a.row_num
from sandbox.segmentation_player_segments_20190604 a
join sandbox.fina_segments_rg b
using (row_num)
--- players in each segment--------

select segment_name, segment, count(player_id), count(row_num)
from shared_ga_mk11_segments_final
group by 1,2
order by 1

--- Engagement ----

---LTD---

select segment_name,sum(hrs)/count(distinct player_id) avghours, sum(hrs)/sum(sessions) sessionlength , sum(sessions)*1.0/count(distinct player_id) avgsessions, count(dt)*1.0/count(distinct player_id)  daysplayed
from(
	select a.player_id, event_dt dt , segment_name, Sum(total_hours) hrs, sum(session_count) sessions, avg(session_count) avgsess
	from seven11_prod_da.wba_player_daily a
	join shared_ga_mk11_segments_final
	using(player_id)
	where event_dt >= '2019-04-22' --and event_dt <= '2019-04-29' 
	and total_hours > 0
	group by 1,2,3
) a
group by 1
order by 1

-------hrs per player per day & sessions per player per day------
select segment_name, sum(hours_per_day)/count(player_id) hrs_per_player_per_day, sum(sessions_per_day)/count(player_id) sessions_per_player_per_day
from
(
select segment_name, player_id, sum(hrs)/count(distinct dt) hours_per_day , sum(sessions)*1.0/count(distinct dt) sessions_per_day
from(
	select a.player_id, event_dt dt , segment_name, Sum(total_hours) hrs, sum(session_count) sessions, avg(session_count) avgsess
	from seven11_prod_da.wba_player_daily a
	join shared_ga_mk11_segments_final
	using(player_id)
	where event_dt >= '2019-04-22' --and event_dt <= '2019-04-29' 
	and total_hours > 0
	group by 1,2,3
)
group by 1,2
order by 1,2
)
group by 1
order by 1

----- Daily Actives

select segment_name, date, count(a.player_id) players
from 
(
select player_id, date(event_dt) date
from seven11_prod_da.wba_player_daily
where event_dt >='2019-04-22'
group by 1,2
) a
join shared_ga_mk11_segments_final b
using(player_id)
group by 1,2
order by 1,2

------


------Players Played Campaign Mode 
select segment_name, count(distinct _platform_account_id) players_played_campaign  
from seven11_prod.seven11_progression_campaignprogress a
join shared_ga_mk11_segments_final b
on a._platform_account_id = b.player_id
where date(_event_time_utc)>= '2019-04-22'
group by 1
order by 1

------Players Completed Campaign Mode 

select segment_name, sum(story_completed) as no_of_players_completed_story
from
(
select _platform_account_id, segment_name, max(fight_number) max_reached
		,case when max_reached = 50 then 1 else 0 end story_completed
from seven11_prod.seven11_progression_campaignprogress a
join shared_ga_mk11_segments_final b
on a._platform_account_id = b.player_id
where player_win = TRUE and date(_event_time_utc)>= '2019-04-22'
group by 1,2
)
group by 1
order by 1



-----Online PvP
select segment_name, count(distinct player_id) players_played_online_pvp, sum(activity_hours) total_hours_played
from seven11_prod_da.wba_fact_activity a
join shared_ga_mk11_segments_final b
using(player_id)
where date(event_dt)>= '2019-04-22' and activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1')
group by 1
order by 1

----Towers of Time
select segment_name, count(distinct player_id) players_played_towers_of_time, sum(activity_hours) total_hours_played
from seven11_prod_da.wba_fact_activity a
join shared_ga_mk11_segments_final b
using(player_id)
where date(event_dt)>= '2019-04-22' and activity_name in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE')
group by 1
order by 1

-----CAP Customization
select segment_name, count(distinct player_id) players_engaged_cap_customization, sum(activity_hours) total_hours_played
from seven11_prod_da.wba_fact_activity a
join shared_ga_mk11_segments_final b
using(player_id)
where date(event_dt)>= '2019-04-22' and activity_name in ('GM_CAP_CUSTOMIZATION')
group by 1
order by 1
select count(*)
from shared_ga_mk11_segments_final

----

--------no of players in each game mode
with temp_table as (
select player_id, Segmentation_Activity
from
(select player_id, activity_name,
	case when activity_name in ('GM_STORY_OFF') then 'story'
         when activity_name in ('GM_PLAYER_MATCH_ON_1V1','GM_PRIVATE_MATCH_ON_1V1','GM_RANKED_ON_1V1') then 'Online_PvP'
         when activity_name in ('GM_TOWERS_OF_TIME','GM_KLASSIC_PORTAL_MODE') then 'Towers_of_Time'
         when activity_name in ('GM_FATALITY_TUTORIAL','GM_TUTORIAL_OFFLINE','GM_PRACTICE') then 'Tutorial_Ladder'
         when activity_name in ('GM_KRYPT') then 'krypt'
         when activity_name in ('GM_LOCAL_VERSUS_OFF') then 'local_versus'
         when activity_name in ('GM_AI_FIGHTER','GM_MULTI_TOURNAMENT_OFF','GM_MULTI_VERSUS_OFF') then 'offline_modes'
         when activity_name in ('GM_CAP_CUSTOMIZATION','GM_GROUP_BATTLES','GM_KOLLECTION','GM_LADDER_OFF','GM_PLAYER_MATCH_ON_HOT_SEAT','GM_PLAYER_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_HOTSEAT','GM_PRIVATE_MATCH_ON_KOTH','GM_PRIVATE_MATCH_ON_PRACTICE') then 'other_activities'
         else '0' end as Segmentation_Activity
from seven11_prod_da.wba_fact_activity)
where Segmentation_Activity <> 0
group by 1,2
)  
select segment_name, Segmentation_Activity, count(distinct(player_id))
from temp_table
join shared_ga_mk11_segments_final
using(player_id)
group by 1,2
order by 1

---- Profile Level---------

select segment_name, case when pl <= 10 then '1-10 level'
			when pl >10 and pl <= 20 then '11-20 level'
			when pl >20 and pl <= 30 then '21-30 level'
			when pl >30 then '+30 level' end profile_level, sum(perc) perc
from
(
	select pl, segment_name, count(_platform_account_id) players, sum(players) over (partition by segment_name) tot, count(_platform_account_id)::float /  sum(players) over (partition by segment_name)::float perc
	from
	(
		SELECT _platform_account_id, segment_name, max(profile_level) pl
		FROM seven11_prod.seven11_match_result_player a
		join shared_ga_mk11_segments_final b
		on a._platform_account_id = b.player_id
		where DATE(_event_time_utc) >= '2019-04-22' -- and '2019-04-29' 
		group by 1,2
	)
	group by 1,2
)
group by 1,2
order by 1

---- Retention---------

with retention as (


            select period, a.segment_name, RetentionDate, newdate, count(c.player_id) retained_players, count(b.player_id) cohorts
            from
		     (		
			 		select *
					from
					(
		              SELECT d.YearMonthDay NewDate, datediff(DAY, d.YearMonthDay, d2.YearMonthDay) period, d2.YearMonthDay RetentionDate
		                FROM ( select event_dt YearMonthDay from seven11_prod_da.wba_fact_activity group by 1) d
		                JOIN ( select event_dt YearMonthDay from seven11_prod_da.wba_fact_activity group by 1)  d2 ON d.YearMonthDay < d2.YearMonthDay
		                WHERE  (d.YearMonthDay>='2019-04-22' and d.YearMonthDay < CAST(getdate() as DATE))
		                AND (d2.YearMonthDay>='2019-04-22' and  d2.YearMonthDay < CAST(getdate() as DATE))
					)
						cross join (select segment_name from shared_ga_mk11_segments_final group by 1 )
            ) A
            join
            (

              select a.player_id,segment_name, min(event_dt) yearmonthday
              from seven11_prod_da.wba_player_daily a
			  join (select player_id, segment_name from shared_ga_mk11_segments_final group by 1,2) b
			  using(player_id)
			  where event_dt >= '2019-04-22'
              group by 1,2

            )  B
            on a.NewDate = b.yearmonthday
			and a.segment_name = b.segment_name
            left join
            (

              select event_dt yearmonthday, player_id
              from seven11_prod_da.wba_player_daily a
              group by 1,2

            ) C
            on b.player_id = c.player_id
            and c.yearmonthday = a.retentiondate
            where b.yearmonthday >= '2019-04-22'
            group by 1,2,3,4
          order by 3,2 desc
)

		  
		  select period,segment_name, sum(retained_players::float) / sum(cohorts::float)
		  from retention
		  group by 1,2
		  