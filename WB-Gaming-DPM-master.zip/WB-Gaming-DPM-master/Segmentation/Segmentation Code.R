library(cluster)
library(fpc)
library(factoextra)

setwd('C:/Users/prateek/Desktop/WB/Segmentation related data/MK11 Segmentation/20190703')

y=read.csv('SegmentationAD.csv')

###########Taking req'd columns
colnames(y)
y1 <- y[,-c(1,2,14)]

##########Pre Processing the dataset
Pre_Processing <- function(y){

  ########Remove anomalous entries
  y$total = y$story+y$online_pvp+y$towers_of_time+y$tutorial_ladder+y$krypt+
    y$offline_modes+y$other_activities
  y <- y[y$total!=0,]
  
  #########Remove any negative rows from the dataset
  neg.rows <- apply(y, 1, function(row) any(row< 0)) 
  y <- y[!neg.rows,]
  
  ######Kombat Pack Ownership Variable setting
  y$kombat_pack_ownership <- ifelse(y$kombat_pack_ownership == 2,1,y$kombat_pack_ownership)
  return(y)
}

df <- Pre_Processing(y1)

###########Taking columns to give to the model
colnames(df)
data <- df[,-c(15,16)]

###########Scaling the data
scaled_data=scale(data)

#K-MEANS
set.seed(50)
kmm = kmeans(scaled_data,6,nstart = 50,iter.max = 1000)
kmm$tot.withinss             ######WCSS or Intracluster Distance
kmm$betweenss                ######Intercluster Distance

#########Getting the Profiling Sheet

Get_Profiling_Sheet <- function(p){
  ##Getting global averages of all the variables  
  Global_Average <- function(x){
    q=colMeans(x)
    q=data.frame(q)
    names(q)[names(q) == 'q'] <- 'Global Average'
    return(q)
  }

  Global <- Global_Average(data) 

  # get cluster means
  Cluster_Averages <- function(x){
    cluster_means_1 <- aggregate(x,by=list(kmm$cluster),FUN=mean)
    cluster_means_1_t <- t(cluster_means_1)
    cluster_averages <- data.frame(cluster_means_1_t)
    cluster_averages <- cluster_averages[-c(1),]
    colnames(cluster_averages) <- c("Cluster 1", "Cluster 2", "Cluster 3", "Cluster 4", 
                                "Cluster 5","Cluster 6")##, "Cluster 7")
    return(cluster_averages)
  }

  Cluster_Wise <- Cluster_Averages(data)

  #####Combining Global Average with the Cluster Average
  w=cbind(Cluster_Wise,Global)

  ########Players in each Cluster
  Cluster_Players <- function(x){
    cluster_players <- aggregate(x,by=list(kmm$cluster),FUN=length)  
    cluster_players <- cluster_players[,c(1,2)]
    colnames(cluster_players) <- c("Clusters", "Total_Players")
    cluster_players_t <- t(cluster_players)
    cluster_players_t <- data.frame(cluster_players_t)
    cluster_players_t <- cluster_players_t[c(2),]
    cluster_players_t$Total_Players <- sum(cluster_players_t)
    colnames(cluster_players_t) <- c("Cluster 1", "Cluster 2", "Cluster 3", "Cluster 4", 
                                "Cluster 5","Cluster 6",  "Global Average")
    return(cluster_players_t)
  }

  Players <- Cluster_Players(data)

  #######Combining averages with no of players
  e = rbind(w,Players)
  return(e)
}

Profiling_Sheet <- Get_Profiling_Sheet(data)

write.csv(Profiling_Sheet[,c(7,1:6)],"profiling_sheet_19062019.csv")

##Writing players of each segment in csv
df$segments <- (kmm$cluster)
for(i in 1:max(kmm$cluster)){
  a = kmm$cluster == i
  z = df[a, ]
  z$ids_to_write_in_sql <- paste("(",z$row_num,",",z$segments,")",",")
  write.csv(z[,c(15,17,18)], file = paste("cluster_no",i,".csv", sep = ""),row.names = FALSE)
}  

