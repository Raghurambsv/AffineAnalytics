
library(leaps)
library(car)
library(RColorBrewer)
library(dummies)
library(rattle)
library(rpart)
library(rpart.plot)
library(lm.beta)
library(data.table)


combi_data = fread("E:/WB_project/daily_tasks/10052019/imputed_data_4_updated.csv")
combi_data = combi_data[!Movie_Title %in% c("Head Full of Honey"),]
combi_data$revenue_by_budget_log <- log(combi_data$BO_Revenue/combi_data$Budget_org)
combi_data$spend_by_budget <-  combi_data$BO_Media_Spend_org/combi_data$Budget_org
combi_data$spend_ratio <-  combi_data$non_digital_spend/combi_data$digital_spend
combi_data$digital_by_budget_log <-  log(combi_data$digital_spend/combi_data$Budget_org)
combi_data$non_digital_by_budget_log <-  log(combi_data$non_digital_spend/combi_data$Budget_org)
combi_data$opening_weekend_bo_log <- log(combi_data$opening_weekend_bo/combi_data$Budget_org)

#combi_data <- combi_data[combi_data$RatedExcellent_3!=0,]
#train_data <- combi_data[(combi_data$Theatrical_Release_Year<=2017)&((combi_data$Theatrical_Release_Year>=2015)),]

train_data <- combi_data[(Theatrical_Release_Year<=2017)&(Theatrical_Release_Year>=2015),]

test_data <-  combi_data[(Theatrical_Release_Year==2018),]


fun <- function(x, lower=TRUE, upper=TRUE){
  
  if((lower=TRUE)&(upper=TRUE)){
    quantiles <- quantile( x, c(.05, .95) )
    x[ x < quantiles[1] ] <- quantiles[1]
    x[ x > quantiles[2] ] <- quantiles[2]
    x
  }
  else if((lower=FALSE)&(upper=TRUE)){
    quantiles <- quantile( x, c(0.95) )
    x[ x > quantiles[1] ] <- quantiles[1]
    x
  }
  else if(((lower=TRUE)&(upper=FALSE))){
    quantiles <- quantile( x, c(0.05) )
    x[ x < quantiles[1] ] <- quantiles[1]
    x
    
  }
  
}
train_data$likes_by_views = fun(train_data$likes_by_views, lower=F)
train_data$digital_by_budget_log = fun(train_data$digital_by_budget_log, lower=F)
train_data$non_digital_by_budget_log = fun(train_data$non_digital_by_budget_log, lower=F)
train_data$revenue_by_budget_log <- fun(train_data$revenue_by_budget_log)
train_data$cast_overall_avg_rating <- fun(train_data$cast_overall_avg_rating)
train_data$BO_Window <- fun(train_data$BO_Window_org, lower=F)
train_data$opening_weekend_run <- fun(train_data$opening_weekend_run, upper=FALSE)
train_data$spend_by_budget <- fun(train_data$spend_by_budget, lower=F)
train_data$opening_weekend_by_budget <- fun(train_data$opening_weekend_by_budget, lower=F)
train_data$opening_weekend_bo_log <- fun(train_data$opening_weekend_bo_log)
#train_data$RatedExcellent_2 <- fun(train_data$RatedExcellent_2, lower=F)
write.csv(train_data, "E:/WB_project/daily_tasks/10052019/train_data_2.csv", row.names = F, na = "")
write.csv(test_data, "E:/WB_project/daily_tasks/10052019/test_data_2.csv", row.names = F, na = "")

lm_model <-  lm((log(revenue_by_budget))~scale(log(digital_by_budget))+scale(log(non_digital_by_budget))+scale(BO_Window)+scale(cast_overall_avg_rating)+franchise_flag+scale(likes_by_views)+Horror+Comedy, data = train_data)
lm_model <-  lm(revenue_by_budget_log~+non_digital_by_budget_log+(BO_Window)+(cast_overall_avg_rating)+franchise_flag+opening_weekend_bo_log, data = train_data)
summary(lm_model)


spend_model <- lm(digital_spend~Budget_org+Genre+franchise_flag, data=combi_data)
summary(spend_model)

lm.beta(lm_model)
vif(lm_model)
residualPlots(lm_model)




train_results = cbind(train_data[c("IMDB_Title_Code", "Movie_Title", "BO_Window_org", "franchise_flag", "likes_by_views", "Budget_org","cast_overall_avg_rating","digital_by_budget", "non_digital_by_budget", "BO_Media_Spend_org", "BO_Revenue", "Horror", "Comedy")], lm_model$fitted.values)
train_results$mape <- abs(train_results$BO_Revenue-exp(train_results$`lm_model$fitted.values`)*train_results$Budget_org)/train_results$BO_Revenue
train_results$predicted <- exp(train_results$`lm_model$fitted.values`)*train_results$Budget_org
test_results = cbind(test_data[c("IMDB_Title_Code", "Movie_Title", "BO_Window_org", "franchise_flag", "likes_by_views", "Budget_org","cast_overall_avg_rating","digital_by_budget", "non_digital_by_budget", "BO_Media_Spend_org", "BO_Revenue", "Horror", "Comedy")], predict(lm_model, test_data, interval="prediction"))
test_results$predicted <- exp(predict(lm_model, test_data))*test_results$Budget_org
test_results$lwr <- exp(test_results$lwr)*test_results$Budget_org
test_results$upr <- exp(test_results$upr)*test_results$Budget_org
test_results$mape <- abs(test_results$predicted-test_results$BO_Revenue)/test_results$BO_Revenue
write.csv(train_data, "E:/WB_project/daily_tasks/17052019/train_results_temp.csv", row.names = F, na = "")
write.csv(test_results, "E:/WB_project/daily_tasks/10052019/test_results_temp.csv", row.names = F, na = "")




#tree = rpart(log(revenue_by_budget)~log(digital_by_budget)+log(non_digital_by_budget)+BO_Window+I(BO_Window^2)+franchise_flag+likes_by_views+Actor_avg_rating+MPAA_rating, data = train_data, control=rpart.control(maxdepth=4, minsplit = 5))
#fancyRpartPlot(tree)
#summary(tree)


error_metrics <- function(y_true, y_pred){
  mae <- mean(abs(y_true-y_pred))
  mape <- mean(abs(y_true-y_pred)/y_true)
  wmape <- sum(abs(y_true-y_pred))/sum(as.numeric(y_true))
  return(c(mae, mape, wmape))
}

train_metrics <- error_metrics(train_data$BO_Revenue, exp(lm_model$fitted.values)*(train_data$Budget_org))

test_metrics <- error_metrics(test_data$BO_Revenue, exp(predict(lm_model, test_data))*(test_data$Budget_org))
train_metrics
test_metrics








