
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 11 12:35:29 2019

@author: amit
"""
import pandas as pd
import statsmodels.api as sm
from sklearn.metrics import r2_score
import numpy as np
from BaselineIteration import BaselineIteration




class SubsetIteration(BaselineIteration):
    """
    Child class of the BaseIteration class to run linear regression on only the
    required set of variables

    Parameters
    ----------
    x_train: Pandas Dataframe
        The train dataframe with only independent variables along with Title Code and Movie Name
    y_train: Pandas Series
        The train series with only dependent variable
    x_test: Pandas Dataframe
        The validation dataframe with only independent variables along with Title Code and Movie Name
    y_test: Pandas Series
        The validation series with only dependent variable
    Print: Bool
        Whether to print the results on hardrive
    subset_list: List of independent variables
        List of independent variables on which the regression has to be run.
    """
    def __init__(self, x_train, y_train, x_test, y_test, subset_list, Print):
        self.subset_list = subset_list
        super().__init__(x_train, y_train, x_test, y_test, Print)

    def run_iteration(self):
        results_df = pd.DataFrame()
        train_title_list = self.x_train[['IMDB_Title_Code', 'Movie_Title']]
        train_title_list.reset_index(drop=True, inplace=True)
        test_title_list = self.x_test[['IMDB_Title_Code', 'Movie_Title']]
        test_title_list.reset_index(drop=True, inplace=True)
        self.x_test.drop(['IMDB_Title_Code', 'Movie_Title'], inplace=True, axis=1)
        self.x_train.drop(['IMDB_Title_Code', 'Movie_Title'], inplace=True, axis=1)

        x_train_subset = pd.get_dummies(self.x_train[self.subset_list], drop_first=True)
        x_test_subset = pd.get_dummies(self.x_test[self.subset_list], drop_first=True)

        # Running the Ordinary Least Squares Iteration.Fitting on
        # the train data
        x_train_subset = sm.add_constant(x_train_subset)
        x_test_subset = sm.add_constant(x_test_subset)
        ols_object = sm.OLS(self.y_train, x_train_subset)
        model = ols_object.fit()

        # Making predictions on the validation data
        predictions = ols_object.predict(
                params=model.params, exog=x_test_subset)

        # Outputting the train, test predictions into csv if print is True
        if self.Print:
            train_features = pd.DataFrame(x_train_subset.copy())
            train_actuals = pd.DataFrame(self.y_train.copy())
            train_features.reset_index(inplace=True, drop=True)
            train_actuals.reset_index(inplace=True, drop=True)
            train_predictions = pd.DataFrame(
                    {'Predictions': model.fittedvalues.values})
            train_results = pd.concat(
                    [train_title_list, train_features, train_predictions, train_actuals], axis=1)
            train_results.to_csv(
                    str('train_results_subset')+str('.csv'), index=False)
            test_features = pd.DataFrame(x_test_subset.copy())
            test_actuals = pd.DataFrame(self.y_test.copy())
            test_features.reset_index(inplace=True, drop=True)
            test_actuals.reset_index(inplace=True, drop=True)
            test_predictions = pd.DataFrame(
                    {'Predictions': predictions})
            test_results = pd.concat(
                    [test_title_list, test_features, test_predictions, test_actuals], axis=1)
            test_results.to_csv(
                    str('test_results_subset')+str('.csv'), index=False)

        # Getting accuracy metrics for the train as well as test data
        train_metrics_list = self.metrics_calculator(self.y_train, model.fittedvalues)
        test_metrics_list = self.metrics_calculator(self.y_test, predictions)

        # Making a list of all the required values (Beta Estimates,
        # P-values,etc.) which will be further collated into a dataframe
        subset_variables_list = model.params.index
        beta_list = model.params.values
        pvalues_list = model.pvalues.values
        std_error_list  = model.params.values/model.tvalues.values
        adj_rsquare_list = [model.rsquared_adj*100]*len(subset_variables_list)
        train_rsquare_list = [train_metrics_list[0]]*len(subset_variables_list)
        train_mae_list = [train_metrics_list[1]]*len(subset_variables_list)
        train_mape_list = [train_metrics_list[2]]*len(subset_variables_list)
        train_wmape_list = [train_metrics_list[3]]*len(subset_variables_list)
        test_rsquare_list = [test_metrics_list[0]]*len(subset_variables_list)
        test_mae_list = [test_metrics_list[1]]*len(subset_variables_list)
        test_mape_list = [test_metrics_list[2]]*len(subset_variables_list)
        test_wmape_list = [test_metrics_list[3]]*len(subset_variables_list)

        # Collating all the required values
        results_df = pd.DataFrame({
                'Variables': subset_variables_list,
                'Beta_Coeff': beta_list,
                'P-Values': pvalues_list,
                'Std_Error': std_error_list,
                'Train_R_Square': train_rsquare_list,
                'Train_Adj_R_Square': adj_rsquare_list,
                'Train_MAE': train_mae_list,
                'Train_MAPE': train_mape_list,
                'Train_WMAPE': train_wmape_list,
                'Test_R_Square': test_rsquare_list,
                'Test_MAE': test_mae_list,
                'Test_MAPE': test_mape_list,
                'Test_WMAPE': test_wmape_list})

        results_df = results_df[['Variables', 'Beta_Coeff',
                                 'Std_Error', 'P-Values', 'Train_MAE',
                                 'Train_MAPE', 'Train_Adj_R_Square',
                                 'Train_R_Square', 'Train_WMAPE',
                                 'Test_MAE', 'Test_MAPE',
                                 'Test_R_Square', 'Test_WMAPE']]
        return results_df
