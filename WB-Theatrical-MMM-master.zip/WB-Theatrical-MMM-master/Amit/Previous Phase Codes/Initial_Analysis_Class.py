# -*- coding: utf-8 -*-
"""
Created on Wed Feb 27 14:58:55 2019

@author: amit
"""

import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import kurtosis, skew, pearsonr
import os

class analysis():
    """
    A class which outputs all the univariate and bivariate plots for the passed
    variables

    Parameters
    ----------
    dataframe: Pandas Dataframe
        The dataframe containing the variables
    numerical_list: List of column names
        The list in which all those numerical columns will be passed whose
        plots is to be outputted
    categorical_list: List of column names
        The list of all those categorical columns will be passed whose bivariate
        analysis is to be done
    dependent variable: String
        The column name of the dependent variable against which the bivariate
        plots will be made
    """
    def __init__(self, dataframe, numerical_list=None, categorical_list=None,
                 dependent_variable=None):
        self.dataframe = dataframe
        self.numerical_list = numerical_list
        self.categorical_list = categorical_list
        self.dependent_variable = dependent_variable


    def univariate_analysis(self):
        if self.numerical_list != None:
            for numerical in self.numerical_list:
                try:
                    print(numerical)
                    fig = plt.figure()
                    ax = fig.add_subplot(121)
                    sns.distplot(self.dataframe[numerical].dropna(), ax=ax)
                    text = "Skewness: "+ str(round(skew(self.dataframe[numerical].dropna()),2))
                    ax.text(1, 1,text, horizontalalignment ='right', verticalalignment='top',
                            transform=ax.transAxes)
                    ax.set_ylabel("Kernel Density Estimate")
                    ax1 = fig.add_subplot(122)
                    sns.boxplot(y= self.dataframe[numerical].dropna(), ax=ax1)
                    plt.tight_layout()
                    plt.close()
                    fig.savefig(numerical)
                except TypeError:
                    continue
        if self.categorical_list!=None:
            for categorical in self.categorical_list:
                print(categorical)
                fig = plt.figure()
                ax = fig.add_subplot(111)
                sns.countplot(x=self.dataframe[categorical], ax=ax)
                ax.set_xticklabels(ax.get_xticklabels(), rotation=90)
                plt.tight_layout()
                plt.close()
                fig.savefig(categorical)



    def bivariate_analysis(self):
        if self.numerical_list != None:
            for numerical in self.numerical_list:
                print(numerical)
                try:
                    fig = plt.figure()
                    ax = fig.add_subplot(111)

                    sns.regplot(y=self.dependent_variable,
                                    x=numerical, ax=ax, data = self.dataframe)
                    text = "Correlation: " + str(round(pearsonr(
                            x=self.dataframe.dropna(subset=[numerical])[self.dependent_variable],
                            y=self.dataframe.dropna(subset=[numerical])[numerical])[0],2))
                    ax.text(1, 1, text, horizontalalignment='right',
                            verticalalignment='top', transform=ax.transAxes)
                    ax.set_xlabel(str(numerical))
                    ax.set_ylabel(str(self.dependent_variable))
                    plt.close()
                    fig.savefig(numerical)
                except TypeError:
                    continue
        if self.categorical_list!=None:
            for categorical in self.categorical_list:
                print(categorical)
                fig = plt.figure()
                ax = fig.add_subplot(111)
                sns.boxplot(x=self.dataframe[categorical],
                            y=self.dataframe[self.dependent_variable], ax= ax)
                ax.set_xticklabels(ax.get_xticklabels(), rotation=90)
                plt.tight_layout()
                plt.close()
                fig.savefig(categorical)





original_data =  pd.read_excel(
        "E:/WB_project/daily_tasks/23042019/BO_modelingAD_new_WB_Only.xlsx")

data_1 = pd.read_csv("train_data.csv")
data_2 = pd.read_csv("test_data.csv")
original_data = pd.concat([data_1, data_2], axis=0)


original_data.columns

# For BO
numerical_columns = [ 'BO_Window', 'BO_Media_Spend', 'Budget',
       'Runtime', 'trailer_window',
       'School_Outage',
       'last_competitor_release_delta_days', 'average_previous_Gross_US',
       'Actor_2_rolling_leads', 'Actor_1_rolling_leads_5',
       'Actor_1_rolling_roles', 'Actor_1_rolling_supporting',
       'Actor_1_rolling_supporting_5', 'Actor_1_rolling_avg_earnings_lead',
       'Actor_1_rolling_avg_earnings_supporting', 'Theatre_minus_45_variable',
       'BO_Revenue']
numerical_columns = ["BO_Media_Spend"]


categorical_columns = ['franchise_flag', 'HolidayFlag', 'Genre', "Month",
                       'franchise_releases_in_last_3_years', 'any_competitor_release']



dropped_titles= ['tt3884528', 'tt3231010', 'tt2366608', 'tt2771372']
original_data = original_data.loc[~original_data['IMDB_Title_Code'].isin(dropped_titles),:]


## For HE
numerical_columns = ['HE_Spend',
                             'HE_Revenue', 'Budget', 'Runtime', 'BO_Window',
                             'window', 'views_count', 'School_Outage',
                             'likes_count', 'dislikes_count', 'comments_count',
                             'last_competitor_release_delta_days', 'Average_Actors_Gross_US',
                             'average_previous_Gross_US', 'median_previous_Gross_US']

categorical_columns = ['Raw_Genre', 'franchise_flag',
                       'Theatrical_Release_Year', 'Theatrical_Release_Month',
                       'EST_Release_Year', 'EST_Release_Month',
                       'PST_Release_Year', 'PST_Release_Month',
                       'MajorFranchise', 'MPAA_rating']

os.chdir('E:/WB_project/Data_Analysis/Univariate/')


instance_1 = analysis(imputed_data, numerical_columns, None,
                      dependent_variable='BO_Revenue')
instance_1.univariate_analysis()
os.chdir('E:/WB_project/Data_Analysis/Bivariate/')
instance_1.bivariate_analysis()

corr_heatmap = original_data.corr().reset_index()
corr_heatmap.to_csv("corr_heatmap.csv", index=False)


fig, ax = plt.subplots()
sns.heatmap(original_data.corr(), ax=ax, annot=True, annot_kws={'size': 7})
fig.savefig("Correlation Heatmap")




train_data['BO_Revenue'] = np.log(train_data['BO_Revenue'])

sns.boxplot(x='Month_Bin', y='BO_Revenue', data=imputed_data)
sns.boxplot(x='Month_Bin', y='BO_Revenue', data=train_data)







