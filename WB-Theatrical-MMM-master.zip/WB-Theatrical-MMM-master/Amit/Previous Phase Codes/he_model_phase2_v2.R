library(leaps)
library(car)
library(data.table)
library(ggplot2)
library(RColorBrewer)
library(rattle)
library(rpart)
library(rpart.plot)
library(readxl)
library(caret)
library(dummies)

# Data loading
modelling_ad <- read_excel("E:/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/03. Analytical Datasets/modelling_ad_he_11_12_2019.xlsx")
modelling_ad <- data.table(modelling_ad)

# Removing movies with no spends in linear coop since this is a very crucial variable in the model and movies
# without this spends skew the results
modelling_ad <- modelling_ad[!imdb_title_name %in% c('They Shall Not Grow Old', 'Head Full of Honey', 'Hot Pursuit', 'The Sun Is Also a Star', 'Barbershop: The Next Cut', 'Creed', 'Tomb Raider',"Ocean's Eight", "Life of the Party", "Teen Titans Go! To the Movies")]


# Removing titles with no competitor index variable
modelling_ad <- modelling_ad[!imdb_title_name %in% c('Entourage', 'Going in Style', 'Head Full of Honey', 'Midnight Special', 'Point Break', 'They Shall Not Grow Old')]



# Removing low revenue titles
modelling_ad[, net_he_revenue:=sum(he_revenue), by=c('imdb_title_code')]
modelling_ad <- modelling_ad[net_he_revenue > 5000000, ]

# Removing 0 entries in dependent variable
modelling_ad <- modelling_ad[he_revenue > 0, ]

# Taking first 30 weeks of HE Revenue
modelling_ad <- modelling_ad[he_week_number %in% c(0:30), ]


# Creating HE week flags where generally peaks are seen
modelling_ad[, he_week_0_flag := ifelse(he_week_number==0, 1, 0)]
modelling_ad[, he_week_1_flag := ifelse(he_week_number==1, 1, 0)]
modelling_ad[, he_week_13_flag := ifelse(he_week_number==13, 1, 0)]
modelling_ad[, he_week_13_flag := ifelse(he_week_number==13, 1, 0)]


# Creating BO window flag
modelling_ad[, bo_window := bo_week_number-he_week_number]
modelling_ad[, franchise_releases_in_last_5_years_bin := ifelse(franchise_releases_in_last_5_years==0, 'zero', ifelse(franchise_releases_in_last_5_years==1, 'one', 'more_than_1'))]


# Creating Dummy Variable
modelling_ad <- data.table(dummy.data.frame(modelling_ad, 'runtime_bin'))



# Train Test Splitting the data
train_data <- modelling_ad[theatrical_release_year %in% c(2015, 2016, 2017), ]
test_data <- modelling_ad[theatrical_release_year%in%c(2018, 2019), ]
#train_data <- train_data[!is.na(competitor_index), ]
#test_data <- test_data[!is.na(competitor_index), ]

# Printing number of train and test titles
paste("Number of train titles:", length(unique(train_data$imdb_title_code)))
paste("Number of test titles:", length(unique(test_data$imdb_title_code)))



# Function for error calculation
error_metrics <- function(y_true, y_pred){
  mae <- mean(abs(y_true-y_pred))
  mape <- mean(abs(y_true-y_pred)/y_true)
  wmape <- sum(abs(y_true-y_pred))/sum(as.numeric(y_true))
  return(c(mae, mape, wmape))
}


# Function for outlier capping
outlier_capping <- function(x){
  quantiles <- quantile( x, c(.05, .95) )
  x[ x < quantiles[1] ] <- quantiles[1]
  x[ x > quantiles[2] ] <- quantiles[2]
  x
  
}


# Building the model
lr_model <- lm(log(he_revenue)~#log(he_week_number+1)+
                 distribution_only+
                 he_week_0_flag+
                 franchise_releases_in_last_5_years_bin+
                 he_week_1_flag+
                 long_weekend_flag+
                 #he_week_2_flag+
                 pst_sellthru_week_1_flag+
                 #vod_week_0_flag+
                 vod_week_1_flag+
                 #total_bo_spend+
                 #franchise_flag+
                 #competitor_index_3_weeks+
                 top3_competitor_index_2_weeks+
                 #competitor_index+
                 #franchise_releases_in_last_5_years+
                 #holiday_flag+
                 log(`he_spend_digital Adstock Linear0.841`+1)+
                 log(`he_spend_digital_video Adstock Linear0.848`+1)+
                 log(`he_spend_linear-coop Adstock Linear0.842`+1)+
                 log(`he_spend_non-digital Adstock Linear0.841`+1)+
                 #log(`he_spend_total_digital Adstock Linear0.847`+1)+
                 #log(`max_combined_views_till_-4`+1)+
                 #`max_combined_comments_till_-4`+
                 #`max_combined_likes_by_views_till_-4`+
                 #log(`max_google_search_volume_till_-4`+1)+
                 #`max_wikipedia_page_views_till_-4`+
                 #`avg_google_search_volume_till_-4`+
                 log(`avg_wikipedia_page_views_till_-4`+1)+
                 #log(`combined_views_-4_adstock_linear0.748`+1)+
                 #log(`combined_likes_by_views_-4_adstock_linear0.719`+1)+
                 #log(`wikipedia_page_views_-4_adstock_linear0.9`+1)+
                 mkt_genre_grouped_horror_scifi_mystery+
                 mkt_genre_grouped_family+
                 #runtime+
                 #runtime_bin90_to_100_mins+
                 runtime_bin100_to_110_mins+
                 #runtime_bin110_to_120_mins+
                 runtime_bin120_to_130_mins+
                 runtime_binmore_than_130_mins+
                 #mkt_genre_grouped_action_adventure+
                 mkt_genre_grouped_drama,
               #runtime_bin,
               #log(cast_avg_rating),
               data = train_data
)

# Checking post model properties
summary(lr_model)
plot(lr_model)
vif(lr_model)
residualPlots(lr_model)


# Calculating title-week level errors
#train_data$predictions <-  exp(predict(lr_model, train_data))
#test_data$predictions <-  exp(predict(lr_model, test_data))
#train_data$error <- abs(train_data$predictions - train_data$he_revenue)
#test_data$error <- abs(test_data$predictions - test_data$he_revenue)
#error_metrics(train_data$he_revenue, exp(predict(lr_model, train_data)))
#error_metrics(test_data$he_revenue, exp(predict(lr_model, test_data)))



# Calculating title level errors
train_data$predictions <-  exp(predict(lr_model, train_data))
test_data$predictions <-  exp(predict(lr_model, test_data))
title_train_data <- train_data[, j=list(predicitions=sum(predictions), he_revenue=sum(he_revenue)), by=c('imdb_title_code', 'imdb_title_name')]
title_test_data <- test_data[, j=list(predicitions=sum(predictions), he_revenue=sum(he_revenue)), by=c('imdb_title_code', 'imdb_title_name')]
paste("Train WAMPE:", error_metrics(title_train_data$he_revenue, title_train_data$predicitions)[3])
paste("Test WMAPE:", error_metrics(title_test_data$he_revenue, title_test_data$predicitions)[3])



#test_data <- test_data[!(imdb_title_name %in% c('Shazam!')), ]
#error_metrics(test_data$he_revenue, exp(predict(lr_model, test_data)))


# Plotting actual vs predicted average revenue trend across weeks for train data
plot_data <- train_data[, j=list(he_revenue=mean(he_revenue), pred=mean(predictions)), by=c('he_week_number')]
ggplot(data=plot_data, aes(x=he_week_number))+
  geom_line(aes(y=he_revenue), color='green')+
  geom_line(aes(y=pred), color='red')


# Plotting actual vs predicted average revenue trend across weeks for test data
plot_data <- test_data[, j=list(he_revenue=mean(he_revenue), pred=mean(predictions)), by=c('he_week_number')]
ggplot(data=plot_data, aes(x=he_week_number))+
  geom_line(aes(y=he_revenue), color='green')+
  geom_line(aes(y=pred), color='red')


# Writing data
fwrite(train_data, "E:\\WB_project\\daily_tasks\\november\\13102019\\train_predict_he.csv", row.names = F)
fwrite(test_data, "E:\\WB_project\\daily_tasks\\november\\13102019\\test_predict_he.csv", row.names = F)


# Writing data with only reuqired columns
subset_train_data <- train_data[, c('imdb_title_code', 'imdb_title_name', 'he_week_number', 'distribution_only', 'he_week_0_flag', 'franchise_releases_in_last_5_years_bin','he_week_1_flag', 'long_weekend_flag', 'pst_sellthru_week_1_flag', 'vod_week_1_flag', 'top3_competitor_index_2_weeks', 'he_spend_digital Adstock Linear0.841', 'he_spend_digital_video Adstock Linear0.848', 'he_spend_linear-coop Adstock Linear0.842', 'he_spend_non-digital Adstock Linear0.841', 'avg_wikipedia_page_views_till_-4', 'mkt_genre_grouped_horror_scifi_mystery', 'mkt_genre_grouped_family', 'runtime_bin100_to_110_mins', 'runtime_bin120_to_130_mins', 'runtime_binmore_than_130_mins', 'mkt_genre_grouped_drama', 'he_revenue', 'predictions', 'error')]
fwrite(subset_train_data, "E:\\WB_project\\daily_tasks\\november\\13112019\\train_predict_he_subset.csv", row.names = F)
subset_test_data <- test_data[, c('imdb_title_code', 'imdb_title_name', 'he_week_number', 'distribution_only', 'he_week_0_flag', 'franchise_releases_in_last_5_years_bin','he_week_1_flag', 'long_weekend_flag', 'pst_sellthru_week_1_flag', 'vod_week_1_flag', 'top3_competitor_index_2_weeks', 'he_spend_digital Adstock Linear0.841', 'he_spend_digital_video Adstock Linear0.848', 'he_spend_linear-coop Adstock Linear0.842', 'he_spend_non-digital Adstock Linear0.841', 'avg_wikipedia_page_views_till_-4', 'mkt_genre_grouped_horror_scifi_mystery', 'mkt_genre_grouped_family', 'runtime_bin100_to_110_mins', 'runtime_bin120_to_130_mins', 'runtime_binmore_than_130_mins', 'mkt_genre_grouped_drama', 'he_revenue', 'predictions', 'error')]
fwrite(subset_test_data, "E:\\WB_project\\daily_tasks\\november\\13112019\\test_predict_he_subset.csv", row.names = F)


## Getting Standardisez Coefficients for the above model
lr_model <- lm(log(he_revenue)~#log(he_week_number+1)+
                 distribution_only+
                 he_week_0_flag+
                 franchise_releases_in_last_5_years_bin+
                 he_week_1_flag+
                 long_weekend_flag+
                 #he_week_2_flag+
                 pst_sellthru_week_1_flag+
                 #vod_week_0_flag+
                 vod_week_1_flag+
                 #franchise_flag+
                 #competitor_index_3_weeks+
                 scale(top3_competitor_index_2_weeks)+
                 #competitor_index+
                 #franchise_releases_in_last_5_years+
                 #holiday_flag+
                 scale(log(`he_spend_digital Adstock Linear0.841`+1))+
                 scale(log(`he_spend_digital_video Adstock Linear0.848`+1))+
                 scale(log(`he_spend_linear-coop Adstock Linear0.842`+1))+
                 scale(log(`he_spend_non-digital Adstock Linear0.841`+1))+
                 #log(`he_spend_total_digital Adstock Linear0.847`+1)+
                 #log(`max_combined_views_till_-4`+1)+
                 #`max_combined_comments_till_-4`+
                 #`max_combined_likes_by_views_till_-4`+
                 #log(`max_google_search_volume_till_-4`+1)+
                 #`max_wikipedia_page_views_till_-4`+
                 #`avg_google_search_volume_till_-4`+
                 #log(`avg_wikipedia_page_views_till_-4`+1)+
                 #log(`combined_views_-4_adstock_linear0.748`+1)+
                 #log(`combined_likes_by_views_-4_adstock_linear0.719`+1)+
                 scale(log(`avg_wikipedia_page_views_till_-4`+1))+
                 mkt_genre_grouped_horror_scifi_mystery+
                 mkt_genre_grouped_family+
                 #runtime+
                 #runtime_bin90_to_100_mins+
                 runtime_bin100_to_110_mins+
                 #runtime_bin110_to_120_mins+
                 runtime_bin120_to_130_mins+
                 runtime_binmore_than_130_mins+
                 #mkt_genre_grouped_action_adventure+
                 mkt_genre_grouped_drama,
               #runtime_bin,
               #log(cast_avg_rating),
               data = train_data
)

# Checking post model properties
summary(lr_model)
