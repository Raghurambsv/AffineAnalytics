# -*- coding: utf-8 -*-
"""
Created on Tue May 21 11:09:09 2019

@author: amit
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error
import pickle
from bayes_opt import BayesianOptimization
import sys


# Helper function-1 Defining a function to caluclate the error metrics
def accuracy_metrics(y_true, y_pred):
    mae = np.mean(np.abs(y_true-y_pred))
    mape = np.mean(np.abs(y_true-y_pred)/y_true)
    wmape = np.sum(np.abs(y_true-y_pred))/np.sum(y_true)
    return[mae, mape, wmape]


# Helper Function-2 Defining a function to optimise the two hyper parameters of the bagging approach
def optimise_hyperparameters(n_estimators, max_features, train_data, test_data):
    title_list = train_data['IMDB_Title_Code'].unique()
    np.random.seed(0)
    n_estimators = int(n_estimators)
    max_features = int(max_features)
    # Initialising the final results dataframe
    master_result_train_dataframe = train_data[['IMDB_Title_Code', 'Week_Number']]
    master_result_test_dataframe = test_data[['IMDB_Title_Code', 'Week_Number']]
    # Initialising the final dataframe with beta coefficient information
    master_beta_dataframe = pd.DataFrame({'variable': features_list+['intercept']})
    # Creating n_estimator number of linear regression models
    for num, iteration in enumerate((range(n_estimators))):
        linear_model = LinearRegression()
        # Randomly subsetting some title codes for training 
        random_sample_indices = np.random.choice(len(train_data['IMDB_Title_Code'].unique()), 40, replace=False)
        # Randomly subsetting some features for training
        random_feature_indices = np.random.choice(len(features_list), max_features, replace=False)
        X_train_subset = train_data.loc[train_data['IMDB_Title_Code'].isin(title_list[random_sample_indices]),
                                        [features_list[index] for index in random_feature_indices]]
        y_train_subset = train_data.loc[train_data['IMDB_Title_Code'].isin(title_list[random_sample_indices]),
                                        'log_bo_revenue']
        linear_model.fit(X_train_subset, y_train_subset)
        # Creating a set of intermediate train result dataframe
        subset_result_train_dataframe =  train_data.loc[train_data['IMDB_Title_Code'].isin(title_list[random_sample_indices]),
                                                  ['IMDB_Title_Code', 'Week_Number']]
        subset_result_train_dataframe['predictions_'+str(num)] = linear_model.predict(X_train_subset)
        # Merging the intermediate dataframe with the train main dataframe
        master_result_train_dataframe = pd.merge(master_result_train_dataframe, subset_result_train_dataframe,
                                           on=['IMDB_Title_Code', 'Week_Number'], 
                                           how='left')
        # Creating a set of intermediate test result dataframe
        subset_result_test_dataframe =  test_data[['IMDB_Title_Code', 'Week_Number']].copy()
        subset_result_test_dataframe['predictions_'+str(num)] = linear_model.predict(test_data[[features_list[index] for index in random_feature_indices]])
        # Merging the intermediate dataframe with the test main dataframe
        master_result_test_dataframe = pd.merge(master_result_test_dataframe, subset_result_test_dataframe,
                                           on=['IMDB_Title_Code', 'Week_Number'], 
                                           how='left')
        # Creating intermediate beta coefficient dataframe
        subset_beta_dataframe = pd.DataFrame({'variable': list(X_train_subset.columns.values)+['intercept'],
                                              'coef_'+str(num): np.append(linear_model.coef_, linear_model.intercept_)})
        # Merging the intermediate dataframe with the main dataframe
        master_beta_dataframe = pd.merge(master_beta_dataframe, subset_beta_dataframe,
                                         on=['variable'], how='left')
    # Taking average of predictions
    master_result_train_dataframe['final_prediction'] = master_result_train_dataframe.apply(
            lambda x: np.exp(np.nanmean([x['predictions_'+str(num)] for num in range(n_estimators)])), axis=1)
    master_result_test_dataframe['final_prediction'] = master_result_test_dataframe.apply(
            lambda x: np.exp(np.nanmean([x['predictions_'+str(num)] for num in range(n_estimators)])), axis=1)
    # Taking average of beta coefficients
    master_beta_dataframe.fillna(0, inplace=True)
    master_beta_dataframe['final_coefficient'] = master_beta_dataframe.apply(
            lambda x: np.mean([x['coef_'+str(num)] for num in range(n_estimators)]), axis=1)
    # caluclating train and test accuracy metrics
    train_metrics = accuracy_metrics(train_data['BO_Revenue'], master_result_train_dataframe['final_prediction'])
    test_metrics = accuracy_metrics(test_data['BO_Revenue'], master_result_test_dataframe['final_prediction'])
    # Returning the objective to be minimized
    return -(train_metrics[0]+test_metrics[0]+np.abs(train_metrics[0]-test_metrics[0]))


# Main fucntion to create a bagging ensemble model made up of linear regressions
def lr_ensemble(train_data, test_data, n_estimators, max_features,
                optimise=True, num_iterations=10, random_seed=1234):
    """
    Function to run bagging approach made up of linear regressions
    
    Parameters
    ----------
    train_data: Dataframe
        The train dataframe with all the required variables and IMDB_Title_Code column
    test_data: Dataframe
        The test dataframe with all the required variables and IMDB_Title_Code column
    n_estimators: int or tuple
        If you want to optimise then a tuple having the range of values to try else
        if you just want to run the model for a particular value then an integer
    max_features: int or tuple
        If you want to optimise then a tuple having the range of values to try else
        if you just want to run the model for a particular value then an integer
    optimise: Bool default True
        Whether to optimise the hyperparameters-n_estimators and max_features
    num_iterations= int default 10
        The number of iterations to try while optimising using bayesian optimisation
    random_seed: int default 1234
        The random seed for reproducibility

    Returns
    -------
    Returns three dataframes- train data with predictions, test data with predictions,
    beta coeffcient dataframe
    """
    # If user wants to optimise then calling the optimisation function defined previously
    if optimise:
        try:
            optimizer = BayesianOptimization(f=optimise_hyperparameters,
                                             pbounds={'n_estimators': n_estimators,
                                                      'max_features': max_features},
                                             random_state=random_seed,
                                             verbose=2)
            optimizer.maximize(n_iter=num_iterations)
            # Setting the best hyperparameters selected form the optimisation
            max_features = int(optimizer.max['params']['max_features'])
            n_estimators = int(optimizer.max['params']['n_estimators'])
        except TypeError:
            print('You have selected optimise to be True. Please provide a tuple and not a single value of hyperparameters')
            sys.exit(1)
    try:
        title_list = train_data['IMDB_Title_Code'].unique()
        np.random.seed(0)
        # Initialising the final results dataframe
        master_result_train_dataframe = train_data[['IMDB_Title_Code', 'Week_Number']]
        master_result_test_dataframe = test_data[['IMDB_Title_Code', 'Week_Number']]
        # Initialising the final dataframe with beta coefficient information
        master_beta_dataframe = pd.DataFrame({'variable': features_list+['intercept']})
        # Creating n_estimator number of linear regression models
        for num, iteration in enumerate((range(n_estimators))):
            linear_model = LinearRegression()
            # Randomly subsetting some title codes for training 
            random_sample_indices = np.random.choice(len(train_data['IMDB_Title_Code'].unique()), 40, replace=False)
            # Randomly subsetting some features for training
            random_feature_indices = np.random.choice(len(features_list), max_features, replace=False)
            X_train_subset = train_data.loc[train_data['IMDB_Title_Code'].isin(title_list[random_sample_indices]),
                                            [features_list[index] for index in random_feature_indices]]
            y_train_subset = train_data.loc[train_data['IMDB_Title_Code'].isin(title_list[random_sample_indices]),
                                            'log_bo_revenue']
            linear_model.fit(X_train_subset, y_train_subset)
            # Creating a set of intermediate train result dataframe
            subset_result_train_dataframe =  train_data.loc[train_data['IMDB_Title_Code'].isin(title_list[random_sample_indices]),
                                                      ['IMDB_Title_Code', 'Week_Number']]
            subset_result_train_dataframe['predictions_'+str(num)] = linear_model.predict(X_train_subset)
            # Merging the intermediate dataframe with the train main dataframe
            master_result_train_dataframe = pd.merge(master_result_train_dataframe, subset_result_train_dataframe,
                                               on=['IMDB_Title_Code', 'Week_Number'], 
                                               how='left')
            # Creating a set of intermediate test result dataframe
            subset_result_test_dataframe =  test_data[['IMDB_Title_Code', 'Week_Number']].copy()
            subset_result_test_dataframe['predictions_'+str(num)] = linear_model.predict(test_data[[features_list[index] for index in random_feature_indices]])
            # Merging the intermediate dataframe with the test main dataframe
            master_result_test_dataframe = pd.merge(master_result_test_dataframe, subset_result_test_dataframe,
                                               on=['IMDB_Title_Code', 'Week_Number'], 
                                               how='left')
            # Creating intermediate beta coefficient dataframe
            subset_beta_dataframe = pd.DataFrame({'variable': list(X_train_subset.columns.values)+['intercept'],
                                                  'coef_'+str(num): np.append(linear_model.coef_, linear_model.intercept_)})
            # Merging the intermediate dataframe with the main dataframe
            master_beta_dataframe = pd.merge(master_beta_dataframe, subset_beta_dataframe,
                                             on=['variable'], how='left')
        # Taking average of predictions
        master_result_train_dataframe['final_prediction'] = master_result_train_dataframe.apply(
                lambda x: np.exp(np.nanmean([x['predictions_'+str(num)] for num in range(n_estimators)])), axis=1)
        master_result_test_dataframe['final_prediction'] = master_result_test_dataframe.apply(
                lambda x: np.exp(np.nanmean([x['predictions_'+str(num)] for num in range(n_estimators)])), axis=1)
        # Taking average of beta coefficients
        master_beta_dataframe.fillna(0, inplace=True)
        master_beta_dataframe['final_coefficient'] = master_beta_dataframe.apply(
                lambda x: np.mean([x['coef_'+str(num)] for num in range(n_estimators)]), axis=1)
         # Caluclating train and test accuracy metrics
        train_metrics = accuracy_metrics(train_data['BO_Revenue'], master_result_train_dataframe['final_prediction'])
        test_metrics = accuracy_metrics(test_data['BO_Revenue'], master_result_test_dataframe['final_prediction'])
        # Creating a final dataframe with coefficients and error info
        final_df = master_beta_dataframe[['variable', 'final_coefficient']].copy()
        final_df['train_mae'] = train_metrics[0]
        final_df['train_mape'] = train_metrics[1]
        final_df['train_wmape'] = train_metrics[2]
        final_df['test_mae'] = test_metrics[0]
        final_df['test_mape'] = test_metrics[1]
        final_df['test_wmape'] = test_metrics[2]
        final_df['n_estimators'] = n_estimators
        final_df['max_features'] = max_features
        train_data = pd.merge(train_data, master_result_train_dataframe[['IMDB_Title_Code', 'Week_Number',
                                                                         'final_prediction']],
                             on=['IMDB_Title_Code', 'Week_Number'],
                             how='left')
        test_data = pd.merge(test_data, master_result_test_dataframe[['IMDB_Title_Code', 'Week_Number',
                                                                         'final_prediction']],
                             on=['IMDB_Title_Code', 'Week_Number'],
                             how='left')
        train_data['error'] = np.abs(train_data['BO_Revenue']-train_data['final_prediction'])
        test_data['error'] = np.abs(test_data['BO_Revenue']-test_data['final_prediction'])
    except TypeError:
        print('You have selected optimise to be False. Please provide a single int value for the hyperparameters')
        sys.exit(1)
    return train_data, test_data, final_df


if __name__=='__main__':
    train_data = pd.read_csv(r"E:\WB_project\daily_tasks\08082019\train_data.csv" , encoding='latin-1')
    test_data = pd.read_csv(r"E:\WB_project\daily_tasks\08082019\test_data.csv", encoding='latin-1')
    features_list = ['log_BO_spend_Digital_Adstock_Linear0.1',
                     'log_BO_spend_Digital_Video_Adstock_Linear0.65',
                     'log_BO_spend_Outdoor_Adstock_Linear0.7',
                     'log_Others_Adstock_Linear0.5',
                      'log_BO_Spend_TV_Adstock_Linear0.6', 
                      'log_max_views_till_week',
                      'log_avg_earnings_franchise',
                      'week_num',
                      'week_square']
    X_train = train_data[features_list+['IMDB_Title_Code']]
    y_train = train_data['log_bo_revenue']
    X_test = test_data[features_list]
    train_data, test_data, final_df = lr_ensemble(train_data, test_data, 
                                                  (1,10), 4, False, 10, 1234)
    with open('E:\WB_project\Pickle_Objects\model_summary_14082019.pkl', 'wb') as f:
        pickle.dump(final_df, f)
    with open('E:\WB_project\Pickle_Objects\model_summary_14082019.pkl', 'rb') as f:
        final_df = pickle.load(f)


























































