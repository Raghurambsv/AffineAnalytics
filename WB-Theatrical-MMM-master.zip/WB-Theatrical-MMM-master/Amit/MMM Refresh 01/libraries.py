# -*- coding: utf-8 -*-
"""
Created on Tue Feb 26 14:35:24 2019

@author: Arunav Saikia
"""
import pandas as pd
import numpy as np
import datetime
from requests import get
import bs4
import re

def clean_date_to_year_v2(x):
    try:
        try:
            year = int(datetime.datetime.strptime(str(x), '%d-%b-%y').date().year)
        
        except:
            try:
                year = int(x)
            except:
                year = int(re.search('([0-9]{4})', x).group(1))
    except:
        year = None
    return year


def clean_date_to_year(x):
    try:
        year = int(datetime.datetime.strptime(str(x), '%Y-%m-%d %H:%M:%S').date().year)
        
    except:
        try:
            year = int(x)
        except:
            year = None
    return year

def clean_date(x):
    try:
        date = datetime.datetime.strptime(str(x), '%Y-%m-%d %H:%M:%S').date()
        
    except:
        try:
            date = datetime.datetime.strptime(str(x), '%Y').date()
        except:
            date = None
    return date


def to_longformat(dataframe, column_to_unpivot, column_as_id):
    
    """
    column_to_unpivot: String
        The column of the variables to convert to long format
    column_as_id: List
        The list of columns to keep as Index while converting to long format
    """
    dataframe[column_to_unpivot] = dataframe[column_to_unpivot].apply(
            lambda x: str(x).strip().split("[")[1][:-1])
   
    temp = dataframe[column_to_unpivot].str.split(" ", expand=True)

    dataframe = pd.concat([dataframe, temp], axis=1)
    dataframe = pd.melt(dataframe, id_vars=column_as_id,
                        value_vars=range(0, temp.shape[1]))
    dataframe.dropna(inplace=True)
    dataframe.drop('variable', axis=1, inplace=True)
    return dataframe

def to_longformat_v2(dataframe, column_to_unpivot, column_as_id):
    
    """
    column_to_unpivot: String
        The column of the variables to convert to long format
    column_as_id: List
        The list of columns to keep as Index while converting to long format
    """
    dataframe[column_to_unpivot] = dataframe[column_to_unpivot].apply(
            lambda x: str(x).strip().split("[")[1][:-1])
   
    temp = dataframe[column_to_unpivot].str.split(",", expand=True)

    dataframe = pd.concat([dataframe, temp], axis=1)
    dataframe = pd.melt(dataframe, id_vars=column_as_id,
                        value_vars=range(0, temp.shape[1]))
    dataframe.dropna(inplace=True)
    dataframe.drop('variable', axis=1, inplace=True)
    return dataframe

def getIndex(movie_containers, tag):
  for index, container in enumerate(movie_containers):
      try:
        if container.h4.text == tag:
          return index
          break
      except:
        pass
  

def get_US_gross(title):
    url = 'https://www.imdb.com/title/'+ title + '/'
    print(title)
    response = get(url)
    soup = bs4.BeautifulSoup(response.text, 'lxml')
    movie_containers = soup.find_all('div', class_ = 'txt-block')
    grossUSIndex = getIndex(movie_containers, 'Gross USA:')

    try:
        gross_US = ''.join(re.findall(r'\d+', re.search(r'\$(.+?)(\n?\s)', movie_containers[grossUSIndex].text).group(1)))
    except:
        gross_US = None  
    return gross_US

