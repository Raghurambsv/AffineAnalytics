# -*- coding: utf-8 -*-
"""
Created on Wed Jun  5 10:53:35 2019

@author: amit
"""

import pandas as pd
import numpy as np


## Main Function for creating GS data features
def social_media_metrics(base_ad, gs_data, snapshot, week_number_colname):
    metric = "google_search_volume"
    gs_data[metric+'_'+str(snapshot)] = gs_data.apply(lambda x: np.nan if x[week_number_colname]>=snapshot else x[metric], axis=1)
    # Creating some basic mean/max variables out of the combined variables
    gs_data['max_'+metric+'_till_'+str(snapshot)] = gs_data.groupby(['imdb_title_code'])[metric+'_'+str(snapshot)].transform('max')
    gs_data['avg_'+metric+'_till_'+str(snapshot)] = gs_data.groupby(['imdb_title_code'])[metric+'_'+str(snapshot)].transform('mean')
    gs_data['total_'+metric+'_till_'+str(snapshot)] = gs_data.groupby(['imdb_title_code'])[metric+'_'+str(snapshot)].transform('sum')
    # Getting title level metrics
    base_ad = pd.merge(base_ad, gs_data[['imdb_title_code', 'max_'+metric+'_till_'+str(snapshot), 'avg_'+metric+'_till_'+str(snapshot), 'total_'+metric+'_till_'+str(snapshot)]].drop_duplicates(),
                                                   on=['imdb_title_code'],
                                                   how='left')

    return base_ad