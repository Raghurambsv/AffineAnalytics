
import numpy as np
import pandas as pd
from datetime import timedelta
import date_manipulations


def holiday_flag(base_dataframe, date_col_calendar, date_col_base_dataframe, holiday_calendar):
    """
    Function to create holiday flag which is 1 if there is any US holiday in that week
    else 0
    
    Parameters
    ---------
    base_dataframe: Pandas Dataframe
        The base AD in which flag is to be calculated
    date_col_calendar: String
        The column name of the holiday date column in the holiday calender
    date_col_base_dataframe: String
        The column name of the week start date column in the base AD
    holiday_calendar: Pandas Dataframe
        The holiday calendar containing the important holidays of US

    Returns
    -------
    The updated Base AD with the flag column
    """
    # Converting the date column to pandas datetime onject
    holiday_calendar[date_col_calendar] = pd.to_datetime(holiday_calendar[date_col_calendar])
    # For every date getting its last sunday date
    holiday_calendar = date_manipulations.last_sunday(holiday_calendar, date_col_calendar,
                                                      'Week_Start_Date')
    holiday_calendar = holiday_calendar[['Week_Start_Date']]
    holiday_calendar['holiday_flag'] = 1
    holiday_calendar.drop_duplicates(inplace=True)
    base_dataframe = pd.merge(base_dataframe, holiday_calendar,
                              left_on=date_col_base_dataframe,
                              right_on='Week_Start_Date', how='left'
                              )
    base_dataframe.fillna({'holiday_flag': 0}, inplace=True)
    return base_dataframe

def long_weekend_flag(base_dataframe, date_col_calendar, date_col_base_dataframe, holiday_calendar):
    """
    Function to create long weekend flag which is 1 if there is any long weekend
    else 0
    
    Parameters
    ---------
    base_dataframe: Pandas Dataframe
        The base AD in which flag is to be calculated
    date_col_calendar: String
        The column name of the holiday date column in the holiday calender
    date_col_base_dataframe: String
        The column name of the week start date column in the base AD
    holiday_calendar: Pandas Dataframe
        The holiday calendar containing the important holidays of US

    Returns
    -------
    The updated Base AD with the long weekend flag column
    """
    # Converting the date column to pandas datetime onject
    holiday_calendar[date_col_calendar] = pd.to_datetime(holiday_calendar[date_col_calendar])
    
    # For every date getting its last sunday date
    holiday_calendar = date_manipulations.last_sunday(holiday_calendar, date_col_calendar,
                                                      'Week_Start_Date')
    # Creating a flag if the holiday is on Mon/Thu/Fri
    holiday_calendar['long_weekend_flag'] = holiday_calendar[date_col_calendar].apply(
            lambda x: 1 if(x.weekday()) in [0, 3, 4] else 0)
    holiday_calendar = holiday_calendar.loc[holiday_calendar['long_weekend_flag']==1, :]
    holiday_calendar.drop_duplicates(subset=['Week_Start_Date'], inplace=True)
    base_dataframe = pd.merge(base_dataframe, holiday_calendar[['Week_Start_Date', 'long_weekend_flag']],
                              left_on=date_col_base_dataframe,
                              right_on='Week_Start_Date',
                              how='left')
    base_dataframe.fillna({'long_weekend_flag': 0}, inplace=True)
    return base_dataframe

#holiday_calendar = pd.read_excel(r"E:\WB_project\daily_tasks\14082019\Modelling AD Folder\US Holiday Calendar Exhaustive.xlsx")
#data = pd.read_excel(r"E:\WB_project\daily_tasks\27082019\wb_only_adhoc_analysis.xlsx")
#updated_data = holiday_flag(data, 'Date', 'week_start_date', holiday_calendar)
#updated_data = long_weekend_flag(updated_data, 'Date', 'week_start_date', holiday_calendar)
#updated_data.to_excel(r"E:\WB_project\daily_tasks\27082019\wb_only_adhoc_analysis_v1.xlsx")
