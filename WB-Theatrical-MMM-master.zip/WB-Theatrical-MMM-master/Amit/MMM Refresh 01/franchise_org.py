# -*- coding: utf-8 -*-
"""
Created on Tue Feb 26 14:32:16 2019

@author: Arunav Saikia
"""

import pandas as pd
import numpy as np
import datetime
from libraries import *


def get_major_franchise():
    """
    This function creates the major franchise of each title based on # of movies in the franchise
    Args:
        None
    Returns:
        major_fran : A dataframe at title level with only one franchise per title
    """
    fran_data = pd.read_excel(r"E:\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\03. Movie Metadata\franchise_data_mapped_v2.xlsm", 
                              sheet_name = 1)


    fran_data['Rank'] = fran_data.groupby(by=['IMDB title'])\
                    ['count of movies in the franchise'].rank(method='max', ascending = False)
                    
    major_fran = fran_data[fran_data['Rank'] == 1]
    
    major_fran.drop(['Rank'], axis = 1,inplace = True)
    
    return major_fran


def franchise_flag(baseAD):
    """
    This function creates franchise flag and name of the major franchise for every title.
    If a title is not part of a franchise, the franchise flag is tipped to 0 and the name 
    of the franchise is set as  'No Franchise'
    
    Args:
        baseAD : The dataframe on which to create the variables
    Returns:
        df : New dataframe with the two variables added
    """
    franchise_data = get_major_franchise()
    franchise_data['franchise_flag'] = 1
    df = baseAD.merge(franchise_data[['IMDB title', 'franchise_flag', 'franchise']].drop_duplicates(), \
                                  left_on = 'IMDB_Title_Code', \
                                  right_on = 'IMDB title', how = 'left').\
              drop(['IMDB title'], axis = 1)

    df.fillna({'franchise_flag':0, 'franchise' : 'No Franchise'}, inplace=True)

    df.rename({'franchise': 'MajorFranchise'}, axis=1, inplace = True)

    return df

def count_of_movies_in_franchise(df, n_years):
    """
    This function calculates the # of movies that have been released as part of the
    franchise in the specified number of preceding years.
    Args:
        df : The dataframe on which the variable is to be calculated
        n_years : viewing period
        
    Returns:
        df : New dataframe with the variable added
    """
    major_fran = get_major_franchise()
    major_fran['release_year'] = major_fran['release date'].apply(clean_date_to_year)
    
    major_fran = major_fran.dropna(axis = 0)
    major_fran_grouped = major_fran.groupby('franchise').agg({'release_year': ['min','max']}).reset_index()
    major_fran_grouped.columns = major_fran_grouped.columns.droplevel(0)
    major_fran_grouped.columns = ['franchise', 'min_year','max_year']
    major_fran_grouped['min_max_year'] = major_fran_grouped.apply(lambda X: np.arange(X['min_year'],X['max_year']+1,1),axis=1)
    major_fran_grouped.drop(['min_year','max_year'], axis =1, inplace = True)
    
    data_new = to_longformat(major_fran_grouped, 'min_max_year',['franchise'])
    data_new['default'] = 0
    
    data_new.value = data_new.value.astype('float')
    
    franchise_data = major_fran.groupby(['franchise','release_year']).agg({'IMDB title':{'no_of_releases': 'count'}}).reset_index()
    franchise_data.columns = franchise_data.columns.droplevel(0)
    franchise_data.columns = ['franchise', 'release_year','no_of_releases']
    
    
    final_data = pd.merge(left= data_new, 
                          right = franchise_data, 
                          how = 'left', 
                          left_on=['franchise', 'value'], 
                          right_on =['franchise', 'release_year'])
    final_data.fillna({'no_of_releases':0}, inplace = True)
    
    
    final_data['rolling_no_of_releases'] = final_data.groupby(['franchise'])['no_of_releases'].\
                                                rolling(window = n_years, min_periods = 1).sum().reset_index(0, drop = True)
    
    
    final_data['franchise_releases_in_last_' + str(n_years) + '_years'] = final_data.groupby(['franchise'])['rolling_no_of_releases'].shift(1)

    df = df.merge(final_data[['franchise','value','franchise_releases_in_last_' + str(n_years) + '_years']], \
                                  left_on = ['MajorFranchise', 'Theatrical_Release_Year'], \
                                  right_on = ['franchise', 'value'], \
                                  how = 'left').\
              drop(['franchise', 'value'], axis = 1)
    
    df.fillna({'franchise_releases_in_last_' + str(n_years) + '_years':0}, inplace=True)

    return df

def last_release_duration(df):
    """
    A function to calculate gap (in years from last release)
    Args:
        df : The dataframe on which the variable is to be calculated
    Returns:
        df : New dataframe with the variable added

    """
    major_fran = get_major_franchise()
    major_fran['release_year'] = major_fran['release date'].apply(clean_date_to_year)

    major_fran = major_fran.sort_values(['franchise','release_year'], ascending = True)

    major_fran['lagged_date'] = major_fran.groupby('franchise')['release_year'].shift(1)
    major_fran['time_delta_since_last_franchise_release'] = major_fran['release_year'] - major_fran['lagged_date']
    
    df = pd.merge(left = df, right = major_fran[['IMDB title','time_delta_since_last_franchise_release']], 
                    how = 'left', 
                    left_on='IMDB_Title_Code', 
                    right_on='IMDB title').\
                    drop(['IMDB title'], axis = 1)
    return df

def get_average_earnings(df):
    """
    This function calculated a rolling average of gross earnings of a franchise per year
    Args:
        df : The dataframe on which the variable is to be calculated
    Returns:
        df : New dataframe with the variable added
    """
    
    try:
        major_fran = pd.read_csv(r"E:\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\03. Movie Metadata\franchise_details_w_gross.csv")
    except:
        major_fran = get_major_franchise()
        titles = major_fran['IMDB title']
        major_fran['Gross_US'] = list(map(get_US_gross, titles))   
        major_fran.to_csv('./franchise_details_w_gross.csv', index = False)
    
    major_fran.Gross_US = major_fran.Gross_US.astype('float')

    major_fran['release_date'] = major_fran['release date'].apply(clean_date)

    major_fran_new = major_fran[major_fran['release_date'].notnull()]

    major_fran_new.sort_values(['franchise','release_date'], ascending = True, inplace = True)

    major_fran_new['rolling_avg'] = major_fran_new.groupby(['franchise'])['Gross_US'].\
                                                expanding(min_periods = 1).mean().reset_index(0, drop = True)

    major_fran_new['avg_earnings_franchise'] = major_fran_new.groupby('franchise')['rolling_avg'].shift(1)

    df = pd.merge(left = df, right = major_fran_new[['IMDB title','avg_earnings_franchise']], 
                    how = 'left', 
                    left_on='IMDB_Title_Code', 
                    right_on='IMDB title').\
                    drop(['IMDB title'], axis = 1)
    return df
