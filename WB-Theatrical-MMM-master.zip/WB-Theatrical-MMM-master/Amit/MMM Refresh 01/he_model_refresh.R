library(leaps)
library(car)
library(data.table)
library(ggplot2)
library(readxl)
library(caret)
library(dummies)

# Data loading
modelling_ad <- read_excel("E:/Affine Analytics Pvt Ltd/WB Theatrical - Documents/04. Media Mix Modelling/Refresh 01/Analytical Datasets/Modelling AD/he_modelling_ad_11_03_2020.xlsx")
modelling_ad <- data.table(modelling_ad)



# Removing low revenue titles
modelling_ad[, net_he_revenue:=sum(he_revenue), by=c('imdb_title_code')]
modelling_ad <- modelling_ad[net_he_revenue > 5000000, ]

# Removing 0 entries in dependent variable and linear coop spends
modelling_ad <- modelling_ad[he_revenue > 0, ]
modelling_ad <- modelling_ad[he_linear_co_op_spend_adstock_linear0_837 > 0, ]

# Removing titles with no competitor effect variable
modelling_ad <- modelling_ad[competitor_effect_2_weeks>0, ]

# Taking first 30 weeks of HE Revenue
modelling_ad <- modelling_ad[he_week_number %in% c(0:30), ]


# Creating HE week flags where generally peaks are seen
modelling_ad[, he_week_0_flag := ifelse(he_week_number==0, 1, 0)]
modelling_ad[, he_week_1_flag := ifelse(he_week_number==1, 1, 0)]
modelling_ad[, he_week_13_flag := ifelse(he_week_number==13, 1, 0)]

# Creating BO window flag
modelling_ad[, bo_window := th_week_number-he_week_number]

# Creating franchise variables
modelling_ad[, dc_flag := ifelse(majorfranchise=='DC Extended Universe', 1, 0)]


# Creating Dummy Variable
modelling_ad <- data.table(dummy.data.frame(modelling_ad, 'metadata_source'))
modelling_ad <- data.table(dummy.data.frame(modelling_ad, 'mkt_genre_grouped'))
modelling_ad <- data.table(dummy.data.frame(modelling_ad, 'runtime_bin'))

# Train Test Splitting the data
train_data <- modelling_ad[th_release_year %in% c(2015, 2016, 2017, 2018), ]
test_data <- modelling_ad[th_release_year%in%c(2019), ]

# Imputing NA values for the demographics data variables with mode
Mode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}
age_mode <- Mode(train_data$age)
income_mode <- Mode(train_data$income)
gender_mode <- Mode(train_data$gender)


train_data[is.na(age), c('age')] <- age_mode
train_data[is.na(income), c('income')] <- income_mode
train_data[is.na(gender), c('gender')] <- gender_mode
test_data[is.na(age), c('age')] <- age_mode
test_data[is.na(income), c('income')] <- income_mode
test_data[is.na(gender), c('gender')] <- gender_mode

# Imputing NA values for gs data with median
max_median <- median(train_data$`max_google_search_volume_till_-4`, na.rm=T)
avg_median <- median(train_data$`avg_google_search_volume_till_-4`, na.rm=T)
total_median <- median(train_data$`total_google_search_volume_till_-4`, na.rm=T)
train_data[is.na(`max_google_search_volume_till_-4`), c('max_google_search_volume_till_-4')] <- max_median
train_data[is.na(`avg_google_search_volume_till_-4`), c('avg_google_search_volume_till_-4')] <- avg_median
train_data[is.na(`total_google_search_volume_till_-4`), c('total_google_search_volume_till_-4')] <- total_median
test_data[is.na(`max_google_search_volume_till_-4`), c('max_google_search_volume_till_-4')] <- max_median
train_data[is.na(`avg_google_search_volume_till_-4`), c('avg_google_search_volume_till_-4')] <- avg_median
train_data[is.na(`total_google_search_volume_till_-4`), c('total_google_search_volume_till_-4')] <- total_median

#train_data <- train_data[!is.na(competitor_index), ]
#test_data <- test_data[!is.na(competitor_index), ]

# Printing number of train and test titles
paste("Number of train titles:", length(unique(train_data$imdb_title_code)))
paste("Number of test titles:", length(unique(test_data$imdb_title_code)))



# Function for error calculation
error_metrics <- function(y_true, y_pred){
  mae <- mean(abs(y_true-y_pred))
  mape <- mean(abs(y_true-y_pred)/y_true)
  wmape <- sum(abs(y_true-y_pred))/sum(as.numeric(y_true))
  return(c(mae, mape, wmape))
}


# Function for outlier capping
outlier_capping <- function(x){
  quantiles <- quantile( x, c(.05, .95) )
  x[ x < quantiles[1] ] <- quantiles[1]
  x[ x > quantiles[2] ] <- quantiles[2]
  x
  
}

train_data[, he_revenue_capped:=lapply(.SD, outlier_capping), by=c('he_week_number'), .SDcols=c('he_revenue')]


# Building the model
lr_model <- lm(log(he_revenue_capped)~#log(he_week_number+1)+
                 #distribution_only+
                 he_week_0_flag+
                 #franchise_releases_in_last_5_years_bin+
                 he_week_1_flag+
                 dc_flag+
                 #holiday_flag+
                 #he_week_2_flag+
                 pst_sell_thru_week_1_flag+
                 #vod_week_0_flag+
                 #vod_week_0_flag+
                 #ivod_week_0_flag+
                 vod_week_1_flag+
                 ivod_week_1_flag+
                 #total_bo_spend+
                 #franchise_flag+
                 #dc_flag+
                 #bo_window+
                 #mpaa_rating+
                 `mkt_genre_groupedaction/adventure`+
                 mkt_genre_groupeddrama+
                 mkt_genre_groupedfamily+
                 log(actors_avg_rating+1)+
                 age+
                 runtime_bin120_130+
                 runtime_bin90_100+
                 runtime_bin100_110+
                 runtime_bin110_120+
                 runtime_binless_than_90+
                 `metadata_sourceBased on Fiction Book/Short Story`+
                 `metadata_sourceBased on Game`+
                 `metadata_sourceBased on Real Life Events`+
                 `metadata_sourceBased on Short Film`+
                 `metadata_sourceOriginal Screenplay`+
                 log(competitor_effect_2_weeks)+
                 log(he_digital_spend_adstock_linear0_839+1)+
                 log(he_digital_video_spend_adstock_linear0_845+1)+
                 log(he_non_digital_spend_adstock_linear0_84+1)+
                 log(he_linear_co_op_spend_adstock_linear0_837+1),
               data = train_data
)

# Checking post model properties
summary(lr_model)
plot(lr_model)
vif(lr_model)
residualPlots(lr_model)


# Calculating title-week level errors
train_data$predictions <-  exp(predict(lr_model, train_data))
test_data$predictions <-  exp(predict(lr_model, test_data))
train_data$error <- abs(train_data$predictions - train_data$he_revenue)
test_data$error <- abs(test_data$predictions - test_data$he_revenue)
error_metrics(train_data$he_revenue, exp(predict(lr_model, train_data)))
error_metrics(test_data$he_revenue, exp(predict(lr_model, test_data)))



# Calculating title level errors
train_data$predictions <-  exp(predict(lr_model, train_data))
test_data$predictions <-  exp(predict(lr_model, test_data))
title_train_data <- train_data[, j=list(predicitions=sum(predictions), he_revenue=sum(he_revenue)), by=c('imdb_title_code', 'imdb_title_name')]
title_test_data <- test_data[, j=list(predicitions=sum(predictions), he_revenue=sum(he_revenue)), by=c('imdb_title_code', 'imdb_title_name')]
paste("Train WAMPE:", error_metrics(title_train_data$he_revenue, title_train_data$predicitions)[3])
paste("Test WMAPE:", error_metrics(title_test_data$he_revenue, title_test_data$predicitions)[3])

# Removing Joker and then calculating errors
train_data$predictions <-  exp(predict(lr_model, train_data))
test_data$predictions <-  exp(predict(lr_model, test_data))
title_train_data <- train_data[, j=list(predicitions=sum(predictions), he_revenue=sum(he_revenue)), by=c('imdb_title_code', 'imdb_title_name')]
title_test_data <- test_data[, j=list(predicitions=sum(predictions), he_revenue=sum(he_revenue)), by=c('imdb_title_code', 'imdb_title_name')]
title_test_data <- title_test_data[imdb_title_name!='Joker', ]
paste("Train WAMPE:", error_metrics(title_train_data$he_revenue, title_train_data$predicitions)[3])
paste("Test WMAPE:", error_metrics(title_test_data$he_revenue, title_test_data$predicitions)[3])



# Plotting actual vs predicted average revenue trend across weeks for train data
plot_data <- train_data[, j=list(he_revenue=mean(he_revenue), pred=mean(predictions)), by=c('he_week_number')]
ggplot(data=plot_data, aes(x=he_week_number))+
  geom_line(aes(y=he_revenue), color='green')+
  geom_line(aes(y=pred), color='red')


# Plotting actual vs predicted average revenue trend across weeks for test data
plot_data <- test_data[, j=list(he_revenue=mean(he_revenue), pred=mean(predictions)), by=c('he_week_number')]
ggplot(data=plot_data, aes(x=he_week_number))+
  geom_line(aes(y=he_revenue), color='green')+
  geom_line(aes(y=pred), color='red')



ggplot(data=modelling_ad, aes(x=as.factor(mkt_genre_grouped), y=log(he_revenue)))+
  geom_boxplot()

# Writing data
fwrite(train_data, "E:\\WB_project\\daily_tasks\\2020\\february\\27022020\\train_predict_he.csv", row.names = F)
fwrite(test_data, "E:\\WB_project\\daily_tasks\\2020\\february\\27022020\\test_predict_he.csv", row.names = F)


# Writing data with only reuqired columns
subset_train_data <- train_data[, c('imdb_title_code', 'imdb_title_name', 'he_week_number', 'distribution_only', 'he_week_0_flag', 'franchise_releases_in_last_5_years_bin','he_week_1_flag', 'long_weekend_flag', 'pst_sellthru_week_1_flag', 'vod_week_1_flag', 'top3_competitor_index_2_weeks', 'he_spend_digital Adstock Linear0.841', 'he_spend_digital_video Adstock Linear0.848', 'he_spend_linear-coop Adstock Linear0.842', 'he_spend_non-digital Adstock Linear0.841', 'avg_wikipedia_page_views_till_-4', 'mkt_genre_grouped_horror_scifi_mystery', 'mkt_genre_grouped_family', 'runtime_bin100_to_110_mins', 'runtime_bin120_to_130_mins', 'runtime_binmore_than_130_mins', 'mkt_genre_grouped_drama', 'he_revenue', 'predictions', 'error')]
fwrite(subset_train_data, "E:\\WB_project\\daily_tasks\\november\\13112019\\train_predict_he_subset.csv", row.names = F)
subset_test_data <- test_data[, c('imdb_title_code', 'imdb_title_name', 'he_week_number', 'distribution_only', 'he_week_0_flag', 'franchise_releases_in_last_5_years_bin','he_week_1_flag', 'long_weekend_flag', 'pst_sellthru_week_1_flag', 'vod_week_1_flag', 'top3_competitor_index_2_weeks', 'he_spend_digital Adstock Linear0.841', 'he_spend_digital_video Adstock Linear0.848', 'he_spend_linear-coop Adstock Linear0.842', 'he_spend_non-digital Adstock Linear0.841', 'avg_wikipedia_page_views_till_-4', 'mkt_genre_grouped_horror_scifi_mystery', 'mkt_genre_grouped_family', 'runtime_bin100_to_110_mins', 'runtime_bin120_to_130_mins', 'runtime_binmore_than_130_mins', 'mkt_genre_grouped_drama', 'he_revenue', 'predictions', 'error')]
fwrite(subset_test_data, "E:\\WB_project\\daily_tasks\\november\\13112019\\test_predict_he_subset.csv", row.names = F)

lr_model <- lm(log(he_revenue_capped)~#log(he_week_number+1)+
                 #distribution_only+
                 he_week_0_flag+
                 #franchise_releases_in_last_5_years_bin+
                 he_week_1_flag+
                 dc_flag+
                 #holiday_flag+
                 #he_week_2_flag+
                 pst_sell_thru_week_1_flag+
                 #vod_week_0_flag+
                 #vod_week_0_flag+
                 #ivod_week_0_flag+
                 vod_week_1_flag+
                 ivod_week_1_flag+
                 #total_bo_spend+
                 #franchise_flag+
                 #dc_flag+
                 #bo_window+
                 #mpaa_rating+
                 `mkt_genre_groupedaction/adventure`+
                 mkt_genre_groupeddrama+
                 mkt_genre_groupedfamily+
                 scale(log(actors_avg_rating+1))+
                 age+
                 runtime_bin120_130+
                 runtime_bin90_100+
                 runtime_bin100_110+
                 runtime_bin110_120+
                 runtime_binless_than_90+
                 `metadata_sourceBased on Fiction Book/Short Story`+
                 `metadata_sourceBased on Game`+
                 `metadata_sourceBased on Real Life Events`+
                 `metadata_sourceBased on Short Film`+
                 `metadata_sourceOriginal Screenplay`+
                 scale(log(competitor_effect_2_weeks))+
                 scale(log(he_digital_spend_adstock_linear0_839+1))+
                 scale(log(he_digital_video_spend_adstock_linear0_845+1))+
                 scale(log(he_non_digital_spend_adstock_linear0_84+1))+
                 scale(log(he_linear_co_op_spend_adstock_linear0_837+1)),
               data = train_data
)

# Checking post model properties
summary(lr_model)
