# -*- coding: utf-8 -*-
"""
Created on Mon Feb 25 12:00:55 2019

@author: amit
"""
import re
import pandas as pd
import numpy as np


def extract_day(date):
    try:
        day = re.search(r'(\d{1,2})([\s-])', date).group(1)
    except AttributeError:
        day = "None"
    return day


def extract_month(date):
    try:
        month = re.search(r'([\s-])(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|January|\
                February|March|April|May|June|July|August|September|\
                October|November|December|\d{2})', date).group(2)
    except AttributeError:
        month = "None"
    if month == "None":
        return month
    elif len(month)>2:
        return month[0:3]
    else:
        return month


def extract_year(date):
    try:
        year = re.search(r'([\s-])(\d{2,4})', date).group(2)
    except AttributeError:
        year = "None"

    if year == 'None':
        try:
            year = re.search(r'(\d{2,4})', date).group(0)
        except AttributeError:
            year = 'None'

    if year != "None":
        if (len(year) == 2) & (int(year) <= 20):
            year = int(year)+2000
        elif (len(year) == 2) & (int(year) > 20):
            year = int(year)+1900
    return str(year)


def string_to_date(dataframe):
    try:
        dataframe['us_release_date'] = pd.to_datetime(
                     dataframe['us_release_date'], format='%d-%b-%Y')
    except ValueError:
        try:
            dataframe['us_release_date'] = pd.to_datetime(
                         dataframe['us_release_date'], format='%d-%m-%Y')
        except:
            dataframe['us_release_date'] = np.nan
        
    return dataframe['us_release_date']


def convert_to_date(dataframe):
    dataframe_corrected = dataframe.copy()
    dataframe_corrected.rename(columns={'US.Release.Date': 'us_release_date'},
                     inplace=True)
    dataframe_corrected['day'] = dataframe_corrected['us_release_date'].apply(
            lambda x: extract_day(str(x)))
    dataframe_corrected['month'] = dataframe_corrected['us_release_date'].apply(
            lambda x: extract_month(str(x)))
    dataframe_corrected['year'] = dataframe_corrected['us_release_date'].apply(
            lambda x: extract_year(str(x)))
    dataframe_corrected['us_release_date'] = dataframe_corrected['day']+'-'+dataframe_corrected['month']+'-'+dataframe_corrected['year']
    dataframe_corrected['us_release_date'] = dataframe_corrected.apply(
            lambda x: string_to_date(x), axis=1)
    return dataframe_corrected



#
#date = "4 January 2019 (India) See more »"
#
#test_df = IMDB_subset_data.head(1)
#test_df.rename(columns={'US Release Date': 'US.Release.Date', 
#                                 'Movie Name': 'Movie.Name'}, inplace=True)
#
#dataframe = test_df
#
#
#temp = convert_to_date(test_df.copy())









