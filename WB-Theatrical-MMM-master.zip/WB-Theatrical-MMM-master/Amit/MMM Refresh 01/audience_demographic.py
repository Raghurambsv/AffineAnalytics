# -*- coding: utf-8 -*-
"""
Created on Fri Mar  6 16:56:06 2020

@author: amit
"""
import pandas as pd
import re

# Helper Function to clean the column names text
def to_lower(x):
    return ([re.sub(r"[^A-Za-z0-9]", "_", item.lower().strip()) for item in x])


def audience_demographics(base_ad):
    demo_data = pd.read_csv(r"E:\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\2019-12-20_Audience-Demos.csv")
    demo_data.columns = to_lower(demo_data.columns)
    demo_data = demo_data.loc[demo_data['release_period']=='lifetime', :]
    grouped_data = demo_data.loc[demo_data.groupby(['imdb_title_code', 'metric_grouped'])['value'].idxmax(), :]
    grouped_data.rename(columns={'metric': 'major_demo_category',
                                 'value': 'major_demo_category_value'}, inplace=True)
    grouped_data = pd.pivot_table(grouped_data, index=['imdb_title_code'], columns=['metric_grouped'],
                                  values='major_demo_category', aggfunc='first').reset_index()
    base_ad = pd.merge(base_ad, grouped_data,
                       how='left',
                       on='imdb_title_code')
    return base_ad








