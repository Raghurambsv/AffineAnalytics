# @author:rolee agarwal
# Created on 24th January, 2020 16:25 PM

# Importing required libraries
import pandas as pd
import numpy as np
import bs4
from requests import get
import re

def get_url_list(title,yor):
    url=r"https://www.the-numbers.com/movie/"+str(title).replace(' ','-')+str('-(')+str(yor)+str(')#tab=summary')
    return url

def get_url_list_2(title):
    url=r"https://www.the-numbers.com/movie/"+str(title).replace(' ','-')+str('#tab=summary')
    return url

def get_title(title):
    lst=title.split(' ')
    lst1=[]
    if lst[0] in {'A', 'An', 'The'}:
        for i in range(0, len(lst) - 1):
            lst1.append(lst[i + 1])
    lst1.append(lst[0])
    title=" ".join(lst1)
    return title


def get_td_text(lst,txt):
    for index, item in enumerate(lst):
        if item.get_text()==txt:
            i=index+1
            return lst[i].get_text()

    return 0

def get_summary(title_list):
    url_list=[]
    title_code=[]
    name_list = []
    source_list = []
    franchise_list = []
    mpaa_list=[]
    running_time_list=[]
    domestic_box_office_list=[]
    international_box_office_list = []
    worldwide_box_office_list=[]
    est_domestic_dvd_sales=[]
    est_domestic_bluray_sales=[]
    total_est_domestic_video_sales=[]
    opening_weekend=[]
    legs=[]
    domestic_share=[]
    genre_list=[]
    production_method_list=[]
    creative_type_list=[]
    production_countries=[]
    languages=[]
    theatre_counts=[]
    infl_adj_list=[]
    domestic_releases=[]
    international_releases=[]
    video_release=[]
    comparisons=[]
    keywords=[]
    production_companies=[]
    missing_name_list=[]
    collated_output = pd.DataFrame(columns=["Name", "Date", "Rank", "Gross", "%YD", "%LW", "Theaters", "Per Theater", "Total Gross", "Days"])

    for i, title in enumerate(title_list['Title Name']):
        print(i)

        url=get_url_list(title,title_list['Year of Release'][i])
        title = re.sub(r"[^a-zA-Z0-9\s]+", '', title)
        print(title)
        response = get(url)
        if response.status_code!=200:
            url=get_url_list_2(title)
            response=get(url)
        if response.status_code!=200:
            title=get_title(title)
            url=get_url_list_2(title)
            response=get(url)
        if response.status_code!=200:
            url=get_url_list(title,title_list['Year of Release'][i])
            response=get(url)
        if response.status_code==200:
            soup = bs4.BeautifulSoup(response.text, 'lxml')
            # SOURCE
            try:
                url_list.append(url)
            except:
                url_list.append('NA')
            try:
                source_list.append(soup.find_all('a', href=re.compile(r"/market/source/"))[0].get_text().strip())
            except:
                source_list.append('NA')

            # FRANCHISE
            # franchise_list.append(soup.find_all('a',href=re.compile(r"/movies/franchise"))[1].get_text().strip())

            # MPAA
            try:
                mpaa_list.append(soup.find_all('a', href=re.compile(r"/market/mpaa-rating/"))[0].get_text().strip())
            except:
                mpaa_list.append('NA')

            # Genre
            try:
                genre_list.append(soup.find_all('a', href=re.compile(r"/market/genre/"))[0].get_text().strip())
            except:
                genre_list.append('NA')

            # Production method
            try:
                production_method_list.append(soup.find_all('a', href=re.compile(r"/market/production-method/"))[0].get_text().strip())
            except:
                production_method_list.append('NA')

            # Creative Type
            # creative_type_list.append(soup.find_all('a',href=re.compile(r"/market/creative-type/"))[0].get_text().strip())

            # NAME
            # name = soup.find_all('h1', itemprop='name')[0].get_text().strip()
            # clean_name = re.sub(r"[^a-zA-Z0-9]+", ' ', name)
            try:
                name_list.append(title)
            except:
                name_list.append('NA')
            # try:
            #     title_code.append(title_list['Title Code'][i])
            # except:
            #     title_code.append('NA')

            # table=soup.find('table',id='movie_finances')
            list1 = soup.find_all('td')
            domestic_box_office_list.append(get_td_text(list1, 'Domestic Box Office'))
            international_box_office_list.append(get_td_text(list1, 'International Box Office'))
            worldwide_box_office_list.append(get_td_text(list1, 'Worldwide Box Office'))
            est_domestic_dvd_sales.append(get_td_text(list1, 'Est. Domestic DVD Sales'))
            est_domestic_bluray_sales.append(get_td_text(list1, 'Est. Domestic Blu-ray Sales'))
            total_est_domestic_video_sales.append(get_td_text(list1, 'Total Est. Domestic Video Sales'))
            running_time_list.append(get_td_text(list1, 'Running Time:'))
            production_countries.append(get_td_text(list1, 'Production Countries:'))
            legs.append(get_td_text(list1, 'Legs:'))
            domestic_share.append(get_td_text(list1, 'Domestic Share:'))
            languages.append(get_td_text(list1, 'Languages:'))
            infl_adj_list.append(get_td_text(list1, 'Infl. Adj. Dom. BO'))
            domestic_releases.append(get_td_text(list1, 'Domestic Releases:'))
            international_releases.append(get_td_text(list1, 'International Releases:'))
            theatre_counts.append(get_td_text(list1, 'Theater counts:'))
            franchise_list.append(get_td_text(list1, 'Franchise:'))
            comparisons.append(get_td_text(list1, 'Comparisons:'))
            keywords.append(get_td_text(list1, 'Keywords:'))
            production_companies.append(get_td_text(list1, 'Production Companies:'))
            try:
                for index, item in enumerate(list1):
                    clean_name_list = re.sub(r"[^a-zA-Z0-9]+", ' ', item.get_text().strip()).split()
                    len_clean_name_list = len(clean_name_list)
                    if len_clean_name_list > 1:
                        if clean_name_list[0] == 'Opening' and clean_name_list[len_clean_name_list - 1] == 'Weekend':
                            i = index + 1
                opening_weekend.append(list1[i].get_text())
            except:
                opening_weekend.append('NA')

            try:
                for index, item in enumerate(list1):
                    clean_name_list = re.sub(r"[^a-zA-Z0-9]+", ' ', item.get_text().strip()).split()
                    len_clean_name_list = len(clean_name_list)
                    if len_clean_name_list > 1:
                        if clean_name_list[0] == 'Video' and clean_name_list[len_clean_name_list - 1] == 'Release':
                            i = index + 1
                video_release.append(list1[i].get_text())
            except:
                video_release.append('NA')

            try:
                for index, item in enumerate(list1):
                    clean_name_list = re.sub(r"[^a-zA-Z0-9]+", ' ', item.get_text().strip()).split()
                    len_clean_name_list = len(clean_name_list)
                    if len_clean_name_list > 1:
                        if clean_name_list[0] == 'Creative' and clean_name_list[len_clean_name_list - 1] == 'Type':
                            i = index + 1
                creative_type_list.append(list1[i].get_text())
            except:
                creative_type_list.append('NA')


            try:
                for i in soup.find_all('h2'):
                    if i.get_text() == 'Daily Box Office Performance':
                        table = i.find_next("table")

                base_list = []
                for tr in table.find_all('tr')[1:]:
                    tds = tr.find_all('td')
                    try:
                        temp_list = [title, tds[0].text, tds[1].text, tds[2].text, tds[3].text, tds[4].text, tds[5].text,
                                     tds[6].text, tds[7].text, tds[8].text]
                    except:
                        temp_list = []
                    base_list.append(temp_list)

                temp_output = pd.DataFrame(base_list,
                                           columns=["Name", "Date", "Rank", "Gross", "%YD", "%LW", "Theaters",
                                                    "Per Theater", "Total Gross", "Days"])
                temp_output.dropna(axis=0, how='all', inplace=True)
                collated_output = collated_output.append(temp_output)
                collated_output = collated_output[["Name", "Date", "Rank", "Gross", "%YD", "%LW", "Theaters", "Per Theater", "Total Gross", "Days"]]
                print(title)
                # temp_output['Title']=url.strip().split('movie')[1].split('-')[0].replace('/',' ')
                # temp_output['Year Of Release']=url.strip().split('movie')[1].split('-')[1].split('#')[0].replace('(',' ').replace(')',' ')
            except:
                continue

        else:
            missing_name_list.append(title)


    d = {'URL':url_list,'Name': name_list, 'Source': source_list, 'Franchise': franchise_list,'Domestic Box Office': domestic_box_office_list,'International Box Office': international_box_office_list,
            'WorldWide Box Office': worldwide_box_office_list, 'Est. Domestic DVD Sales': est_domestic_dvd_sales,'Est. Domestic Blu-ray Sales': est_domestic_bluray_sales,
                 'Total Est. Domestic Video Sales': total_est_domestic_video_sales, 'Legs': legs,'Domestic Share': domestic_share, 'MPAA': mpaa_list, 'Running Time': running_time_list,
                 'Genre': genre_list, 'Production Method': production_method_list, 'Creative Type': creative_type_list,'Prodcution Countries': production_countries, 'Languages': languages,
                 'Infl. Adj. Dom. BO': infl_adj_list, 'Domestic Release dates': domestic_releases,'International Release dates': international_releases, 'Theatre Counts': theatre_counts,
                 'Opening Weekend': opening_weekend, 'Video Release': video_release,'Production Companies': production_companies, 'Comparisons': comparisons, 'KeyWords': keywords}
    df = pd.DataFrame(data=d)
    mt=pd.DataFrame(data=missing_name_list)

    return df,mt,collated_output



title_list=pd.read_excel(r"E:\WB_project\daily_tasks\2020\february\27022020\demographic_data_titles.xlsx")
summary,missing_titles,daily_box_office=get_summary(title_list)
summary.to_excel(r"E:\WB_project\daily_tasks\2020\february\27022020\demographic_data_titles_genre_v2.xlsx", index=False)

missing_titles.to_excel(r"C:\Users\rolee\Desktop\Unscrapped titles.xlsx",index=False)

with pd.ExcelWriter(r'C:\Users\rolee\Desktop\Scrapping_the_numbers_27thJan.xlsx',engine='xlsxwriter',mode='w') as writer:
    summary.to_excel(writer,sheet_name='Summary',index=False)
    daily_box_office.to_excel(writer,sheet_name='Daily_Box_Office',index=False)
writer.save()
