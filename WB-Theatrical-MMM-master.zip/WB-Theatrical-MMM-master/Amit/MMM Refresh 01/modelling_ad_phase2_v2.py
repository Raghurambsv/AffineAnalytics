# -*- coding: utf-8 -*-
"""
Created on Fri Aug 16 14:07:06 2019

@author: amit
"""
import os
os.chdir(r"E:\WB_project\daily_tasks\2020\february\27022020")
import cast_rating
import franchise
import holiday_metrics
import pandas as pd
import numpy as np
import re
from AdstockClass import Adstock
from datetime import datetime
import audience_demographic


# Helper Function to clean the column names text
def to_lower(x):
    return ([re.sub(r"[^A-Za-z0-9]", "_", item.lower().strip()) for item in x])

# Helper Function for creating GS data features
def gs_metrics(base_ad, snapshot, week_number_colname):
    gs_data = pd.read_excel(r"E:\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\Google Search Data\Google Search Data_ver1_v2.xlsx")
    gs_data.columns = to_lower(gs_data)
    metric = "google_search_volume"
    gs_data[metric+'_'+str(snapshot)] = gs_data.apply(lambda x: np.nan if x[week_number_colname]>=snapshot else x[metric], axis=1)
    # Creating some basic mean/max variables out of the combined variables
    gs_data['max_'+metric+'_till_'+str(snapshot)] = gs_data.groupby(['imdb_title_code'])[metric+'_'+str(snapshot)].transform('max')
    gs_data['avg_'+metric+'_till_'+str(snapshot)] = gs_data.groupby(['imdb_title_code'])[metric+'_'+str(snapshot)].transform('mean')
    gs_data['total_'+metric+'_till_'+str(snapshot)] = gs_data.groupby(['imdb_title_code'])[metric+'_'+str(snapshot)].transform('sum')
    # Merging back with the base_ad
    base_ad = pd.merge(base_ad, gs_data[['imdb_title_code', 'max_'+metric+'_till_'+str(snapshot), 'avg_'+metric+'_till_'+str(snapshot), 'total_'+metric+'_till_'+str(snapshot)]].drop_duplicates(),
                                                   on=['imdb_title_code'],
                                                   how='left')
    return base_ad


# Main Function to create features, this function uses all the global variables and dataframes
def create_modelling_ad(ad_for):
    # Reading all the required base files first
    holiday_calender = pd.read_csv(os.path.join(SHAREPOINT_PATH, r"WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\US Holiday Calendar_Exhaustive.csv"))
    base_ad = pd.read_excel(os.path.join(SHAREPOINT_PATH, r"WB Theatrical - Documents\04. Media Mix Modelling\Refresh 01\Analytical Datasets\Base AD\Base AD_v1.0.xlsx"))
    genre_data = pd.read_excel(os.path.join(SHAREPOINT_PATH, r"WB Theatrical - Documents\01. Data Harmonization-Cleaning\01. Base Data - As received\03. Movie Metadata\Genre Mapping\Mkt Genre_Grouped_final.xlsx"))
    imdb_data = pd.read_csv(os.path.join(SHAREPOINT_PATH, r"WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\03. Movie Metadata\IMDB Data Files\IMDB_scrapped_titles_v5.csv"))
    distribution_only = pd.read_excel(r"E:\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\Distribution only flag.xlsx")
    # Cleaning the column names of all the data sources
    holiday_calender.columns = to_lower(holiday_calender.columns)
    base_ad.columns = to_lower(base_ad.columns)
    genre_data.columns = to_lower(genre_data.columns)
    imdb_data.columns = to_lower(imdb_data.columns)
    distribution_only.columns = to_lower(distribution_only.columns)
    # Creating some basic features
    base_ad['th_release_year'] = base_ad['theatrical_release_date'].dt.strftime('%Y')
    base_ad['th_release_month'] = base_ad['theatrical_release_date'].dt.strftime('%b')
    base_ad['he_revenue'] = base_ad[['blu_ray_sell_thru_revenue', 'blu_ray_rental_revenue',
                                     'dvd_sell_thru_revenue', 'dvd_rental_revenue',
                                     'est_sell_thru_revenue', 'ivod_rental_revenue',
                                     'vod_rental_revenue']].sum(axis=1)
    # Creating franchise features
    updated_ad = franchise.get_average_earnings(base_ad)
    updated_ad = franchise.last_release_duration(updated_ad)
    updated_ad = franchise.franchise_flag(updated_ad)
    updated_ad = franchise.count_of_movies_in_franchise(updated_ad, 5)
    
    # Creating imdb related variables
    imdb_data.rename(columns={'titleid': 'imdb_title_code'}, inplace=True)
    updated_ad = pd.merge(updated_ad, imdb_data[['imdb_title_code', 'budget', 'runtime',
                                                     'openingweekendus', 'mpaa_rating']],
                          on='imdb_title_code',
                          how='left')
    updated_ad = cast_rating.create_cast_rating(updated_ad, imdb_data, 'actor')
    updated_ad = cast_rating.create_cast_rating(updated_ad, imdb_data, 'director')
    updated_ad['cast_avg_rating'] = np.nanmean([updated_ad['actors_avg_rating'], updated_ad['directors_avg_rating']], axis=0)
    updated_ad.fillna({'cast_avg_rating': updated_ad['cast_avg_rating'].mean()}, inplace=True)
    updated_ad.columns = to_lower(updated_ad.columns)
    
    # Imputing franchise variable to be 1 for certain movies-Detective Pikachu, Ocean's Eight
    updated_ad.loc[updated_ad['imdb_title_code']=='tt5884052', 'franchise_flag'] = 1
    updated_ad.loc[updated_ad['imdb_title_code']=='tt5884052', 'avg_earnings_franchise'] = 26317654.5
    updated_ad.loc[updated_ad['imdb_title_code']=='tt5164214', 'franchise_flag'] = 1
    updated_ad.loc[updated_ad['imdb_title_code']=='tt5164214', 'avg_earnings_franchise'] = 142038718.5
    
    # Creating holiday flag
    updated_ad = holiday_metrics.holiday_flag(updated_ad, 'date', 'week_start_date', holiday_calender)
    updated_ad = holiday_metrics.long_weekend_flag(updated_ad, 'date', 'week_start_date', holiday_calender)
    
    # Creating MKT genre variable
    updated_ad = pd.merge(updated_ad, genre_data[['imdb_title_code', 'mkt_genre_grouped']],
                          on='imdb_title_code',
                          how='left')
    
    # Creating distribution only flag
    updated_ad = pd.merge(updated_ad, distribution_only[['imdb_title_code', 'distribution_only']],
                          on='imdb_title_code',
                          how='left')
    # Pre processing the runtime variables
    updated_ad['runtime'] = updated_ad['runtime'].apply(lambda x: int(x.split()[0]))
    updated_ad['runtime_bin'] = pd.cut(updated_ad['runtime'], bins= [80, 90, 100, 110, 120, 130, 200],
                                     labels = ['less_than_90', '90_100', '100_110', '110_120', '120_130', 'more_than_130'])
    updated_ad['runtime_bin'] =  updated_ad['runtime_bin'].astype(object)
    updated_ad = audience_demographic.audience_demographics()
    updated_ad = gs_metrics(updated_ad, -4, 'week_number')
    # Creating bo and he respecitve variables for spend
    if 'bo' in ad_for.lower():
        # Creating spends adstock variables
        adstock_instance = Adstock(base_dataframe=updated_ad, dictionary_spends={'bo_digital_spend': [0.1, 'Linear'],
                                                                             'bo_digital_video_spend': [0.1, 'Linear'],
                                                                             'bo_total_linear_spend': [0.1, 'Linear'],
                                                                             'bo_total_radio_spend': [0.1, 'Linear'],
                                                                             'bo_ooh_experiential_spend': [0.1, 'Linear'],
                                                                             'bo_outdoor_print_spend': [0.1, 'Linear']},
                               week_number_colname='th_week_number',
                               revenue_colname='bo_revenue')
        updated_ad = adstock_instance.optimise_adstock()
    elif 'he' in ad_for.lower():
        # Creating spends adstock variables
        adstock_instance = Adstock(base_dataframe=updated_ad, dictionary_spends={'he_digital_spend': [0.1, 'Linear'],
                                                                             'he_digital_video_spend': [0.1, 'Linear'],
                                                                             'he_non_digital_spend': [0.1, 'Linear'],
                                                                             'he_linear_co_op_spend': [0.1, 'Linear']},
                               week_number_colname='th_week_number',
                               revenue_colname='he_revenue')
        updated_ad = adstock_instance.optimise_adstock()
        temp = updated_ad.loc[updated_ad['he_revenue']>0, ].copy()
        temp['first_he_release_date'] = temp.groupby('imdb_title_code')['week_start_date'].transform('min')
        updated_ad = pd.merge(updated_ad, temp[['imdb_title_code', 'first_he_release_date']].drop_duplicates(),
                           how='left',
                           on=['imdb_title_code'])
        updated_ad['he_week_number'] = updated_ad.apply(lambda x: (x['week_start_date']-x['first_he_release_date']).days/7, axis=1)
        
        # Creating EST week since launch column in the data
        temp = updated_ad.loc[updated_ad['est_sell_thru_revenue']>0, ].copy()
        temp['first_est_release_date'] = temp.groupby('imdb_title_code')['week_start_date'].transform('min')
        updated_ad = pd.merge(updated_ad, temp[['imdb_title_code', 'first_est_release_date']].drop_duplicates(),
                           how='left',
                           on=['imdb_title_code'])
        updated_ad['est_week_number'] = updated_ad.apply(lambda x: (x['week_start_date']-x['first_est_release_date']).days/7, axis=1)
    
        # Creating PST week since launch column in the data
        updated_ad['pst_sell_thru_revenue'] = updated_ad[['dvd_sell_thru_revenue', 'blu_ray_sell_thru_revenue']].sum(axis=1)
        temp = updated_ad.loc[updated_ad['pst_sell_thru_revenue']>0, ].copy()
        temp['first_pst_release_date'] = temp.groupby('imdb_title_code')['week_start_date'].transform('min')
        updated_ad = pd.merge(updated_ad, temp[['imdb_title_code', 'first_pst_release_date']].drop_duplicates(),
                           how='left',
                           on=['imdb_title_code'])
        updated_ad['pst_week_number'] = updated_ad.apply(lambda x: (x['week_start_date']-x['first_pst_release_date']).days/7, axis=1)
        
        # Creating iVOD week since launch column in the data
        temp = updated_ad.loc[updated_ad['vod_rental_revenue']>0, ].copy()
        temp['first_vod_release_date'] = temp.groupby('imdb_title_code')['week_start_date'].transform('min')
        updated_ad = pd.merge(updated_ad, temp[['imdb_title_code', 'first_vod_release_date']].drop_duplicates(),
                           how='left',
                           on=['imdb_title_code'])
        updated_ad['vod_week_number'] = updated_ad.apply(lambda x: (x['week_start_date']-x['first_vod_release_date']).days/7, axis=1)
        
        # Creating cVOD week since launch column in the data
        temp = updated_ad.loc[updated_ad['ivod_rental_revenue']>0, ].copy()
        temp['first_ivod_release_date'] = temp.groupby('imdb_title_code')['week_start_date'].transform('min')
        updated_ad = pd.merge(updated_ad, temp[['imdb_title_code', 'first_ivod_release_date']].drop_duplicates(),
                           how='left',
                           on=['imdb_title_code'])
        updated_ad['ivod_week_number'] = updated_ad.apply(lambda x: (x['week_start_date']-x['first_ivod_release_date']).days/7, axis=1)

        # Creating week0-1 flags
        updated_ad['est_week_1_flag'] = updated_ad.apply(lambda x: 1 if x['est_week_number']==1 else 0, axis=1)
        updated_ad['pst_sell_thru_week_0_flag'] = updated_ad.apply(lambda x: 1 if x['pst_week_number']==0 else 0, axis=1)
        updated_ad['pst_sell_thru_week_1_flag'] = updated_ad.apply(lambda x: 1 if x['pst_week_number']==1 else 0, axis=1)
        updated_ad['vod_week_0_flag'] = updated_ad.apply(lambda x: 1 if x['vod_week_number']==0 else 0, axis=1)
        updated_ad['vod_week_1_flag'] = updated_ad.apply(lambda x: 1 if x['vod_week_number']==1 else 0, axis=1)
        updated_ad['ivod_week_0_flag'] = updated_ad.apply(lambda x: 1 if x['ivod_week_number']==0 else 0, axis=1)
        updated_ad['ivod_week_1_flag'] = updated_ad.apply(lambda x: 1 if x['ivod_week_number']==1 else 0, axis=1)
        updated_ad.columns = to_lower(updated_ad.columns)

    return updated_ad


today_date = datetime.now().date().strftime(format="%d_%m_%Y")
SHAREPOINT_PATH = "E:\Affine Analytics Pvt Ltd"
bo_modelling_ad = create_modelling_ad('bo')
he_modelling_ad = create_modelling_ad('he')

bo_modelling_ad.to_excel(os.path.join(SHAREPOINT_PATH, r"WB Theatrical - Documents\04. Media Mix Modelling\Refresh 01\Analytical Datasets\Modelling AD\bo_modelling_ad_"+today_date+".xlsx"), index=False)
he_modelling_ad.to_excel(os.path.join(SHAREPOINT_PATH, r"WB Theatrical - Documents\04. Media Mix Modelling\Refresh 01\Analytical Datasets\Modelling AD\he_modelling_ad_"+today_date+".xlsx"), index=False)
