# -*- coding: utf-8 -*-
"""
Created on Wed Mar  4 11:53:05 2020

@author: amit
"""
import statsmodels.api as sm
import statsmodels.formula.api as smf
import numpy as np
import pandas as pd

modelling_ad = pd.read_excel(r"E:\Affine Analytics Pvt Ltd\WB Theatrical - Documents\04. Media Mix Modelling\Refresh 01\Analytical Datasets\Modelling AD\he_modelling_ad_02_03_2020.xlsx")

# Dropping titles without linear coop spends
modelling_ad.set_index('imdb_title_name', inplace=True)
titles_without_linearcoop = modelling_ad.loc[modelling_ad.groupby('imdb_title_name')['he_linear_co_op_spend'].sum()==0].index.drop_duplicates()
print("Titles without linear coop: ", titles_without_linearcoop.values)
modelling_ad = modelling_ad.drop(titles_without_linearcoop, axis=0)

# Removing very low revenue titles
REVENUE_CUTOFF = 5000000
low_revenue_titles = modelling_ad.loc[modelling_ad.groupby('imdb_title_name')['he_revenue'].sum()<=REVENUE_CUTOFF].index.drop_duplicates()
print("Titles with low Revenue: ", low_revenue_titles.values)
modelling_ad = modelling_ad.drop(low_revenue_titles, axis=0)
# Removing 0 entries from dependent variable
modelling_ad = modelling_ad.loc[modelling_ad['he_revenue']>0, :]
# Taking first 30 weeks of HE revenue
modelling_ad = modelling_ad.loc[modelling_ad['he_week_number'].isin(np.arange(0, 30)), :]
# Creating HE week flags where generally peaks and dips are seen
modelling_ad['he_week_0_flag'] = modelling_ad['he_week_number'].apply(lambda x: 1 if x==0 else 0)
modelling_ad['he_week_1_flag'] = modelling_ad['he_week_number'].apply(lambda x: 1 if x==0 else 0)
# Creating BO window variables
modelling_ad['bo_window'] = modelling_ad['th_week_number'] - modelling_ad['he_week_number']
# Binning the franchise release in last 5 years variable
modelling_ad['franchise_release_bin_5_years'] = modelling_ad['franchise_releases_in_last_5_years'].apply(
                                                lambda x: "zero" if x==0 else "one" if x==1 else "more_than_one")
# Binning the runtime variable
modelling_ad['runtime'] = modelling_ad['runtime'].apply(lambda x: int(x.split()[0]))
modelling_ad['runtime_bin'] = pd.cut(modelling_ad['runtime'], bins= [90, 100, 110, 120, 130, 164],
                                     labels = ['90_100', '100_110', '110_120', '120_130', 'more_than_130'])

# Splitting the train and test data
train_data = modelling_ad.loc[modelling_ad['th_release_year'].isin([2016, 2017, 2018]), :]
test_data = modelling_ad.loc[modelling_ad['th_release_year'].isin([2019]), :]

# Pringiting the # titles
print("# Train Titles: ", train_data['imdb_title_code'].nunique())
print("# Test Titles: ", test_data['imdb_title_code'].nunique())


def error_metrics(y_true, y_pred):
    mae = np.mean(np.abs(y_true-y_pred))
    mape = np.mean(np.abs(y_true-y_pred))
    wmape = np.sum(np.abs(y_true-y_pred))/np.sum(y_true)
    return (mae, mape, wmape)






dat = sm.datasets.get_rdataset("Guerry", "HistData").data
results = smf.ols('Lottery ~ Literacy + np.log(Pop1831)', data=dat).fit()
results_summary = results.summary()

# Note that tables is a list. The table at index 1 is the "core" table. Additionally, read_html puts dfs in a list, so we want index 0
results_as_html = results_summary.tables[1].as_html()
temp = pd.read_html(results_as_html, header=0, index_col=0)[0]
