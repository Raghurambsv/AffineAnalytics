# -*- coding: utf-8 -*-
"""
Created on Wed Feb 27 17:02:24 2019

@author: Amit
"""

import date_extraction
import pandas as pd
import numpy as np

def trim(x):
    return str(x).strip()


def create_average_rating(df, column, actor_director):
    """
    Function to create average past ratings of the actors/directors
    Parameters
    ---------
    df: Pandas Dataframe
        The original dataframe in which the metric is to be calculated
    column: String
        Name of the column whose metric is to be calculated
    actor_director: String
        Either of one of the two; 'Actor' or 'Director'
    Returns
    -------
    Pandas Dataframe: The updated dataframe with earnings of the
    actors/directors
    """

    # Sorting the resultant dataframe so as to calculate cumulative average
    df = df.sort_values(
            by=[actor_director, 'us_release_date'])
    df.reset_index(inplace=True, drop=True)

    # Creating a lagged column of variable, which will be used to calculate
    # cumulative average in the next step
    df[str('lagged_')+column] = df.groupby(
            [actor_director])[column].shift(1)

    # Creating a cumulative average column
    df_grouped = df.groupby(
                [actor_director],
                as_index=False)[str('lagged_')+column].expanding(1).mean()
    df_grouped.reset_index(inplace=True, drop=True)
    df[str('average_previous_')+column] = df_grouped

    return df



#### Main Function ####
def create_cast_rating(dataframe, scrapped_info, actor_director):
    """
    Function to calculate the actor/director past ratings
    Parameters
    ----------
    dataframe: Pandas Dataframe
        The original base dataframe in which metrics are to be calculated. It
        must have columns: 'imdb_title_code'
    scrapped_info: Pandas Dataframe
        The actor/director info dataframe at Title ID level. It must have
        columns: 'imdb_title_code','Actors/Directorsurl', 'Budget',
        'Gross_US'
    actor_director: String
        Either of one of the two; 'Actor' or 'Director'
    Returns
    -------
    Pandas dataframe: The updated dataframe with Average ratings for actors/directors
    """
    # Creating a backup version
    scrapped_info_ = scrapped_info.copy()
    
    scrapped_info_.rename(columns={'titleID':'imdb_title_code'}, inplace=True)
    # Extracting the date column
    scrapped_info_ = date_extraction.convert_to_date(scrapped_info_)
    scrapped_info_ = scrapped_info_.dropna(subset=['us_release_date'])
    # Setting maximum number of actors to 4 and directors to 2
    if actor_director == 'actor':
        maxlen = 4
    else:
        maxlen = 2

    # Splitting the actors/directors to columns
    scrapped_info_[actor_director+'s'+'url'] = scrapped_info_[actor_director+'s'+'url'].apply(lambda x: str(x))
    temp = scrapped_info_[actor_director+'s'+'url'].str.replace('[','').str.replace("\'",'').str.replace(']','').\
                                                    str.split(",", expand=True)
    temp = temp.applymap(trim)
    temp = temp.iloc[:, 0:maxlen]
    # Renaming the columns
    temp.columns = [str(actor_director)+'_'+str(i) for i in range(maxlen)]
    scrapped_info_ = pd.concat([scrapped_info_, temp], axis=1)

    # Converting the Title ID level dataframe to an exhaustive
    # ActorID-titleID level dataframe

    cast_level_data = pd.melt(scrapped_info_, 
                              id_vars=['imdb_title_code','us_release_date',
                                       'rating'],
                 value_vars = temp.columns)
    
    cast_level_data = cast_level_data.replace(['None', 'nan'] ,np.nan)
    cast_level_data.dropna(subset=['value'],inplace=True)
    cast_level_data.rename(columns={'value': actor_director}, inplace=True)


    # Calling the helper functions to calculate Average Earnings and ROI
    cast_level_data = create_average_rating(
            cast_level_data, 'rating', actor_director)

    # Subsetting the required columns
    required_df = cast_level_data[
        ['imdb_title_code', actor_director, 'average_previous_rating']]
    required_df.dropna(subset=[actor_director],inplace=True)
    # Merging back the dataframe with metrics to the actors/directors info
    # dataframe and converting back to TitleID level dataframe
    for num in range(maxlen):
        scrapped_info_ = pd.merge(scrapped_info_, required_df,
                                  left_on=[actor_director+'_'+str(num),
                                           'imdb_title_code'],
                                  right_on=[actor_director, 'imdb_title_code'],
                                  how='left')
        scrapped_info_.rename(columns={'average_previous_rating':
                                       actor_director+'_'+str(num)+'_'+'rating'
                                       },
                              inplace=True)

    # Making a list of only required columns
    required_columns = [str(actor_director)+'_'+str(i) for i in range(maxlen)]
    required_columns.extend(
            [str(actor_director)+'_'+str(i)+'_'+'rating' for i in range(maxlen)])
    required_columns.extend(['imdb_title_code'])

    # Merging back with the original Base AD dataframe and returning the
    # updated dataframe
    scrapped_info_2 = scrapped_info_[required_columns]
    if actor_director=="actor":
        scrapped_info_2['actors_avg_rating'] = scrapped_info_2.apply(
                lambda x: np.nanmean([x['actor_0_rating'], x['actor_1_rating'], x['actor_2_rating'],
                                      x['actor_3_rating']]), axis=1)
         # Dropping multiple emntries of the same movie
        scrapped_info_2.drop_duplicates(subset=['imdb_title_code', 'actors_avg_rating'], inplace=True)
    else:
        scrapped_info_2['directors_avg_rating'] = scrapped_info_2.apply(
                lambda x: np.nanmean([x['director_0_rating'], x['director_1_rating']]), axis=1)
        # Dropping multiple emntries of the same movie
        scrapped_info_2.drop_duplicates(subset=['imdb_title_code', 'directors_avg_rating'], inplace=True)
   
    dataframe = pd.merge(
        dataframe, scrapped_info_2, how='left',
        left_on=['imdb_title_code'],
        right_on=['imdb_title_code'])

    return dataframe
