# importing modules
import numpy as np
import pandas as pd
import statsmodels.api as sm
import sys
# importing user defined modules
# change the path in the below line : enter folder path of where model_objects.py file is
sys.path.insert(0, r"C:/Users/sandeep/PycharmProjects/WB-Theatrical/Miscellaneous")
import model_objects

# importing dataset
base_data = pd.read_excel(
    # enter full path of where "modelling_ad_bo_11_12_2019.xlsx" file is located in the line below
    io=r"C:/Users/sandeep/Affine Analytics Pvt Ltd/WB Theatrical/Analytical Datasets/modelling_ad_bo_11_12_2019.xlsx",
    sheet_name="modelling_ad_bo_11_12_2019",
    na_values=['#NA','#N/A','NA','na','',' ']
)
# adding constant term
base_data['const'] = 1

# subsetting dataset
base_data = base_data.loc[~base_data['imdb_title_name'].isin(['They Shall Not Grow Old' # documentary
                                                              ,'War Dogs' #
                                                              ,'Head Full of Honey' # <10MM BO Revenue
                                                              ,'The Sun Is Also a Star' # <10MM BO Revenue
                                                              ,'Our Brand Is Crisis' # <10MM BO Revenue
                                                              ,'Midnight Special' # <10MM BO Revenue
                                                              ,'The Water Diviner' # <10MM BO Revenue
                                                              ,'We Are Your Friends' # <10MM BO Revenue
                                                              ,'Live by Night' # <12MM BO Revenue
                                                              ,'Pan' # train # high error title
                                                              ,'The Lego Ninjago Movie' # train # high error title
                                                              ,'CHIPS' # train # high error title
                                                              ,'Central Intelligence' # train
                                                              ,'The Lego Movie 2: The Second Part' # test # high error title
                                                              ,"Ocean's Eight" # test
                                                              ,'The Nun' # test
                                                              ,'Crazy Rich Asians' # test
                                                              ,'A Star Is Born' # test
                                                              ,'The 15:17 to Paris'  # test
                                                              ,'Paddington 2'  # test
                                                              ,'Teen Titans Go! To the Movies'  # test
                                                             ])]

base_data = base_data.loc[(base_data['week_number']>=0) & (base_data['week_number']<=8),:]

# variable transformations
## creating dummies
base_data['week_number_temp'] = base_data['week_number']
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'week_number_temp',
                           ],
                           prefix='week_number',
                           drop_first=False)
base_data['genre_(a)_temp'] = base_data['genre_(a)']
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'genre_(a)_temp'
                           ],
                           prefix='genre',
                           drop_first=False)

# log transformations
cont_var = [
    'bo_revenue'
    , 'total_digital Adstock Linear0.569'
    , 'total_linear Adstock Linear0.616'
    , 'total_radio Adstock Linear0.653'
    , 'ooh_-_experiential Adstock Linear0.57'
    , 'outdoor_print Adstock Linear0.721'
    , 'max_wikipedia_page_views_till_-4'
    , 'Avg Competitor Index top3'
]
for col in cont_var:
    base_data[col] = np.log(base_data[col]+1)
del col

# selecting independent variables
indep_vars = [
    'const'
    ,'total_digital Adstock Linear0.569'
    ,'total_linear Adstock Linear0.616'
    ,'total_radio Adstock Linear0.653'
    ,'ooh_-_experiential Adstock Linear0.57'
    ,'outdoor_print Adstock Linear0.721'
    ,'max_wikipedia_page_views_till_-4'
    ,'Avg Competitor Index top3'
    ,'genre_Action Adventure'
    ,'genre_Action Drama'
    ,'genre_Comedy'
    ,'genre_Drama'
    ,'genre_Family'
    ,'genre_Horror'
    ,'franchise_flag'
    ,'distribution_only'
    ,'week_number_1'
    ,'week_number_2'
    ,'week_number_3'
]

title_identifier_vars = [
    'IMDB_Title_Code'
    ,'imdb_title_name'
    ,'theatrical_release_date'
    ,'week_number'
    ,'genre_(a)'
]

# subset dataset
train_data = base_data.loc[(base_data['theatrical_release_year']>=2015) &
                           (base_data['theatrical_release_year']<=2017), title_identifier_vars + ['bo_revenue'] + indep_vars].reset_index(drop=True)
test_data = base_data.loc[base_data['theatrical_release_year']>=2018, title_identifier_vars + ['bo_revenue'] + indep_vars].reset_index(drop=True)

# model development
model = sm.OLS(endog=train_data['bo_revenue'],
               exog=train_data[indep_vars]).fit()

# print model summary
print(model.summary())

# print VIF
print(model_objects.vif(X=train_data[indep_vars]))

# exporting model predictions
train_data['predicted'] = model.predict(exog=train_data[indep_vars]).tolist()
train_data['predicted'] = np.exp(train_data['predicted'])-1
train_data['set'] = 'train'
test_data['predicted'] = model.predict(exog=test_data[indep_vars]).tolist()
test_data['predicted'] = np.exp(test_data['predicted'])-1
test_data['set'] = 'test'

predictions = pd.concat(
    [
        train_data,
        test_data
    ],
    axis=0
)
for col in list(set(cont_var).intersection(predictions.columns.values.tolist())):
    predictions[col] = np.exp(predictions[col])-1
ids = [
    'IMDB_Title_Code'
    ,'imdb_title_name'
    ,'theatrical_release_date'
    ,'genre_(a)'
    ,'franchise_flag'
    ,'distribution_only'
]
title_level_predictions = predictions.groupby(ids).agg(
    {
        'bo_revenue':'sum',
        'predicted':'sum',
        'set':'unique'
    }
).reset_index()
title_level_predictions['Absolute Error'] = np.absolute(
    title_level_predictions['bo_revenue'] -
    title_level_predictions['predicted']
)
title_level_predictions['Percentage Error'] = (
        title_level_predictions['Absolute Error'] /
        title_level_predictions['bo_revenue']
)

model_performace = model_objects.model_results(
    model=model,
    train_data=train_data,
    indep_vars=indep_vars
)

# export model summary / results / predictions
with pd.ExcelWriter(
    # change path below where you wish to export results
        path=r"C:/Users/sandeep/Affine Analytics Pvt Ltd/WB Theatrical/Media Mix Modelling/Analysis Results/MMM BO model result.xlsx",
        mode='w',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    model_performace.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='mode_performance',
        engine='openpyxl')
    predictions.drop('const', axis=1).to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='title-week',
        engine='openpyxl')
    title_level_predictions.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='title',
        engine='openpyxl')
