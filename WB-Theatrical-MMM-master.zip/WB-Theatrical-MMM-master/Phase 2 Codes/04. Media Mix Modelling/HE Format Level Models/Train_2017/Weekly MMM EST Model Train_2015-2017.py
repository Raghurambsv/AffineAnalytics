root_folder=r"C:/Users/Sandeep Sanyal/PycharmProjects/WB-Theatrical-MMM"
sharepoint_path=r"C:/Users/Sandeep Sanyal/Affine Analytics Pvt Ltd/WB Theatrical - Documents"

# importing modules
import numpy as np
import pandas as pd
import statsmodels.api as sm
import sys
# importing user defined modules
sys.path.insert(0, root_folder+r"/Phase 2 Codes/06. Miscellaneous")
import model_objects

# importing dataset
base_data = pd.read_excel(
    io=sharepoint_path+r"/06. HE Format level Models/Phase 2/Format Level Models/EST Revenue T+1/EST_revenue_Comp_AD_v7.0.xlsx",
    sheet_name="Sheet1",
    na_values=['#NA','#N/A','NA','na','',' ']
)
# adding constant term
base_data['const'] = 1

# subsetting dataset
## Week 1 to Week 13
base_data = base_data.loc[(base_data['est_week_number']>=1) & (base_data['est_week_number']<=13),:]
# base_data = base_data.loc[base_data['studio']=='WB']
## dropping < 25M BO Revenue titles
base_data = base_data.loc[base_data['BO_Revenue']>25000000]
## dropping titles with no GS Volume
base_data = base_data.loc[base_data['google_search_volume_old_mean']>0]
## dropping titles with missing metadata
base_data = base_data.dropna(subset=['md_source'])
## dropping titles with no BO Spends
# base_data = base_data.loc[base_data['bo_spends_sum_total']>0]
## dropping outlier titles
base_data = base_data.loc[~base_data['imdb_title_name'].isin([
    "Crazy Rich Asians",
    "A Star Is Born"
])]
## dropping train titles
base_data = base_data.loc[~base_data['imdb_title_name'].isin([
    "Everything, Everything"
])]
## dropping test titles
# base_data = base_data.loc[~base_data['imdb_title_name'].isin([
#     "Teen Titans Go! To the Movies",
#     "Paddington 2",
#     "The Mule",
#     "The 15:17 to Paris"
# ])]

# variable transformations
## creating dummies
base_data['est_week_number_temp'] = base_data['est_week_number']
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'est_week_number_temp',
                           ],
                           prefix='est_week_number',
                           drop_first=False)
base_data['Month_Flag_temp'] = base_data['Month_Flag']
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'Month_Flag_temp',
                           ],
                           prefix='Month_Flag',
                           drop_first=False)
base_data['Release_Month_Flag_temp'] = base_data['Release_Month_Flag']
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'Release_Month_Flag_temp',
                           ],
                           prefix='Release_Month_Flag',
                           drop_first=False)
base_data['md_source_temp'] = base_data['md_source']
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'md_source_temp',
                           ],
                           prefix='md_source',
                           drop_first=False)

# dependent variable
dep_var = "est_revenue_clubbed"

# log transformations
cont_var = [dep_var]+[
    "est_week_number"
    # ,"opening_weekend_bo"
    ,"locations_at_widest_release"
    # ,"definitely_recommended"
    # ,"lc_Interest to Buy EST_new"
    # ,"bo_spends_adstock_linear0.852"
    # ,"rt_tomatometer"
    ,"EST_Release_Year"
    # ,'est_window_by_est_bo'
    # ,"est_bo_window"
    ,"Min_iVOD_EST_Window"
    ,"google_search_volume_old_sum"
    # ,"Casual Moviegoer (6-12 annual)_Value"
    # ,"Medium_High_Income_50Kabove"
    ,"Avg_Comp_Index"
]
for col in cont_var:
    base_data[col] = np.log(base_data[col]+1)
del col

# selecting independent variables
indep_vars = [
    'const'
    ,"opening_weekend_bo"
    ,"locations_at_widest_release"
    ,"definitely_recommended"
    # ,"bo_spends_sum_total"
    # ,"bo_spends_adstock_linear0.852"
    # ,"count_film_festival_new"
    # ,"est_bo_window"
    # ,'est_window_by_est_bo'
    ,"Min_iVOD_EST_Window"
    # ,"film_festival_binary_flag_new"
    # ,"film_festival_flag_new"
    # ,"franchise_flag"
    # ,"holiday_flag"
    # ,"holiday_flag_clubbed"
    # ,"long_weekend_flag"
    # ,"long_weekend_flag_clubbed"
    # ,"minimum_of_vod_est_window"
    # ,"pst_est_window"
    # ,"lc_Awareness_new"
    # ,"lc_Definitely Interested_new"
    # ,"lc_Definitely Interested among Aware_new"
    # ,"lc_Interest All Rent_new"
    # ,"lc_Interest Any Buy_new"
    # ,"lc_Interest Any HE_new"
    # ,"lc_Interest HE Any Only_new"
    ,"lc_Interest to Buy EST_new"
    # ,"lc_Interest to Rent cVod_new"
    # ,"lc_Interest to Rent iVod_new"
    # ,"lc_TOP2 Interested_new"
    # ,"lc_Unaid_new"
    # ,"rt_tomatometer"
    # ,"studio"
    # ,"BO_Revenue"
    # ,"Sporting_Events"
    # ,"Runtime_Flag_120"
    # ,"Runtime_Flag_110"
    # ,"Runtime_Flag_100"
    # ,"MPAA"
    # ,"NDJF"
    ,"Easter_Flag"
    # ,"Fourth_July_Flag"
    # ,"Month_OND"
    # ,"Nov_Dec_Jan"
    # ,"lc_top2"
    # ,"lc_interest_buy_est"
    ,"EST_Release_Year"
    ,"google_search_volume_old_sum"
    ,"Infrequent moviegoer (<6 annual)_Value"
    ,"Casual Moviegoer (6-12 annual)_Value"
    # ,"Frequent Moviegoer (see 12+ annual)_Value"
    # ,"High Income ($100K+ annual HH)_Value"
    # ,"Males_Value"
    # ,"Males 18-34_Value"
    # ,"Males 35-49_Value"
    # ,"Low income (<$50K annual HH)_Value"
    # ,"Middle Income ($50K-$99K annual HH)_Value"
    # ,"Medium_High_Income_50Kabove"
    # ,"Parent (of child under 13)_Value"
    # ,"Total Sample (#)_Value"
    # ,"Under 18_Value"
    # ,"DC_Marvel_Flag"
    # ,"Comp_Index"
    ,"Avg_Comp_Index"

    # ,'md_source_Based on Comic/Graphic Novel'
    # ,'md_source_Based on Factual Book/Article'
    ,'md_source_Based on Fiction Book/Short Story'
    # ,'md_source_Based on Folk Tale/Legend/Fairytale'
    # ,'md_source_Based on Game'
    ,'md_source_Based on Real Life Events'
    ,'md_source_Based on Religious Text'
    ,'md_source_Based on Short Film'
    ,'md_source_Based on TV'
    # ,'md_source_Based on Theme Park Ride'
    # ,'md_source_Based on Toy'
    # ,'md_source_Original Screenplay'
    # ,'md_source_Remake'
    # ,'md_source_Spin-Off'

    ,'est_week_number'
    # ,'est_week_number_0'
    # ,'est_week_number_1'
    # ,'est_week_number_2'
    # ,'est_week_number_3'
    # ,'est_week_number_4'
    # ,'est_week_number_5'
    # ,'est_week_number_6'
    # ,'est_week_number_7'
    # ,'est_week_number_8'
    # ,'est_week_number_9'
    # ,'est_week_number_10'
    # ,'est_week_number_11'
    # ,'est_week_number_12'
    # ,'est_week_number_13'
    # ,'EST2-13 weeks'
    # ,'Month_Flag_8'
    # ,'Month_Flag_9'
    # ,'Month_Flag_10'
    # ,'Release_Month_Flag_11'
]

title_identifier_vars = [
    'imdb_title_code'
    ,'imdb_title_name'
    ,'theatrical_release_date'
    ,'est_release_date'
    # ,'est_week_number'
    ,'studio'
    ,'mkt_genre_grouped'
]

# subset dataset
train_data = base_data.loc[(base_data['theatrical_release_year']>=2015) &
                           (base_data['theatrical_release_year']<=2017), title_identifier_vars + [dep_var] + indep_vars].reset_index(drop=True)
test_data = base_data.loc[(base_data['theatrical_release_year']==2018), title_identifier_vars + [dep_var] + indep_vars].reset_index(drop=True)

# model development
model = sm.OLS(endog=train_data[dep_var],
               exog=train_data[indep_vars]).fit()

# print model summary
print(model.summary())

# print VIF
print(model_objects.vif(X=train_data[indep_vars]))

# exporting iteration results
model_objects.model_results(model=model,
                            train_data=train_data,
                            test_data=test_data,
                            indep_vars=indep_vars,
                            dep_var=dep_var,
                            transform_dep_var='log',
                            studio=True,
                            ids=['imdb_title_code'
                                ,'imdb_title_name'
                                ,'theatrical_release_date'
                                ,'est_release_date'
                                ,'mkt_genre_grouped'
                                ,'studio'],
                            export_path=sharepoint_path+r"/06. HE Format level Models/Phase 2/Format Level Models/EST Revenue T+1/intermediate files/EST_iterations01-07.xlsx"
                            )

# exporting model predictions
train_data['predicted'] = np.exp(model.predict(exog=train_data[indep_vars]).tolist())-1
train_data['set'] = 'train'
test_data['predicted'] = np.exp(model.predict(exog=test_data[indep_vars]).tolist())-1
test_data['set'] = 'test'
predictions = pd.concat([train_data,
                         test_data],
                        axis=0)
for col in list(set(cont_var).intersection(predictions.columns.values.tolist())):
    predictions[col] = np.exp(predictions[col])-1

WB_title_level_predictions = predictions.loc[predictions['studio']=='WB',:].groupby(
    [
    'imdb_title_code'
    ,'imdb_title_name'
    ,'theatrical_release_date'
    ,'est_release_date'
    ,'mkt_genre_grouped'
    ,'studio'
    ]).agg({dep_var:'sum',
            'predicted':'sum',
            'set':'unique'}).reset_index()
WB_title_level_predictions['Absolute Error'] = np.absolute(WB_title_level_predictions[dep_var] - WB_title_level_predictions['predicted'])
WB_title_level_predictions['Percentage Error'] = WB_title_level_predictions['Absolute Error']/WB_title_level_predictions[dep_var]

WBNONWB_title_level_predictions = predictions.groupby(
    [
    'imdb_title_code'
    ,'imdb_title_name'
    ,'theatrical_release_date'
    ,'est_release_date'
    ,'mkt_genre_grouped'
    ,'studio'
    ]
).agg({dep_var:'sum',
       'predicted':'sum',
       'set':'unique'}).reset_index()
WBNONWB_title_level_predictions['Absolute Error'] = np.absolute(WBNONWB_title_level_predictions[dep_var] - WBNONWB_title_level_predictions['predicted'])
WBNONWB_title_level_predictions['Percentage Error'] = WBNONWB_title_level_predictions['Absolute Error']/WBNONWB_title_level_predictions[dep_var]

# title level WMAPE
print('Train WMAPE (WB):'+str((WB_title_level_predictions.loc[WB_title_level_predictions['set']=='train',['Absolute Error']].sum()[0]/WB_title_level_predictions.loc[WB_title_level_predictions['set']=='train',[dep_var]].sum()[0])*100))
print('Test WMAPE (WB):'+str((WB_title_level_predictions.loc[WB_title_level_predictions['set']=='test',['Absolute Error']].sum()[0]/WB_title_level_predictions.loc[WB_title_level_predictions['set']=='test',[dep_var]].sum()[0])*100))
print('Train WMAPE (WB+NonWB):'+str((WBNONWB_title_level_predictions.loc[WBNONWB_title_level_predictions['set']=='train',['Absolute Error']].sum()[0]/WBNONWB_title_level_predictions.loc[WBNONWB_title_level_predictions['set']=='train',[dep_var]].sum()[0])*100))
print('Test WMAPE (WB+NonWB):'+str((WBNONWB_title_level_predictions.loc[WBNONWB_title_level_predictions['set']=='test',['Absolute Error']].sum()[0]/WBNONWB_title_level_predictions.loc[WBNONWB_title_level_predictions['set']=='test',[dep_var]].sum()[0])*100))

with pd.ExcelWriter(
        path=sharepoint_path+r"/06. HE Format level Models/Phase 2/Format Level Models/EST Revenue T+1/intermediate files/EST_iterations01-07.xlsx",
        engine='openpyxl',
        mode='a',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    predictions.drop('const', axis=1).to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='title-week'
    )
    WBNONWB_title_level_predictions.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='title')
