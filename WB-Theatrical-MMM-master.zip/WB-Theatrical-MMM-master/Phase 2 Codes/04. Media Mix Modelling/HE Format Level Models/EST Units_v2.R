#install.packages(c("leaps", "car", "data.table", "ggplot2",
#              "rattle","rpart","rpart.plot","dummies","readxl","writexl", "caret"))
 
library("leaps")
library("writexl")
library("car")
library("data.table")
library("ggplot2")
library("rattle")
library("rpart")
library("rpart.plot")
library("dummies")
library("readxl")
library("caret")

#error metrics function
error_metrics <- function(y_true, y_pred){
  mae <- mean(abs(y_true-y_pred))
  mape <- mean(abs(y_true-y_pred)/y_true)
  wmape <- sum(abs(y_true-y_pred))/sum(as.numeric(y_true))
  print(paste("MAE", mae, sep=":"))
  print(paste("MAPE", mape, sep=":"))
  print(paste("WMAPE", wmape, sep=":"))
}

#please input the path of the AD in quotes with forward slash
modelling_ad <- read_excel("D:/WB_Theatrical/HE Format Level Forecasting/2019 Titles Refresh/EST Units model/EST_Units_modeling_AD_v1.0.xlsx",
                           na = c("", " ", "NA", "N/A", "#N/A"))

modelling_ad <- data.table(modelling_ad)

modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]


#Putting filter for HE Phase 2 titles 441 count only
modelling_ad <- modelling_ad[HE_phase_1_flag!=0]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#Filtering only for 13 weeks
modelling_ad <- modelling_ad[EST_Week_Number< 14 & EST_Week_Number > 0]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#Filtering missing Metadata Titles
modelling_ad <- modelling_ad[!is.na(SOURCE)]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#Revenue More than 0 more to be included
modelling_ad <- modelling_ad[EST_Units > 0]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#Filtering Missing GSV titles
modelling_ad <- modelling_ad[Max_Google_Search_Volume_manual!=0]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]


#Filtering titles with BO revenue less than 25mm
modelling_ad <- modelling_ad[BO_Revenue > 25000000]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#dummy variable for metadata source variable
modelling_ad = dummy.data.frame(data = modelling_ad,
                                names = c("SOURCE"))

modelling_ad <- data.table(modelling_ad)


#modelling_ad <- modelling_ad[Opening_Weekend_Box_Office>0]
modelling_ad <- modelling_ad[Number_of_Theatres_released_latest>0]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

modelling_ad <- modelling_ad[!is.na(EST_to_iVOD_Window)]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#modelling_ad <- modelling_ad[!is.na(`movio_50_&_over_Value`)]
#modelling_ad <- modelling_ad[!is.na(`25-34_Value`)]
#modelling_ad <- modelling_ad[!is.na(`Casual_Moviegoer_(6-12_annual)_Value`)]
modelling_ad <- modelling_ad[!is.na(`High_Income_($100K+_annual_HH)_Value`)]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#modelling_ad <- modelling_ad[!is.na(`Low_income_(<$50K_annual_HH)_Value`)]


#Dropping usual high error train titles
modelling_ad <- modelling_ad[!IMDB_Title_Code%in%'tt7905466'] #They shall not grow old : No Openiing BO
#modelling_ad <- modelling_ad[!IMDB_Title_Code%in%'tt7286456'] #Joker
#modelling_ad <- modelling_ad[!IMDB_Title_Code%in%'tt5001718'] #Everything, Everything
#modelling_ad <- modelling_ad[!IMDB_Title_Code%in%'tt4468740'] #Paddington 2

modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#train and test split
train_data <- modelling_ad[Theatrical_Release_Year%in% c(2015, 2016, 2017, 2018), ]
test_data <- modelling_ad[Theatrical_Release_Year%in%c(2019), ]

#Outlier Capping
# outlier_capping <- function(x){
#   quantiles <- quantile( x, c(.05, .95) )
#   x[ x < quantiles[1] ] <- quantiles[1]
#   x[ x > quantiles[2] ] <- quantiles[2]
#   x
# }
# 
# range <- seq(1:13)
# for (i in range){
#   train_data1 <- train_data[train_data$EST_Week_Number==i]
#   train_data$EST_Revenue_Capped[train_data$EST_Week_Number==i] <- outlier_capping(train_data1$EST_Revenue_Clubbed)
# }


#train and test title count
train_data[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]
test_data[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

colnames(modelling_ad)

##### Model with raw beta estimates ######
lr_model <- lm(log(EST_Units_Clubbed)~
                 log(`EST_Week_Number`)+
                 log(`Opening_Weekend_Box_Office`)+
                 log(`Number_of_Theatres_released_latest`)+
                 log(`Definitely_Recommended_latest`+1)+
                 log(`EST_to_iVOD_Window`+1)+
                 log(`EST_Release_Year`)+
                 log(`Mean_Google_Search_Volume_manual`)+
                 #log(`Max_Google_Search_Volume_manual`)+
                 #log(`tomatometer_imputed`+1)+
                 #`movio_50_&_over_Value`+
                 #`franchise_flag`+
                 #`franchise_flag`:`Week2_Onwards`+
                 #`Runtime_110`+
                 #`DC/Marvel_Flag`+
                 #`25-34_Value`+
                 log(`Casual_Moviegoer_(6-12_annual)_Value`+1)+
                 log(`High_Income_($100K+_annual_HH)_Value`+1)+
                 log(`Middle_Income_($50K-$99K_annual HH)_Value`+1)+
                 log(`lc_Interest to Buy EST_latest`+1)+
                 log(`Comp_index_avg`+1)+
                 #log(`Low_income_(<$50K_annual_HH)_Value`+1)+
                 #log(`tomatometer_imputed`+1)+
                 #`SOURCEBased on Comic/Graphic Novel`,
                 `SOURCEBased on Factual Book/Article`+
                 `SOURCEBased on Fiction Book/Short Story`+
                 #`SOURCEBased on Folk Tale/Legend/Fairytale`+
                 #`SOURCEBased on Game`+
                 #`SOURCEBased on Movie`+
                 #`SOURCEBased on Play`+
                 #`SOURCEBased on Real Life Events`+
                 `SOURCEBased on Religious Text`+
                 #`SOURCEBased on Short Film`+
                 `SOURCEBased on Theme Park Ride`+
                 #`SOURCEBased on Toy`+
                 #`SOURCEOriginal Screenplay`,
                 #`SOURCERemake`+
                 #`SOURCESpin-Off`,
                 `SOURCEBased on TV`,
               data= train_data)


summary(lr_model)
vif(lr_model)

ggplot(data=train_data, aes(y=log(EST_Units_Clubbed + 1), x=as.factor(`SOURCEBased on Fiction Book/Short Story`)))+
geom_boxplot()

#WB plus NON WB Errors
train_data$predictions <-  exp(predict(lr_model, train_data))
test_data$predictions <-  exp(predict(lr_model, test_data))

title_train_data <- train_data[, j=list(est_unit_actuals=sum(EST_Units_Clubbed), est_unit_pred=sum(predictions)), by=c('IMDB_Title_Code')]
title_test_data <- test_data[, j=list(est_unit_actuals=sum(EST_Units_Clubbed), est_unit_pred=sum(predictions)), by=c('IMDB_Title_Code')]
error_metrics(title_train_data$est_unit_actuals, title_train_data$est_unit_pred)
error_metrics(title_test_data$est_unit_actuals, title_test_data$est_unit_pred)

#Only WB Errors
train_datawb <- train_data[`wb_flag`%in%'1', ]
test_datawb <- test_data[`wb_flag`%in%'1', ]

title_train_datawb <- train_datawb[, j=list(est_unit_actuals=sum(EST_Units_Clubbed), est_unit_pred=sum(predictions)), by=c('IMDB_Title_Code')]
error_metrics(title_train_datawb$est_unit_actuals, title_train_datawb$est_unit_pred)
title_test_datawb <- test_datawb[, j=list(est_unit_actuals=sum(EST_Units_Clubbed), est_unit_pred=sum(predictions)), by=c('IMDB_Title_Code')]
error_metrics(title_test_datawb$est_unit_actuals, title_test_datawb$est_unit_pred)

# fwrite(title_train_datawb, "D:/WB_Theatrical/HE Format Level Forecasting/2019 Titles Refresh/EST Units model/train_wb.csv", row.names = F)
# fwrite(title_test_datawb, "D:/WB_Theatrical/HE Format Level Forecasting/2019 Titles Refresh/EST Units model/test_wb.csv", row.names = F)

fwrite(title_train_data, "D:/WB_Theatrical/HE Format Level Forecasting/2019 Titles Refresh/EST Units model/train_wb_comp.csv", row.names = F)
fwrite(title_test_data, "D:/WB_Theatrical/HE Format Level Forecasting/2019 Titles Refresh/EST Units model/test_wb_comp.csv", row.names = F)
### Model with scaled beta estimates ### 
# lr_model <- lm(log(EST_Units_Clubbed)~
#                  Comp_index_avg,
#                data= train_data)


# summary(lr_model)