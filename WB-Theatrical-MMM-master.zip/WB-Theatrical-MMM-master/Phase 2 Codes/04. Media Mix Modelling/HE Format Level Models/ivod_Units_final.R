# install.packages(c("leaps", "car", "data.table", "ggplot2",
#                  "rattle","rpart","rpart.plot","dummies","readxl","writexl", "caret"))
# 
# library("leaps")
# library("writexl")
# library("car")
# library("data.table")
# library("ggplot2")
# library("rattle")
# library("rpart")
# library("rpart.plot")
# library("dummies")
# library("readxl")
# library("caret")

# # INSTALLING REQUIRED PACKAGES
# list.of.packages <- c("data.table",
#                       "dplyr",
#                       "car",
#                       "ggplot2",
#                       "rattle",
#                       "leaps",
#                       "rpart",
#                       "rpart.plot",
#                       "readxl",
#                       "writexl",
#                       "dummies")
# new.packages = list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
# if(length(new.packages)) install.packages(new.packages, dependencies = TRUE)
# remove(list.of.packages, new.packages)

library("car")
library("data.table")
library("ggplot2")
library("rattle")
library("rpart")
library("rpart.plot")
library("dummies")
library("readxl")
library("writexl")

#error metrics function
error_metrics <- function(y_true, y_pred){
  mae <- mean(abs(y_true-y_pred))
  mape <- mean(abs(y_true-y_pred)/y_true)
  wmape <- sum(abs(y_true-y_pred))/sum(as.numeric(y_true))
  print(paste("MAE", mae, sep=":"))
  print(paste("MAPE", mape, sep=":"))
  print(paste("WMAPE", wmape, sep=":"))
}


#please input the path of the AD in quotes 
modelling_ad <- read_excel("C:/Users/diganta/Desktop/WB_results/Mar 17/iVOD_Units_modeling_AD_v2.0.xlsx",
                           na = c("", " ", "NA", "N/A", "#N/A"))

modelling_ad <- data.table(modelling_ad)

modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]


#Putting filter for HE Phase 2 titles 414 here because for 322+2019+ivod revenue present
modelling_ad <- modelling_ad[HE_phase_1_flag!=0]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#Filtering only for 13 weeks
modelling_ad <- modelling_ad[iVOD_Week_Number< 14 & iVOD_Week_Number > 0]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#Filtering missing Metadata Titles
modelling_ad <- modelling_ad[!is.na(SOURCE)]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#Revenue More than 0 more to be included
modelling_ad <- modelling_ad[iVOD_Units > 0]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#Filtering Missing GSV titles
modelling_ad <- modelling_ad[Max_Google_Search_Volume_manual!=0]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]


#Filtering titles with BO revenue less than 25mm
modelling_ad <- modelling_ad[!less_than_25m%in%'TRUE']
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#dummy variable for metadata source variable
modelling_ad = dummy.data.frame(data = modelling_ad,
                                names = c("SOURCE"))

modelling_ad <- data.table(modelling_ad)


modelling_ad <- modelling_ad[Opening_Weekend_Box_Office>0]
modelling_ad <- modelling_ad[Number_of_Theatres_released_latest>0]
modelling_ad <- modelling_ad[!is.na(EST_to_iVOD_Window)]
#modelling_ad <- modelling_ad[!is.na(`movio_50_&_over_Value`)]
#modelling_ad <- modelling_ad[!is.na(`25-34_Value`)]
#modelling_ad <- modelling_ad[!is.na(`Casual_Moviegoer_(6-12_annual)_Value`)]
modelling_ad <- modelling_ad[!is.na(`High_Income_($100K+_annual_HH)_Value`)]
#modelling_ad <- modelling_ad[!is.na(`Low_income_(<$50K_annual_HH)_Value`)]


#Dropping usual high error train titles
modelling_ad <- modelling_ad[!IMDB_Title_Code%in%'tt7905466'] #They shall not grow old : No Openiing BO
# modelling_ad <- modelling_ad[!IMDB_Title_Code%in%'tt1517451'] #A Star is Born
# modelling_ad <- modelling_ad[!IMDB_Title_Code%in%'tt3104988'] #Crazy Rich Asians
# modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt5001718'] #Everything, Everthing

# removing Joker
modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt7286456'] #Joker

# Dropping usual high error test titles
# modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt7424200'] #Teen Titans Go! To the Movies
# modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt4468740'] #Paddington 2
# modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt6802308'] #The 15:17 to Paris
# modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt7959026'] #The Mule

#Dropping the high error titles phase 2 updated
#modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt4913966'] #The Curse of La Llorona
#modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt7424200'] #Teen Titans Go! To the Movies
#modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt2452244'] #Isn't It Romantic
#modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt4468740'] #Paddington 2

modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

#train and test split
train_data <- modelling_ad[Theatrical_Release_Year%in% c(2015,2016, 2017,2018),]
test_data <- modelling_ad[Theatrical_Release_Year%in%c( 2019), ]

#Outlier Capping
# outlier_capping <- function(x){
#   quantiles <- quantile( x, c(.05, .95) )
#   x[ x < quantiles[1] ] <- quantiles[1]
#   x[ x > quantiles[2] ] <- quantiles[2]
#   x
# }
# 
# range <- seq(1:13)
# for (i in range){
#   train_data1 <- train_data[train_data$iVOD_Week_Number==i]
#   train_data$iVOD_Revenue_Capped[train_data$iVOD_Week_Number==i] <- outlier_capping(train_data1$iVOD_Revenue_Clubbed)
# }

# write_xlsx(
#   modelling_ad,
#   path = "C:/Users/hari/Desktop/IVOD_reve_mod_ad.xlsx",
#   col_names = TRUE,
#   format_headers = FALSE
# )

#train and test title count
train_data[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]
test_data[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]

colnames(modelling_ad)

##### Model with raw beta estimates ######
lr_model <- lm(log(iVOD_Units_Clubbed+1)~
                 log(`iVOD_Week_Number`+1)+
                 log(`EST_to_iVOD_Window`+1)+
                 log(`iVOD_Release_Year`+1)+
                 `franchise_flag`+
                 `franchise_flag`:`Week2_Onwards`+
                 log(`Opening_Weekend_Box_Office`+1)+
                 `SOURCEBased on Comic/Graphic Novel`+
                 `SOURCEBased on Factual Book/Article`+
                 `SOURCEBased on Fiction Book/Short Story`+
                 # `SOURCEBased on Folk Tale/Legend/Fairytale`+
                 `SOURCEBased on Game`+
                 # `SOURCEBased on Movie`+
                 # `SOURCEBased on Play`+
                 `SOURCEBased on Real Life Events`+
                 `SOURCEBased on Religious Text`+
                 # `SOURCEBased on Short Film`+
                 # `SOURCEBased on Theme Park Ride`+
                 # `SOURCEBased on Toy`+
                 # `SOURCEBased on TV`+
                 `SOURCEOriginal Screenplay`+
                 `SOURCERemake`+
                 # `SOURCESpin-Off`+
                 #log(`Casual_Moviegoer_(6-12_annual)_Value`+1)+
                 # `Max_Google_Search_Volume`+
                 # `Mean_Google_Search_Volume`+
                 # log(`Sum_Google_Search_Volume`+1)+
                 # `Max_Google_Search_Volume_manual`+
                 log(`Mean_Google_Search_Volume_manual`+1)+
                 `DC/Marvel_Flag`+
                 `High_Income_($100K+_annual_HH)_Value`+
                 log(`tomatometer_imputed`+1)+
                 log(`lc_Interest_to_Rent_iVod_latest`+1)+
                 # log(`lc_TOP2_Interested_latest`+ 1)+
                 log(`Number_of_Theatres_released_latest`+1)+
                 log(`Definitely_Recommended_latest`+1)+
                 log(`Comp`+1),
               data= train_data)

summary(lr_model)
vif(lr_model)


#WB plus NON WB Errors
train_data$predictions <-  exp(predict(lr_model, train_data))-1
test_data$predictions <-  exp(predict(lr_model, test_data))-1

title_train_data <- train_data[, j=list(ivod_units_actuals=sum(iVOD_Units_Clubbed), ivod_units_pred=sum(predictions)), by=c('IMDB_Title_Code')]
title_test_data <- test_data[, j=list(ivod_units_actuals=sum(iVOD_Units_Clubbed), ivod_units_pred=sum(predictions)), by=c('IMDB_Title_Code')]
error_metrics(title_train_data$ivod_units_actuals, title_train_data$ivod_units_pred)
error_metrics(title_test_data$ivod_units_actuals, title_test_data$ivod_units_pred)

#Only WB Errors
train_datawb <- train_data[`wb_flag`%in%'1', ]
test_datawb <- test_data[`wb_flag`%in%'1', ]

title_train_datawb <- train_datawb[, j=list(ivod_units_actuals=sum(iVOD_Units_Clubbed), ivod_units_pred=sum(predictions)), by=c('IMDB_Title_Code')]
error_metrics(title_train_datawb$ivod_units_actuals, title_train_datawb$ivod_units_pred)
title_test_datawb <- test_datawb[, j=list(ivod_units_actuals=sum(iVOD_Units_Clubbed), ivod_units_pred=sum(predictions)), by=c('IMDB_Title_Code')]
error_metrics(title_test_datawb$ivod_units_actuals, title_test_datawb$ivod_units_pred)

# # ### Model with scaled beta estimates ###
# lr_model <- lm(log(iVOD_Units_Clubbed+1)~
#                  scale(log(`iVOD_Week_Number`+1))+
#                  scale(log(`EST_to_iVOD_Window`+1))+
#                  scale(log(`iVOD_Release_Year`+1))+
#                  `franchise_flag`+
#                  `franchise_flag`:`Week2_Onwards`+
#                  scale(log(`Opening_Weekend_Box_Office`+1))+
#                  `SOURCEBased on Comic/Graphic Novel`+
#                  `SOURCEBased on Factual Book/Article`+
#                  `SOURCEBased on Fiction Book/Short Story`+
#                  # `SOURCEBased on Folk Tale/Legend/Fairytale`+
#                  `SOURCEBased on Game`+
#                  # `SOURCEBased on Movie`+
#                  # `SOURCEBased on Play`+
#                  `SOURCEBased on Real Life Events`+
#                  `SOURCEBased on Religious Text`+
#                  # `SOURCEBased on Short Film`+
#                  # `SOURCEBased on Theme Park Ride`+
#                  # `SOURCEBased on Toy`+
#                  # `SOURCEBased on TV`+
#                  `SOURCEOriginal Screenplay`+
#                  `SOURCERemake`+
#                  # `SOURCESpin-Off`+
#                  #log(`Casual_Moviegoer_(6-12_annual)_Value`+1)+
#                  # `Max_Google_Search_Volume`+
#                  # `Mean_Google_Search_Volume`+
#                  # log(`Sum_Google_Search_Volume`+1)+
#                  # `Max_Google_Search_Volume_manual`+
#                  scale(log(`Mean_Google_Search_Volume_manual`+1))+
#                  `DC/Marvel_Flag`+
#                  scale(`High_Income_($100K+_annual_HH)_Value`)+
#                  scale(log(`tomatometer_imputed`+1))+
#                  scale(log(`lc_Interest_to_Rent_iVod_latest`+1))+
#                  # log(`lc_TOP2_Interested_latest`+ 1)+
#                  scale(log(`Number_of_Theatres_released_latest`+1))+
#                  scale(log(`Definitely_Recommended_latest`+1))+
#                  scale(log(`Comp`+1)),
#                data= train_data)
# 
# summary(lr_model)

fwrite(title_train_datawb, "C:/Users/diganta/Desktop/WB_results/Mar 17/train_wb_NO_Joker.csv", row.names = F)
fwrite(title_test_datawb, "C:/Users/diganta/Desktop/WB_results/Mar 17/test_wb_NO_Joker.csv", row.names = F)
# 
# sandy = function(df, set){
# 
#   df = data.frame(df)
# 
#   # log_var = c("est_revenue_clubbed",
#   #             "Avg_Comp_Index",
#   #             "locations_at_widest_release",
#   #             "bo_spends_adstock_linear0.852",
#   #             "google_search_volume_old_sum")
#   # for(i in log_var){
#   #   df[i] = exp(df[i])
#   # }
#   # df["Avg_Comp_Index"] = df["Avg_Comp_Index"]+1
#   indep_var = c("iVOD_Release_Year",
#                 "opening_weekend_bo",
#                 # "locations_widest_release",
#                 # "bo_spends_adstock_linear0.851",
#                 # "google_search_volume_old_sum",
#                 # "new_avg_competitor_effect",
#                 # "Easter_Flag",
#                 # "definitely_recommended",
#                 # "new_EST_IVOD_window",
#                 # "Casual.Moviegoer..6.12.annual._Value",
#                 # "Infrequent.moviegoer...6.annual._Value",
#                 # "lc_Interest.to.Buy.EST_new",
#                 "iVOD_Units_Clubbed",
#                 # "Easter_Flag",
#                 # "sourceBased.on.Fiction.Book.Short.Story",
#                 # "sourceBased.on.Real.Life.Events",
#                 # "sourceBased.on.Religious.Text",
#                 # "sourceBased.on.Short.Film",
#                 # "sourceBased.on.TV",
#                 "predictions")
#   other_var = c("imdb_title_code",
#                 "imdb_title_name",
#                 # "th_week_number",
#                 # "week_start_date",
#                 # "est_week_number",
#                 "wb_nonwb_flag")
# 
#   df = df[c(other_var
#             #log_var
#             ,indep_var
#   )]
#   df['set'] = set
# 
#   return(df)
# }
# ""
# write_xlsx(
#   rbind(sandy(df = train_data, set = 'train'),sandy(df = test_data, set = 'test')),
#   path = "C:/Users/hari/Desktop/mod_res_sheet_feb6.xlsx",
#   col_names = TRUE,
#   format_headers = FALSE
# )