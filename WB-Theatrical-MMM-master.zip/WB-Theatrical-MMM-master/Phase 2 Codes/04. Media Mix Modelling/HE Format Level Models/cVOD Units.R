
# INSTALLING REQUIRED PACKAGES
list.of.packages <- c("data.table",
                      "dplyr",
                      "car",
                      "ggplot2",
                      "rattle",
                      "leaps",
                      "rpart",
                      "rpart.plot",
                      "readxl",
                      "writexl",
                      "dummies")
new.packages = list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
if(length(new.packages)) install.packages(new.packages, dependencies = TRUE)
remove(list.of.packages, new.packages)



library("car")
library("data.table")
library("ggplot2")
library("rattle")
library("rpart")
library("rpart.plot")
library("dummies")
library("readxl")
library("writexl")



#error metrics function
error_metrics <- function(y_true, y_pred){
  mae <- mean(abs(y_true-y_pred))
  mape <- mean(abs(y_true-y_pred)/y_true)
  wmape <- sum(abs(y_true-y_pred))/sum(as.numeric(y_true))
  print(paste("MAE", mae, sep=":"))
  print(paste("MAPE", mape, sep=":"))
  print(paste("WMAPE", wmape, sep=":"))
}




#please input the path of the AD in quotes with forward slash
modelling_ad <- read_excel("C:/Users/sandeep/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Phase 2 Refresh/ADs/cVOD Units/CVOD_Units_modeling_AD_v1.0.xlsx",
                           na = c("", " ", "NA", "N/A", "#N/A"))

modelling_ad <- data.table(modelling_ad)

modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]




#Putting filter for HE Phase 2 titles 441 count only
modelling_ad <- modelling_ad[HE_phase_1_flag!=0]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]



#Filtering only for 13 weeks
modelling_ad <- modelling_ad[VOD_Week_Number< 14 & VOD_Week_Number > 0]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]



#Filtering missing Metadata Titles
modelling_ad <- modelling_ad[!is.na(SOURCE)]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]



#Revenue More than 0 more to be included
modelling_ad <- modelling_ad[VOD_Units > 0]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]



#Filtering Missing GSV titles
modelling_ad <- modelling_ad[Mean_Google_Search_Volume_manual!=0]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]




#Filtering titles with BO revenue less than 25mm
modelling_ad <- modelling_ad[BO_Revenue > 25000000]
modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]



#dummy variable for metadata source variable
modelling_ad = dummy.data.frame(data = modelling_ad,
                                names = c("SOURCE"))



modelling_ad <- data.table(modelling_ad)




#modelling_ad <- modelling_ad[Opening_Weekend_Box_Office>0]
#modelling_ad <- modelling_ad[Number_of_Theatres_released_latest > 0]
modelling_ad <- modelling_ad[!is.na(EST_to_VOD_Window)]
#modelling_ad <- modelling_ad[!is.na(`movio_50_&_over_Value`)]
#modelling_ad <- modelling_ad[!is.na(`25-34_Value`)]
#modelling_ad <- modelling_ad[!is.na(`Casual_Moviegoer_(6-12_annual)_Value`)]
modelling_ad <- modelling_ad[!is.na(`High_Income_($100K+_annual_HH)_Value`)]
#modelling_ad <- modelling_ad[!is.na(`Low_income_(<$50K_annual_HH)_Value`)]




#Dropping usual high error train titles
modelling_ad <- modelling_ad[!IMDB_Title_Code%in%'tt7905466'] #They shall not grow old : No Openiing BO
modelling_ad <- modelling_ad[!IMDB_Title_Code%in%'tt1517451'] #A Star is Born
modelling_ad <- modelling_ad[!IMDB_Title_Code%in%'tt3104988'] #Crazy Rich Asians
modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt5001718'] #Everything, Everthing
modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt7959026'] #The Mule
# modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt1524930'] #Vacation
# modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt2561572'] #GetHard


# Dropping usual high error test titles
# modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt7424200'] #Teen Titans Go! To the Movies
#modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt4468740'] #Paddington 2
# modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt6802308'] #The 15:17 to Paris
modelling_ad <- modelling_ad[!IMDB_Title_Code %in% 'tt7286456'] #Joker



modelling_ad[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]



#train and test split
train_data <- modelling_ad[Theatrical_Release_Year%in% c(2015, 2016, 2017,2018), ]
test_data <- modelling_ad[Theatrical_Release_Year%in%c( 2019), ]




#train and test title count
train_data[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]
test_data[, j=list(length(unique(IMDB_Title_Code))), by= "wb_flag"]



##### Model with raw beta estimates ######
lr_model <- lm(log(VOD_Units_Clubbed)~
                 log(`VOD_Week_Number`+1)+
                 #log(`VOD_Release_Year`+1)+
                 #`tomatometer_imputed`+
                 #`DC/Marvel_Flag`+
                 `franchise_flag`+
                 `franchise_flag`:`Week2_Onwards`+
                 log(`Opening_Weekend_Box_Office`)+
                 #  log(`Number_of_Theatres_released_latest`+1)+
                 log(`Definitely_Recommended_latest`)+
                 `SOURCEBased on Religious Text`+
                 `SOURCEBased on Short Film`+
                 # `SOURCEBased on Factual Book/Article`+
                 # `SOURCEBased on Fiction Book/Short Story`+
                 #  `SOURCEBased on Comic/Graphic Novel`+
                 `SOURCEBased on Theme Park Ride`+
                 # `SOURCEBased on Game`+
                 # `SOURCEBased on TV`+
                 log(`Frequent_Moviegoer_(see_12+_annual)_Value`)+
                 # log(`Infrequent_moviegoer_(<6_annual)_Value`)+
                 # log(`Casual_Moviegoer_(6-12_annual)_Value`)+
                 #log(`25-34_Value`)+
                 `SOURCEOriginal Screenplay`+
                 `SOURCESpin-Off`+
                 log(`Mean_Google_Search_Volume_manual`+1)+
                 log(`lc_Interest_to_Rent_cVod_latest`)+
                 #`lc_Unaid_latest`+
                 log(`High_Income_($100K+_annual_HH)_Value`)+
                 #log(`Theatrical_to_VOD_Window`)+
                 # log(`Avg Comp Index`+1),
                 #log(`Avg Comp Index 3 weeks`)+
                 log(`Avg Comp Index_no0`)+
                 log(`EST_to_VOD_Window`+1),
               
               data= train_data)




summary(lr_model)
vif(lr_model)



#WB plus NON WB Errors
train_data$predictions <-  exp(predict(lr_model, train_data))
test_data$predictions <-  exp(predict(lr_model, test_data))



# title_train_data <- train_data[, j=list(est_rev_actuals=sum(VOD_Units_Clubbed), est_rev_pred=sum(predictions)), by=c('IMDB_Title_Code')]
# title_test_data <- test_data[, j=list(est_rev_actuals=sum(VOD_Units_Clubbed), est_rev_pred=sum(predictions)), by=c('IMDB_Title_Code')]
# error_metrics(title_train_data$est_rev_actuals, title_train_data$est_rev_pred)
# error_metrics(title_test_data$est_rev_actuals, title_test_data$est_rev_pred)
# 


#Only WB Errors
train_datawb <- train_data[`wb_flag`%in%'1', ]
test_datawb <- test_data[`wb_flag`%in%'1', ]



title_train_datawb <- train_datawb[, j=list(est_rev_actuals=sum(VOD_Units_Clubbed), est_rev_pred=sum(predictions)), by=c('IMDB_Title_Code')]
error_metrics(title_train_datawb$est_rev_actuals, title_train_datawb$est_rev_pred)
title_test_datawb <- test_datawb[, j=list(est_rev_actuals=sum(VOD_Units_Clubbed), est_rev_pred=sum(predictions)), by=c('IMDB_Title_Code')]
error_metrics(title_test_datawb$est_rev_actuals, title_test_datawb$est_rev_pred)

# write.csv(summary(lr_model)$coefficients, "C:/Users/sandeep/Desktop/mod_sum_tits_removed.csv")


# fwrite(title_train_datawb, "C:/Users/sandeep/Desktop/train.csv", row.names = F)
# fwrite(title_test_datawb, "C:/Users/sandeep/Desktop/test.csv", row.names = F)



# ### Model with scaled beta estimates ### 
# lr_model <- lm(log(est_revenue_clubbed)~
#                  scale(log(`est_week_number`))+
#                  scale(`opening_weekend_bo`)+
#                  scale(log(`locations_at_widest_release`))+
#                  scale(`definitely_recommended`)+
#                  scale(log(`Min_iVOD_EST_Window`+1))+
#                  scale(log(`EST_Release_Year`))+
#                  scale(log(`google_search_volume_old_sum`))+
#                  `25-34_Value`+
#                  scale(`Casual Moviegoer (6-12 annual)_Value`)+
#                  scale(log(`Avg_Comp_Index`+1))+
#                  scale(`lc_Interest to Buy EST_new`)+
#                  `md_sourceBased on TV`,
#                data= train_data)
# 
# 
# summary(lr_model)