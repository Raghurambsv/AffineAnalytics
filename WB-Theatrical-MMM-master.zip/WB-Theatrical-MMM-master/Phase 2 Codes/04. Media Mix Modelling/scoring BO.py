# importing modules
import numpy as np
import pandas as pd
import statsmodels.api as sm
import sys
# importing user defined modules
sys.path.insert(0, r"C:/Users/Sandeep Sanyal/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/06. Miscellaneous")
from model_objects import *

for sheet in ["P50"]:
    # importing dataset
    scoring_data = pd.read_excel(
        io=r"C:\Users\Sandeep Sanyal\Desktop\shit file.xlsx",
        sheet_name=sheet,
        na_values=['#NA', '#N/A', 'NA', 'na', '', ' ']
    )

    # renaming columns
    scoring_data.rename(
        columns={
            "IMDB Title Code": "imdb_title_code",
            "IMDB Title Name": "imdb_title_name",
            "Theatrical Release Date": "theatrical_release_date",
            "TH Week Number": "th_week_number",
            "Genre": "Genre",
            "Digital Spend Adstock 0.56": "Total Digital Spends Adstock Linear0.56",
            "Linear Spend Adstock 0.616": "bo_total_linear_spend_adstock_linear0_616",
            "Radio Spend Adstock 0.66": "bo_total_radio_spend_adstock_linear0_66",
            "Outdoor & Print Spend Adstock 0.721": "bo_outdoor_print_spend_adstock_linear0_721",
            "Sequel: Based on Theatrical Release Order (flag)": "Prequel/ Sequel",
            "Cast Strength": "actors_avg_rating",
            "Only distributed by WB (flag)": "distribution_only",
            "DC Universe (flag)": "DC Universe",
            "Metadata: Source": "Metadata: Source",
            "Age Group": "age",
            "Income Group": "income",
            "Google Search Volume": "max_google_search_volume_till_-4",
            "Competitor Effect": "Average Comp Index",
            "Genre - Action (flag)": "Action",
            "Genre - Horror (flag)": "Horror",
            "Genre - Family (flag)": "Family",
            "Movie Metadata: Source Based on Fiction Book/Short Story (flag)": "Source_Based on Fiction Book/Short Story",
            "Movie Metadata: Source Based on Folk Tale/Legend/Fairytale (flag)": "Source_Based on Folk Tale/Legend/Fairytale",
            "Movie Metadata: Source Spin-Off (flag)": "Source_Spin-Off",
            "High Income Group ($100K+ annual HH) (flag)": "income_High Income ($100K+ annual HH)",
            "Age: Under 18 (flag)": "age_Under 18",
            "Age: Above 50 (flag)": "age_50 & over",
            "TH Week Number 1 (flag)": "th_week_number_1",
            "TH Week Number 2 (flag)": "th_week_number_2",
            "TH Week Number 3 (flag)": "th_week_number_3",
            "TH Week Number 4 (flag)": "th_week_number_4"
        },
        inplace=True
    )

    # adding constant term
    scoring_data['const'] = 1

    # log transformations
    cont_var = [
        'max_google_search_volume_till_-4'
        ,'Total Digital Spends Adstock Linear0.56'
        ,'bo_total_linear_spend_adstock_linear0_616'
        ,'bo_total_radio_spend_adstock_linear0_66'
        ,'bo_outdoor_print_spend_adstock_linear0_721'
        ,'Average Comp Index'
    ]
    for col in cont_var:
        scoring_data[col] = np.log(scoring_data[col]+1)
    del col

    # selecting independent variables
    indep_vars = [
        'const'
        # ,'th_week_number'
        ,'Total Digital Spends Adstock Linear0.56'
        # ,'bo_digital_spend_adstock_linear0_516'
        # ,'bo_digital_video_spend_adstock_linear0_686'
        ,'bo_total_linear_spend_adstock_linear0_616'
        ,'bo_total_radio_spend_adstock_linear0_66'
        ,'bo_outdoor_print_spend_adstock_linear0_721'
        # ,'bo_ooh_experiential_spend_adstock_linear0_568'
        ,'actors_avg_rating'
        # ,'cast_avg_rating'
        # , 'audience_demo_metric'
        # ,'holiday_flag'
        # ,'long_weekend_flag'
        ,'Prequel/ Sequel'
        #,'Franchise'
        ,'distribution_only'
        , "Action"
        # , "Adventure"
        # , "Thriller/Suspense"
        , "Horror"
        # , "Drama"
        # , "Comedy"
        , "Family"
        , "DC Universe"
        # , "Conjuring Universe"
        # , "Lego Universe"
        #,'week_0_flag'
        #,'week_number_0'
        , 'max_google_search_volume_till_-4'
        # , 'avg_google_search_volume_till_-4'
        # ,'Competitor Index'
        ,'Average Comp Index'
        # , 'Source_Based on Comic/Graphic Novel'
        # , 'Source_Based on Factual Book/Article'
        , 'Source_Based on Fiction Book/Short Story'
        , 'Source_Based on Folk Tale/Legend/Fairytale'
        # , 'Source_Based on Game'
        # , 'Source_Based on Real Life Events'
        # , 'Source_Based on Short Film'
        # , 'Source_Based on TV'
        # , 'Source_Based on Toy'
        # , 'Source_Original Screenplay'
        # , 'Source_Remake'
        , 'Source_Spin-Off'
        # ,'income_Low income (<$50K annual HH)'
        # ,'income_Middle Income ($50K-$99K annual HH)'
        ,'income_High Income ($100K+ annual HH)'
        ,'age_Under 18'
        # ,'age_25-34'
        # ,'age_35-49'
        ,'age_50 & over'
        , 'th_week_number_1'
        , 'th_week_number_2'
        , 'th_week_number_3'
        ,'th_week_number_4'
        # ,'th_week_number_5'
        # ,'th_week_number_6'
        # ,'th_week_number_7'
        # ,'th_week_number_8'
    ]

    # scoring
    scoring_data['predicted'] = model.predict(exog=scoring_data[indep_vars]).tolist()
    scoring_data['predicted'] = np.exp(scoring_data['predicted'])-1

    with pd.ExcelWriter(
            path=r"C:\Users\Sandeep Sanyal\Desktop\shit file.xlsx",
            mode='a',
            date_format='YYYY-MM-DD',
            datetime_format='DD-MMM-YYYY') as writer:
        scoring_data.to_excel(
            excel_writer=writer,
            index=False,
            sheet_name=sheet+"Scored",
            engine='openpyxl'
        )
    print(sheet+" done")
