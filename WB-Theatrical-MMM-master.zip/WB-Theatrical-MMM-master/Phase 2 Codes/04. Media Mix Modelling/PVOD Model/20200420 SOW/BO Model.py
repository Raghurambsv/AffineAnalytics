# importing modules
import numpy as np
import pandas as pd
import statsmodels.api as sm
import sys
# importing user defined modules
# change the path in the below line : enter folder path of where model_objects.py file is
sys.path.insert(0, r"C:/Users/Sandeep Sanyal/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/04. Media Mix Modelling/PVOD Model/20200420 SOW")
import model_objects

# importing dataset
base_data = pd.read_excel(
    # enter full path of where PVOD Modelling AD file is located in the line below
    io=r"C:\Users\Sandeep Sanyal\Desktop\Overall AD.xlsx",
    sheet_name="BO Present",
    na_values=['#NA','#N/A','NA','na','',' ']
)

# dropping titles
# base_data = base_data.loc[
#     ~base_data['IMDB Title Name'].isin(
#         ["The Kitchen"]
#     )
# ]

# adding constant term
base_data['const'] = 1

dep_var = "BO Revenue (Total)"
# log transformations
cont_var = [
    # dep_var,
    "Number of Theaters Released in",
    'Tomatometer Critic Score',
    # "Unaided Awareness",
    'Total_Unaid_awareness',
    'Max_unaided',
    "Google Search Volume (Max)",
    "Google Search Volume (Mean)"
]
for col in cont_var:
    base_data[col] = np.log(base_data[col]+1)
del col

# selecting independent variables
indep_vars = [
    'const',
    "Number of Theaters Released in",
    # "Unaided Awareness",
    # 'Total_Unaid_awareness',
    # 'Max_unaided',
    # 'Tomatometer Critic Score',
    # "Google Search Volume (Max)",
    "Google Search Volume (Mean)",
    # 'Franchise (flag)',
    'DC/Marvel Universe (Flag)',
    # 'Sequel: Based on Theatrical Release Order',
    # 'Runtime Bin < 90',
    # 'Runtime Bin (90 - 100)',
    # 'Runtime Bin (100 - 110)',
    # 'Runtime Bin (110 - 120)',
    # 'Runtime Bin >= 120',
    # 'Source_Original Screenplay',
    # 'Source_Based on Movie',
    # 'Source_Based on Fiction Book/Short Story',
    # 'Source_Based on Game',
    # 'Source_Remake',
    # 'Source_Based on Real Life Events',
    # 'Source_Based on Factual Book/Article',
    # 'Source_Based on TV',
    # 'Source_Based on Comic/Graphic Novel'
    # 'Source_Based on Toy',
    # 'Source_Spin-Off',
    # "Action",
    # "Adventure",
    # "ActionAdventure",
    # "Family",
    # "Comedy",
    # "Romance",
    # "RomCom",
    # "Drama",
    # "Horror",
    # "Thriller",
    # "Suspense",
    # "Animation",
    # "Music"
]

title_identifier_vars = [
    'IMDB Title Code'
    ,'IMDB Title Name'
    ,'Theatrical Release Date'
    ,'MKT Genre (Grouped)'
    ,'Genre (numbers)'
    ,'Genre (imdb)'
]

# subset dataset
train_data = base_data[title_identifier_vars + [dep_var] + indep_vars].reset_index(drop=True)

# model development
model = sm.OLS(endog=train_data[dep_var],
               exog=train_data[indep_vars]).fit()

# print model summary
print(model.summary())

# print VIF
print(model_objects.vif(X=train_data[indep_vars]))

# exporting model predictions
train_data['predicted'] = model.predict(exog=train_data[indep_vars]).tolist()
# train_data['predicted'] = np.exp(train_data['predicted'])-1

predictions = train_data.drop('const', axis=1)
# predictions = train_data.copy()

for col in list(set(cont_var).intersection(predictions.columns.values.tolist())):
    predictions[col] = np.exp(predictions[col])-1

predictions['Absolute Error'] = np.absolute(
    predictions[dep_var] -
    predictions['predicted']
)
predictions['Percentage Error'] = (
        predictions['Absolute Error'] /
        predictions[dep_var]
)

model_performace = model_objects.model_results(
    model=model,
    train_data=train_data,
    indep_vars=indep_vars
)

# title_level_predictions_wb = title_level_predictions.loc[title_level_predictions["Studio"]== "WB",:]
print("Whole Model error % is :",(100)*((predictions['Absolute Error'].sum())/(predictions[dep_var].sum())))
# print("WB Model error % is :",(100)*((title_level_predictions_wb['Absolute Error'].sum())/(title_level_predictions_wb[dep_var].sum())))


# export model summary / results / predictions
with pd.ExcelWriter(
    # change path below where you wish to export results
        path=r"C:/Users/Sandeep Sanyal/Desktop/output.xlsx",
        mode='w',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    model_performace.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='mode_performance',
        engine='openpyxl')
    predictions.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='title',
        engine='openpyxl')
