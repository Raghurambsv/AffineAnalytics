# importing modules
import numpy as np
import pandas as pd

# importing dataset
scoring_data = pd.read_excel(
    # enter full path of where PVOD Modelling AD file is located in the line below
    io=r"C:\Users\Sandeep Sanyal\Desktop\Overall AD.xlsx",
    sheet_name="Scoring",
    na_values=['#NA','#N/A','NA','na','',' ']
)

# adding constant term
scoring_data['const'] = 1

scoring_data.rename(
    {
        "Number of Theaters Released in": "Actual Number of Theaters Released in"
    },
    axis=1,
    inplace=True
)

scoring_full = pd.DataFrame()

# changing number of "Number of Theaters Released in"
for ntheaters in np.arange(0, 110, 10):
    scoring_data2 = scoring_data.copy()
    scoring_data2["% theaters open"] = ntheaters
    scoring_data2["Number of Theaters Released in"] = round(scoring_data2["Actual Number of Theaters Released in"] * (ntheaters/100), 0)

    cont_var = [
        "Number of Theaters Released in",
        "Google Search Volume (Max)"
    ]
    for col in cont_var:
        scoring_data2[col] = np.log(scoring_data2[col]+1)
    del col

    scoring_data2['predictions'] = model.predict(
            exog=scoring_data2[indep_vars]
        ).tolist()
    #) - 1

    for col in cont_var:
        scoring_data2[col] = np.exp(scoring_data2[col]) - 1
    del col, scoring_data2['const']

    scoring_full = pd.concat(
        [
            scoring_full,
            scoring_data2
        ],
        axis=0
    )

    del scoring_data2

with pd.ExcelWriter(
    # change path below where you wish to export results
        path=r"C:/Users/Sandeep Sanyal/Desktop/score.xlsx",
        mode='w',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    scoring_full.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='Sheet1',
        engine='openpyxl'
    )