"""
Run this code after running model development code to get objects "model" & "indep_vars
"""


# importing modules
import numpy as np
import pandas as pd

# importing dataset
scoring_data = pd.read_excel(
    # enter full path of where PVOD Modelling AD file is located in the line below
    io=r"C:/Users/Sandeep Sanyal/Downloads/PVOD+EST_Scoring.xlsx",
    sheet_name="Master AD New",
    na_values=['#NA','#N/A','NA','na','',' ']
)

# adding constant term
scoring_data['const'] = 1

#variable transformation
# log transformations
cont_var = [
    'Tomatometer Critic Score',
    'Max_unaided',
    "Interest to Buy EST",
]
for col in cont_var:
    scoring_data[col] = np.log(scoring_data[col]+1)
del col

scoring_data['predictions'] = np.exp(
    model.predict(
        exog=scoring_data[indep_vars]
    ).tolist()
) - 1

with pd.ExcelWriter(
    # change path below where you wish to export results
        path=r"C:/Users/Sandeep Sanyal/Desktop/score.xlsx",
        mode='w',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    scoring_data.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='Sheet1',
        engine='openpyxl'
    )