# importing modules
import numpy as np
import pandas as pd
import statsmodels.api as sm
import sys
# importing user defined modules
# change the path in the below line : enter folder path of where model_objects.py file is
sys.path.insert(0, r"C:/Users/Sandeep Sanyal/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/04. Media Mix Modelling/PVOD Model/20200420 SOW")
import model_objects

# importing dataset
base_data = pd.read_excel(
    # enter full path of where PVOD Modelling AD file is located in the line below
    io=r"C:/Users/Sandeep Sanyal/Downloads/PVOD Modeling AD v3_beta2.xlsx",
    sheet_name="Sheet1",
    na_values=['#NA','#N/A','NA','na','',' ']
)

# adding constant term
base_data['const'] = 1

base_data["Unaided Awareness"] = base_data["Unaided Awareness"].fillna(0)
base_data["PVOD Revenue"] = base_data["PVOD Revenue"].fillna(0)
base_data["EST Revenue"] = base_data["EST Revenue"].fillna(0)

# variable transformations
## creating dummies
base_data['PVOD Week Number_temp'] = base_data['PVOD Week Number']
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'PVOD Week Number_temp',
                           ],
                           prefix='PVOD Week Number',
                           drop_first=False)
base_data['EST Week Number_temp'] = base_data['EST Week Number']
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'EST Week Number_temp',
                           ],
                           prefix='EST Week Number',
                           drop_first=False)
# base_data['MKT Genre (Grouped)_temp'] = base_data['MKT Genre (Grouped)']
# base_data = pd.get_dummies(data=base_data,
#                            columns=[
#                                'MKT Genre (Grouped)_temp'
#                            ],
#                            prefix='MKT Genre',
#                            drop_first=False)

dep_var = "PVOD + EST Revenue"
# log transformations
cont_var = [
    dep_var,
    "Number of Theaters Released in",
    'Tomatometer Critic Score',
    "Unaided Awareness",
    'Total_Unaid_awareness',
    'Max_unaided',
    # 'PVOD Week Number',
    # 'EST Week Number',
    "Interest to Buy EST",
    "Google Search Volume (Max)",
    "Google Search Volume (Mean)"
]
for col in cont_var:
    base_data[col] = np.log(base_data[col]+1)
del col

# selecting independent variables
indep_vars = [
    'const',
    "Number of Theaters Released in",
    # "Unaided Awareness",
    # 'Total_Unaid_awareness',
    'Max_unaided',
    # 'Tomatometer Critic Score',
    "Interest to Buy EST",
    # "Google Search Volume (Max)",
    # "Google Search Volume (Mean)",
    # "EST (flag)",
    "PVOD (flag)",
    # 'PVOD Week Number',
    'PVOD Week Number_1',
    'PVOD Week Number_2',
    'PVOD Week Number_3',
    'PVOD Week Number_4',
    'PVOD Week Number_5',
    'PVOD Week Number_6',
    # 'PVOD Week Number_7',
    # 'PVOD Week Number_8',
    # 'PVOD Week Number_9',
    # 'PVOD Week Number_10',
    # 'EST Week Number',
    'EST Week Number_1',
    'EST Week Number_2',
    'EST Week Number_3',
    'EST Week Number_4',
    'EST Week Number_5',
    'EST Week Number_6',
    'EST Week Number_7',
    'EST Week Number_8',
    'EST Week Number_9',
    'EST Week Number_10',
    'EST Week Number_11',
    'EST Week Number_12',
    'EST Week Number_13',
    'EST Week Number_14',
    'EST Week Number_15',
    # 'EST Week Number_16',
    # 'EST Week Number_17',
    # 'EST Week Number_18',
    # 'EST Week Number_19',
    # 'EST Week Number_20',
    # 'MKT Genre_Action/Adventure',
    # 'MKT Genre_Comedy',
    # 'MKT Genre_Drama',
    # 'MKT Genre_Family'
    # 'Franchise (flag)',
    # "Franchise_week_2_onwards",
    # 'DC/Marvel Universe (Flag)',
    # 'Runtime Bin < 90',
    # 'Runtime Bin (90 - 100)',
    # 'Runtime Bin (100 - 110)',
    'Runtime Bin (110 - 120)',
    # 'Runtime Bin >= 120',
    'Source_Original Screenplay',
    # 'Source_Based on Movie',
    # 'Source_Based on Fiction Book/Short Story',
    # 'Source_Based on Game',
    # 'Source_Remake',
    'Source_Based on Real Life Events',
    # 'Source_Based on Factual Book/Article',
    # 'Source_Based on TV',
    # 'Source_Based on Comic/Graphic Novel'
    # 'Source_Based on Toy',
    # 'Source_Spin-Off',
    # "Action",
    "Adventure",
    # "ActionAdventure",
    # "Family",
    "Comedy",
    # "Romance",
    # "RomCom",
    # "Drama",
    "Horror",
    # "Thriller",
    # "Suspense",
    # "Animation"
    # "Musical"
]

title_identifier_vars = [
    'IMDB Title Code'
    ,'IMDB Title Name'
    ,'Theatrical Release Date'
    ,'PVOD Week Number'
    ,'MKT Genre (Grouped)'
    ,'Genre (numbers)'
    ,'Genre (imdb)'
    ,'Studio'
]

# subset dataset
train_data = base_data[title_identifier_vars + [dep_var] + indep_vars].reset_index(drop=True)

# model development
model = sm.OLS(endog=train_data[dep_var],
               exog=train_data[indep_vars]).fit()

# print model summary
print(model.summary())

# print VIF
print(model_objects.vif(X=train_data[indep_vars]))

# exporting model predictions
train_data['predicted'] = model.predict(exog=train_data[indep_vars]).tolist()
train_data['predicted'] = np.exp(train_data['predicted'])-1

predictions = train_data.copy()

for col in list(set(cont_var).intersection(predictions.columns.values.tolist())):
    predictions[col] = np.exp(predictions[col])-1
ids = [
    'IMDB Title Code'
    ,'IMDB Title Name'
    ,'Theatrical Release Date'
    ,'MKT Genre (Grouped)'
    ,'Genre (numbers)'
    ,'Genre (imdb)'
    ,'Studio'
    # ,'MKT Genre (Grouped)'
    # ,'Franchise (flag)'
    # ,'DC/Marvel Universe (Flag)'
]
title_level_predictions = predictions.groupby(ids).agg(
    {

        # "Studio":np.unique,
        dep_var:'sum',
        'predicted':'sum'
    }
).reset_index()
title_level_predictions['Absolute Error'] = np.absolute(
    title_level_predictions[dep_var] -
    title_level_predictions['predicted']
)
title_level_predictions['Percentage Error'] = (
        title_level_predictions['Absolute Error'] /
        title_level_predictions[dep_var]
)

model_performace = model_objects.model_results(
    model=model,
    train_data=train_data,
    indep_vars=indep_vars
)

title_level_predictions_wb = title_level_predictions.loc[title_level_predictions["Studio"]== "WB",:]
print("Whole Model error % is :",(100)*((title_level_predictions['Absolute Error'].sum())/(title_level_predictions['PVOD + EST Revenue'].sum())))
print("WB Model error % is :",(100)*((title_level_predictions_wb['Absolute Error'].sum())/(title_level_predictions_wb['PVOD + EST Revenue'].sum())))


# export model summary / results / predictions
with pd.ExcelWriter(
    # change path below where you wish to export results
        path=r"C:/Users/Sandeep Sanyal/Desktop/output.xlsx",
        mode='w',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    model_performace.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='mode_performance',
        engine='openpyxl')
    predictions.drop('const', axis=1).to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='title-week',
        engine='openpyxl')
    title_level_predictions.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='title',
        engine='openpyxl')
