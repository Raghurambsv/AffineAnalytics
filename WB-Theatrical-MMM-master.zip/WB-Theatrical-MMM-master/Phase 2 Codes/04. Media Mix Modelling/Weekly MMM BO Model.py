# importing modules
import numpy as np
import pandas as pd
import statsmodels.api as sm
import sys
# importing user defined modules
sys.path.insert(0, r"C:/Users/Sandeep Sanyal/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/06. Miscellaneous")
from model_objects import *

# importing dataset
base_data = pd.read_excel(
    io=r"C:/Users/Sandeep Sanyal/Affine Analytics Pvt Ltd/WB Theatrical - Documents/04. Media Mix Modelling/Refresh 01/Analytical Datasets/Modelling AD/bo_modelling_ad_11_03_2020.xlsx",
    sheet_name="Sheet1",
    na_values=['#NA', '#N/A', 'NA', 'na', '', ' ']
)
# adding constant term
base_data['const'] = 1

# subsetting dataset
base_data = base_data.loc[
    ~base_data['imdb_title_name'].isin(
        [
            # 'The 15:17 to Paris' # train, high error
            # ,'War Dogs'  # removed in Phase 1
            # 'Pan'  # removed in Phase 1
            # ,'The Lego Ninjago Movie'  # removed in Phase 1
            # ,'CHIPS'  # removed in Phase 1
            # 'Central Intelligence'  # removed in Phase 1
            # 'It'
            # 'Run All Night'
            # 'In the Heart of the Sea'
            # ,'The Man from U.N.C.L.E.'
            # ,'Hot Pursuit'
            'San Andreas'
            , 'A Star Is Born'

            # , "Motherless Brooklyn"  # <12MM BO Revenue  # test title
            , "Our Brand Is Crisis"  # <12MM BO Revenue
            , "Live by Night"  # <12MM BO Revenue
            , "Midnight Special"  # <12MM BO Revenue, no GS Data
            , "The Water Diviner"  # <12MM BO Revenue
            , "Unforgettable"  # <12MM BO Revenue
            , "We Are Your Friends"  # <12MM BO Revenue
            # , "The Goldfinch"  # <12MM BO Revenue  # test title
            , "Head Full of Honey"  # <12MM BO Revenue, no GS Data
            # , "The Sun Is Also a Star"  # <12MM BO Revenue  # test title
            # , "It Chapter Two"  # 0MM BO Revenue  # test title
            # , "Blinded by the Light"  # <12MM BO Revenue  # test title
            , "Crazy Rich Asians"  # outlier title
            # , "They Shall Not Grow Old"  # outlier title, only Documentary Title, no GS Data  # test title
            # , "Joker"  # test title
            # , "The Kitchen"  # test title
            # , "Justice League"
            # , "Doctor Sleep"  # test title
        ]
    )
]

base_data = base_data.loc[(base_data['th_week_number']>=0) & (base_data['th_week_number']<=8),:]
base_data['th_week_number_temp'] = base_data['th_week_number']
base_data['Metadata: Source_temp'] = base_data['Metadata: Source']
base_data['age_temp'] = base_data['age']
base_data['income_temp'] = base_data['income']

# variable transformations
## creating dummies
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'th_week_number_temp',
                           ],
                           prefix='th_week_number',
                           drop_first=False)
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'Metadata: Source_temp'
                           ],
                           prefix='Source',
                           drop_first=False)
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'income_temp'
                           ],
                           prefix='income',
                           drop_first=False)
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'age_temp'
                           ],
                           prefix='age',
                           drop_first=False)
Genre = [
    "Action",
    "Adventure",
    "Horror",
    "Family",
    "Comedy",
    "Drama",
    "Thriller/Suspense"
]
for i in base_data.index:
    for gen in Genre:
        if gen in base_data.loc[i, "Genre"]:
            base_data.loc[i, gen] = 1
        else:
            base_data.loc[i, gen] = 0

# log transformations
cont_var = [
    'bo_revenue'
    # ,'th_week_number'
    , 'max_google_search_volume_till_-4'
    , 'avg_google_search_volume_till_-4'
    ,'Total Digital Spends Adstock Linear0.56'
    ,'bo_digital_spend_adstock_linear0_516'
    ,'bo_digital_video_spend_adstock_linear0_686'
    ,'bo_total_linear_spend_adstock_linear0_616'
    ,'bo_total_radio_spend_adstock_linear0_66'
    ,'bo_outdoor_print_spend_adstock_linear0_721'
    ,'bo_ooh_experiential_spend_adstock_linear0_568'
    ,'cast_avg_rating'
    ,'Competitor Index'
    ,'Average Comp Index'
    ,'audience_demo_metric'
]
for col in cont_var:
    base_data[col] = np.log(base_data[col]+1)
del col

# standardize
# for col in [x for x in cont_var if x!='bo_revenue']:
#     base_data[col] = (base_data[col] - np.mean(base_data[col]))/np.std(base_data[col])
# del col

# selecting independent variables
indep_vars = [
    'const'
    # ,'th_week_number'
    ,'Total Digital Spends Adstock Linear0.56'
    # ,'bo_digital_spend_adstock_linear0_516'
    # ,'bo_digital_video_spend_adstock_linear0_686'
    ,'bo_total_linear_spend_adstock_linear0_616'
    ,'bo_total_radio_spend_adstock_linear0_66'
    ,'bo_outdoor_print_spend_adstock_linear0_721'
    # ,'bo_ooh_experiential_spend_adstock_linear0_568'
    ,'actors_avg_rating'
    # ,'cast_avg_rating'
    # , 'audience_demo_metric'
    # ,'holiday_flag'
    # ,'long_weekend_flag'
    ,'Prequel/ Sequel'
    #,'Franchise'
    ,'distribution_only'
    , "Action"
    # , "Adventure"
    # , "Thriller/Suspense"
    , "Horror"
    # , "Drama"
    # , "Comedy"
    , "Family"
    , "DC Universe"
    # , "Conjuring Universe"
    # , "Lego Universe"
    #,'week_0_flag'
    #,'week_number_0'
    , 'max_google_search_volume_till_-4'
    # , 'avg_google_search_volume_till_-4'
    # ,'Competitor Index'
    ,'Average Comp Index'
    # , 'Source_Based on Comic/Graphic Novel'
    # , 'Source_Based on Factual Book/Article'
    , 'Source_Based on Fiction Book/Short Story'
    , 'Source_Based on Folk Tale/Legend/Fairytale'
    # , 'Source_Based on Game'
    # , 'Source_Based on Real Life Events'
    # , 'Source_Based on Short Film'
    # , 'Source_Based on TV'
    # , 'Source_Based on Toy'
    # , 'Source_Original Screenplay'
    # , 'Source_Remake'
    , 'Source_Spin-Off'
    # ,'income_Low income (<$50K annual HH)'
    # ,'income_Middle Income ($50K-$99K annual HH)'
    ,'income_High Income ($100K+ annual HH)'
    ,'age_Under 18'
    # ,'age_25-34'
    # ,'age_35-49'
    ,'age_50 & over'
    , 'th_week_number_1'
    , 'th_week_number_2'
    , 'th_week_number_3'
    ,'th_week_number_4'
    # ,'th_week_number_5'
    # ,'th_week_number_6'
    # ,'th_week_number_7'
    # ,'th_week_number_8'
]

title_identifier_vars = [
    'imdb_title_code'
    ,'imdb_title_name'
    ,'theatrical_release_date'
    ,'th_week_number'
    ,'Genre'
    ,'Metadata: Source'
    ,'age'
    ,'income'
]

# subset dataset
train_data = base_data.loc[
    (base_data['th_release_year']>=2015) & (base_data['th_release_year']<=2018),
    title_identifier_vars + ['bo_revenue'] + indep_vars
].reset_index(drop=True)
test_data = base_data.loc[
    base_data['th_release_year']>=2019,
    title_identifier_vars + ['bo_revenue'] + indep_vars
].reset_index(drop=True)

# model development
model = sm.OLS(
    endog=train_data['bo_revenue'],
    exog=train_data[indep_vars]
).fit()

# print model summary
print(model.summary())

# print VIF
print(vif(X=train_data[indep_vars]))

# exporting model predictions
train_data['predicted'] = model.predict(exog=train_data[indep_vars]).tolist()
train_data['predicted'] = np.exp(train_data['predicted'])-1
train_data['set'] = 'train'
test_data['predicted'] = model.predict(exog=test_data[indep_vars]).tolist()
test_data['predicted'] = np.exp(test_data['predicted'])-1
test_data['set'] = 'test'

predictions = pd.concat(
    [
        train_data,
        test_data
    ],
    axis=0
)
for col in list(set(cont_var).intersection(predictions.columns.values.tolist())):
    predictions[col] = np.exp(predictions[col])-1
ids = [
    'imdb_title_code'
    ,'imdb_title_name'
    ,'theatrical_release_date'
    ,'Genre'
    ,'Prequel/ Sequel'
    ,"DC Universe"
    # ,"Conjuring Universe"
    # ,"Lego Universe"
    ,'distribution_only'
    ,'Metadata: Source'
    ,'age'
    ,'income'
]
title_level_predictions = predictions.groupby(ids).agg(
    {
        'bo_revenue':'sum',
        'predicted':'sum',
        'set':'unique'
    }
).reset_index()
title_level_predictions['Absolute Error'] = np.absolute(
    title_level_predictions['bo_revenue'] -
    title_level_predictions['predicted']
)
title_level_predictions['Percentage Error'] = (
        title_level_predictions['Absolute Error'] /
        title_level_predictions['bo_revenue']
)

# title level WMAPE
print(
    'Train WMAPE:' +
    str(
        title_level_model_accuracies(df=train_data,dep_var='bo_revenue',indep_vars=indep_vars,model=model,ids=ids,transform_dep_var="log")["WMAPE"] * 100
    )
)
print(
    'Test WMAPE:' +
    str(
        title_level_model_accuracies(df=test_data,dep_var='bo_revenue',indep_vars=indep_vars,model=model,ids=ids,transform_dep_var="log")["WMAPE"] * 100
    )
)

model_performace = model_results(model=model,train_data=train_data,test_data=test_data,indep_vars=indep_vars,dep_var='bo_revenue',transform_dep_var='log')
model_performace["Train MAE"] = title_level_model_accuracies(df=train_data,dep_var='bo_revenue',indep_vars=indep_vars,model=model,ids=ids,transform_dep_var="log")["MAE"]
model_performace["Train MAPE"] = title_level_model_accuracies(df=train_data,dep_var='bo_revenue',indep_vars=indep_vars,model=model,ids=ids,transform_dep_var="log")["MAPE"]
model_performace["Train WMAPE"] = title_level_model_accuracies(df=train_data,dep_var='bo_revenue',indep_vars=indep_vars,model=model,ids=ids,transform_dep_var="log")["WMAPE"]
model_performace["Test MAE"] = title_level_model_accuracies(df=test_data,dep_var='bo_revenue',indep_vars=indep_vars,model=model,ids=ids,transform_dep_var="log")["MAE"]
model_performace["Test MAPE"] = title_level_model_accuracies(df=test_data,dep_var='bo_revenue',indep_vars=indep_vars,model=model,ids=ids,transform_dep_var="log")["MAPE"]
model_performace["Test WMAPE"] = title_level_model_accuracies(df=test_data,dep_var='bo_revenue',indep_vars=indep_vars,model=model,ids=ids,transform_dep_var="log")["WMAPE"]

with pd.ExcelWriter(
        path=r"C:\Users\Sandeep Sanyal\Desktop\test.xlsx",
        mode='w',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    model_performace.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='mode_performance',
        engine='openpyxl')
    predictions.drop('const', axis=1).to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='title-week',
        engine='openpyxl')
    title_level_predictions.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='title',
        engine='openpyxl')
