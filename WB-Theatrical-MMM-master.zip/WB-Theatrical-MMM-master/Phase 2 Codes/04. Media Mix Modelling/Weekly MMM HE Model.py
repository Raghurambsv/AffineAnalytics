# importing modules
import numpy as np
import pandas as pd
import statsmodels.api as sm
import sys
# importing user defined modules
sys.path.insert(0, r"/home/sandeepsanyal/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/06. Miscellaneous")
from model_objects import *

# importing dataset
base_data = pd.read_excel(io=r"/home/sandeepsanyal/OneDrive/01. Data Harmonization-Cleaning/03. Analytical Datasets/modelling_ad_he_11_12_2019.xlsx",
                          sheet_name="modelling_ad_he_11_12_2019",
                          na_values=['#NA','#N/A','NA','na','',' '])
# adding constant term
base_data = sm.add_constant(base_data)

# subsetting dataset
base_data = base_data.loc[~base_data['imdb_title_name'].isin(['They Shall Not Grow Old' # <5MM HE Revenue
                                                              ,'Head Full of Honey' # No HE Revenue
                                                              ,'Hot Pursuit' # no linear co-op spends
                                                              ,'The Sun Is Also a Star' # <5MM HE Revenue
                                                              ,'Midnight Special' # no comp index
                                                              ,'The Water Diviner' # <10MM BO Revenue
                                                              ,'We Are Your Friends' # <5MM HE Revenue
                                                              ,'Live by Night' # <12MM BO Revenue
                                                              ,'Entourage' # no comp index
                                                              ,'Teen Titans Go! To the Movies' # no linear co-op spends
                                                              ,'Going in Style' # no comp index
                                                              ,'Point Break' # no comp index
                                                              #,'Unforgettable' # <12MM BO Revenue
                                                              #,'Pan' # train # high error title
                                                              #,'The Lego Ninjago Movie' # train # high error title
                                                              #,'CHIPS' # train # high error title
                                                              #,'San Andreas' # train
                                                              #,'Central Intelligence' # train
                                                              ,'Barbershop: The Next Cut' # no linear co-op spends
                                                              ,'Creed' # no linear co-op spends
                                                              ,'Tomb Raider' # no linear co-op spends
                                                              ,"Ocean's Eight" # no linear co-op spends
                                                              ,'Life of the Party' # no linear co-op spends
                                                              #,'The Lego Movie 2: The Second Part' # test # high error title
                                                              #,"Ocean's Eight" # test
                                                              #,'Pokemon Detective Pikachu' # test
                                                              #,'The Nun' # test
                                                              #,'Crazy Rich Asians' # test
                                                              #,'A Star Is Born' # test
                                                             ])]

base_data = base_data.loc[(base_data['he_week_number']>=0) & (base_data['he_week_number']<=30),:]
base_data['he_week_number_temp'] = base_data['he_week_number']
base_data['mkt_genre_grouped_temp'] = base_data['mkt_genre_grouped']
base_data['mpaa_rating_temp'] = base_data['mpaa_rating']
base_data['runtime_bin_temp'] = base_data['runtime_bin']

# variable transformations
## creating dummies
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'he_week_number_temp',
                           ],
                           prefix='he_week_number',
                           drop_first=False)
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'mkt_genre_grouped_temp'
                           ],
                           prefix='genre',
                           drop_first=False)
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'mpaa_rating_temp'
                           ],
                           prefix='mpaa_rating',
                           drop_first=False)
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'runtime_bin_temp'
                           ],
                           prefix='runtime_bin',
                           drop_first=False)


#base_data['week_0_flag'] = [1 if base_data.loc[i,'week_number']==0 else 0 for i in base_data.index]
# log transformations
cont_var = [
    'he_revenue'
    ,'he_week_number'
,"he_spend_digital Adstock Linear0.841"
,"he_spend_digital_video Adstock Linear0.848"
,"he_spend_linear-coop Adstock Linear0.842"
,"he_spend_non-digital Adstock Linear0.841"
,"max_google_search_volume_till_-4"
,"avg_google_search_volume_till_-4"
,"max_wikipedia_page_views_till_-4"
,"avg_wikipedia_page_views_till_-4"
,"google_search_volume_-4_adstock_linear0.9"
,"wikipedia_page_views_-4_adstock_linear0.9"
,"cast_avg_rating"
,"competitor_index_8_weeks"
,"competitor_index_3_weeks"
,"top3_competitor_index_3_weeks"
,"top3_competitor_index_2_weeks"
,"top3_competitor_index_1_week"
]
for col in cont_var:
    base_data[col] = np.log(base_data[col]+1)
del col

# selecting independent variables
indep_vars = [
    'const'
    #,'week_number'
    #,'franchise_releases_in_last_5_years'
    , "he_spend_digital Adstock Linear0.841"
    , "he_spend_digital_video Adstock Linear0.848"
    , "he_spend_linear-coop Adstock Linear0.842"
    , "he_spend_non-digital Adstock Linear0.841"
#,"max_google_search_volume_till_-4"
#,"avg_google_search_volume_till_-4"
#,"max_wikipedia_page_views_till_-4"
,"avg_wikipedia_page_views_till_-4"
#,"google_search_volume_-4_adstock_linear0.9"
#,"wikipedia_page_views_-4_adstock_linear0.9"
#,"cast_avg_rating"
#,"competitor_index_8_weeks"
#,"competitor_index_3_weeks"
#,"top3_competitor_index_3_weeks"
,"top3_competitor_index_2_weeks"
#,"top3_competitor_index_1_week"
,"franchise_flag"
#,"holiday_flag"
,"long_weekend_flag"
,"est_week_1_flag"
#,"pst_sellthru_week_0_flag"
,"pst_sellthru_week_1_flag"
,"vod_week_0_flag"
,"vod_week_1_flag"
,"distribution_only"
#,'he_week_number_0',
    ,'he_week_number_1', 'he_week_number_2', 'he_week_number_3'
    ,'he_week_number_4'
    ,'he_week_number_5', 'he_week_number_6'
    ,'he_week_number_7', 'he_week_number_8', 'he_week_number_9'
    ,'he_week_number_10', 'he_week_number_11', 'he_week_number_12'
    ,'he_week_number_13', 'he_week_number_14', 'he_week_number_15'
    ,'he_week_number_16', 'he_week_number_17', 'he_week_number_18'
    ,'he_week_number_19', 'he_week_number_20', 'he_week_number_21'
    ,'he_week_number_22', 'he_week_number_23', 'he_week_number_24'
    ,'he_week_number_25', 'he_week_number_26', 'he_week_number_27'
    ,'he_week_number_28', 'he_week_number_29', 'he_week_number_30'
    #,'genre_Others'
    ,'genre_Action/Adventure'
    #,'genre_Drama'
    #,'genre_Family'
    ,'genre_comedy'
    ,'mpaa_rating_PG'
    #,'mpaa_rating_PG-13', 'mpaa_rating_R'
    #, 'runtime_bin_80_to_90_mins'
    #,'runtime_bin_100_to_110_mins'
    #, 'runtime_bin_110_to_120_mins'
    ,'runtime_bin_120_to_130_mins'
    #,'runtime_bin_90_to_100_mins'
    ,'runtime_bin_more_than_130_mins'
]

title_identifier_vars = [
    'imdb_title_code'
    ,'imdb_title_name'
    ,'theatrical_release_date'
    ,'he_week_number'
    ,'mkt_genre_grouped'
]

# subset dataset
train_data = base_data.loc[(base_data['theatrical_release_year']>=2015) &
                           (base_data['theatrical_release_year']<=2017), title_identifier_vars + ['he_revenue'] + indep_vars].reset_index(drop=True)
test_data = base_data.loc[base_data['theatrical_release_year']>=2018, title_identifier_vars + ['he_revenue'] + indep_vars].reset_index(drop=True)

# model development
model = sm.OLS(endog=train_data['he_revenue'],
               exog=train_data[indep_vars]).fit()

# print model summary
print(model.summary())

# print VIF
print(vif(X=train_data[indep_vars]))

# checking accuracies
# print("train accuracy")
# print(model_accuracies(df=train_data,
#                        dep_var='bo_revenue',
#                        indep_vars=indep_vars,
#                        model=model,
#                        transform_dep_var='log'))
# print("test accuracy")
# print(model_accuracies(df=test_data,
#                        dep_var='bo_revenue',
#                        indep_vars=indep_vars,
#                        model=model,
#                        transform_dep_var='log'))

# exporting iteration results
# model_results(model=model,
#               train_data=train_data,
#               test_data=test_data,
#               indep_vars=indep_vars,
#               dep_var='he_revenue',
#               transform_dep_var='log'
#               ,export_path=r"/home/sandeepsanyal/OneDrive/04. Media Mix Modelling/03. Analysis Results/HE TH-30 model results_Sandeep/HE_Iteration_results11-13.xlsx"
#               )

# exporting model predictions
train_data['predicted'] = model.predict(exog=train_data[indep_vars]).tolist()
train_data['predicted'] = np.exp(train_data['predicted'])-1
train_data['set'] = 'train'
print("train accuracy")
print(small_model_accuracies(df=train_data, y='he_revenue', y_hat='predicted', transform_dep_var="log"))
test_data['predicted'] = model.predict(exog=test_data[indep_vars]).tolist()
test_data['predicted'] = np.exp(test_data['predicted'])-1
test_data['set'] = 'test'
print("test accuracy")
print(small_model_accuracies(df=test_data, y='he_revenue', y_hat='predicted', transform_dep_var="log"))
predictions = pd.concat([train_data,
                         test_data],
                        axis=0)
for col in list(set(cont_var).intersection(predictions.columns.values.tolist())):
    predictions[col] = np.exp(predictions[col])-1

title_level_predictions = predictions.groupby(
    [
        'imdb_title_code',
        'imdb_title_name',
        'mkt_genre_grouped',
        'franchise_flag',
        #'Franchise',
        #'Prequel_Sequel',
        'distribution_only'
    ]
).agg({'he_revenue':'sum',
       'predicted':'sum',
       'set':'unique'}).reset_index()
title_level_predictions['Absolute Error'] = np.absolute(title_level_predictions['he_revenue'] - title_level_predictions['predicted'])
title_level_predictions['Percentage Error'] = title_level_predictions['Absolute Error']/title_level_predictions['he_revenue']

# title level WMAPE
print('Train WMAPE:'+str((title_level_predictions.loc[title_level_predictions['set']=='train',['Absolute Error']].sum()[0]/title_level_predictions.loc[title_level_predictions['set']=='train',['he_revenue']].sum()[0])*100))
print('Test WMAPE:'+str((title_level_predictions.loc[title_level_predictions['set']=='test',['Absolute Error']].sum()[0]/title_level_predictions.loc[title_level_predictions['set']=='test',['he_revenue']].sum()[0])*100))

# with pd.ExcelWriter(r"/home/sandeepsanyal/OneDrive/04. Media Mix Modelling/03. Analysis Results/HE TH-30 model results_Sandeep/HE_predictions11-13.xlsx",
#         mode='w',
#         date_format='YYYY-MM-DD',
#         datetime_format='DD-MMM-YYYY') as writer:
#     predictions.drop('const', axis=1).to_excel(
#         excel_writer=writer,
#         index=False,
#         sheet_name='title-week',
#         engine='openpyxl')
#     title_level_predictions.to_excel(
#         excel_writer=writer,
#         index=False,
#         sheet_name='title',
#         engine='openpyxl')
