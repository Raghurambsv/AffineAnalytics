# -*- coding: utf-8 -*-
"""
Created on Wed Aug 21 13:19:03 2019

@author: mukund
"""

import pandas as pd
import numpy as np
import bs4
from requests import get
import multiprocessing
import time

def scrape_film_festivals(title_list):
    country_name_list = []
    date_list = []
    item_attribute_list = []
    title_id_list = []
    for name in title_list:
        print(name)
        time.sleep(5)
        url = "https://www.imdb.com/title/" + name + "/releaseinfo?ref_=tt_ov_inf"
        response = get(url)
        soup = bs4.BeautifulSoup(response.text, 'lxml')
        try:
            x = soup.find_all('table', {'class' : 'ipl-zebra-list ipl-zebra-list--fixed-first release-dates-table-test-only'})[0]
            y = x.find_all('tr', {'class':'ipl-zebra-list__item release-date-item'})
            length = len(y)
            for i in range(0, length):
                country_name = y[i].find_all('td', {'class' : 'release-date-item__country-name'})[0].get_text().strip()
                date = y[i].find_all('td', {'class' : 'release-date-item__date'})[0].get_text().strip()
                try:
                    item_attribute = y[i].find_all('td', {'class' : 'release-date-item__attributes--empty'})[0].get_text()
                except:
                    item_attribute = y[i].find_all('td', {'class' : 'release-date-item__attributes'})[0].get_text().strip().replace('(', '').replace(')', '')
                title_id_list.append(name)
                country_name_list.append(country_name)
                date_list.append(date)
                item_attribute_list.append(item_attribute)
        except:
            title_id_list.append(name)
            country_name_list.append('Not Found')
            date_list.append('Not Found')
            item_attribute_list.append('Not Found')

    return [title_id_list, country_name_list, date_list, item_attribute_list]


if __name__=="__main__":
    #To scrape for all Titles from IMDB
    imdb_scrapper = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\00. Phase 1 Data Dependencies\03. Movie Metadata\IMDB_scrapped_titles_v3.csv") 
    pool = multiprocessing.Pool(processes = 4)
    list_test = [[title] for title in imdb_scrapper['titleID'].tolist()]
    results = pool.map(scrape_film_festivals, list_test)
    results=pd.DataFrame(results)
    
    # To clean the scraped data and convert it to a dataframe
    final_df = pd.DataFrame()
    # To convert list of string type to list type
    results['0'] = results['0'].apply(lambda x: ast.literal_eval(x))
    results['1'] = results['1'].apply(lambda x: ast.literal_eval(x))
    results['2'] = results['2'].apply(lambda x: ast.literal_eval(x))
    results['3'] = results['3'].apply(lambda x: ast.literal_eval(x))

    for row in range(df.shape[0]):
        temp_df = pd.DataFrame({'IMDB Title Code' : results.loc[row, '0'],
                                'Country Name' : results.loc[row, '1'],
                                'Release Date' : results.loc[row, '2'], 
                                'Festival Name' : results.loc[row, '3']})
        final_df = pd.concat([final_df, temp_df], axis=0)
        
    final_df.to_csv(r"C:\Users\mukund\Documents\Feature Engineering\Final_Film_Festival_All.csv", index=False)
 