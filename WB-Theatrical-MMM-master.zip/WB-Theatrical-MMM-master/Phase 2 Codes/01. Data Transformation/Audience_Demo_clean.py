import pandas as pd

def audience_demo_cleaning(raw_file, export_path=False):

    aud_demo = pd.read_csv(raw_file)

    aud_demo_copy = aud_demo.copy()

    #Title codes need to be mapped first

    col = 'Metric'
    values = ['Value', 'Sample Size', '95 CI', 'Fandango Available', 'Movio Available', 'NPD Available', 'Cinema Score Available']
    index = ['IMDB Title Code', 'Release Period']
    metric = list(aud_demo_copy['Metric'].unique())
    masterAD = pd.DataFrame()
    for i, x in enumerate(values):
        if(i==0):
            masterAD = pd.pivot_table(aud_demo_copy, values = x, index = index,
                        columns = col).reset_index()
            updated_col_names = [str(item) + "_" + str(x) if item in metric else item for item in list(masterAD.columns)]
            masterAD.columns = updated_col_names
        else:
            temp = pd.pivot_table(aud_demo_copy, values = x, index = index,
                            columns = col).reset_index()
            updated_col_names = [str(item) + "_" + str(x) if item in metric else item for item in list(temp.columns)]
            temp.columns = updated_col_names
            masterAD = pd.merge(masterAD, temp,
                              how = 'left',
                              on = index)
    masterAD = masterAD[masterAD['Release Period'] == 'day1']
    masterAD=masterAD[['IMDB Title Code','Release Period','18-24_Value','25-34_Value','35-49_Value','50 & over_Value','Afr.-Amer._Value','Asian / Other ethnicity_Value',
                       'Casual Moviegoer (6-12 annual)_Value','Caucasian_Value','Early Attender (see w/in first 10 days)_Value','Females_Value','Females 18-34_Value','Females 35-49_Value',
	                    'Frequent Moviegoer (see 12+ annual)_Value','High Income ($100K+ annual HH)_Value','Infrequent moviegoer (<6 annual)_Value','Latino_Value',
	                    'Low income (<$50K annual HH)_Value','Males_Value','Males 18-34_Value','Males 35-49_Value','Middle Income ($50K-$99K annual HH)_Value',
	                    'Midwest_Value','Northeast_Value','Overall_Value','Parent (of child under 13)_Value','South_Value','Total Sample (#)_Value','Under 18_Value','West_Value']]
    # masterAD.to_csv(export_path)
    return masterAD
