# checking for required modules
import pkg_resources
from subprocess import call
required_packages = [
    "numpy",
    "pandas",
    "xlrd",
    "openpyxl"
]
for package in required_packages:
    if package in [  # list all packages with available latest stable updates
        dist.project_name
        for dist in pkg_resources.working_set
    ]:
        call(  # update all packages in shell
            "pip install --upgrade " + package,
            shell=True
        )
    else:
        call(  # update all packages in shell
            "pip install " + package,
            shell=True
        )

# importing modules
import xlrd
import numpy as np
import pandas as pd
import calendar
import sys

def clean_comp_release_schedule(
        root_folder,
        sharepoint_path,
        input_file_path
):

    """

    :param sharepoint_path:
    :param input_file_path:
    :param export_path:
    :return:
    """

    # importing user defined modules
    sys.path.insert(0, root_folder + r"\Phase 2 Codes\06. Miscellaneous")
    import IMDB_title_code_scraping

    # reading list of all sheets present in the excel file
    sheet_names = xlrd.open_workbook(filename=input_file_path,
                                     on_demand=True).sheet_names()

    CompReleaseSchedule = pd.DataFrame() # creating an empty dataframe
    # preparing column name maps for consistency
    column_maps = {'B.O. \n(Mil.)': 'BO Sales (in Millions)',
                   'B.O. (Mil.)': 'BO Sales (in Millions)',
                   'B.O.\n(Mil.)': 'BO Sales (in Millions)',
                   'BO (Mil.)': 'BO Sales (in Millions)',
                   'EST Release': 'EST Release Date',
                   'Phys Rental \nRelease': 'PST Rental Release Date',
                   'Phys Rental Release': 'PST Rental Release Date',
                   'Phys Rental\nRelease': 'PST Rental Release Date',
                   'VOD\nRelease': 'VOD Release Date',
                   'STREET\nDATE': 'PST Release Date',
                   'STUDIO': 'Studio',
                   'THEAT. DATE': 'Theatrical Release Date',
                   'TITLE': 'Title'}

    for sheet in sheet_names:
        Current_Year = (sheet.strip())[0:4]
        Forecast_Year = (sheet.strip())[len(sheet.strip())-4:len(sheet.strip())+1]
        # importing sheet
        CompReleaseSchedule_raw = pd.read_excel(io=sharepoint_path + r"/WB Theatrical - Documents/01. Data Harmonization-Cleaning/00. Phase 1 Data Dependencies/05. Scoring Data/Raw data/COMPETITIVE RELEASE SCHEDULE  07.26.19.xlsx",
                                                sheet_name=sheet,
                                                na_values="N/A")
        # snipping dataset from sheet
        temp = np.where(CompReleaseSchedule_raw.values == "TITLE")
        first = [x[0] for x in temp] # row-column position of the word "TITLE" present in all sheets
        del temp
        row_end = min(np.where(CompReleaseSchedule_raw.values == "TOTAL")[0]) # row number containing the word "TOTAL"
        col_end = CompReleaseSchedule_raw.shape[1] # last column number of the sheet where data is available
        # keeping column names consistent
        CompReleaseSchedule_raw.replace(column_maps,
                                        inplace=True)
        CompReleaseSchedule_raw.columns = CompReleaseSchedule_raw.iloc[first[0], :].values
        CompReleaseSchedule_raw = CompReleaseSchedule_raw.iloc[range(first[0]+1, row_end), range(first[1], col_end)] # data snippet

        # snipping month wise data per sheet and biding them in row
        for i in np.arange(0, (CompReleaseSchedule_raw.shape[1]-(int(CompReleaseSchedule_raw.shape[1] / 12))+1), (int(CompReleaseSchedule_raw.shape[1] / 12))):
            Forecast_Month =  calendar.month_name[int((i/(CompReleaseSchedule_raw.shape[1] / 12))+1)]
            CompReleaseSchedule = pd.concat([CompReleaseSchedule, # previous data frame
                                             pd.concat([CompReleaseSchedule_raw.iloc[:, range(i, i + (int(CompReleaseSchedule_raw.shape[1] / 12)))].reset_index(drop=True), # dataset snipped at sheet-month level
                                                        pd.DataFrame({'Current Year': [Current_Year] * (CompReleaseSchedule_raw.shape[0]), # appending Current Year
                                                                      'Forecast Year': [Forecast_Year] * (CompReleaseSchedule_raw.shape[0]), # appending Forecasted Year
                                                                      'Forecast Month': [Forecast_Month] * (CompReleaseSchedule_raw.shape[0])})], # appending Forecasted Month
                                                       axis=1)],
                                            axis=0)
    del sheet

    CompReleaseSchedule['BO Revenue'] = CompReleaseSchedule['BO Sales (in Millions)']*1000000

    # selecting columns that are required
    required_columns = ['Current Year',
                        'Forecast Year',
                        'Forecast Month',
                        'Title',
                        'Theatrical Release Date',
                        'EST Release Date',
                        'VOD Release Date',
                        'PST Release Date',
                        'PST Rental Release Date',
                        'Studio',
                        'BO Revenue']
    CompReleaseSchedule = CompReleaseSchedule[[col for col in required_columns if col in CompReleaseSchedule.columns.values.tolist()]]

    # dropping rows with no information present in the raw file
    required_columns = ['Theatrical Release Date',
                        'PST Release Date',
                        'BO Revenue',
                        'EST Release Date',
                        'Studio',
                        'VOD Release Date',
                        'PST Rental Release Date']
    CompReleaseSchedule = CompReleaseSchedule.dropna(how='all',
                                                     subset = [col for col in required_columns if col in CompReleaseSchedule.columns.values.tolist()],
                                                     axis=0)

    # scrapping title codes for new titles
    IMDB_title_code_scraping.scrape_IMDB_Title_Codes(sharepoint_path=sharepoint_path,
                                                     titles=CompReleaseSchedule['Title'].tolist())
    # reading IMDB Title Maps
    scrapped_imdb_title_codes = pd.read_excel(
        io=sharepoint_path + r"\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\intermediate files\IMDB Mapping Data.xlsx",
        sheet_name='scrapped title ids',
        na_values=['#NA', '#N/A', '', ' ', 'na', 'NA'])

    CompReleaseSchedule['temp'] = CompReleaseSchedule['Title'].str.lower()
    CompReleaseSchedule['temp'] = (CompReleaseSchedule['temp'].str.split(pat='(', expand=True))
    CompReleaseSchedule['Cleaned Movie Name'] = CompReleaseSchedule['temp'].str.rstrip(' ')
    CompReleaseSchedule = pd.merge(left=CompReleaseSchedule,
                                   right=scrapped_imdb_title_codes[['Movie Name',
                                                                    'IMDB Title Code',
                                                                    'IMDB Title Name']],
                                   how='left',
                                   left_on='Cleaned Movie Name',
                                   right_on='Movie Name')
    # selecting columns that are required
    required_columns = ['Current Year',
                        'Forecast Year',
                        'Forecast Month',
                        'Title',
                        'IMDB Title Code',
                        'IMDB Title Name',
                        'Theatrical Release Date',
                        'EST Release Date',
                        'VOD Release Date',
                        'PST Release Date',
                        'PST Rental Release Date',
                        'Studio',
                        'BO Revenue']
    CompReleaseSchedule = CompReleaseSchedule[[col for col in required_columns if col in CompReleaseSchedule.columns.values.tolist()]]

    # fixing dates
    for i in [col for col in CompReleaseSchedule.columns.values.tolist() if "Date" in col]:
        CompReleaseSchedule[i] = pd.to_datetime(arg=CompReleaseSchedule[i],
                                                infer_datetime_format=True,
                                                errors="coerce")
    # fixing integers
    for i in ['Current Year', 'Forecast Year']:
        CompReleaseSchedule[i] = CompReleaseSchedule[i].astype(int)
    CompReleaseSchedule['BO Revenue'] = CompReleaseSchedule['BO Revenue'].astype(np.number)

    # exporting cleaned data
    with pd.ExcelWriter(
            path=sharepoint_path+r"\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\Competitor Release Schedule.xlsx",
            mode='w',
            date_format='YYYY-MM-DD',
            datetime_format='DD-MMM-YYYY') as writer:
        CompReleaseSchedule.to_excel(
            excel_writer=writer,
            index=False,
            sheet_name='Sheet1',
            engine='openpyxl')
