import pandas as pd
import numpy as np

def HE_sales_cleaning(raw_file, HE_sales_export_path=False, Total_BO_sales_export_path=False):

    # importing dataset
    raw_file = pd.read_excel(io = raw_file,
                             sheet_name = "Sheet1",
                             header = [13,14,15,16,17])

    # cleaning Overall BO Revenue
    total_theater_sales = raw_file.iloc[:,range(0,10)]
    total_theater_sales.columns = ["IMDB Title Code",
                                   "Global Title Description",
                                   "Studio",
                                   "Street Date",
                                   "Native B.O.-2D Amount",
                                   "Native B.O.-3D Amount",
                                   "Native B.O.-3D-IMAX Amount",
                                   "Native B.O.-IMAX Amount",
                                   "Opening Weekend Box Office",
                                   "Opening Weekend Runs"]
    total_theater_sales.drop(["Studio",
                              "Street Date"],
                             axis=1,
                             inplace=True)
    total_theater_sales.dropna(subset=["IMDB Title Code"],
                               inplace=True)
    total_theater_sales.drop_duplicates(inplace=True)
    total_theater_sales["BO Revenue"] = total_theater_sales.loc[:,["Native B.O.-2D Amount",
                                                                   "Native B.O.-3D Amount",
                                                                   "Native B.O.-3D-IMAX Amount",
                                                                   "Native B.O.-IMAX Amount"]].sum(axis=1)
    # total_theater_sales.to_csv(r"C:/Users/rolee/Desktop/trial3.csv")


    # cleaning weekly HE sales
    HE_sales = raw_file.iloc[:,list(np.arange(0,4))+list(np.arange(10,raw_file.shape[1]))]
    del raw_file
    HE_sales.drop(HE_sales.columns[4], axis=1, inplace=True)

    melted_df = HE_sales.melt(id_vars=HE_sales.columns.tolist()[0:4])
    melted_df.drop("variable_4", inplace=True, axis=1)
    melted_df.columns = ["IMDB Title Code",
                         "Global Title Description",
                         "Studio",
                         "Street Date",
                         "Amt_Qty",
                         "Media Type",
                         "Media SubType",
                         "Week",
                         "Value"]
    melted_df["Week"] = melted_df["Week"].str.replace(pat = "Week ",
                                                      repl = "",
                                                      case = False)
    melted_df["Week"] = melted_df["Week"].astype(str).astype(int)
    melted_df["Value"] = melted_df["Value"].astype(np.float64)
    melted_df = melted_df.pivot_table(index=["IMDB Title Code",
                                             "Global Title Description",
                                             "Studio",
                                             "Street Date",
                                             "Media Type",
                                             "Media SubType",
                                             "Week"],
                                      columns="Amt_Qty",
                                      values="Value")
    melted_df.reset_index(inplace=True)

    # Fill-up missing weeks between Week 0 and Week  26 with 0.
    unique_movie_media = melted_df[["IMDB Title Code",
                                    "Global Title Description",
                                    "Studio",
                                    "Street Date",
                                    "Media Type",
                                    "Media SubType"]]
    unique_movie_media.drop_duplicates(inplace=True)
    unique_movie_media["cross_join"]=1
    unique_week = pd.DataFrame({"Week": np.arange(0,27)})
    unique_week["cross_join"]=1
    unique_movie_media_week = pd.merge(left=unique_movie_media,
                                       right=unique_week,
                                       on="cross_join")
    melted_df = pd.merge(left=unique_movie_media_week.drop(["cross_join"],
                                                           axis=1),
                         right=melted_df,
                         on=["IMDB Title Code",
                             "Global Title Description",
                             "Studio",
                             "Street Date",
                             "Media Type",
                             "Media SubType",
                             "Week"],
                         how='left')
    melted_df.columns = ["IMDB Title Code",
                         "Global Title Description",
                         "Studio",
                         "Street Date",
                         "Media Type",
                         "Media SubType",
                         "Week",
                         "Revenue",
                         "Units"]
    # correcting data structure
    melted_df['Street Date'] = pd.to_datetime(arg=melted_df['Street Date'],
                                              format="%Y-%m-%d",
                                              errors="coerce")

    # exporting cleaned data
    if HE_sales_export_path != False:
        with pd.ExcelWriter(
                path=HE_sales_export_path,
                mode='w',
                engine='openpyxl',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY') as writer:
            melted_df.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name='Sheet1')

    if Total_BO_sales_export_path != False:
        with pd.ExcelWriter(
                path=Total_BO_sales_export_path,
                mode='w',
                engine='openpyxl',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY') as writer:
            total_theater_sales.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name='Sheet1')

    return melted_df, total_theater_sales
