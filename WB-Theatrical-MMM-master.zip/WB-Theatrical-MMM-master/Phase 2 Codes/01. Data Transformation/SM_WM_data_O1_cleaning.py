# importing packages
import pandas as pd
import os
from pandas.io.json import json_normalize

def social_media_data_option1_cleaning(sharepoint_path, raw_files_folder_path, export_path):
    """
    This function takes in a folder path containing Facebook/Twitter/YouTube
    data in movie level json files and returns an excel file containing sheets
    for each social media data. If the existing social media file already exists,
    it appends the new data to the existing file

    Parameters
    ----------
    sharepoint_path: string
        Synced sharepoint home path for local user eg."C:/Users/user_name/Affine Analytics Pvt Ltd"
    raw_files_folder_path: string
        Full path of the folder containing json files of Social Media data
    export_path: string
        Full path of the folder where file "WaveMetrix Social Media Data Option1.xlsx" exists or needs to be created
    Returns
    -------
        File "WaveMetrix Social Media Data Option1.xlsx" in the path specified in 'export_path'
    """

    # importing IMDB Title List
    imdb_title_list = pd.read_excel(io=sharepoint_path+r"/01. Data Harmonization-Cleaning/02. Cleaned Data/03. Movie Metadata/IMDB Data Files/IMDB dataset.xlsx",
                                    sheet_name='Title Basics')[['IMDB Title Code', 'IMDB Title Name']]

    try:
        movie_data_Facebook = pd.read_excel(io=export_path, sheet_name="Facebook")
        movie_data_Facebook['Post Date'] = pd.to_datetime(arg=movie_data_Facebook['Post Date'],
                                           infer_datetime_format=True,
                                           errors="coerce")
    except:
        movie_data_Facebook = pd.DataFrame()
    try:
        movie_data_Twitter = pd.read_excel(io=export_path, sheet_name="Twitter")
        movie_data_Twitter['Post Date'] = pd.to_datetime(arg=movie_data_Twitter['Post Date'],
                                           infer_datetime_format=True,
                                           errors="coerce")
    except:
        movie_data_Twitter = pd.DataFrame()
    try:
        movie_data_YouTube = pd.read_excel(io=export_path, sheet_name="YouTube")
        movie_data_YouTube['Post Date'] = pd.to_datetime(arg=movie_data_YouTube['Post Date'],
                                                         infer_datetime_format=True,
                                                         errors="coerce")
    except:
        movie_data_YouTube = pd.DataFrame()

    for file_name in [s for s in os.listdir(raw_files_folder_path) if ".json" in s]:
        json_file = pd.read_json(raw_files_folder_path+r"/" + file_name) # reading json file
        temp_movie_data = json_normalize(json_file.loc[0, 'data'])  # getting dataframe
        # preparing a master dataframe containing all data from each movie titles
        if 'youtube' in file_name:
            temp = pd.concat(
                [pd.DataFrame({'IMDB Title Code': [json_file.loc[0, 'imdb_id']] * temp_movie_data.shape[0]}),
                 # adding IMDB Title Code
                 temp_movie_data],
                axis=1)
            temp = pd.merge(left=temp,
                            right=imdb_title_list,
                            how='left',
                            left_on='IMDB Title Code',
                            right_on='IMDB Title Code')
            temp.rename(columns={'comments': 'Comments',
                                 'likes': 'Likes',
                                 'dislikes': 'Dislikes',
                                 'post_date': 'Post Date',
                                 'sentiment': 'Sentiment',
                                 'videos': 'Videos',
                                 'views': 'Views'},
                        inplace=True)
            temp['Post Date'] = pd.to_datetime(arg=temp['Post Date'],
                                               infer_datetime_format=True,
                                               errors="coerce")
            movie_data_YouTube = pd.concat([movie_data_YouTube,
                                            temp],
                                           axis=0)
            movie_data_YouTube = movie_data_YouTube[['IMDB Title Code',
                                                     'IMDB Title Name',
                                                     'Post Date',
                                                     'Videos',
                                                     'Views',
                                                     'Comments',
                                                     'Likes',
                                                     'Dislikes',
                                                     'Sentiment']]
            movie_data_YouTube = movie_data_YouTube.groupby(['IMDB Title Code',
                                                             'IMDB Title Name',
                                                             'Post Date']).agg({'Videos' : 'max',
                                                                                'Views' : 'max',
                                                                                'Comments' : 'max',
                                                                                'Likes' : 'max',
                                                                                'Dislikes' : 'max',
                                                                                'Sentiment' : 'max'}).reset_index(drop=False)
            del temp_movie_data, json_file
        elif 'facebook' in file_name:
            temp = pd.concat([pd.DataFrame({'IMDB Title Code': [json_file.loc[0, 'imdb_id']] * temp_movie_data.shape[0]}),  # adding IMDB Title Code
                              temp_movie_data],
                             axis=1)
            temp = pd.merge(left=temp,
                            right=imdb_title_list,
                            how='left',
                            left_on='IMDB Title Code',
                            right_on='IMDB Title Code')
            temp.rename(columns={'comments': 'Comments',
                                 'likes': 'Likes',
                                 'post_date': 'Post Date',
                                 'ptat': 'Ptat',
                                 'shares': 'Shares',
                                 'videos': 'Videos',
                                 'views': 'Views'},
                        inplace=True)
            temp['Post Date'] = pd.to_datetime(arg=temp['Post Date'],
                                               infer_datetime_format=True,
                                               errors="coerce")
            movie_data_Facebook = pd.concat([movie_data_Facebook,
                                             temp],
                                             axis=0)
            movie_data_Facebook = movie_data_Facebook[['IMDB Title Code',
                                                       'IMDB Title Name',
                                                       'Post Date',
                                                       'Videos',
                                                       'Views',
                                                       'Comments',
                                                       'Likes',
                                                       'Shares',
                                                       'Ptat']]
            movie_data_Facebook = movie_data_Facebook.groupby(['IMDB Title Code',
                                                               'IMDB Title Name',
                                                               'Post Date']).agg({'Videos' : 'max',
                                                                                  'Views' : 'max',
                                                                                  'Comments' : 'max',
                                                                                  'Likes' : 'max',
                                                                                  'Shares' : 'max',
                                                                                  'Ptat' : 'max'}).reset_index(drop=False)
            del temp_movie_data, json_file
        elif 'twitter' in file_name:
            temp = pd.concat([pd.DataFrame({'IMDB Title Code': [json_file.loc[0, 'imdb_id']] * temp_movie_data.shape[0]}),
                              pd.DataFrame({'Views': temp_movie_data['actual.US'],
                                            'Post Date': temp_movie_data['post_date']})],
                             axis=1)
            temp = pd.merge(left=temp,
                            right=imdb_title_list,
                            how='left',
                            left_on='IMDB Title Code',
                            right_on='IMDB Title Code')
            temp['Post Date'] = pd.to_datetime(arg=temp['Post Date'],
                                               infer_datetime_format=True,
                                               errors="coerce")
            movie_data_Twitter = pd.concat([movie_data_Twitter,
                                            temp],
                                           axis=0)
            movie_data_Twitter = movie_data_Twitter[['IMDB Title Code',
                                                     'IMDB Title Name',
                                                     'Post Date',
                                                     'Views']]
            movie_data_Twitter = movie_data_Twitter.groupby(['IMDB Title Code',
                                                             'IMDB Title Name',
                                                             'Post Date']).agg({'Views' : 'max'}).reset_index(drop=False)
            del temp_movie_data, json_file
    del file_name
    # exporting social media data
    j=0
    for i in ['Facebook', 'YouTube', 'Twitter']:
        if not eval('movie_data_'+i).empty:
            j=j+1
            if j==1:
                mode='w'
            else:
                mode='a'
            with pd.ExcelWriter(path=export_path,
                                mode=mode,
                                engine='openpyxl',
                                date_format='YYYY-MM-DD',
                                datetime_format='DD-MMM-YYYY') as writer:
                eval('movie_data_'+i).drop_duplicates().to_excel(excel_writer=writer,
                                                                 index=False,
                                                                 sheet_name=i)
        else:
            print("No "+i+" data available")
    del i, j
