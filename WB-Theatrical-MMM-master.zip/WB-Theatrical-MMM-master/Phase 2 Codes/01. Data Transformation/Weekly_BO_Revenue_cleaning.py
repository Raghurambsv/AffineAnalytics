import numpy as np
import pandas as pd

title_list = pd.read_excel(
    io=r"C:/Users/sande/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Title List.xlsx",
    sheet_name='WB Titles',
    na_values=['#NA','#N/A','',' ','na','NA'],
    usecols=["IMDB Title Code","IMDB Title Name","Theatrical Release Date"]
)
title_list['Theatrical Release Date'] = pd.to_datetime(arg=title_list['Theatrical Release Date'], infer_datetime_format=True)

existing_file = pd.read_excel(
    io=r"C:/Users/sande/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/02. Cleaned Data/01. Sales Data/WB_Weekly_BO_Revenue_v1.0.xlsx",
    sheet_name='Sheet1',
    na_values=['#NA','#N/A','',' ','na','NA']
)
existing_file['Theatrical Release Date'] = pd.to_datetime(arg=existing_file['Theatrical Release Date'], infer_datetime_format=True)
existing_file['Week Begin'] = pd.to_datetime(arg=existing_file['Week Begin'], infer_datetime_format=True)
existing_file['Week End'] = pd.to_datetime(arg=existing_file['Week End'], infer_datetime_format=True)

raw_file = pd.read_excel(
    io=r"C:/Users/sande/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/01. Base Data - As received/01. Sales Data/BO Sales/Priyanka.BoxOffice.2020.02.26.xlsx",
    sheet_name='Sheet1',
    header=14,
    na_values=['#NA','#N/A','',' ','na','NA']
)
raw_file.columns = [
    "IMDB Title Code",
    "Global Title Description",
    "Fiscal Week",
    "Week Begin",
    "Week End",
    "Metrics",
    "Box Office",
    "252-Industry Sold Qty TY"
]
raw_file.drop(["Global Title Description","Metrics","252-Industry Sold Qty TY"],
              axis=1,
              inplace=True)
raw_file = pd.merge(
    left=raw_file,
    right=title_list,
    how='left',
    left_on="IMDB Title Code",
    right_on="IMDB Title Code"
)
raw_file['Theatrical Release Date'] = pd.to_datetime(arg=raw_file['Theatrical Release Date'], infer_datetime_format=True)
raw_file['Week Begin'] = pd.to_datetime(arg=raw_file['Week Begin'], infer_datetime_format=True)
raw_file['Week End'] = pd.to_datetime(arg=raw_file['Week End'], infer_datetime_format=True)

existing_file = pd.concat(
    [
        existing_file,
        raw_file
    ],
    axis=0
)

existing_file = existing_file.groupby(
    [
        'IMDB Title Code',
        'IMDB Title Name',
        'Theatrical Release Date',
        'Fiscal Week',
        'Week Begin',
        'Week End'
    ]
).agg(
    {'Box Office': np.max}
).reset_index(drop=False)
existing_file['Theatrical Release Date'] = pd.to_datetime(arg=existing_file['Theatrical Release Date'], infer_datetime_format=True)
existing_file['Week Begin'] = pd.to_datetime(arg=existing_file['Week Begin'], infer_datetime_format=True)
existing_file['Week End'] = pd.to_datetime(arg=existing_file['Week End'], infer_datetime_format=True)

existing_file.sort_values(
    by=[
        'Theatrical Release Date',
        'Week Begin'
    ],
    ascending=[
        False,
        False
    ],
    inplace=True
)
existing_file.reset_index(
    drop=True,
    inplace=True
)

# exporting cleaned file
with pd.ExcelWriter(
        path="C:/Users/sande/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/02. Cleaned Data/01. Sales Data/WB_Weekly_BO_Revenue_v1.0.xlsx",
        engine='openpyxl',
        mode='w',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    existing_file.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='Sheet1')
