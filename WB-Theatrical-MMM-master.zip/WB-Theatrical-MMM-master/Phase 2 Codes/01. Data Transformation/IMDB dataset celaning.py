# importing packages
import numpy as np
import pandas as pd
from datetime import date

# reading dataset
title_basics = pd.read_csv(filepath_or_buffer=r"/home/wb/WB Theatrical/data_files/IMDB downloads/title.basics.tsv",
                           sep='\t',
                           na_values=r'\N')
# preparing dataset
title_basics = title_basics.loc[title_basics['titleType']=='movie',['tconst',
                                                                    'originalTitle',
                                                                    'startYear',
                                                                    'runtimeMinutes',
                                                                    'genres']].reset_index(drop=True)
title_basics.rename(columns={'tconst' : 'IMDB Title Code',
                             'originalTitle' : 'IMDB Title Name',
                             'startYear' : 'Title Release Year IMDB',
                             'runtimeMinutes' : 'Runtime',
                             'genres' : 'Genre IMDB'},
                    inplace=True)
# subsetting movies released since the last 50 years till to be released 1 year ahead
title_basics = title_basics.loc[(title_basics['Title Release Year IMDB'] > int(date.today().strftime("%Y"))-50) &
                                (title_basics['Title Release Year IMDB'] < int(date.today().strftime("%Y"))+2), :]
title_basics.sort_values(by='Title Release Year IMDB',
                         axis=0,
                         ascending=False,
                         inplace=True)
# exporting dataset
with pd.ExcelWriter(path=r"/home/wb/WB Theatrical/data_files/IMDB downloads/IMDB dataset.xlsx",
                    mode='w',
                    engine='openpyxl',
                    date_format='YYYY-MM-DD',
                    datetime_format='DD-MMM-YYYY') as writer:
    title_basics.to_excel(excel_writer=writer,
                          index=False,
                          sheet_name='Title Basics')


# reading dataset
name_basics = pd.read_csv(filepath_or_buffer=r"/home/wb/WB Theatrical/data_files/IMDB downloads/name.basics.tsv",
                           sep='\t',
                           na_values=r'\N')
# subsetting columns and removing all crew who passed away since 50 years
name_basics = name_basics.loc[name_basics['deathYear'] > int(date.today().strftime("%Y"))-50,['nconst',
                                                                                              'primaryName',
                                                                                              'knownForTitles']]
# renaming columns
name_basics.rename(columns={'nconst' : 'IMDB Crew Code',
                            'primaryName' : 'Crew Name',
                            'knownForTitles' : 'Known for Titles'},
                   inplace=True)
# dropping crew who were never a part of any known titles
name_basics.dropna(subset=['Known for Titles'],
                      inplace=True)
name_basics.reset_index(drop=True,
                        inplace=True)
# exporting dataset
with pd.ExcelWriter(path=r"/home/wb/WB Theatrical/data_files/IMDB downloads/IMDB dataset.xlsx",
                    mode='a',
                    engine='openpyxl',
                    date_format='YYYY-MM-DD',
                    datetime_format='DD-MMM-YYYY') as writer:
    name_basics.to_excel(excel_writer=writer,
                          index=False,
                          sheet_name='Crew Basics')

# reading dataset
title_principals = pd.read_csv(filepath_or_buffer=r"/home/wb/WB Theatrical/data_files/IMDB downloads/title.principals.tsv",
                               sep='\t',
                               na_values=r'\N')
# subsetting dataset with movies of recent 50 years and actors alive in the recent 50 years
title_principals = pd.merge(left=title_principals,
                            right=title_basics[['IMDB Title Code', 'IMDB Movie Title']],
                            how='inner',
                            left_on='tconst',
                            right_on='IMDB Title Code')
title_principals = pd.merge(left=title_principals,
                            right=name_basics[['IMDB Crew Code', 'Crew Name']],
                            how='inner',
                            left_on='nconst',
                            right_on='IMDB Crew Code')
title_principals.drop(['tconst', 'nconst', 'IMDB Movie Title', 'Crew Name'],
                      axis=1,
                      inplace=True)
title_principals = title_principals[['IMDB Title Code', 'ordering', 'IMDB Crew Code', 'category']]
title_actors = title_principals.loc[(title_principals['category']=='actor') |
                                    (title_principals['category']=='actress'), ['IMDB Title Code',
                                                                                'ordering',
                                                                                'IMDB Crew Code']]
title_actors.sort_values(by=['IMDB Title Code','ordering'],
                         ascending=True,
                         axis=0,
                         inplace=True)
title_directors = title_principals.loc[title_principals['category']=='director', ['IMDB Title Code',
                                                                                  'ordering',
                                                                                  'IMDB Crew Code']]
title_directors.sort_values(by=['IMDB Title Code','ordering'],
                            ascending=True,
                            axis=0,
                            inplace=True)
# exporting dataset
with pd.ExcelWriter(path=r"/home/wb/WB Theatrical/data_files/IMDB downloads/IMDB dataset.xlsx",
                    mode='a',
                    engine='openpyxl',
                    date_format='YYYY-MM-DD',
                    datetime_format='DD-MMM-YYYY') as writer:
    title_actors.to_excel(excel_writer=writer,
                          index=False,
                          sheet_name='Title-Actor')
    title_directors.to_excel(excel_writer=writer,
                             index=False,
                             sheet_name='Title-Director')
