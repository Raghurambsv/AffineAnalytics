# importing modules
import numpy as np
import pandas as pd
import sys

def GS_data_cleaning(sharepoint_path, root_folder, raw_file,export_path=False):

    # importing modules
    sys.path.insert(0, root_folder+r"/Phase 2 Codes/06. Miscellaneous")
    import date_manipulations

    # importing raw data
    raw_data = pd.read_csv(filepath_or_buffer=raw_file,
                           na_values=['#NA','#N/A','',' ','na','NA'])
    # formating date columns
    raw_data['Theatrical Release Date'] = pd.to_datetime(arg=raw_data['adj_release_date'],
                                                         format="%Y%m%d")
    raw_data['Recorded Date'] = pd.to_datetime(arg=raw_data['stat_date'],
                                               format="%Y%m%d")
    raw_data.drop(labels=['adj_release_date', 'stat_date', 'num_days_to_release'],
                  axis=1,
                  inplace=True)
    raw_data.dropna(subset=['search_volume'], axis=0, inplace=True)
    raw_data.rename(columns={'search_volume':'Google Search Volume'}, inplace=True)

    # correcting IMDB Title Codes
    GS_title_code_QC = pd.read_excel(io=sharepoint_path+r"/01. Data Harmonization-Cleaning/04. QC Checklists/GS raw_data QC.xlsx",
                                     sheet_name='GS Data QC',
                                     na_values=['#NA', '#N/A', '', ' ', 'na', 'NA'],
                                     header=3).drop('Unnamed: 0', axis=1)

    raw_data = pd.merge(left=raw_data,
                        right=GS_title_code_QC[['IMDB Title Code (WB)',
                                                'IMDB Title Code (Corrected)',
                                                'IMDB Title Name']].rename(columns={'IMDB Title Code (Corrected)':'IMDB Title Code',
                                                                                    'IMDB Title Code (WB)':'imdb_id'}),
                        how='left',
                        left_on='imdb_id',
                        right_on='imdb_id').drop(['imdb_id', 'title'],
                                                 axis=1)
    raw_data.dropna(subset=['IMDB Title Code'], axis=0, inplace=True)
    # fixing a release date discrepancy
    raw_data.loc[raw_data['IMDB Title Code']=='tt2361317','Theatrical Release Date'] = pd.to_datetime('2017-01-13', format="%Y-%m-%d")

    # calculating last sunday dates
    raw_data = date_manipulations.last_sunday(df=raw_data,
                                              date_column_name='Theatrical Release Date',
                                              sunday_date_column_name='Theatrical Week Start Sunday')
    raw_data = date_manipulations.last_sunday(df=raw_data,
                                              date_column_name='Recorded Date',
                                              sunday_date_column_name='Recorded Week Start Sunday')

    raw_data = raw_data.groupby(by=['IMDB Title Code',
                                    'IMDB Title Name',
                                    'Theatrical Release Date',
                                    'Theatrical Week Start Sunday',
                                    'Recorded Week Start Sunday']).agg({'Google Search Volume':'mean'}).reset_index(drop=False)
    raw_data.rename(columns={'Recorded Week Start Sunday':'Week Start Date'},
                    inplace=True)
    raw_data['Week Number'] = np.floor(((raw_data['Week Start Date'] - raw_data['Theatrical Week Start Sunday']) / pd.offsets.Day(1)) / 7)

    raw_data = raw_data[['IMDB Title Code',
                         'IMDB Title Name',
                         'Theatrical Release Date',
                         'Week Start Date',
                         'Week Number',
                         'Google Search Volume']]

    # exporting cleaned file
    if export_path!=False:
        with pd.ExcelWriter(
                path=export_path,
                engine='openpyxl',
                mode='w',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY') as writer:
            raw_data.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name='GS Data')

    return raw_data
