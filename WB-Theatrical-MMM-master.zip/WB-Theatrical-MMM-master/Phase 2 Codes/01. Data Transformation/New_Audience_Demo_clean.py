import pandas as pd
import numpy as np

def audience_demo_cleaning(raw_file, export_path=False):

    aud_demo = raw_file
    aud_demo_copy = aud_demo.copy()

    # filtering for movio 1 absolutely

    aud_demo_copy = aud_demo_copy[(aud_demo_copy["Movio Available"] == 1) & (aud_demo_copy["Cinema Score Available"] == 0) & (
                aud_demo_copy["Fandango Available"] == 0) & (aud_demo_copy["NPD Available"] == 0)]

    #Title codes need to be mapped first

    col = 'Metric'
    values = ['Value', 'Sample Size', '95 CI', 'Fandango Available', 'Movio Available', 'NPD Available', 'Cinema Score Available']
    index = ['IMDB Title Code', 'Release Period']
    metric = list(aud_demo_copy['Metric'].unique())
    masterAD = pd.DataFrame()
    for i, x in enumerate(values):
        if(i==0):
            masterAD = pd.pivot_table(aud_demo_copy, values = x, index = index,
                        columns = col).reset_index()
            updated_col_names = [str(item) + "_" + str(x) if item in metric else item for item in list(masterAD.columns)]
            masterAD.columns = updated_col_names
        else:
            temp = pd.pivot_table(aud_demo_copy, values = x, index = index,
                            columns = col).reset_index()
            updated_col_names = [str(item) + "_" + str(x) if item in metric else item for item in list(temp.columns)]
            temp.columns = updated_col_names
            masterAD = pd.merge(masterAD, temp,
                              how = 'left',
                              on = index)
    masterAD = masterAD[masterAD['Release Period'] == 'day1']

    # only these 18+2 columns because , they only remain after movio and day 1 filter , checked via excel also
    masterAD=masterAD[['IMDB Title Code', 'Release Period', '18-24_Value', '25-34_Value', '35-49_Value', '50 & over_Value', 'Afr.-Amer._Value', 'Asian / Other ethnicity_Value', 'Caucasian_Value', 'Early Attender (see w/in first 10 days)_Value', 'Females_Value', 'Females 18-34_Value', 'Females 35-49_Value', 'Latino_Value', 'Males_Value', 'Males 18-34_Value', 'Males 35-49_Value', 'Overall_Value', 'Total Sample (#)_Value', 'Under 18_Value']]

    # masterAD.to_csv(export_path)
    return masterAD

def new_audience_demo_cleaning(raw_file, export_path=False):

    aud_demo = raw_file
    aud_demo_copy = aud_demo.copy()

    # renaming the column names as such
    # operating on the assumption that movioMetric is the value required based on preliminary understanding

    aud_demo_copy.rename(columns = {"movioMetric": "Value","imdb_title_code": "IMDB Title Code","window": "Release Period"}, inplace= True)

    # filtering for movio 1 absolutely

    aud_demo_copy = aud_demo_copy[(aud_demo_copy["movio"] == 1) & (aud_demo_copy["cinemaScore"] == 0) & (aud_demo_copy["fandango"] == 0) & (
                aud_demo_copy["npd"] == 0)]

    #Title codes need to be mapped first
    # here the "metric_name_from_old_data" column was manually mapped to column "metric" in the new data, as its names are slightly different

    col = 'metric_name_from_old_data'
    # in case of composite score
    # values = ['composite', 'compositeN', 'compositeConf95', 'fandango', 'movio', 'npd', 'cinemaScore']
    # in case of Movio only
    values = ['Value', 'movioN', 'movioConf95', 'fandango', 'movio', 'npd', 'cinemaScore']
    index = ['IMDB Title Code', 'Release Period']
    metric = list(aud_demo_copy['metric_name_from_old_data'].unique())
    masterAD = pd.DataFrame()
    for i, x in enumerate(values):
        if(i==0):
            masterAD = pd.pivot_table(aud_demo_copy, values = x, index = index,
                        columns = col).reset_index()
            updated_col_names = [str(item) + "_" + str(x) if item in metric else item for item in list(masterAD.columns)]
            masterAD.columns = updated_col_names
        else:
            temp = pd.pivot_table(aud_demo_copy, values = x, index = index,
                            columns = col).reset_index()
            updated_col_names = [str(item) + "_" + str(x) if item in metric else item for item in list(temp.columns)]
            temp.columns = updated_col_names
            masterAD = pd.merge(masterAD, temp,
                              how = 'left',
                              on = index)
    masterAD = masterAD[masterAD['Release Period'] == 'day1']

    # only these 6+2 columns because , they only remain after movio and day 1 filter , checked via excel also in new data
    masterAD=masterAD[['IMDB Title Code', 'Release Period', '50 & over_Value', 'Females 18-34_Value', 'Females 35-49_Value', 'Males 18-34_Value', 'Males 35-49_Value', 'Under 18_Value']]
    # masterAD.to_csv(export_path)
    return masterAD


# for composite score calulation


def comp_audience_demo_cleaning(raw_file, export_path=False):

    aud_demo = raw_file

    aud_demo_copy = aud_demo.copy()

    #Title codes need to be mapped first

    col = 'Metric'
    values = ['Value', 'Sample Size', '95 CI', 'Fandango Available', 'Movio Available', 'NPD Available', 'Cinema Score Available']
    index = ['IMDB Title Code', 'Release Period']
    metric = list(aud_demo_copy['Metric'].unique())
    masterAD = pd.DataFrame()
    for i, x in enumerate(values):
        if(i==0):
            masterAD = pd.pivot_table(aud_demo_copy, values = x, index = index,
                        columns = col).reset_index()
            updated_col_names = [str(item) + "_" + str(x) if item in metric else item for item in list(masterAD.columns)]
            masterAD.columns = updated_col_names
        else:
            temp = pd.pivot_table(aud_demo_copy, values = x, index = index,
                            columns = col).reset_index()
            updated_col_names = [str(item) + "_" + str(x) if item in metric else item for item in list(temp.columns)]
            temp.columns = updated_col_names
            masterAD = pd.merge(masterAD, temp,
                              how = 'left',
                              on = index)
    masterAD = masterAD[masterAD['Release Period'] == 'day1']

    # only these 29+2 columns because , they only remain after day 1 filter , checked via excel also
    # kindly note that 'Parent (of child under 13)_Value' wont come for the filter of day 1, but comes here as all values nan, will get dropped eventually during common columns match

    masterAD=masterAD[['IMDB Title Code', 'Release Period', '18-24_Value', '25-34_Value', '35-49_Value', '50 & over_Value',
     'Afr.-Amer._Value', 'Asian / Other ethnicity_Value', 'Casual Moviegoer (6-12 annual)_Value', 'Caucasian_Value',
     'Early Attender (see w/in first 10 days)_Value', 'Females_Value', 'Females 18-34_Value', 'Females 35-49_Value',
     'Frequent Moviegoer (see 12+ annual)_Value', 'High Income ($100K+ annual HH)_Value', 'Infrequent moviegoer (<6 annual)_Value',
     'Latino_Value', 'Low income (<$50K annual HH)_Value', 'Males_Value', 'Males 18-34_Value', 'Males 35-49_Value',
     'Middle Income ($50K-$99K annual HH)_Value', 'Midwest_Value', 'Northeast_Value', 'Overall_Value', 'Parent (of child under 13)_Value',
     'South_Value', 'Total Sample (#)_Value', 'Under 18_Value', 'West_Value']]

    # masterAD.to_csv(export_path)
    return masterAD

def comp_new_audience_demo_cleaning(raw_file, export_path=False):

    aud_demo = raw_file

    aud_demo_copy = aud_demo.copy()

    # renaming the column names as such
    # operating on the assumption that "composite" is the value required based on preliminary understanding

    aud_demo_copy.rename(columns = {"composite": "Value","imdb_title_code": "IMDB Title Code","window": "Release Period"}, inplace= True)


    #Title codes need to be mapped first
    # here the "metric_name_from_old_data" column was manually mapped to column "metric" in the new data, as its names are slightly different

    col = 'metric_name_from_old_data'
    # in case of composite score
    # values = ['composite', 'compositeN', 'compositeConf95', 'fandango', 'movio', 'npd', 'cinemaScore']
    values = ['Value', 'compositeN', 'compositeConf95', 'fandango', 'movio', 'npd', 'cinemaScore']
    index = ['IMDB Title Code', 'Release Period']
    metric = list(aud_demo_copy['metric_name_from_old_data'].unique())
    masterAD = pd.DataFrame()
    for i, x in enumerate(values):
        if(i==0):
            masterAD = pd.pivot_table(aud_demo_copy, values = x, index = index,
                        columns = col).reset_index()
            updated_col_names = [str(item) + "_" + str(x) if item in metric else item for item in list(masterAD.columns)]
            masterAD.columns = updated_col_names
        else:
            temp = pd.pivot_table(aud_demo_copy, values = x, index = index,
                            columns = col).reset_index()
            updated_col_names = [str(item) + "_" + str(x) if item in metric else item for item in list(temp.columns)]
            temp.columns = updated_col_names
            masterAD = pd.merge(masterAD, temp,
                              how = 'left',
                              on = index)
    masterAD = masterAD[masterAD['Release Period'] == 'day1']

    # only these 28+2 columns because , they only remain after day 1 filter , checked via excel also in new data
    masterAD=masterAD[['IMDB Title Code', 'Release Period', '18-24_Value', '25-34_Value', '35-49_Value', '50 & over_Value',
                       'Afr.-Amer._Value', 'Asian / Other ethnicity_Value', 'Casual Moviegoer (6-12 annual)_Value',
                       'Caucasian_Value', 'Early Attender (see w/in first 10 days)_Value', 'Females_Value',
                       'Females 18-34_Value', 'Females 35-49_Value', 'Frequent Moviegoer (see 12+ annual)_Value',
                       'High Income ($100K+ annual HH)_Value', 'Infrequent moviegoer (<6 annual)_Value', 'Latino_Value',
                       'Low income (<$50K annual HH)_Value', 'Males_Value', 'Males 18-34_Value', 'Males 35-49_Value',
                       'Middle Income ($50K-$99K annual HH)_Value', 'Midwest_Value', 'Northeast_Value', 'Overall_Value',
                       'South_Value', 'Total Sample (#)_Value', 'Under 18_Value', 'West_Value']]
    # masterAD.to_csv(export_path)
    return masterAD
