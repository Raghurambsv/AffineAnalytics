# importing modules
import pandas as pd
import numpy as np

sharepoint_path = r"C:\Users\sande\Affine Analytics Pvt Ltd"

data = pd.read_excel(io=sharepoint_path+r"\WB Theatrical - Documents\01. Data Harmonization-Cleaning\01. Base Data - As received\04. Other Data Elements\Postrack Survey Data\post_trak_film_lookup_results_2019_08_12__13_09.xlsx",
                     sheet_name='Recovered_Sheet1',
                     na_values=['#NA','#N/A','',' ','na','NA'])


