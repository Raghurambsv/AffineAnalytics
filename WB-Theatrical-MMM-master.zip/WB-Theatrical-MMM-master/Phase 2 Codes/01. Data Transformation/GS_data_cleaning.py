# importing modules
import numpy as np
import pandas as pd
import sys

def GS_data_cleaning(sharepoint_path, root_folder, raw_file):

    sys.path.insert(0, root_folder+r"/WB-Theatrical-MMM/Phase 2 Codes/06. Miscellaneous")
    import date_manipulations

    # importing raw data
    raw_data = pd.read_csv(filepath_or_buffer=raw_file,
                           na_values=['#NA','#N/A','',' ','na','NA'])
    # formating date columns
    raw_data['Theatrical Release Date'] = pd.to_datetime(arg=raw_data['Theatrical Release Date'],
                                                         infer_datetime_format=True)
    raw_data['Recorded Date'] = pd.to_datetime(arg=raw_data['DATE'],
                                               infer_datetime_format=True)
    raw_data.drop(labels=['DATE','ODID','TITLE','RELEASE_ODID','SEARCH_CATEGORY','RELEASE_DATE','DAYS_SINCE_RELEASE','REGION','SOURCE','CREATIVE_TYPE'],
                  axis=1,
                  inplace=True)
    raw_data.dropna(subset=['INDEXED_VOLUME'], axis=0, inplace=True)
    raw_data.rename(columns={'INDEXED_VOLUME':'Google Search Volume'}, inplace=True)

    # fixing a release date discrepancy
    raw_data.loc[raw_data['IMDB Title Code']=='tt2361317','Theatrical Release Date'] = pd.to_datetime('2017-01-13', format="%Y-%m-%d")

    # calculating last sunday dates
    raw_data = date_manipulations.last_sunday(df=raw_data,
                                              date_column_name='Theatrical Release Date',
                                              sunday_date_column_name='Theatrical Week Start Sunday')
    raw_data = date_manipulations.last_sunday(df=raw_data,
                                              date_column_name='Recorded Date',
                                              sunday_date_column_name='Recorded Week Start Sunday')

    raw_data = raw_data.groupby(by=['IMDB Title Code',
                                    'IMDB Title Name',
                                    'Theatrical Release Date',
                                    'Studio',
                                    'GENRE',
                                    'Theatrical Week Start Sunday',
                                    'Recorded Week Start Sunday']).agg({'Google Search Volume':'sum'}).reset_index(drop=False)
    raw_data.rename(columns={'Recorded Week Start Sunday':'Week Start Date'},
                    inplace=True)
    raw_data['Week Number'] = np.floor(((raw_data['Week Start Date'] - raw_data['Theatrical Week Start Sunday']) / pd.offsets.Day(1)) / 7)

    # exporting cleaned file
    with pd.ExcelWriter(
            path=sharepoint_path+r"/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Google Search Data/Google Search Data_v5.xlsx",
            engine='openpyxl',
            mode='w',
            date_format='YYYY-MM-DD',
            datetime_format='DD-MMM-YYYY') as writer:
        raw_data.drop('Theatrical Week Start Sunday', axis=1).to_excel(
            excel_writer=writer,
            index=False,
            sheet_name='GS Data')
