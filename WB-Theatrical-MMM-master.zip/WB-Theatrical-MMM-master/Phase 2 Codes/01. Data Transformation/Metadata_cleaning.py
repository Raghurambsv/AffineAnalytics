import pandas as pd

def metadata_cleaning(df_metadata,export_path=False):

    df_metadata.drop_duplicates(subset=['ODID', 'Title Code', 'MOVIE_DISPLAY_NAME', 'REGION', 'RELEASE_PATTERN'],
                                inplace=True)
    df_metadata.drop(['ODID'],axis=1)

    return df_metadata

