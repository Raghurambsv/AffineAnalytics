# checking for required modules
import pkg_resources
from subprocess import call
required_packages = [
    "datetime",
    "numpy",
    "pandas",
    "xlrd",
    "openpyxl",
    "requests",
    "bs4"
]
for package in required_packages:
    if package in [  # list all packages with available latest stable updates
        dist.project_name
        for dist in pkg_resources.working_set
    ]:
        call(  # update all packages in shell
            "pip install --upgrade " + package,
            shell=True
        )
    else:
        call(  # update all packages in shell
            "pip install " + package,
            shell=True
        )

# importing modules
import datetime
import time
import numpy as np
import pandas as pd
import requests
import bs4
import json
import re

def source_code(
        title: str
) -> bs4.BeautifulSoup:
    """
    Extracts the HTML source code of a movie's main page from imdb.com

    Parameters
    ----------
    title: string
        An IMDB Title Code
    Returns
    -------
        HTML source code
    """

    response = requests.get(
        url='https://www.imdb.com/title/' + title + '/'
    )
    if response.status_code == 404:
        soup = None
    else:
        soup = bs4.BeautifulSoup(
            markup=response.text,
            features='html5lib'
        )

    return response.status_code, soup

def getIndex(
        movie_containers: bs4.element.Tag,
        tag: str
) -> int:
    """
    Snips portion of an HTML script with header=h4

    Parameters
    ----------
    movie_containers: A bs4 element
        A bs4 element of type 'bs4.element.Tag'
    tag: String
        A string with belongs to h4 header
    Returns
    -------
        Index of the tag inside the bs4 element
    """

    for index in np.arange(len(movie_containers)):
        try:
            if movie_containers[index].h4.text == tag:
                return index
        except:
            pass

def scrape_description(
        soup: bs4.BeautifulSoup
) -> str:
    """
    Extracts description of the movie

    Parameters
    ----------
    soup: bs4.BeautifulSoup
        A bs4 element of type 'bs4.BeautifulSoup'
    Returns
    -------
        Movie's IMDB Description
    """

    try:
        movie_container = soup.find(
            name='div',
            class_='summary_text'
        )
        description = movie_container.text.strip()
    except:
        description = np.NaN

    return description


def scrape_rating(
        soup: bs4.BeautifulSoup
) -> float:
    """
    Extracts IMDB Rating of the movie

    Parameters
    ----------
    soup: bs4.BeautifulSoup
        A bs4 element of type 'bs4.BeautifulSoup'
    Returns
    -------
        Movie's IMDB Rating
    """

    try:
        movie_container = soup.find(
            name='div',
            class_='ratingValue'
        )
        rating = float(movie_container.span.text)
    except:
        rating = np.NaN

    return rating

def scrape_release_date(
        soup: bs4.BeautifulSoup
) -> str:
    """
    Extracts Theatrical Release Date of the movie (at the US)

    Parameters
    ----------
    soup: bs4.BeautifulSoup
        A bs4 element of type 'bs4.BeautifulSoup'
    Returns
    -------
        US Theatrical Release Date
    """

    movie_containers = soup.find_all(
        name='div',
        class_='txt-block'
    )
    try:
        release_date = datetime.datetime.strptime(
            movie_containers[
                getIndex(
                    movie_containers=movie_containers,
                    tag='Release Date:'
                )
            ].text.split(':')[1].split('(USA)')[0].split('/n')[0].split('(')[0].strip(),
            '%d %B %Y'
        ).date()
    except:
        release_date = np.NaN

    return release_date

def scrape_runtime(
        soup: bs4.BeautifulSoup
) -> int:
    """
    Extracts movie runtime (in minutes)

    Parameters
    ----------
    soup: bs4.BeautifulSoup
        A bs4 element of type 'bs4.BeautifulSoup'
    Returns
    -------
        Movie Runtime
    """

    movie_containers = soup.find_all(
        name='div',
        class_='txt-block'
    )
    try:
        runtime = int(
            movie_containers[
                getIndex(
                    movie_containers=movie_containers,
                    tag='Runtime:'
                )
            ].time.text.split(" ")[0]
        )
    except:
        runtime = np.NaN

    return runtime


def scrape_monetary_info(
        soup: bs4.BeautifulSoup
) -> dict:
    """
    Extracts monetary information of a movie like:
        - Production Budget
        - Gross Domestic Box Office Revenue at the US
        - Gross World Wide Box Office Revenue
        - Opening Weekend Box Office Revenue at the US

    Parameters
    ----------
    soup: bs4.BeautifulSoup
        A bs4 element of type 'bs4.BeautifulSoup'
    Returns
    -------
        A dictionary containing monetary information of a movie
    """

    movie_containers = soup.find_all(
        name='div',
        class_='txt-block'
    )

    # scrapping Production Budget
    try:
        budget = int(
            "".join(
                re.findall(
                    pattern=r"\d+",
                    string=re.search(
                        pattern=r"\$(.+?)(\n?\s)",
                        string=movie_containers[
                            getIndex(
                                movie_containers=movie_containers,
                                tag="Budget:"
                            )
                        ].text
                    ).group(1)
                )
            )
        )
    except:
        budget = np.NaN

    # scrapping Gross Domestic Box Office Revenue at the US
    try:
        gross_US = int(
            "".join(
                re.findall(
                    pattern=r"\d+",
                    string=re.search(
                        r"\$(.+?)(\n?\s)",
                        movie_containers[
                            getIndex(
                                movie_containers=movie_containers,
                                tag="Gross USA:"
                            )
                        ].text
                    ).group(1)
                )
            )
        )
    except:
        gross_US = np.NaN

    # scrapping Gross World Wide Box Office Revenue
    try:
        gross_WW = int(
            "".join(
                re.findall(
                    pattern=r"\d+",
                    string=re.search(
                        pattern=r"\$(.+?)(\n?\s)",
                        string=movie_containers[
                            getIndex(
                                movie_containers=movie_containers,
                                tag="Cumulative Worldwide Gross:"
                            )
                        ].text
                    ).group(1)
                )
            )
        )
    except:
        gross_WW = np.NaN

    # scrapping Opening Weekend Box Office Revenue at the US
    try:
        opening_weekend_US = int(
            "".join(
                re.findall(
                    pattern=r"\d+",
                    string=re.search(
                        pattern=r"\$(.+?)(\n?\s)",
                        string=movie_containers[
                            getIndex(
                                movie_containers=movie_containers,
                                tag="Opening Weekend USA:"
                            )
                        ].text
                    ).group(1)
                )
            )
        )
    except:
        opening_weekend_US = np.NaN

    return {
        "Production Budget": budget,
        "Domestic Box Office (USA)": gross_US,
        "World Wide Box Office": gross_WW,
        "Opening Weekend Box Office (USA)": opening_weekend_US
    }


def scrape_metadata(
        soup: bs4.BeautifulSoup
) -> dict:
    """
    Extracts movie metadata like:
        - Name
        - Language
        - MPAA Rating
        - Genre(s)
        - Actor(s)
        - Director(s)
        - Writer(s)

    Parameters
    ----------
    soup: bs4.BeautifulSoup
        A bs4 element of type 'bs4.BeautifulSoup'
    Returns
    -------
        A dictionary containing the movie metadata
    """

    # scrapping language
    movie_containers = soup.find_all(
        name='div',
        class_='txt-block'
    )
    try:
        language = movie_containers[
            getIndex(
                movie_containers=movie_containers,
                tag='Language:'
            )
        ].text.split("\n")[2].strip()
    except:
        language = np.NaN

    # converting script to json data
    json_data = json.loads(
        s=soup.find(
            name='script',
            attrs={
                "type": "application/ld+json"
            }
        ).getText()
    )

    # scrapping IMDB Title Name
    try:
        name = json_data['name']
    except:
        name = np.NaN

    # scrapping MPAA Rating
    try:
        MPAA_rating = json_data['contentRating']
    except:
        MPAA_rating = np.NaN

    # scrapping Genre
    try:
        genres = json_data['genre']
    except:
        genres = np.NaN

    # scrapping list of Actor(s)
    try:
        try:
            actors = [person['name'] for person in json_data['actor']]
        except:
            actors = json_data['actor']['name']
    except:
        actors = np.NaN

    # scrapping list of Director(s)
    try:
        try:
            directors = [person['name'] for person in json_data['director']]
        except:
            directors = json_data['director']['name']
    except:
        directors = np.NaN

    # scrapping list of Writer(s)
    try:
        try:
            writers = [person['name'] for person in json_data['creator'] if person['@type'] == 'Person']
        except:
            writers = json_data['creator']['name']
    except:
        writers = np.NaN

    return {
        "Name": name,
        "Language": language,
        "MPAA Rating": MPAA_rating,
        "Genre(s)": genres,
        "Actor(s)": actors,
        "Director(s)": directors,
        "Writer(s)": writers
    }

def scrape_movie_info(
        title_list: list
) -> pd.core.frame.DataFrame:
    """
        This function takes in a dataframe and a column name and returns the same
        dataframe with a column containing the date of it's last sunday

        Parameters
        ----------
         title_list: list+
             A list of  IMDB Title Codes
        Returns
        -------
            A DataFrame containing information about the movie at IMDB
        """

    # Creating an empty DataFrame to populate with IMDB information
    scrapped_data = pd.DataFrame(
        {
            "IMDB Title Code": [],
            "IMDB Title Name": [],
            "Theatrical Release Date": [],
            "Genre": [],
            "Language": [],
            "MPAA Rating": [],
            "Production Budget": [],
            "Domestic Box Office (USA)": [],
            "World Wide Box Office": [],
            "Opening Weekend Box Office (USA)": [],
            "Runtime (in mins)": [],
            "Actor(s)": [],
            "Director(s)": [],
            "Writer(s)": [],
            "Movie Description": []
        }
    )

    # Looping through each list of IMDB Title Codes and scrapping their IMDB information
    time_start = time.time()  # timer start
    for title in title_list:  # for each IMDB Title Code
        response, soup = source_code(title=title)  # extract HTML source code of it's IMDB movie page
        if response == 404:  # if page not found
            print(  # print a message
                "Page Not Found ::: " + 'https://www.imdb.com/title/' + title + '/'
            )
        else:
            scrapped_data = pd.concat(  # concatenate
                [
                    scrapped_data,  # previous movie's scrapped information, with
                    pd.DataFrame(  # current movie's scrapped information
                        {
                            "IMDB Title Code": [title],
                            "IMDB Title Name": [scrape_metadata(soup)["Name"]],
                            "Theatrical Release Date": [scrape_release_date(soup)],
                            "Genre": [
                                str(scrape_metadata(soup)["Genre(s)"]).replace("'", "").replace("[", "").replace("]", "")
                            ],
                            "Language": [scrape_metadata(soup)["Language"]],
                            "MPAA Rating": [scrape_metadata(soup)["MPAA Rating"]],
                            "Production Budget": [scrape_monetary_info(soup)["Production Budget"]],
                            "Domestic Box Office (USA)": [scrape_monetary_info(soup)["Domestic Box Office (USA)"]],
                            "World Wide Box Office": [scrape_monetary_info(soup)["World Wide Box Office"]],
                            "Opening Weekend Box Office (USA)": [
                                scrape_monetary_info(soup)["Opening Weekend Box Office (USA)"]
                            ],
                            "Runtime (in mins)": [scrape_runtime(soup)],
                            "Actor(s)": [
                                str(scrape_metadata(soup)["Actor(s)"]).replace("'", "").replace("[", "").replace("]", "")
                            ],
                            "Director(s)": [
                                str(scrape_metadata(soup)["Director(s)"]).replace("'", "").replace("[", "").replace("]", "")
                            ],
                            "Writer(s)": [
                                str(scrape_metadata(soup)["Writer(s)"]).replace("'", "").replace("[", "").replace("]", "")
                            ],
                            "Movie Description": [scrape_description(soup)],
                            "IMDB Rating": [scrape_rating(soup)]
                        }
                    )
                ],
                axis=0  # concatenate by row
            )
            print(  # print movie name and title code whose IMDB information has been scrapped and added to the DataFrame
                "Scrapped ::: " + title + " ::: " + scrape_metadata(soup)["Name"]
            )
    time_end = time.time()  # timer stop
    print(  # print timer information
        "\nTime Taken (Total): " + "{}".format(
            str(datetime.timedelta(seconds=(time_end - time_start)))
        ) +
        "\nTime Taken (per title): " + "{}".format(
            str(datetime.timedelta(seconds=(time_end - time_start) / len(title_list)))
        )
    )

    return scrapped_data


def scrape_IMDB_Title_Codes(
        sharepoint_path: str,
        titles: list
) -> pd.core.frame.DataFrame:
    """
    This function takes a list of movie titles as input searches IMDb.com using each titles and tries to scrape its
    IMDB_Title_Code. Finally it exports a DataFrame

    Parameters
    ----------
        sharepoint_path : string
            Home folder for shared drive
        titles : list
            A list of movie titles
    Returns
    -------
        A DataFrame with mapped IMDB Title Codes
    """

    titles = pd.DataFrame(
        {
            'Movie Name': titles
        }
    )
    titles['temp'] = titles['Movie Name'].str.lower()
    titles['temp'] = titles['temp'].str.split(
        pat='(',
        expand=True
    )
    titles['Cleaned Movie Name'] = titles['temp'].str.rstrip(' ')
    titles.drop(
        ['temp'],
        axis=1,
        inplace=True
    )
    try:
        base_file = pd.read_excel(
            io=sharepoint_path + r"/01. Data Harmonization-Cleaning/02. Cleaned Data/intermediate files/IMDB Mapping Data.xlsx",
            sheet_name='scrapped title ids'
        )
        to_scrape_titles = [
            value
            for value in titles['Cleaned Movie Name'].tolist()
            if value not in [
                x.lower()
                for x in base_file['Movie Name'].to_list()
            ]
        ]
    except:
        base_file = pd.DataFrame(
            {
                'Movie Name': [],
                'IMDB Title Code': [],
                'IMDB Title Name': [],
                'IMDB Title URL': []
            }
        )
        to_scrape_titles = titles['Cleaned Movie Name'].tolist()

    IMDB_Title_maps = pd.DataFrame(
        {
            'Movie Name': [],
            'IMDB Title Code': [],
            'IMDB Title Name': [],
            'IMDB Title URL': []
        }
    )

    def scrape_title_codes():
        if str(title) != 'nan':
            error = 0
            CleanedMovieName = title.replace(' ', '+')

            url = 'https://www.imdb.com/find?ref_=nv_sr_fn&q=' + CleanedMovieName + '&s=tt'

            response = requests.get(url)
            soup = bs4.BeautifulSoup(response.text, 'html.parser')

            MovieChoice = soup.find('td', class_='result_text')

            try:
                TitleName = MovieChoice.a.text
            except AttributeError:
                TitleName = ""
                error = 1

            try:
                TitleURL = MovieChoice.a.get('href')
                if not TitleURL.startswith("https://www.imdb.com"):
                    TitleURL = "https://www.imdb.com" + TitleURL
            except AttributeError:
                TitleURL = ""
                error = 1

            try:
                TitleID = re.search(
                    '/(tt[0-9]{7})/',
                    TitleURL
                ).group(1)
            except AttributeError:
                TitleID = ""
                error = 1

            IMDB_Title_maps = pd.concat(
                [
                    IMDB_Title_maps,
                    pd.DataFrame(
                        {
                            'Movie Name': [title],
                            'IMDB Title Code': [TitleID],
                            'IMDB Title Name': [TitleName],
                            'IMDB Title URL': [TitleURL]
                        }
                    )
                ],
                axis=0,
                ignore_index=True
            )
            # printing scrapping status
            if error == 0:
                print('Movie ' + title + ' done!')
            else:
                print('Movie ' + title + ' had error!')


    if len(to_scrape_titles) > 0:
        for title in to_scrape_titles:  # multithreading code goes here
            # if str(title) != 'nan':
            #     error = 0
            #     CleanedMovieName = title.replace(' ', '+')
            #
            #     url = 'https://www.imdb.com/find?ref_=nv_sr_fn&q=' + CleanedMovieName + '&s=tt'
            #
            #     response = requests.get(url)
            #     soup = bs4.BeautifulSoup(response.text, 'html.parser')
            #
            #     MovieChoice = soup.find('td', class_='result_text')
            #
            #     try:
            #         TitleName = MovieChoice.a.text
            #     except AttributeError:
            #         TitleName = ""
            #         error = 1
            #
            #     try:
            #         TitleURL = MovieChoice.a.get('href')
            #         if not TitleURL.startswith("https://www.imdb.com"):
            #             TitleURL = "https://www.imdb.com" + TitleURL
            #     except AttributeError:
            #         TitleURL = ""
            #         error = 1
            #
            #     try:
            #         TitleID = re.search(
            #             '/(tt[0-9]{7})/',
            #             TitleURL
            #         ).group(1)
            #     except AttributeError:
            #         TitleID = ""
            #         error = 1
            #
            #     IMDB_Title_maps = pd.concat(
            #         [
            #             IMDB_Title_maps,
            #             pd.DataFrame(
            #                 {
            #                     'Movie Name': [title],
            #                     'IMDB Title Code': [TitleID],
            #                     'IMDB Title Name': [TitleName],
            #                     'IMDB Title URL': [TitleURL]
            #                 }
            #             )
            #         ],
            #         axis=0,
            #         ignore_index=True
            #     )
            #     # printing scrapping status
            #     if error == 0:
            #         print('Movie ' + title + ' done!')
            #     else:
            #         print('Movie ' + title + ' had error!')

        IMDB_Title_maps = pd.merge(
            left=IMDB_Title_maps[
                [
                    'Movie Name',
                    'IMDB Title Code',
                    'IMDB Title Name',
                    'IMDB Title URL'
                ]
            ],
            right=base_file[
                [
                    'IMDB Title Code',
                    'Title Release Year IMDB'
                ]
            ],
            how='left',
            left_on='IMDB Title Code',
            right_on='IMDB Title Code'
        )

        base_file = pd.concat(
            [
                base_file,
                IMDB_Title_maps
            ],
            axis=0,
            ignore_index=True
        )

    print("\nScraping Complete!!!")

    # exporting scrapped IMDB_Title_Codes
    with pd.ExcelWriter(
        path=sharepoint_path + r"/01. Data Harmonization-Cleaning/02. Cleaned Data/intermediate files/IMDB Mapping Data.xlsx",
        engine='openpyxl',
        mode='w',
        date_format='DD-MMM-YYYY',
        datetime_format='DD-MMM-YYYY'
    ) as writer:
        base_file.to_excel(
            excel_writer=writer,
            index=False,
            sheet_name='scrapped title ids'
        )
