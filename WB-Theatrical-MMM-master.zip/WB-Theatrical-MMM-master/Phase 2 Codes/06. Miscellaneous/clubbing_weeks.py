#importing modules
import pandas as pd

def units_clubbed(DataFrame, IMDB_Title_Code, revenue, weeks):
    """
       Function to club the sales/revenue of the 0th and the 1st week and keep
       the sales of the rest of the weeks as same
       Parameters
       ---------
       Dataframe: Pandas Dataframe
           The base AD in which flag is to be calculated
       IMDB_Title_Code: String
           The column name of the IMDB title code in dataframe
       revenue: String
           The column name of the EST Sales data
       weeks: String
           The column name of the EST weeks start data
        Returns
       -------
       The updated Base AD with Added EST Units. (Week1 = Week0 + Week1)
       """
    data = DataFrame.copy()
    df1 = data[[IMDB_Title_Code,
                revenue,
                weeks]]
    # Setting week 0 as week 1
    df1[weeks] = df1.apply(lambda x: 1 if x[weeks] == 0 else x[weeks],
                           axis=1)
    # merging week0 and week1
    df2 = df1.groupby([IMDB_Title_Code,
                       weeks]).agg({revenue:'sum'}).reset_index()
    df2.reset_index(drop=True, inplace=True)
    # Merging with the base dataframe
    result = pd.merge(left=data,
                      right=df2.rename(columns={revenue:revenue+'_Clubbed'}),
                      how='left',
                      left_on=[IMDB_Title_Code, weeks],
                      right_on=[IMDB_Title_Code, weeks])
    result.fillna({revenue+'_Clubbed': 0},
                  inplace=True)
    return result
