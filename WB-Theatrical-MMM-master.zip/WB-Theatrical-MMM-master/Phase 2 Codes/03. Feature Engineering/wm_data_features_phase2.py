
import pandas as pd
import numpy as np
from tqdm import tqdm
import sys
tqdm.pandas()



## Helper function for the main function below it
def combined_maker(merged_yt_fb_data):
    # SImple average of YT and FB metrics
    merged_yt_fb_data['combined_likes'] = np.nanmean([merged_yt_fb_data['YouTube_Likes'], merged_yt_fb_data['Facebook_Likes']])
    merged_yt_fb_data['combined_views'] = np.nanmean([merged_yt_fb_data['YouTube_Views'], merged_yt_fb_data['Facebook_Views']])
    merged_yt_fb_data['combined_comments'] = np.nanmean([merged_yt_fb_data['YouTube_Comments'], merged_yt_fb_data['Facebook_Comments']])
    return merged_yt_fb_data

## Main Function for combining YT and FB data and then creating adstock for the same
def social_media_metrics(studio,root_folder, base_ad, social_media_data, snapshot, week_number_colname, revenue_colname):

    if (studio=='wb'):

        sys.path.insert(0, root_folder+r"/WB-Theatrical-MMM/Phase 2 Codes/03. Feature Engineering")
        from AdstockClass import Adstock

        """
        A function to calculate the combined metrics using FB, YT and adstock
        metrics of Wiki views.
    
        Parameters
        ----------
        base_ad: Pandas Dataframe
            The base dataframe in which the metrics are to be added
        social_media_data: Pandas Dataframe
            The dataframe in which all the collated social media data is present outer joined
        snapshot: int
            The snapshot for which these metrics are required. For example for TH-8, 
            this argument should be -8
        week_number_colname: String
            The name of the week number column name
        revenue_colname: String
            The name of the revenue variable column name. This is used to get the
            optimal lambda with max correlation between the spends adstock and revenue
        Returns
        -------
        The updated base AD with the new metrics left joined
        """
        # Creating the combined metrics using the helper function defined previously
        #social_media_data = social_media_data.progress_apply(lambda x: combined_maker(x), axis=1)
        social_media_data['combined_likes'] = np.nanmean([social_media_data['YouTube_Likes'],
                                                          social_media_data['Facebook_Likes']],
                                                         axis=0)
        social_media_data['combined_views'] = np.nanmean([social_media_data['YouTube_Views'],
                                                          social_media_data['Facebook_Views']],
                                                         axis=0)
        social_media_data['combined_comments'] = np.nanmean([social_media_data['YouTube_Comments'],
                                                             social_media_data['Facebook_Comments']],
                                                            axis=0)

        # Creating another variable likes by views
        social_media_data['combined_likes_by_views'] = social_media_data['combined_likes']/social_media_data['combined_views']
        # Creating the adstock of the combined metrics using the Adstock Class by making
        # the actual social media metrics 0 after the required snapshot
        for metric in ['combined_likes', 'combined_views', 'combined_comments',
                       'combined_likes_by_views', 'Google_Search_Volume', 'Wikipedia_Page_Views']:
            social_media_data[metric+'_'+str(snapshot)] = social_media_data.apply(lambda x: np.nan if x[week_number_colname]>=snapshot else x[metric], axis=1)
            # Creating some basic mean/max variables out of the combined variables
            social_media_data['max_'+metric+'_till_'+str(snapshot)] = social_media_data.groupby(['IMDB_Title_Code'])[metric+'_'+str(snapshot)].transform('max')
            social_media_data['avg_'+metric+'_till_'+str(snapshot)] = social_media_data.groupby(['IMDB_Title_Code'])[metric+'_'+str(snapshot)].transform('mean')
            social_media_data['total_'+metric+'_till_'+str(snapshot)] = social_media_data.groupby(['IMDB_Title_Code'])[metric+'_'+str(snapshot)].transform('sum')
            # Getting title level metrics
            base_ad = pd.merge(base_ad, social_media_data[['IMDB_Title_Code', 'max_'+metric+'_till_'+str(snapshot), 'avg_'+metric+'_till_'+str(snapshot), 'total_'+metric+'_till_'+str(snapshot)]].drop_duplicates(),
                                                           on=['IMDB_Title_Code'],
                                                           how='left')
        # Getting BO Revenue column from base ad into this merged data
        social_media_data = pd.merge(social_media_data, base_ad[['IMDB_Title_Code', week_number_colname, revenue_colname]],
                               on=['IMDB_Title_Code', week_number_colname],
                               how='outer')
        # Creating Adstock for these combined metrics using optimal lambda
        class_instance = Adstock(base_dataframe=social_media_data, dictionary_spends={'combined_views'+'_'+str(snapshot): [0.1, 'Linear'],
                                               'combined_likes'+'_'+str(snapshot): [0.1, 'Linear'],
                                               'combined_comments'+'_'+str(snapshot): [0.1, 'Linear'],
                                               'combined_likes_by_views'+'_'+str(snapshot): [0.1, 'Linear'],
                                               'Google_Search_Volume'+'_'+str(snapshot): [0.1, 'Linear'],
                                               'Wikipedia_Page_Views'+'_'+str(snapshot): [0.1, 'Linear']},
                                 week_number_colname= week_number_colname,
                                 revenue_colname=revenue_colname)
        merged_data = class_instance.optimise_adstock()
        # Merging these variables with the base ad
        merged_data.drop(columns=['IMDB_Title_Name', 'Theatrical_Release_Date',
                                  'Week_Start_Date', 'Facebook_Comments', 'Facebook_Likes',
                                  'Facebook_Ptat', 'Facebook_Shares', 'Facebook_Videos', 'Facebook_Views',
                                  'Twitter_Views', 'YouTube_Comments', 'YouTube_Likes',
                                  'YouTube_Dislikes', 'YouTube_Videos', 'YouTube_Views',
                                  'YouTube_Sentiment', 'Google_Search_Volume', 'Wikipedia_Page_Views',
                                  revenue_colname], inplace=True)
        # Dropping more variables that have been already merged in the base ad

        merged_data.drop(columns=[col for col in merged_data.columns if 'max' in col or 'avg' in col or 'total' in col], inplace=True)
        base_ad = pd.merge(base_ad, merged_data, on=['IMDB_Title_Code', week_number_colname],
                           how='left')
        return base_ad

    #base_ad.to_excel(r"E:\WB_project\daily_tasks\14082019\modelling_ad_21082019.xlsx", index=False)

    elif(studio == 'nonwb'):

        sys.path.insert(0, root_folder + r"/WB-Theatrical-MMM/Phase 2 Codes/03. Feature Engineering")
        from AdstockClass import Adstock

        """

        Parameters
        ----------
        base_ad: Pandas Dataframe
            The base dataframe in which the metrics are to be added
        social_media_data: Pandas Dataframe
            The dataframe in which all the collated social media data is present outer joined
        snapshot: int
            The snapshot for which these metrics are required. For example for TH-8, 
            this argument should be -8
        week_number_colname: String
            The name of the week number column name
        revenue_colname: String
            The name of the revenue variable column name. This is used to get the
            optimal lambda with max correlation between the spends adstock and revenue
        Returns
        -------
        The updated base AD with the new metrics left joined
        """
        # Creating the combined metrics using the helper function defined previously
        # social_media_data = social_media_data.progress_apply(lambda x: combined_maker(x), axis=1)
        # social_media_data['combined_likes'] = np.nanmean([social_media_data['YouTube_Likes'],
        #                                                   social_media_data['Facebook_Likes']],
        #                                                  axis=0)
        # social_media_data['combined_views'] = np.nanmean([social_media_data['YouTube_Views'],
        #                                                   social_media_data['Facebook_Views']],
        #                                                  axis=0)
        # social_media_data['combined_comments'] = np.nanmean([social_media_data['YouTube_Comments'],
        #                                                      social_media_data['Facebook_Comments']],
        #                                                     axis=0)

        # Creating another variable likes by views
        # social_media_data['combined_likes_by_views'] = social_media_data['combined_likes'] / social_media_data[
        #     'combined_views']
        # Creating the adstock of the combined metrics using the Adstock Class by making
        # the actual social media metrics 0 after the required snapshot
        for metric in ['Google_Search_Volume']:
            social_media_data[metric + '_' + str(snapshot)] = social_media_data.apply(
                lambda x: np.nan if x[week_number_colname] >= snapshot else x[metric], axis=1)
            # Creating some basic mean/max variables out of the combined variables
            social_media_data['max_' + metric + '_till_' + str(snapshot)] = social_media_data.groupby(['IMDB_Title_Code'])[metric + '_' + str(snapshot)].transform('max')
            social_media_data['avg_' + metric + '_till_' + str(snapshot)] = social_media_data.groupby(['IMDB_Title_Code'])[metric + '_' + str(snapshot)].transform('mean')
            social_media_data['total_' + metric + '_till_' + str(snapshot)] =social_media_data.groupby(['IMDB_Title_Code'])[metric + '_' + str(snapshot)].transform('sum')
            # Getting title level metrics
            base_ad = pd.merge(base_ad, social_media_data[
                ['IMDB_Title_Code', 'max_' + metric + '_till_' + str(snapshot),
                 'avg_' + metric + '_till_' + str(snapshot),
                 'total_' + metric + '_till_' + str(snapshot)]].drop_duplicates(),
                               on=['IMDB_Title_Code'],
                               how='left')
        # Getting BO Revenue column from base ad into this merged data
        social_media_data = pd.merge(social_media_data,
                                     base_ad[['IMDB_Title_Code', week_number_colname, revenue_colname]],
                                     on=['IMDB_Title_Code', week_number_colname],
                                     how='outer')
        # Creating Adstock for these combined metrics using optimal lambda
        class_instance = Adstock(base_dataframe=social_media_data,
                                 dictionary_spends={'Google_Search_Volume' + '_' + str(snapshot): [0.1, 'Linear']},
                                 week_number_colname=week_number_colname,
                                 revenue_colname=revenue_colname)
        merged_data = class_instance.optimise_adstock()
        # Merging these variables with the base ad
        merged_data.drop(columns=['IMDB_Title_Name', 'Theatrical_Release_Date',
                                  'Week_Start_Date', 'Google_Search_Volume',
                                  revenue_colname], inplace=True)

        # Dropping more variables that have been already merged in the base ad

        merged_data.drop(columns=[col for col in merged_data.columns if 'max' in col or 'avg' in col or 'total' in col],
                         inplace=True)
        base_ad = pd.merge(base_ad, merged_data, on=['IMDB_Title_Code', week_number_colname],
                           how='left')
        return base_ad

    # base_ad.to_excel(r"E:\WB_project\daily_tasks\14082019\modelling_ad_21082019.xlsx", index=False)



