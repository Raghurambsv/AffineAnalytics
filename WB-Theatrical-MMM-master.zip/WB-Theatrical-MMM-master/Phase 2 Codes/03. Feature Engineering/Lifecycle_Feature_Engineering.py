# importing modules
import pandas as pd

def lifecycle_feature_engg(sharepoint_path,root_folder,input_path,export_path=False):

    import sys
    sys.path.insert(0, root_folder + r"/Phase 2 Codes/03. Feature Engineering")
    import marketing_genre_grouping


    # reading dataset
    base_data=pd.read_csv(filepath_or_buffer=input_path,
                          na_values=["#N/A","N/A","NA","na"," ",""],
                          usecols=['imdb_id','title','T_window','theatrical_release_date','base_condition','metric','total'],
                          low_memory=False)

    # pd.read_csv(filepath_or_buffer=sharepoint_path+r"/05. Ad Hoc Requests/Unaided vs EST/Version 2/Archive/aggregate_request_wb_upload.csv",
    #                       na_values=["#N/A","N/A","NA","na"," ",""],
    #                       low_memory=False,
    #                       nrows=2).columns.values

    # base_data.base_condition.unique()
    intermediate_data = base_data[base_data['base_condition']=='Home Entertainment Qualified']
    filtered_data= intermediate_data[intermediate_data['T_window']<1]
    # genre_data=pd.read_excel(sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/Genre Mapping/Mkt Genre_Grouped_final.xlsx")
    genre_data=marketing_genre_grouping.marketing_genre_grouped_creation(raw_file=sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/Genre Mapping/MKT_Genre_Curr_Data_061719 -Ungrouped.xlsx",
                                 mapping_file=sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/Genre Mapping/Mkt Genre_Grouped.xlsx",
                                 export_path=False)

    result = pd.merge(filtered_data,
                    genre_data[['IMDB Title Code','Mkt_Genre_Grouped','Mkt_Genre']],
                    left_on='imdb_id',
                    right_on='IMDB Title Code',
                    how='left')

    result=result.dropna(subset=['IMDB Title Code']) #To drop title codes of lifeycle data which are not present in MKT genre base file

    result.drop(['IMDB Title Code'], axis = 1, inplace = True)
    lc_values=result.groupby(['metric','Mkt_Genre_Grouped'])['total'].mean().reset_index()
    final_lc_values = lc_values[lc_values['metric'].isin(['Awareness','Definitely Interested','Definitely Interested among Aware','HE First Choice  ALL','Interest All Rent','Interest Any Buy','Interest Any HE','Interest HE Any Only','Interest to Buy EST','Interest to Rent cVod','Interest to Rent iVod','TOP2 Interested','Unaid'])]
    final_model_lc_data=final_lc_values.pivot('Mkt_Genre_Grouped', 'metric', 'total')
    # final_model_lc_data.to_excel(export_path)


    return final_model_lc_data

