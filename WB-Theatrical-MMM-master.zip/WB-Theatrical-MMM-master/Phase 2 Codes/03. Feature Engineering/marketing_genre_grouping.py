import pandas as pd

def marketing_genre_grouped_creation(raw_file,mapping_file,export_path=False):

    raw_data=pd.read_excel(io=raw_file)
    mapping_data=pd.read_excel(io=mapping_file)
    genre_mapped_data = pd.merge(raw_data,
                      mapping_data,
                      on='Mkt_Genre',
                      how='left')
    # genre_mapped_data.to_excel(export_path,index=False)
    genre_mapped_data.columns
    genre_mapped_data.rename(columns={'IMDB_Title_Code':'IMDB Title Code'},inplace=True)
    genre_mapped_data=genre_mapped_data.filter(['IMDB Title Code','Mkt_Genre','Mkt_Genre_Grouped'])

    return genre_mapped_data

