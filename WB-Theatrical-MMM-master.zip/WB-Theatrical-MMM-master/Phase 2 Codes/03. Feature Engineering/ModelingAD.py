# -*- coding: utf-8 -*-
"""
Created on Fri Aug  2 14:50:27 2019

@author: mukund
"""

import pandas as pd
import numpy as np
import others
import franchise
import libraries
import holiday_metrics


baseAD = pd.read_excel('./Base AD.xlsx')

## Preprocessing
baseAD.rename(columns={'IMDB Title Code':'IMDB_Title_Code', 'IMDB Title Name':'IMDB_Title_Name', 'Theatrical Release Date':'Theatrical_Release_Date'}, inplace=True)

df_1 = franchise.franchise_flag(baseAD)

df_2 = others.get_scrapped_data(df_1)

df_2['Theatrical_Release_Year'] = df_2['Theatrical_Release_Date'].apply(lambda x: np.float64(x.year))

df_3 = franchise.count_of_movies_in_franchise(df_2, 3)

df_4 = franchise.last_release_duration(df_3)

df_5 = franchise.get_average_earnings(df_4)

df_6 = holiday_metrics.holiday_flag(df_5, 'Theatrical_Release_Date')

df_7 = holiday_metrics.avg_school_outage(df_6, 'Theatrical_Release_Date')

df_7.to_excel('./Base AD.xlsx', index = False)

