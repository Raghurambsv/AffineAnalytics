def Sequel_function(df,sharepoint_path,root_folder):
    """
    The following function creates 4 variables related to the Sequel:
    Universe, Sequel, Count of Universe, Independent Movies

    Args: This will take the input of the dataframe

    Returns: This will return the dataframe with the appended variables

    """
    # importing the libraries
    import sys
    sys.path.insert(0, root_folder + r"/WB-Theatrical-MMM/Phase 2 Codes/03. Feature Engineering")
    from franchise import *
    sys.path.insert(0, root_folder + r"/WB-Theatrical-MMM/Phase 2 Codes/06. Miscellaneous")
    from libraries import *


    # cleaning the date by calling the function
    major_fran = get_major_franchise()
    for i in major_fran.index:
        major_fran.loc[i, 'release date'] = clean_date(x=major_fran.loc[i, 'release date'])
    
    # Dropping rows/movies without any dates
    major_fran.dropna(subset=['release date'], inplace=True)

    # Ranking the franchises based on their dates (Universe)
    major_fran.sort_values(by=['franchise', 'release date'], inplace=True)
    major_fran['Universe_rank'] = major_fran.groupby('franchise')['release date'].apply(lambda x: x.rank())

    # Creating (Sequel) Flag
    major_fran['Sequel_flag'] = major_fran['Universe_rank'].apply(lambda x: 0 if x == 1 else 1)

    # creating variable for count of the number of movies in the universe
    major_fran['Count_of_Universe'] = major_fran.groupby('franchise')['release date'].transform(lambda x: len(x))

    # Creating (Independent) variable flag
    major_fran['Independent_flag'] = major_fran['Count_of_Universe'].transform(lambda x: 0 if x > 1 else 1)

    # Merging with the original data frame
    df = pd.merge(left=df, right=major_fran[['Universe_rank', 'Sequel_flag', 'Count_of_Universe', 'Independent_flag']],
                  how='left',
                  left_on='IMDB_Title_Code',
                  right_on='IMDB title').drop(['IMDB title'], axis=1)

    return df
