# importing modules
import pandas as pd
import sys

def holiday_flag(
        root_folder: str,
        df: pd.core.frame.DataFrame,
        holiday_df: pd.core.frame.DataFrame
) -> pd.core.frame.DataFrame:

    """
    This function identifies holidays at a given week

    Parameters
    ----------
    root_folder: String
        The root location where you are syncing your WB Theatrical github repository
    df: Pandas DataFrame
        A DataFrame containing the column 'Week Start Date'
    holiday_df: Pandas DataFrame
         A DataFrame having the following columns:
            Date
            Holiday
    Returns
    -------
        A DataFrame with holiday flags (1=Holiday, 0=Not-Holiday) in week level
    """

    sys.path.insert(0, root_folder + r"/Phase 2 Codes/06. Miscellaneous")
    import date_manipulations

    holiday_df = date_manipulations.last_sunday(
        df=holiday_df,
        date_column_name='Date',
        sunday_date_column_name='Week Start Date'
    )
    holiday_df = holiday_df.groupby(
        by='Week Start Date'
    ).agg(
        {
            'Holiday': 'count'
        }
    ).reset_index(
        drop=False
    )
    holiday_df['Holiday'] = 1

    df = pd.merge(
        left=df,
        right=holiday_df,
        how='left',
        left_on='Week Start Date',
        right_on='Week Start Date'
    )
    df['Holiday'].fillna(
        value=0,
        inplace=True
    )
    df['Holiday'] = df['Holiday'].astype(int)
    df.rename(
        columns={
            'Holiday': 'Holiday Flag'
        },
        inplace=True
    )

    print("Holiday flag appended")
    return df
