# -*- coding: utf-8 -*-
"""
Created on Thu Sep 26 12:17:53 2019

@author: nitin
"""

import numpy as np
import pandas as pd

sm_data = pd.read_excel(io = r"C:\Users\nitin\Affine Analytics Pvt Ltd\WB Theatrical - Documents\03. Feature Engineering\Factor Analysis\New_Wave_Metrics\Social Media Data.xlsx",
              sheet_name = 'Social Media Data')


######  --------- T-4 snapshot data sets  -----------  #######


##### Excluding Twitter

sm_data['Wikipedia Page Views'] = np.where(sm_data['Week Number'] >-13,0, sm_data['Wikipedia Page Views'])
sm_data['Facebook Comments'] = np.where(sm_data['Week Number'] >-13,0, sm_data['Facebook Comments'])
sm_data['Facebook Likes'] = np.where(sm_data['Week Number'] >-13,0, sm_data['Facebook Likes'])
sm_data['Facebook Ptat'] = np.where(sm_data['Week Number'] >-13,0, sm_data['Facebook Ptat'])
sm_data['Facebook Shares'] = np.where(sm_data['Week Number'] >-13,0, sm_data['Facebook Shares'])
sm_data['Facebook Videos'] = np.where(sm_data['Week Number'] >-13,0, sm_data['Facebook Videos'])
sm_data['Facebook Views'] = np.where(sm_data['Week Number'] >-13,0, sm_data['Facebook Views'])
#sm_data['Twitter Views'] = np.where(sm_data['Week Number'] >-8,0, sm_data['Twitter Views'])
sm_data['YouTube Comments'] = np.where(sm_data['Week Number'] >-13,0, sm_data['YouTube Comments'])
sm_data['YouTube Likes'] = np.where(sm_data['Week Number'] >-13,0, sm_data['YouTube Likes'])
sm_data['YouTube Dislikes'] = np.where(sm_data['Week Number'] >-13,0, sm_data['YouTube Dislikes'])
sm_data['YouTube Videos'] = np.where(sm_data['Week Number'] >-13,0, sm_data['YouTube Videos'])
sm_data['YouTube Views'] = np.where(sm_data['Week Number'] >-13,0, sm_data['YouTube Views'])
sm_data['YouTube Sentiment'] = np.where(sm_data['Week Number'] >-13,0, sm_data['YouTube Sentiment'])
sm_data['Google Search Volume'] = np.where(sm_data['Week Number'] >-13,0, sm_data['Google Search Volume'])


# Create a adstock dataset with the available file
sm_data.to_csv(r"C:\Users\nitin\Affine Analytics Pvt Ltd\WB Theatrical - Documents\03. Feature Engineering\Factor Analysis\New_Wave_Metrics\sm_data.csv",index=False)


# Reading the adstocked data
sm_data_adstocked = pd.read_csv(r"C:\Users\nitin\Affine Analytics Pvt Ltd\WB Theatrical - Documents\03. Feature Engineering\Factor Analysis\New_Wave_Metrics\sm_data_adstocked.csv")


# Revenue Columns
sm_data_adstocked1 = sm_data_adstocked.loc[sm_data_adstocked['BO Revenue'] != 0]

sm_data_adstocked1.columns
### Factor analysis of SM variables:
sm_data_adstocked_f1 = sm_data_adstocked1[['Wikipedia Page Views Adstock Linear0.7',
       'Facebook Comments Adstock Linear0.77',
       'Facebook Likes Adstock Linear0.77', 'Facebook Ptat Adstock Linear0.78',
       'Facebook Shares Adstock Linear0.79',
       'Facebook Videos Adstock Linear0.78',
       'Facebook Views Adstock Linear0.78',
       'Google Search Volume Adstock Linear0.7',
       'YouTube Comments Adstock Linear0.71',
       'YouTube Likes Adstock Linear0.77',
       'YouTube Dislikes Adstock Linear0.64',
       'YouTube Views Adstock Linear0.74', 'YouTube Videos Adstock Linear0.71',
       'YouTube Sentiment Adstock Linear0.75']]


# Scalar Transformation
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(sm_data_adstocked_f1)
sm_data_adstocked_f2 = scaler.transform(sm_data_adstocked_f1)   


# Create factors object and perform factor analysis
from factor_analyzer import FactorAnalyzer
import matplotlib.pyplot as plt

fa = FactorAnalyzer()
fa.fit(sm_data_adstocked_f2, 14)
ev,v = fa.get_eigenvalues()


## Scree Plot suggest 3 factors
plt.scatter(range(1,sm_data_adstocked_f2.shape[1]+1),ev)
plt.plot(range(1,sm_data_adstocked_f2.shape[1]+1),ev)
plt.title('Scree Plot')
plt.xlabel('Factors')
plt.ylabel('Eigenvalue')
plt.grid()
plt.show()


# Fitting a three factor solution as suggested by Scree Plot
fa = FactorAnalyzer(n_factors=3)
fa.fit(sm_data_adstocked_f1)
tot_var_exp = pd.DataFrame({'Factors': ['Factor1','Factor2','Factor3'], '% Variance Explained' :fa.get_factor_variance()[0]/14})

print("Total Variance explained: ",np.sum(tot_var_exp['% Variance Explained']))

# Loading Matrix
factor_loadings = pd.DataFrame({'Var': sm_data_adstocked_f1.columns, 'Factor1': fa.loadings_[:,0], 'Factor2': fa.loadings_[:,1],
              'Factor3': fa.loadings_[:,2]})


sm_factor_df =  pd.DataFrame(data = fa.fit_transform(sm_data_adstocked_f2), columns=['Factor1','Factor2','Factor3'])

final_df_T_8 = pd.merge(sm_data_adstocked1[['IMDB_Title_Code', 'IMDB Title Name', 'Theatrical Release Date',
       'Week Start Date', 'Week Number','BO Revenue']].reset_index(),sm_factor_df,left_index=True,right_index=True).drop(['index'],axis=1)


base_ad = pd.read_excel(io= r"C:\Users\nitin\Affine Analytics Pvt Ltd\WB Theatrical - Documents\03. Feature Engineering\Factor Analysis\New_Wave_Metrics\base_ad_bo_23092019_.xlsx",
                        sheet_name = 'Base AD',header=3,
                        na_values=['#NA','#N/A','',' ','na','NA']
                                   ).drop(['Unnamed: 0'],axis=1)



base_ad_factor = pd.merge(base_ad,final_df_T_8[['IMDB_Title_Code','Week Number','Factor1','Factor2','Factor3']], left_on = ['IMDB Title Code','Week Number'],
                          right_on = ['IMDB_Title_Code','Week Number'],how='left').drop(['IMDB_Title_Code'],axis=1)

base_ad_factor.to_csv(r"C:\Users\nitin\Affine Analytics Pvt Ltd\WB Theatrical - Documents\03. Feature Engineering\Factor Analysis\New_Wave_Metrics\Base_AD_With_Factor_Vars.csv")

base_ad_factor.columns


### Regression
import statsmodels.api as sm
from sklearn.model_selection import train_test_split

base_ad_factor =base_ad_factor.fillna(0)

base_ad_factor1 = base_ad_factor.loc[base_ad_factor['Box Office Revenue']!=0,['IMDB Title Code','Box Office Revenue','Factor1','Factor2','Factor3']]


X = base_ad_factor1.drop(['Box Office Revenue'],axis=1)
Y = base_ad_factor1.loc[:,['Box Office Revenue','IMDB Title Code']]

# Train Test Split 
X_test= X[X['IMDB Title Code'].isin(['tt3741700','tt6423362','tt5884052','tt4913966','tt0448115','tt2452244','tt3513498','tt7905466'])]
X_train= X[~X['IMDB Title Code'].isin(['tt3741700','tt6423362','tt5884052','tt4913966','tt0448115','tt2452244','tt3513498','tt7905466'])]
X_test = X_test.drop(['IMDB Title Code'],axis=1)
X_train = X_train.drop(['IMDB Title Code'],axis=1)

Y_test= Y[Y['IMDB Title Code'].isin(['tt3741700','tt6423362','tt5884052','tt4913966','tt0448115','tt2452244','tt3513498','tt7905466'])]
Y_train= Y[~Y['IMDB Title Code'].isin(['tt3741700','tt6423362','tt5884052','tt4913966','tt0448115','tt2452244','tt3513498','tt7905466'])]

Y_test = Y_test['Box Office Revenue']
Y_train = Y_train['Box Office Revenue']



#X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.20, random_state=123)

X_train = sm.add_constant(X_train)
X_test = sm.add_constant(X_test)

### Fitting a model


mod = sm.OLS(Y_train, X_train).fit()
mod.summary()




## Check VIF
def vif_calc(df):
    vif =[]
    var =[]
    from sklearn.linear_model import LinearRegression
    for i in df.columns:
        lr= LinearRegression()
        lr.fit(df.drop([i],axis=1),df[i])
        r2 = lr.score(df.drop([i],axis=1),df[i])
        vif.append(1/(1-r2))
        var.append(i)
    vif_df = pd.DataFrame({'variable':var,'vif':vif})

    return(vif_df)   
    
    
vif_factor = vif_calc(base_ad_factor1.drop(['Box Office Revenue','IMDB Title Code'],axis=1))




