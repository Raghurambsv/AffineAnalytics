import pandas as pd
import numpy as np
import sys

def gsv(root_folder, sharepoint_path,export_path=False):

    # importing modules
    sys.path.insert(0, root_folder + r"/Rolee/HE Forecasting")
    import Data_cleaning

    base_file=Data_cleaning.data_cleaning(
        root_folder=root_folder,
        sharepoint_path=sharepoint_path,
        cleaning_these='Google Search Volume'
    )["Cleaned GSV"]

    base_file.loc[base_file['Week Number'] > 1, ['Google Search Volume']] = np.NaN # As the model is at T+3 days


    temp = base_file.groupby('IMDB Title Code').agg({'Google Search Volume':[np.nanmax,
                                                                             np.nanmean,
                                                                             np.nansum]}).reset_index(drop=False)

    temp.columns = ['IMDB Title Code', 'Max Google Search Volume', 'Mean Google Search Volume', 'Sum Google Search Volume']



    return temp

