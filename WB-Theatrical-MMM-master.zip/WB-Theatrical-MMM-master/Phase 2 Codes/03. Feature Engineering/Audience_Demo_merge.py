import pandas as pd

def audience_merge(root_folder,sharepoint_path,old_raw_file,new_raw_file):

    import sys
    sys.path.insert(0, root_folder+r"/Phase 2 Codes/01. Data Transformation")

    import New_Audience_Demo_clean


    # old_data = pd.read_csv(sharepoint_path+"/01. Base Data - As received/04. Other Data Elements/Survey Data/Audience Demographics/2019-12-20_Audience-Demos.csv")

    # new_data = pd.read_excel(io = sharepoint_path+"01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Audience Demographics data/20200304_rohan_query_mapped_cleaned.xlsx",
    #                            sheet_name= "20200304_rohan_query")

    # for movio score calculation
    old_pivoted_day1 = New_Audience_Demo_clean.audience_demo_cleaning(raw_file=old_raw_file, export_path=False)

    # dropping these titles since they have an updated value in the latest file
    # Shazam
    old_pivoted_day1.drop(old_pivoted_day1[old_pivoted_day1["IMDB Title Code"] == "tt0448115"].index,inplace = True)
    # The Curse of La Llorona
    old_pivoted_day1.drop(old_pivoted_day1[old_pivoted_day1["IMDB Title Code"] == "tt4913966"].index,inplace = True)
    # PokÃ©mon: Detective Pikachu
    old_pivoted_day1.drop(old_pivoted_day1[old_pivoted_day1["IMDB Title Code"] == "tt5884052"].index,inplace = True)

    new_pivoted_day1 = New_Audience_Demo_clean.new_audience_demo_cleaning(raw_file=new_raw_file, export_path=False)


    col_names_old_data = list(old_pivoted_day1.columns)
    col_names_new_data = list(new_pivoted_day1.columns)

    common_columns = list(set(col_names_new_data).intersection(col_names_old_data))

    appended_df = new_pivoted_day1[common_columns].append(old_pivoted_day1[common_columns],sort = True).reset_index(drop=True)
    # df.rename(columns={col: '' for col in df.columns[idx_filter]}, inplace=True)
    appended_df.rename(columns={col: 'movio '+ col for col in appended_df.columns},inplace=True)


    # for composite score
    comp_old_pivoted_day1 = New_Audience_Demo_clean.comp_audience_demo_cleaning(raw_file = old_raw_file, export_path=False)

    # dropping these titles since they have an updated value in the latest file
    # Shazam
    comp_old_pivoted_day1.drop(comp_old_pivoted_day1[comp_old_pivoted_day1["IMDB Title Code"] == "tt0448115"].index,inplace = True)
    # The Curse of La Llorona
    comp_old_pivoted_day1.drop(comp_old_pivoted_day1[comp_old_pivoted_day1["IMDB Title Code"] == "tt4913966"].index,inplace = True)
    # PokÃ©mon: Detective Pikachu
    comp_old_pivoted_day1.drop(comp_old_pivoted_day1[comp_old_pivoted_day1["IMDB Title Code"] == "tt5884052"].index,inplace = True)
    # Isnt it Romantic
    comp_old_pivoted_day1.drop(comp_old_pivoted_day1[comp_old_pivoted_day1["IMDB Title Code"] == "tt2452244"].index,inplace = True)


    comp_new_pivoted_day1 = New_Audience_Demo_clean.comp_new_audience_demo_cleaning(raw_file = new_raw_file, export_path=False)

    comp_col_names_old_data = list(comp_old_pivoted_day1.columns)
    comp_col_names_new_data = list(comp_new_pivoted_day1.columns)

    comp_common_columns = list(set(comp_col_names_new_data).intersection(comp_col_names_old_data))

    comp_appended_df = comp_new_pivoted_day1[comp_common_columns].append(comp_old_pivoted_day1[comp_common_columns],sort = True)

    audi_df=pd.merge(left=appended_df,
                     right=comp_appended_df,
                     how="right",
                     left_on='movio IMDB Title Code',
                     right_on='IMDB Title Code').drop(['movio IMDB Title Code'],axis=1)


    return audi_df