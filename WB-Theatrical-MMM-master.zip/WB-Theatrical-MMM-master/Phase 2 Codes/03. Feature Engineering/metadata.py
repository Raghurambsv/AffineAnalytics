import pandas as pd
import numpy as np


def metadata(df):

    """
    The following function will add the metadata in the dataframe

    Args: The Argument will be the dataframe
    Return: Returns the dataframe with the appended columns of metadata
    """

    #reading the metadata file
    df_metadata = pd.read_excel(r"C:\Users\abhinav\Affine Analytics Pvt Ltd\WB Theatrical - Documents\02. Exploratory Analysis")

    #merging the original dataframe with the metadata
    df = pd.merge(left = df, right = df_metadata[['Title Code', 'Low Revenue Flag','PRODUCTION_YEAR', 'SOURCE',
                                              'CREATIVE_TYPE', 'PROD_METHOD','REGION','RELEASE_PATTERN']],
                  how = 'left',
                 left_on='IMDB_Title_Code',
                 right_on = 'Title Code').drop(['Title Code'], axis = 1)

    return df
