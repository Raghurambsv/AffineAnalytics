import pandas as pd
import numpy as np

def runtime_creation(input_path,export_path):

    base_file=pd.read_csv(input_path)
    base_file.shape
    base_file.columns
    derived_file=base_file[['titleID', 'Runtime']]
    derived_file.shape


    derived_file['Run'] = [float(x) for x in derived_file['Runtime'].str.replace(" min", "").tolist()]
    derived_file['Runtime_flag_120'] = np.where(derived_file['Run'] >=120, 1,0)
    derived_file['Runtime_flag_110'] = np.where(derived_file['Run'] >= 110, 1, 0)
    derived_file['Runtime_flag_100'] = np.where(derived_file['Run'] >= 100, 1, 0)
    derived_file.to_excel(export_path,index=False)