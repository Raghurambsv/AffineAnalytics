# -*- coding: utf-8 -*-
"""
Created on Tue Aug  6 16:56:19 2019

@author: amit
"""
import pandas as pd
import numpy as np
import sys
from bayes_opt import BayesianOptimization


class Adstock():
    """
    Class which contains various functions to calculate adstock variables at
    Title Level

    Parameters
    ---------
    base_dataframe: Pandas Dataframe
        The base AD in which the spends columns are present
    dictionary_spends: Dictionary
        A dictionary containing the spends information in the following manner:
        key: The name of the spends column\n
        values: A list containing two/three elements in the order of Decay Rate(lambda),
        Decay Type(Linear/Exponential/Logistic) and Learning Rate(only required
        for Exponential and Logistic Types). If you want to optimise the decay rate,
        then just provide any dummy values here, it doesnt matter what they are
    week_number_colname: String
        The name of the column name where week numbers are present
    revenue_colname: String
        The name of the column name where revenue is present
    Returns:
    -------
    Pandas Dataframe: The original dataframe with the adstocked variables calculated
    """
    # Defining the constructor
    def __init__(self, base_dataframe, dictionary_spends, week_number_colname, revenue_colname):
        self.base_dataframe = base_dataframe.copy()
        self.dictionary_spends = dictionary_spends
        self.week_number_colname = week_number_colname
        self.revenue_colname = revenue_colname

    # Defining the linear adstock function
    def adstock_linear(self, current_value, previous_value, decay_rate):
        return current_value+decay_rate*previous_value

    # Defining the exponential decay adstock function
    def adstock_exponential(self, current_value, previous_value, decay_rate, learning_rate):
        return 1-np.exp(-learning_rate*current_value)+decay_rate*previous_value

    # Defining the Logistic (S-Curve) adstock function
    def adstock_logistic(self, current_value, previous_value, decay_rate, learning_rate):
        return 1/(1+np.exp(-learning_rate*current_value))+decay_rate*previous_value

    # The function which calculates adstock values for all the actual values given in a list
    def adstock_calculator(self, spends_list, decay_rate, learning_rate, decay_type):
        # Initialising the adstocked array, which should be the samee length as original spend array
        adstock_spend_array = []
        # For every spend value looping through
        for index, spend in enumerate(spends_list):
            # If it is the first value then returning it as it is
            if index == 0:
                adstock_spend_array.append(spends_list[0])
            # If is in not the first value then calculating adstock using actual
            # current spend value and previous adstocked value
            else:
                if decay_type=='Linear':
                    current_adstock = self.adstock_linear(spend, adstock_spend_array[index-1], decay_rate)
                    adstock_spend_array.append(current_adstock)
                elif decay_type=='Exponential':
                    current_adstock = self.adstock_exponential(spend, adstock_spend_array[index-1], decay_rate, learning_rate)
                    adstock_spend_array.append(current_adstock)
                else:
                    current_adstock = self.adstock_logistic(spend, adstock_spend_array[index-1], decay_rate, learning_rate)
                    adstock_spend_array.append(current_adstock)
        return adstock_spend_array


    def adstock_calculator_main(self):
        """
        The main function of the Adstock class
        Returns:
        -------
        The dataframe with adstocked spends columns
        """
        # Iterating through the dictionary containing the spend items
        for key, value in self.dictionary_spends.items():
            # Unzipping the dictionary and assigning the values to variables
            decay_rate = value[0]
            decay_type = value[1]
            try:
                learning_rate = value[2]
            except IndexError:
                # Raising an exception if the learning rate is not provided for 
                # Exponential and Logistic decay types
                learning_rate = 0
                if decay_type != 'Linear':
                    print("You have not provided learning rate")
                    sys.exit(1)
            self.base_dataframe.sort_values(by=['IMDB Title Code', self.week_number_colname], inplace=True)
            self.base_dataframe.fillna({key: 0}, inplace=True)
            self.base_dataframe[key+' '+'Adstock '+decay_type+str(round(decay_rate, 3))] = self.base_dataframe.groupby('IMDB Title Code')[key].transform(
                lambda x: self.adstock_calculator(list(x), decay_rate, learning_rate, decay_type))

        return self.base_dataframe

    def optimise_adstock(self, list_of_spends=None, n_iter=10):
        """
        The main function to give adstock spends at optimal lambda. Here optimal
        lambda is the one with maximum correlation with BO Revenue
        
        Parameters
        ----------
        list_of_spends: List of strings (Optional)
            The list containing the column names of the spend columns whose optimal 
            adstock. If not given optimisation is done for all the spends passed in
            the spends dictionary
            is to be calculated
        n_iter: int
            Number of iterations to try while searching for maxima (default=10)
            
        Returns
        -------
        The dataframe with adstocked spend columns using optimal lambda
        """
        

        optimisation_base_dataframe = self.base_dataframe.copy()
        # Initialising a dictionary where results will  be stored
        optimised_dictionary = dict()
        if list_of_spends is None:
            list_of_spends = list(self.dictionary_spends.keys())

        for key in list_of_spends:
            print('Optimising: ', str(key))

            # This small function will return the correlation value which needs to be maximised
            def optimisation_function(decay_rate):
                class_instance = Adstock(optimisation_base_dataframe, {key: [decay_rate, 'Linear']}, self.week_number_colname, self.revenue_colname)
                temp = class_instance.adstock_calculator_main()
                optimisation_dataframe = temp.loc[(temp[self.week_number_colname]>=0)&(temp[self.revenue_colname]>0), [self.revenue_colname, key+' '+'Adstock '+'Linear'+str(round(decay_rate, 3))]].copy()
                return optimisation_dataframe.corr().iloc[0, 1]
            # Running the optimiser
            optimizer = BayesianOptimization(
                f=optimisation_function,
                pbounds={
                    "decay_rate": (0.001, 0.9),
                },
                random_state=1234,
                verbose=2
            )
            optimizer.maximize(n_iter=n_iter)
            #print("Final result:", optimizer.max)
            optimised_dictionary[key] = [optimizer.max['params']['decay_rate']]
            optimised_dictionary[key].append('Linear')
        self.dictionary_spends = optimised_dictionary
        print(self.dictionary_spends)
        # Calling the adstock calculator for these optimal lambda values
        final_dataframe = self.adstock_calculator_main()
        return final_dataframe

