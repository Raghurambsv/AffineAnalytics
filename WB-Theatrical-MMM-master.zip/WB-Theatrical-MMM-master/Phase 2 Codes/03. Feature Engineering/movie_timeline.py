# importing modules
import numpy as np
import pandas as pd
from datetime import timedelta
from tqdm import tqdm
import sys

def window_calculation(
        root_folder: str,
        sharepoint_path: str,
        title_list_file: pd.core.frame.DataFrame
) -> pd.core.frame.DataFrame:
    """
    Correct HE Street Dates for titles provided and calculates time gap between releases

    Parameters
    ----------
    root_folder : string
        Home folder containing codes after a github pull
    sharepoint_path : string
        Home folder for shared drive
    title_list_file : A Pandas DataFrame
        List of titles for which release dates & time gap between releases needs to be calculated
        DataFrame should be in the following columns:
            IMDB Title Code
            IMDB Title Name
            Theatrical Release Date
            Studio

    Returns
    -------
    Two DataFrames
        1) A DataFrame with corrected HE Street Dates
        2) A DataFrame containing release dates & time gap between releases
    """

    # importing user defined functions
    sys.path.insert(0, root_folder+r"/Phase 2 Codes/06. Miscellaneous")
    import date_manipulations
    sys.path.insert(0, root_folder + r"/Rolee/HE Forecasting")
    import Data_cleaning

    # importing relevant datasets
    # importing title list
    df = title_list_file.copy()
    df['Theatrical Release Date'] = pd.to_datetime(
        arg=df['Theatrical Release Date'],
        format="%Y-%m-%d",
        errors="coerce"
    )
    df.sort_values(
        by=['Theatrical Release Date'],
        ascending=False,
        inplace=True
    )
    # list of all_titles
    titles = df['IMDB Title Code'].tolist()  # selecting list of title IDs
    # Weekly_HE_sales data
    Weekly_HE_sales = Data_cleaning.data_cleaning(
            root_folder=root_folder,
            sharepoint_path=sharepoint_path,
            cleaning_these=["Weekly Home Ent. Sales"]
        )["Cleaned Weekly HE sales"]

    # keeping information of those titles selected from Title List
    Weekly_HE_sales = Weekly_HE_sales.loc[Weekly_HE_sales['IMDB Title Code'].isin(titles), :].reset_index(drop=True)
    df = df.loc[df['IMDB Title Code'].isin(Weekly_HE_sales['IMDB Title Code'].tolist()), :].reset_index(drop=True)
    titles = df['IMDB Title Code'].tolist()

    # converting negative values in Revenue & Units columns with np.NaN
    Weekly_HE_sales[['Revenue', 'Units']] = Weekly_HE_sales[['Revenue', 'Units']].applymap(
        lambda x: np.nan if x <= 0 else x
    )
    # removing rows with np.NaN values in Revenue and/or Units columns
    Weekly_HE_sales.dropna(
            subset=[
                'Revenue',
                'Units'
            ],
            inplace=True)
    Weekly_HE_sales['Street Date'] = pd.to_datetime(
            arg=Weekly_HE_sales['Street Date'],
            format="%Y-%m-%d",
            errors="coerce"
    )

    # calculating Last Sunday Date
    Weekly_HE_sales = date_manipulations.last_sunday(
        df=Weekly_HE_sales,
        date_column_name='Street Date',
        sunday_date_column_name='Week Start Date'
    )
    df = date_manipulations.last_sunday(
        df=df,
        date_column_name='Theatrical Release Date',
        sunday_date_column_name='Theatrical Week Start Sunday'
    )
    # calculating Theatrical Week Number
    Weekly_HE_sales = pd.merge(
        left=Weekly_HE_sales,
        right=df[
            [
                'IMDB Title Code',
                'IMDB Title Name',
                'Theatrical Week Start Sunday'
            ]
        ],
        how='left',
        left_on='IMDB Title Code',
        right_on='IMDB Title Code'
    ).drop(
        [
            'Global Title Description'
        ],
        axis=1
    )
    Weekly_HE_sales['Theatrical Week Number'] = (
            np.floor(
                (
                        (
                                Weekly_HE_sales['Theatrical Week Start Sunday'] -
                                Weekly_HE_sales['Week Start Date']
                        ) / pd.offsets.Day(-1)
                ) / 7
            ) +
            Weekly_HE_sales['Week']
    )
    # calculating Week Start Date
    for i in tqdm(Weekly_HE_sales.index):
        Weekly_HE_sales.loc[i, 'Week Start Date'] = (
                Weekly_HE_sales.loc[i, 'Theatrical Week Start Sunday'] +
                timedelta(
                    days=int(Weekly_HE_sales.loc[i, 'Theatrical Week Number']) * 7
                )
        )
    del i

    # # fixing double studio issues
    # for id in tqdm(Weekly_HE_sales['IMDB Title Code'].unique()):
    #     temp = Weekly_HE_sales.loc[Weekly_HE_sales['IMDB Title Code'] == id, :]
    #     for format in temp['Media Type'].unique():
    #         temp1 = temp.loc[temp['Media Type'] == format, :]
    #         for subformat in temp1['Media SubType'].unique():
    #             temp2 = temp1.loc[temp1['Media SubType'] == subformat, :]
    #             if len(temp2['Studio'].unique()) > 1:
    #                 if temp2['Studio'].str.contains('WARNER').sum() > 0:
    #                     Weekly_HE_sales.drop(
    #                         index=temp2.loc[temp2['Studio'] != 'WARNER'].index.values,
    #                         axis=0,
    #                         inplace=True
    #                     )
    #                 else:
    #                     gp_data = temp2.groupby(
    #                         [
    #                             'IMDB Title Code',
    #                             'Studio',
    #                             'Street Date'
    #                         ]
    #                     ).agg(
    #                         {
    #                             'Revenue': 'sum',
    #                             'Units': 'sum'
    #                         }
    #                     ).reset_index()
    #                     if len(gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].unique()) == 2:
    #                         Weekly_HE_sales.drop(
    #                             index=temp2.loc[temp2['Studio'] == 'ALL OTHERS'].index.values,
    #                             axis=0,
    #                             inplace=True
    #                         )
    #                     elif len(gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].unique()) == 1:
    #                         Weekly_HE_sales.drop(
    #                             index=Weekly_HE_sales.loc[
    #                                   (Weekly_HE_sales['IMDB Title Code'] == id) &
    #                                   (Weekly_HE_sales['Studio'] == (
    #                                       gp_data.loc[
    #                                           gp_data['Revenue'] != max(gp_data['Revenue']),
    #                                           'Studio'
    #                                       ].values
    #                                   )[0]),
    #                                   :].index.values,
    #                             axis=0,
    #                             inplace=True
    #                         )
    # fixing double Street Date issues
    Weekly_HE_sales = Weekly_HE_sales.groupby(
        [
            'IMDB Title Code',
            'IMDB Title Name',
            'Media Type',
            'Media SubType',
            'Studio',
            'Week Start Date',
            'Theatrical Week Start Sunday',
            'Theatrical Week Number'
        ]
    ).agg(
        {
            'Street Date': np.min,
            'Revenue': np.sum,
            'Units': np.sum,
        }
    ).reset_index(drop=False)

    Weekly_HE_sales = Weekly_HE_sales.groupby(
        [
            'IMDB Title Code',
            'IMDB Title Name',
            'Media Type',
            'Media SubType',
            'Week Start Date',
            'Theatrical Week Start Sunday',
            'Theatrical Week Number'
        ]
    ).agg(
        {
            'Street Date': np.min,
            'Revenue': np.sum,
            'Units': np.sum,
        }
    ).reset_index(drop=False)

    # fixing Street Dates
    Weekly_HE_sales_temp = pd.DataFrame({})
    for id in tqdm(Weekly_HE_sales['IMDB Title Code'].unique().tolist()):
        temp = Weekly_HE_sales.loc[Weekly_HE_sales['IMDB Title Code'] == id, :]
        for mediatype in Weekly_HE_sales['Media Type'].unique():
            temp1 = temp.loc[temp['Media Type'] == mediatype, :]
            for mediasubtype in Weekly_HE_sales['Media SubType'].unique():
                temp2 = temp1.loc[temp1['Media SubType'] == mediasubtype, :]
                for dt in temp['Street Date'].unique():
                    temp3 = temp2.loc[temp['Street Date'] == dt, :]
                    min_wk = temp3['Week Start Date'].min()
                    for i in temp3.index:
                        temp3.loc[i, 'Street Date'] = min_wk
                        del i
                    Weekly_HE_sales_temp = pd.concat(
                        [
                            Weekly_HE_sales_temp,
                            temp3
                        ],
                        axis=0
                    )
                    del temp3, dt
                del temp2
            del temp1
        del temp
    del id
    Weekly_HE_sales = Weekly_HE_sales_temp.copy()
    del Weekly_HE_sales_temp

    # creating list of all IMDB_Title_Codes & their Theatrical, EST & PST Release Dates
    all_titles = df.copy()

    all_titles['DVD Rental Street Date'] = np.NaN
    all_titles['DVD Sell-Thru Street Date'] = np.NaN
    all_titles['Blu-ray Rental Street Date'] = np.NaN
    all_titles['Blu-ray Sell-Thru Street Date'] = np.NaN
    all_titles['EST Sell-Thru Street Date'] = np.NaN
    all_titles['iVOD Rental Street Date'] = np.NaN
    all_titles['VOD Rental Street Date'] = np.NaN
    for i in tqdm(all_titles['IMDB Title Code'].unique()):
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'DVD Rental Street Date'] = Weekly_HE_sales.loc[
            (Weekly_HE_sales['IMDB Title Code'] == i) &
            (Weekly_HE_sales['Media Type'] == 'DVD') &
            (Weekly_HE_sales['Media SubType'] == 'Rental'), 'Week Start Date'
        ].min()
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'DVD Sell-Thru Street Date'] = Weekly_HE_sales.loc[
            (Weekly_HE_sales['IMDB Title Code'] == i) &
            (Weekly_HE_sales['Media Type'] == 'DVD') &
            (Weekly_HE_sales['Media SubType'] == 'Sell-Thru'), 'Week Start Date'
        ].min()
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'Blu-ray Rental Street Date'] = Weekly_HE_sales.loc[
            (Weekly_HE_sales['IMDB Title Code'] == i) &
            (Weekly_HE_sales['Media Type'] == 'Blu-ray') &
            (Weekly_HE_sales['Media SubType'] == 'Rental'), 'Week Start Date'
        ].min()
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'Blu-ray Sell-Thru Street Date'] = Weekly_HE_sales.loc[
            (Weekly_HE_sales['IMDB Title Code'] == i) &
            (Weekly_HE_sales['Media Type'] == 'Blu-ray') &
            (Weekly_HE_sales['Media SubType'] == 'Sell-Thru'), 'Week Start Date'
        ].min()
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'EST Sell-Thru Street Date'] = Weekly_HE_sales.loc[
            (Weekly_HE_sales['IMDB Title Code'] == i) &
            (Weekly_HE_sales['Media Type'] == 'EST') &
            (Weekly_HE_sales['Media SubType'] == 'Sell-Thru'), 'Week Start Date'
        ].min()
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'iVOD Rental Street Date'] = Weekly_HE_sales.loc[
            (Weekly_HE_sales['IMDB Title Code'] == i) &
            (Weekly_HE_sales['Media Type'] == 'iVOD') &
            (Weekly_HE_sales['Media SubType'] == 'Rental'), 'Week Start Date'
        ].min()
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'VOD Rental Street Date'] = Weekly_HE_sales.loc[
            (Weekly_HE_sales['IMDB Title Code'] == i) &
            (Weekly_HE_sales['Media Type'] == 'VOD') &
            (Weekly_HE_sales['Media SubType'] == 'Rental'), 'Week Start Date'
        ].min()
    del i

    all_titles['DVD Rental Street Date'] = pd.to_datetime(
        arg=all_titles['DVD Rental Street Date'],
        format="%Y-%m-%d",
        errors="coerce"
    )
    all_titles['DVD Sell-Thru Street Date'] = pd.to_datetime(
        arg=all_titles['DVD Sell-Thru Street Date'],
        format="%Y-%m-%d",
        errors="coerce"
    )
    all_titles['Blu-ray Rental Street Date'] = pd.to_datetime(
        arg=all_titles['Blu-ray Rental Street Date'],
        format="%Y-%m-%d",
        errors="coerce"
    )
    all_titles['Blu-ray Sell-Thru Street Date'] = pd.to_datetime(
        arg=all_titles['Blu-ray Sell-Thru Street Date'],
        format="%Y-%m-%d",
        errors="coerce"
    )
    all_titles['EST Sell-Thru Street Date'] = pd.to_datetime(
        arg=all_titles['EST Sell-Thru Street Date'],
        format="%Y-%m-%d",
        errors="coerce"
    )
    all_titles['iVOD Rental Street Date'] = pd.to_datetime(
        arg=all_titles['iVOD Rental Street Date'],
        format="%Y-%m-%d",
        errors="coerce"
    )
    all_titles['VOD Rental Street Date'] = pd.to_datetime(
        arg=all_titles['VOD Rental Street Date'],
        format="%Y-%m-%d",
        errors="coerce"
    )


    all_titles["PST Release Date"] = np.nanmin(
        all_titles[
            [
                'Blu-ray Rental Street Date',
                'Blu-ray Sell-Thru Street Date',
                'DVD Rental Street Date',
                'DVD Sell-Thru Street Date',
            ]
        ],
        axis=1
    )
    all_titles = all_titles.rename(
        columns={
            "EST Sell-Thru Street Date": "EST Release Date",
            "iVOD Rental Street Date": "iVOD Release Date",
            "VOD Rental Street Date": "VOD Release Date"
        }
    ).drop(
        [
            'DVD Rental Street Date',
            'DVD Sell-Thru Street Date',
            'Blu-ray Rental Street Date',
            'Blu-ray Sell-Thru Street Date'
        ],
        axis=1
    )

    all_formats = [
        "Theatrical",
        "EST",
        "iVOD",
        "VOD",
        "PST"
    ]
    for media1 in range(0, len(all_formats)):
        if media1 < len(all_formats)-1:
            for media2 in range(media1+1, len(all_formats)):
                all_titles[
                    all_formats[media1] +
                    " to " +
                    all_formats[media2] +
                    " Window"
                ] = (
                                            (
                                                    date_manipulations.last_sunday(
                                                        df=all_titles,
                                                        date_column_name=all_formats[media1] + " Release Date",
                                                        sunday_date_column_name='Sunday Date'
                                                    )['Sunday Date'] -
                                                    date_manipulations.last_sunday(
                                                        df=all_titles,
                                                        date_column_name=all_formats[media2] + " Release Date",
                                                        sunday_date_column_name='Sunday Date'
                                                    )['Sunday Date']
                                            ) / pd.offsets.Day(-1)
                                    ) / 7

    print("Window Calculation: Done")

    return Weekly_HE_sales, all_titles
