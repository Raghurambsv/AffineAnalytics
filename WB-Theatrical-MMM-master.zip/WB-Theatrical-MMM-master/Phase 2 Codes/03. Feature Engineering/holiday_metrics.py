import numpy as np
import pandas as pd
from datetime import timedelta
import sys
import holidays
from datetime import date

# def generating_holiday():
#     us_holidays = holidays.US()
#     print(us_holidays)
#     us_holidays.get('2014-01-01')
#
#     # Print all the holidays in UnitedKingdom in year 2018
#     count=0
#     for ptr in holidays.UnitedStates(years=[2015],prov=None,state='CA').items():
#         count+=1
#         print(ptr)
#     print(count)

def holiday_flag(root_folder, base_dataframe, date_col_calendar, date_col_base_dataframe, holiday_calendar):

    sys.path.insert(0, root_folder+r"/WB-Theatrical-MMM/Phase 2 Codes/06. Miscellaneous")
    import date_manipulations

    """
    Function to create holiday flag which is 1 if there is any US holiday in that week
    else 0

    Parameters
    ---------
    base_dataframe: Pandas Dataframe
        The base AD in which flag is to be calculated
    date_col_calendar: String
        The column name of the holiday date column in the holiday calender
    date_col_base_dataframe: String
        The column name of the week start date column in the base AD
    holiday_calendar: Pandas Dataframe
        The holiday calendar containing the important holidays of US

    Returns
    -------
    The updated Base AD with the flag column
    """
    # Converting the date column to pandas datetime onject
    holiday_calendar[date_col_calendar] = pd.to_datetime(holiday_calendar[date_col_calendar])
    # For every date getting its last sunday date
    holiday_calendar = date_manipulations.last_sunday(holiday_calendar, date_col_calendar,
                                                      'Week Start Date')
    holiday_calendar = holiday_calendar[['Week Start Date']]
    holiday_calendar['holiday_flag'] = 1
    holiday_calendar.drop_duplicates(inplace=True)
    base_dataframe.columns
    base_dataframe = pd.merge(base_dataframe, holiday_calendar,
                              on='Week Start Date', how='left'
                              )
    base_dataframe.fillna({'holiday_flag': 0}, inplace=True)
    return base_dataframe


def long_weekend_flag(root_folder, base_dataframe, date_col_calendar, date_col_base_dataframe, holiday_calendar):

    sys.path.insert(0, root_folder+r"/WB-Theatrical-MMM/Phase 2 Codes/06. Miscellaneous")
    import date_manipulations

    """
    Function to create long weekend flag which is 1 if there is any long weekend
    else 0

    Parameters
    ---------
    base_dataframe: Pandas Dataframe
        The base AD in which flag is to be calculated
    date_col_calendar: String
        The column name of the holiday date column in the holiday calender
    date_col_base_dataframe: String
        The column name of the week start date column in the base AD
    holiday_calendar: Pandas Dataframe
        The holiday calendar containing the important holidays of US

    Returns
    -------
    The updated Base AD with the long weekend flag column
    """
    # Converting the date column to pandas datetime onject
    holiday_calendar[date_col_calendar] = pd.to_datetime(holiday_calendar[date_col_calendar])

    # For every date getting its last sunday date
    holiday_calendar = date_manipulations.last_sunday(holiday_calendar, date_col_calendar,
                                                      'Week Start Date')
    # Creating a flag if the holiday is on Mon/Thu/Fri
    holiday_calendar['long_weekend_flag'] = holiday_calendar[date_col_calendar].apply(
        lambda x: 1 if (x.weekday()) in [0, 3, 4] else 0)
    holiday_calendar = holiday_calendar.loc[holiday_calendar['long_weekend_flag'] == 1, :]
    holiday_calendar.drop_duplicates(subset=['Week Start Date'], inplace=True)
    base_dataframe = pd.merge(base_dataframe, holiday_calendar[['Week Start Date', 'long_weekend_flag']],
                              left_on=date_col_base_dataframe,
                              right_on='Week Start Date',
                              how='left').drop(['Week Start Date'], axis=1)
    base_dataframe.fillna({'long_weekend_flag': 0}, inplace=True)
    return base_dataframe

def easter_flag(root_folder, base_dataframe, date_col_calendar, date_col_base_dataframe, holiday_calendar):

    sys.path.insert(0, root_folder + r"/WB-Theatrical-MMM/Phase 2 Codes/06. Miscellaneous")
    import date_manipulations

    """
    Function to create easter flag which is 1 if there is easter flag in that week
    else 0

    Parameters
    ---------
    base_dataframe: Pandas Dataframe
        The base AD in which flag is to be calculated
    date_col_calendar: String
        The column name of the holiday date column in the holiday calender
    date_col_base_dataframe: String
        The column name of the week start date column in the base AD
    holiday_calendar: Pandas Dataframe
        The holiday calendar containing the important holidays of US

    Returns
    -------
    The updated Base AD with the easter flag column
    """

    holiday_calendar = holiday_calendar[holiday_calendar['Holiday'] == 'Easter Day']
    # Converting the date column to pandas datetime onject
    holiday_calendar[date_col_calendar] = pd.to_datetime(holiday_calendar[date_col_calendar])
    # For every date getting its last sunday date
    holiday_calendar = date_manipulations.last_sunday(holiday_calendar, date_col_calendar,
                                                      'Week Start Date')
    holiday_calendar = holiday_calendar[['Week Start Date']]
    holiday_calendar['Easter Flag']=1
    base_dataframe = pd.merge(base_dataframe, holiday_calendar,
                              left_on=date_col_base_dataframe,
                              right_on='Week Start Date', how='left'
                              ).drop(['Week Start Date'], axis=1)
    base_dataframe.fillna({'Easter Flag': 0}, inplace=True)
    return base_dataframe

def fourth_july(root_folder, base_dataframe, date_col_calendar, date_col_base_dataframe, holiday_calendar):

    sys.path.insert(0, root_folder + r"/WB-Theatrical-MMM/Phase 2 Codes/06. Miscellaneous")
    import date_manipulations

    """
    Function to create 4th of July flag which is 1 if there is 4th july in that week
    else 0

    Parameters
    ---------
    base_dataframe: Pandas Dataframe
        The base AD in which flag is to be calculated
    date_col_calendar: String
        The column name of the holiday date column in the holiday calender
    date_col_base_dataframe: String
        The column name of the week start date column in the base AD
    holiday_calendar: Pandas Dataframe
        The holiday calendar containing the important holidays of US

    Returns
    -------
    The updated Base AD with the 4th of july flag column
    """

    holiday_calendar = holiday_calendar[holiday_calendar['Holiday'] == '4th of july']
    # Converting the date column to pandas datetime onject
    holiday_calendar[date_col_calendar] = pd.to_datetime(holiday_calendar[date_col_calendar])
    # For every date getting its last sunday date
    holiday_calendar = date_manipulations.last_sunday(holiday_calendar, date_col_calendar,
                                                      'Week Start Date')
    holiday_calendar = holiday_calendar[['Week Start Date']]
    holiday_calendar['fourth july flag']=1
    base_dataframe = pd.merge(base_dataframe, holiday_calendar,
                              left_on=date_col_base_dataframe,
                              right_on='Week Start Date', how='left'
                              ).drop(['Week Start Date'], axis=1)
    base_dataframe.fillna({'fourth july flag': 0}, inplace=True)
    return base_dataframe