# -*- coding: utf-8 -*-
"""
Created on Thu Jul 25 16:33:51 2019

@author: amit
"""

import pandas as pd
import bs4
from requests import get
import re
from tqdm import tqdm
from imdb import IMDb




def get_similar_movies(dataframe_with_titles, colname_of_title_code):
    """
    Function to get similar movie titles for a movie

    Parameters
    ----------
    dataframe_with_titles: Pandas Dataframe
        The base dataframe containing title codes
    colname_of_title_code: String
        The column name of the Title Code Column


    Returns
    ------
    Pandas Dataframe
        A dataframe with all similar titles at base title similar title level
    """

    # Creating an empty dictionary where the final results will be stored
    similar_titles_dict = {}
    # Looping through all the titles in the base file
    for title_code in tqdm(dataframe_with_titles[colname_of_title_code]):
        try:
            # Making a soup object of the movie url response
            movie_url = get("https://www.imdb.com/title/"+str(title_code)+"/")
            soup_obj = bs4.BeautifulSoup(movie_url.text,  'lxml')
            # Creating an intermediate array which will store similar titles for every base title
            similar_titles_array = []
            # Getting the image class  where the similar movies are stored in webpage
            image_class = soup_obj.find(name='div', class_='rec_view').find_all('a', href=re.compile(r'/title/'))
            # Appending each similar movie in the above intermediate array
            for img in image_class:
                similar_title_code = img.get('href')
                similar_title_code = re.search(r'tt\d+', similar_title_code).group()
                similar_titles_array.append(similar_title_code)
            # Updating the dictionary with the current title in the loop
            similar_titles_dict[title_code] = similar_titles_array
        except:
            similar_titles_dict[title_code] = ["Not Found"]
    # Converting the dictionary into a dataframe at title similar movie level
    similar_titles_dataframe = pd.DataFrame.from_dict(similar_titles_dict, orient='index').reset_index()
    similar_titles_dataframe = pd.melt(similar_titles_dataframe, id_vars='index')
    similar_titles_dataframe.rename(columns={'index': 'IMDB_Title_Code',
                                             'variable': 'similar_title_num',
                                             'value': 'similar_title_code'}, inplace=True)
    return similar_titles_dataframe


def get_rating(dataframe_with_titles, colname_of_title_code):
    """
    Function to get ratings and US release dates from IMDB

    Parameters
    ----------
    dataframe_with_titles: Pandas Dataframe
        The base dataframe containing title codes
    colname_of_title_code: String
        The column name of the Title Code Column


    Returns
    ------
    Pandas Dataframe
        A dataframe with ratings and release dates for the titles
    """
    # Create empty arrays where the results will be kept appending
    title_list = []
    release_date_list = []
    rating_list = []
    # Looping through all the titles
    for title in tqdm(dataframe_with_titles[colname_of_title_code]):
        # Making a soup object of the title for rating
        try:
            movie_url = get("https://www.imdb.com/title/"+str(title)+"/")
            soup_obj = bs4.BeautifulSoup(movie_url.text,  'lxml')
            title_list.append(title)
        except:
            continue
        # Getting the movie rating if available else "Not Found"
        try:
            rating = soup_obj.find('span', itemprop='ratingValue').get_text()
            rating_list.append(rating)
        except:
            rating_list.append('Not Found')
        # Getting the US release date else "Not Found"
        try:
            movie_url = get("https://www.imdb.com/title/"+str(title)+"/releaseinfo?ref_=tt_ov_inf")
            soup_obj = bs4.BeautifulSoup(movie_url.text,  'lxml')
            release_date_found = False
            multiple_date_list = soup_obj.find_all('tr', class_='ipl-zebra-list__item release-date-item')
            us_release_dates = []
            for index, date in enumerate(multiple_date_list):
                # We need the US release date hence checking all the 'td' tags where it is present
                try:
                    date = date.find('a', href=re.compile(r'/calendar/\?region=us')).get_text()
                    # There  can be multiple US release dates hence making a list of them
                    us_release_dates.append(multiple_date_list[index].find('td', class_='release-date-item__date').get_text())
                    release_date_found = True
                except:
                    continue
            if release_date_found:
                release_date_list.append(us_release_dates)
            else:
                release_date_list.append(["Not Found"])
        except:
            release_date_list.append(["Not Found"])
    # Creating a dataframe from all  the result arrays
    rating_dataframe = pd.DataFrame({'IMDB_Title_Code': title_list,
                                     'IMDB_Rating': rating_list,
                                     'IMDB_US_Release_Date': release_date_list})
    return rating_dataframe


if __name__ == "__main__":
    dataframe_with_titles = pd.read_csv(r"E:\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Scrapped Title Info - IMDB\bo_model_ad_27062019_yt_v3.csv")
    output_df = get_similar_movies(dataframe_with_titles[['IMDB_Title_Code']], 'IMDB_Title_Code')
    required_data = output_df.drop_duplicates(subset='similar_title_code')
    rating_data = get_rating(required_data, 'similar_title_code')
    output_df_2 = pd.merge(output_df, rating_data,
                           left_on='similar_title_code', 
                           right_on='IMDB_Title_Code',
                           how='left')
    output_df_2.drop('IMDB_Title_Code_y', axis=1, inplace=True)
    output_df_2.rename(columns={'IMDB_Title_Code_x': 'IMDB_Title_Code',
                                'IMDB_Rating': 'similar_title_rating',
                                'IMDB_US_Release_Date': 'similar_title_release'}, inplace=True)
    output_df_2.to_excel(r"E:\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Scrapped Title Info - IMDB\IMDB_similar_movies_v2.xlsx", index=False)
