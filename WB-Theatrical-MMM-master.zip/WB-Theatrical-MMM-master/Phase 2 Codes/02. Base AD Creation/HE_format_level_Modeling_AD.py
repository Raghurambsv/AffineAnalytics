# importing modules
import numpy as np
import pandas as pd
from tqdm import tqdm
import sys
import time

def he_modeling_ad_creation(sale, media, root_folder, sharepoint_path, export_path_user=False):


    sys.path.insert(0, root_folder + r"/Rolee/HE Forecasting")
    import Data_cleaning
    import Feature_Engineering
    sys.path.insert(0, root_folder + r"/Phase 2 Codes/02. Base AD Creation")
    import HE_format_level_Base_AD
    sys.path.insert(0, root_folder + r"/Phase 2 Codes/06. Miscellaneous" )
    import clubbing_weeks

    temp = Data_cleaning.data_cleaning(
        root_folder=root_folder,
        sharepoint_path=sharepoint_path
    )

    bo_rev_df = temp["Cleaned Total Theater Sales"]
    posttrak_df = temp["Cleaned Postrak"]
    audi_df = temp["Cleaned Audience Demographics"]
    md_df = temp["Cleaned Metadata"]
    tomatometer_df = temp["Cleaned Tomatometer"]



    mg_df, lifecycle_df, gsv_df, franchise_df=Feature_Engineering.feature_engg(root_folder=root_folder,
                                                                               sharepoint_path=sharepoint_path)


    studio = 'wb'
    wb_modeling_ad = HE_format_level_Base_AD.he_base_ad_creation(sale, studio, media, root_folder, sharepoint_path)
    wb_modeling_ad.to_csv(r"C:/Users/rolee/Desktop/trial_wb_Base_AD.csv", index=False)
    studio = 'nonwb'
    nonwb_modeling_ad = HE_format_level_Base_AD.he_base_ad_creation(sale, studio, media, root_folder, sharepoint_path)
    nonwb_modeling_ad.to_csv(r"C:/Users/rolee/Desktop/trial_non_wb_Base_AD.csv", index=False)

    # Combining both WB & Non-WB Base AD and getting a combined AD
    wb_modeling_ad['WB Flag']=1
    nonwb_modeling_ad['WB Flag']=0
    combined_modeling_ad = pd.concat([wb_modeling_ad, nonwb_modeling_ad])
    # combined_modeling_ad.to_csv(r"C:/Users/rolee/Desktop/trial_combined_Base_AD.csv", index=False)

    # Theatrical release year
    combined_modeling_ad['Theatrical Release Year'] = combined_modeling_ad['Theatrical Release Date'].dt.year

    # Media release year
    temp_df=combined_modeling_ad[['IMDB Title Code','Week Start Date',media+' Week Number']]
    temp_df=temp_df[temp_df[media+' Week Number']==0]
    temp_df[media+' Release Year']=temp_df['Week Start Date'].dt.year
    combined_modeling_ad=pd.merge(left=combined_modeling_ad,
                         right=temp_df.drop(['Week Start Date', 'VOD Week Number'],axis=1),
                         on='IMDB Title Code',
                         how='left')


    #Franchise
    combined_modeling_ad=pd.merge(combined_modeling_ad,
                         franchise_df,
                         on='IMDB Title Code',
                         how='left')


    #Google Search Volume
    combined_modeling_ad=pd.merge(combined_modeling_ad,
                         gsv_df,
                         on='IMDB Title Code',
                         how='left')


    #Marketing Genre
    combined_modeling_ad = pd.merge(combined_modeling_ad,
                           mg_df,
                           on='IMDB Title Code',
                           how='left')


    #Tomatometer
    combined_modeling_ad=pd.merge(combined_modeling_ad,
                         tomatometer_df[['IMDB Title Code','tomatometer']],
                         on='IMDB Title Code',
                         how='left'
                         )

    #Posttrak
    combined_modeling_ad = pd.merge(combined_modeling_ad,
                           posttrak_df[['IMDB Title Code', 'Number of Theatres released','Definitely Recommended']],
                           on='IMDB Title Code',
                           how='left'
                           )

    #Lifecycle
    combined_modeling_ad=pd.merge(combined_modeling_ad,
                         lifecycle_df,
                         on='Mkt_Genre_Grouped',
                         how='left')


    #Week2 Onwards Flag
    combined_modeling_ad['Week2 Onwards']=np.where(combined_modeling_ad[media+' Week Number']>=2, 1, 0)


    #BO Revenue & Opening Weekend
    combined_modeling_ad = pd.merge(combined_modeling_ad,
                           bo_rev_df[['IMDB Title Code','Opening Weekend Box Office','BO Revenue']],
                           on='IMDB Title Code',
                           how='left')

    #Metadata
    combined_modeling_ad=pd.merge(combined_modeling_ad,
                         md_df,
                         left_on='IMDB Title Code',
                         right_on='Title Code',
                         how='left').drop(['Title Code'],axis=1)

    # clubbing week0 and week1
    combined_modeling_ad = clubbing_weeks.units_clubbed(DataFrame=combined_modeling_ad,
                                                        IMDB_Title_Code='IMDB Title Code',
                                                        revenue=media + ' ' + sale + '',
                                                        weeks=media + ' Week Number')

    # # Audience Demo Data
    # combined_modeling_ad = pd.merge(combined_modeling_ad,
    #                                 audi_df,
    #                                 on='IMDB Title Code',
    #                                 how='left')


    # AUDIENCE DEMO DATA & its IMPUTATION

    mkt_df = combined_modeling_ad[combined_modeling_ad[media+' Week Number'] == 0]
    mkt_df = mkt_df[['IMDB Title Code', 'Mkt_Genre_Grouped']]
    mkt_df=mkt_df.dropna(subset=['Mkt_Genre_Grouped'])
    demo_data = pd.merge(
        left=mkt_df,
        right=audi_df,
        how="left",
        on='IMDB Title Code')
    final_col = list(demo_data.columns)
    exclude = ['IMDB Title Code','Release Period','Mkt_Genre_Grouped']
    for i in tqdm(final_col):
        if (i not in exclude):
            tempNA = demo_data.loc[pd.isnull(demo_data[i]), :]
            tempNonNA = demo_data.loc[~(pd.isnull(demo_data[i])), :]
            grouped = tempNonNA.groupby('Mkt_Genre_Grouped').agg({i: 'mean'}).reset_index()
            tempNA = pd.merge(left=tempNA.drop(i, axis=1),
                              right=grouped,
                              how='left',
                              on='Mkt_Genre_Grouped')
            demo_data = pd.concat([tempNA, tempNonNA],
                                  axis=0,
                                  sort=True)
    demo_data = demo_data[final_col]
    combined_modeling_ad = pd.merge(
        left=combined_modeling_ad,
        right=demo_data.drop(columns=['Mkt_Genre_Grouped']),
        how="left",
        on='IMDB Title Code')


    #POSTTRAK IMPUTATION
    temp_df = combined_modeling_ad[['IMDB Title Code', media + ' Week Number', 'Number of Theatres released','Definitely Recommended']]
    temp_df=temp_df.loc[temp_df[media + ' Week Number'] == 1]
    temp_df =temp_df.dropna(axis=0, how='any')
    """
    To get the imputed value of the previous Modeling AD, we drop the duplicates.
    Otherwise proper way is not dropping the duplicates. So, if the model is refreshed then we shouldnt drop the duplicates.
    """
    temp_df.drop_duplicates(subset=['Number of Theatres released','Definitely Recommended'], inplace=True)
    no_of_theat_median=temp_df['Number of Theatres released'].median(skipna=False)
    def_recom_median=temp_df['Definitely Recommended'].median(skipna=False)
    combined_modeling_ad['Number of Theatres released'].fillna(no_of_theat_median, inplace=True)
    combined_modeling_ad['Definitely Recommended'].fillna(def_recom_median, inplace=True)
    # combined_modeling_ad.to_csv(r"C:/Users/rolee/Desktop/trial_modeling_AD.csv", index=False)

    return combined_modeling_ad

    # # holiday metrics
    # modeling_ad = holiday_metrics.holiday_flag(root_folder = root_folder,
    #                            base_dataframe=modeling_ad,
    #                            date_col_calendar='Date',
    #                            date_col_base_dataframe='Week Start Date',
    #                            holiday_calendar=pd.read_excel(io=sharepoint_path+r"/03. Feature Engineering/02. Codes/Modelling AD Folder/US Holiday Calendar Exhaustive.xlsx",
    #                                                           sheet_name="Sheet1",
    #                                                           na_values=['#NA','#N/A','',' ','na','NA']))
    # modeling_ad = holiday_metrics.long_weekend_flag(root_folder = root_folder,
    #                                 base_dataframe=modeling_ad,
    #                                 date_col_calendar='Date',
    #                                 date_col_base_dataframe='Week Start Date',
    #                                 holiday_calendar=pd.read_excel(io=sharepoint_path+r"/03. Feature Engineering/02. Codes/Modelling AD Folder/US Holiday Calendar Exhaustive.xlsx",
    #                                                                sheet_name="Sheet1",
    #                                                                na_values=['#NA','#N/A','',' ','na','NA']))
    # modeling_ad = holiday_metrics.easter_flag(root_folder=root_folder,
    #                                            base_dataframe=modeling_ad,
    #                                            date_col_calendar='Date',
    #                                            date_col_base_dataframe='Week Start Date',
    #                                            holiday_calendar=pd.read_excel(
    #                                                io=sharepoint_path + r"/03. Feature Engineering/02. Codes/Modelling AD Folder/US Holiday Calendar Exhaustive.xlsx",
    #                                                sheet_name="Sheet1",
    #                                                na_values=['#NA', '#N/A', '', ' ', 'na', 'NA']))
    # modeling_ad = holiday_metrics.fourth_july(root_folder=root_folder,
    #                                            base_dataframe=modeling_ad,
    #                                            date_col_calendar='Date',
    #                                            date_col_base_dataframe='Week Start Date',
    #                                            holiday_calendar=pd.read_excel(
    #                                                io=sharepoint_path + r"/03. Feature Engineering/02. Codes/Modelling AD Folder/US Holiday Calendar Exhaustive.xlsx",
    #                                                sheet_name="Sheet1",
    #                                                na_values=['#NA', '#N/A', '', ' ', 'na', 'NA']))
    #