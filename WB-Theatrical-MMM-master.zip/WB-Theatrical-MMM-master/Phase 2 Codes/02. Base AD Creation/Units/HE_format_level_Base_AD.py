# importing modules
from tqdm import tqdm
import pandas as pd
import numpy as np
import math
from datetime import timedelta
import sys
sys.path.insert(0, r"/home/sandeepsanyal/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/06. Miscellaneous")
import date_manipulations

def he_base_ad_creation(media, sharepoint_path, export_path_user=False):

    # importing relevant datasets
    # importing title list
    df = pd.read_excel(io=sharepoint_path+r"/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Title List.xlsx",
                sheet_name='Phase 2B 88 titles',
                na_values=['#NA','#N/A','',' ','na','NA'])
    df = df[['IMDB Title Code',
             'IMDB Title Name',
             'Theatrical Release Date',
             media+' Release Date']].dropna(subset=[media+' Release Date']).drop([media+' Release Date'],
                                                                                 axis=1)
    # list of all titles
    titles = df['IMDB Title Code'].tolist()  # selecting list of title IDs
    # Weekly HE sales data
    Weekly_HE_sales = pd.read_excel(
            io=sharepoint_path + r"WB_Weekly_HE_Revenue_v4.0.xlsx",
            sheet_name='Sheet1',    # Contains Title-Week level Blu-ray & DVD, EST, iVOD & cVOD Revenue
            na_values=['#NA','#N/A','',' ','na','NA'])
    Weekly_HE_sales.dropna(
            subset=['Revenue',
                    'Units'],
            inplace=True)
    Weekly_HE_sales = Weekly_HE_sales.loc[Weekly_HE_sales['IMDB Title Code'].isin(titles), :].reset_index(drop=True)
    if media in ['EST', 'iVOD', 'VOD']:
        Weekly_HE_sales = Weekly_HE_sales.loc[Weekly_HE_sales['Media Type']==media,:].drop(['Theatrical Release Date'], axis=1)
    else:
        if media == 'PST':
            Weekly_HE_sales = Weekly_HE_sales.loc[((Weekly_HE_sales['Media Type'] == 'Blu-ray') &
                                                   (Weekly_HE_sales['Media SubType'] == 'Sell-Thru')) |
                                                  ((Weekly_HE_sales['Media Type'] == 'DVD') &
                                                   (Weekly_HE_sales['Media SubType'] == 'Sell-Thru')), :].drop('Theatrical Release Date', axis=1)
            Weekly_HE_sales = Weekly_HE_sales.groupby(['IMDB Title Code',
                                                       'Global Title Description',
                                                       'Studio',
                                                       'Week']).agg({'Street Date':'min',
                                                                     'Revenue':'sum',
                                                                     'Units':'sum'}).reset_index()
            Weekly_HE_sales['Media Type'] = 'PST'


    # correcting date columns
    df['Theatrical Release Date'] = pd.to_datetime(
        arg=df['Theatrical Release Date'],
        format="%Y-%m-%d",
        errors="coerce")
    Weekly_HE_sales['Street Date'] = pd.to_datetime(
        arg=Weekly_HE_sales['Street Date'],
        format="%Y-%m-%d",
        errors="coerce")

    # fixing Street Dates
    Weekly_HE_sales_temp = pd.DataFrame({})
    for id in tqdm(Weekly_HE_sales['IMDB Title Code'].unique().tolist()):
        temp = Weekly_HE_sales.loc[Weekly_HE_sales['IMDB Title Code']==id,:]
        for studio in temp['Studio'].unique().tolist():
            temp = temp.loc[temp['Studio']==studio,:]
            for dt in temp['Street Date'].unique():
                temp = temp.loc[temp['Street Date']==dt,:]
                min_wk = int(temp['Week'].min())
                for i in temp.index:
                    temp.loc[i, 'Street Date'] = temp.loc[i, 'Street Date'] + timedelta(days=min_wk * 7)
                    temp.loc[i,'Week'] = temp.loc[i,'Week'] - min_wk
                del i
                Weekly_HE_sales_temp = pd.concat([Weekly_HE_sales_temp,
                                                  temp],
                                                 axis=0)
    Weekly_HE_sales = Weekly_HE_sales_temp.copy()
    del Weekly_HE_sales_temp



    # getting Week Start dates in all files (Sunday date)
    df = date_manipulations.last_sunday(df=df,
                                        date_column_name='Theatrical Release Date',
                                        sunday_date_column_name='Theatrical Week Start Sunday')
    Weekly_HE_sales = date_manipulations.last_sunday(df=Weekly_HE_sales,
                                                     date_column_name='Street Date',
                                                     sunday_date_column_name=media+' Week Start Sunday')

    # creating list of all IMDB_Title_Codes & their Theatrical, EST & PST Release Dates
    all_titles = df[['IMDB Title Code', 'Theatrical Week Start Sunday']]
    all_titles[media+'_Street_Date'] = np.NaN
    for i in all_titles['IMDB Title Code'].unique().tolist():
        all_titles.loc[all_titles['IMDB Title Code'] == i, media+'_Street_Date'] = Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB Title Code'] == i) &
                                                                                                       (Weekly_HE_sales['Media Type'] == media), media+' Week Start Sunday'].min()
    del i
    all_titles[media+'_Street_Date'] = pd.to_datetime(
            arg=all_titles[media+'_Street_Date'],
            format="%Y-%m-%d",
            errors="coerce")
    # calculating Week number for EST & PST Release dates
    all_titles[media+'_Week_Start'] = np.nan
    for i in all_titles['IMDB Title Code'].unique():
        if pd.isnull(all_titles.loc[all_titles['IMDB Title Code'] == i, media+'_Week_Start'].values[0]):
            all_titles.loc[all_titles['IMDB Title Code'] == i, media+'_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB Title Code'] == i, 'Theatrical Week Start Sunday'] - all_titles.loc[all_titles['IMDB Title Code'] == i, media+'_Street_Date']) / pd.offsets.Day(-1)) / 7)
    del i

    Weekly_HE_sales = pd.merge(left=Weekly_HE_sales,
                               right=df[['IMDB Title Code', 'Theatrical Week Start Sunday']],
                               how='left',
                               left_on='IMDB Title Code',
                               right_on='IMDB Title Code')
    Weekly_HE_sales['TH Week Number'] = np.floor(((Weekly_HE_sales['Theatrical Week Start Sunday'] - Weekly_HE_sales[media+' Week Start Sunday']) / pd.offsets.Day(-1)) / 7) + Weekly_HE_sales['Week']

    # updating list of all IMDB_Title_Codes & their Theatrical, EST & PST Release Dates with last week number
    all_titles[media+'_Week_Ends'] = np.NaN
    for i in all_titles['IMDB Title Code'].unique():
        if math.isnan(all_titles.loc[all_titles['IMDB Title Code'] == i, media+'_Week_Start']) != True:
            all_titles.loc[all_titles['IMDB Title Code'] == i, media+'_Week_Ends'] = max(Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB Title Code'] == i) &
                                                                                                                    (Weekly_HE_sales['Media Type'] == media), 'TH Week Number'].dropna())

    # creating the master_AD
    # creating a dataframe of IMDB Title Codes and Week ranges for each IMDB Title Codes
    unique_week = pd.DataFrame({'IMDB Title Code': [],
                                'TH Week Number': [],
                                media+' Week Number': []})
    activity_range = pd.DataFrame({'IMDB Title Code': all_titles['IMDB Title Code'].tolist(),
                                   'Oldest Week': np.nanmin(all_titles.loc[:, all_titles.loc[:, all_titles.dtypes == np.float64].columns.values],
                                                            axis=1).tolist(),
                                   'Latest Week': np.nanmax(all_titles.loc[:, all_titles.loc[:, all_titles.dtypes == np.float64].columns.values],
                                                            axis=1).tolist()})
    activity_range['Week Length'] = (activity_range['Latest Week'] - activity_range['Oldest Week']) + 1
    activity_range.dropna(subset=['Oldest Week', 'Latest Week', 'Week Length'],
                          inplace=True)

    for i in activity_range['IMDB Title Code']:
        temp = pd.DataFrame(
            {'IMDB Title Code': [i] * int(activity_range.loc[activity_range['IMDB Title Code'] == i, 'Week Length']),
             'TH Week Number': range(int(activity_range.loc[activity_range['IMDB Title Code'] == i, 'Oldest Week']),
                                     int(activity_range.loc[activity_range['IMDB Title Code'] == i, 'Latest Week']) + 1)})
        temp[media+' Week Number'] = temp['TH Week Number'] - temp['TH Week Number'].min()
        unique_week = unique_week.append(temp, sort=True)
        del temp
    del i
    unique_week.reset_index(drop=True, inplace=True)
    del activity_range


    # merging Theater Release Date with unique_week dataset
    master_AD = pd.merge(left=unique_week,
                         right=all_titles[['IMDB Title Code',
                                           'Theatrical Week Start Sunday']],
                         how='left',
                         left_on='IMDB Title Code',
                         right_on='IMDB Title Code',
                         sort=True,
                         copy=False)
    del unique_week

    # merging HE Revenue for weeks present
    Weekly_HE_sales = pd.pivot_table(data=Weekly_HE_sales[['IMDB Title Code',
                                                           'Media Type',
                                                           'TH Week Number',
                                                           'Units']],
                                     index=['IMDB Title Code',
                                            'TH Week Number'],
                                     columns=['Media Type'],
                                     values=['Units'],
                                     aggfunc=np.unique).reset_index()
    Weekly_HE_sales.columns = ['IMDB Title Code',
                               'TH Week Number',
                               media+' Units']
    master_AD = pd.merge(left=master_AD,
                         right=Weekly_HE_sales,
                         how='left',
                         left_on=['IMDB Title Code', 'TH Week Number'],
                         right_on=['IMDB Title Code', 'TH Week Number'],
                         sort=True,
                         copy=False)

    # adding Week Start Date
    for i in master_AD.index:
        master_AD.loc[i, 'Week Start Date'] = master_AD.loc[i, 'Theatrical Week Start Sunday'] + timedelta(days=int(master_AD.loc[i, 'TH Week Number']) * 7)
    del i

    master_AD = pd.merge(left=master_AD,
                         right=df[['IMDB Title Code',
                                   'IMDB Title Name',
                                   'Theatrical Release Date']],
                         how='left',
                         left_on='IMDB Title Code',
                         right_on='IMDB Title Code',
                         sort=True,
                         copy=False)

    master_AD = master_AD[['IMDB Title Code',
                           'IMDB Title Name',
                           'Theatrical Release Date',
                           'Week Start Date',
                           'TH Week Number',
                           media+' Week Number',
                           media+' Units']]

    master_AD.drop_duplicates(inplace=True)

    # exporting dataset
    if export_path_user != False:
        with pd.ExcelWriter(
                path=export_path_user,
                mode='a',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY') as writer:
            master_AD.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name=media+' Base AD',
                engine='openpyxl')

