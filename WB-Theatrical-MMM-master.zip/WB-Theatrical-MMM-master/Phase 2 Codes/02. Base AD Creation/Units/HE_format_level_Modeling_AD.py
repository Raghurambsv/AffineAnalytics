# importing modules
import numpy as np
import pandas as pd
import sys
sys.path.insert(0, r"/home/sandeepsanyal/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/03. Feature Engineering")
from film_festivals import *
from franchise import *
from cast_rating import *
from holiday_metrics import *
from wm_data_features_phase2 import *
sys.path.insert(0, r"/home/sandeepsanyal/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/06. Miscellaneous")
from clubbing_weeks import *

def he_modeling_ad_creation(media, snapshot, sharepoint_path, export_path_user=False):

    # film festival
    modeling_ad = film_festival(df=pd.read_excel(io=sharepoint_path+r"WB_Base AD v1.0.xlsx",
                                                 sheet_name=media+' Base AD',
                                                 na_values=['#NA','#N/A','',' ','na','NA']).rename(columns={'IMDB Title Code':'IMDB_Title_Code',
                                                                                                            'Theatrical Release Date':'Theatrical_Release_Date'}),
                                film_festival_data=pd.read_excel(io=sharepoint_path+r"Film_Festival_88_Titles.xlsx",
                                                                 sheet_name="WB 88 Titles",
                                                                 na_values=['#NA','#N/A','',' ','na','NA']).rename(columns={'IMDB Title Code':'IMDB_Title_Code'}))
    modeling_ad = pd.merge(left=modeling_ad,
                           right=pd.read_excel(io=sharepoint_path+r"Distribution only flag.xlsx",
                                               sheet_name="Distribution only",
                                               na_values=['#NA','#N/A','',' ','na','NA']).rename(columns={'IMDB Title Code':'IMDB_Title_Code'})[['IMDB_Title_Code',
                                                                                                                                                 'Distribution_only']],
                           left_on='IMDB_Title_Code',
                           right_on='IMDB_Title_Code',
                           how='left')

    # franchise
    modeling_ad['Theatrical_Release_Year'] = modeling_ad['Theatrical_Release_Date'].dt.year
    modeling_ad = franchise_flag(baseAD=modeling_ad)
    modeling_ad = count_of_movies_in_franchise(df=modeling_ad, n_years=2)
    modeling_ad = count_of_movies_in_franchise(df=modeling_ad, n_years=3)
    modeling_ad = count_of_movies_in_franchise(df=modeling_ad, n_years=4)
    modeling_ad = last_release_duration(df=modeling_ad)
    modeling_ad = get_average_earnings(df=modeling_ad)

    # cast ratings
    modeling_ad = create_cast_rating(dataframe=modeling_ad,
                                     scrapped_info=pd.read_csv(sharepoint_path+r"IMDB_scrapped_titles_v5.csv"),
                                     actor_director='Actor')
    modeling_ad = create_cast_rating(dataframe=modeling_ad,
                                     scrapped_info=pd.read_csv(sharepoint_path+r"IMDB_scrapped_titles_v5.csv"),
                                     actor_director='Director')
    modeling_ad['cast_avg_rating'] = np.nanmean(modeling_ad[['actors_avg_rating','directors_avg_rating']],
                                                axis=1)

    # holiday metrics
    modeling_ad = holiday_flag(base_dataframe=modeling_ad,
                               date_col_calendar='Date',
                               date_col_base_dataframe='Week Start Date',
                               holiday_calendar=pd.read_excel(io=sharepoint_path+r"US Holiday Calendar Exhaustive.xlsx",
                                                              sheet_name="Sheet1",
                                                              na_values=['#NA','#N/A','',' ','na','NA']))
    modeling_ad = long_weekend_flag(base_dataframe=modeling_ad,
                                    date_col_calendar='Date',
                                    date_col_base_dataframe='Week Start Date',
                                    holiday_calendar=pd.read_excel(io=sharepoint_path+r"US Holiday Calendar Exhaustive.xlsx",
                                                                   sheet_name="Sheet1",
                                                                   na_values=['#NA','#N/A','',' ','na','NA']))

    # genre
    modeling_ad = pd.merge(left=modeling_ad,
                           right=pd.read_excel(io=sharepoint_path+r"Genre_Check.xlsx",
                                               sheet_name="Genre Check",
                                               na_values=['#NA','#N/A','',' ','na','NA'])[['IMDB_Title_Code',
                                                                                           'Mkt_Genre',
                                                                                           'Mkt_Genre_Grouped']],
                           how='left',
                           left_on='IMDB_Title_Code',
                           right_on='IMDB_Title_Code')

    # Estimated BO
    modeling_ad = pd.merge(left=modeling_ad,
                           right=pd.concat([pd.read_excel(io=sharepoint_path+r"Affine - WB - BO Model TH-30 Results_v1.5.xlsx",
                                                          sheet_name="Train Results",
                                                          header=3,
                                                          na_values=['#NA','#N/A','',' ','na','NA']).drop(['Unnamed: 0'], axis=1)[['IMDB Title Code',
                                                                                                                                   'Predictions']],
                                            pd.read_excel(io=sharepoint_path+r"Affine - WB - BO Model TH-30 Results_v1.5.xlsx",
                                                          sheet_name="Test Results",
                                                          header=3,
                                                          na_values=['#NA','#N/A','',' ','na','NA']).drop(['Unnamed: 0'], axis=1).loc[np.arange(0,7),['IMDB Title Code',
                                                                                                                                                      'Predictions']]],
                                           axis=0).rename(columns={'IMDB Title Code':'IMDB_Title_Code',
                                                                   'Predictions':'Estimated_BO_Revenue'}),
                           how='left',
                           left_on='IMDB_Title_Code',
                           right_on='IMDB_Title_Code')

    # opening weekend BO
    modeling_ad = pd.merge(left=modeling_ad,
                           right=pd.read_excel(io=sharepoint_path+r"BO Revenue v2.0.xlsx",
                                               sheet_name="Sheet1",
                                               na_values=['#NA','#N/A','',' ','na','NA'])[['IMDB Title Code',
                                                                                           'Opening Weekend Box Office']].rename(columns={'IMDB Title Code':'IMDB_Title_Code',
                                                                                                                                          'Opening Weekend Box Office':'Opening_Weekend_BO'}),
                           how='left',
                           left_on='IMDB_Title_Code',
                           right_on='IMDB_Title_Code')

    # competitor index
    modeling_ad = pd.merge(left=modeling_ad.rename(columns={'TH Week Number':'TH_Week_Number',
                                                            media+' Week Number':media+'_Week_Number'}),
                           right=pd.read_excel(io=sharepoint_path+r"Competitor Effect/WB Titles/Competitor Effect_"+media+"_13weeks.xlsx",
                                               sheet_name="Weekly Competitor Effect",
                                               na_values=['#NA','#N/A','',' ','na','NA'])[['IMDB Title Code',
                                                                                           'Week Number',
                                                                                           'Competitor Index']].rename(columns={'IMDB Title Code':'IMDB_Title_Code',
                                                                                                                                'Week Number':media+'_Week_Number',
                                                                                                                                'Competitor Index':'Competitor_Effect'}),
                           how='left',
                           left_on=['IMDB_Title_Code', media+'_Week_Number'],
                           right_on=['IMDB_Title_Code', media+'_Week_Number'])
    modeling_ad = pd.merge(left=modeling_ad,
                           right=modeling_ad.groupby(['IMDB_Title_Code']).agg({'Competitor_Effect': np.nanmean}).reset_index().rename(columns={'Competitor_Effect':'avg_competitor_effect'}),
                           how='left',
                           left_on='IMDB_Title_Code',
                           right_on='IMDB_Title_Code')

    # clubbing week0 and week1
    modeling_ad = units_clubbed(DataFrame=modeling_ad,
                                IMDB_Title_Code='IMDB_Title_Code',
                                revenue=media + ' Units',
                                weeks=media+'_Week_Number',
                                holiday='holiday_flag',
                                long_weekend='long_weekend_flag')

    # social media
    modeling_ad = social_media_metrics(base_ad=modeling_ad,
                                       social_media_data=pd.read_excel(io=sharepoint_path+r"Social Media Data.xlsx",
                                                                       sheet_name="Social Media Data",
                                                                       na_values=['#NA','#N/A','',' ','na','NA']).rename(columns={'IMDB Title Code':'IMDB_Title_Code',
                                                                                                                                  'IMDB Title Name':'IMDB_Title_Name',
                                                                                                                                  'Theatrical Release Date':'Theatrical_Release_Date',
                                                                                                                                  'Week Start Date':'Week_Start_Date',
                                                                                                                                  'Week Number':'TH_Week_Number',
                                                                                                                                  'Facebook Comments': 'Facebook_Comments',
                                                                                                                                  'Facebook Likes': 'Facebook_Likes',
                                                                                                                                  'Facebook Ptat': 'Facebook_Ptat',
                                                                                                                                  'Facebook Shares': 'Facebook_Shares',
                                                                                                                                  'Facebook Videos': 'Facebook_Videos',
                                                                                                                                  'Facebook Views': 'Facebook_Views',
                                                                                                                                  'Twitter Views': 'Twitter_Views',
                                                                                                                                  'YouTube Comments': 'YouTube_Comments',
                                                                                                                                  'YouTube Likes': 'YouTube_Likes',
                                                                                                                                  'YouTube Dislikes': 'YouTube_Dislikes',
                                                                                                                                  'YouTube Videos': 'YouTube_Videos',
                                                                                                                                  'YouTube Views': 'YouTube_Views',
                                                                                                                                  'YouTube Sentiment': 'YouTube_Sentiment',
                                                                                                                                  'Google Search Volume': 'Google_Search_Volume',
                                                                                                                                  'Wikipedia Page Views': 'Wikipedia_Page_Views'}),
                                       snapshot=snapshot,
                                       week_number_colname='TH_Week_Number',
                                       revenue_colname=media + ' Units')

    # exporting dataset
    with pd.ExcelWriter(
            path=export_path_user,
            mode='a',
            date_format='YYYY-MM-DD',
            datetime_format='DD-MMM-YYYY') as writer:
        modeling_ad.to_excel(
            excel_writer=writer,
            index=False,
            sheet_name=media+'_TH'+ ['+' + str(snapshot-1) if len(str(snapshot-1))==1 else str(snapshot-1)][0] +' week(s)',
            engine='openpyxl')

