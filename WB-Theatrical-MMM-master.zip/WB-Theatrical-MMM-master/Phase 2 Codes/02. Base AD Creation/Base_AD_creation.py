
def base_ad_creation(sharepoint_path, export_path_user=False):

    """
    This function takes in a user provided dataframe containing unique IMDB Title Codes and their Theater Release Dates and returns a dataframe in a title-week level for which there are sales and(or) spends activity

    Parameters
    ----------
    sharepoint_path: String
        The root location where you are syncing WB Theatrical sharedrive
    export_path: String
        The root location where you are syncing WB Theatrical sharedrive
    Returns
    -------
        A dataframe in a title-week level for which there are sales, spends and social media activity along with holiday flag
    """

    # importing modules
    import pandas as pd
    from datetime import timedelta
    import sys
    sys.path.insert(0, r"C:/Users/sande/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/06. Miscellaneous")
    import holiday_flag
    import date_manipulations
    sys.path.insert(0, r"C:/Users/sande/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/02. Base AD Creation")
    import Weekly_Spends_and_Revenue
    import Weekly_Social_Media_Data

    # importing dataset
    # sales & spends dataset
    salesNspends_data = Weekly_Spends_and_Revenue.weekly_sales_spends_activity(
        df = pd.read_excel(
            io=sharepoint_path+r"\WB Theatrical - Documents\01. Data Harmonization-Cleaning\03. Analytical Datasets\Title List.xlsx",
            sheet_name='Phase 2B 88 titles',
            na_values=['#NA','#N/A','',' ','na','NA'])[['IMDB Title Code',
                                                        'IMDB Title Name',
                                                        'Theatrical Release Date']],
        sharepoint_path=sharepoint_path,
        export_path=False)
    # social media dataset
    social_media_data = Weekly_Social_Media_Data.weekly_social_media_activity(
        df=pd.read_excel(
                io=sharepoint_path+r"/WB Theatrical - Documents/01. Data Harmonization-Cleaning/03. Analytical Datasets/Title List.xlsx",
                sheet_name='Phase 2B 88 titles',
                na_values=['#NA','#N/A','',' ','na','NA'])[['IMDB Title Code',
                                                            'IMDB Title Name',
                                                            'Theatrical Release Date']],
        sharepoint_path=sharepoint_path,
        export_path=False)

    # creating base_ad
    all_titles = pd.read_excel(
        io=sharepoint_path+r"/WB Theatrical - Documents/01. Data Harmonization-Cleaning/03. Analytical Datasets/Title List.xlsx",
        sheet_name='Phase 2B 88 titles',
        na_values=['#NA','#N/A','',' ','na','NA'])[['IMDB Title Code',
                                                    'IMDB Title Name',
                                                    'Theatrical Release Date']]

    for title in all_titles['IMDB Title Code'].unique().tolist():
        all_titles.loc[all_titles['IMDB Title Code']==title,'Oldest Week'] = min(salesNspends_data.loc[salesNspends_data['IMDB Title Code'] == title, 'Week Number'].tolist() + social_media_data.loc[social_media_data['IMDB Title Code'] == title, 'Week Number'].tolist())
        all_titles.loc[all_titles['IMDB Title Code']==title,'Latest Week'] = max(salesNspends_data.loc[salesNspends_data['IMDB Title Code'] == title, 'Week Number'].tolist() + social_media_data.loc[social_media_data['IMDB Title Code'] == title, 'Week Number'].tolist())
    all_titles['Week Length'] = (all_titles['Latest Week'] - all_titles['Oldest Week'])+1

    unique_week = pd.DataFrame({'IMDB Title Code': [],
                                'IMDB Title Name': [],
                                'Theatrical Release Date': [],
                                'Week Number': []})
    for i in all_titles['IMDB Title Code'].tolist():
        temp = pd.DataFrame(
            {'IMDB Title Code': [i] * int(all_titles.loc[all_titles['IMDB Title Code'] == i, 'Week Length']),
             'IMDB Title Name': all_titles.loc[all_titles['IMDB Title Code']==i, 'IMDB Title Name'].tolist() * int(all_titles.loc[all_titles['IMDB Title Code'] == i, 'Week Length']),
             'Theatrical Release Date': all_titles.loc[all_titles['IMDB Title Code']==i, 'Theatrical Release Date'].tolist() * int(all_titles.loc[all_titles['IMDB Title Code'] == i, 'Week Length']),
             'Week Number': range(int(all_titles.loc[all_titles['IMDB Title Code'] == i, 'Oldest Week']),
                                  int(all_titles.loc[all_titles['IMDB Title Code'] == i, 'Latest Week']) + 1)})
        unique_week = unique_week.append(temp, sort=True)
        del temp
    del i
    unique_week.reset_index(drop=True, inplace=True)
    del all_titles
    unique_week = date_manipulations.last_sunday(df=unique_week,
                                                 date_column_name='Theatrical Release Date',
                                                 sunday_date_column_name='Theatrical Week Start Sunday')
    # adding Week Start Date
    for i in unique_week.index:
        unique_week.loc[i, 'Week Start Date'] = unique_week.loc[i, 'Theatrical Week Start Sunday'] + timedelta(days=int(unique_week.loc[i, 'Week Number']) * 7)
    del i

    # merging sales & spends data with social media data
    base_ad = pd.merge(left=unique_week.drop(['Theatrical Week Start Sunday'],axis=1),
                       right=salesNspends_data,
                       how='left',
                       left_on=['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', 'Week Number', 'Week Start Date'],
                       right_on=['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', 'Week Number', 'Week Start Date'])
    del unique_week
    base_ad = pd.merge(left=base_ad,
                       right=social_media_data,
                       how='left',
                       left_on=['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', 'Week Number', 'Week Start Date'],
                       right_on=['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', 'Week Number', 'Week Start Date'])
    # flagging holidays
    base_ad = holiday_flag.holiday_flag(
        df=base_ad,
        holiday_df=pd.read_excel(
            io=sharepoint_path+r"\WB Theatrical - Documents\01. Data Harmonization-Cleaning\03. Analytical Datasets\US Holiday Calendar Exhaustive.xlsx",
            sheet_name='Sheet1',
            na_values=['#NA', '#N/A', '', ' ', 'na', 'NA']))

    # exporting dataset
    if export_path_user!=False:
        with pd.ExcelWriter(
                path=export_path_user,
                mode='w',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY') as writer:
            base_ad.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name='Base AD',
                engine='openpyxl')

    print("Base AD created")
