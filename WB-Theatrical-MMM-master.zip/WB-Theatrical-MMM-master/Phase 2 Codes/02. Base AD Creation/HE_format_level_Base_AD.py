# importing modules
import pandas as pd
import sys

def he_base_ad_creation(
        root_folder: str,
        sharepoint_path: str,
        studio: str,
        sale: str,
        media: str,
        export_path_user: str = False
) -> pd.core.frame.DataFrame:
    """
    Creates HE Base AD for a given Studio, Sale type and Format

    Parameters
    ----------
    root_folder : string
        Home folder containing codes after a github pull
    sharepoint_path : string
        Home folder for shared drive
    studio : str
        Options: "WB" or "NonWB
        For which title AD needs to be created
    sale: string,
        Options: "Revenue" or "Units"
        For which sale type AD needs to be created
    media: string,
        Options: "EST", "iVOD", "VOD", "PST"
        For which format AD needs to be created
    export_path_user: string
        Default: Nothing will be exported
        If a excel file is required for export, enter full path

    Returns
    -------
    A DataFrame
        HE Base AD
    """

    # importing user defined functions
    sys.path.insert(0, root_folder + r"/Phase 2 Codes/03. Feature Engineering")
    import movie_timeline
    sys.path.insert(0, root_folder + r"/Phase 2 Codes/06. Miscellaneous")
    import date_manipulations

    # window calculation
    Weekly_HE_sales, all_titles = movie_timeline.window_calculation(
        root_folder=root_folder,
        sharepoint_path=sharepoint_path,
        title_list_file=pd.read_excel(
                io=sharepoint_path+r"/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Title List.xlsx",
                sheet_name=studio+' Titles',
                usecols=[
                    "IMDB Title Code",
                    "IMDB Title Name",
                    "Studio",
                    'Theatrical Release Date'
                ],
                na_values=['#NA', '#N/A', '', ' ', 'na', 'NA']
        )
    )

    # subset by Electronic / Physical media data
    if media in ['EST', 'iVOD', 'VOD']:
        Weekly_HE_sales = Weekly_HE_sales.loc[Weekly_HE_sales['Media Type'] == media,:]
    else:
        if media == 'PST':
            Weekly_HE_sales = Weekly_HE_sales.loc[
                              (
                                      (Weekly_HE_sales['Media Type'] == 'Blu-ray') &
                                      (Weekly_HE_sales['Media SubType'] == 'Sell-Thru')
                              ) |
                              (
                                      (Weekly_HE_sales['Media Type'] == 'DVD') &
                                      (Weekly_HE_sales['Media SubType'] == 'Sell-Thru')
                              ), :
                              ]
            Weekly_HE_sales['Media Type'] = 'PST'

    Weekly_HE_sales = pd.merge(
        left=Weekly_HE_sales.drop(
            [
                'Media SubType',
                'Theatrical Week Start Sunday',
                'Street Date'
            ],
            axis=1
        ),
        right=all_titles[
            [
                'IMDB Title Code',
                'Theatrical Release Date',
                media+' Release Date',
                "Studio"
            ]
        ],
        how='left',
        left_on="IMDB Title Code",
        right_on="IMDB Title Code"
    )

    Weekly_HE_sales[media+' Week Number'] = (
            (
                    (
                            date_manipulations.last_sunday(
                                df=Weekly_HE_sales,
                                date_column_name=media + " Release Date",
                                sunday_date_column_name='Sunday Date'
                            )['Sunday Date'] -
                            Weekly_HE_sales['Week Start Date']
                    ) / pd.offsets.Day(-1)
            ) / 7
                                            ) - 1

    Weekly_HE_sales = Weekly_HE_sales[
        [
            'IMDB Title Code',
            'IMDB Title Name',
            'Studio',
            'Theatrical Release Date',
            media + ' Release Date',
            'Week Start Date',
            'Theatrical Week Number',
            media + ' Week Number',
            ''+sale+''
        ]
    ].rename(
        columns={
            ''+sale+'': media+" "+sale
        }
    )

    Weekly_HE_sales.drop_duplicates(inplace=True)

    # adding Windows
    Weekly_HE_sales = pd.merge(
        left=Weekly_HE_sales,
        right=all_titles.loc[
              :,
              ["IMDB Title Code"] + [
                  item for item in all_titles.columns.values.tolist()
                  if
                  media in item and
                  "Window" in item
              ]
        ],
        how="left",
        left_on="IMDB Title Code",
        right_on = "IMDB Title Code"
    )


    # exporting dataset
    if export_path_user != False:
        with pd.ExcelWriter(
                path=export_path_user,
                engine='openpyxl',
                mode='w',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY') as writer:
            Weekly_HE_sales.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name=media+' Base AD'+sale
            )

    print(media + " " + sale + " Base AD created")

    return Weekly_HE_sales
