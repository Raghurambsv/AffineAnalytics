# importing modules
import pandas as pd
import numpy as np
import math
from datetime import timedelta
import sys
from tqdm import tqdm

# reading list of titles for which to create Base AD
df = pd.read_excel(
    io=r"C:/Users/sande/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Title List.xlsx",
    sheet_name="WB Titles",
    usecols=[
        "IMDB Title Code",
        "IMDB Title Name",
        "Theatrical Release Date"
    ]
)
# helping python to understand the date format for column "Theatrical Release Date"
df['Theatrical Release Date'] = pd.to_datetime(
    arg=df['Theatrical Release Date'],
    format="%Y-%m-%d",
    errors="coerce"
)

# selecting titles that were released after 2015
df = df.loc[df['Theatrical Release Date'].dt.year >= 2015,:]

root_folder = r"C:/Users/sande/PycharmProjects/WB-Theatrical-MMM"
sharepoint_path = r"C:/Users/sande/Affine Analytics Pvt Ltd/WB Theatrical - Documents"
export_path = r"C:/Users/sande/OneDrive/Desktop/Base AD_v1.0.xlsx"


def weekly_sales_spends_activity(df, root_folder, sharepoint_path, export_path=False):

    """
    This function takes in a user provided dataframe containing unique IMDB Title Codes and their Theater Release Dates and returns a dataframe in a title-week level for which there are sales and(or) spends activity

    Parameters
    ----------
    df: Pandas Dataframe
         A dataframe having the following columns:
            IMDB Title Code
            Theatrical Release Date
    root_folder: String
        The root location where you are syncing your WB Theatrical github repository
    sharepoint_path: String
        The root location where you are syncing WB Theatrical sharedrive
    Returns
    -------
        A dataframe in a title-week level for which there are sales and(or) spends activity
    """

    sys.path.insert(0, root_folder+r"/Phase 2 Codes/06. Miscellaneous")
    import date_manipulations

    # importing  relevant datasets
    # list of all titles
    titles = df['IMDB Title Code'].tolist()  # selecting list of title IDs

    # Weekly BO Sales
    Weekly_BO_sales = pd.read_excel(
        io=sharepoint_path + r"/01. Data Harmonization-Cleaning/02. Cleaned Data/01. Sales Data/WB_Weekly_BO_Revenue_v2.0.xlsx",
        sheet_name='Sheet1',    # Contains Title-Week level BO Revenue,
        na_values=['#NA','#N/A','',' ','na','NA']
    )
    Weekly_BO_sales[['Box Office']] = Weekly_BO_sales[['Box Office']].applymap(
        lambda x: np.nan if x <= 0 else x
    )
    Weekly_BO_sales.dropna(
        subset=['Box Office'],
        inplace=True
    )
    # Weekly HE Sales
    Weekly_HE_sales = pd.read_excel(
        io=sharepoint_path + r"/01. Data Harmonization-Cleaning/02. Cleaned Data/01. Sales Data/WB_Weekly_HE_Revenue_v6.0.xlsx",
        sheet_name='Sheet1',    # Contains Title-Week level Blu-ray & DVD, EST, iVOD & cVOD Revenue
        na_values=['#NA','#N/A','',' ','na','NA'])
    Weekly_HE_sales[['Revenue', 'Units']] = Weekly_HE_sales[['Revenue', 'Units']].applymap(
        lambda x: np.nan if x <= 0 else x
    )
    Weekly_HE_sales.dropna(
        subset=['Revenue', 'Units'],
        inplace=True
    )
    # Weekly BO Spends
    Weekly_BO_spends = pd.read_excel(
        io=sharepoint_path + r"/01. Data Harmonization-Cleaning/02. Cleaned Data/02. Spend Data/6. Spends 2019-02-05/Reallocated Spends data - v7.xlsx",
        sheet_name='BO - Redistributed Spends',  # Contains Title-Division-Channel-Week level BO & HE Spends
        na_values=['#NA','#N/A','',' ','na','NA'],
        header=3
    ).drop(
        ['Unnamed: 0'],
        axis=1
    )
    # Weekly HE Spends
    Weekly_HE_spends = pd.read_excel(
        io=sharepoint_path + r"/01. Data Harmonization-Cleaning/02. Cleaned Data/02. Spend Data/6. Spends 2019-02-05/Reallocated Spends data - v7.xlsx",
        sheet_name='HE - Redistributed Spends',  # Contains Title-Division-Channel-Week level BO & HE Spends
        na_values=['#NA', '#N/A', '', ' ', 'na', 'NA'],
        header=3
    ).drop(
        ['Unnamed: 0'],
        axis=1
    )
    # Weekly Spends
    Weekly_spends = pd.merge(
        left=Weekly_BO_spends.drop('TITLE',
                                   axis=1
                                   ).rename(
            columns={
                'TITLE ID':'IMDB Title Code',
                'TH WEEK NO':'TH Week Number',
                'DIGITAL':'BO Digital Spend',
                'DIGITAL VIDEO':'BO Digital Video Spend',
                'TOTAL LINEAR':'BO Total Linear Spend',
                'TOTAL RADIO':'BO Total Radio Spend',
                'OUTDOOR_PRINT':'BO Outdoor/Print Spend',
                'OOH - EXPERIENTIAL':'BO OOH-Experiential Spend'
            }
        ),
        right=Weekly_HE_spends[
            [
                'TITLE ID',
                'TH WEEK NO',
                'DIGITAL',
                'DIGITAL VIDEO',
                'NON-DIGITAL',
                'LINEAR CO-OP'
            ]
        ].rename(
            columns={
                'TITLE ID': 'IMDB Title Code',
                'TH WEEK NO': 'TH Week Number',
                'DIGITAL':'HE Digital Spend',
                'DIGITAL VIDEO': 'HE Digital Video Spend',
                'NON-DIGITAL': 'HE Non-Digital Spend',
                'LINEAR CO-OP': 'HE Linear Co-op Spend'}),
        how='outer',
        left_on=['IMDB Title Code', 'TH Week Number'],
        right_on=['IMDB Title Code', 'TH Week Number']
    )
    del Weekly_BO_spends, Weekly_HE_spends
    Weekly_spends.sort_values(
        by=['IMDB Title Code', 'TH Week Number'],
        axis=0,
        ascending=True,
        inplace=True
    )
    Weekly_spends[[
        'BO Digital Spend',
        'BO Digital Video Spend',
        'BO Total Linear Spend',
        'BO Total Radio Spend',
        'BO Outdoor/Print Spend',
        'BO OOH-Experiential Spend',
        'HE Digital Spend',
        'HE Digital Video Spend',
        'HE Non-Digital Spend',
        'HE Linear Co-op Spend'
    ]] = Weekly_spends[[
        'BO Digital Spend',
        'BO Digital Video Spend',
        'BO Total Linear Spend',
        'BO Total Radio Spend',
        'BO Outdoor/Print Spend',
        'BO OOH-Experiential Spend',
        'HE Digital Spend',
        'HE Digital Video Spend',
        'HE Non-Digital Spend',
        'HE Linear Co-op Spend'
    ]].applymap(
        lambda x: np.nan if x <= 0 else x
    )

    # subsetting datasets
    Weekly_BO_sales = Weekly_BO_sales.loc[Weekly_BO_sales['IMDB Title Code'].isin(titles), :].reset_index(drop=True)
    Weekly_HE_sales = Weekly_HE_sales.loc[Weekly_HE_sales['IMDB Title Code'].isin(titles), :].reset_index(drop=True)
    Weekly_spends = Weekly_spends.loc[Weekly_spends['IMDB Title Code'].isin(titles), :].reset_index(drop=True)

    # correcting date columns
    df['Theatrical Release Date'] = pd.to_datetime(
        arg=df['Theatrical Release Date'],
        format="%Y-%m-%d",
        errors="coerce")
    Weekly_HE_sales['Street Date'] = pd.to_datetime(
        arg=Weekly_HE_sales['Street Date'],
        format="%Y-%m-%d",
        errors="coerce")
    Weekly_BO_sales['Week Begin'] = pd.to_datetime(
        arg=Weekly_BO_sales['Week Begin'],
        format="%Y-%m-%d",
        errors="coerce")
    Weekly_BO_sales['Week End'] = pd.to_datetime(
        arg=Weekly_BO_sales['Week End'],
        format="%Y-%m-%d",
        errors="coerce")

    # getting Week Start dates in all files (Sunday date)
    df = date_manipulations.last_sunday(df=df,
                                        date_column_name='Theatrical Release Date',
                                        sunday_date_column_name='Theatrical Week Start Sunday')
    Weekly_BO_sales = date_manipulations.last_sunday(df=Weekly_BO_sales,
                                                     date_column_name='Week Begin',
                                                     sunday_date_column_name='Week Start Date')
    Weekly_HE_sales = date_manipulations.last_sunday(df=Weekly_HE_sales,
                                                     date_column_name='Street Date',
                                                     sunday_date_column_name='Week Start Date')

    Weekly_HE_sales = pd.merge(left=Weekly_HE_sales,
                               right=df[['IMDB Title Code',
                                         'Theatrical Week Start Sunday']],
                               how='left',
                               left_on='IMDB Title Code',
                               right_on='IMDB Title Code')
    Weekly_HE_sales['TH Week Number'] = np.floor(((Weekly_HE_sales['Theatrical Week Start Sunday'] - Weekly_HE_sales['Week Start Date']) / pd.offsets.Day(-1)) / 7) + Weekly_HE_sales['Week']

    for i in tqdm(Weekly_HE_sales.index):
        Weekly_HE_sales.loc[i, 'Week Start Date'] = Weekly_HE_sales.loc[i, 'Theatrical Week Start Sunday'] + timedelta(days=int(Weekly_HE_sales.loc[i, 'TH Week Number']) * 7)
    del i

    # fixing double studio issues
    for id in tqdm(Weekly_HE_sales['IMDB Title Code'].unique()):
        temp = Weekly_HE_sales.loc[Weekly_HE_sales['IMDB Title Code'] == id, :]
        for format in temp['Media Type'].unique():
            temp1 = temp.loc[temp['Media Type'] == format, :]
            for subformat in temp1['Media SubType'].unique():
                temp2 = temp1.loc[temp1['Media SubType'] == subformat, :]
                if len(temp2['Studio'].unique()) > 1:
                    if temp2['Studio'].str.contains('WARNER').sum() > 0:
                        Weekly_HE_sales.drop(index=temp2.loc[temp2['Studio'] != 'WARNER'].index.values,
                                             axis=0,
                                             inplace=True)
                    else:
                        gp_data = temp2.groupby(['IMDB Title Code',
                                                'Studio',
                                                'Street Date']).agg({'Revenue': 'sum',
                                                                     'Units': 'sum'}).reset_index()
                        if len(gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].unique()) == 2:
                            Weekly_HE_sales.drop(index=temp2.loc[temp2['Studio'] == 'ALL OTHERS'].index.values,
                                                 axis=0,
                                                 inplace=True)
                        elif len(gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].unique()) == 1:
                            Weekly_HE_sales.drop(
                                index=Weekly_HE_sales.loc[
                                          (Weekly_HE_sales['IMDB Title Code'] == id) &
                                          (Weekly_HE_sales['Studio'] == (gp_data.loc[
                                                                             gp_data['Revenue'] != max(gp_data['Revenue']),
                                                                             'Studio'
                                                                         ].values)[0]), :
                                      ].index.values,
                                axis=0,
                                inplace=True
                            )
    # fixing same studio, double release date issues
    Weekly_HE_sales = Weekly_HE_sales.groupby(
        [
            'IMDB Title Code',
            'Media Type',
            'Media SubType',
            'Studio',
            'Week Start Date',
            'Theatrical Week Start Sunday',
            'TH Week Number'
        ]
    ).agg(
        {
            'Street Date': np.min,
            'Revenue': np.sum,
            'Units': np.sum
        }
    ).reset_index(drop=False)

    # fixing Street Dates
    Weekly_HE_sales_temp = pd.DataFrame({})
    for id in tqdm(Weekly_HE_sales['IMDB Title Code'].unique().tolist()):
        temp = Weekly_HE_sales.loc[Weekly_HE_sales['IMDB Title Code'] == id, :]
        for dt in temp['Street Date'].unique():
            temp1 = temp.loc[temp['Street Date'] == dt, :]
            min_wk = temp1['Week Start Date'].min()
            for i in temp1.index:
                temp1.loc[i, 'Street Date'] = min_wk
                del i
            Weekly_HE_sales_temp = pd.concat([Weekly_HE_sales_temp,
                                              temp1],
                                             axis=0)
            del temp1
        del dt, temp
    del id
    Weekly_HE_sales = Weekly_HE_sales_temp.copy()
    del Weekly_HE_sales_temp

    # creating list of all IMDB_Title_Codes & their Theatrical, EST & PST Release Dates
    all_titles = df[['IMDB Title Code', 'Theatrical Week Start Sunday']]

    all_titles['DVD_Rental_Street_Date'] = np.NaN
    all_titles['DVD_Sell-Thru_Street_Date'] = np.NaN
    all_titles['Blu-ray_Rental_Street_Date'] = np.NaN
    all_titles['Blu-ray_Sell-Thru_Street_Date'] = np.NaN
    all_titles['EST_Sell-Thru_Street_Date'] = np.NaN
    all_titles['iVOD_Rental_Street_Date'] = np.NaN
    all_titles['VOD_Rental_Street_Date'] = np.NaN
    for i in tqdm(all_titles['IMDB Title Code'].unique()):
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'DVD_Rental_Street_Date'] = Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB Title Code'] == i) &
                                                                                                           (Weekly_HE_sales['Media Type'] == 'DVD') &
                                                                                                           (Weekly_HE_sales['Media SubType'] == 'Rental'), 'Week Start Date'].min()
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'DVD_Sell-Thru_Street_Date'] = Weekly_HE_sales.loc[
            (Weekly_HE_sales['IMDB Title Code'] == i) &
            (Weekly_HE_sales['Media Type'] == 'DVD') &
            (Weekly_HE_sales['Media SubType'] == 'Sell-Thru'), 'Week Start Date'].min()
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'Blu-ray_Rental_Street_Date'] = Weekly_HE_sales.loc[
            (Weekly_HE_sales['IMDB Title Code'] == i) &
            (Weekly_HE_sales['Media Type'] == 'Blu-ray') &
            (Weekly_HE_sales['Media SubType'] == 'Rental'), 'Week Start Date'].min()
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'Blu-ray_Sell-Thru_Street_Date'] = Weekly_HE_sales.loc[
            (Weekly_HE_sales['IMDB Title Code'] == i) &
            (Weekly_HE_sales['Media Type'] == 'Blu-ray') &
            (Weekly_HE_sales['Media SubType'] == 'Sell-Thru'), 'Week Start Date'].min()
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'EST_Sell-Thru_Street_Date'] = Weekly_HE_sales.loc[
            (Weekly_HE_sales['IMDB Title Code'] == i) &
            (Weekly_HE_sales['Media Type'] == 'EST') &
            (Weekly_HE_sales['Media SubType'] == 'Sell-Thru'), 'Week Start Date'].min()
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'iVOD_Rental_Street_Date'] = Weekly_HE_sales.loc[
            (Weekly_HE_sales['IMDB Title Code'] == i) &
            (Weekly_HE_sales['Media Type'] == 'iVOD') &
            (Weekly_HE_sales['Media SubType'] == 'Rental'), 'Week Start Date'].min()
        all_titles.loc[all_titles['IMDB Title Code'] == i, 'VOD_Rental_Street_Date'] = Weekly_HE_sales.loc[
            (Weekly_HE_sales['IMDB Title Code'] == i) &
            (Weekly_HE_sales['Media Type'] == 'VOD') &
            (Weekly_HE_sales['Media SubType'] == 'Rental'), 'Week Start Date'].min()
    del i

    all_titles['DVD_Rental_Street_Date'] = pd.to_datetime(
        arg=all_titles['DVD_Rental_Street_Date'],
        format="%Y-%m-%d",
        errors="coerce")
    all_titles['DVD_Sell-Thru_Street_Date'] = pd.to_datetime(
        arg=all_titles['DVD_Sell-Thru_Street_Date'],
        format="%Y-%m-%d",
        errors="coerce")
    all_titles['Blu-ray_Rental_Street_Date'] = pd.to_datetime(
        arg=all_titles['Blu-ray_Rental_Street_Date'],
        format="%Y-%m-%d",
        errors="coerce")
    all_titles['Blu-ray_Sell-Thru_Street_Date'] = pd.to_datetime(
        arg=all_titles['Blu-ray_Sell-Thru_Street_Date'],
        format="%Y-%m-%d",
        errors="coerce")
    all_titles['EST_Sell-Thru_Street_Date'] = pd.to_datetime(
        arg=all_titles['EST_Sell-Thru_Street_Date'],
        format="%Y-%m-%d",
        errors="coerce")
    all_titles['iVOD_Rental_Street_Date'] = pd.to_datetime(
        arg=all_titles['iVOD_Rental_Street_Date'],
        format="%Y-%m-%d",
        errors="coerce")
    all_titles['VOD_Rental_Street_Date'] = pd.to_datetime(
        arg=all_titles['VOD_Rental_Street_Date'],
        format="%Y-%m-%d",
        errors="coerce")

    # calculating Week number for EST & PST Release dates
    all_titles['EST_Sell-Thru_Week_Start'] = np.nan
    all_titles['iVOD_Rental_Week_Start'] = np.nan
    all_titles['VOD_Rental_Week_Start'] = np.nan
    all_titles['DVD_Sell-Thru_Week_Start'] = np.nan
    all_titles['DVD_Rental_Week_Start'] = np.nan
    all_titles['Blu-ray_Sell-Thru_Week_Start'] = np.nan
    all_titles['Blu-ray_Rental_Week_Start'] = np.nan
    for i in tqdm(all_titles['IMDB Title Code'].unique()):
        if pd.isnull(all_titles.loc[all_titles['IMDB Title Code'] == i, 'EST_Sell-Thru_Week_Start'].values[0]):
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'EST_Sell-Thru_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB Title Code'] == i, 'Theatrical Week Start Sunday'] - all_titles.loc[all_titles['IMDB Title Code'] == i, 'EST_Sell-Thru_Street_Date']) / pd.offsets.Day(-1)) / 7)
        if pd.isnull(all_titles.loc[all_titles['IMDB Title Code'] == i, 'iVOD_Rental_Week_Start'].values[0]):
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'iVOD_Rental_Week_Start'] = np.floor(((all_titles.loc[
                                                                                                          all_titles[
                                                                                                              'IMDB Title Code'] == i, 'Theatrical Week Start Sunday'] -
                                                                                                      all_titles.loc[
                                                                                                          all_titles[
                                                                                                              'IMDB Title Code'] == i, 'iVOD_Rental_Street_Date']) / pd.offsets.Day(
                -1)) / 7)
        if pd.isnull(all_titles.loc[all_titles['IMDB Title Code'] == i, 'VOD_Rental_Week_Start'].values[0]):
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'VOD_Rental_Week_Start'] = np.floor(((all_titles.loc[
                                                                                                         all_titles[
                                                                                                             'IMDB Title Code'] == i, 'Theatrical Week Start Sunday'] -
                                                                                                     all_titles.loc[
                                                                                                         all_titles[
                                                                                                             'IMDB Title Code'] == i, 'VOD_Rental_Street_Date']) / pd.offsets.Day(
                -1)) / 7)
        if pd.isnull(all_titles.loc[all_titles['IMDB Title Code'] == i, 'DVD_Sell-Thru_Week_Start'].values[0]):
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'DVD_Sell-Thru_Week_Start'] = np.floor(((all_titles.loc[
                                                                                                            all_titles[
                                                                                                                'IMDB Title Code'] == i, 'Theatrical Week Start Sunday'] -
                                                                                                        all_titles.loc[
                                                                                                            all_titles[
                                                                                                                'IMDB Title Code'] == i, 'DVD_Sell-Thru_Street_Date']) / pd.offsets.Day(
                -1)) / 7)
        if pd.isnull(all_titles.loc[all_titles['IMDB Title Code'] == i, 'DVD_Rental_Week_Start'].values[0]):
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'DVD_Rental_Week_Start'] = np.floor(((all_titles.loc[
                                                                                                         all_titles[
                                                                                                             'IMDB Title Code'] == i, 'Theatrical Week Start Sunday'] -
                                                                                                     all_titles.loc[
                                                                                                         all_titles[
                                                                                                             'IMDB Title Code'] == i, 'DVD_Rental_Street_Date']) / pd.offsets.Day(
                -1)) / 7)
        if pd.isnull(all_titles.loc[all_titles['IMDB Title Code'] == i, 'Blu-ray_Sell-Thru_Week_Start'].values[0]):
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'Blu-ray_Sell-Thru_Week_Start'] = np.floor(((
                                                                                                                       all_titles.loc[
                                                                                                                           all_titles[
                                                                                                                               'IMDB Title Code'] == i, 'Theatrical Week Start Sunday'] -
                                                                                                                       all_titles.loc[
                                                                                                                           all_titles[
                                                                                                                               'IMDB Title Code'] == i, 'Blu-ray_Sell-Thru_Street_Date']) / pd.offsets.Day(
                -1)) / 7)
        if pd.isnull(all_titles.loc[all_titles['IMDB Title Code'] == i, 'Blu-ray_Rental_Week_Start'].values[0]):
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'Blu-ray_Rental_Week_Start'] = np.floor(((all_titles.loc[
                                                                                                             all_titles[
                                                                                                                 'IMDB Title Code'] == i, 'Theatrical Week Start Sunday'] -
                                                                                                         all_titles.loc[
                                                                                                             all_titles[
                                                                                                                 'IMDB Title Code'] == i, 'Blu-ray_Rental_Street_Date']) / pd.offsets.Day(
                -1)) / 7)
    del i

    Weekly_BO_sales = pd.merge(left=Weekly_BO_sales.drop(['Theatrical Release Date'],
                                                         axis=1),
                               right=df[['IMDB Title Code', 'Theatrical Week Start Sunday']],
                               how='left',
                               left_on=['IMDB Title Code'],
                               right_on=['IMDB Title Code'])
    Weekly_BO_sales['TH Week Number'] = np.floor(
        ((Weekly_BO_sales['Week Start Date'] - Weekly_BO_sales['Theatrical Week Start Sunday']) / pd.offsets.Day(1)) / 7
    )

    # updating all_titles dataframe with title level spends activity weeks
    spends_week_range = pd.pivot_table(data=Weekly_spends,
                                       index=['IMDB Title Code'],
                                       values=['TH Week Number'],
                                       aggfunc=['min', 'max']).reset_index()
    all_titles = pd.merge(left=all_titles,
                          right=spends_week_range,
                          how='left',
                          left_on=['IMDB Title Code'],
                          right_on=[('IMDB Title Code', '')])
    all_titles.drop([('IMDB Title Code', '')], axis=1, inplace=True)
    del spends_week_range

    # updating list of all IMDB_Title_Codes & their Theatrical, EST & PST Release Dates with last TH Week Number
    all_titles['EST_Sell-Thru_Week_Ends'] = np.NaN
    all_titles['iVOD_Rental_Week_Ends'] = np.NaN
    all_titles['VOD_Rental_Week_Ends'] = np.NaN
    all_titles['DVD_Sell-Thru_Week_Ends'] = np.NaN
    all_titles['DVD_Rental_Week_Ends'] = np.NaN
    all_titles['Blu-ray_Sell-Thru_Week_Ends'] = np.NaN
    all_titles['Blu-ray_Rental_Week_Ends'] = np.NaN
    all_titles['BO_Week_Start'] = np.float64(0)
    all_titles['BO_Week_Ends'] = np.NaN
    for i in tqdm(all_titles['IMDB Title Code'].unique()):
        if math.isnan(all_titles.loc[all_titles['IMDB Title Code'] == i, 'EST_Sell-Thru_Week_Start']) != True:
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'EST_Sell-Thru_Week_Ends'] = max(
                Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB Title Code'] == i) &
                                    (Weekly_HE_sales['Media Type'] == 'EST') &
                                    (Weekly_HE_sales['Media SubType'] == 'Sell-Thru'), 'TH Week Number'].dropna())
        if math.isnan(all_titles.loc[all_titles['IMDB Title Code'] == i, 'iVOD_Rental_Week_Start']) != True:
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'iVOD_Rental_Week_Ends'] = max(
                Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB Title Code'] == i) &
                                    (Weekly_HE_sales['Media Type'] == 'iVOD') &
                                    (Weekly_HE_sales['Media SubType'] == 'Rental'), 'TH Week Number'].dropna())
        if math.isnan(all_titles.loc[all_titles['IMDB Title Code'] == i, 'VOD_Rental_Week_Start']) != True:
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'VOD_Rental_Week_Ends'] = max(
                Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB Title Code'] == i) &
                                    (Weekly_HE_sales['Media Type'] == 'VOD') &
                                    (Weekly_HE_sales['Media SubType'] == 'Rental'), 'TH Week Number'].dropna())
        if math.isnan(all_titles.loc[all_titles['IMDB Title Code'] == i, 'DVD_Sell-Thru_Week_Start']) != True:
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'DVD_Sell-Thru_Week_Ends'] = max(
                Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB Title Code'] == i) &
                                    (Weekly_HE_sales['Media Type'] == 'DVD') &
                                    (Weekly_HE_sales['Media SubType'] == 'Sell-Thru'), 'TH Week Number'].dropna())
        if math.isnan(all_titles.loc[all_titles['IMDB Title Code'] == i, 'DVD_Rental_Week_Start']) != True:
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'DVD_Rental_Week_Ends'] = max(
                Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB Title Code'] == i) &
                                    (Weekly_HE_sales['Media Type'] == 'DVD') &
                                    (Weekly_HE_sales['Media SubType'] == 'Rental'), 'TH Week Number'].dropna())
        if math.isnan(all_titles.loc[all_titles['IMDB Title Code'] == i, 'Blu-ray_Sell-Thru_Week_Start']) != True:
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'Blu-ray_Sell-Thru_Week_Ends'] = max(
                Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB Title Code'] == i) &
                                    (Weekly_HE_sales['Media Type'] == 'Blu-ray') &
                                    (Weekly_HE_sales['Media SubType'] == 'Sell-Thru'), 'TH Week Number'].dropna())
        if math.isnan(all_titles.loc[all_titles['IMDB Title Code'] == i, 'Blu-ray_Rental_Week_Start']) != True:
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'Blu-ray_Rental_Week_Ends'] = max(
                Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB Title Code'] == i) &
                                    (Weekly_HE_sales['Media Type'] == 'Blu-ray') &
                                    (Weekly_HE_sales['Media SubType'] == 'Rental'), 'TH Week Number'].dropna())
        if i in Weekly_BO_sales['IMDB Title Code'].unique():
            all_titles.loc[all_titles['IMDB Title Code'] == i, 'BO_Week_Ends'] = max(
                Weekly_BO_sales.loc[Weekly_BO_sales['IMDB Title Code'] == i, 'TH Week Number'].dropna())
    del i

    # creating the master_AD
    # creating a dataframe of IMDB Title Codes and Week ranges for each IMDB Title Codes
    unique_week = pd.DataFrame({'IMDB Title Code': [],
                                'TH Week Number': []})
    activity_range = pd.DataFrame({'IMDB Title Code': all_titles['IMDB Title Code'].tolist(),
                                   'Oldest Week': np.nanmin(all_titles.loc[:, all_titles.loc[:,
                                                                              all_titles.dtypes == np.float64].columns.values],
                                                            axis=1).tolist(),
                                   'Latest Week': np.nanmax(all_titles.loc[:, all_titles.loc[:,
                                                                              all_titles.dtypes == np.float64].columns.values],
                                                            axis=1).tolist()})
    activity_range['Week Length'] = (activity_range['Latest Week'] - activity_range['Oldest Week']) + 1
    activity_range.dropna(axis=0,
                          how='all',
                          thresh=3,
                          inplace=True)

    for i in activity_range['IMDB Title Code']:
        temp = pd.DataFrame(
            {'IMDB Title Code': [i] * int(activity_range.loc[activity_range['IMDB Title Code'] == i, 'Week Length']),
             'TH Week Number': range(int(activity_range.loc[activity_range['IMDB Title Code'] == i, 'Oldest Week']),
                                     int(activity_range.loc[activity_range['IMDB Title Code'] == i, 'Latest Week']) + 1)})
        unique_week = unique_week.append(temp, sort=True)
        del temp
    del i
    unique_week.reset_index(drop=True, inplace=True)
    del activity_range

    # merging Theater Release Date with unique_week dataset
    master_AD = pd.merge(left=unique_week,
                         right=all_titles[['IMDB Title Code',
                                           'Theatrical Week Start Sunday']],
                         how='left',
                         left_on='IMDB Title Code',
                         right_on='IMDB Title Code',
                         sort=True,
                         copy=False)
    del unique_week

    # merging spends for weeks present
    master_AD = pd.merge(left=master_AD,
                         right=Weekly_spends,
                         how='left',
                         left_on=['IMDB Title Code', 'TH Week Number'],
                         right_on=['IMDB Title Code', 'TH Week Number'],
                         sort=True,
                         copy=False)

    # merging BO Revenue for weeks present
    master_AD = pd.merge(left=master_AD,
                         right=Weekly_BO_sales[['IMDB Title Code',
                                                'TH Week Number',
                                                'Box Office']],
                         how='left',
                         left_on=['IMDB Title Code', 'TH Week Number'],
                         right_on=['IMDB Title Code', 'TH Week Number'],
                         sort=True,
                         copy=False)

    # merging HE Revenue for weeks present
    Weekly_HE_sales = pd.pivot_table(data=Weekly_HE_sales[['IMDB Title Code',
                                                           'Media Type',
                                                           'Media SubType',
                                                           'TH Week Number',
                                                           'Revenue']],
                                     index=['IMDB Title Code',
                                            'TH Week Number'],
                                     columns=['Media Type',
                                              'Media SubType'],
                                     values=['Revenue'],
                                     aggfunc=np.unique).reset_index()
    Weekly_HE_sales.columns = ['IMDB Title Code',
                               'TH Week Number',
                               'Blu-ray Rental Revenue',
                               'Blu-ray Sell-Thru Revenue',
                               'DVD Rental Revenue',
                               'DVD Sell-Thru Revenue',
                               'EST Sell-Thru Revenue',
                               'VOD Rental Revenue',
                               'iVOD Rental Revenue']

    master_AD = pd.merge(left=master_AD,
                         right=Weekly_HE_sales,
                         how='left',
                         left_on=['IMDB Title Code', 'TH Week Number'],
                         right_on=['IMDB Title Code', 'TH Week Number'],
                         sort=True,
                         copy=False)

    # adding Week Start Date
    for i in tqdm(master_AD.index):
        master_AD.loc[i, 'Week Start Date'] = master_AD.loc[i, 'Theatrical Week Start Sunday'] + timedelta(days=int(master_AD.loc[i, 'TH Week Number']) * 7)
    del i

    master_AD = pd.merge(left=master_AD,
                         right=df[['IMDB Title Code',
                                   'IMDB Title Name',
                                   'Theatrical Release Date']],
                         how='left',
                         left_on='IMDB Title Code',
                         right_on='IMDB Title Code',
                         sort=True,
                         copy=False)

    # renaming columns for column name consistency across all files
    master_AD = master_AD[['IMDB Title Code',
                           'IMDB Title Name',
                           'Theatrical Release Date',
                           'TH Week Number',
                           'Week Start Date',
                           'BO Digital Spend',
                           'BO Digital Video Spend',
                           'BO Total Linear Spend',
                           'BO Total Radio Spend',
                           'BO Outdoor/Print Spend',
                           'BO OOH-Experiential Spend',
                           'HE Digital Spend',
                           'HE Digital Video Spend',
                           'HE Non-Digital Spend',
                           'HE Linear Co-op Spend',
                           'Box Office',
                           'Blu-ray Sell-Thru Revenue',
                           'Blu-ray Rental Revenue',
                           'DVD Sell-Thru Revenue',
                           'DVD Rental Revenue',
                           'EST Sell-Thru Revenue',
                           'iVOD Rental Revenue',
                           'VOD Rental Revenue']]
    master_AD.rename(columns={'Box Office': 'BO Revenue'},
                     inplace=True)

    # master_AD.drop_duplicates(inplace=True)

    # exporting dataset
    if export_path != False:
        with pd.ExcelWriter(
                path=export_path,
                mode='w',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY') as writer:
            master_AD.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name='Sales & Spends Data',
                engine='openpyxl')

    print("Sales & spends data collated")
    return master_AD
