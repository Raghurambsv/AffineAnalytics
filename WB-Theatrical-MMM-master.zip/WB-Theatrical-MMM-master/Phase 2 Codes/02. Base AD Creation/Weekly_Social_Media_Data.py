# importing modules
import numpy as np
import pandas as pd
from datetime import timedelta
import sys

def weekly_social_media_activity(df, root_folder, sharepoint_path, export_path=False):

    """
    This function takes in a user provided dataframe containing unique IMDB Title Codes and their Theater Release Dates and returns a dataframe in a title-week level for which there are sales and(or) spends activity

    Parameters
    ----------
    df: Pandas Dataframe
         A dataframe having the following columns:
            IMDB Title Code
            Theatrical Release Date
    root_folder: String
        The root location where you are syncing your WB Theatrical github repository
    sharepoint_path: String
        The root location where you are syncing WB Theatrical sharedrive
    export_path: String
        The root location where you are syncing WB Theatrical sharedrive
    Returns
    -------
        A dataframe in a title-week level for which there are sales and(or) spends activity
    """

    sys.path.insert(0, root_folder+r"/Phase 2 Codes/06. Miscellaneous")
    import date_manipulations

    # cleaning files
    # Facebook
    Weekly_FB_data = pd.read_excel(
            io=sharepoint_path + r"\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\WaveMetrix Social Media Data Option1.xlsx",
            sheet_name='Facebook',
            na_values=['#NA','#N/A','',' ','na','NA'])
    Weekly_FB_data = pd.merge(left=Weekly_FB_data.drop('Theatrical Release Date', axis=1),
                              right=df[['IMDB Title Code', 'Theatrical Release Date']],
                              how='inner',
                              left_on='IMDB Title Code',
                              right_on='IMDB Title Code')
    Weekly_FB_data = date_manipulations.last_sunday(df=Weekly_FB_data,
                                                    date_column_name='Theatrical Release Date',
                                                    sunday_date_column_name='Theatrical Week Start Sunday')
    Weekly_FB_data = date_manipulations.last_sunday(df=Weekly_FB_data,
                                                    date_column_name='Post Date',
                                                    sunday_date_column_name='Week Start Date')
    Weekly_FB_data['Week Number'] = np.floor(((Weekly_FB_data['Week Start Date'] - Weekly_FB_data['Theatrical Week Start Sunday']) / pd.offsets.Day(1)) / 7)
    Weekly_FB_data = Weekly_FB_data.groupby(by=['IMDB Title Code',
                                                'IMDB Title Name',
                                                'Theatrical Release Date',
                                                'Week Start Date',
                                                'Week Number']).agg({'Comments':'max',
                                                                     'Likes':'max',
                                                                     'Ptat':'max',
                                                                     'Shares':'max',
                                                                     'Videos':'max',
                                                                     'Views':'max'}).reset_index(drop=False)
    Weekly_FB_data.columns = ['IMDB Title Code',
                              'IMDB Title Name',
                              'Theatrical Release Date',
                              'Week Start Date',
                              'Week Number',
                              'Facebook Comments',
                              'Facebook Likes',
                              'Facebook Ptat',
                              'Facebook Shares',
                              'Facebook Videos',
                              'Facebook Views']
    Weekly_FB_data['Facebook Comments'] = Weekly_FB_data['Facebook Comments'] - Weekly_FB_data.groupby(['IMDB Title Code']).agg({'Facebook Comments' : 'shift'}).iloc[:,0]
    Weekly_FB_data['Facebook Likes'] = Weekly_FB_data['Facebook Likes'] - Weekly_FB_data.groupby(['IMDB Title Code']).agg({'Facebook Likes' : 'shift'}).iloc[:,0]
    Weekly_FB_data['Facebook Ptat'] = Weekly_FB_data['Facebook Ptat'] - Weekly_FB_data.groupby(['IMDB Title Code']).agg({'Facebook Ptat' : 'shift'}).iloc[:,0]
    Weekly_FB_data['Facebook Shares'] = Weekly_FB_data['Facebook Shares'] - Weekly_FB_data.groupby(['IMDB Title Code']).agg({'Facebook Shares' : 'shift'}).iloc[:,0]
    Weekly_FB_data['Facebook Videos'] = Weekly_FB_data['Facebook Videos'] - Weekly_FB_data.groupby(['IMDB Title Code']).agg({'Facebook Videos' : 'shift'}).iloc[:,0]
    Weekly_FB_data['Facebook Views'] = Weekly_FB_data['Facebook Views'] - Weekly_FB_data.groupby(['IMDB Title Code']).agg({'Facebook Views' : 'shift'}).iloc[:,0]
    
    # exporting dataset
    if export_path!=False:
        with pd.ExcelWriter(
                path=export_path,
                mode='w',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY') as writer:
            Weekly_FB_data.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name='Facebook',
                engine='openpyxl')
    print("Weekly Facebook data prepared")

    # Twitter
    Weekly_TW_data = pd.read_excel(
            io=sharepoint_path + r"\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\WaveMetrix Social Media Data Option1.xlsx",
            sheet_name='Twitter',
            na_values=['#NA','#N/A','',' ','na','NA'])
    Weekly_TW_data = pd.merge(left=Weekly_TW_data.drop('Theatrical Release Date', axis=1),
                              right=df[['IMDB Title Code', 'Theatrical Release Date']],
                              how='inner',
                              left_on='IMDB Title Code',
                              right_on='IMDB Title Code')
    Weekly_TW_data = date_manipulations.last_sunday(df=Weekly_TW_data,
                                                    date_column_name='Theatrical Release Date',
                                                    sunday_date_column_name='Theatrical Week Start Sunday')
    Weekly_TW_data = date_manipulations.last_sunday(df=Weekly_TW_data,
                                                    date_column_name='Post Date',
                                                    sunday_date_column_name='Week Start Date')
    Weekly_TW_data['Week Number'] = np.floor(((Weekly_TW_data['Week Start Date'] - Weekly_TW_data['Theatrical Week Start Sunday']) / pd.offsets.Day(1)) / 7)
    Weekly_TW_data = Weekly_TW_data.groupby(by=['IMDB Title Code',
                                                'IMDB Title Name',
                                                'Theatrical Release Date',
                                                'Week Start Date',
                                                'Week Number']).agg({'Views':'sum'}).reset_index(drop=False)
    Weekly_TW_data.columns = ['IMDB Title Code',
                              'IMDB Title Name',
                              'Theatrical Release Date',
                              'Week Start Date',
                              'Week Number',
                              'Twitter Views']
    # exporting dataset
    if export_path != False:
        with pd.ExcelWriter(
                path=export_path,
                mode='a',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY') as writer:
            Weekly_TW_data.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name='Twitter',
                engine='openpyxl')
    print("Weekly Twitter data prepared")

    #YouTube
    Weekly_YT_data = pd.read_excel(
            io=sharepoint_path + r"\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\WaveMetrix Social Media Data Option1.xlsx",
            sheet_name='YouTube',
            na_values=['#NA','#N/A','',' ','na','NA'])
    Weekly_YT_data = pd.merge(left=Weekly_YT_data.drop('Theatrical Release Date', axis=1),
                              right=df[['IMDB Title Code', 'Theatrical Release Date']],
                              how='inner',
                              left_on='IMDB Title Code',
                              right_on='IMDB Title Code')
    Weekly_YT_data = date_manipulations.last_sunday(df=Weekly_YT_data,
                                                    date_column_name='Theatrical Release Date',
                                                    sunday_date_column_name='Theatrical Week Start Sunday')
    Weekly_YT_data = date_manipulations.last_sunday(df=Weekly_YT_data,
                                                    date_column_name='Post Date',
                                                    sunday_date_column_name='Week Start Date')
    Weekly_YT_data['Week Number'] = np.floor(((Weekly_YT_data['Week Start Date'] - Weekly_YT_data['Theatrical Week Start Sunday']) / pd.offsets.Day(1)) / 7)
    Weekly_YT_data = Weekly_YT_data.groupby(by=['IMDB Title Code',
                                                'IMDB Title Name',
                                                'Theatrical Release Date',
                                                'Week Start Date',
                                                'Week Number']).agg({'Comments':'max',
                                                                     'Likes':'max',
                                                                     'Dislikes':'max',
                                                                     'Videos':'max',
                                                                     'Views':'max'}).reset_index(drop=False)
    Weekly_YT_data['Sentiment'] = Weekly_YT_data['Likes']/(Weekly_YT_data['Likes']+Weekly_YT_data['Dislikes'])
    Weekly_YT_data.columns = ['IMDB Title Code',
                              'IMDB Title Name',
                              'Theatrical Release Date',
                              'Week Start Date',
                              'Week Number',
                              'YouTube Comments',
                              'YouTube Likes',
                              'YouTube Dislikes',
                              'YouTube Videos',
                              'YouTube Views',
                              'YouTube Sentiment']
    Weekly_YT_data['YouTube Comments'] = Weekly_YT_data['YouTube Comments'] - Weekly_YT_data.groupby(['IMDB Title Code']).agg({'YouTube Comments' : 'shift'}).iloc[:,0]
    Weekly_YT_data['YouTube Likes'] = Weekly_YT_data['YouTube Likes'] - Weekly_YT_data.groupby(['IMDB Title Code']).agg({'YouTube Likes' : 'shift'}).iloc[:,0]
    Weekly_YT_data['YouTube Dislikes'] = Weekly_YT_data['YouTube Dislikes'] - Weekly_YT_data.groupby(['IMDB Title Code']).agg({'YouTube Dislikes' : 'shift'}).iloc[:,0]
    Weekly_YT_data['YouTube Videos'] = Weekly_YT_data['YouTube Videos'] - Weekly_YT_data.groupby(['IMDB Title Code']).agg({'YouTube Videos' : 'shift'}).iloc[:,0]
    Weekly_YT_data['YouTube Views'] = Weekly_YT_data['YouTube Views'] - Weekly_YT_data.groupby(['IMDB Title Code']).agg({'YouTube Views' : 'shift'}).iloc[:,0]
    
    # exporting dataset
    if export_path != False:
        with pd.ExcelWriter(
                path=export_path,
                mode='a',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY') as writer:
            Weekly_YT_data.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name='YouTube',
                engine='openpyxl')
    print("Weekly YouTube data prepared")

    # Google Search
    Weekly_GS_data = pd.read_excel(
            io=sharepoint_path + r"\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\Google Search Data\Google Search Data_v4.xlsx",
            sheet_name='GS Data',
            na_values=['#NA','#N/A','',' ','na','NA'])
    Weekly_GS_data = pd.merge(left=Weekly_GS_data.drop('Theatrical Release Date', axis=1),
                              right=df[['IMDB Title Code', 'Theatrical Release Date']],
                              how='inner',
                              left_on='IMDB Title Code',
                              right_on='IMDB Title Code')
    Weekly_GS_data = Weekly_GS_data.groupby(by=['IMDB Title Code',
                                                'IMDB Title Name',
                                                'Theatrical Release Date',
                                                'Week Start Date',
                                                'Week Number']).agg({'Google Search Volume':'sum'}).reset_index(drop=False)
    Weekly_GS_data.columns = ['IMDB Title Code',
                              'IMDB Title Name',
                              'Theatrical Release Date',
                              'Week Start Date',
                              'Week Number',
                              'Google Search Volume']
    # exporting dataset
    if export_path != False:
        with pd.ExcelWriter(
                path=export_path,
                mode='a',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY') as writer:
            Weekly_GS_data.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name='Google Search',
                engine='openpyxl')
    print("Weekly Google Search data prepared")

    # Wikipedia
    Weekly_WK_data = pd.read_excel(
            io=sharepoint_path + r"\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\Wikipedia Data\AAS Wikipedia Views - Full data.xlsx",
            sheet_name='Base Data',
            na_values=['#NA','#N/A','',' ','na','NA'])
    Weekly_WK_data = pd.merge(left=Weekly_WK_data,
                              right=df[['IMDB Title Code', 'Theatrical Release Date']],
                              how='inner',
                              left_on='IMDB Title Code',
                              right_on='IMDB Title Code')
    for i in Weekly_WK_data.index:
        Weekly_WK_data.loc[i, 'Post Date'] = Weekly_WK_data.loc[i, 'Theatrical Release Date'] - timedelta(days=int(Weekly_WK_data.loc[i, 'Days before release']))
    del i
    Weekly_WK_data = date_manipulations.last_sunday(df=Weekly_WK_data,
                                                    date_column_name='Theatrical Release Date',
                                                    sunday_date_column_name='Theatrical Week Start Sunday')
    Weekly_WK_data = date_manipulations.last_sunday(df=Weekly_WK_data,
                                                    date_column_name='Post Date',
                                                    sunday_date_column_name='Week Start Date')
    Weekly_WK_data['Week Number'] = np.floor(((Weekly_WK_data['Week Start Date'] - Weekly_WK_data['Theatrical Week Start Sunday']) / pd.offsets.Day(1)) / 7)
    Weekly_WK_data = Weekly_WK_data.groupby(by=['IMDB Title Code',
                                                'IMDB Title Name',
                                                'Theatrical Release Date',
                                                'Week Start Date',
                                                'Week Number']).agg({'Wiki Page Views - AA':'sum'}).reset_index(drop=False)
    Weekly_WK_data.columns = ['IMDB Title Code',
                              'IMDB Title Name',
                              'Theatrical Release Date',
                              'Week Start Date',
                              'Week Number',
                              'Wikipedia Page Views']
    # exporting dataset
    if export_path != False:
        with pd.ExcelWriter(
                path=export_path,
                mode='a',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY') as writer:
            Weekly_WK_data.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name='Wikipedia',
                engine='openpyxl')
    print("Weekly Wikipedia data prepared")
    
    # creating master social media dataset
    social_media_data = pd.merge(left=Weekly_FB_data,
                                 right=Weekly_TW_data,
                                 how='outer',
                                 left_on=['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', 'Week Start Date', 'Week Number'],
                                 right_on=['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', 'Week Start Date', 'Week Number'])
    social_media_data = pd.merge(left=social_media_data,
                                 right=Weekly_YT_data,
                                 how='outer',
                                 left_on=['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', 'Week Start Date', 'Week Number'],
                                 right_on=['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', 'Week Start Date', 'Week Number'])
    social_media_data = pd.merge(left=social_media_data,
                                 right=Weekly_GS_data,
                                 how='outer',
                                 left_on=['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', 'Week Start Date', 'Week Number'],
                                 right_on=['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', 'Week Start Date', 'Week Number'])
    social_media_data = pd.merge(left=social_media_data,
                                 right=Weekly_WK_data,
                                 how='outer',
                                 left_on=['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', 'Week Start Date', 'Week Number'],
                                 right_on=['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', 'Week Start Date', 'Week Number'])
    # exporting dataset
    if export_path != False:
        with pd.ExcelWriter(
                path=export_path,
                mode='a',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY') as writer:
            social_media_data.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name='Social Media Data',
                engine='openpyxl')

    print("Social Media data collated")
    return social_media_data
