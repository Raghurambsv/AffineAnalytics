import os
import pandas as pd
import re
import datetime

#os.chdir('D:/Sayantan_C/Projects/09. Warner Bros - Theatrical MMM/Survey Data - Cleaning')
#filename = 'Week 43'

# Read Dynata Extract
#base_data = pd.read_excel(filename + '.xlsx')

# Read Data Dependencies
#panel_coding = pd.read_excel(r"C:\Users\mukund\Documents\Creative elements\Cleaned Data\Mapping File.xlsx", sheet_name = 'Panel Mapping')
#country_coding = pd.read_excel(r"C:\Users\mukund\Documents\Creative elements\Cleaned Data\Mapping File.xlsx", sheet_name = 'Country Mapping')
#state_coding = pd.read_excel(r"C:\Users\mukund\Documents\Creative elements\Cleaned Data\Mapping File.xlsx", sheet_name = 'State Mapping')

def decode_generic_columns(base_data, panel_coding, country_coding):
    status_dict = {1 : 'Terminated', 2 : 'Overquota', 3 : 'Qualified', 4 : 'Partial'}
    
    cleaned_data = pd.DataFrame()
    cleaned_data['UID'] = base_data['uuid']
    cleaned_data['Status_dc'] = base_data['status'].apply(lambda x : status_dict.get(x))
    cleaned_data['Panel_Name'] = pd.merge(base_data, panel_coding,left_on='panelSource',right_on='Panel ID', how='left')['Panel Name']
    cleaned_data['Country_Name'] = pd.merge(base_data, country_coding,left_on='Country',right_on='Country ID', how='left')['Country Name']
    return cleaned_data

def decode_demographics(base_data, cleaned_data, state_coding):
    age_bucket1_dict = {1 : '13 to 29', 2 : '30 to 64'}
    age_bucket2_dict = {1 : '13 to 17', 2 : '18 to 24', 3 : '25 to 29', 4 : '30 to 34', 5 : '35 to 39' , 6 : '40 to 44',
                       7 : '45 to 49', 8 : '50 to 59', 9 : '60 to 64'}   
    household_member_dict = {1 : 'One', 2 : 'Two', 3 : 'Three', 4 : 'Four', 5 : 'More than Five'}
    household_child_dict = {1 : 'None', 2 : 'One', 3 : 'Two', 4 : 'Three', 5 : 'Four', 6 : 'More than Five'}
    marital_status_dict = {1: 'Single', 2 : 'Married', 3 : 'Living with partner', 4 : 'Separated', 5 : 'Divorced',
                          6 : 'Widowed', 7 : 'Civil Union', 8 : 'NA'}
    education_dict = {1: 'High School or less', 2 : 'High School Grad', 3 : 'College/University/Technical School',
                      4 : 'Vocational/Technical Degree', 5 : 'Associate', 6 : 'Bachelors', 7 : 'Masters', 8 : 'Doctoral',
                     9 : 'NA'}
    income_dict = {1 : 'Less than $15,000', 2 : '$15,000 to $24,999', 3 : '$25,000 to $49,999', 4 : '$50,000 to $74,999',
                  5 : '$75,000 to $99,999', 6 : '$100,000 to $149,999', 7 : '$150,000 to $199,999', 8 : '$200,000 to $249,999',
                  9 : '$250,000 or more', 10 : 'Prefer not to answer'}
    employment_dict = {1 : 'Full time', 2 : 'Part time', 3 : 'Contract, Freelance or Temporary', 4 : 'Self-employed',
                       5 : 'Semi-retired', 6 : 'Retired', 7 : 'Homemaker', 8 : 'Stay-at-Home Parent', 9 : 'Full-time Student',
                       10 : 'Part-time Student', 11 : 'Unemployed', 12 : 'NA', 13 : 'Disabled'}
        
    cleaned_data['Age'] = base_data['Q1106']
    cleaned_data['Age_Bucket_1'] = base_data['hAge'].apply(lambda x : age_bucket1_dict.get(x))
    cleaned_data['Age_Bucket_2'] = base_data['hAge2'].apply(lambda x : age_bucket2_dict.get(x))
    cleaned_data['Gender'] = base_data['Q1107'].apply(lambda x : 'Male' if x==1 else 'Female')
    cleaned_data['Hisp_Lat_flag'] = base_data['Q1110'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else 'NA'))
    
    base_data['Eth_1'] = base_data['Q1115r1'].apply(lambda x : 'Caucasian / White' if x==1 else '')
    base_data['Eth_2'] = base_data['Q1115r2'].apply(lambda x : 'African American / Black' if x==1 else '')
    base_data['Eth_3'] = base_data['Q1115r3'].apply(lambda x : 'Asian / Asian American' if x==1 else '')
    base_data['Eth_4'] = base_data['Q1115r4'].apply(lambda x : 'Native American, Inuit or Aleut' if x==1 else '')
    base_data['Eth_5'] = base_data['Q1115r5'].apply(lambda x : 'Native Hawaiian / Pacific Islander' if x==1 else '')
    base_data['Eth_6'] = base_data['Q1115r6'].apply(lambda x : 'Other' if x==1 else '')
    
    cleaned_data['Caucasian'] = base_data['Q1115r1']
    cleaned_data['African_American'] = base_data['Q1115r2']
    cleaned_data['Asian'] = base_data['Q1115r3']
    cleaned_data['Native_American'] = base_data['Q1115r4']
    cleaned_data['Native Hawaiian'] = base_data['Q1115r5']
    cleaned_data['Other'] = base_data['Q1115r6']
    
    cleaned_data['Ethnicity_Other'] = base_data['Q1115r6oe']
    cleaned_data['Ethnicity_Flag'] = base_data.apply(lambda x : 'Hispanic' if x['Q1110']==1
                                                     else ('African American' if x['Eth_2']=='African American / Black'
                                                           else ('Asian' if x['Eth_3']=='Asian / Asian American'
                                                                 else 'Caucasian/Other')), axis = 1)
    
    cleaned_data['Movie_Survey_LM'] = base_data['Q1117'].apply(lambda x : 'Yes' if x==1 else 'No')
    cleaned_data['Zip_Code'] = base_data['Q1120']
    cleaned_data['State_Name'] = pd.merge(base_data, state_coding,left_on='STATE',right_on='State ID', how='left')['State Name']
    
    cleaned_data['Household_Members'] = base_data['Q1125'].apply(lambda x : household_member_dict.get(x))
    cleaned_data['Household_Children'] = base_data['Q1130'].apply(lambda x : household_child_dict.get(x))
    
    base_data['Girl_2_4'] = base_data['Q1135r1']
    base_data['Girl_5_7'] = base_data['Q1135r2']
    base_data['Girl_8_9'] = base_data['Q1135r3']
    base_data['Girl_10_12'] = base_data['Q1135r4']
    base_data['Boy_2_4'] = base_data['Q1135r5']
    base_data['Boy_5_7'] = base_data['Q1135r6']
    base_data['Boy_8_9'] = base_data['Q1135r7']
    base_data['Boy_10_12'] = base_data['Q1135r8']
    base_data['Child_Age_NA'] = base_data['Q1135r9']
    
    cleaned_data['Marital_Status'] = base_data['Q1922'].apply(lambda x : marital_status_dict.get(x))    
    cleaned_data['Education'] = base_data['Q1928'].apply(lambda x : education_dict.get(x))
    cleaned_data['Annual_Income'] = base_data['Q1934'].apply(lambda x : income_dict.get(x))
    cleaned_data['Employment_Status'] = base_data['Q1936'].apply(lambda x : employment_dict.get(x))
    
    return cleaned_data

def decode_preferences(base_data, cleaned_data):
    
    opening_wk_dict = {1 : 'Very Often', 2 : 'Often', 3 : 'Sometimes', 4 : 'Rarely', 5 : 'Never'}
    fan_dict = {1 : 'Very much a fan', 2 : 'Somewhat a fan', 3 : 'Not at all a fan'}
    isp_dict = {1 : 'AOL',2 : 'AT&T U-verse', 3 : 'Bright House Networks', 4 : 'Charter Spectrum/Time Warner',
                5 : 'Cablevision (Optimum)', 6 : 'Comcast Xfinity', 7 : 'Cox', 8 : 'CenturyLink', 9 : 'Suddenlink',
                10 : 'Verizon Fios', 11 : 'Frontier Comm', 12 : 'Cable One', 13 : 'Cincinnati Bell', 14 : 'Hughes NET',
                15 : 'Mediacom', 16 : 'RCN', 17 : 'Windstream', 18 : 'Wide Open West', 19 : 'Google Fiber', 20 : 'Others',
                21 : 'Do not know', 22 : 'No Internet Service'}
    tv_dict = {1 : 'Bright House Networks', 2 : 'Cable One', 3 : 'Cablevision (Optimum)', 4 : 'Charter Spectrum/Time Warner',
               5 : 'Comcast Xfinity', 6 : 'Cox', 7 : 'Mediacom', 8 : 'RCN', 9 : 'Suddenlink', 10 : 'Wide Open West',
               11 : 'DirecTV', 12 : 'Dish Network', 13 : 'AT&T U-verse', 14 : 'CenturyLink', 15 : 'Verizon Fios',
               16 : 'Frontier Comm', 17 : 'DirecTV Now', 18 : 'PS Vue', 19 : 'SlingTV', 20 : 'Others',
               21 : 'Do not know'}
    mobile_dict = {1 : 'AT&T', 2 : 'Boost Mobile', 3 : 'Cricket Wireless' , 4 : 'MetroPCS', 5 : 'Simple Mobile', 6 : 'Sprint',
                  7 : 'Straight Talk', 8 : 'T-Mobile', 9 : 'US Cellular', 10 : 'Verizon', 11 : 'Google Fi/Project Fi',
                  12 : 'Others', 13 : 'Do not know', 14 : 'No Mobile Service'}
    political_dict = {1 : 'Republican', 2 : 'Democrat', 3 : 'Libertarian', 4 : 'Green', 5 : 'Independent',
                      6 : 'Other', 7 : 'NA'}
    
    Q2008_dict = {1 : 'Never', 2 : 'Often', 3 : 'Frequently'}
    
    base_data['Broadcast_TV'] = base_data['Q1155r1']
    base_data['Cable_TV'] = base_data['Q1155r2']
    base_data['Satellite_TV'] = base_data['Q1155r3']
    base_data['Telecom_TV'] = base_data['Q1155r4']
    base_data['Live_TV'] = base_data['Q1155r5']
    base_data['Subscription_Streaming'] = base_data['Q1155r6']
    base_data['Free_streaming'] = base_data['Q1155r7']
    base_data['Other_TV'] = base_data['Q1155r8']
    base_data['None_TV'] = base_data['Q1155r9'] 
    
    cleaned_data['TV_Program_Other'] = base_data['Q1155r8oe']
    
    base_data['Netflix'] = base_data['Q1160r1']
    base_data['Hulu'] = base_data['Q1160r2']
    base_data['Amazon_Prime_Video'] = base_data['Q1160r3']
    base_data['HBO_Now'] = base_data['Q1160r4']
    base_data['Theatre_Subscription'] = base_data['Q1160r5']
    base_data['Movies_Anywhere'] = base_data['Q1160r6']
        
    cleaned_data['Movies_Watched_LTD'] = base_data['Q1170r1']
    cleaned_data['Unknown_Column_Q1171'] = base_data['Q1171r1']
    
    base_data['AMC'] = base_data['Q1175r1']
    base_data['Regal'] = base_data['Q1175r2']
    base_data['Cinemark'] = base_data['Q1175r3']
    base_data['Landmark'] = base_data['Q1175r4']
    base_data['Pacific_Theatres'] = base_data['Q1175r5']
    base_data['B&B_Theatres'] = base_data['Q1175r6']
    base_data['Harkins'] = base_data['Q1175r7']
    base_data['Marcus_Theatres'] = base_data['Q1175r8']
    base_data['Southern_Theatres'] = base_data['Q1175r9']
    base_data['Regency'] = base_data['Q1175r10']
    base_data['Other_Theatrs'] = base_data['Q1175r11']
        
    cleaned_data['Opening_Wk_Preference'] = base_data['Q1178'].apply(lambda x : opening_wk_dict.get(x))
    
    cleaned_data['Bought_DVD_LTM'] = base_data['Q1180r1']
    cleaned_data['Bought_BR_LTM'] = base_data['Q1180r2']
    cleaned_data['Bought_4KUltra_LTM'] = base_data['Q1180r3']
    cleaned_data['Bought_Digital_LTM'] = base_data['Q1180r4']
    cleaned_data['Rent_DVD_BR_4K_LTM'] = base_data['Q1180r5']
    cleaned_data['Rent_Digital_LTM'] = base_data['Q1180r6']
    cleaned_data['Rent_cVOD_LTM'] = base_data['Q1180r7']
    cleaned_data['Streaming_Sub_LTM'] = base_data['Q1180r8']
    cleaned_data['Streaming_Free_LTM'] = base_data['Q1180r9']
    
    cleaned_data['Bought_DVD_LTM_New'] = base_data['Q1210r1']
    cleaned_data['Bought_BR_LTM_New'] = base_data['Q1210r2']
    cleaned_data['Bought_4K_UHD_LTM_New'] = base_data['Q1210r3']
    cleaned_data['Bought_Digital_LTM_New'] = base_data['Q1210r4']
    cleaned_data['Rent_DVD_LTM_New'] = base_data['Q1210r5']
    cleaned_data['Rent_Digital_LTM_New'] = base_data['Q1210r6']
    cleaned_data['Rent_CVOD_LTM_New'] = base_data['Q1210r7']
    
    cleaned_data['Theatre_Visit'] = base_data['Q1190r1']
    cleaned_data['Bought_DVD'] = base_data['Q1190r2']
    cleaned_data['Bought_BR'] = base_data['Q1190r3']
    cleaned_data['Bought_4KUltra'] = base_data['Q1190r4']
    cleaned_data['Bought_Digital'] = base_data['Q1190r5']
    cleaned_data['Rent_DVD_BR_4K'] = base_data['Q1190r6']
    cleaned_data['Rent_Digital'] = base_data['Q1190r7']
    cleaned_data['Rent_cVOD'] = base_data['Q1190r8']
    cleaned_data['Streaming_Sub'] = base_data['Q1190r9']
    cleaned_data['Streaming_Free'] = base_data['Q1190r10']
    
    cleaned_data['Bought_Digital']  = base_data['Q1186r1']
    cleaned_data['Rent_Digital']  = base_data['Q1186r2']
        
    cleaned_data['1st_Theatre_Visit'] = base_data['Q1185r1'].apply(lambda x : 'Before LTM' if x==1 else 'Within LTM')
    cleaned_data['1st_Bought_DVD'] = base_data['Q1185r2'].apply(lambda x : 'Before LTM' if x==1 else 'Within LTM')
    cleaned_data['1st_Bought_BR'] = base_data['Q1185r3'].apply(lambda x : 'Before LTM' if x==1 else 'Within LTM')
    cleaned_data['1st_Bought_4KUltra'] = base_data['Q1185r4'].apply(lambda x : 'Before LTM' if x==1 else 'Within LTM')
    cleaned_data['1st_Bought_Digital'] = base_data['Q1185r5'].apply(lambda x : 'Before LTM' if x==1 else 'Within LTM')
    cleaned_data['1st_Rent_DVD_BR_4K'] = base_data['Q1185r6'].apply(lambda x : 'Before LTM' if x==1 else 'Within LTM')
    cleaned_data['1st_Rent_Digital'] = base_data['Q1185r7'].apply(lambda x : 'Before LTM' if x==1 else 'Within LTM')
    cleaned_data['1st_Rent_cVOD'] = base_data['Q1185r8'].apply(lambda x : 'Before LTM' if x==1 else 'Within LTM')
    cleaned_data['1st_Streaming_Sub'] = base_data['Q1185r9'].apply(lambda x : 'Before LTM' if x==1 else 'Within LTM')
    cleaned_data['1st_Streaming_Free'] = base_data['Q1185r10'].apply(lambda x : 'Before LTM' if x==1 else 'Within LTM') 
    
    cleaned_data['Fan_Family'] = base_data['Q1225r1'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_Romantic'] = base_data['Q1225r2'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_SciFi'] = base_data['Q1225r3'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_Thriller'] = base_data['Q1225r4'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_Musical'] = base_data['Q1225r5'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_Horror'] = base_data['Q1225r6'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_R_Comedy'] = base_data['Q1225r7'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_Star_Wars'] = base_data['Q1225r8'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_Pixar'] = base_data['Q1225r9'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_Lego'] = base_data['Q1225r10'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_HP'] = base_data['Q1225r11'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_DC'] = base_data['Q1225r12'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_MCU'] = base_data['Q1225r13'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_Conjuring'] = base_data['Q1225r14'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_Pokemon'] = base_data['Q1225r15'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_Godzilla'] = base_data['Q1225r16'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_TMNT'] = base_data['Q1225r17'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_Stephen_King'] = base_data['Q1225r18'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_Indie'] = base_data['Q1225r19'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_Springsteen'] = base_data['Q1225r20'].apply(lambda x : fan_dict.get(x))
    cleaned_data['Fan_True_Stories'] = base_data['Q1225r21'].apply(lambda x : fan_dict.get(x))
    
    cleaned_data['TH_Qualified'] = base_data['Q1305r1']
    cleaned_data['HE_Qualified'] = base_data['Q1305r2']
    cleaned_data['Not_Qualified'] = base_data['Q1305r3']
    
    cleaned_data['Live_TV_Hrs'] = base_data['Q2000r1']
    cleaned_data['Radio_Stn_Hrs'] = base_data['Q2000r2']
    cleaned_data['Net_Usage_Hrs'] = base_data['Q2000r3']
    cleaned_data['Mobile_App_Web_Hrs'] = base_data['Q2000r4']
    cleaned_data['Newspaper_Magazine_Hrs'] = base_data['Q2000r5']
    cleaned_data['Mobile_Games_Hrs'] = base_data['Q2000r6']
    cleaned_data['Console_Games_Hrs'] = base_data['Q2000r7']
    cleaned_data['Movies_Buy_Rent_Hrs'] = base_data['Q2000r8']
    cleaned_data['Subscription_Streaming_Hrs'] = base_data['Q2000r9']
    
    cleaned_data['TV_Weekday_10am'] = base_data['Q2005r1c1']
    cleaned_data['TV_Weekday_5pm'] = base_data['Q2005r2c1']
    cleaned_data['TV_Weekday_8pm'] = base_data['Q2005r3c1']
    cleaned_data['TV_Weekday_11pm'] = base_data['Q2005r4c1']
    cleaned_data['TV_Weekday_2am'] = base_data['Q2005r5c1']
    cleaned_data['TV_Weekday_6am'] = base_data['Q2005r6c1']
    cleaned_data['TV_Weekday_None'] = base_data['Q2005r7c1']

    cleaned_data['TV_Weekend_10am'] = base_data['Q2005r1c2']
    cleaned_data['TV_Weekend_5pm'] = base_data['Q2005r2c2']
    cleaned_data['TV_Weekend_8pm'] = base_data['Q2005r3c2']
    cleaned_data['TV_Weekend_11pm'] = base_data['Q2005r4c2']
    cleaned_data['TV_Weekend_2am'] = base_data['Q2005r5c2']
    cleaned_data['TV_Weekend_6am'] = base_data['Q2005r6c2']
    cleaned_data['TV_Weekend_None'] = base_data['Q2005r7c2']
    
    cleaned_data['Channel_Large_Sports'] = base_data['Q2006r1'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_League_Sports'] = base_data['Q2006r2'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_TBS_TNT'] = base_data['Q2006r3'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_Discovery_History'] = base_data['Q2006r4'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_Food_Cooking'] = base_data['Q2006r5'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_CN_Disney'] = base_data['Q2006r6'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_Adult_Swim'] = base_data['Q2006r7'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_AMC'] = base_data['Q2006r8'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_Comedy_Central'] = base_data['Q2006r9'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_MTV_VH1'] = base_data['Q2006r10'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_NBC_ABC'] = base_data['Q2006r11'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_Fox_News'] = base_data['Q2006r12'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_MSNBC'] = base_data['Q2006r13'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_CNN'] = base_data['Q2006r14'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_FX'] = base_data['Q2006r15'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_Bravo_Ion'] = base_data['Q2006r16'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_CW_Freeform'] = base_data['Q2006r17'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_Hallmark_Lifetime'] = base_data['Q2006r18'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_TLC_Weather'] = base_data['Q2006r19'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_TV_Land'] = base_data['Q2006r20'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_SYFY'] = base_data['Q2006r21'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_Game_Show'] = base_data['Q2006r22'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_Boomerang'] = base_data['Q2006r23'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_BBC'] = base_data['Q2006r24'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_Sprout'] = base_data['Q2006r25'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_Oxygen_Up'] = base_data['Q2006r26'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_BET'] = base_data['Q2006r27'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    cleaned_data['Channel_Spanish'] = base_data['Q2006r28'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else ''))
    
    cleaned_data['Social_FB'] = base_data['Q2007r1']
    cleaned_data['Social_Celeb_Apps'] = base_data['Q2007r2']
    cleaned_data['Social_IG'] = base_data['Q2007r3']
    cleaned_data['Social_Snap'] = base_data['Q2007r4']
    cleaned_data['Social_Prime_Video'] = base_data['Q2007r5']
    cleaned_data['Social_Netflix'] = base_data['Q2007r6']
    cleaned_data['Social_Spotify'] = base_data['Q2007r7']
    cleaned_data['Social_LinkedIn'] = base_data['Q2007r8']
    cleaned_data['Social_TW'] = base_data['Q2007r9']
    cleaned_data['Social_Fitness_Apps'] = base_data['Q2007r10']
    cleaned_data['Social_Ride_Sharing'] = base_data['Q2007r11']
    cleaned_data['Social_Dating'] = base_data['Q2007r12']
    cleaned_data['Social_YT'] = base_data['Q2007r13']
    cleaned_data['Social_Tumblr'] = base_data['Q2007r14']
    cleaned_data['Social_Reddit'] = base_data['Q2007r15']
    cleaned_data['Social_Pinterest'] = base_data['Q2007r16']
    cleaned_data['Social_None'] = base_data['Q2007r17']
    
    cleaned_data['Pref_Radio'] = base_data['Q2008r1'].apply(lambda x : Q2008_dict.get(x))
    cleaned_data['Pref_News_Magazine'] = base_data['Q2008r2'].apply(lambda x : Q2008_dict.get(x))
    cleaned_data['Pref_Games_Mobile'] = base_data['Q2008r3'].apply(lambda x : Q2008_dict.get(x))
    cleaned_data['Pref_Games_Console'] = base_data['Q2008r4'].apply(lambda x : Q2008_dict.get(x))
    
    cleaned_data['Internet_Provider'] = base_data['Q2010'].apply(lambda x : isp_dict.get(x))
#    cleaned_data['Internet_Provider_Other'] = base_data['Q2010r20oe']
    
    cleaned_data['TV_Provider'] = base_data['Q2015'].apply(lambda x : tv_dict.get(x))
#    cleaned_data['TV_Provider_Other'] = base_data['Q2015r20oe']
    
    cleaned_data['Mobile_Provider'] = base_data['Q2025'].apply(lambda x : mobile_dict.get(x))
#    cleaned_data['Mobile_Provider_Other'] = base_data['Q2025r12oe']
    
    cleaned_data['Political_Affiliation'] = base_data['Q2105'].apply(lambda x : political_dict.get(x))
    cleaned_data['Religious_Flag'] = base_data['Q2115'].apply(lambda x : 'Very' if x==1 else ('Somewhat' if x==2
                                                                                             else 'Not at all'))
    cleaned_data['LGBTQ_Flag'] = base_data['Q2120'].apply(lambda x : 'Yes' if x==1 else ('No' if x==2 else 'NA'))    
    
    return cleaned_data

def decode_movie_response(base_data,cleaned_data):
    
    cleaned_data['TH_First_Choice_1'] = base_data['Q1650'].apply(lambda x : '' if (x==99 or pd.isnull(x)) else 'tt'+str(round(x)))
    cleaned_data['TH_First_Choice_2'] = base_data['Q1655'].apply(lambda x : '' if (x==99 or pd.isnull(x)) else 'tt'+str(round(x)))
    
    cleaned_data['TH_First_Choice_3'] = base_data['Q1660']
    cleaned_data['TH_First_Choice_Child'] = base_data['Q1665']
    
    cleaned_data['Curr_Movie_1'] = base_data['Q1435r1']
    cleaned_data['Curr_Movie_2'] = base_data['Q1435r2']
    cleaned_data['Curr_Movie_3'] = base_data['Q1435r3']
    cleaned_data['Curr_Movie_4'] = base_data['Q1435r4']
    cleaned_data['Curr_Movie_5'] = base_data['Q1435r5']
    cleaned_data['Curr_Movie_6'] = base_data['Q1435r6']
    cleaned_data['Curr_Movie_7'] = base_data['Q1435r7']
    cleaned_data['Curr_Movie_8'] = base_data['Q1435r8']
    
    cleaned_data['HE_First_Choice_1'] = base_data['QQ1780'].apply(lambda x : '' if (x==99 or pd.isnull(x)) else 'tt'+str(round(x)))
    
    cleaned_data['Q1785_r1'] = base_data['Q1785r1']
    cleaned_data['Q1785_r2'] = base_data['Q1785r2']
    cleaned_data['Q1785_r3'] = base_data['Q1785r3']
    cleaned_data['Q1785_r4'] = base_data['Q1785r4']
    cleaned_data['Q1785_r5'] = base_data['Q1785r5']
    cleaned_data['Q1785_r6'] = base_data['Q1785r6']
    cleaned_data['Q1785_r7'] = base_data['Q1785r7']
    cleaned_data['Q1785_r8'] = base_data['Q1785r8']
    cleaned_data['Q1785_r9'] = base_data['Q1785r9']
    cleaned_data['Q1785_r10'] = base_data['Q1785r10']
    cleaned_data['Q1785_r11'] = base_data['Q1785r11']
    cleaned_data['Q1785_r11oe'] = base_data['Q1785r11oe']
    
    cleaned_data['Q1790'] = base_data['Q1790']
    
    
    return cleaned_data

def decode_title_specific_questions_1(base_data):
    
    Q1628_dict = {'r1' : 'On Opening Weekend', 'r2' : 'After Opening Weekend', 'r3' : 'Buy DVD',
                 'r4' : 'Buy Blu Ray Disc/Combo', 'r5' : 'Buy 4K Ultra HD Combo', 'r6' : 'Buy Digital',
                 'r7' : 'Rent DVD/Blu Ray', 'r8' : 'Rent Digital', 'r9' : 'Order VOD/PPV - Cable' }
    Q1765_dict = {'r1' : 'In Theatre', 'r2' : 'Bought DVD', 'r3' : 'Bought Blu Ray Disc/Combo',
                 'r4' : 'Bought 4K Ultra HD Combo', 'r5' : 'Bought Digital', 'r6' : 'Rent DVD/Blu Ray',
                 'r7' : 'Rent Digital', 'r8' : 'Order VOD/PPV - Cable', 'r9' : 'None of the above' }
    Q1775_dict = {'r1' : 'Barnes & Noble', 'r2' : 'Best Buy', 'r3' : 'Costco', 'r4' : 'Target', 'r5' : 'Walmart',
                 'r6' : 'Local Drug Store', 'r7' : 'Local Grocery Store', 'r8' : 'Redbox', 'r9' : 'Other Retail',
                 'r10' : 'Amazon.com', 'r11' : 'BarnesandNoble.com', 'r12' : 'BestBuy.com', 'r13' : 'Costco.com',
                 'r14' : 'Target.com', 'r15' : 'Walmart.com', 'r16' : 'Movie Studio Website', 'r17' : 'Other Website',
                 'r9oe' : 'Other Retail_Ans', 'r17oe' : 'Other Website_Ans'}
    Q1776_dict = {'r1' : 'On Demand Cable/Satellite', 'r2' : 'iTunes', 'r3' : 'Amazon Prime Video',
                  'r4' : 'Playstation Store', 'r5' : 'Microsoft Movies & TV', 'r6' : 'Vudu', 'r7' : 'CinemaNow',
                  'r8' : 'Google Play/Google Movies', 'r9' : 'Fandango Now', 'r10' : 'YouTube', 'r11' : 'Redbox On Demand',
                  'r12' : 'Other Digital Retailer', 'r12oe' : 'Other Digital Retailer_Ans'}
    Q1780_dict = {'r1' : 'Looks good for all ages', 'r2' : 'Looks new & different', 'r3' : 'Has characters I want to see',
                  'r4' : 'Looks better than previous movies', 'r5' : 'Liked all previous movies in this series',
                  'r6' : 'Heard good things about this', 'r7' : 'I have to see in the theatre', 'r8' : 'Want to watch at home'}
    Q1795_dict = {'r1' : 'Decided to see another movie', 'r2' : 'Would rather see something new/different',
                  'r3' : 'Not a movie you have to watch right away', 'r4' : 'Did not know it was out in theatres',
                  'r5' : 'Did not have time', 'r6' : 'Did not have money', 'r7' : 'Not available in local theatre',
                  'r8' : 'Wait to see when it is available at home', 'r9' : 'Heard from friends/family it is not good',
                  'r10' : 'Reviews were not good', 'r11' : 'None of friends/family wanted to see',
                  'r12' : 'Want to see but child not interested', 'r13' : 'Child too young, will wait to see at home',
                  'r14' : 'Could not get a babysitter', 'r15' : 'Others',
                  'r16' : 'Decided to watch another movie/TV show on streaming service', 'r15oe' : 'Others_Ans'}
    Q1800_dict = {'r1' : 'Decided to see another movie at Home', 'r2' : 'Decided to see another movie in Theatres',
                  'r3' : 'Forgot about it', 'r4' : 'Did not have time', 'r5' : 'Did not have money',
                  'r6' : 'Not available at my preferred retailer', 'r7' : 'Waiting for price to drop',
                  'r8' : 'Heard from friends/family it is not good', 'r9' : 'Reviews were not good',
                  'r10' : 'None of friends/family wanted to see', 'r11' : 'Decided to start a new TV show instead',
                  'r12' : 'Waiting to get as gift', 'r13' : 'Already seen in Theatres'}
    Q1810_dict = {'r1' : 'Looks original & different', 'r2' : 'Looks fun & entertaining',
                  'r3' : 'Looks like it has impressive visuals/action', 'r4' : 'Fan of characters', 'r5' : 'Fan of brand/franchise',
                  'r6' : 'Good for date night', 'r7' : 'Good for girls night out', 'r8' : 'Whole family will enjoy it',
                  'r9' : 'Looks like it has to be seen on big screen', 'r10' : 'Looks intense/scary', 'r11' : 'Fan of cast',
                  'r12' : 'Fan of director', 'r13' : 'Looks dramatic/emotionally moving',
                  'r14' : 'I like movies based on true stories/events', 'r15' : 'Fan of book', 'r16' : 'Tired of movies like this',
                  'r17' : 'Has multicultural appeal', 'r18' : 'Will wait to stream'}  
    Q1828_dict = {'r1' : 'On Opening Weekend', 'r2' : 'After Opening Weekend', 'r3' : 'Buy DVD',
                 'r4' : 'Buy Blu Ray Disc/Combo', 'r5' : 'Buy 4K Ultra HD Combo', 'r6' : 'Buy Digital',
                 'r7' : 'Rent DVD/Blu Ray', 'r8' : 'Rent Digital', 'r9' : 'Order VOD/PPV - Cable',
                  'r10' : 'Rent Digital after 4 weeks'}
    
    column_list = base_data.columns.values
#    column_index = [index for index, name in enumerate(column_list) if (name.startswith('Q1628') | name.startswith('Q1765') | 
#                                                                        name.startswith('Q1775') | name.startswith('Q1776') | 
#                                                                        name.startswith('Q1780') | name.startswith('Q1795') | 
#                                                                        name.startswith('Q1800') | name.startswith('Q1810') |
#                                                                        name.startswith('Q1828'))]
    
    column_index = [index for index, name in enumerate(column_list) if (name.startswith('Q1810'))]
    column_index.append(1)
        
    subset_data = base_data.iloc[:,column_index].copy()
    subset_data.fillna(0, inplace = True)
    subset_data.set_index(['uuid'], inplace = True)
    subset_data = subset_data.stack().reset_index()
    subset_data.columns = ['uuid', 'Question_no','Response']
    
    pivot_data = pd.DataFrame()
        
    pivot_data[['Question','Title']] = subset_data['Question_no'].str.split('_', expand=True)
    pivot_data[['Title','Resp_No']] = pivot_data['Title'].str.split('r', expand=True)
    pivot_data['Resp_No'] = 'r' + pivot_data['Resp_No']
    
    #pivot_data['Resp_No'] = pivot_data['Title'].apply(lambda x : re.search('.*(r.*)', x).group(1))
    #pivot_data['Title'] = pivot_data['Title'].apply(lambda x : re.sub('r.*', '' ,x))
    pivot_data['uuid'] = subset_data['uuid']
    pivot_data['Response'] = subset_data['Response']
    
#    pivot_data['Resp_No'] = pivot_data.apply(lambda x : Q1628_dict.get(x['Resp_No']) if x['Question'] == 'Q1628' else
#                                            (Q1765_dict.get(x['Resp_No']) if x['Question'] == 'Q1765' else
#                                            (Q1775_dict.get(x['Resp_No']) if x['Question'] == 'Q1775' else
#                                            (Q1776_dict.get(x['Resp_No']) if x['Question'] == 'Q1776' else
#                                            (Q1780_dict.get(x['Resp_No']) if x['Question'] == 'Q1780' else
#                                            (Q1795_dict.get(x['Resp_No']) if x['Question'] == 'Q1795' else
#                                            (Q1800_dict.get(x['Resp_No']) if x['Question'] == 'Q1800' else
#                                            (Q1810_dict.get(x['Resp_No']) if x['Question'] == 'Q1810' else
#                                            (Q1828_dict.get(x['Resp_No']))))))))), axis=1)
    
    pivot_data['Resp_No'] = pivot_data.apply(lambda x : Q1810_dict.get(x['Resp_No']) if x['Question'] == 'Q1810' else None, axis = 1)
    
    return pivot_data

def decode_title_specific_questions_2(base_data):
    Q1445_dict = {1 : 'Heard of', 2 : 'Not Heard of'}
    Q1625_dict = {1 : 'Definitely interested in seeing', 2 : 'Probably interested in seeing', 3 : 'Might/Might not be interested',
                 4 : 'Probably not interested', 5 : 'Definitely not interested'}
    Q1630_dict = {1 : 'Definitely interested in taking child', 2 : 'Probably interested in taking child',
                 3 : 'Might/Might not be interested in taking child', 4 : 'Probably not interested in taking child',
                 5 : 'Definitely not interested in taking child'}
    Q1755_dict = {1 : 'Seen', 2 : 'Not yet seen'}
    Q1820_Q1830_dict = {1 : 'Very likely to rent', 2 : 'Somewhat likely to rent', 3 : 'Neither likely nor unlikely',
                  4 : 'Somewhat unlikely to rent', 5 : 'Very unlikely to rent'}
    QQ1785_QQ1790_dict = {1 : 'More than a month', 2 : 'Within 3-4 weeks', 3 : 'Within 1-2 weeks', 4 : 'Already available'}
    
    column_list = base_data.columns.values
#    column_index = [index for index, name in enumerate(column_list) if (name.startswith('Q1326') | name.startswith('Q1445') |
#                                                                        name.startswith('Q1625') | name.startswith('Q1630') |
#                                                                        name.startswith('Q1755') | name.startswith('Q1820') | 
#                                                                        name.startswith('Q1830') | name.startswith('QQ1785') | 
#                                                                        name.startswith('QQ1790'))]
    column_index = [index for index, name in enumerate(column_list) if (name.startswith('Q1625') | name.startswith('Q1445'))]
    column_index.append(1)
        
    subset_data = base_data.iloc[:,column_index].copy()
    subset_data.fillna(0, inplace = True)   
    subset_data.set_index(['uuid'], inplace = True)
    subset_data = subset_data.stack().reset_index()    
    subset_data.columns = ['uuid', 'Question_no','Response']
    
    pivot_data = pd.DataFrame()
    
    pivot_data[['Question','Title']] = subset_data['Question_no'].str.split('tt', expand=True)
    pivot_data['Title'] = 'tt' + pivot_data['Title']
    pivot_data['uuid'] = subset_data['uuid']
    pivot_data['Response'] = subset_data['Response']
    
#    pivot_data['Response'] = pivot_data.apply(lambda x : Q1445_dict.get(x['Response']) if x['Question'] == 'Q1445' else
#                                            (Q1625_dict.get(x['Response']) if x['Question'] == 'Q1625' else
#                                            (Q1630_dict.get(x['Response']) if x['Question'] == 'Q1630' else
#                                            (Q1755_dict.get(x['Response']) if x['Question'] == 'Q1755' else 
#                                            (Q1820_Q1830_dict.get(x['Response']) if (x['Question'] in ['Q1820','Q1830']) else
#                                            (QQ1785_QQ1790_dict.get(x['Response']) if (x['Question'] in ['QQ1785','QQ1790']) else
#                                             x['Response']))))), axis=1)
    
    pivot_data['Response'] = pivot_data.apply(lambda x: Q1445_dict.get(x['Response']) if x['Question'] == 'Q1445' else
                                              (Q1625_dict.get(x['Response']) if x['Question'] == 'Q1625' else x['Response']), axis = 1)

    return pivot_data

def decode_h_suffix_questions(base_data):
    column_list = base_data.columns.values
#    column_index = [index for index, name in enumerate(column_list) if (name.startswith('hFC') | name.startswith('hThInterest') |
#                                                                        name.startswith('hINTChild') | name.startswith('hQ1326') |
#                                                                        name.startswith('hTitlesSeen') | name.startswith('hIntNotSeen') | 
#                                                                        name.startswith('hhefc') | name.startswith('hpvod') |
#                                                                        name.startswith('hDescriptors') )]
    column_index = [index for index, name in enumerate(column_list) if (name.startswith('hDescriptors'))]
    column_index.append(1)
        
    subset_data = base_data.iloc[:,column_index].copy()
    subset_data.fillna(0, inplace = True)   
    subset_data.set_index(['uuid'], inplace = True)
    subset_data = subset_data.stack().reset_index()    
    subset_data.columns = ['uuid', 'Question_no','Response']
    
    pivot_data = pd.DataFrame()
    
    pivot_data[['Question','Title']] = subset_data['Question_no'].str.split('tt', expand=True)
    pivot_data['Title'] = 'tt' + pivot_data['Title']
    pivot_data['uuid'] = subset_data['uuid']
    pivot_data['Response'] = subset_data['Response']

    return pivot_data

def cleaned_part1(base_data, file_name, panel_coding, country_coding, state_coding):
    
    #start_time = datetime.datetime.now()
    df = decode_generic_columns(base_data, panel_coding, country_coding)
    df = decode_demographics(base_data, df, state_coding)
    df = decode_preferences(base_data,df)
    df = decode_movie_response(base_data,df)
    df.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\1. Request1 Q1810\Cleaned Data/" + file_name + "_Cleaned_part1.csv", index = False)
    #df.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\1. Request1 Q1810\Cleaned Data/" + file_name[0:7].strip().replace(" ", "_") + "_Cleaned_part1.csv", index = False)
    #print('Total completion time : ' + str(datetime.datetime.now() - start_time))

def cleaned_part2(base_data, file_name):
    #start_time = datetime.datetime.now()
    movie_specific_questions = decode_title_specific_questions_1(base_data)
    #print('Step 1 : ' + str(datetime.datetime.now() - start_time))
    #movie_specific_questions = movie_specific_questions.append(decode_title_specific_questions_2(base_data), sort = False)
    #print('Step 2 : ' + str(datetime.datetime.now() - start_time))
    movie_specific_questions = movie_specific_questions.append(decode_h_suffix_questions(base_data), 
                                                               sort = False)
    #print('Step 3 : ' + str(datetime.datetime.now() - start_time))
    movie_specific_questions = movie_specific_questions[['uuid','Question','Title','Resp_No','Response']]
    
    movie_specific_questions.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\1. Request1 Q1810\Cleaned Data/" + file_name + "_Cleaned_part2.csv", index= False)
    #movie_specific_questions.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\1. Request1 Q1810\Cleaned Data/" + file_name[0:7].strip().replace(" ", "_") + "_Cleaned_part2.csv", index= False)
    #print('Total completion time : ' + str(datetime.datetime.now() - start_time))
    
    