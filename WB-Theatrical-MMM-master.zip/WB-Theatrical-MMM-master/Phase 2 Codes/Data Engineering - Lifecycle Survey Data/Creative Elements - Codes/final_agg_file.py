# -*- coding: utf-8 -*-
"""
Created on Mon Sep 30 17:01:01 2019

@author: mukund
"""

import pandas as pd
import numpy as np
import datetime
import sys
sys.path.insert(0, r"C:/Users/mukund/Documents/Creative elements/Codes")
from Survey_data_cleaning import *
import os
from tqdm import tqdm

#Function to subset data by choosing top 4 metrics from each file and then concating the data to the final file
def agg_data_Q1810(agg_data, qname, file_name):
    part1 = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\0. Data\2. Processed files\Cleaned/" + file_name + "_Cleaned_part1.csv")
    part2 = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\0. Data\2. Processed files\Cleaned/" + file_name + "_Cleaned_part2.csv")
    part2_copy = part2.copy()
    part2_copy = part2_copy.loc[part2_copy['Question'] == qname]
    movie_dict = {'tt0385887' : 'Motherless Brooklyn', 'tt7286456' : 'Joker', 'tt5606664' : 'Doctor Sleep', 
                  'tt7349950' : 'It Chapter 2', 'tt5563334' : 'The Good Liar'}
    part2_copy = part2_copy.loc[part2_copy['Title'].isin(list(movie_dict.keys()))]
    merge_1 = pd.merge(left=part2_copy,
                       right = part1,
                       how = 'left', 
                       left_on = 'uuid', 
                       right_on = 'UID')
    merge_1.drop(columns = 'UID', axis = 1, inplace = True)
    merge_1['Title'] = merge_1['Title'].map(movie_dict)
    for i in merge_1['Title'].unique():
        subset_data = merge_1.loc[merge_1['Title'] == i]
        data_to_subset = pd.DataFrame()
        val = (subset_data.groupby('Resp_No')['Response'].sum().sort_values()) / (subset_data.groupby('Resp_No')['Response'].count().sort_values())
        df_resp = val.reset_index()
        data_to_subset = df_resp.sort_values('Response', ascending = False).nlargest(4, 'Response')
        final_subset = subset_data.loc[subset_data['Resp_No'].isin(list(data_to_subset['Resp_No']))].reset_index(drop = True)
        final_subset['Week No. File'] = file_name
        agg_data = pd.concat([agg_data, final_subset], axis = 0)
        
    return agg_data

#Function to concat all the files and then calculate top (4/5) metrics
def agg_data_Q1810_2(agg_data, qname, file_name):
    part1 = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\1. Request1 Q1810\Cleaned Data/" + file_name + "_Cleaned_part1.csv")
    part2 = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\1. Request1 Q1810\Cleaned Data/" + file_name + "_Cleaned_part2.csv")
    part2_copy = part2.copy()
    part2_copy = part2_copy.loc[part2_copy['Question'] == qname]
    movie_dict = {'tt4972582' : 'Split', 'tt7286456' : 'Joker', 'tt3315342' : 'Logan', 
                  'tt7349950' : 'It Chapter 2', 'tt3890160' : 'Baby Driver', 'tt1270797' : 'Venom', 
                  'tt6146586' : 'John Wick 3', 'tt7713068' : 'Birds Of Prey'}
    part2_copy = part2_copy.loc[part2_copy['Title'].isin(list(movie_dict.keys()))]
    merge_1 = pd.merge(left=part2_copy,
                       right = part1,
                       how = 'left', 
                       left_on = 'uuid', 
                       right_on = 'UID')
    merge_1.drop(columns = 'UID', axis = 1, inplace = True)
    merge_1['Title'] = merge_1['Title'].map(movie_dict)
    merge_1['Week No. File'] = file_name
    agg_data = pd.concat([agg_data, merge_1], axis = 0)
    return agg_data

def agg_data_Q1755(agg_data, qname, path_name):
    for file_name in tqdm([s for s in os.listdir(path_name) if ".csv" in s]):
        part2=pd.read_csv(path_name+r'/'+file_name)
        part2_copy = part2.copy()
        #part2_copy = part2_copy.loc[part2_copy['Question'] == qname]
        part2_copy['Week No. File'] = file_name[0:7]
        agg_data = pd.concat([agg_data, part2_copy], axis = 0)
    
    agg_data.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\2. Request2 Q1755\Q1625 & Q1445\Aggregate Data/agg_data_Q1625_Q1445.csv", index = False)


#Run this part of code to create First Aggregate file (agg_data_Q1810)
def first_file():
    start_time = datetime.datetime.now()
    data = pd.DataFrame()
    for i in range(36, 44):
        file_name = 'Week ' + str(i)
        qname = 'Q1810'
        data = agg_data_Q1810(data, qname, file_name)
    data.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\0. Data\2. Processed files\Cleaned\aggregate_data_updated.csv", index = False)
    print(str(datetime.datetime.now() - start_time))
    return data
    
#Run this part of code to create Second Aggregate file (agg_data_Q1810_2)
def second_file():
    start_time = datetime.datetime.now()
    data2 = pd.DataFrame()
    for i in tqdm(range(36, 46)):
        file_name = 'Week ' + str(i)
        qname = 'Q1810'
        data2 = agg_data_Q1810_2(data2, qname, file_name)
    final_data = pd.DataFrame()
    for i in tqdm(data2['Title'].unique()):
        subset_data = data2.loc[data2['Title'] == i]
        data_to_subset = pd.DataFrame()
        val = (subset_data.groupby('Resp_No')['Response'].sum().sort_values()) / (subset_data.groupby('Resp_No')['Response'].count().sort_values())
        df_resp = val.reset_index()
        data_to_subset = df_resp.sort_values('Response', ascending = False).nlargest(10, 'Response')
        final_subset = subset_data.loc[subset_data['Resp_No'].isin(list(data_to_subset['Resp_No']))].reset_index(drop = True)
        final_data = pd.concat([final_data, final_subset], axis = 0)
    
    #final_data.to_csv(r"C:\Users\mukund\Documents\Creative elements\Aggregate Data\aggregate_data_all_updated.csv", index = False)
    print(str(datetime.datetime.now() - start_time))
    return final_data


def clean_files_Q1810():
    start_time = datetime.datetime.now()
    panel_coding = pd.read_excel(r"C:\Users\mukund\Documents\Creative elements\Cleaned Data\Mapping File.xlsx", sheet_name = 'Panel Mapping')
    country_coding = pd.read_excel(r"C:\Users\mukund\Documents\Creative elements\Cleaned Data\Mapping File.xlsx", sheet_name = 'Country Mapping')
    state_coding = pd.read_excel(r"C:\Users\mukund\Documents\Creative elements\Cleaned Data\Mapping File.xlsx", sheet_name = 'State Mapping')
    for i in tqdm(range(36, 46)):
        file_name = 'Week ' + str(i)
        qname = 'Q1810'
        base_data = pd.read_excel(r"C:/Users/mukund/Affine Analytics Pvt Ltd/WB Theatrical - Documents/Data Engineering - Lifecycle Survey Data/Survey Questions to Answers Mapping/" + file_name + ".xlsx")
        cleaned_part1(base_data, file_name, panel_coding, country_coding, state_coding)
        cleaned_part2(base_data, file_name)
    print('Total completion time : ' + str(datetime.datetime.now() - start_time))

def call_Q1755():
    path_name = r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\2. Request2 Q1755\Q1625 & Q1445"
    qname = 'Q1755'
    agg_data = pd.DataFrame()
    agg_data_Q1755(agg_data, qname, path_name)
    

call_Q1755()
agg_func1 = first_file()
aggregate_data = second_file()
aggregate_data.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\1. Request1 Q1810\New Aggregate Files\aggregate_data_Q1810_Q1225.csv", index = False)
clean_files_Q1810()
#aggregate_data['Resp_No'].nunique()
#aggregate_data['Title'].unique()
#It_chap_2 = aggregate_data.loc[aggregate_data['Title'] == 'It Chapter 2']
#Joker = aggregate_data.loc[aggregate_data['Title'] == 'Joker']
#
#It_chap_2.to_csv(r"C:\Users\mukund\Documents\Creative elements\Aggregate Data\aggregate_data_IT_updated.csv", index = False)
#Joker.to_csv(r"C:\Users\mukund\Documents\Creative elements\Aggregate Data\aggregate_data_Joker_updated.csv", index = False)
#
#It_chap_2.groupby('Resp_No')['Response'].sum()/It_chap_2.loc[It_chap_2['Response'] == 1].groupby('Resp_No')['uuid'].nunique()
#
#aggregate_data.groupby(['Title', 'Resp_No'])
#movie = ['It Chapter 2', 'Joker']
#aggregate_data_copy = aggregate_data.loc[aggregate_data['Title'].isin(movie)]
#temp = aggregate_data_copy.groupby('Resp_No')['Response'].sum()/aggregate_data_copy.loc[aggregate_data_copy['Response'] == 1].groupby('Resp_No')['uuid'].nunique()

data = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\2. Request2 Q1755\Aggregate Data\agg_data_Q1755.csv")
subset_data = data.copy()
subset_data = subset_data.loc[~pd.isnull(subset_data['Response'])]
#temp2 = subset_data.groupby('Title')['uuid'].nunique()
subset_data_seen = subset_data.loc[subset_data['Response'] == 'Seen']
subset_data_notseen = subset_data.loc[subset_data['Response'] == 'Not yet seen']
temp2 = subset_data.groupby(['Title', 'Week No. File'])['uuid'].nunique().reset_index()
temp2.rename(columns = {'uuid' : 'Count of responders who responded to Q1755'}, inplace = True)
temp_seen = subset_data_seen.groupby(['Title', 'Week No. File'])['uuid'].nunique().reset_index()
temp_notseen = subset_data_notseen.groupby(['Title', 'Week No. File'])['uuid'].nunique().reset_index()
temp_seen.rename(columns = {'uuid' : 'Count of responders who have seen'}, inplace = True)
temp_notseen.rename(columns = {'uuid' : 'Count of responders who have not seen'}, inplace = True)

temp2 = pd.merge(left = temp2, 
                 right = temp_seen, 
                 how = 'left', 
                 left_on = ['Title', 'Week No. File'], 
                 right_on = ['Title', 'Week No. File'])

temp2 = pd.merge(left = temp2, 
                 right = temp_notseen, 
                 how = 'left', 
                 left_on = ['Title', 'Week No. File'], 
                 right_on = ['Title', 'Week No. File'])

temp2.to_excel(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\2. Request2 Q1755\Final Data\agg_data_Q1755.xlsx", index = False)


data2 = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\2. Request2 Q1755\Q1625 & Q1445\Aggregate Data\agg_data_Q1625_Q1445.csv")
Q1445_data = data2.loc[data2['Question'] == 'Q1445']
Q1625_data = data2.loc[data2['Question'] == 'Q1625']
Q1445_data = Q1445_data.loc[~pd.isnull(Q1445_data['Response'])]
Q1625_data = Q1625_data.loc[~pd.isnull(Q1625_data['Response'])]
Q1445_data_aware = Q1445_data.loc[Q1445_data['Response'] == 'Heard of']
temp_aided = Q1445_data_aware.groupby(['Title', 'Week No. File'])['uuid'].nunique().reset_index()
temp_aided.rename(columns = {'uuid' : 'Count of responders who are aware of the movie'}, inplace = True)

temp_interested = Q1625_data.groupby(['Title', 'Week No. File'])['uuid'].nunique().reset_index()
temp_interested.rename(columns = {'uuid' : 'Count of responders who are interested to watch the movie'}, inplace = True)
top3  = ['Definitely interested in seeing', 'Probably interested in seeing', 'Might/Might not be interested']
Q1625_data_top3_interest = Q1625_data.loc[Q1625_data['Response'].isin(top3)]
top3_interest = Q1625_data_top3_interest.groupby(['Title', 'Week No. File'])['uuid'].nunique().reset_index()
top3_interest.rename(columns = {'uuid' : 'Count of Top 3 responders who are interested to watch the movie'}, inplace = True)
temp_top3_interest = Q1625_data_top3_interest.groupby(['Title', 'Week No. File']).filter(lambda x: x.uuid.is_unique)

recontact_data = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\0. Data\1. As Received\Recontact All Waves.csv")
recontact_data['Week No. File'] = recontact_data['wave'].apply(lambda x: 'Week_' + str(x) if (len(str(x)) == 2) else 'Week_' + str(x) + '_')

recontact_data['HE Interest'] = recontact_data.apply(lambda x: np.nansum([x['Q1765_r2'], x['Q1765_r3'], 
                                                                         x['Q1765_r4'], x['Q1765_r5'], 
                                                                         x['Q1765_r6'], x['Q1765_r7'], 
                                                                         x['Q1765_r8']]), axis = 1)
recontact_data['HE Interest'] = recontact_data['HE Interest'].apply(lambda x: 1 if(x>0) else 0)

temp_recontact_HE_interest = recontact_data.loc[recontact_data['HE Interest'] == 1]
temp_recontact_TH_interest = recontact_data.loc[recontact_data['Q1765_r1'] == 1]
recontact_HE_interest_grouped = temp_recontact_HE_interest.groupby(['imdb_id', 'Week No. File']).filter(lambda x: x.uuid.is_unique)
recontact_TH_interest_grouped = temp_recontact_TH_interest.groupby(['imdb_id', 'Week No. File']).filter(lambda x: x.uuid.is_unique)

HE_interest_combined = pd.merge(left = temp_top3_interest, 
                                right = recontact_HE_interest_grouped, 
                                how = 'left', 
                                left_on = ['Title', 'Week No. File', 'uuid'], 
                                right_on = ['imdb_id', 'Week No. File', 'uuid'])

TH_interest_combined = pd.merge(left = temp_top3_interest, 
                                right = recontact_TH_interest_grouped, 
                                how = 'left', 
                                left_on = ['Title', 'Week No. File', 'uuid'], 
                                right_on = ['imdb_id', 'Week No. File', 'uuid'])

HE_interest_combined = HE_interest_combined.loc[~pd.isnull(HE_interest_combined['HE Interest'])]
TH_interest_combined = TH_interest_combined.loc[~pd.isnull(TH_interest_combined['Q1765_r1'])]
temp_combined = pd.merge(left = temp_aided, 
                         right = top3_interest, 
                         how = 'left', 
                         left_on = ['Title', 'Week No. File'], 
                         right_on = ['Title', 'Week No. File'])
temp_HE_interest_combined = HE_interest_combined.groupby(['Title', 'Week No. File'])['uuid'].nunique().reset_index()
temp_HE_interest_combined.rename(columns = {'uuid' : 'Count of responders interested and seen in HE'}, inplace = True)
temp_TH_interest_combined = TH_interest_combined.groupby(['Title', 'Week No. File'])['uuid'].nunique().reset_index()
temp_TH_interest_combined.rename(columns = {'uuid' : 'Count of responders interested and seen in TH'}, inplace = True)

temp_HE_interest_combined.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\2. Request2 Q1755\Q1625 & Q1445\Aggregate Data\HE Interest.csv", index = False)
temp_TH_interest_combined.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\2. Request2 Q1755\Q1625 & Q1445\Aggregate Data\TH Interest.csv", index = False)
temp_combined.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\2. Request2 Q1755\Q1625 & Q1445\Aggregate Data\aided and top 3.csv", index = False)

HE_interest_combined.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\2. Request2 Q1755\Q1625 & Q1445\Aggregate Data\HE_data.csv", index = False)
TH_interest_combined.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\2. Request2 Q1755\Q1625 & Q1445\Aggregate Data\TH data.csv", index = False)


