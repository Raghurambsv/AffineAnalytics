# importing module
import pandas as pd
import os
from tqdm import tqdm
import sys
sys.path.insert(0, r"C:/Users/mukund/Documents/Creative elements/Codes")
from Survey_data_cleaning import *
import datetime

panel_coding = pd.read_excel(r"C:\Users\mukund\Documents\Creative elements\Cleaned Data\Mapping File.xlsx", sheet_name = 'Panel Mapping')
country_coding = pd.read_excel(r"C:\Users\mukund\Documents\Creative elements\Cleaned Data\Mapping File.xlsx", sheet_name = 'Country Mapping')
state_coding = pd.read_excel(r"C:\Users\mukund\Documents\Creative elements\Cleaned Data\Mapping File.xlsx", sheet_name = 'State Mapping')

# importing files
path_name = r"C:/Users/mukund/Affine Analytics Pvt Ltd/WB Theatrical - Documents/Data Engineering - Lifecycle Survey Data/Survey Questions to Answers Mapping"
export_path = r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\2. Request2 Q1755\Q1625 & Q1445"
start_time = datetime.datetime.now()
for file_name in tqdm([s for s in os.listdir(path_name) if ".xlsx" in s]):
    if file_name[0:7].strip().replace(" ", "_") + "_Cleaned_part2.csv" in os.listdir(export_path):
        continue
    else:
    #    cleaned_part1(base_data=pd.read_excel(io=path_name+r'/'+file_name),
    #                  file_name=file_name, 
    #                  panel_coding = panel_coding, 
    #                  country_coding = country_coding, 
    #                  state_coding = state_coding)
        cleaned_part2(base_data=pd.read_excel(io=path_name+r'/'+file_name),
                      file_name=file_name)
print('Total completion time : ' + str(datetime.datetime.now() - start_time))

