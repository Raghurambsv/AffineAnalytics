# -*- coding: utf-8 -*-
"""
Created on Mon Oct 14 19:50:50 2019

@author: mukund
"""
import pandas as pd
import numpy as np

subset = aggregate_data.iloc[0:100]
aggregate_data = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\1. Request1 Q1810\New Aggregate Files\aggregate_data_Q1810_Q1225.csv")
aggregate_data_copy = aggregate_data.copy()
aggregate_data_copy.reset_index(drop = True, inplace = True)

aggregate_data_copy['Age_Bucket_3'] = aggregate_data_copy['Age_Bucket_2'].apply(lambda x: '18 to 24' if x == '18 to 24' else
                                                                      ('25 to 34' if x == '30 to 34' else
                                                                      ('25 to 34' if x == '25 to 29' else
                                                                      ('35 to 44' if x == '35 to 39' else
                                                                      ('35 to 44' if x == '40 to 44' else
                                                                      ('45+' if x == '45 to 49' else
                                                                      ('45+' if x == '50 to 59' else 
                                                                      ('45+' if x == '60 to 64' else '13 to 17'))))))))
#aggregate_data = aggregate_data.loc[~pd.isnull(aggregate_data['Age_Bucket_3'])]

aggregate_data_joker = aggregate_data_copy.loc[aggregate_data_copy['Title'] == 'Joker']
aggregate_data_joker = aggregate_data_joker.loc[~(aggregate_data_joker['Age_Bucket_3'] == '13 to 17')]

aggregate_data_joker.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\1. Request1 Q1810\New Aggregate Files\aggregate_data_Q1810_Q1225_joker.csv", index = False)

joker_top10 = (aggregate_data_joker.groupby('Resp_No')['Response'].sum().sort_values())/(aggregate_data_joker.groupby('Resp_No')['uuid'].nunique().sort_values())
joker_top10 = joker_top10.reset_index()
aggregate_data_IT2 = aggregate_data_copy.loc[aggregate_data_copy['Title'] == 'It Chapter 2']
IT2_top10 = (aggregate_data_IT2.groupby('Resp_No')['Response'].sum().sort_values())/(aggregate_data_IT2.groupby('Resp_No')['uuid'].nunique().sort_values())
IT2_top10 = IT2_top10.reset_index()

aggregate_data_joker_DCfans = (aggregate_data_joker.loc[(aggregate_data_joker['Response'] == 1) & (aggregate_data_joker['Fan_DC'] == 'Very much a fan')].groupby('Resp_No')['uuid'].nunique()) / (aggregate_data_joker.loc[aggregate_data_joker['Response'] == 1].groupby('Resp_No')['uuid'].nunique())
aggregate_data_joker_DCfans = aggregate_data_joker_DCfans.reset_index()
aggregate_data_joker_DCfans.rename(columns = {'uuid' : 'DC_fans_very_much'}, inplace = True)

norm_DCfans = aggregate_data_joker.loc[aggregate_data_joker['Fan_DC'] == 'Very much a fan']['uuid'].nunique() / aggregate_data_joker['uuid'].nunique()
norm_Horrorfans = aggregate_data_joker.loc[aggregate_data_joker['Fan_Horror'] == 'Very much a fan']['uuid'].nunique() / aggregate_data_joker['uuid'].nunique()

aggregate_data_joker_DCfans_all = (aggregate_data_joker.loc[aggregate_data_joker['Fan_DC'] == 'Very much a fan'].groupby('Resp_No')['uuid'].nunique()) / (aggregate_data_joker.loc[aggregate_data_joker['Response'] == 1].groupby('Resp_No')['uuid'].nunique())
aggregate_data_joker_DCfans_all = aggregate_data_joker_DCfans.reset_index()
aggregate_data_joker_DCfans_all.rename(columns = {'uuid' : 'DC_fans_very_much'}, inplace = True)

aggregate_data_joker_Horrorfans = (aggregate_data_joker.loc[(aggregate_data_joker['Response'] == 1) & (aggregate_data_joker['Fan_Horror'] == 'Very much a fan')].groupby('Resp_No')['uuid'].nunique()) / (aggregate_data_joker.loc[aggregate_data_joker['Response'] == 1].groupby('Resp_No')['uuid'].nunique())
aggregate_data_joker_Horrorfans = aggregate_data_joker_Horrorfans.reset_index()
aggregate_data_joker_Horrorfans.rename(columns = {'uuid' : 'Horror_fans_very_much'}, inplace = True)

aggregate_data_IT2_Horrorfans = (aggregate_data_IT2.loc[(aggregate_data_IT2['Response'] == 1) & (aggregate_data_IT2['Fan_Horror'] == 'Very much a fan')].groupby('Resp_No')['uuid'].nunique()) / (aggregate_data_IT2.loc[aggregate_data_IT2['Response'] == 1].groupby('Resp_No')['uuid'].nunique())
aggregate_data_IT2_Horrorfans = aggregate_data_IT2_Horrorfans.reset_index()
aggregate_data_IT2_Horrorfans.rename(columns = {'uuid' : 'Horror_fans_very_much'}, inplace = True)

aggregate_data_IT2.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\1. Requests\1. Request1 Q1810\New Aggregate Files\aggregate_data_Q1810_Q1225_IT2.csv", index = False)

temp = (aggregate_data_joker.groupby('Resp_No')['Response'].sum().sort_values())/(aggregate_data_joker.groupby('Resp_No')['uuid'].nunique().sort_values())
temp = temp.reset_index()
temp.rename(columns = {0 : 'Response'}, inplace = True)
joker_top3 = temp.sort_values('Response', ascending = False).nlargest(3, 'Response').reset_index(drop = True)
joker_top3.rename(columns = {'Response' : 'Interest'}, inplace = True)

joker_top10_updated = (aggregate_data_joker.groupby('Resp_No')['Response'].sum().sort_values())/(aggregate_data_joker.loc[aggregate_data_joker['Response'] == 1]['uuid'].nunique())
joker_unique_count = aggregate_data_joker.loc[aggregate_data_joker['Response'] == 1].groupby('Week No. File')['uuid'].nunique().reset_index()
aggregate_data_joker.loc[(aggregate_data_joker['Response'] == 1) & (aggregate_data_joker['Resp_No'] == 'Looks intense/scary')].groupby('Week No. File')['uuid'].nunique()

aggregate_data_joker.loc[(aggregate_data_joker['Response'] == 1) & (aggregate_data_joker['Resp_No'] == 'Fan of characters')].groupby(['Week No. File', 'Fan_DC'])['uuid'].nunique()


very_much_DCfans = aggregate_data_joker.loc[aggregate_data_joker['Fan_DC'] == 'Very much a fan']
temp_DCfans = very_much_DCfans.loc[very_much_DCfans['Response'] == 1].groupby('Resp_No')['uuid'].nunique().reset_index()

very_much_Horrorfans = aggregate_data_joker.loc[aggregate_data_joker['Fan_Horror'] == 'Very much a fan']
temp_Horrorfans = very_much_Horrorfans.loc[very_much_Horrorfans['Response'] == 1].groupby('Resp_No')['uuid'].nunique().reset_index()

