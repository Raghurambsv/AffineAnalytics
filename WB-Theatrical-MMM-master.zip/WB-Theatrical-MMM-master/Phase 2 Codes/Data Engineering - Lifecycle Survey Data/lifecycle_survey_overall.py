# -*- coding: utf-8 -*-
"""
Created on Thu Sep 12 12:30:00 2019

@author: mukund
"""

import pandas as pd
import numpy as np
from openpyxl import load_workbook

# Importing Raw aggregate survey data
survey = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\Aggregate Data\aggregate_request_wb_upload.csv")
survey_copy = survey.copy()

# Titles for which the deck is to be created
title = ['Motherless Brooklyn', 'IT Chapter Two', 'Doctor Sleep', 'Joker', 'The Kitchen']
# Overall
column_list_0 = ['OVERALL']
# Columns to select from the aggregate raw file that are common in the excel deck
column_list_1 = ['total', 'male', 'female', 'male_u25', 'male_o25', 'fem_u25', 'fem_o25', 
               'male_u35', 'male_o35', 'fem_u35', 'fem_o35', 'parent_u12', 'parent_13_17',  
               'age_17_24', 'age_25_34',	'age_35_44', 'age_45_54', 'age_55_64', 
               'white', 'black', 'hispanic', 'asian', 'his_male', 'his_female', 'his_male_u25', 
               'his_fem_u25', 'his_male_o25', 'his_fem_o25', 'his_male_u35', 'his_fem_u35', 'his_male_o35',  
               'his_fem_o35', 'aa_male', 'aa_female', 'aa_male_u25', 'aa_fem_u25', 'aa_male_o25', 
               'aa_fem_o25', 'aa_male_u35', 'aa_fem_u35', 'aa_male_o35', 'aa_fem_o35']

#Subsetting the data for the selected titles
survey_subset = survey_copy.loc[survey_copy['title'].isin(title)]
# Filters to apply
survey_subset = survey_subset.loc[survey_subset['base_condition'] == 'Home Entertainment Qualified']
survey_subset_def_int = survey_subset.loc[survey_subset['metric'] == 'Definitely Interested']
survey_subset_top2 = survey_subset.loc[survey_subset['metric'] == 'TOP2 Interested']

#Creating the file in the deck format provided for Kitchen from the aggregate file (Overall)
for sheet_index, i in enumerate(survey_subset['title'].unique()):        
    row_names_1 = ['H' + str(int(x)) if int(x)<0 else 'H+' + str(int(x)) for x in np.sort(survey_subset_def_int.loc[survey_subset_def_int['title'] == i, 'HE_window'].unique())]
    date_list = list(survey_subset_def_int.loc[survey_subset_def_int['title'] == i, 'field_date'].unique())
    res_1 = [i + ' ' + j for i, j in zip(row_names_1, date_list)]
    res_1 = ['Definitely Interested'] + res_1
    row_names_2 = ['H' + str(int(x)) if int(x)<0 else 'H+' + str(int(x)) for x in np.sort(survey_subset_top2.loc[survey_subset_top2['title'] == i, 'HE_window'].unique())]
    res_2 = [i + ' ' + j for i, j in zip(row_names_2, date_list)]
    res_2 = ['Metric Top 2 Box (Probably and Definitely Interested)'] + res_2
    df_1 = pd.DataFrame(columns = pd.MultiIndex.from_product([column_list_0, column_list_1]), index = res_1)
    df_2 = pd.DataFrame(columns = pd.MultiIndex.from_product([column_list_0, column_list_1]), index = res_2)
    for j in df_1.index:
        if(j == 'Definitely Interested'):
            continue
        else:
            number = int(j.split()[0].replace('H', ''))
            for k in column_list_1:
                df_1.loc[j, ('OVERALL', k)] = survey_subset_def_int.loc[(survey_subset_def_int['HE_window'] == number) & (survey_subset_def_int['title'] == i), k].values[0]
    
    for j in df_2.index:
        if(j == 'Metric Top 2 Box (Probably and Definitely Interested)'):
            continue
        else:
            number = int(j.split()[0].replace('H', ''))
            for k in column_list_1:
                df_2.loc[j, ('OVERALL', k)] = survey_subset_top2.loc[(survey_subset_top2['HE_window'] == number) & (survey_subset_top2['title'] == i), k].values[0]

    df = pd.concat([df_1, df_2], axis = 0)
    
    book = load_workbook(r"C:\Users\mukund\Desktop\Lifecycle Survey Data_HE.xlsx")
    with pd.ExcelWriter(path = r"C:\Users\mukund\Desktop\Lifecycle Survey Data_HE.xlsx", 
                        mode = 'w', engine = 'openpyxl') as writer:
        writer.book = book
        df.to_excel(writer, sheet_name = 'Q1625 ' + str(i), engine = 'openpyxl')
        

