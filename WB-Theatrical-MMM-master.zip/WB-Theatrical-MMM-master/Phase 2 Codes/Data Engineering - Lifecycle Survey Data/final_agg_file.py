# -*- coding: utf-8 -*-
"""
Created on Mon Sep 30 17:01:01 2019

@author: mukund
"""

import pandas as pd
import numpy as np
import datetime

#Function to subset data by choosing top 4 metrics from each file and then concating the data to the final file
def agg_data_Q1810(agg_data, qname, file_name):
    part1 = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\0. Data\2. Processed files\Cleaned/" + file_name + "_Cleaned_part1.csv")
    part2 = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\0. Data\2. Processed files\Cleaned/" + file_name + "_Cleaned_part2.csv")
    part2_copy = part2.copy()
    part2_copy = part2_copy.loc[part2_copy['Question'] == qname]
    movie_dict = {'tt0385887' : 'Motherless Brooklyn', 'tt7286456' : 'Joker', 'tt5606664' : 'Doctor Sleep', 
                  'tt7349950' : 'It Chapter 2', 'tt5563334' : 'The Good Liar'}
    part2_copy = part2_copy.loc[part2_copy['Title'].isin(list(movie_dict.keys()))]
    merge_1 = pd.merge(left=part2_copy,
                       right = part1,
                       how = 'left', 
                       left_on = 'uuid', 
                       right_on = 'UID')
    merge_1.drop(columns = 'UID', axis = 1, inplace = True)
    merge_1['Title'] = merge_1['Title'].map(movie_dict)
    for i in merge_1['Title'].unique():
        subset_data = merge_1.loc[merge_1['Title'] == i]
        data_to_subset = pd.DataFrame()
        val = (subset_data.groupby('Resp_No')['Response'].sum().sort_values()) / (subset_data.groupby('Resp_No')['Response'].count().sort_values())
        df_resp = val.reset_index()
        data_to_subset = df_resp.sort_values('Response', ascending = False).nlargest(4, 'Response')
        final_subset = subset_data.loc[subset_data['Resp_No'].isin(list(data_to_subset['Resp_No']))].reset_index(drop = True)
        final_subset['Week No. File'] = file_name
        agg_data = pd.concat([agg_data, final_subset], axis = 0)
        
    return merge_1

#Function to concat all the files and then calculate top (4/5) metrics
def agg_data_Q1810_2(agg_data, qname, file_name):
    part1 = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\0. Data\2. Processed files\Cleaned/" + file_name + "_Cleaned_part1.csv")
    part2 = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\0. Data\2. Processed files\Cleaned/" + file_name + "_Cleaned_part2.csv")
    part2_copy = part2.copy()
    part2_copy = part2_copy.loc[part2_copy['Question'] == qname]
    movie_dict = {'tt0385887' : 'Motherless Brooklyn', 'tt7286456' : 'Joker', 'tt5606664' : 'Doctor Sleep', 
                  'tt7349950' : 'It Chapter 2', 'tt5563334' : 'The Good Liar'}  
    part2_copy = part2_copy.loc[part2_copy['Title'].isin(list(movie_dict.keys()))]
    merge_1 = pd.merge(left=part2_copy,
                       right = part1,
                       how = 'left', 
                       left_on = 'uuid', 
                       right_on = 'UID')
    merge_1.drop(columns = 'UID', axis = 1, inplace = True)
    merge_1['Title'] = merge_1['Title'].map(movie_dict)
    merge_1['Week No. File'] = file_name
    agg_data = pd.concat([agg_data, merge_1], axis = 0)
    return agg_data

#Run this part of code to create First Aggregate file (agg_data_Q1810)
def first_file():
    start_time = datetime.datetime.now()
    data = pd.DataFrame()
    for i in range(36, 43):
        file_name = 'Week ' + str(i)
        qname = 'Q1810'
        data = agg_data_Q1810(data, qname, file_name)
    data.to_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\0. Data\2. Processed files\Cleaned\aggregate_data.csv", index = False)
    print(str(datetime.datetime.now() - start_time))
    return data
    
#Run this part of code to create Second Aggregate file (agg_data_Q1810_2)
def second_file():
    start_time = datetime.datetime.now()
    data2 = pd.DataFrame()
    for i in range(36, 43):
        file_name = 'Week ' + str(i)
        qname = 'Q1810'
        data2 = agg_data_Q1810_2(data2, qname, file_name)
    final_data = pd.DataFrame()
    for i in data2['Title'].unique():
        subset_data = data2.loc[data2['Title'] == i]
        data_to_subset = pd.DataFrame()
        val = (subset_data.groupby('Resp_No')['Response'].sum().sort_values()) / (subset_data.groupby('Resp_No')['Response'].count().sort_values())
        df_resp = val.reset_index()
        data_to_subset = df_resp.sort_values('Response', ascending = False).nlargest(5, 'Response')
        final_subset = subset_data.loc[subset_data['Resp_No'].isin(list(data_to_subset['Resp_No']))].reset_index(drop = True)
        final_data = pd.concat([final_data, final_subset], axis = 0)
    
    final_data.to_csv(r"C:\Users\mukund\Documents\Creative elements\Aggregate Data\aggregate_data_all.csv", index = False)
    print(str(datetime.datetime.now() - start_time))
    return final_data
    
aggregate_data = first_file()