# -*- coding: utf-8 -*-
"""
Created on Thu Sep 12 12:25:42 2019

@author: mukund
"""

import pandas as pd
import numpy as np
from openpyxl import load_workbook

# Importing raw norms data
norms_survey = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\01. Base Data - As received\05. Lifecycle Tracker Data\Norms\norm_request_wb_upload (1).csv")
norms_survey_copy = norms_survey.copy()

# Applying budget cuts based on the movies selected (Joker, It chapter 2, Motherless Brooklyn and Doctor Sleep)
norm_cut = ['$50M to $100M B.O. Grossing Titles', '$100M to $200M B.O. Grossing Titles']
# Formats
column_list_0 = ['EST', 'PST', 'iVOD', 'cVOD']
# Columns to select from the raw norms file that are common in the excel deck
column_list_1 = ['total', 'male', 'female', 'male_u25', 'male_o25', 'fem_u25', 'fem_o25', 
               'male_u35', 'male_o35', 'fem_u35', 'fem_o35', 'parent_u12', 'parent_13_17',  
               'age_17_24', 'age_25_34',	'age_35_44', 'age_45_54', 'age_55_64', 
               'white', 'black', 'hispanic', 'asian', 'his_male', 'his_female', 'his_male_u25', 
               'his_fem_u25', 'his_male_o25', 'his_fem_o25', 'his_male_u35', 'his_fem_u35', 'his_male_o35',  
               'his_fem_o35', 'aa_male', 'aa_female', 'aa_male_u25', 'aa_fem_u25', 'aa_male_o25', 
               'aa_fem_o25', 'aa_male_u35', 'aa_fem_u35', 'aa_male_o35', 'aa_fem_o35']

# Subsetting the data based on norms cuts and base conditions
norms_survey_subset = norms_survey_copy.loc[norms_survey_copy['norm_cut'].isin(norm_cut)]
norms_survey_subset = norms_survey_subset.loc[norms_survey_subset['base_condition'] == 'Home Entertainment Qualified']
norms_survey_subset.dropna(subset = ['HE_window'], inplace = True)

# Applying filters
norms_survey_subset_est = norms_survey_subset.loc[norms_survey_subset['metric'] == 'Interest to Buy EST']
norms_survey_subset_pst = norms_survey_subset.loc[norms_survey_subset['metric'] == 'Interest Any Buy Physical']
norms_survey_subset_ivod = norms_survey_subset.loc[norms_survey_subset['metric'] == 'Interest to Rent iVod']
norms_survey_subset_cvod = norms_survey_subset.loc[norms_survey_subset['metric'] == 'Interest to Rent cVod']

#Creating the file in the deck format provided for Kitchen from the raw norms file across formats
for sheet_index, i in enumerate(norms_survey_subset['norm_cut'].unique()):      
    row_names = ['H' + str(int(x)) if int(x)<0 else 'H+' + str(int(x)) for x in np.sort(norms_survey_subset_est.loc[norms_survey_subset_est['norm_cut'] == i, 'HE_window'].unique())]
    row_names = ['Interest to buy'] + row_names
    df = pd.DataFrame(columns = pd.MultiIndex.from_product([column_list_0, column_list_1]), index = row_names)
    for j in df.index:
        if(j == 'Interest to buy'):
            continue
        else:
            number = int(j.split()[0].replace('H', ''))
            for k in column_list_1:
                df.loc[j, ('EST', k)] = norms_survey_subset_est.loc[(norms_survey_subset_est['HE_window'] == number) & (norms_survey_subset_est['norm_cut'] == i), k].values[0]
                df.loc[j, ('PST', k)] = norms_survey_subset_pst.loc[(norms_survey_subset_pst['HE_window'] == number) & (norms_survey_subset_pst['norm_cut'] == i), k].values[0]
                df.loc[j, ('iVOD', k)] = norms_survey_subset_ivod.loc[(norms_survey_subset_ivod['HE_window'] == number) & (norms_survey_subset_ivod['norm_cut'] == i), k].values[0]
                df.loc[j, ('cVOD', k)] = norms_survey_subset_cvod.loc[(norms_survey_subset_cvod['HE_window'] == number) & (norms_survey_subset_cvod['norm_cut'] == i), k].values[0]
                
    book = load_workbook(r"C:\Users\mukund\Desktop\Lifecycle Survey Data_HE.xlsx")
    with pd.ExcelWriter(path = r"C:\Users\mukund\Desktop\Lifecycle Survey Data_HE.xlsx", 
                        mode = 'w', engine = 'openpyxl') as writer:
        writer.book = book
        df.to_excel(writer, sheet_name = 'norms ' + str(i.split()[0]), engine = 'openpyxl')