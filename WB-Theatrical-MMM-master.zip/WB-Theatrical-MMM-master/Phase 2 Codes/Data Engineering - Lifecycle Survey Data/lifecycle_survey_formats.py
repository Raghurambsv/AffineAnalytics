# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 13:52:22 2019

@author: mukund
"""

import pandas as pd
import numpy as np
from openpyxl import load_workbook

# Importing Raw aggregate survey data
survey = pd.read_csv(r"C:\Users\mukund\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\Aggregate Data\aggregate_request_wb_upload.csv")
survey_copy = survey.copy()

# Titles for which the deck is to be created
title = ['Motherless Brooklyn', 'IT Chapter Two', 'Doctor Sleep', 'Joker', 'The Kitchen']
# Formats
column_list_0 = ['EST', 'PST', 'iVOD', 'cVOD']
# Columns to select from the aggregate raw file that are common in the excel deck
column_list_1 = ['total', 'male', 'female', 'male_u25', 'male_o25', 'fem_u25', 'fem_o25', 
               'male_u35', 'male_o35', 'fem_u35', 'fem_o35', 'parent_u12', 'parent_13_17', 
               'age_17_24', 'age_25_34',	'age_35_44', 'age_45_54', 'age_55_64', 
               'white', 'black', 'hispanic', 'asian', 'his_male', 'his_female', 'his_male_u25', 
               'his_fem_u25', 'his_male_o25', 'his_fem_o25', 'his_male_u35', 'his_fem_u35', 'his_male_o35',  
               'his_fem_o35', 'aa_male', 'aa_female', 'aa_male_u25', 'aa_fem_u25', 'aa_male_o25', 
               'aa_fem_o25', 'aa_male_u35', 'aa_fem_u35', 'aa_male_o35', 'aa_fem_o35']

#Subsetting the data for the selected titles
survey_subset = survey_copy.loc[survey_copy['title'].isin(title)]
# Filters to apply
survey_subset = survey_subset.loc[survey_subset['base_condition'] == 'Home Entertainment Qualified']
survey_subset_est = survey_subset.loc[survey_subset['metric'] == 'Interest to Buy EST']
survey_subset_pst = survey_subset.loc[survey_subset['metric'] == 'Interest Any Buy Physical']
survey_subset_ivod = survey_subset.loc[survey_subset['metric'] == 'Interest to Rent iVod']
survey_subset_cvod = survey_subset.loc[survey_subset['metric'] == 'Interest to Rent cVod']

#Creating the file in the deck format provided for Kitchen from the aggregate file across formats
for sheet_index, i in enumerate(survey_subset['title'].unique()):        
    row_names = ['H' + str(int(x)) if int(x)<0 else 'H+' + str(int(x)) for x in np.sort(survey_subset_est.loc[survey_subset_est['title'] == i, 'HE_window'].unique())]
    date_list = list(survey_subset_est.loc[survey_subset_est['title'] == i, 'field_date'].unique())
    res = [i + ' ' + j for i, j in zip(row_names, date_list)]
    res = ['Interest to buy'] + res
    df = pd.DataFrame(columns = pd.MultiIndex.from_product([column_list_0, column_list_1]), index = res)
    for j in df.index:
        if(j == 'Interest to buy'):
            continue
        else:
            number = int(j.split()[0].replace('H', ''))
            for k in column_list_1:
                df.loc[j, ('EST', k)] = survey_subset_est.loc[(survey_subset_est['HE_window'] == number) & (survey_subset_est['title'] == i), k].values[0]
                df.loc[j, ('PST', k)] = survey_subset_pst.loc[(survey_subset_pst['HE_window'] == number) & (survey_subset_pst['title'] == i), k].values[0]
                df.loc[j, ('iVOD', k)] = survey_subset_ivod.loc[(survey_subset_ivod['HE_window'] == number) & (survey_subset_ivod['title'] == i), k].values[0]
                df.loc[j, ('cVOD', k)] = survey_subset_cvod.loc[(survey_subset_cvod['HE_window'] == number) & (survey_subset_cvod['title'] == i), k].values[0]
        
    if(sheet_index == 0):
        with pd.ExcelWriter(path = r"C:\Users\mukund\Desktop\Lifecycle Survey Data_HE.xlsx", 
                            mode = 'w', engine = 'openpyxl') as writer:
            df.to_excel(writer, sheet_name = 'Q1628 ' + str(i), engine = 'openpyxl')
    else:
        book = load_workbook(r"C:\Users\mukund\Desktop\Lifecycle Survey Data_HE.xlsx")
        with pd.ExcelWriter(path = r"C:\Users\mukund\Desktop\Lifecycle Survey Data_HE.xlsx", 
                            mode = 'w', engine = 'openpyxl') as writer:
            writer.book = book
            df.to_excel(writer, sheet_name = 'Q1628 ' + str(i), engine = 'openpyxl')

