import numpy as np
import pandas as pd
from scipy.optimize import minimize, dual_annealing, basinhopping

