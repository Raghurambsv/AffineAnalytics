# importing modules
import numpy as np
import pandas as pd
import statistics as stat
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor


def vif(
        X: pd.core.frame.DataFrame
) -> pd.core.frame.DataFrame:
    """
    Calculates variance inflation factor (VIF), for all variables

    Variance Inflation Factor (VIF) quantifies the severity of multicollinearity in an ordinary least squares regression
    analysis.
    It provides an index that measures how much the variance (the square of the estimate's standard deviation) of an
    estimated regression coefficient is increased because of collinearity

    Parameters
    ----------
    X : Pandas DataFrame
        Design matrix with all explanatory variables, as for example used in regression

    Returns
    -------
    Pandas DataFrame
        Variance inflation factor
    """

    # checking for intercept term. If not, adding intercept
    if 'const' in X.columns.values.tolist():
        X = sm.add_constant(X)

    # calculating VIF and converting result to a DataFrame
    vif = pd.DataFrame()
    vif["VIF"] = [
        variance_inflation_factor(X.values, i) for i in range(X.shape[1])
    ]
    vif["Variable"] = X.columns
    vif = vif.loc[
        vif['Variable'] != 'const',
        ["Variable", "VIF"]
    ].reset_index(drop=True)
    vif.sort_values(
        by=["VIF"],
        ascending=False,
        inplace=True
    )
    vif.reset_index(
        drop=True,
        inplace=True
    )

    return vif


def model_results(
        model,
        train_data: pd.core.frame.DataFrame,
        indep_vars: list,
        export_path: str = None
):
    """
    prepares model summary table

    Parameters
    ----------
    model
        model object developed
    train_data : Pandas DataFrame
        A DataFrame containing complete training data
    indep_vars : list
        A list of column names of independent variables
    export_path : Optional : string
        Complete path where you wish to export the final table

    Returns
    -------
    Pandas DataFrame
        Variance inflation factor
    """

    try:
        temp = pd.read_excel(
            io=export_path,
            sheet_name="model_performace",
            na_values=['#NA', '#N/A', '', ' ', 'na', 'NA']
        )
        iter = temp['Iteration Number'].max() + 1
    except:
        iter = 1

    result_table = pd.merge(left=pd.DataFrame(
        {
            'Iteration Number': iter,
            'Variable': model.params.index,
            'Estimate': model.params
        }
    ),
        right=pd.DataFrame(
            {
                'Variable': model.pvalues.index,
                'p-value': model.pvalues
            }
        ),
        how='left',
        left_on='Variable',
        right_on='Variable'
    )
    result_table = pd.merge(
        left=result_table,
        right=pd.DataFrame(
            {
                'Variable': model.tvalues.index,
                't-value': model.tvalues
            }
        ),
        how='left',
        left_on='Variable',
        right_on='Variable'
    )
    result_table = pd.merge(
        left=result_table,
        right=vif(
            X=train_data[indep_vars]
        ),
        how='left',
        left_on='Variable',
        right_on='Variable'
    )
    result_table['Adj R-sq'] = model.rsquared_adj

    print("Iteration No.: " + str(iter))
    if type(export_path) == str:
        if iter > 1:
            result_table = pd.concat(
                [
                    temp,
                    result_table
                ],
                axis=0
            )
        else:
            None
        with pd.ExcelWriter(
                path=export_path,
                mode='w',
                date_format='YYYY-MM-DD',
                datetime_format='DD-MMM-YYYY'
        ) as writer:
            result_table.to_excel(
                excel_writer=writer,
                index=False,
                sheet_name='Sheet1',
                engine='openpyxl'
            )

    return result_table
