# importing modules
import pandas as pd
import numpy as np


# Input the relevant root folder for codes
root_folder = "C:/Users/hari/PycharmProjects/WB-Theatrical-MMM/"
import sys
sys.path.insert(0,root_folder + "KPI/04.Modelling")
import all_models


# Importing the required Dataset
base_data = pd.read_excel(
    io=r"D:\Affine Analytics Pvt Ltd\WB Theatrical - Documents\07. Overall Model Refresh\04. Overall Model Refresh\01. Theatrical\Base AD BO Refresh V0.8.xlsx",
    sheet_name="Base AD",
    na_values=['#NA', '#N/A', 'NA', 'na', '', ' ']
)

# selecting independent variables
indep_vars = [
    # 'const',
    'Max_GS_30'
    ,'Mean_GS_30'
    ,'Max_wiki_30'
    ,'Mean_wiki_30'
    ,'growth_likes_30'
    ,'growth_views_30'
    ,'growth_comments_30'
    , 'Survey_Topbox'
    , 'Survey_ITST'
]

title_identifier_vars = [
     'IMDB_Title_Code'
    ,'Movie_Title'
    ,'Theatrical_Release_Date'
]


cont_var = [
    'BO_Revenue'
    ,'Max_GS_30'
    ,'Mean_GS_30'
    ,'Max_wiki_30'
    ,'Mean_wiki_30'
    ,'growth_likes_30'
    ,'growth_views_30'
    ,'growth_comments_30'
    ,'Survey_Topbox'
    ,'Survey_ITST'
]


# # ----------- LR Module Output -----------
# LR_Model_output, LR_whole_error, LR_train_error, LR_test_error = \
#     all_models.run_model(model="LR",
#                          root_folder = root_folder,
#                          data= base_data,
#                          dep_var= "BO_Revenue",
#                          indep_vars = indep_vars,
#                          title_identifier_vars = title_identifier_vars,
#                          cont_var = cont_var)



# # ----------- RF Module Output -----------
# RF_model, RF_Whole_model_WMAPE_error, RF_Train_model_WMAPE_error, RF_Test_model_WMAPE_error, RF_feat_importance = \
#     all_models.run_model(
#         model="RF",
#         root_folder = root_folder,
#         data=base_data,
#         indep_vars = indep_vars,
#         dep_var="BO_Revenue",
#         title_identifier_vars = title_identifier_vars,
#         n_estimators = 100,
#         max_depth= 7,
#         max_features = None,
#         random_state = 7)



# # ----------- LR Ensemble Module Output -----------
# LRE_ensemble_model, LRE_Whole_model_WMAPE_error, LRE_Train_model_WMAPE_error, LRE_Test_model_WMAPE_error, \
# LRE_train_r2_score, LRE_beta_coefficients_df, LRE_beta_coefficients_final = all_models.run_model(
#     model = "LRE",
#     root_folder = root_folder,
#     data=base_data,
#     indep_vars=indep_vars,
#     dep_var="BO_Revenue",
#     cont_var=cont_var,
#     title_identifier_vars=title_identifier_vars,
#     n_estimators=35,
#     max_features=6,
#     max_samples=1.0,
#     oob_score=True,
#     random_state=100
# )



# -----------  Grid Search LR Module Output -----------
LR_grid_model, LR_GRD_Whole_model_WMAPE_error, LR_GRD_Train_model_WMAPE_error, LR_GRD_Test_model_WMAPE_error,\
train_score, beta_coefficients_df, beta_coefficients_final = all_models.run_model(
    model = "LR_GRD",
    root_folder = root_folder,
    data=base_data,
    indep_vars=indep_vars,
    dep_var="BO_Revenue",
    cont_var=cont_var,
    title_identifier_vars=title_identifier_vars,
    n_estimator_range=np.arange(20, 100, 5),
    max_features_range=[2,3,4,5,6],
    max_samples=1.0,
    oob_score=True,
    random_state=100,
    n_jobs=-1,
    cv=5,
    verbose=1,
    scoring='r2')



# # # -----------  Grid Search RF Module Output -----------
# RF_GRD_model, RF_GRD_Whole_model_WMAPE_error, RF_GRD_Train_model_WMAPE_error, RF_GRD_Test_model_WMAPE_error, \
# RF_GRD_feat_importance = all_models.run_model(
#     model = "RF_GRD",
#     root_folder = root_folder,
#     data=base_data,
#     indep_vars=indep_vars,
#     dep_var="BO_Revenue",
#     cont_var=cont_var,
#     title_identifier_vars=title_identifier_vars,
#     n_estimator_range=np.arange(20, 200, 5),
#     max_features_range=[2,3,4,5,6],
#     max_depth = 7,
#     random_state=100,
#     n_jobs=-1,
#     cv=5,
#     verbose=1,
#     scoring='r2')






