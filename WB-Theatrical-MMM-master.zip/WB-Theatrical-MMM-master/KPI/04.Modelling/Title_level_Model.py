# importing modules
import numpy as np
import pandas as pd
import statsmodels.api as sm
import sys
# importing user defined modules
sys.path.insert(0, r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\KPI\05.Miscellaneous")
from model_objects import *

# importing dataset
base_data = pd.read_excel(
    io=r"D:\Affine Analytics Pvt Ltd\WB Theatrical - Documents\07. Overall Model Refresh\04. Overall Model Refresh\01. Theatrical\Base AD BO Refresh V0.8.xlsx",
    sheet_name="Base AD",
    na_values=['#NA', '#N/A', 'NA', 'na', '', ' ']
)
# adding constant term
base_data['const'] = 1



# log transformations
cont_var = [
    # 'BO_Revenue'
    # ,'Max_GS_30'
    # ,'Mean_GS_30'
    # ,'Max_wiki_30'
    # ,'Mean_wiki_30'
    # ,'growth_likes_30'
    # ,'growth_views_30'
    # ,'growth_comments_30'
    # ,'Survey_Topbox'
    # ,'Survey_ITST'

]
for col in cont_var:
    base_data[col] = np.log(base_data[col]+1)
del col


# # standardize - for std. betas
# for col in [x for x in cont_var if x!='BO_Revenue']:
#     base_data[col] = (base_data[col] - np.mean(base_data[col]))/np.std(base_data[col])
# del col

# selecting independent variables
indep_vars = [
    # 'const',
    # ,'th_week_number'
    'Max_GS_30'
    ,'Mean_GS_30'
    ,'Max_wiki_30'
    ,'Mean_wiki_30'
    ,'growth_likes_30'
    ,'growth_views_30'
    ,'growth_comments_30'
    , 'Survey_Topbox'
    , 'Survey_ITST'
]

title_identifier_vars = [
     'IMDB_Title_Code'
    ,'Movie_Title'
    ,'Theatrical_Release_Date'
]

# subset dataset
train_data = base_data.loc[
    (base_data['TH_Rel_Yr']>=2015) & (base_data['TH_Rel_Yr']<=2018),
    title_identifier_vars + ['BO_Revenue'] + indep_vars
].reset_index(drop=True)
test_data = base_data.loc[
    base_data['TH_Rel_Yr']>=2019,
    title_identifier_vars + ['BO_Revenue'] + indep_vars
].reset_index(drop=True)

# drop NA values
train_data.dropna(inplace=True)
train_data = train_data.reset_index(drop=True)
# for test set
test_data.dropna(inplace=True)
test_data = test_data.reset_index(drop=True)



# model development
model = sm.OLS(
    endog=train_data['BO_Revenue'],
    exog=train_data[indep_vars]
).fit()

# print model summary
print(model.summary())

# print VIF
print(vif(X=train_data[indep_vars]))

# exporting model predictions
train_data['predicted'] = model.predict(exog=train_data[indep_vars]).tolist()
train_data['predicted'] = np.exp(train_data['predicted'])-1
train_data['set'] = 'train'
test_data['predicted'] = model.predict(exog=test_data[indep_vars]).tolist()
test_data['predicted'] = np.exp(test_data['predicted'])-1
test_data['set'] = 'test'

predictions = pd.concat(
    [
        train_data,
        test_data
    ],
    axis=0
)

# Unlogging the logged variables above
for col in list(set(cont_var).intersection(predictions.columns.values.tolist())):
    predictions[col] = np.exp(predictions[col])-1

# Calculating the Absolute Error and Percentage Error
predictions['Absolute Error'] = np.absolute(
    predictions['BO_Revenue'] -
    predictions['predicted']
)
predictions['Percentage Error'] = (
        predictions['Absolute Error'] /
        predictions['BO_Revenue']
)

# WHOLE MODEL WMAPE Error
# title_level_predictions_wb = title_level_predictions.loc[title_level_predictions["Studio"]== "WB",:]
print("Whole Model error % is :",(100)*((predictions['Absolute Error'].sum())/(predictions['BO_Revenue'].sum())))
# Train WMAPE
predictions_train = predictions[predictions['set'] == "train"]
print("Train Model error % is :",(100)*((predictions_train['Absolute Error'].sum())/(predictions_train['BO_Revenue'].sum())))
# Test WMAPE
predictions_test = predictions[predictions['set'] == "test"]
print("Test Model error % is :",(100)*((predictions_test['Absolute Error'].sum())/(predictions_test['BO_Revenue'].sum())))



# with pd.ExcelWriter(
#         path=r"C:/Users/sandeep/Affine Analytics Pvt Ltd/WB Theatrical - Documents/04. Media Mix Modelling/Refresh 01/Analysis Results/temp/BO_Title Level_results13-03_3.xlsx",
#         mode='w',
#         date_format='YYYY-MM-DD',
#         datetime_format='DD-MMM-YYYY') as writer:
#     model_performace.to_excel(
#         excel_writer=writer,
#         index=False,
#         sheet_name='mode_performance',
#         engine='openpyxl')
#     predictions.drop('const', axis=1).to_excel(
#         excel_writer=writer,
#         index=False,
#         sheet_name='title-week',
#         engine='openpyxl')
#     title_level_predictions.to_excel(
#         excel_writer=writer,
#         index=False,
#         sheet_name='title',
#         engine='openpyxl')
