import numpy as np
import pandas as pd
import sys
sys.path.insert(0, r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\KPI\04.Modelling")
import all_models



model_LR = all_models.run_model(model="LR",data= train_data, indep_vars = indep_vars, dep_var= "BO_Revenue")
Y_pred_LR = np.exp(model_LR.predict(test_data[indep_vars]))-1

model_RF = all_models.run_model(model="RF", indep_vars = indep_vars, dep_var = "BO_Revenue", data=train_data,
                             n_estimators = 100, max_depth= 7, max_features = None, random_state = 7)
Y_pred_RF = pd.Series(np.exp(model_RF.predict(test_data[indep_vars]))-1)


# -------------

# Tree Based regression

from sklearn import tree
#Assumed you have, X (predictor) and Y (target) for training data set and x_test(predictor) of test_dataset
# Create tree object
model = tree.DecisionTreeRegressor() # here you can change the algorithm as gini or entropy (information gain) by default it is gini
# model = tree.DecisionTreeRegressor() for regression
# Train the model using the training sets and check score
model.fit(train_data[indep_vars],train_data["BO_Revenue"])
model.score(train_data[indep_vars],train_data["BO_Revenue"])
#Predict Output
predicted = pd.Series(model.predict(test_data[indep_vars]))


# Random Forest

# importing required libraries
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import accuracy_score

# shape of the dataset
print('\nShape of training data :',train_data.shape)
print('\nShape of testing data :',test_data.shape)

model= RandomForestRegressor()

# fit the model with the training data
model.fit(train_data[indep_vars],train_data["BO_Revenue"])

# number of trees used
print('Number of Trees used : ', model.n_estimators)

# predict the target on the train dataset
predict_train = pd.Series(model.predict(train_data[indep_vars]))
print('\nTarget on train data',predict_train)

# Accuray Score on train dataset
# accuracy_train = accuracy_score(train_data["BO_Revenue"],predict_train)

# exporting model predictions
train_data['predicted'] = pd.Series(model.predict(train_data[indep_vars]))
train_data['set'] = 'train'
test_data['predicted'] = pd.Series(model.predict(test_data[indep_vars]))
test_data['set'] = 'test'

predictions = pd.concat(
    [
        train_data,
        test_data
    ],
    axis=0
)


# Calculating the Absolute Error and Percentage Error
predictions['Absolute Error'] = np.absolute(
    predictions['BO_Revenue'] -
    predictions['predicted']
)
predictions['Percentage Error'] = (
        predictions['Absolute Error'] /
        predictions['BO_Revenue']
)

# WHOLE MODEL WMAPE Error
print("Whole Model error % is :",(100)*((predictions['Absolute Error'].sum())/(predictions['BO_Revenue'].sum())))
# Train WMAPE
predictions_train = predictions[predictions['set'] == "train"]
print("Train Model error % is :",(100)*((predictions_train['Absolute Error'].sum())/(predictions_train['BO_Revenue'].sum())))
# Test WMAPE
predictions_test = predictions[predictions['set'] == "test"]
print("Test Model error % is :",(100)*((predictions_test['Absolute Error'].sum())/(predictions_test['BO_Revenue'].sum())))


# compare LR Model calculations

indep_vars_2 = [
    'const',
    'Max_GS_30'
    ,'Mean_GS_30'
    ,'Max_wiki_30'
    ,'Mean_wiki_30'
    ,'growth_likes_30'
    ,'growth_views_30'
    ,'growth_comments_30'
    , 'Survey_Topbox'
    , 'Survey_ITST'
]
train_data["const"] = 1

# way 1
linear_model = LinearRegression()
linear_model.fit(train_data[indep_vars], train_data[dep_var])
linear_model.coef_
linear_model.intercept_
linear_model.score(train_data[indep_vars], train_data[dep_var])

# way 2
LR_model = sm.OLS(
    endog=train_data[dep_var],
    exog=train_data[indep_vars_2]
).fit()

# print model summary
print(LR_model.summary())

LR_model.rsquared


# ---------------------other parts as of July 28



# --------
# features_list = ['digital_by_budget_log',
#                  'non_digital_by_budget_log',
#                  'bo_window_log',
#                  'franchise_flag',
#                   'Horror',
#                   'Summer',
#                  'growth_views_60_log']

features_list = indep_vars.copy()


# X_train = train_data[features_list]
# y_train = train_data['revenue_by_budget_log']
# X_test = test_data[features_list]

X_train = train_data[features_list]
y_train = train_data[dep_var]
X_test = test_data[features_list]
Y_test = test_data[dep_var]





###### Model Tuning ######

n_estimator_range = np.arange(20, 205, 5)
max_features_range = [2,3,4,5, 6,7,8,9]
result_array = np.zeros(shape=(np.max(max_features_range)+1, np.max(n_estimator_range)+1))
result_array.shape
for n_estimator in tqdm(n_estimator_range):
    for max_feature in max_features_range:
        linear_model = LinearRegression()
        ensemble_model = BaggingRegressor(base_estimator=linear_model, max_samples=1.0, oob_score=True,
                                  random_state=100, n_estimators=n_estimator, max_features=max_feature)
        ensemble_model.fit(X_train, y_train)
        result_array[max_feature, n_estimator] = ensemble_model.oob_score_
best_result = np.unravel_index(np.argmax(result_array), result_array.shape)
result_array[best_result]


fig, ax = plt.subplots(nrows = len(max_features_range), ncols = 1, sharex=True)
for num, plot_num in enumerate(max_features_range):
    sns.lineplot(x=n_estimator_range, y=result_array[plot_num, np.arange(20, 205, 5)], ax=ax[num])
    ax[num].set_title("Max Features: "+str(plot_num))


# simple model ---------
ensemble_model = BaggingRegressor(base_estimator=linear_model, max_samples=1.0, oob_score=True,
                                  random_state=100, n_estimators=35, max_features=6)
ensemble_model.fit(X_train, y_train)

ensemble_model.score(X= X_test,y=Y_test)

ensemble_model.predict(X=X_test)

linear_model = LinearRegression()
linear_model.fit(train_data[indep_vars], train_data[dep_var])
linear_model.coef_


Y_pred_LRE = pd.Series(np.exp(ensemble_model.predict(X_test))-1)
test_data_2 = np.exp(test_data["BO_Revenue"])-1
Y_pred_LRE = pd.Series(np.exp(model_RF.predict(test_data[indep_vars]))-1)


# -----------

# Fitting Best Model


n_estimator_range = np.arange(20, 100, 5)
max_features_range = [2,3,4,5, 6,7,8,9]


linear_model = LinearRegression()
ensemble_model = BaggingRegressor(base_estimator=linear_model, oob_score=True,
                                  random_state=100,
                                  max_samples =1.0)
grid_model = GridSearchCV(ensemble_model, param_grid={'n_estimators':n_estimator_range,
                                                      'max_features': max_features_range},
                          n_jobs=-1, cv=5, verbose=1, scoring='neg_mean_absolute_error', )
grid_model.fit(X_train, y_train)


best_max_features = grid_model.best_params_['max_features']

best_n_estimators = grid_model.best_params_['n_estimators']


ensemble_model = BaggingRegressor(base_estimator=linear_model, oob_score=True,
                                  random_state=100,
                                  max_samples =1.0,
                                  n_estimators=best_n_estimators,
                                  max_features=best_max_features)
ensemble_model.fit(X_train, y_train)
print(best_max_features, best_n_estimators)

# Now for each sample extracting beta coefficients
beta_coefficients = np.zeros(shape=(best_n_estimators,len(features_list)+1))
train_predictions = np.zeros(shape=(best_n_estimators, train_data.shape[0]))
test_predictions = np.zeros(shape=(best_n_estimators, test_data.shape[0]))
model_oob_score = []
scale=True

for num, sample in enumerate(ensemble_model.estimators_samples_):
    subset_features = ensemble_model.estimators_features_[num]
    subset_features = np.sort(subset_features)
    print(num)
    subset_train_data_X = X_train.iloc[sample, subset_features]
    subset_train_data_y = y_train[sample]
    if scale:
        scaling_columns = [
                col for col in subset_train_data_X.columns if col not in title_identifier_vars]
        scaler = StandardScaler()
        subset_train_data_X[scaling_columns] = scaler.fit_transform(subset_train_data_X[scaling_columns])
        scaled_test_data = X_test.copy()
        scaled_test_data[scaling_columns] = scaler.transform(scaled_test_data[scaling_columns])
        linear_model.fit(subset_train_data_X, subset_train_data_y)
        test_predictions[num, :] = linear_model.predict(scaled_test_data.iloc[:,subset_features])
        subset_train_predictions = linear_model.predict(subset_train_data_X)
        train_predictions[num, sample] = subset_train_predictions
    else:
        linear_model.fit(subset_train_data_X, subset_train_data_y)
        subset_train_predictions = linear_model.predict(subset_train_data_X)
        train_predictions[num, sample] = subset_train_predictions
        test_predictions[num, :] = linear_model.predict(X_test.iloc[:,subset_features])

    subset_features = np.append(subset_features, len(features_list))
    all_beta = np.append(linear_model.coef_, linear_model.intercept_)
    beta_coefficients[num, subset_features] = all_beta
colnames = features_list.copy()
colnames.append('intercept')
denominator = np.sum(model_oob_score)
beta_coefficients_df = pd.DataFrame(data=beta_coefficients, columns=colnames)
#beta_coefficients_df = beta_coefficients_df.multiply(model_oob_score, axis='index')
#beta_coefficients_final = beta_coefficients_df.apply(lambda x: np.sum(x), axis=0)/denominator
beta_coefficients_final = beta_coefficients_df.apply(lambda x: np.nanmean(x), axis=0)

train_error_data = pd.DataFrame(data=train_predictions, columns=np.arange(0,train_data.shape[0]))
train_error_data.replace(0, np.nan, inplace=True)
#train_error_data = train_error_data.multiply(model_oob_score, axis='index')
#fitted_values = train_error_data.apply(lambda x: np.nansum(x), axis=0)/denominator
fitted_values = train_error_data.apply(lambda x: np.nanmean(x), axis=0)
train_data['fitted_values'] = np.exp(fitted_values)*train_data['Budget']


test_error_data = pd.DataFrame(data=test_predictions, columns=np.arange(0, test_data.shape[0]))
#test_error_data = test_error_data.multiply(model_oob_score, axis='index')
#predictions = test_error_data.apply(lambda x: np.nansum(x), axis=0)/denominator
predictions = test_error_data.apply(lambda x: np.mean(x), axis=0)

test_data['predictions'] = np.exp(predictions)*test_data['Budget']


def accuracy_metrics(y_true, y_pred):
    mae = np.mean(np.abs(y_true-y_pred))
    mape = np.mean(np.abs(y_true-y_pred)/y_true)
    wmape = np.sum(np.abs(y_true-y_pred))/np.sum(y_true)
    return[mae, mape, wmape]


train_metrics = accuracy_metrics(train_data['BO_Revenue'], train_data['fitted_values'])

test_metrics = accuracy_metrics(test_data['BO_Revenue'], test_data['predictions'])

final_df = pd.DataFrame(beta_coefficients_final)
final_df['train_mae'] = train_metrics[0]
final_df['train_mape'] = train_metrics[1]
final_df['train_wmape'] = train_metrics[2]
final_df['test_mae'] = test_metrics[0]
final_df['test_mape'] = test_metrics[1]
final_df['test_wmape'] = test_metrics[2]
final_df['n_estimators'] = best_n_estimators
final_df['max_features'] = best_max_features


# addn tries


train_error_data = pd.DataFrame(data=train_predictions, columns=np.arange(0,train_data.shape[0]))
train_error_data.replace(0, np.nan, inplace=True)
#train_error_data = train_error_data.multiply(model_oob_score, axis='index')
#fitted_values = train_error_data.apply(lambda x: np.nansum(x), axis=0)/denominator
fitted_values = train_error_data.apply(lambda x: np.nanmean(x), axis=0)
train_data['fitted_values'] = np.exp(fitted_values) - 1


test_error_data = pd.DataFrame(data=test_predictions, columns=np.arange(0, test_data.shape[0]))
#test_error_data = test_error_data.multiply(model_oob_score, axis='index')
#predictions = test_error_data.apply(lambda x: np.nansum(x), axis=0)/denominator
predictions_2 = test_error_data.apply(lambda x: np.mean(x), axis=0)
test_data['predicted_values'] = np.exp(predictions_2) - 1


final_df.to_csv("E:/WB_project/daily_tasks/17072019/ensemble_metrics_60_2015_18.csv")
train_data.to_csv("E:/WB_project/daily_tasks/17072019/ensemble_train_60_2015_18.csv", index=False)
test_data.to_csv("E:/WB_project/daily_tasks/17072019/ensemble_test_60_2015_18.csv", index=False)


#  rf grid serach

RF_model = RandomForestRegressor(
    n_estimators=70,
    max_features=2,
    max_depth=max_depth,
    random_state=random_state
).fit(X_train, y_train)
RF_model.score(train_data[indep_vars], train_data[dep_var])


# RF Grid p2

ensemble_model = BaggingRegressor(base_estimator=linear_model, oob_score=True,
                                  random_state=100,
                                  max_samples=1.0,
                                  n_estimators=best_n_estimators,
                                  max_features=best_max_features)
ensemble_model.fit(X_train, y_train)
print(best_max_features, best_n_estimators)

# Now for each sample extracting beta coefficients
beta_coefficients = np.zeros(shape=(best_n_estimators, len(features_list) + 1))
train_predictions = np.zeros(shape=(best_n_estimators, train_data.shape[0]))
test_predictions = np.zeros(shape=(best_n_estimators, test_data.shape[0]))

# if standardized beta's are required, make scale as True, else default False
scale = False

for num, sample in enumerate(ensemble_model.estimators_samples_):
    subset_features = ensemble_model.estimators_features_[num]
    subset_features = np.sort(subset_features)
    print("LR Model", num + 1, "is calculated")
    subset_train_data_X = X_train.iloc[sample, subset_features]
    subset_train_data_y = y_train[sample]
    if scale:
        scaling_columns = [
            col for col in subset_train_data_X.columns if col not in title_identifier_vars]
        scaler = StandardScaler()
        subset_train_data_X[scaling_columns] = scaler.fit_transform(subset_train_data_X[scaling_columns])
        scaled_test_data = X_test.copy()
        scaled_test_data[scaling_columns] = scaler.transform(scaled_test_data[scaling_columns])
        linear_model.fit(subset_train_data_X, subset_train_data_y)
        test_predictions[num, :] = linear_model.predict(scaled_test_data.iloc[:, subset_features])
        subset_train_predictions = linear_model.predict(subset_train_data_X)
        train_predictions[num, sample] = subset_train_predictions
    else:
        linear_model.fit(subset_train_data_X, subset_train_data_y)
        subset_train_predictions = linear_model.predict(subset_train_data_X)
        train_predictions[num, sample] = subset_train_predictions
        test_predictions[num, :] = linear_model.predict(X_test.iloc[:, subset_features])

    subset_features = np.append(subset_features, len(features_list))
    all_beta = np.append(linear_model.coef_, linear_model.intercept_)
    beta_coefficients[num, subset_features] = all_beta
colnames = features_list.copy()
colnames.append('intercept')
beta_coefficients_df = pd.DataFrame(data=beta_coefficients, columns=colnames)
beta_coefficients_df.replace(0, np.nan, inplace=True)
beta_coefficients_final = beta_coefficients_df.apply(lambda x: np.nanmean(x), axis=0)


# temp
cv_results = np.zeros(shape=(best_n_estimators,len(features_list)+1))
a = pd.DataFrame(grid_model.cv_results_)

pd.DataFrame(grid_model.cv_results_)
pd.DataFrame(grid_model.cv_results_["params"]),pd.DataFrame(grid_model.cv_results_["mean_test_score"], columns=["Accuracy"])

pd.concat([pd.DataFrame(grid_model.cv_results_["params"]),pd.DataFrame(grid_model.cv_results_["mean_test_score"], columns=["Accuracy"])],axis=1)

empty = pd.DataFrame()
del grid_scores
for j in range(len(grid_model.cv_results_['mean_test_score'])):
    grid_scores.append((grid_model.cv_results_['params'][j],
                        grid_model.cv_results_['mean_test_score'][j],
                        grid_model.cv_results_['std_test_score'][j]))

scores_sd = grid_model.cv_results_['std_test_score']
scores_sd = np.array(scores_sd)
    .reshape(len(grid_param_2),len(grid_param_1))

pd.DataFrame(grid_model.cv_results_['std_test_score'])

# rough
RF_model = RandomForestRegressor(
    n_estimators=50,
    max_depth=100,
    max_features=9,
    random_state=random_state
)

RF_model.fit(X=train_data[indep_vars],
             y=train_data[dep_var]
             )
RF_model.score(X=train_data[indep_vars],
               y=train_data[dep_var])

from sklearn.tree import DecisionTreeRegressor
ensemble_model = BaggingRegressor(base_estimator=DecisionTreeRegressor(criterion = "mse",
                                                                       max_depth = 100,
                                                                       max_features=9,
                                                                       random_state=random_state),
                                  oob_score=False,
                                  random_state=100,
                                  max_samples=1.0,
                                  n_estimators=50,
                                  max_features=9)
ensemble_model.fit(X=train_data[indep_vars],
                   y=train_data[dep_var])

ensemble_model.score(X=train_data[indep_vars],
                     y=train_data[dep_var])

