# importing modules
import numpy as np
import pandas as pd
import statsmodels.api as sm
import sys
# importing user defined modules
sys.path.insert(0, r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\KPI\05.Miscellaneous")
from model_objects import *

def LR_model(
        data,
        dep_var,
        indep_vars,
        title_identifier_vars,
        cont_var,
):

    # adding constant term used (for LR)
    data['const'] = 1

    # log transformations
    for col in cont_var:
        data[col] = np.log(data[col]+1)
    del col


    # # standardize - if reqd for standardized betas
    # for col in [x for x in cont_var if x!=dep_var]:
    #     data[col] = (data[col] - np.mean(data[col]))/np.std(data[col])
    # del col


    # subset tran and test dataset
    train_data = data.loc[
        (data['TH_Rel_Yr']>=2015) & (data['TH_Rel_Yr']<=2018),
        title_identifier_vars + [dep_var] + indep_vars
    ].reset_index(drop=True)
    test_data = data.loc[
        data['TH_Rel_Yr']>=2019,
        title_identifier_vars + [dep_var] + indep_vars
    ].reset_index(drop=True)

    # drop NA values for train set
    train_data.dropna(inplace=True)
    train_data = train_data.reset_index(drop=True)
    # drop NA values for test set
    test_data.dropna(inplace=True)
    test_data = test_data.reset_index(drop=True)



    # model development
    LR_model = sm.OLS(
        endog=train_data[dep_var],
        exog=train_data[indep_vars]
    ).fit()

    # print model summary
    print(LR_model.summary())

    # print VIF
    print(vif(X=train_data[indep_vars]))

    # exporting model predictions
    train_data['predicted'] = LR_model.predict(exog=train_data[indep_vars]).tolist()
    train_data['predicted'] = np.exp(train_data['predicted'])-1
    train_data['set'] = 'train'
    test_data['predicted'] = LR_model.predict(exog=test_data[indep_vars]).tolist()
    test_data['predicted'] = np.exp(test_data['predicted'])-1
    test_data['set'] = 'test'

    predictions = pd.concat(
        [
            train_data,
            test_data
        ],
        axis=0
    )

    # Un-logging the logged variables above
    for col in list(set(cont_var).intersection(predictions.columns.values.tolist())):
        predictions[col] = np.exp(predictions[col])-1

    # Calculating the Absolute Error and Percentage Error
    predictions['Absolute Error'] = np.absolute(
        predictions[dep_var] -
        predictions['predicted']
    )
    predictions['Percentage Error'] = (
            predictions['Absolute Error'] /
            predictions[dep_var]
    )

    # WHOLE MODEL WMAPE Error

    LR_Whole_model_WMAPE_error = (100)*((predictions['Absolute Error'].sum())/(predictions[dep_var].sum()))
    # Train WMAPE
    predictions_train = predictions[predictions['set'] == "train"]
    LR_Train_model_WMAPE_error = (100)*((predictions_train['Absolute Error'].sum())/(predictions_train[dep_var].sum()))
    # Test WMAPE
    predictions_test = predictions[predictions['set'] == "test"]
    LR_Test_model_WMAPE_error = (100)*((predictions_test['Absolute Error'].sum())/(predictions_test[dep_var].sum()))


    # title_level_predictions_wb = title_level_predictions.loc[title_level_predictions["Studio"]== "WB",:]
    print("Whole Model error % is :",(100)*((predictions['Absolute Error'].sum())/(predictions[dep_var].sum())))
    # Train WMAPE
    predictions_train = predictions[predictions['set'] == "train"]
    print("Train Model error % is :",(100)*((predictions_train['Absolute Error'].sum())/(predictions_train[dep_var].sum())))
    # Test WMAPE
    predictions_test = predictions[predictions['set'] == "test"]
    print("Test Model error % is :",(100)*((predictions_test['Absolute Error'].sum())/(predictions_test[dep_var].sum())))

    return LR_model,LR_Whole_model_WMAPE_error, LR_Train_model_WMAPE_error, LR_Test_model_WMAPE_error

