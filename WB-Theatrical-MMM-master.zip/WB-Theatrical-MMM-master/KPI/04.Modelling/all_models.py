# # checking for required modules
# import pkg_resources
# from subprocess import call
# required_packages = [
#     "statsmodels",
#     "sklearn",
#     "pandas",
#     "numpy"
# ]
# for package in required_packages:
#     if package in [  # list all packages with available latest stable updates
#         dist.project_name
#         for dist in pkg_resources.working_set
#     ]:
#         call(  # update all packages in shell
#             "pip install --upgrade " + package,
#             shell=True
#         )
#     else:
#         call(  # update all packages in shell
#             "pip install " + package,
#             shell=True
#         )

# importing modules
import pandas as pd
import numpy as np
import statsmodels.api as sm
from sklearn.ensemble import RandomForestRegressor
# import sys
# sys.path.insert(0, r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\KPI\04.Modelling")
# import

def run_model(
        model: str,
        root_folder: str,
        data: pd.core.frame.DataFrame,
        dep_var: str,
        indep_vars: list,
        title_identifier_vars: list = None,
        cont_var: list = None,
        n_estimators: int = 100,
        max_depth: int = None,
        max_features = None,
        random_state: int =None,
        max_samples: int = 1,
        oob_score: bool = False,
        n_estimator_range: list = None,
        max_features_range: list = None,
        n_jobs: int = None,
        cv: int = 5,
        verbose: int = 1,
        scoring: str = 'neg_mean_absolute_error'
):

    """
    Develops a model specified by the user

    Parameters
    ----------
    model: string
        Model to develop
        Options:
            LR: Linear Regression
            RF: Random Forrest
    dep_var: dependent variable
        Used in LR
    indep_vars: list
        Used in LR, RF
    n_estimators: int, default=100
        The number of trees in the forest.
    max_depth: int, default=None
        The maximum depth of the tree. If None, then nodes are expanded until all leaves are pure or until all leaves
        contain less than min_samples_split samples.
    max_features: {“auto”, “sqrt”, “log2”}, int or float, default=”auto”
        The number of features to consider when looking for the best split:
            - If int, then consider max_features features at each split.
            - If float, then max_features is a fraction and int(max_features * n_features) features are considered at
              each split.
            - If “auto”, then max_features=n_features.
            - If “sqrt”, then max_features=sqrt(n_features).
            - If “log2”, then max_features=log2(n_features).
            - If None, then max_features=n_features.
        Note: The search for a split does not stop until at least one valid partition of the node samples is found,
              even if it requires to effectively inspect more than max_features features.
    random_state: int or RandomState, default=None
        Controls both the randomness of the bootstrapping of the samples used when building trees (if bootstrap=True) and the sampling of the features to consider when looking for the best split at each node (if max_features < n_features). See Glossary for details.


    Returns
    -------
    A developed model that is specified by the client
    """

    if model=="LR":
        import sys
        sys.path.insert(0, root_folder + "KPI/04.Modelling")
        import LR
        LR_Model_output, LR_whole_error, LR_train_error, LR_test_error = LR.LR_model(
            data = data,
            dep_var = dep_var,
            indep_vars = indep_vars,
            title_identifier_vars = title_identifier_vars,
            cont_var = cont_var,
        )
        return LR_Model_output, LR_whole_error, LR_train_error, LR_test_error

    if model=="RF":

        import sys
        sys.path.insert(0, root_folder + "KPI/04.Modelling")
        import Random_Forest_Regression
        RF_model, RF_Whole_model_WMAPE_error, RF_Train_model_WMAPE_error, RF_Test_model_WMAPE_error, RF_feat_importance=\
            Random_Forest_Regression.RF_model_function(
                data=data,
                indep_vars=indep_vars,
                dep_var=dep_var,
                title_identifier_vars=title_identifier_vars,
                n_estimators=n_estimators,
                max_depth=max_depth,
                max_features=max_features,
                random_state=random_state
            )
        return RF_model, RF_Whole_model_WMAPE_error, RF_Train_model_WMAPE_error, RF_Test_model_WMAPE_error, RF_feat_importance

    if model=="LRE":

        import sys
        sys.path.insert(0, root_folder + "KPI/04.Modelling")
        import LR_ensemble
        LRE_ensemble_model, LRE_Whole_model_WMAPE_error, LRE_Train_model_WMAPE_error, LRE_Test_model_WMAPE_error,\
        LRE_train_r2_score, LRE_beta_coefficients_df, LRE_beta_coefficients_final = LR_ensemble.LR_ensemble_function(
            data=data,
            indep_vars=indep_vars,
            dep_var=dep_var,
            cont_var = cont_var,
            title_identifier_vars=title_identifier_vars,
            n_estimators=n_estimators,
            max_features=max_features,
            max_samples =max_samples,
            oob_score = oob_score,
            random_state=random_state
        )
        return LRE_ensemble_model, LRE_Whole_model_WMAPE_error, LRE_Train_model_WMAPE_error, LRE_Test_model_WMAPE_error,\
               LRE_train_r2_score, LRE_beta_coefficients_df, LRE_beta_coefficients_final

    if model=="LR_GRD":

        import sys
        sys.path.insert(0, root_folder + "KPI/04.Modelling")
        import LR_GridSearch

        LR_grid_model, LR_GRD_Whole_model_WMAPE_error, LR_GRD_Train_model_WMAPE_error, LR_GRD_Test_model_WMAPE_error, \
        train_r2_score, beta_coefficients_df, beta_coefficients_final = LR_GridSearch.GridSearch_LR_function(
            data = data,
            indep_vars = indep_vars,
            dep_var = dep_var,
            cont_var = cont_var,
            title_identifier_vars = title_identifier_vars,
            n_estimator_range = n_estimator_range,
            max_features_range = max_features_range,
            max_samples = max_samples,
            oob_score = oob_score,
            random_state = random_state,
            n_jobs = n_jobs,
            cv =cv,
            verbose = verbose,
            scoring = scoring
        )

        return LR_grid_model, LR_GRD_Whole_model_WMAPE_error, LR_GRD_Train_model_WMAPE_error, LR_GRD_Test_model_WMAPE_error,\
               train_r2_score, beta_coefficients_df, beta_coefficients_final

    if model=="RF_GRD":

        import sys
        sys.path.insert(0, root_folder + "KPI/04.Modelling")
        import RF_GridSearch

        RF_GRD_model, RF_GRD_Whole_model_WMAPE_error, RF_GRD_Train_model_WMAPE_error, RF_GRD_Test_model_WMAPE_error, \
        RF_GRD_feat_importance = RF_GridSearch.GridSearch_RF_function(
            data = data,
            indep_vars = indep_vars,
            dep_var = dep_var,
            cont_var = cont_var,
            title_identifier_vars = title_identifier_vars,
            n_estimator_range = n_estimator_range,
            max_features_range = max_features_range,
            max_depth = max_depth,
            random_state = random_state,
            n_jobs = n_jobs,
            cv =cv,
            verbose = verbose,
            scoring = scoring
        )

        return RF_GRD_model, RF_GRD_Whole_model_WMAPE_error, RF_GRD_Train_model_WMAPE_error,\
               RF_GRD_Test_model_WMAPE_error, RF_GRD_feat_importance




    # return LR_Model_output, LR_whole_error, LR_train_error, LR_test_error
    # return RF_model, RF_Whole_model_WMAPE_error, RF_Train_model_WMAPE_error, RF_Test_model_WMAPE_error, RF_feat_importance



# Initial one - can del later ----------------------------------------------------------------------------------------
#
# def run_model(
#         model: str,
#         data: pd.core.frame.DataFrame,
#         dep_var: str,
#         indep_vars: list,
#         n_estimators: int = 100,
#         max_depth: int = None,
#         max_features = None,
#         random_state: int =None
# ):
#
#     """
#     Develops a model specified by the user
#
#     Parameters
#     ----------
#     model: string
#         Model to develop
#         Options:
#             LR: Linear Regression
#             RF: Random Forrest
#     dep_var: dependent variable
#         Used in LR
#     indep_vars: list
#         Used in LR, RF
#     n_estimators: int, default=100
#         The number of trees in the forest.
#     max_depth: int, default=None
#         The maximum depth of the tree. If None, then nodes are expanded until all leaves are pure or until all leaves
#         contain less than min_samples_split samples.
#     max_features: {“auto”, “sqrt”, “log2”}, int or float, default=”auto”
#         The number of features to consider when looking for the best split:
#             - If int, then consider max_features features at each split.
#             - If float, then max_features is a fraction and int(max_features * n_features) features are considered at
#               each split.
#             - If “auto”, then max_features=n_features.
#             - If “sqrt”, then max_features=sqrt(n_features).
#             - If “log2”, then max_features=log2(n_features).
#             - If None, then max_features=n_features.
#         Note: The search for a split does not stop until at least one valid partition of the node samples is found,
#               even if it requires to effectively inspect more than max_features features.
#     random_state: int or RandomState, default=None
#         Controls both the randomness of the bootstrapping of the samples used when building trees (if bootstrap=True) and the sampling of the features to consider when looking for the best split at each node (if max_features < n_features). See Glossary for details.
#
#
#     Returns
#     -------
#     A developed model that is specified by the client
#     """
#
#     if model=="LR":
#
#         # Linear Regression model development
#         mod = sm.OLS(
#             endog=data[dep_var],
#             exog=data[indep_vars]
#         ).fit()
#
#     if model=="RF":
#
#         # Random Forest model development
#         mod = RandomForestRegressor(
#             n_estimators=n_estimators,
#             max_depth=max_depth,
#             max_features=max_features,
#             random_state=random_state
#         ).fit(
#             X=data[indep_vars],
#             y=data[dep_var]
#         )
#
#     return mod
#

