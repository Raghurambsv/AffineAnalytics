# importing modules
import pandas as pd
import numpy as np
import statsmodels.api as sm
from sklearn.ensemble import RandomForestRegressor


def RF_model_function(
        data,
        indep_vars,
        dep_var,
        title_identifier_vars,
        n_estimators,
        max_depth,
        max_features,
        random_state
):

    # # log transformations if reqd
    # for col in cont_var:
    #     data[col] = np.log(data[col] + 1)
    # del col

    # # standardize - if reqd for standardized betas
    # for col in [x for x in cont_var if x!=dep_var]:
    #     data[col] = (data[col] - np.mean(data[col]))/np.std(data[col])
    # del col

    # subset tran and test dataset
    train_data = data.loc[
        (data['TH_Rel_Yr'] >= 2015) & (data['TH_Rel_Yr'] <= 2018),
        title_identifier_vars + [dep_var] + indep_vars
    ].reset_index(drop=True)
    test_data = data.loc[
        data['TH_Rel_Yr'] >= 2019,
        title_identifier_vars + [dep_var] + indep_vars
    ].reset_index(drop=True)

    # drop NA values for train set
    train_data.dropna(inplace=True)
    train_data = train_data.reset_index(drop=True)
    # drop NA values for test set
    test_data.dropna(inplace=True)
    test_data = test_data.reset_index(drop=True)

    # model development

    # RF_model = RandomForestRegressor(
    #     n_estimators=n_estimators,
    #     max_depth=max_depth,
    #     max_features=max_features,
    #     random_state=random_state
    # ).fit(
    #     X=train_data[indep_vars],
    #     y=train_data[dep_var]
    # )

    RF_model = RandomForestRegressor(
        n_estimators=n_estimators,
        max_depth=max_depth,
        max_features=max_features,
        random_state=random_state
    )

    RF_model.fit(X=train_data[indep_vars],
                 y=train_data[dep_var]
                 )

    # predict the target on the train dataset
    # predict_train = pd.Series(RF_model.predict(train_data[indep_vars]))
    # print('\nTarget on train data', predict_train)

    # exporting model predictions
    train_data['predicted'] = pd.Series(RF_model.predict(train_data[indep_vars]))
    train_data['set'] = 'train'
    test_data['predicted'] = pd.Series(RF_model.predict(test_data[indep_vars]))
    test_data['set'] = 'test'

    predictions = pd.concat(
        [
            train_data,
            test_data
        ],
        axis=0
    )

    # Calculating the Absolute Error and Percentage Error
    predictions['Absolute Error'] = np.absolute(
        predictions[dep_var] -
        predictions['predicted']
    )
    predictions['Percentage Error'] = (
            predictions['Absolute Error'] /
            predictions[dep_var]
    )


    # WHOLE MODEL WMAPE Error

    RF_Whole_model_WMAPE_error = (100) * ((predictions['Absolute Error'].sum()) / (predictions[dep_var].sum()))
    # Train WMAPE
    predictions_train = predictions[predictions['set'] == "train"]
    RF_Train_model_WMAPE_error = (100) * (
            (predictions_train['Absolute Error'].sum()) / (predictions_train[dep_var].sum()))
    # Test WMAPE
    predictions_test = predictions[predictions['set'] == "test"]
    RF_Test_model_WMAPE_error = (100) * (
            (predictions_test['Absolute Error'].sum()) / (predictions_test[dep_var].sum()))

    # Print WMAPE
    print("RF Whole Model error % is :",RF_Whole_model_WMAPE_error)
    # Train WMAPE
    print("RF Train Model error % is :",RF_Train_model_WMAPE_error)
    # Test WMAPE
    print("RF Test Model error % is :",RF_Test_model_WMAPE_error)

    # R2 Score check on Train data
    Train_R2_Score = RF_model.score(X = train_data[indep_vars],
                                    y= train_data[dep_var])
    print("R2 score on Train data set is :",Train_R2_Score)
    # R2 Score check on Test data
    Test_R2_Score = RF_model.score(X = test_data[indep_vars],
                                   y= test_data[dep_var])
    print("R2 score on Test data set is :", Test_R2_Score)

    # Feature Importance calculation

    RF_feat_importance = pd.Series(RF_model.feature_importances_, index= train_data[indep_vars].columns)
    print("The Feature Importances of the variables are:\n",RF_feat_importance)
    feat_plot = RF_feat_importance.nlargest(10).plot(kind='barh')


    return RF_model, RF_Whole_model_WMAPE_error, RF_Train_model_WMAPE_error, RF_Test_model_WMAPE_error, RF_feat_importance

