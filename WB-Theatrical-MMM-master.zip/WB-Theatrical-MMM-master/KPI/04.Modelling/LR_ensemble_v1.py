import numpy as np
import pandas as pd
import statsmodels.api as sm

from sklearn.feature_selection import RFE
from sklearn.ensemble import BaggingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import r2_score, mean_absolute_error
# import matplotlib.pyplot as plt
# import seaborn as sns
# from tqdm import tqdm

# --------- Function -----------

def LR_ensemble_function(
        data,
        indep_vars,
        dep_var,
        cont_var,
        title_identifier_vars,
        n_estimators,
        max_features,
        max_samples,
        oob_score,
        random_state
):


    # log transformations
    for col in cont_var:
        data[col] = np.log(data[col] + 1)
    del col

    # # standardize - if reqd for standardized betas
    for col in [x for x in cont_var if x!=dep_var]:
        data[col] = (data[col] - np.mean(data[col]))/np.std(data[col])
    del col


    # subset train and test dataset
    train_data = data.loc[
        (data['TH_Rel_Yr'] >= 2015) & (data['TH_Rel_Yr'] <= 2018),
        title_identifier_vars + [dep_var] + indep_vars
    ].reset_index(drop=True)
    test_data = data.loc[
        data['TH_Rel_Yr'] >= 2019,
        title_identifier_vars + [dep_var] + indep_vars
    ].reset_index(drop=True)

    # drop NA values for train set
    train_data.dropna(inplace=True)
    train_data = train_data.reset_index(drop=True)
    # drop NA values for test set
    test_data.dropna(inplace=True)
    test_data = test_data.reset_index(drop=True)


    # Choosing the base estimator model for the Ensemble method: Here it is Linear Regression (using sklearn)
    linear_model = LinearRegression()

    # The Ensemble Model
    ensemble_model = BaggingRegressor(base_estimator=linear_model, max_samples=max_samples, oob_score=oob_score,
                                      random_state=random_state, n_estimators=n_estimators, max_features=max_features)

    ensemble_model.fit(train_data[indep_vars], train_data[dep_var])

    train_r2_score = ensemble_model.score(train_data[indep_vars], train_data[dep_var])
    print("coefficient of determination, R^2 of the train data is : ",train_r2_score)


    # exporting model predictions
    train_data['predicted'] = ensemble_model.predict(train_data[indep_vars]).tolist()
    train_data['predicted'] = np.exp(train_data['predicted']) - 1
    train_data['set'] = 'train'
    test_data['predicted'] = ensemble_model.predict(test_data[indep_vars]).tolist()
    test_data['predicted'] = np.exp(test_data['predicted']) - 1
    test_data['set'] = 'test'

    predictions = pd.concat(
        [
            train_data,
            test_data
        ],
        axis=0
    )

    # Un-logging the logged variables above
    for col in list(set(cont_var).intersection(predictions.columns.values.tolist())):
        predictions[col] = np.exp(predictions[col]) - 1

    # Calculating the Absolute Error and Percentage Error
    predictions['Absolute Error'] = np.absolute(
        predictions[dep_var] -
        predictions['predicted']
    )
    predictions['Percentage Error'] = (
            predictions['Absolute Error'] /
            predictions[dep_var]
    )

    # WHOLE MODEL WMAPE Error

    LRE_Whole_model_WMAPE_error = (100) * ((predictions['Absolute Error'].sum()) / (predictions[dep_var].sum()))
    print("Whole Model error % is :", LRE_Whole_model_WMAPE_error)
    # Train WMAPE
    predictions_train = predictions[predictions['set'] == "train"]
    LRE_Train_model_WMAPE_error = (100) * ((predictions_train['Absolute Error'].sum()) / (predictions_train[dep_var].sum()))
    print("Train Model error % is :",LRE_Train_model_WMAPE_error)
    # Test WMAPE
    predictions_test = predictions[predictions['set'] == "test"]
    LRE_Test_model_WMAPE_error = (100) * ((predictions_test['Absolute Error'].sum()) / (predictions_test[dep_var].sum()))
    print("Test Model error % is :",LRE_Test_model_WMAPE_error)


    # additional train and test sets for extracting the beta coefficients of the LR Models
    X_train = train_data[indep_vars]
    y_train = train_data[dep_var]
    X_test = test_data[indep_vars]
    Y_test = test_data[dep_var]
    features_list = indep_vars

    # Now for each sample extracting beta coefficients:
    beta_coefficients = np.zeros(shape=(n_estimators,len(features_list)+1))
    train_predictions = np.zeros(shape=(n_estimators, train_data.shape[0]))
    test_predictions = np.zeros(shape=(n_estimators, test_data.shape[0]))


    # if standardized beta's are required, make scale as True, else default False
    scale=False


    for num, sample in enumerate(ensemble_model.estimators_samples_):
        subset_features = ensemble_model.estimators_features_[num]
        subset_features = np.sort(subset_features)
        print("LR Model",num+1,"is calculated")
        subset_train_data_X = X_train.iloc[sample, subset_features]
        subset_train_data_y = y_train[sample]
        if scale:
            scaling_columns = [
                    col for col in subset_train_data_X.columns if col not in title_identifier_vars]
            scaler = StandardScaler()
            subset_train_data_X[scaling_columns] = scaler.fit_transform(subset_train_data_X[scaling_columns])
            scaled_test_data = X_test.copy()
            scaled_test_data[scaling_columns] = scaler.transform(scaled_test_data[scaling_columns])
            linear_model.fit(subset_train_data_X, subset_train_data_y)
            test_predictions[num, :] = linear_model.predict(scaled_test_data.iloc[:,subset_features])
            subset_train_predictions = linear_model.predict(subset_train_data_X)
            train_predictions[num, sample] = subset_train_predictions
        else:
            linear_model.fit(subset_train_data_X, subset_train_data_y)
            subset_train_predictions = linear_model.predict(subset_train_data_X)
            train_predictions[num, sample] = subset_train_predictions
            test_predictions[num, :] = linear_model.predict(X_test.iloc[:,subset_features])

        subset_features = np.append(subset_features, len(features_list))
        all_beta = np.append(linear_model.coef_, linear_model.intercept_)
        beta_coefficients[num, subset_features] = all_beta
    colnames = features_list.copy()
    colnames.append('intercept')
    beta_coefficients_df = pd.DataFrame(data=beta_coefficients, columns=colnames)
    beta_coefficients_df.replace(0, np.nan, inplace=True)
    beta_coefficients_final = beta_coefficients_df.apply(lambda x: np.nanmean(x), axis=0)

    # coeffs

    beta_coeffs =beta_coefficients_final

    stdevs = []
    for i in train_data[indep_vars].columns:
        stdev = train_data[i].std()
        stdevs.append(stdev)

    # method1 for feature importance
    beta = beta_coeffs.drop(['intercept']).abs()
    feature_importance_1 = pd.DataFrame({'variable': beta.index, 'std_beta': beta.values})

    feature_importance_1['importance'] = (feature_importance_1['std_beta'].div(beta.sum(axis=0))) * 100
    feature_importance_1 = (feature_importance_1[['variable', 'importance']])
    print(feature_importance_1)

    # method2
    beta = beta_coeffs.drop(['intercept']).abs()
    feature_importance_2 = pd.DataFrame({'variable': beta.index, 'std_beta': beta.values})
    feature_importance_2["stdev"] = np.array(stdevs).reshape(-1, 1)
    feature_importance_2['importance'] = feature_importance_2['std_beta'] * feature_importance_2['stdev']

    feature_importance_2['importance_normalized'] = (
                100 * feature_importance_2['importance'] / (feature_importance_2['importance'].max()))
    feature_importance_2 = (feature_importance_2[['variable', 'importance_normalized']])
    print(feature_importance_2)


    return ensemble_model, LRE_Whole_model_WMAPE_error, LRE_Train_model_WMAPE_error, LRE_Test_model_WMAPE_error,\
           train_r2_score, feature_importance_1,feature_importance_2




 