import numpy as np
import pandas as pd
 
from sklearn.linear_model import LinearRegression

from sklearn.feature_selection import RFE

# --------- Function -----------

def variable_selection(
        data,
        dep_var,
        indep_vars,
        title_identifier_vars,
        cont_var,
        model
):
    # adding constant term used (for LR)
    data['const'] = 1

    # log transformations
    for col in cont_var:
        data[col] = np.log(data[col] + 1)
    del col

    # # standardize - if reqd for standardized betas
    # for col in [x for x in cont_var if x!=dep_var]:
    #     data[col] = (data[col] - np.mean(data[col]))/np.std(data[col])
    # del col

    # subset tran and test dataset
    train_data = data.loc[
        (data['TH_Rel_Yr'] >= 2015) & (data['TH_Rel_Yr'] <= 2018),
        title_identifier_vars + [dep_var] + indep_vars
    ].reset_index(drop=True)
    test_data = data.loc[
        data['TH_Rel_Yr'] >= 2019,
        title_identifier_vars + [dep_var] + indep_vars
    ].reset_index(drop=True)

    # drop NA values for train set
    train_data.dropna(inplace=True)
    train_data = train_data.reset_index(drop=True)
    # drop NA values for test set
    test_data.dropna(inplace=True)
    test_data = test_data.reset_index(drop=True)




    #This number 13 is the max features that we have as input in our model

    nof_list = np.arange(1, 13)
    high_score = 0
    # Variable to store the optimum features
    nof = 0
    score_list = []
    for n in range(len(nof_list)):
        # model = LinearRegression()
        rfe = RFE(model, nof_list[n])
        X_train_rfe = rfe.fit_transform(train_data[indep_vars], train_data[dep_var])
        X_test_rfe = rfe.transform(test_data[indep_vars])
        model.fit(X_train_rfe, train_data[dep_var])
        score = model.score(X_test_rfe, test_data[dep_var])
        score_list.append(score)
        if (score > high_score):
            high_score = score
            nof = nof_list[n]

    print("Optimum number of features: %d" % nof)
    print("Score with %d features: %f" % (nof, high_score))

    # Now we got the best number of features (nof) we need to find out the list of best features
    cols = list(train_data[indep_vars].columns)
    #model = LinearRegression()
    # Initializing RFE model
    rfe = RFE(model, nof)
    # Transforming data using RFE
    X_rfe = rfe.fit_transform(test_data[indep_vars], test_data[dep_var])
    # Fitting the data to model
    model.fit(X_rfe, test_data[dep_var])

    temp = pd.Series(rfe.support_, index=cols)
    RANKS =pd.Series(rfe.ranking_,index=cols)
    selected_features_rfe = pd.concat([temp,RANKS],axis=1)
    #selected_features_rfe = temp[temp == True].index
    print(selected_features_rfe)









