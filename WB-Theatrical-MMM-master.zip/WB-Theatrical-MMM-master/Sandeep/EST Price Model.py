# importing python modules
import numpy as np
import pandas as pd
import statsmodels.api as sm
import sys
# importing user defined modules
sys.path.insert(0, r"C:\Users\Sandeep Sanyal\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Rohan's Box Folder\WB Home Entertainment\3) HE Forecasting codes and Analytical Data\codes\user_defined_functions")
import model_objects
sys.path.insert(0, r"C:\Users\Sandeep Sanyal\PycharmProjects\WB-Theatrical-MMM\Phase 2 Codes\02. Base AD Creation")
import HE_format_level_Base_AD

HE_units_data = HE_format_level_Base_AD.he_base_ad_creation(
        root_folder=r"C:/Users/Sandeep Sanyal/PycharmProjects/WB-Theatrical-MMM",
        sharepoint_path = r"C:/Users/Sandeep Sanyal/Affine Analytics Pvt Ltd/WB Theatrical - Documents",
        studio="WB",
        sale="Units",
        media="EST",
        export_path_user=False
)
HE_revenue_data = HE_format_level_Base_AD.he_base_ad_creation(
        root_folder=r"C:/Users/Sandeep Sanyal/PycharmProjects/WB-Theatrical-MMM",
        sharepoint_path = r"C:/Users/Sandeep Sanyal/Affine Analytics Pvt Ltd/WB Theatrical - Documents",
        studio="WB",
        sale="Revenue",
        media="EST",
        export_path_user=False
)

HE_sales_data = pd.merge(
        left=HE_revenue_data,
        right=HE_units_data,
        how="left",
        left_on=[
                "IMDB Title Code",
                "IMDB Title Name",
                "Studio",
                "Theatrical Release Date",
                "EST Release Date",
                "Week Start Date",
                "Theatrical Week Number",
                "EST Week Number",
                "Theatrical to EST Window",
                "EST to iVOD Window",
                "EST to VOD Window",
                "EST to PST Window"
        ],
        right_on=[
                "IMDB Title Code",
                "IMDB Title Name",
                "Studio",
                "Theatrical Release Date",
                "EST Release Date",
                "Week Start Date",
                "Theatrical Week Number",
                "EST Week Number",
                "Theatrical to EST Window",
                "EST to iVOD Window",
                "EST to VOD Window",
                "EST to PST Window"
        ]
)

HE_sales_data.sort_values(
        by=[
                "Theatrical Release Date",
                "EST Release Date",
                "IMDB Title Name",
                "Week Start Date"
        ],
        ascending=[
                False,
                False,
                True,
                False
        ],
        inplace=True
)

HE_sales_data["EST Price"] = HE_sales_data["EST Revenue"] / HE_sales_data["EST Units"]

base_data = pd.merge(
        left=pd.read_excel(
                io=r"C:\Users\Sandeep Sanyal\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Rohan's Box Folder\WB Home Entertainment\3) HE Forecasting codes and Analytical Data\Modelling AD - HE Formats.xlsx",
                sheet_name="Modelling AD",
                na_values=['#NA', '#N/A', 'NA', 'na', '', ' ']
        ),
        right=HE_sales_data[["IMDB Title Code", "Week Start Date", "EST Price"]],
        how="left",
        left_on=["IMDB Title Code", "Week Start Date"],
        right_on=["IMDB Title Code", "Week Start Date"]
)

base_data.dropna(
        subset=["EST Price"],
        axis=0,
        inplace=True
)

# helping python to understand the date format for column "Theatrical Release Date & EST Release Date"
base_data['Theatrical Release Date'] = pd.to_datetime(
    arg=base_data['Theatrical Release Date'],
    format="%Y-%m-%d",
    errors="coerce"
)
base_data['EST Release Date'] = pd.to_datetime(
    arg=base_data['EST Release Date'],
    format="%Y-%m-%d",
    errors="coerce"
)

# print WB & NonWB title count
print("Initial Title Counts: ")
print("# WB Title: " + str(len(base_data.loc[base_data["Studio"] == "WB", "IMDB Title Code"].unique())))
print("# NonWB Title: " + str(len(base_data.loc[base_data["Studio"] == "NonWB", "IMDB Title Code"].unique())))
print("Total: " + str(len(base_data["IMDB Title Code"].unique())))



# Subsetting dataset

# Selecting data for weeks required (first 13 weeks of data required)
base_data = base_data.loc[(base_data['EST Week Number'] >= 1) & (base_data['EST Week Number'] <= 13), :]

# print WB & NonWB title count
print("Selecting data for weeks required (first 13 weeks of data required)")
print("# WB Title: " + str(len(base_data.loc[base_data["Studio"] == "WB", "IMDB Title Code"].unique())))
print("# NonWB Title: " + str(len(base_data.loc[base_data["Studio"] == "NonWB", "IMDB Title Code"].unique())))
print("Total: " + str(len(base_data["IMDB Title Code"].unique())))


# Keeping weeks having sales > 0 Units
base_data = base_data.loc[base_data["EST Units"] > 0, :]

# print WB & NonWB title count
print("# Keeping weeks having sales > 0 Units")
print("# WB Title: " + str(len(base_data.loc[base_data["Studio"] == "WB", "IMDB Title Code"].unique())))
print("# NonWB Title: " + str(len(base_data.loc[base_data["Studio"] == "NonWB", "IMDB Title Code"].unique())))
print("Total: " + str(len(base_data["IMDB Title Code"].unique())))


# Keeping titles with Total BO Revenue > $25 Million
base_data = base_data.loc[base_data["BO Revenue (Total)"] > 25000000, :]

# print WB & NonWB title count
print("Keeping titles with Total BO Revenue > $25 Million")
print("# WB Title: " + str(len(base_data.loc[base_data["Studio"] == "WB", "IMDB Title Code"].unique())))
print("# NonWB Title: " + str(len(base_data.loc[base_data["Studio"] == "NonWB", "IMDB Title Code"].unique())))
print("Total: " + str(len(base_data["IMDB Title Code"].unique())))


# Dropping titles with missing metadata
base_data.dropna(
    subset=["SOURCE"],
    axis=0,
    inplace=True
)

# print WB & NonWB title count
print("Dropping titles with missing metadata")
print("# WB Title: " + str(len(base_data.loc[base_data["Studio"] == "WB", "IMDB Title Code"].unique())))
print("# NonWB Title: " + str(len(base_data.loc[base_data["Studio"] == "NonWB", "IMDB Title Code"].unique())))
print("Total: " + str(len(base_data["IMDB Title Code"].unique())))


# Dropping titles with Missing Google Search Volume
base_data.dropna(
    subset=["Google Search Volume (Mean)"],  # dropping looking at "Google Search Volume (Mean)" column
    axis=0,
    inplace=True
)

# print WB & NonWB title count
print("Dropping titles with Missing Google Search Volume")
print("# WB Title: " + str(len(base_data.loc[base_data["Studio"] == "WB", "IMDB Title Code"].unique())))
print("# NonWB Title: " + str(len(base_data.loc[base_data["Studio"] == "NonWB", "IMDB Title Code"].unique())))
print("Total: " + str(len(base_data["IMDB Title Code"].unique())))


# Keeping titles with Number of Theaters Released in > 0
base_data = base_data.loc[base_data["Number of Theaters Released in"] > 0, :]

# print WB & NonWB title count
print("Keeping titles with Number of Theaters Released in > 0")
print("# WB Title: " + str(len(base_data.loc[base_data["Studio"] == "WB", "IMDB Title Code"].unique())))
print("# NonWB Title: " + str(len(base_data.loc[base_data["Studio"] == "NonWB", "IMDB Title Code"].unique())))
print("Total: " + str(len(base_data["IMDB Title Code"].unique())))


# Dropping titles with missing EST to iVOD Window
# (means either of EST Release or iVOD release is skipped for those titles)
base_data.dropna(
    subset=["EST to iVOD Window"],
    axis=0,
    inplace=True
)

# print WB & NonWB title count
print("Dropping titles with missing EST to iVOD Window")
print("# WB Title: " + str(len(base_data.loc[base_data["Studio"] == "WB", "IMDB Title Code"].unique())))
print("# NonWB Title: " + str(len(base_data.loc[base_data["Studio"] == "NonWB", "IMDB Title Code"].unique())))
print("Total: " + str(len(base_data["IMDB Title Code"].unique())))


# Dropping titles with missing Audience Demographics data
base_data.dropna(
    subset=["High Income ($100K+ annual HH)"],  # dropping looking at "High Income ($100K+ annual HH)" column
    axis=0,
    inplace=True
)

# print WB & NonWB title count
print("Dropping titles with missing Audience Demographics data")
print("# WB Title: " + str(len(base_data.loc[base_data["Studio"] == "WB", "IMDB Title Code"].unique())))
print("# NonWB Title: " + str(len(base_data.loc[base_data["Studio"] == "NonWB", "IMDB Title Code"].unique())))
print("Total: " + str(len(base_data["IMDB Title Code"].unique())))


# Dropping outlier titles
base_data = base_data.loc[
    ~base_data["IMDB Title Name"].isin(
        [
              "Joker"  # test title
        ]
    )
]

# print WB & NonWB title count
print("Dropping outlier titles")
print("# WB Title: " + str(len(base_data.loc[base_data["Studio"] == "WB", "IMDB Title Code"].unique())))
print("# NonWB Title: " + str(len(base_data.loc[base_data["Studio"] == "NonWB", "IMDB Title Code"].unique())))
print("Total: " + str(len(base_data["IMDB Title Code"].unique())))



# Creating Dummy Variables

# creating dummy variable for column "SOURCE"
base_data["SOURCE_temp"] = base_data["SOURCE"]
base_data = pd.get_dummies(
    data=base_data,
    columns=[
        "SOURCE_temp"
    ],
    prefix="Metadata:",
    prefix_sep=" ",
    drop_first=False
)



# Data transformations

# Adding a constant term (for an intercept model)
base_data["const"] = 1

## Log transformations

### log(x) transformations
cont_var_log = [
      "EST Units Wk01 Clubbed"
    , "EST Week Number"
    , "EST Release Year"
    , "EST Price"
    # , "BO Revenue (Opening Weekend)"
    , "Number of Theaters Released in"
    , "Google Search Volume (Mean)"
]
for col in cont_var_log:
    base_data[col] = np.log(base_data[col])
del col

### log(x+1) transformation
cont_var_log1 = [
      "Definitely Recommended"
    , "EST to iVOD Window"
    # , "Casual Moviegoer (6-12 annual)"
    , "Middle Income ($50K-$99K annual HH)"
    , "High Income ($100K+ annual HH)"
    , "Interest to Buy EST"
    , "EST Competitor Effect (Avg)"
]
for col in cont_var_log1:
    base_data[col] = np.log(base_data[col] + 1)
del col



# Selecting Variables

## Dependent variable
dep_var = "EST Units Wk01 Clubbed"

## Independent variables

### numeric variables
continuous_variables = [x for x in cont_var_log if x not in dep_var] + cont_var_log1

### categorical variables
cat_vars = [
      "Metadata: Based on Factual Book/Article"
    # , "Metadata: Based on Fiction Book/Short Story"
    # , "Metadata: Based on Religious Text"
    # , "Metadata: Based on Theme Park Ride"
    # , "Metadata: Based on TV"
]

### independent variables
indep_vars = ["const"] + continuous_variables + cat_vars

## Title Identifiers
title_identifier_vars = [
      "IMDB Title Code"
    , "IMDB Title Name"
    , "Theatrical Release Date"
    , "EST Release Date"
    , "Studio"
    , "MKT Genre Grouped"
    , "SOURCE"
]



# Splitting dataset into training set & validation set

## training set
train_data = base_data.loc[
    (base_data["Theatrical Release Year"] >= 2017) &
    (base_data["Theatrical Release Year"] <= 2019),
    title_identifier_vars + [dep_var] + indep_vars
].reset_index(drop=True)

## validation set
test_data = base_data.loc[
    base_data["Theatrical Release Year"] == 2019,
    title_identifier_vars + [dep_var] + indep_vars
].reset_index(drop=True)

## print WB title count from training & validation set
print(
        "# WB Title in training set: " + str(len(train_data.loc[
                                                         train_data["Studio"] == "WB",
                                                         "IMDB Title Code"
                                                 ].unique()))
)
print(
        "# WB Title in validation set: " + str(len(test_data.loc[
                                                           test_data["Studio"] == "WB",
                                                           "IMDB Title Code"
                                                   ].unique()))
)



# Model development
model = sm.OLS(
    endog=train_data[dep_var],  # series of dependent variable
    exog=train_data[indep_vars]  # matrix of independent variables
).fit()

# print model summary
print("Model summary")
print(model.summary())
print("\n\n")
print("VIF")
print(model_objects.vif(X=train_data[indep_vars]))



# Model predictions

## scoring training data
train_data['prediction'] = np.exp(model.predict(exog=train_data[indep_vars]).tolist())
train_data['set'] = 'train'
## scoring validation data
test_data['prediction'] = np.exp(model.predict(exog=test_data[indep_vars]).tolist())
test_data['set'] = 'test'

## concatinating scored training & validation set
predictions = pd.concat(
    [
        train_data.drop("const", axis=1),
        test_data.drop("const", axis=1)
    ],
    axis=0
)



# Transforming variables back

## transforming variables that were transformed to log(x)
for col in cont_var_log:
        predictions[col] = np.exp(predictions[col])
## transforming variables that were transformed to log(x+1)
for col in cont_var_log1:
        predictions[col] = np.exp(predictions[col]) - 1

predictions[dep_var] = predictions[dep_var].round(decimals=2)
predictions["prediction"] = predictions["prediction"].round(decimals=2)



# Error Metrics

## grouping predictions at title level
title_level_predictions = predictions.groupby(
    title_identifier_vars
).agg(
    {
         dep_var : "sum",
        "prediction" : "sum",
        "set" : "unique"
    }
).reset_index()
title_level_predictions[dep_var] = title_level_predictions[dep_var].round(decimals=2)

## calculating title level error
title_level_predictions["Error"] = np.absolute(
    title_level_predictions["prediction"] -
    title_level_predictions[dep_var]
)
title_level_predictions["Absolute Error"] = np.absolute(
    title_level_predictions[dep_var] -
    title_level_predictions["prediction"]
)
title_level_predictions["Percentage Error"] = round(
    (
        title_level_predictions["Absolute Error"] /
        title_level_predictions[dep_var]
    ) * 100,
    2
)

## calculating overall Error

### Train WMAPE
print(" Train WMAPE: " + str(
    round(
        (
            np.sum(
                title_level_predictions.loc[
                    (title_level_predictions["Studio"] == "WB") &
                    (title_level_predictions["set"] == "train"),
                    "Absolute Error"
                ]
            ) / np.sum(
                title_level_predictions.loc[
                    (title_level_predictions["Studio"] == "WB") &
                    (title_level_predictions["set"] == "train"),
                    dep_var
                ]
            )
        ) * 100
    , 2
    )
) + " %")

### Validation WMAPE
print(" Test WMAPE: " + str(
    round(
        (
            np.sum(
                title_level_predictions.loc[
                    (title_level_predictions["Studio"] == "WB") &
                    (title_level_predictions["set"] == "test"),
                    "Absolute Error"
                ]
            ) / np.sum(
                title_level_predictions.loc[
                    (title_level_predictions["Studio"] == "WB") &
                    (title_level_predictions["set"] == "test"),
                    dep_var
                ]
            )
        ) * 100
    , 2
    )
) + " %")



# Exporting results

model_performace = model_objects.model_results(
    model=model,
    train_data=train_data,
    indep_vars=indep_vars
)

with pd.ExcelWriter(
        path=r"C:\Users\Sandeep Sanyal\Desktop\EST Units prediction.xlsx",
        mode='w',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    model_performace.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='mode performance',
        engine='openpyxl'
    )
    predictions.loc[predictions["Studio"] == "WB", :].to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='title-week level',
        engine='openpyxl'
    )
    title_level_predictions.loc[title_level_predictions["Studio"] == "WB", :].drop(
        "Error",
        axis=1
    ).rename(
        columns={
            dep_var : "EST Units"
        }
    ).to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='title level',
        engine='openpyxl'
    )
