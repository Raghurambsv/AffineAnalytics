# user paths
sharepoint_path = r"/home/sandeepsanyal/OneDrive"
root_folder = r"/home/sandeepsanyal/PycharmProjects/WB-Theatrical-MMM"

# importing modules
import numpy as np
import pandas as pd
import statsmodels.api as sm
from tqdm import tqdm
import sys
sys.path.insert(0,root_folder+r"/Phase 2 Codes/03. Feature Engineering")
from AdstockClass import Adstock
sys.path.insert(0,root_folder+r"/Phase 2 Codes/06. Miscellaneous")
import date_manipulations
sys.path.insert(0, root_folder+r"/Phase 2 Codes/06. Miscellaneous")
import model_objects

# importing dataset
base_data = pd.read_excel(io=sharepoint_path+r"/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Base AD v1.3.xlsx",
                          sheet_name="Base AD",
                          na_values=['#NA','#N/A','',' ','na','NA'],
                          header=3)
base_data['Theatrical Release Date'] = pd.to_datetime(arg=base_data['Theatrical Release Date'],infer_datetime_format=True,errors="coerce")
base_data['Week Start Date'] = pd.to_datetime(arg=base_data['Week Start Date'],infer_datetime_format=True,errors="coerce")
base_data['BO Spends'] = base_data[['BO Digital Spend',
                                    'BO Digital Video Spend',
                                    'BO Total Linear Spend',
                                    'BO Outdoor/Print Spend',
                                    'BO OOH-Experiential Spend']].sum(axis=1)
base_data['HE Spends'] = base_data[['HE Digital Spend',
                                    'HE Digital Video Spend',
                                    'HE Non-Digital Spend',
                                    'HE Linear Co-op Spend']].sum(axis=1)
base_data['PST Revenue'] = base_data[['Blu-ray Sell-Thru Revenue',
                                      'Blu-ray Rental Revenue',
                                      'DVD Sell-Thru Revenue',
                                      'DVD Rental Revenue']].sum(axis=1)
base_data['HE Revenue'] = base_data[['Blu-ray Sell-Thru Revenue',
                                     'Blu-ray Rental Revenue',
                                     'DVD Sell-Thru Revenue',
                                     'DVD Rental Revenue',
                                     'EST Sell-Thru Revenue',
                                     'iVOD Rental Revenue',
                                     'VOD Rental Revenue']].sum(axis=1)

base_data = base_data[['IMDB Title Code','IMDB Title Name','Theatrical Release Date','TH Week Number','Week Start Date',
                       'BO Spends','HE Spends',
                       'BO Revenue','EST Sell-Thru Revenue','iVOD Rental Revenue','VOD Rental Revenue','PST Revenue','HE Revenue']]
base_data.fillna(0,inplace=True)

# calculating Adstock of BO & HE spends
instance = Adstock(base_dataframe=base_data.rename(columns={'IMDB Title Code': 'IMDB_Title_Code'}),
                   dictionary_spends={'BO Spends': [0.01,'Linear']},
                   week_number_colname='TH Week Number',
                   revenue_colname='BO Revenue')
base_data = instance.optimise_adstock()
instance = Adstock(base_dataframe=base_data,
                   dictionary_spends={'HE Spends': [0.01,'Linear']},
                   week_number_colname='TH Week Number',
                   revenue_colname='HE Revenue')
base_data = instance.optimise_adstock()
base_data.rename(columns={'IMDB_Title_Code':'IMDB Title Code'},
                 inplace=True)
del instance

release_date_data = base_data[['IMDB Title Code',
                               'IMDB Title Name',
                               'Theatrical Release Date']].drop_duplicates().reset_index(drop=True)

# getting release_dates
for format in tqdm(['EST Sell-Thru Revenue','PST Revenue','iVOD Rental Revenue','VOD Rental Revenue']):
    temp = base_data[['IMDB Title Code','IMDB Title Name','Theatrical Release Date','TH Week Number','Week Start Date']+[format]]
    temp[format] = temp[format].replace(0,np.nan)
    temp.dropna(subset=[format],axis=0,inplace=True)
    temp = temp.groupby(['IMDB Title Code']).agg({'Week Start Date':'min'}).rename(columns={'Week Start Date':format[0:4].strip()+' Release Date'})
    release_date_data = pd.merge(left=release_date_data,
                                 right=temp,
                                 left_on='IMDB Title Code',
                                 right_on='IMDB Title Code',
                                 how='left')
    del temp
del format

release_date_data = date_manipulations.last_sunday(df=release_date_data,
                                                   date_column_name='Theatrical Release Date',
                                                   sunday_date_column_name='BO  Release Date')
release_date_data = release_date_data[['IMDB Title Code','IMDB Title Name',
                                       'Theatrical Release Date','BO  Release Date',
                                       'EST Release Date','PST Release Date','iVOD Release Date','VOD Release Date']]
for i in tqdm(range(3,8)):
    for j in range(i+1,8):
        if i!=j:
            release_date_data[release_date_data.columns.values.tolist()[i][0:4].strip()+\
                              ' to '+\
                              release_date_data.columns.values.tolist()[j][0:4].strip()+\
                              ' Window'] = \
                (release_date_data[release_date_data.columns.values.tolist()[i]] - \
                 release_date_data[release_date_data.columns.values.tolist()[j]]) \
                / pd.offsets.Day(-7)
del i,j
release_date_data.drop(['BO  Release Date'],axis=1,inplace=True)

base_data = pd.merge(left=base_data,
                     right=release_date_data,
                     how='left',
                     left_on=['IMDB Title Code','IMDB Title Name','Theatrical Release Date'],
                     right_on=['IMDB Title Code','IMDB Title Name','Theatrical Release Date'])

base_data = base_data[[
    'IMDB Title Code','IMDB Title Name',
    'Theatrical Release Date','EST Release Date','PST Release Date','iVOD Release Date','VOD Release Date',
    'Week Start Date','TH Week Number',
    'BO to EST Window','BO to PST Window','BO to iVOD Window','BO to VOD Window','EST to PST Window','EST to iVOD Window','EST to VOD Window','PST to iVOD Window','PST to VOD Window','iVOD to VOD Window',
    'BO Spends','HE Spends',
    'BO Spends Adstock Linear0.648','HE Spends Adstock Linear0.84',
    'BO Revenue','EST Sell-Thru Revenue','iVOD Rental Revenue','VOD Rental Revenue','PST Revenue','HE Revenue'
]]

# exporting dataset
with pd.ExcelWriter(
        path=sharepoint_path+r"/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Base AD v1.4.xlsx",
        engine='openpyxl',
        mode='w',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    base_data.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='Sheet1')
# importing dataset
base_data = pd.read_excel(io=sharepoint_path+r"/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Base AD v1.4.xlsx",
                          sheet_name="Sheet1",
                          na_values=['#NA','#N/A','',' ','na','NA'])

base_data = base_data.loc[base_data['TH Week Number']>=0,:]
temp = base_data.copy()
temp['Total Revenue'] = temp[['BO Revenue',
                              'EST Sell-Thru Revenue',
                              'iVOD Rental Revenue',
                              'VOD Rental Revenue',
                              'PST Revenue']].sum(axis=1)
temp['Total Revenue'] = temp['Total Revenue'].replace(0,np.nan)
temp['CumSum Total Revenue'] = temp['Total Revenue'].cumsum(skipna=True)
temp.dropna(subset=['CumSum Total Revenue'],axis=0,inplace=True)

temp = temp.groupby('IMDB Title Code').agg({'TH Week Number':'max'}).reset_index()

base_data2 = pd.DataFrame()
for title in tqdm(temp['IMDB Title Code']):
    base_data2 = pd.concat([base_data2,
                            base_data.loc[(base_data['IMDB Title Code']==title) &\
                                          (base_data['TH Week Number']<=temp.loc[temp['IMDB Title Code']==title,'TH Week Number'].values[0]),:]],
                           axis=0)
base_data = base_data2.reset_index(drop=True)
del base_data2, temp, title

titles = []
for title_code in release_date_data['IMDB Title Code']:
    if (np.isnan(release_date_data.loc[release_date_data['IMDB Title Code']==title_code,'BO to EST Window'].values[0])==False) &\
       (np.isnan(release_date_data.loc[release_date_data['IMDB Title Code']==title_code,'BO to PST Window'].values[0])==False) &\
       (np.isnan(release_date_data.loc[release_date_data['IMDB Title Code']==title_code,'BO to iVOD Window'].values[0])==False) &\
       (np.isnan(release_date_data.loc[release_date_data['IMDB Title Code']==title_code,'BO to VOD Window'].values[0])==False) :
        titles = titles+[title_code]
del title_code

base_data = base_data.loc[base_data['IMDB Title Code'].isin(titles),:]

# importing other variables
pvod_ad = pd.read_csv(filepath_or_buffer=r"/home/sandeepsanyal/OneDrive/05. Ad Hoc Requests/Unaided vs EST/Version 2/model2_ad_v6.csv")

# adding unaided awareness
base_data = pd.merge(left=base_data,
                     right=pvod_ad[['imdb_title_code',
                                    'bo_week_since_launch',
                                    'unaid_predictions',
                                    'avg_google_search_volume_till_-4',
                                    'mpaa_rating',
                                    'franchise_flag',
                                    'cast_avg_rating',
                                    'source',
                                    'Runtime_bin',
                                    'easter_flag',
                                    'july4_flag',
                                    'DC_flag']].rename(columns={'imdb_title_code':'IMDB Title Code',
                                                                'bo_week_since_launch':'TH Week Number'}),
                     how='left',
                     left_on=['IMDB Title Code', 'TH Week Number'],
                     right_on=['IMDB Title Code', 'TH Week Number'])







# exporting dataset
with pd.ExcelWriter(
        path=sharepoint_path+r"/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Base AD v1.4.xlsx",
        engine='openpyxl',
        mode='a',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    base_data.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='Sheet2')


# importing dataset
base_data = pd.read_excel(io=sharepoint_path+r"/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Base AD v1.4.xlsx",
                          sheet_name="Sheet1",
                          na_values=['#NA','#N/A','',' ','na','NA'])

base_data['Total Revenue'] = base_data[['BO Revenue',
                                        'EST Sell-Thru Revenue',
                                        'iVOD Rental Revenue',
                                        'VOD Rental Revenue',
                                        'PST Revenue']].sum(axis=1)
base_data['Total Revenue'] = base_data['Total Revenue'].replace(0,np.nan)
base_data.dropna(subset=['Total Revenue'],axis=0,inplace=True)

# dropping titles against release sequence assumption (BO,EST,PST,iVOD,VOD)
base_data = base_data.loc[base_data['BO to EST Window']>=0,:]
base_data = base_data.loc[base_data['EST to PST Window']>=0,:]
base_data = base_data.loc[base_data['PST to iVOD Window']>=0,:]
base_data = base_data.loc[base_data['iVOD to VOD Window']>=0,:]

# adding constant term
base_data = sm.add_constant(base_data)

for row in base_data.index:
    if base_data.loc[row,'EST to PST Window'] == 0:
        base_data.loc[row,'EST Run Effect'] = 0
    else:
        base_data.loc[row,'EST Run Effect'] = base_data.loc[row,'BO to EST Window']/base_data.loc[row,'EST to PST Window']
    if base_data.loc[row,'PST to iVOD Window'] == 0:
        base_data.loc[row,'PST Run Effect'] = 0
    else:
        base_data.loc[row,'PST Run Effect'] = base_data.loc[row,'EST to PST Window']/base_data.loc[row,'PST to iVOD Window']
    if base_data.loc[row,'iVOD to VOD Window'] == 0:
        base_data.loc[row,'iVOD Run Effect'] = 0
    else:
        base_data.loc[row,'iVOD Run Effect'] = base_data.loc[row,'PST to iVOD Window']/base_data.loc[row,'iVOD to VOD Window']
del row

# Total Window
base_data['Total Window'] = base_data[['BO to EST Window', 'EST to PST Window', 'PST to iVOD Window', 'iVOD to VOD Window']].sum(axis=1)

# dep_var transformation
base_data['Total Revenue by Total Window'] = base_data['Total Revenue']/base_data['Total Window']

dep_var = 'Total Revenue by Total Window'

# log transformations
cont_var = [
    'Total Revenue'
    ,'Total Revenue by Total Window'
    ,'TH Week Number'
    ,'BO Spends Adstock Linear0.639'
    ,'HE Spends Adstock Linear0.827'
    ,'BO to EST Window'
    ,'BO to PST Window'
    ,'BO to iVOD Window'
    ,'BO to VOD Window'
    ,'EST to PST Window'
    ,'EST to iVOD Window'
    ,'EST to VOD Window'
    ,'PST to iVOD Window'
    ,'PST to VOD Window'
    ,'iVOD to VOD Window'
    ,'EST Run Effect'
    ,'PST Run Effect'
    ,'iVOD Run Effect'
]
for col in cont_var:
    base_data[col] = np.log(base_data[col]+1)
del col

# selecting independent variables
indep_vars = [
    'const'
    ,'BO Spends Adstock Linear0.639'
    ,'HE Spends Adstock Linear0.827'
    ,'BO to EST Window'
    # ,'BO to PST Window'
    # ,'BO to iVOD Window'
    # ,'BO to VOD Window'
    # ,'EST to PST Window'
    # ,'EST to iVOD Window'
    # ,'EST to VOD Window'
    # ,'PST to iVOD Window'
    # ,'PST to VOD Window'
    ,'EST Run Effect'
    ,'PST Run Effect'
    # ,'iVOD Run Effect'
    ,'iVOD to VOD Window'
]

title_identifier_vars = [
    'IMDB Title Code'
    ,'IMDB Title Name'
    ,'Theatrical Release Date'
    ,'TH Week Number'
]
# del train_data, test_data
# subset dataset
train_data = base_data.loc[(base_data['Theatrical Release Date'].dt.year>=2015) &
                           (base_data['Theatrical Release Date'].dt.year<=2017),title_identifier_vars + [dep_var] + indep_vars].reset_index(drop=True)
test_data = base_data.loc[base_data['Theatrical Release Date'].dt.year>=2018,title_identifier_vars + [dep_var] + indep_vars].reset_index(drop=True)

# model development
model = sm.OLS(endog=train_data[dep_var],
               exog=train_data[indep_vars]).fit()

# print model summary
print(model.summary())

# print VIF
print(model_objects.vif(X=train_data[indep_vars]))




# importing dataset
base_data = pd.read_excel(io=sharepoint_path+r"/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Base AD v1.5.xlsx",
                          sheet_name="Sheet3",
                          na_values=['#NA','#N/A','',' ','na','NA']).iloc[:,range(0,6)]
base_data = base_data.loc[base_data['EST to BO Performance']!=0,:]
base_data = base_data.loc[abs(base_data['EST to BO Performance'])<50,:]

base_data['BO to EST Window_temp'] = base_data['BO to EST Window']

# variable transformations
## creating dummies
base_data = pd.get_dummies(data=base_data,
                           columns=[
                               'BO to EST Window_temp',
                           ],
                           prefix='BO to EST Window',
                           drop_first=False)
# log transformations
cont_var = [
    'Total Revenue'
    #,'EST to BO Performance'
]
for col in cont_var:
    base_data[col] = np.log(base_data[col]+1)
del col

dep_var = ['Total Revenue']
indep_vars = [
    'EST to BO Performance'
    ,'BO to EST Window_7'
    ,'BO to EST Window_10'
    ,'BO to EST Window_11'
    ,'BO to EST Window_12'
    ,'BO to EST Window_13'
    # 'BO to EST Window_14'
    ,'BO to EST Window_15'
    ,'BO to EST Window_16'
    ,'BO to EST Window_17']

# model development
model = sm.OLS(endog=base_data[dep_var],
               exog=base_data[indep_vars]).fit()

# print model summary
print(model.summary())