import random

face = ["U", "D", "F", "B", "R", "L"]
direction = ["", "'", "2"]
shuffle_length = random.randint(25, 28)

def scramble_gen():
    scramble = [0] * shuffle_length
    for x in range(len(scramble)):
        scramble[x] = [0] * 2
    return scramble

def scramble_replace(ar):
    for x in range(len(ar)):
        ar[x][0] = random.choice(face)
        ar[x][1] = random.choice(direction)
    return ar

def valid(ar):
    for x in range(1, len(ar)):
        while ar[x][0] == ar[x-1][0]:
            ar[x][0] = random.choice(face)
    for x in range(2, len(ar)):
        while ar[x][0] == ar[x-2][0] or ar[x][0] == ar[x-1][0]:
            ar[x][0] = random.choice(face)
    return ar

def sprint(ar):
    for x in range(len(ar)):
        print(str(ar[x][0]) + str(ar[x][1]), end = " ")

sprint(valid(scramble_replace(scramble_gen())))