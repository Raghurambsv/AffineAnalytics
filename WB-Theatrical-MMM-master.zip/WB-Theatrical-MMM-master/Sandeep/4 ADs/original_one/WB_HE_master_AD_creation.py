# importing packages
import pandas as pd

# importing datasets
Weekly_Sales_v1_0 = pd.read_csv(r'/home/wb/WB-data/Base Data/Weekly_Sales_v1.0.csv',
                                sep = ',',
                                encoding = 'latin-1')
Comp_Spending_v3 = pd.read_csv(r'/home/wb/WB-data/Base Data/Comp_Spending_v3.csv',
                                sep = ',',
                                encoding = 'latin-1')
Total_Theater_Sales_v3 = pd.read_csv(r'/home/wb/WB-data/Base Data/Total_Theater_Sales_v3.csv',
                                sep = ',',
                                encoding = 'latin-1')
Total_Media2_v3 = pd.read_csv(r'/home/wb/WB-data/Base Data/Total Media2_v3.csv',
                                sep = ',',
                                encoding = 'latin-1')
BO_Spend = pd.read_csv(r'/home/wb/WB-data/Base Data/BO_Spend.csv',
                                sep = ',',
                                encoding = 'latin-1')
all_movie_list = pd.read_csv(r'/home/wb/WB-data/Base Data/all_movie_list.csv',
                                sep = ',',
                                encoding = 'latin-1')

# Master AD creation
master_AD = Total_Media2_v3.merge(right = Weekly_Sales_v1_0,
                            how='inner',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)
master_AD = master_AD.merge(right = Total_Theater_Sales_v3,
                            how='inner',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)
master_AD = master_AD.merge(right = Comp_Spending_v3,
                            how='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)
master_AD = master_AD.merge(right = BO_Spend[['IMDB_Title_Code', 'BO_Spend']],
                            how='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)

master_AD['EST_Release_Date'] = master_AD[['Blu-ray_Street_Date', 'DVD_Street_Date']].min(axis = 1)
master_AD['Theatrical_Release_Date_x'] = pd.to_datetime(arg=master_AD['Theatrical_Release_Date_x'], infer_datetime_format=True)
master_AD['Blu-ray_Street_Date'] = pd.to_datetime(arg=master_AD['Blu-ray_Street_Date'], infer_datetime_format=True)
master_AD['DVD_Street_Date'] = pd.to_datetime(arg=master_AD['DVD_Street_Date'], infer_datetime_format=True)
master_AD['EST_Street_Date'] = pd.to_datetime(arg=master_AD['EST_Street_Date'], infer_datetime_format=True)
master_AD['cVOD_Street_Date'] = pd.to_datetime(arg=master_AD['cVOD_Street_Date'], infer_datetime_format=True)
master_AD['iVOD_Street_Date'] = pd.to_datetime(arg=master_AD['iVOD_Street_Date'], infer_datetime_format=True)
master_AD['EST_Release_Date'] = master_AD[['EST_Street_Date', 'cVOD_Street_Date', 'iVOD_Street_Date']].min(axis = 1)
master_AD['PST_Release_Date'] = master_AD[['Blu-ray_Street_Date', 'DVD_Street_Date']].min(axis = 1)

master_AD['BO_Revenue'] = master_AD[['Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount']].sum(axis = 1)
master_AD['EST_Revenue'] = master_AD[['EST_Revenue', 'cVOD_Revenue', 'iVOD_Revenue']].sum(axis = 1)
master_AD['PST_Revenue'] = master_AD[['Blu-ray_Revenue', 'DVD_Revenue']].sum(axis = 1)

master_AD['EST_Sold'] = master_AD[['EST_Sold', 'cVOD_Sold', 'iVOD_Sold']].sum(axis = 1)
master_AD['PST_Sold'] = master_AD[['Blu-ray_Sold', 'DVD_Sold']].sum(axis = 1)

master_AD['EST_Media_Spend'] = master_AD[['EST', 'VOD']].sum(axis = 1)

master_AD.rename(columns = {'EST_Studio' : 'EST_Studio_old'}, inplace = True)
master_AD['EST_Studio'] = None
master_AD['PST_Studio'] = None
for i in range(master_AD.shape[0]):
    master_AD.loc[i, ['EST_Studio']] = pd.unique(master_AD.loc[i, ['EST_Studio_old', 'cVOD_Studio', 'iVOD_Studio']])[0]
    master_AD.loc[i, ['PST_Studio']] = pd.unique(master_AD.loc[i, ['DVD_Studio', 'Blu-ray_Studio']])
del i

# getting movie titles
master_AD = master_AD.merge(right = all_movie_list[['IMDB_Title_Code', 'Movie_Title']],
                            how='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)

master_AD = master_AD[['IMDB_Title_Code', 'Movie_Title', 'Genre',
                       'Studio', 'EST_Studio', 'PST_Studio',
                       'Theatrical_Release_Date_x', 'EST_Release_Date', 'PST_Release_Date',
                       'BO_Spend', 'EST_Media_Spend', 'PHYSICAL_MEDIA',
                       'BO_Revenue', 'EST_Revenue', 'PST_Revenue',
                       'EST_Sold', 'PST_Sold',
                       'Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount',
                       'Opening_Weekend_BO', 'Opening_Weekend_Runs']]
master_AD.rename(columns = {'Studio' : 'Theatrical_Studio',
                            'Theatrical_Release_Date_x' : 'Theatrical_Release_Date',
                            'PHYSICAL_MEDIA' : 'PST_Media_Spend',
                            'BO_Spend' : 'BO_Media_Spend'},
                 inplace = True)

#  removing objects to free memory
del Comp_Spending_v3, Total_Media2_v3, Total_Theater_Sales_v3, Weekly_Sales_v1_0

master_AD['Theatrical_Release_Date'] = pd.to_datetime(arg=master_AD['Theatrical_Release_Date'], infer_datetime_format=True)
master_AD['EST_Release_Date'] = pd.to_datetime(arg=master_AD['EST_Release_Date'], infer_datetime_format=True)
master_AD['PST_Release_Date'] = pd.to_datetime(arg=master_AD['PST_Release_Date'], infer_datetime_format=True)

# exporting dataset
master_AD.to_csv(r'/home/wb/WB-data/Base Data/ADs/HE_master_AD_WB_v1.0.csv', index = False)
