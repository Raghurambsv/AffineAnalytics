# importing packages
import numpy as np
import pandas as pd

# importing all files
Physical_Weekly_Sales_v3 = pd.read_csv(r'/home/wb/WB-data/Base Data/Physical_Weekly_Sales_v3.csv',
                                       sep = ',',
                                       encoding = 'latin-1')
Digital_Weekly_Sales_v3 = pd.read_csv(r'/home/wb/WB-data/Base Data/Digital_Weekly_Sales_v3.csv',
                                      sep = ',',
                                      encoding = 'latin-1')

# row binding Physical Weekly Sales and Digital Weekly Sales files
phys_digi = pd.concat([Physical_Weekly_Sales_v3, Digital_Weekly_Sales_v3], ignore_index=True)
phys_digi = phys_digi.loc[phys_digi['Media_Type']!='TOTAL VOD (iVOD+cVOD)', :]

# collating Physical Weekly Sales and Digital Weekly Sales files and converting to Movie level dataset
gp_data = phys_digi.groupby(['IMDB_Title_Code', 'Item_Title_WW', 'Studio', 'Street_Date', 'Theatrical_Release_Date', 'Media_Type']).agg({'Revenue':'sum','Units':'sum'}).reset_index()

unq_titles = gp_data['IMDB_Title_Code'].unique()
for i in unq_titles:
    unq_media = (gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Media_Type']).unique()
    for j in unq_media:
        temp = gp_data.loc[(gp_data['IMDB_Title_Code'] == i) & (gp_data['Media_Type'] == j)]
        if temp.shape[0] > 1 :
            if temp['Studio'].str.contains('WARNER').sum() > 0 :
                gp_data = gp_data.drop(index=temp.loc[temp['Studio'] != 'WARNER'].index.values, axis=0)
            else:
                gp_data = gp_data.drop(index=temp.loc[temp['Revenue'] != max(temp['Revenue'])].index.values, axis=0)
del i, j, temp

street_date = pd.pivot_table(data  = gp_data,
                             index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                             columns=['Media_Type'],
                             values=['Street_Date'],
                             aggfunc=np.unique).reset_index()
studio = pd.pivot_table(data  = gp_data,
                             index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                             columns=['Media_Type'],
                             values=['Studio'],
                             aggfunc=np.unique).reset_index()
Revenue = pd.pivot_table(data  = gp_data,
                             index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                             columns=['Media_Type'],
                             values=['Revenue'],
                             aggfunc=np.unique).reset_index()
Units = pd.pivot_table(data  = gp_data,
                             index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                             columns=['Media_Type'],
                             values=['Units'],
                             aggfunc=np.unique).reset_index()
weekly_sales = pd.merge(left=street_date,
                        right = studio,
                        how='left',
                        left_on = ['IMDB_Title_Code'],
                        right_on = ['IMDB_Title_Code'],
                        sort = True,
                        copy = False)
weekly_sales.drop(['Theatrical_Release_Date_y', 'Item_Title_WW_y'], axis = 1, inplace = True)
weekly_sales.rename(columns = {'Item_Title_WW_x' : 'Item_Title_WW',
                               'Theatrical_Release_Date_x' : 'Theatrical_Release_Date'},
                    inplace = True)
weekly_sales = pd.merge(left=weekly_sales,
                        right = Revenue,
                        how='left',
                        left_on = ['IMDB_Title_Code'],
                        right_on = ['IMDB_Title_Code'],
                        sort = True,
                        copy = False)
weekly_sales.drop(['Theatrical_Release_Date_y', 'Item_Title_WW_y'], axis = 1, inplace = True)
weekly_sales.rename(columns = {'Item_Title_WW_x' : 'Item_Title_WW',
                               'Theatrical_Release_Date_x' : 'Theatrical_Release_Date'},
                    inplace = True)
weekly_sales = pd.merge(left=weekly_sales,
                        right = Units,
                        how='left',
                        left_on = ['IMDB_Title_Code'],
                        right_on = ['IMDB_Title_Code'],
                        sort = True,
                        copy = False)
weekly_sales.drop(['Theatrical_Release_Date_y', 'Item_Title_WW_y'], axis = 1, inplace = True)
#  removing objects to free memory
del Revenue, Units, gp_data, street_date, phys_digi, studio, Digital_Weekly_Sales_v3, Physical_Weekly_Sales_v3
weekly_sales.columns = ['IMDB_Title_Code',
                        'Theatrical_Release_Date',
                        'Item_Title_WW',
                        'Blu-ray_Street_Date',
                        'DVD_Street_Date',
                        'EST_Street_Date',
                        'cVOD_Street_Date',
                        'iVOD_Street_Date',
                        'Blu-ray_Studio',
                        'DVD_Studio',
                        'EST_Studio',
                        'cVOD_Studio',
                        'iVOD_Studio',
                        'Blu-ray_Revenue',
                        'DVD_Revenue',
                        'EST_Revenue',
                        'cVOD_Revenue',
                        'iVOD_Revenue',
                        'Blu-ray_Sold',
                        'DVD_Sold',
                        'EST_Sold',
                        'cVOD_Sold',
                        'iVOD_Sold']

# correcting date_time format
weekly_sales['Theatrical_Release_Date'] = pd.to_datetime(arg=weekly_sales['Theatrical_Release_Date'], infer_datetime_format=True)
weekly_sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=weekly_sales['Blu-ray_Street_Date'], infer_datetime_format=True)
weekly_sales['DVD_Street_Date'] = pd.to_datetime(arg=weekly_sales['DVD_Street_Date'], infer_datetime_format=True)
weekly_sales['EST_Street_Date'] = pd.to_datetime(arg=weekly_sales['EST_Street_Date'], infer_datetime_format=True)
weekly_sales['cVOD_Street_Date'] = pd.to_datetime(arg=weekly_sales['cVOD_Street_Date'], infer_datetime_format=True)
weekly_sales['iVOD_Street_Date'] = pd.to_datetime(arg=weekly_sales['iVOD_Street_Date'], infer_datetime_format=True)

# deleting titles whose HE release date is before BO release date
weekly_sales['BO_Window'] = (weekly_sales['Theatrical_Release_Date'] - weekly_sales[['Blu-ray_Street_Date', 'DVD_Street_Date', 'EST_Street_Date', 'cVOD_Street_Date', 'iVOD_Street_Date']].min(axis = 1))/pd.offsets.Day(-1)
for i in weekly_sales.index :
    if weekly_sales.loc[i, 'BO_Window'] < 0 :
        weekly_sales = weekly_sales.drop(index=i, axis=0)
weekly_sales.drop(['BO_Window'], axis = 1, inplace = True)

# export Weekly_sales file
weekly_sales.to_csv(r'/home/wb/WB-data/Base Data/Archive/Weekly_Sales_v3.3.csv', index = False)
