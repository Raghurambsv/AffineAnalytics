# importing packages
import pandas as pd

# importing datasets
Weekly_Sales_v1_0 = pd.read_csv(r'/home/wb/WB-data/Base Data/Weekly_Sales_v1.0.csv',
                                sep = ',',
                                encoding = 'latin-1')
Comp_Spending_v3 = pd.read_csv(r'/home/wb/WB-data/Base Data/Comp_Spending_v3.csv',
                                sep = ',',
                                encoding = 'latin-1')
Total_Theater_Sales_v3 = pd.read_csv(r'/home/wb/WB-data/Base Data/Total_Theater_Sales_v3.csv',
                                sep = ',',
                                encoding = 'latin-1')
all_movie_list = pd.read_csv(r'/home/wb/WB-data/Base Data/all_movie_list.csv',
                                sep = ',',
                                encoding = 'latin-1')

Total_Theater_Sales_v3['Theatrical_Release_Date'] = pd.to_datetime(arg=Total_Theater_Sales_v3['Theatrical_Release_Date'], infer_datetime_format=True)

Comp_Spending_v3['BO_Media_Spend'] = Comp_Spending_v3['Total_Media_Spend']

# Master AD creation
master_AD = Total_Theater_Sales_v3.merge(right = Comp_Spending_v3,
                                        how='inner',
                                        left_on = ['IMDB_Title_Code'],
                                        right_on = ['IMDB_Title_Code'],
                                        sort = True,
                                        copy = False)
master_AD = master_AD.merge(right = Weekly_Sales_v1_0[['IMDB_Title_Code', 'Blu-ray_Street_Date', 'DVD_Street_Date', 'EST_Street_Date', 'cVOD_Street_Date', 'iVOD_Street_Date']],
                            how='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)

master_AD['BO_Revenue'] = master_AD[['Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount']].sum(axis = 1)

master_AD['Blu-ray_Street_Date'] = pd.to_datetime(arg=master_AD['Blu-ray_Street_Date'], infer_datetime_format=True)
master_AD['DVD_Street_Date'] = pd.to_datetime(arg=master_AD['DVD_Street_Date'], infer_datetime_format=True)
master_AD['EST_Street_Date'] = pd.to_datetime(arg=master_AD['EST_Street_Date'], infer_datetime_format=True)
master_AD['cVOD_Street_Date'] = pd.to_datetime(arg=master_AD['cVOD_Street_Date'], infer_datetime_format=True)
master_AD['iVOD_Street_Date'] = pd.to_datetime(arg=master_AD['iVOD_Street_Date'], infer_datetime_format=True)

master_AD['HE_Release_Date'] = master_AD[['Blu-ray_Street_Date', 'DVD_Street_Date', 'EST_Street_Date', 'cVOD_Street_Date', 'iVOD_Street_Date']].min(axis = 1)
master_AD['BO_Window'] = (master_AD['Theatrical_Release_Date'] - master_AD['HE_Release_Date'])/pd.offsets.Day(-1)

# getting movie titles
master_AD = master_AD.merge(right = all_movie_list[['IMDB_Title_Code', 'Movie_Title']],
                            how='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)

master_AD = master_AD[['IMDB_Title_Code', 'Movie_Title', 'Theatrical_Release_Date', 'HE_Release_Date',
                       'Genre', 'Studio',
                       'BO_Media_Spend', 'BO_Revenue', 'BO_Window',
                       'Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount',
                       'Opening_Weekend_BO', 'Opening_Weekend_Runs']]

master_AD.rename(columns = {'Studio' : 'Theatrical_Studio'},
                 inplace = True)

master_AD.to_csv(r'/home/wb/WB-data/Base Data/ADs/BO_master_AD_non_WB_v1.0.csv',
            index = False)
