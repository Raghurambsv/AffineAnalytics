# importing packages
import numpy as np
import pandas as pd

# importing all files
Physical_Weekly_Sales_v3 = pd.read_csv(r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Physical_Weekly_Sales_v3.csv',
                                       sep = ',',
                                       encoding = 'latin-1')
Digital_Weekly_Sales_v3 = pd.read_csv(r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Digital_Weekly_Sales_v3.csv',
                                      sep = ',',
                                      encoding = 'latin-1')
Comp_Spending_v3 = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Comp_Spending_v3.csv',
                                sep = ',',
                                encoding = 'latin-1')
del Comp_Spending_v3['Studio']
Total_Theater_Sales_v3 = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Total_Theater_Sales_v3.csv',
                                sep = ',',
                                encoding = 'latin-1')
Spend_data = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Sales_data_v1.1.csv',
                                sep = ',',
                                encoding = 'latin-1')
all_movie_list = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\all_movie_mappings.csv',
                                sep = ',',
                                encoding = 'latin-1')

# row binding Physical Weekly Sales and Digital Weekly Sales files
phys_digi = pd.concat([Physical_Weekly_Sales_v3, Digital_Weekly_Sales_v3], ignore_index=True)

# collating Physical Weekly Sales and Digital Weekly Sales files and converting to Movie level dataset
gp_data = phys_digi.groupby(['IMDB_Title_Code',
                             'Item_Title_WW',
                             'Studio',
                             'Street_Date',
                             'Theatrical_Release_Date',
                             'Media_Type']).agg({'Revenue':'sum',
                                                 'Units':'sum'}).reset_index()

# fixing double studio issues
for i in gp_data['IMDB_Title_Code'].unique():
    for j in gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Media_Type'].unique():
        temp = gp_data.loc[(gp_data['IMDB_Title_Code'] == i) & (gp_data['Media_Type'] == j)]
        if temp.shape[0] > 1 :
            if temp['Studio'].str.contains('WARNER').sum() > 0 :
                gp_data = gp_data.drop(index=temp.loc[temp['Studio'] != 'WARNER'].index.values, axis=0)
            else:
                if len(temp.loc[temp['Revenue'] != max(temp['Revenue']), 'Studio'].unique()) == 2:
                    gp_data.drop(index=temp.loc[temp['Studio'] == 'ALL OTHERS'].index.values,
                                 axis=0,
                                 inplace=True)
                else:
                    gp_data.drop(index=temp.loc[temp['Revenue'] != max(temp['Revenue'])].index.values,
                                 axis=0,
                                 inplace=True)
del i, j, temp

# fixing same studio, double release date issues
for i in gp_data['IMDB_Title_Code'].unique() :
    gp_data.loc[gp_data["IMDB_Title_Code"] == i, 'Street_Date'] = gp_data.loc[gp_data["IMDB_Title_Code"] == i, 'Street_Date'].min()
del i

street_date = pd.pivot_table(data  = gp_data,
                             index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                             columns=['Media_Type'],
                             values=['Street_Date'],
                             aggfunc=np.unique).reset_index()
studio = pd.pivot_table(data  = gp_data,
                             index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                             columns=['Media_Type'],
                             values=['Studio'],
                             aggfunc=np.unique).reset_index()
Revenue = pd.pivot_table(data  = gp_data,
                             index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                             columns=['Media_Type'],
                             values=['Revenue'],
                             aggfunc=np.sum).reset_index()
Units = pd.pivot_table(data  = gp_data,
                             index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                             columns=['Media_Type'],
                             values=['Units'],
                             aggfunc=np.sum).reset_index()
weekly_sales = pd.merge(left=street_date[[('IMDB_Title_Code', ''), ('Theatrical_Release_Date', ''), ('Street_Date', 'Blu-ray'), ('Street_Date', 'DVD'), ('Street_Date', 'EST'), ('Street_Date', 'cVOD'), ('Street_Date', 'iVOD')]],
                        right = studio[[('IMDB_Title_Code', ''), ('Studio', 'Blu-ray'), ('Studio', 'DVD'), ('Studio', 'EST'), ('Studio', 'cVOD'), ('Studio', 'iVOD')]],
                        how='left',
                        left_on = ['IMDB_Title_Code'],
                        right_on = ['IMDB_Title_Code'],
                        sort = True,
                        copy = False)
weekly_sales = pd.merge(left=weekly_sales,
                        right = Revenue[[('IMDB_Title_Code', ''), ('Revenue', 'Blu-ray'), ('Revenue', 'DVD'), ('Revenue', 'EST'), ('Revenue', 'cVOD'), ('Revenue', 'iVOD')]],
                        how='left',
                        left_on = ['IMDB_Title_Code'],
                        right_on = ['IMDB_Title_Code'],
                        sort = True,
                        copy = False)
weekly_sales = pd.merge(left=weekly_sales,
                        right = Units[[('IMDB_Title_Code', ''), ('Units', 'Blu-ray'), ('Units', 'DVD'), ('Units', 'EST'), ('Units', 'cVOD'), ('Units', 'iVOD')]],
                        how='left',
                        left_on = ['IMDB_Title_Code'],
                        right_on = ['IMDB_Title_Code'],
                        sort = True,
                        copy = False)
#  removing objects to free memory
del Revenue, Units, gp_data, street_date, phys_digi, studio, Digital_Weekly_Sales_v3, Physical_Weekly_Sales_v3
weekly_sales.columns = ['IMDB_Title_Code',
                        'Theatrical_Release_Date',
                        'Blu-ray_Street_Date',
                        'DVD_Street_Date',
                        'EST_Street_Date',
                        'cVOD_Street_Date',
                        'iVOD_Street_Date',
                        'Blu-ray_Studio',
                        'DVD_Studio',
                        'EST_Studio',
                        'cVOD_Studio',
                        'iVOD_Studio',
                        'Blu-ray_Revenue',
                        'DVD_Revenue',
                        'EST_Revenue',
                        'cVOD_Revenue',
                        'iVOD_Revenue',
                        'Blu-ray_Sold',
                        'DVD_Sold',
                        'EST_Sold',
                        'cVOD_Sold',
                        'iVOD_Sold']

# correcting date_time format
weekly_sales['Theatrical_Release_Date'] = pd.to_datetime(arg=weekly_sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
weekly_sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=weekly_sales['Blu-ray_Street_Date'], infer_datetime_format=True, errors="coerce")
weekly_sales['DVD_Street_Date'] = pd.to_datetime(arg=weekly_sales['DVD_Street_Date'], infer_datetime_format=True, errors="coerce")
weekly_sales['EST_Street_Date'] = pd.to_datetime(arg=weekly_sales['EST_Street_Date'], infer_datetime_format=True, errors="coerce")
weekly_sales['cVOD_Street_Date'] = pd.to_datetime(arg=weekly_sales['cVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
weekly_sales['iVOD_Street_Date'] = pd.to_datetime(arg=weekly_sales['iVOD_Street_Date'], infer_datetime_format=True, errors="coerce")

# deleting titles whose HE release date is before BO release date
weekly_sales['BO_Window'] = (weekly_sales['Theatrical_Release_Date'] - weekly_sales[['Blu-ray_Street_Date', 'DVD_Street_Date', 'EST_Street_Date', 'cVOD_Street_Date', 'iVOD_Street_Date']].min(axis = 1))/pd.offsets.Day(-1)
for i in weekly_sales.index :
    if weekly_sales.loc[i, 'BO_Window'] < 0 :
        weekly_sales = weekly_sales.drop(index=i, axis=0)
weekly_sales.drop(['BO_Window'], axis = 1, inplace = True)
del i
weekly_sales.drop_duplicates(inplace=True)





# correcting date columns
weekly_sales['Theatrical_Release_Date'] = pd.to_datetime(arg=weekly_sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
weekly_sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=weekly_sales['Blu-ray_Street_Date'], infer_datetime_format=True, errors="coerce")
weekly_sales['DVD_Street_Date'] = pd.to_datetime(arg=weekly_sales['DVD_Street_Date'], infer_datetime_format=True, errors="coerce")
weekly_sales['EST_Street_Date'] = pd.to_datetime(arg=weekly_sales['EST_Street_Date'], infer_datetime_format=True, errors="coerce")
weekly_sales['cVOD_Street_Date'] = pd.to_datetime(arg=weekly_sales['cVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
weekly_sales['iVOD_Street_Date'] = pd.to_datetime(arg=weekly_sales['iVOD_Street_Date'], infer_datetime_format=True, errors="coerce")

# Master AD creation
master_AD = weekly_sales.merge(right = Spend_data.loc[Spend_data['Studio']=='WARNER',['IMDB_Title_Code', 'BO_Spend', 'Studio']],
                                    how ='inner',
                                    left_on = ['IMDB_Title_Code'],
                                    right_on = ['IMDB_Title_Code'],
                                    sort = True,
                                    copy = False)
master_AD = master_AD.merge(right = Total_Theater_Sales_v3[['IMDB_Title_Code', 'Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount', 'Opening_Weekend_BO', 'Opening_Weekend_Runs']],
                            how ='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)
master_AD = master_AD.merge(right = Comp_Spending_v3,
                            how='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)

# calculating BO Revenue
master_AD['BO_Revenue'] = master_AD[['Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount']].sum(axis = 1)

# calculating BO Window
master_AD['HE_Release_Date'] = master_AD[['Blu-ray_Street_Date', 'DVD_Street_Date', 'EST_Street_Date', 'cVOD_Street_Date', 'iVOD_Street_Date']].min(axis = 1)
master_AD['BO_Window'] = (master_AD['Theatrical_Release_Date'] - master_AD['HE_Release_Date'])/pd.offsets.Day(-1)

# getting movie titles
master_AD = master_AD.merge(right = all_movie_list[['IMDB_Title_Code', 'Movie_Title']],
                            how='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)
master_AD = master_AD[['IMDB_Title_Code', 'Movie_Title', 'Theatrical_Release_Date', 'HE_Release_Date',
                       'Genre', 'Studio',
                       'BO_Spend', 'BO_Revenue', 'BO_Window',
                       'Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount',
                       'Opening_Weekend_BO', 'Opening_Weekend_Runs']]

master_AD.rename(columns = {'Studio' : 'Theatrical_Studio',
                            'BO_Spend' : 'BO_Media_Spend'},
                 inplace = True)

del weekly_sales, Comp_Spending_v3, Total_Theater_Sales_v3, Spend_data, all_movie_list
master_AD.drop_duplicates(inplace=True)

# exporting dataset
master_AD.to_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\04. Analysis\Analytical Datasets\Set 1 - WB Base\BO AD\BO_Base_AD_WB_v1.0.csv', index = False)

