# importing packages
import pandas as pd

# importing datasets
Weekly_Sales_v1_0 = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\HE_Sales_v1.1_null_EST_Replaced.csv',
                                sep = ',',
                                encoding = 'latin-1')
Comp_Spending_v3 = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Comp_Spending_v3.csv',
                                sep = ',',
                                encoding = 'latin-1')
del Comp_Spending_v3['Studio']
Total_Theater_Sales_v3 = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Total_Theater_Sales_v3.csv',
                                sep = ',',
                                encoding = 'latin-1')
Spend_data = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Sales_data_v1.1.csv',
                                sep = ',',
                                encoding = 'latin-1')
all_movie_list = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\all_movie_mappings.csv',
                                sep = ',',
                                encoding = 'latin-1')

# correcting date columns
Weekly_Sales_v1_0['Theatrical_Release_Date'] = pd.to_datetime(arg=Weekly_Sales_v1_0['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Weekly_Sales_v1_0['Blu-ray_Street_Date'] = pd.to_datetime(arg=Weekly_Sales_v1_0['Blu-ray_Street_Date'], infer_datetime_format=True, errors="coerce")
Weekly_Sales_v1_0['DVD_Street_Date'] = pd.to_datetime(arg=Weekly_Sales_v1_0['DVD_Street_Date'], infer_datetime_format=True, errors="coerce")
Weekly_Sales_v1_0['EST_Street_Date'] = pd.to_datetime(arg=Weekly_Sales_v1_0['EST_Street_Date'], infer_datetime_format=True, errors="coerce")
Weekly_Sales_v1_0['cVOD_Street_Date'] = pd.to_datetime(arg=Weekly_Sales_v1_0['cVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
Weekly_Sales_v1_0['iVOD_Street_Date'] = pd.to_datetime(arg=Weekly_Sales_v1_0['iVOD_Street_Date'], infer_datetime_format=True, errors="coerce")

# imputing Media Spends from Comp_Spending file
# Comp_Spending_v3['BO_Media_Spend'] = Comp_Spending_v3['Total_Media_Spend']
# Comp_Spending_v3['EST_Media_Spend'] = Comp_Spending_v3['Total_Media_Spend']*(3/5)
# Comp_Spending_v3['PST_Media_Spend'] = Comp_Spending_v3['Total_Media_Spend']*(2/5)
# Comp_Spending_v3 = Comp_Spending_v3.loc[Comp_Spending_v3['Studio'] != "WARNER", ['IMDB_Title_Code', 'Studio', 'Genre', 'BO_Media_Spend', 'EST_Media_Spend', 'PST_Media_Spend']]

# Master AD creation
master_AD = pd.merge(left=Spend_data.loc[Spend_data['Studio']!='WARNER', ['IMDB_Title_Code', 'Studio', 'BO_Spend', 'EST_Spend', 'PST_Spend']],
                     right = Weekly_Sales_v1_0,
                            how='inner',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)
master_AD = pd.merge(left=master_AD,
                     right = Comp_Spending_v3,
                            how='inner',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)
master_AD = master_AD.merge(right = Total_Theater_Sales_v3,
                            how='inner',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)

# calculating only one EST and one PST date
master_AD['EST_Release_Date'] = master_AD[['EST_Street_Date', 'cVOD_Street_Date', 'iVOD_Street_Date']].min(axis = 1)
master_AD['PST_Release_Date'] = master_AD[['Blu-ray_Street_Date', 'DVD_Street_Date']].min(axis = 1)

# calculating Revenues
master_AD['BO_Revenue'] = master_AD[['Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount']].sum(axis = 1)
master_AD['EST_Revenue'] = master_AD[['EST_Revenue', 'cVOD_Revenue', 'iVOD_Revenue']].sum(axis = 1)
master_AD['PST_Revenue'] = master_AD[['Blu-ray_Revenue', 'DVD_Revenue']].sum(axis = 1)

# calculating tickets sold
master_AD['EST_Sold'] = master_AD[['EST_Sold', 'cVOD_Sold', 'iVOD_Sold']].sum(axis = 1)
master_AD['PST_Sold'] = master_AD[['Blu-ray_Sold', 'DVD_Sold']].sum(axis = 1)

master_AD.rename(columns = {'EST_Studio' : 'EST_Studio_old'}, inplace = True)
master_AD['EST_Studio'] = None
master_AD['PST_Studio'] = None
for i in range(master_AD.shape[0]):
    if len(pd.unique(master_AD.loc[i, ['EST_Studio_old', 'cVOD_Studio', 'iVOD_Studio']].dropna())) == 0 :
        master_AD.loc[i, ['EST_Studio']] = None
    else :
        master_AD.loc[i, ['EST_Studio']] = pd.unique(master_AD.loc[i, ['EST_Studio_old', 'cVOD_Studio', 'iVOD_Studio']].dropna())
    if len(pd.unique(master_AD.loc[i, ['DVD_Studio', 'Blu-ray_Studio']].dropna())) == 0 :
        master_AD.loc[i, ['PST_Studio']] = None
    else :
        master_AD.loc[i, ['PST_Studio']] = pd.unique(master_AD.loc[i, ['DVD_Studio', 'Blu-ray_Studio']].dropna())
del i

# calculating BO Window
master_AD['HE_Release_Date'] = master_AD[['PST_Release_Date', 'EST_Release_Date']].min(axis = 1)
master_AD['BO_Window'] = (master_AD['Theatrical_Release_Date_x'] - master_AD['HE_Release_Date'])/pd.offsets.Day(-1)

# getting movie titles
master_AD = master_AD.merge(right = all_movie_list[['IMDB_Title_Code', 'Movie_Title']],
                            how='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)

master_AD = master_AD[['IMDB_Title_Code', 'Movie_Title', 'Genre',
                       'Studio', 'EST_Studio', 'PST_Studio',
                       'Theatrical_Release_Date_x', 'EST_Release_Date', 'PST_Release_Date', 'BO_Window',
                       'BO_Spend', 'EST_Spend', 'PST_Spend',
                       'BO_Revenue', 'EST_Revenue', 'PST_Revenue',
                       'EST_Sold', 'PST_Sold',
                       'Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount',
                       'Opening_Weekend_BO', 'Opening_Weekend_Runs']]
master_AD.rename(columns = {'BO_Spend' : 'BO_Media_Spend',
                            'EST_Spend' : 'EST_Media_Spend',
                            'PST_Spend' : 'PST_Media_Spend',
                            'Studio' : 'Theatrical_Studio',
                            'Theatrical_Release_Date_x' : 'Theatrical_Release_Date'},
                 inplace = True)

#  removing objects to free memory
del Comp_Spending_v3, Total_Theater_Sales_v3, Weekly_Sales_v1_0, all_movie_list
master_AD.drop_duplicates(inplace=True)

# exporting dataset
master_AD.to_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\HE ADs\HE_master_AD_non_WB_v1.2.csv', index = False)
