# importing packages
import pandas as pd

# importing datasets
Weekly_Sales_v1_0 = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\HE_Sales_v1.1_null_EST_Replaced.csv',
                                sep = ',',
                                encoding = 'latin-1')
Comp_Spending_v3 = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Comp_Spending_v3.csv',
                                sep = ',',
                                encoding = 'latin-1')
del Comp_Spending_v3['Studio']
Total_Theater_Sales_v3 = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Total_Theater_Sales_v3.csv',
                                sep = ',',
                                encoding = 'latin-1')
Spend_data = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Sales_data_v1.1.csv',
                                sep = ',',
                                encoding = 'latin-1')
all_movie_list = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\all_movie_mappings.csv',
                                sep = ',',
                                encoding = 'latin-1')

# correcting date columns
Weekly_Sales_v1_0['Theatrical_Release_Date'] = pd.to_datetime(arg=Weekly_Sales_v1_0['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Weekly_Sales_v1_0['Blu-ray_Street_Date'] = pd.to_datetime(arg=Weekly_Sales_v1_0['Blu-ray_Street_Date'], infer_datetime_format=True, errors="coerce")
Weekly_Sales_v1_0['DVD_Street_Date'] = pd.to_datetime(arg=Weekly_Sales_v1_0['DVD_Street_Date'], infer_datetime_format=True, errors="coerce")
Weekly_Sales_v1_0['EST_Street_Date'] = pd.to_datetime(arg=Weekly_Sales_v1_0['EST_Street_Date'], infer_datetime_format=True, errors="coerce")
Weekly_Sales_v1_0['cVOD_Street_Date'] = pd.to_datetime(arg=Weekly_Sales_v1_0['cVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
Weekly_Sales_v1_0['iVOD_Street_Date'] = pd.to_datetime(arg=Weekly_Sales_v1_0['iVOD_Street_Date'], infer_datetime_format=True, errors="coerce")

# Master AD creation
master_AD = Weekly_Sales_v1_0.merge(right = Spend_data.loc[Spend_data['Studio']=='WARNER',['IMDB_Title_Code', 'BO_Spend', 'Studio']],
                                    how ='inner',
                                    left_on = ['IMDB_Title_Code'],
                                    right_on = ['IMDB_Title_Code'],
                                    sort = True,
                                    copy = False)
master_AD = master_AD.merge(right = Total_Theater_Sales_v3[['IMDB_Title_Code', 'Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount', 'Opening_Weekend_BO', 'Opening_Weekend_Runs']],
                            how ='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)
master_AD = master_AD.merge(right = Comp_Spending_v3,
                            how='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)

# calculating BO Revenue
master_AD['BO_Revenue'] = master_AD[['Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount']].sum(axis = 1)

# calculating BO Window
master_AD['HE_Release_Date'] = master_AD[['Blu-ray_Street_Date', 'DVD_Street_Date', 'EST_Street_Date', 'cVOD_Street_Date', 'iVOD_Street_Date']].min(axis = 1)
master_AD['BO_Window'] = (master_AD['Theatrical_Release_Date'] - master_AD['HE_Release_Date'])/pd.offsets.Day(-1)

# getting movie titles
master_AD = master_AD.merge(right = all_movie_list[['IMDB_Title_Code', 'Movie_Title']],
                            how='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)
master_AD = master_AD[['IMDB_Title_Code', 'Movie_Title', 'Theatrical_Release_Date', 'HE_Release_Date',
                       'Genre', 'Studio',
                       'BO_Spend', 'BO_Revenue', 'BO_Window',
                       'Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount',
                       'Opening_Weekend_BO', 'Opening_Weekend_Runs']]

master_AD.rename(columns = {'Studio' : 'Theatrical_Studio',
                            'BO_Spend' : 'BO_Media_Spend'},
                 inplace = True)

del Weekly_Sales_v1_0, Comp_Spending_v3, Total_Theater_Sales_v3, Spend_data, all_movie_list
master_AD.drop_duplicates(inplace=True)

# exporting dataset
master_AD.to_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\BO ADs\BO_master_AD_WB_v1.2.csv', index = False)
