# @author: sandeep / hanaa

# set local path for synced sharepoint
sharepoint_path = r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/'

# importing modules
import pandas as pd
import math

# reading datasets
BO_Spend = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\BO_Spend.csv',
                       sep = ',',
                       encoding = 'latin-1')
BO_Spend['Studio'] = 'WARNER' # Since this file only contain WB titles
Comp_Spending_v3 = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Comp_Spending_v3.csv',
                               sep = ',',
                               encoding = 'latin-1')
Comp_Spending_v3['Street_Date'] = pd.to_datetime(arg=Comp_Spending_v3['Street_Date'], infer_datetime_format=True, errors="coerce")
Comp_Spending_v3.drop(index=Comp_Spending_v3.loc[(Comp_Spending_v3['IMDB_Title_Code']=='tt0762125') & (Comp_Spending_v3['Studio']=='DISNEY'),:].index,
                      axis=0, # as per IMDB, Title Code: 'tt0762125' is not DISNEY's production
                      inplace=True)
Comp_Spending_v3.drop(index=Comp_Spending_v3.loc[(Comp_Spending_v3['IMDB_Title_Code']=='tt0765429') & (Comp_Spending_v3['Street_Date']==pd.Timestamp(year=2008, month=3, day=18)),:].index,
                      axis=0, # deleting duplicate title code with street date later than the other than
                      inplace=True)
Total_Media2_v3 = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Total Media2_v3.csv',
                              sep = ',',
                              encoding = 'latin-1')
Total_Media2_v3['Studio'] = 'WARNER' # Since this file only contain WB titles
Total_Media2_v3.rename(columns={'EST' : 'Raw_EST'}, inplace=True)
all_movie_list = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\all_movie_mappings.csv',
                             sep = ',', # file contains IMDB Title Codes and IMDB Title Names of all movies received from client
                             encoding = 'latin-1')

# Spend Ratio Split
# for WB
WB_BO_spend_ratio = 5
WB_EST_spend_ratio = 3
WB_PST_spend_ratio = 2
# for competitor
nonWB_BO_spend_ratio = 18
nonWB_EST_spend_ratio = 1
nonWB_PST_spend_ratio = 1

# merging available BO spend data for all titles
spend_data = pd.merge(left=all_movie_list,
                      right=BO_Spend[['IMDB_Title_Code', 'BO_Spend', 'Studio']],
                      how='left',
                      left_on=['IMDB_Title_Code'],
                      right_on = ['IMDB_Title_Code'],
                      sort = True,
                      copy = False)
spend_data.rename(columns={'Studio' : 'Studio_BO_Spend'}, inplace=True)
# merging HE spend data from Comp_Spending file, for all titles
spend_data = pd.merge(left=spend_data,
                      right=Comp_Spending_v3[['IMDB_Title_Code', 'Studio', 'Total_Media_Spend']],
                      how='left',
                      left_on=['IMDB_Title_Code'],
                      right_on = ['IMDB_Title_Code'],
                      sort = True,
                      copy = False)
spend_data.rename(columns={'Studio' : 'Studio_CompSpend'}, inplace=True)
# merging Total HE, EST, VOD and PST spend data from Total_Media2 file, for all titles
spend_data = pd.merge(left=spend_data,
                      right=Total_Media2_v3[['IMDB_Title_Code', 'TOTAL_CONSUMER_MEDIA', 'PHYSICAL_MEDIA', 'Raw_EST', 'VOD', 'Studio']],
                      how='left',
                      left_on=['IMDB_Title_Code'],
                      right_on = ['IMDB_Title_Code'],
                      sort = True,
                      copy = False)
spend_data.rename(columns={'Studio' : 'Studio_TotMedia'},
                  inplace=True)

# dropping all titles with no spend data
spend_data.dropna(subset=['BO_Spend',
                         'Total_Media_Spend',
                         'TOTAL_CONSUMER_MEDIA',
                         'PHYSICAL_MEDIA',
                         'Raw_EST',
                         'VOD'],
                  how='all',
                  inplace=True)

spend_data['EST_Revenue'] = spend_data['Raw_EST']+spend_data['VOD']
spend_data.reset_index(inplace=True, drop=True)

# assigning Studio for all titles
spend_data['Studio'] = math.nan
for i in range((spend_data.shape)[0]) :
    spend_data.loc[i, 'Studio'] = spend_data.loc[i, ['Studio_BO_Spend', 'Studio_CompSpend', 'Studio_TotMedia']].dropna().unique()
del i # dropping unnecessary objects to free memory

# extrapolating missing BO/EST/PST spend data
spend_data['BO'] = math.nan
spend_data['EST'] = math.nan
spend_data['PST'] = math.nan
for i in range((spend_data.shape)[0]) :
    if spend_data.loc[i,'Studio']=='WARNER' : # Imputation of missing BO/EST/PST spend data for WB titles
        if (math.isnan(spend_data.loc[i,'BO_Spend'])!=True) & (math.isnan(spend_data.loc[i,'Total_Media_Spend'])!=True) & (math.isnan(spend_data.loc[i,'TOTAL_CONSUMER_MEDIA'])!=True) :
            spend_data.loc[i, 'BO'] = spend_data.loc[i, 'BO_Spend']
            spend_data.loc[i, 'EST'] = spend_data.loc[i, 'EST_Revenue']
            spend_data.loc[i, 'PST'] = spend_data.loc[i, 'PHYSICAL_MEDIA']
        elif (math.isnan(spend_data.loc[i,'BO_Spend'])!=True) & (math.isnan(spend_data.loc[i,'Total_Media_Spend'])!=False) & (math.isnan(spend_data.loc[i,'TOTAL_CONSUMER_MEDIA'])!=True) :
            spend_data.loc[i, 'BO'] = spend_data.loc[i, 'BO_Spend']
            spend_data.loc[i, 'EST'] = spend_data.loc[i, 'EST_Revenue']
            spend_data.loc[i, 'PST'] = spend_data.loc[i, 'PHYSICAL_MEDIA']
        elif (math.isnan(spend_data.loc[i, 'BO_Spend']) != True) & (math.isnan(spend_data.loc[i, 'Total_Media_Spend']) != True) & (math.isnan(spend_data.loc[i, 'TOTAL_CONSUMER_MEDIA']) != False):
            spend_data.loc[i, 'BO'] = spend_data.loc[i, 'BO_Spend']
            spend_data.loc[i, 'EST'] = spend_data.loc[i, 'Total_Media_Spend']*(WB_EST_spend_ratio/(WB_EST_spend_ratio+WB_PST_spend_ratio))
            spend_data.loc[i, 'PST'] = spend_data.loc[i, 'Total_Media_Spend']*(WB_PST_spend_ratio/(WB_EST_spend_ratio+WB_PST_spend_ratio))
        elif (math.isnan(spend_data.loc[i, 'BO_Spend']) != True) & (math.isnan(spend_data.loc[i, 'Total_Media_Spend']) != False) & (math.isnan(spend_data.loc[i, 'TOTAL_CONSUMER_MEDIA']) != False):
            spend_data.loc[i, 'BO'] = spend_data.loc[i, 'BO_Spend']
            spend_data.loc[i, 'EST'] = spend_data.loc[i, 'BO_Spend']*(WB_EST_spend_ratio/(WB_EST_spend_ratio+WB_PST_spend_ratio))
            spend_data.loc[i, 'PST'] = spend_data.loc[i, 'BO_Spend']*(WB_PST_spend_ratio/(WB_EST_spend_ratio+WB_PST_spend_ratio))
        elif (math.isnan(spend_data.loc[i, 'BO_Spend']) != False) & (math.isnan(spend_data.loc[i, 'Total_Media_Spend']) != True) & (math.isnan(spend_data.loc[i, 'TOTAL_CONSUMER_MEDIA']) != True):
            spend_data.loc[i, 'BO'] = spend_data.loc[i, 'TOTAL_CONSUMER_MEDIA']*(WB_BO_spend_ratio/(WB_EST_spend_ratio+WB_PST_spend_ratio))
            spend_data.loc[i, 'EST'] = spend_data.loc[i, 'EST_Revenue']
            spend_data.loc[i, 'PST'] = spend_data.loc[i, 'PHYSICAL_MEDIA']
        elif (math.isnan(spend_data.loc[i, 'BO_Spend']) != False) & (math.isnan(spend_data.loc[i, 'Total_Media_Spend']) != False) & (math.isnan(spend_data.loc[i, 'TOTAL_CONSUMER_MEDIA']) != True):
            spend_data.loc[i, 'BO'] = spend_data.loc[i, 'TOTAL_CONSUMER_MEDIA']*(WB_BO_spend_ratio/(WB_EST_spend_ratio+WB_PST_spend_ratio))
            spend_data.loc[i, 'EST'] = spend_data.loc[i, 'EST_Revenue']
            spend_data.loc[i, 'PST'] = spend_data.loc[i, 'PHYSICAL_MEDIA']
        elif (math.isnan(spend_data.loc[i, 'BO_Spend']) != False) & (math.isnan(spend_data.loc[i, 'Total_Media_Spend']) != True) & (math.isnan(spend_data.loc[i, 'TOTAL_CONSUMER_MEDIA']) != False):
            spend_data.loc[i, 'BO'] = spend_data.loc[i, 'Total_Media_Spend']*(WB_BO_spend_ratio/(WB_EST_spend_ratio+WB_PST_spend_ratio))
            spend_data.loc[i, 'EST'] = spend_data.loc[i, 'Total_Media_Spend']*(WB_EST_spend_ratio/(WB_EST_spend_ratio+WB_PST_spend_ratio))
            spend_data.loc[i, 'PST'] = spend_data.loc[i, 'Total_Media_Spend']*(WB_PST_spend_ratio/(WB_EST_spend_ratio+WB_PST_spend_ratio))
    else : # Imputation of missing BO/EST/PST spend data for Non-WB titles
        spend_data.loc[i, 'BO'] = spend_data.loc[i, 'Total_Media_Spend']*(nonWB_BO_spend_ratio/(nonWB_EST_spend_ratio+nonWB_PST_spend_ratio))
        spend_data.loc[i, 'EST'] = spend_data.loc[i, 'Total_Media_Spend']*(nonWB_EST_spend_ratio/(nonWB_EST_spend_ratio+nonWB_PST_spend_ratio))
        spend_data.loc[i, 'PST'] = spend_data.loc[i, 'Total_Media_Spend']*(nonWB_PST_spend_ratio/(nonWB_EST_spend_ratio+nonWB_PST_spend_ratio))
del i, WB_BO_spend_ratio, WB_EST_spend_ratio, WB_PST_spend_ratio, nonWB_BO_spend_ratio, nonWB_EST_spend_ratio, nonWB_PST_spend_ratio # dropping unnecessary objects to free memory

# arranging columns
spend_data = spend_data[['IMDB_Title_Code',
                         'Movie_Title',
                         'Studio',
                         #'BO_Spend',
                         #'Total_Media_Spend',
                         #'TOTAL_CONSUMER_MEDIA',
                         #'PHYSICAL_MEDIA',
                         #'EST_Revenue',
                         'BO',
                         'EST',
                         'PST'
                         #'Studio_BO_Spend',
                         #'Studio_CompSpend',
                         #'Studio_TotMedia'
                         ]]
spend_data.rename(columns={'BO' : 'BO_Spend',
                           'EST' : 'EST_Spend',
                           'PST' : 'PST_Spend'}, inplace=True)

# exporting sales data
spend_data.to_csv(path_or_buf = r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Spends_data_v1.1.csv',
                  index=False)
