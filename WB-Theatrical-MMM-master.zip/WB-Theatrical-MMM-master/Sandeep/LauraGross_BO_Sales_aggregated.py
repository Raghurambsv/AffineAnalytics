# author=Sandeep Sanyal

# set local path for synced sharepoint
sharepoint_path = r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/'

import pandas as pd
start_time = pd.datetime.now()

# reading datasets
bo_df = pd.read_excel(io=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Latest\LauraGross.2019.02.11.xlsx",
                      sheet_name='Box',
                      header=1)
all_movie_list = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Final_Mapping_Data_v4.csv",
                             sep = ',',
                             encoding = 'latin-1')
bo_df['YEAR'] = bo_df['Theatrical Release Date'].dt.year

# dropping duplicate entries
bo_df.drop_duplicates(inplace=True)
all_movie_list.drop_duplicates(inplace=True)

# appending IMDB_Title_Codes
master_AD = pd.merge(left = bo_df,
                     right = all_movie_list[['Title',
                                             'IMDB_Title_Code',
                                             'Release Year_WB']],
                     how='inner',
                     left_on = ['Title',
                                'YEAR'],
                     right_on = ['Title',
                                 'Release Year_WB'],
                     sort = True,
                     copy = False)
del bo_df, all_movie_list # dropping unnecessary objects to free memory
master_AD.loc[(master_AD['Title'] == 'First Love') & (master_AD['Theatrical Release Date'] == pd.Timestamp(year=2018, month=2, day=8)), 'IMDB_Title_Code'] = 'tt7705790'
master_AD.loc[(master_AD['Title'] == 'First Love') & (master_AD['Theatrical Release Date'] == pd.Timestamp(year=2018, month=10, day=26)), 'IMDB_Title_Code'] = 'tt9060390'
master_AD.loc[(master_AD['Title'] == 'Fallen') & (master_AD['Theatrical Release Date'] == pd.Timestamp(year=2017, month=9, day=8)), 'IMDB_Title_Code'] = 'tt1564777'
master_AD.loc[(master_AD['Title'] == 'Fallen') & (master_AD['Theatrical Release Date'] == pd.Timestamp(year=2017, month=4, day=7)), 'IMDB_Title_Code'] = 'tt3240622'
master_AD.loc[(master_AD['Title'] == 'Gold') & (master_AD['Theatrical Release Date'] == pd.Timestamp(year=2017, month=1, day=27)), 'IMDB_Title_Code'] = 'tt1800302'
master_AD.loc[(master_AD['Title'] == 'Gold') & (master_AD['Theatrical Release Date'] == pd.Timestamp(year=2017, month=12, day=1)), 'IMDB_Title_Code'] = 'tt5162658'
master_AD.loc[(master_AD['Title'] == 'Three') & (master_AD['Theatrical Release Date'] == pd.Timestamp(year=2016, month=6, day=24)), 'IMDB_Title_Code'] = 'tt4379728'
master_AD.loc[(master_AD['Title'] == 'Three') & (master_AD['Theatrical Release Date'] == pd.Timestamp(year=2016, month=6, day=10)), 'IMDB_Title_Code'] = 'tt4814290'
master_AD.loc[(master_AD['Title'] == 'Reset') & (master_AD['Theatrical Release Date'] == pd.Timestamp(year=2017, month=1, day=13)), 'IMDB_Title_Code'] = 'tt5419742'
master_AD.loc[(master_AD['Title'] == 'Reset') & (master_AD['Theatrical Release Date'] == pd.Timestamp(year=2017, month=6, day=30)), 'IMDB_Title_Code'] = 'tt5342650'

# arranging columns
master_AD = master_AD[['IMDB_Title_Code',
                       'Title',
                       'Genre',
                       'Studio',
                       'Theatrical Release Date',
                       'Fiscal Week',
                       'Week Begin',
                       'Week End',
                       'Box Office']]
master_AD.drop_duplicates(inplace=True)
# aggregating week level data to title level data
gp_data = master_AD.groupby(['IMDB_Title_Code',
                             'Title',
                             'Genre',
                             'Studio',
                             'Theatrical Release Date']).agg({'Week Begin':'min',
                                                              'Week End':'max',
                                                              'Box Office':'sum'}).reset_index()

# exporting BO Sales Data
gp_data.to_csv(path_or_buf=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Laura_BO_sales_v1.0.csv",
               index=False)
# exporting Weekly BO Sales Data
master_AD.to_csv(path_or_buf=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Weekly_BO_sales_v1.0.csv",
                 index=False)

print("Program Complete")
print("Time Elapsed: " + str(pd.datetime.now()-start_time))
