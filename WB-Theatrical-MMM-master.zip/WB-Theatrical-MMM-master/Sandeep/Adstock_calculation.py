import numpy as np
import pandas as pd

# Function to calculate Adstock of a column given a decay rate
def calculate_adstock(
    spend_column,
    decay_rate,
    df
):
    df2 = pd.DataFrame(
        {

        }
    )
    df[spend_column+" Adstock|"+str(decay_rate)] = np.NaN
    for i in df["IMDB Title Code"].unique():
        temp = df.loc[df["IMDB Title Code"]==i, :].reset_index(drop=True)
        # filling all NaN values in spends with 0
        temp.fillna(
            {
                spend_column: 0
            },
            inplace=True
        )
        for j in temp.index:
            if j == 0:
                temp.loc[j, spend_column+" Adstock|"+str(decay_rate)] = temp.loc[j, spend_column]
            else:
                temp.loc[j, spend_column+" Adstock|"+str(decay_rate)] = (
                    # Current Week's Spend
                    temp.loc[j, spend_column] +
                    (
                        # Previous Week's Adstock Spend
                        temp.loc[j-1, spend_column+" Adstock|"+str(decay_rate)] *
                        # Decay Rate
                        decay_rate
                    )
                )
        df2 = pd.concat(
            [
                df2,
                temp
            ],
            axis=0
        )

    return df2