# author=Sandeep Sanyal

# set local path for synced sharepoint
sharepoint_path = r"C:\Users\sande\Affine Analytics Pvt Ltd"

# importing libraries
import pandas as pd
# reading dataset
base_titles = pd.read_excel(io=sharepoint_path+r"\WB Theatrical - Documents\01. Data Harmonization-Cleaning\01. Base Data - As received\02. Spend Data\MEDIA_SPEND_KW_8.25.19.xlsx",
                          sheet_name="CAMPAIGN TOTALS",
                          header=2,
                          na_values=['#NA','#N/A','',' ','na','NA'])
base_file = pd.read_excel(io=sharepoint_path+r"\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\intermediate files\IMDB Mapping Data.xlsx",
                                  sheet_name='scrapped title ids')

base_titles['temp'] = base_titles['TITLE'].str.lower()
base_titles['temp'] = (base_titles['temp'].str.split(pat='(', expand=True))
base_titles['Cleaned Movie Name'] = base_titles['temp'].str.rstrip(' ')
base_titles.drop(['temp'], axis=1, inplace=True)

base_titles = pd.merge(left=base_titles,
         right=base_file[['Movie Name', 'IMDB Title Code', 'IMDB Title Name']],
         how='left',
         left_on='Cleaned Movie Name',
         right_on='Movie Name')
# exporting master_AD
with pd.ExcelWriter(
        path=r"C:\Users\sande\OneDrive\Desktop\temp.xlsx",
        mode='w',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    base_titles.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='temp',
        engine='openpyxl')