# author=Sandeep Sanyal

# set local path for synced sharepoint
sharepoint_path = r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/'

# importing modules
import pandas as pd
start_time = pd.datetime.now()
import numpy as np
import math
from datetime import timedelta

# reading datasets
# FB_Data = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 2 Data\Cleaned\FB Data\FB_Data_v1.0.csv",
#                       sep = ',',                # Contains Title-Week level Campaign data
#                       encoding = 'latin-1')
Weekly_BO_sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r"\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Weekly_BO_sales_v1.0.csv",
                              sep = ',',                # Contains Title-Week level BO Revenue
                              encoding = 'latin-1')
HE_sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\HE_Sales_v1.0.csv",
                       sep = ',',                       # Contains Title level Blu-ray, DVD, EST, iVOD, cVOD Revenues
                       encoding = 'latin-1')            # used to get unique PST and EST Release dates along with unique Studio per Title
Physical_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Physical_Weekly_Sales_v3.csv",
                                    sep = ',',       # Contains Title-Week level Blu-ray & DVD Revenue
                                    encoding = 'latin-1')
Digital_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Digital_Weekly_Sales_v3.csv",
                                   sep = ',',        # Contains Title-Week level EST, iVOD & cVOD Revenue
                                   encoding = 'latin-1')
title_maps = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Final_Mapping_Data_v4.csv",
                         sep = ',',
                         encoding = 'latin-1')

# correcting date columns
HE_sales['Theatrical_Release_Date'] = pd.to_datetime(arg=HE_sales['Theatrical_Release_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=HE_sales['Blu-ray_Street_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['DVD_Street_Date'] = pd.to_datetime(arg=HE_sales['DVD_Street_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['EST_Street_Date'] = pd.to_datetime(arg=HE_sales['EST_Street_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['cVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['cVOD_Street_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['iVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['iVOD_Street_Date'], format="%Y-%m-%d", errors="coerce")
Physical_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Street_Date'], format="%Y-%m-%d", errors="coerce")
Physical_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Theatrical_Release_Date'], format="%Y-%m-%d", errors="coerce")
Digital_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Street_Date'], format="%Y-%m-%d", errors="coerce")
Digital_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Theatrical_Release_Date'], format="%Y-%m-%d", errors="coerce")
# FB_Data['Day'] = pd.to_datetime(arg=FB_Data['Day'], infer_datetime_format=True)
Weekly_BO_sales['Theatrical Release Date'] = pd.to_datetime(arg=Weekly_BO_sales['Theatrical Release Date'], infer_datetime_format=True)
Weekly_BO_sales['Week Begin'] = pd.to_datetime(arg=Weekly_BO_sales['Week Begin'], infer_datetime_format=True)
Weekly_BO_sales['Week End'] = pd.to_datetime(arg=Weekly_BO_sales['Week End'], infer_datetime_format=True)

# preparing mapping file
# temp = title_maps[['Movie_Title', 'IMDB_Title_Code']]
# temp.rename(columns={'Movie_Title' : 'Title'}, inplace=True)
# title_maps = temp.append(title_maps[['Title', 'IMDB_Title_Code']])
# del temp
# title_maps.drop_duplicates(inplace=True)
# title_maps['Title_lowercase'] = title_maps['Title'].str.lower()

# mapping IMDB Title Codes with FB_data
# FB_Data['Title_lowercase'] = FB_Data['Title_Name'].str.lower()
# FB_Data = pd.merge(left=FB_Data,
#                    right=title_maps,
#                    how='left',
#                    left_on=['Title_lowercase'],
#                    right_on=['Title_lowercase'],
#                    sort=True,
#                    copy=False)
# # getting Theater Release Dates for FB_Data
# FB_Data = pd.merge(left=FB_Data,
#                    right=HE_sales[['IMDB_Title_Code',
#                                    'Theatrical_Release_Date']],
#                    how='left',
#                    left_on=['IMDB_Title_Code'],
#                    right_on=['IMDB_Title_Code'],
#                    sort=True,
#                    copy=False)
# FB_Data['Year'] = FB_Data['Day'].dt.year
# FB_Data['Month'] = FB_Data['Day'].dt.month

# # subseting datasets
# titles = pd.merge(left=FB_Data[['IMDB_Title_Code']].drop_duplicates(), # selecting titles with both Campaign and HE Sales data present
#                   right=HE_sales[['IMDB_Title_Code']],
#                   how='inner',
#                   left_on=['IMDB_Title_Code'],
#                   right_on=['IMDB_Title_Code'],
#                   sort=True,
#                   copy=False).iloc[:,0].tolist()
# FB_Data = FB_Data.loc[FB_Data['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)
titles = pd.merge(left=Weekly_BO_sales[['IMDB_Title_Code']].drop_duplicates(), # selecting titles with both Campaign and HE Sales data present
                  right=HE_sales[['IMDB_Title_Code']],
                  how='inner',
                  left_on=['IMDB_Title_Code'],
                  right_on=['IMDB_Title_Code'],
                  sort=True,
                  copy=False).iloc[:,0].tolist()
Weekly_BO_sales = Weekly_BO_sales.loc[Weekly_BO_sales['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)
HE_sales = HE_sales.loc[HE_sales['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)
Physical_Weekly_Sales = Physical_Weekly_Sales.loc[Physical_Weekly_Sales['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)
Digital_Weekly_Sales = Digital_Weekly_Sales.loc[Digital_Weekly_Sales['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)

# # fixing double studio issues
# Weekly_BO_sales
for i in Weekly_BO_sales['IMDB_Title_Code'].unique():
    temp = Weekly_BO_sales.loc[Weekly_BO_sales['IMDB_Title_Code']==i, :]
    if len(temp['Studio'].unique()) > 1:
        if temp['Studio'].str.contains('WARNER').sum() > 0:
            Weekly_BO_sales.drop(index=temp.loc[temp['Studio'] != 'WARNER'].index.values,
                                 axis=0,
                                 inplace=True)
        else:
            gp_data = temp.groupby(['IMDB_Title_Code',
                                    'Studio']).agg({'Box Office': 'sum'}).reset_index()
            if len(gp_data.loc[gp_data['Box Office'] == max(gp_data['Box Office']), 'Studio'].unique()) == 2:
                Weekly_BO_sales.drop(index=temp.loc[temp['Studio'] == 'ALL OTHER'].index.values,
                                          axis=0,
                                          inplace=True)
            elif len(gp_data.loc[gp_data['Box Office'] == max(gp_data['Box Office']), 'Studio'].unique()) == 1:
                Weekly_BO_sales.drop(index=Weekly_BO_sales.loc[(Weekly_BO_sales['IMDB_Title_Code'] == i) & (Weekly_BO_sales['Studio'] == (gp_data.loc[gp_data['Box Office'] != max(gp_data['Box Office']), 'Studio'].values)[0]), :].index.values,
                                     axis=0,
                                     inplace=True)
del temp, i
# Digital_Weekly_Sales
for i in Digital_Weekly_Sales['IMDB_Title_Code'].unique():
    temp1 = Digital_Weekly_Sales.loc[Digital_Weekly_Sales['IMDB_Title_Code'] == i, :]
    for j in temp1['Media_Type'].unique():
        temp2 = temp1.loc[temp1['Media_Type'] == j, :]
        if len(temp2['Studio'].unique()) > 1 :
            if temp2['Studio'].str.contains('WARNER').sum() > 0 :
                Digital_Weekly_Sales.drop(index=temp2.loc[temp1['Studio'] != 'WARNER'].index.values,
                                          axis=0,
                                          inplace=True)
            else :
                gp_data = temp2.groupby(['IMDB_Title_Code',
                                        'Item_Title_WW',
                                        'Studio',
                                        'Street_Date',
                                        'Theatrical_Release_Date']).agg({'Revenue': 'sum',
                                                                         'Units': 'sum'}).reset_index()
                if len(gp_data.loc[gp_data['Revenue'] == max(gp_data['Revenue']), 'Studio'].unique()) == 2 :
                    Digital_Weekly_Sales.drop(index=temp1.loc[temp1['Studio'] == 'ALL OTHERS'].index.values,
                                              axis=0,
                                              inplace=True)
                elif len(gp_data.loc[gp_data['Revenue'] == max(gp_data['Revenue']), 'Studio'].unique()) == 1:
                    Digital_Weekly_Sales.drop(index=Digital_Weekly_Sales.loc[(Digital_Weekly_Sales['IMDB_Title_Code'] == i) & (Digital_Weekly_Sales['Studio'] == (gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].values)[0]), :].index.values,
                                              axis=0,
                                              inplace=True)
        del temp2, gp_data
    del temp1, j
# Physical_Weekly_Sales
for i in Physical_Weekly_Sales['IMDB_Title_Code'].unique():
    temp1 = Physical_Weekly_Sales.loc[Physical_Weekly_Sales['IMDB_Title_Code'] == i, :]
    for j in temp1['Media_Type'].unique():
        temp2 = temp1.loc[temp1['Media_Type'] == j, :]
        if len(temp2['Studio'].unique()) > 1 :
            if temp2['Studio'].str.contains('WARNER').sum() > 0 :
                Physical_Weekly_Sales.drop(index=temp2.loc[temp2['Studio'] != 'WARNER'].index.values,
                                           axis=0,
                                           inplace=True)
            else :
                gp_data = temp2.groupby(['IMDB_Title_Code',
                                        'Item_Title_WW',
                                        'Studio',
                                        'Street_Date',
                                        'Theatrical_Release_Date']).agg({'Revenue': 'sum',
                                                                         'Units': 'sum'}).reset_index()
                if len(gp_data.loc[gp_data['Revenue'] == max(gp_data['Revenue']), 'Studio'].unique()) == 2 :
                    Physical_Weekly_Sales.drop(index=temp2.loc[temp2['Studio'] == 'ALL OTHERS'].index.values,
                                               axis=0,
                                               inplace=True)
                elif len(gp_data.loc[gp_data['Revenue'] == max(gp_data['Revenue']), 'Studio'].unique()) == 1 :
                    Physical_Weekly_Sales.drop(index=Physical_Weekly_Sales.loc[(Physical_Weekly_Sales['IMDB_Title_Code'] == i) & (Physical_Weekly_Sales['Studio'] == (gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].values)[0]), :].index.values,
                                               axis=0,
                                               inplace=True)
        del temp2, gp_data
    del temp1, j
del i

# fixing same studio, double release date issues
# Digital_Weekly_Sales
Digital_Weekly_Sales = Digital_Weekly_Sales.groupby(['IMDB_Title_Code',
                                                     'Item_Title_WW',
                                                     'Studio',
                                                     'Theatrical_Release_Date',
                                                     'Media_Type',
                                                     'Week']).agg({'Street_Date':'min',
                                                                   'Revenue':'sum',
                                                                   'Units':'sum'}).reset_index()
# Physical_Weekly_Sales
Physical_Weekly_Sales = Physical_Weekly_Sales.groupby(['IMDB_Title_Code',
                                                       'Item_Title_WW',
                                                       'Studio',
                                                       'Theatrical_Release_Date',
                                                       'Media_Type',
                                                       'Week']).agg({'Street_Date':'min',
                                                                     'Revenue':'sum',
                                                                     'Units':'sum'}).reset_index()

# creating list of all IMDB_Title_Codes & their Theatrical, EST & PST Release Dates
all_titles = HE_sales[['IMDB_Title_Code',
                       'Theatrical_Release_Date']]
del HE_sales # deleting objects to free memory
all_titles['DVD_Street_Date']=np.NaN
all_titles['Blu-ray_Street_Date']=np.NaN
all_titles['EST_Street_Date']=np.NaN
all_titles['iVOD_Street_Date']=np.NaN
all_titles['cVOD_Street_Date']=np.NaN
for i in all_titles['IMDB_Title_Code'].unique():
    all_titles.loc[all_titles['IMDB_Title_Code']==i, 'DVD_Street_Date'] = Physical_Weekly_Sales.loc[(Physical_Weekly_Sales['IMDB_Title_Code']==i) & (Physical_Weekly_Sales['Media_Type']=='DVD'),'Street_Date'].min()
    all_titles.loc[all_titles['IMDB_Title_Code']==i, 'Blu-ray_Street_Date'] = Physical_Weekly_Sales.loc[(Physical_Weekly_Sales['IMDB_Title_Code']==i) & (Physical_Weekly_Sales['Media_Type']=='Blu-ray'),'Street_Date'].min()
    all_titles.loc[all_titles['IMDB_Title_Code']==i, 'EST_Street_Date'] = Digital_Weekly_Sales.loc[(Digital_Weekly_Sales['IMDB_Title_Code']==i) & (Digital_Weekly_Sales['Media_Type']=='EST'),'Street_Date'].min()
    all_titles.loc[all_titles['IMDB_Title_Code']==i, 'iVOD_Street_Date'] = Digital_Weekly_Sales.loc[(Digital_Weekly_Sales['IMDB_Title_Code']==i) & (Digital_Weekly_Sales['Media_Type']=='iVOD'),'Street_Date'].min()
    all_titles.loc[all_titles['IMDB_Title_Code']==i, 'cVOD_Street_Date'] = Digital_Weekly_Sales.loc[(Digital_Weekly_Sales['IMDB_Title_Code']==i) & (Digital_Weekly_Sales['Media_Type']=='cVOD'),'Street_Date'].min()
del i
all_titles['Blu-ray_Street_Date'] = pd.to_datetime(arg=all_titles['Blu-ray_Street_Date'], format="%Y-%m-%d", errors="coerce")
all_titles['DVD_Street_Date'] = pd.to_datetime(arg=all_titles['DVD_Street_Date'], format="%Y-%m-%d", errors="coerce")
all_titles['EST_Street_Date'] = pd.to_datetime(arg=all_titles['EST_Street_Date'], format="%Y-%m-%d", errors="coerce")
all_titles['cVOD_Street_Date'] = pd.to_datetime(arg=all_titles['cVOD_Street_Date'], format="%Y-%m-%d", errors="coerce")
all_titles['iVOD_Street_Date'] = pd.to_datetime(arg=all_titles['iVOD_Street_Date'], format="%Y-%m-%d", errors="coerce")
all_titles['Week Begin'] = all_titles.loc[:,['Theatrical_Release_Date',
                                             'EST_Street_Date',
                                             'iVOD_Street_Date',
                                             'cVOD_Street_Date',
                                             'DVD_Street_Date',
                                             'Blu-ray_Street_Date']].min(axis=1)

# calculating Week number for FB_data, EST & PST Release dates
all_titles['EST_Week_Start'] = np.nan
all_titles['iVOD_Week_Start'] = np.nan
all_titles['cVOD_Week_Start'] = np.nan
all_titles['DVD_Week_Start'] = np.nan
all_titles['Blu-ray_Week_Start'] = np.nan
for i in all_titles['IMDB_Title_Code'].unique() :
    if pd.isnull(all_titles.loc[all_titles['IMDB_Title_Code']==i, 'Week Begin'].values[0]) :
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code']==i, 'Theatrical_Release_Date'] - all_titles.loc[all_titles['IMDB_Title_Code']==i, 'EST_Street_Date'])/pd.offsets.Day(-1))/7)+1
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'iVOD_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code']==i, 'Theatrical_Release_Date'] - all_titles.loc[all_titles['IMDB_Title_Code']==i, 'iVOD_Street_Date'])/pd.offsets.Day(-1))/7)+1
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'cVOD_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code']==i, 'Theatrical_Release_Date'] - all_titles.loc[all_titles['IMDB_Title_Code']==i, 'cVOD_Street_Date'])/pd.offsets.Day(-1))/7)+1
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'DVD_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code']==i, 'Theatrical_Release_Date'] - all_titles.loc[all_titles['IMDB_Title_Code']==i, 'DVD_Street_Date'])/pd.offsets.Day(-1))/7)+1
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Blu-ray_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Theatrical_Release_Date'] - all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Blu-ray_Street_Date'])/pd.offsets.Day(-1))/7)+1
    else :
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Week Begin'] - all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Street_Date'])/pd.offsets.Day(-1))/7)+1
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'iVOD_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Week Begin'] - all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'iVOD_Street_Date'])/pd.offsets.Day(-1))/7)+1
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'cVOD_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Week Begin'] - all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'cVOD_Street_Date'])/pd.offsets.Day(-1))/7)+1
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'DVD_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Week Begin'] - all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'DVD_Street_Date'])/pd.offsets.Day(-1))/7)+1
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Blu-ray_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Week Begin'] - all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Blu-ray_Street_Date'])/pd.offsets.Day(-1))/7)+1
    # FB_Data['Week'] = np.floor(((FB_Data['Theatrical_Release_Date'] - FB_Data['Day'])/pd.offsets.Day(-1))/7)
del i

Weekly_BO_sales = pd.merge(left=Weekly_BO_sales.drop('Theatrical Release Date', axis=1),
                           right=all_titles[['IMDB_Title_Code', 'Theatrical_Release_Date']],
                           how='left',
                           left_on='IMDB_Title_Code',
                           right_on='IMDB_Title_Code')
Weekly_BO_sales['Week_Number'] = np.floor(((Weekly_BO_sales['Week Begin'] - Weekly_BO_sales['Theatrical_Release_Date'])/pd.offsets.Day(1))/7)+1

# grouping FB_data
# gp_data=FB_Data.groupby(['IMDB_Title_Code',
#                          'Week']).agg({'Amt_Spent':'sum',
#                                        'Impressions':'sum',
#                                        'Clicks':'sum',
#                                        'Reach':'sum',
#                                        'Engagement':'sum',
#                                        'Likes':'sum',
#                                        'Comments':'sum',
#                                        'Shares':'sum',
#                                        'Day':['min', 'max']}).reset_index()

# calculating week numbers since release date
# Physical_Weekly_Sales
Weekly_PST_sales_1 = pd.DataFrame({'IMDB_Title_Code' : [],
                                   'Item_Title_WW' : [],
                                   'Studio' : [],
                                   'Street_Date' : [],
                                   'Theatrical_Release_Date' : [],
                                   'Media_Type' : [],
                                   'Week_Number' : [],
                                   'Revenue' : [],
                                   'Units' : []})
# for i in all_titles['IMDB_Title_Code'].unique() :
#     temp = Physical_Weekly_Sales.loc[Physical_Weekly_Sales['IMDB_Title_Code'] == i, :]
#     for j in temp['Media_Type'].unique() :
#         temp1 = temp.loc[temp['Media_Type'] == j, :]
#         for k in temp1.index :
#             temp1.loc[k,'Week'] = temp1.loc[k,'Week'] + all_titles.loc[all_titles['IMDB_Title_Code'] == i, str(j+'_Week_Start')].values
#         Weekly_PST_sales_1 = Weekly_PST_sales_1.append(temp1)
#         del temp1
#     del temp
# Digital_Weekly_Sales
Weekly_EST_sales_1 = pd.DataFrame({'IMDB_Title_Code' : [],
                                   'Item_Title_WW' : [],
                                   'Studio' : [],
                                   'Street_Date' : [],
                                   'Theatrical_Release_Date' : [],
                                   'Media_Type' : [],
                                   'Week_Number' : [],
                                   'Revenue' : [],
                                   'Units' : []})
# for i in all_titles['IMDB_Title_Code'] :
#     temp = Digital_Weekly_Sales.loc[Digital_Weekly_Sales['IMDB_Title_Code'] == i, :]
#     for j in temp['Media_Type'].unique() :
#         temp1 = temp.loc[temp['Media_Type'] == j, :]
#         for k in temp1.index :
#             temp1.loc[k,'Week'] = temp1.loc[k,'Week'] + all_titles.loc[all_titles['IMDB_Title_Code'] == i,str(j+'_Week_Start')].values
#         Weekly_EST_sales_1 = Weekly_EST_sales_1.append(temp1)
#         del temp1
#     del temp
for i in all_titles['IMDB_Title_Code'].unique() :
    tempP = Physical_Weekly_Sales.loc[Physical_Weekly_Sales['IMDB_Title_Code'] == i, :]
    tempD = Digital_Weekly_Sales.loc[Digital_Weekly_Sales['IMDB_Title_Code'] == i, :]
    for j in ['Blu-ray', 'DVD', 'EST', 'iVOD', 'cVOD'] :
        tempP1 = tempP.loc[tempP['Media_Type'] == j, :]
        tempD1 = tempD.loc[tempD['Media_Type'] == j, :]
        for k in tempP1.index :
            tempP1.loc[k,'Week_Number'] = tempP1.loc[k,'Week_Number'] + all_titles.loc[all_titles['IMDB_Title_Code'] == i, str(j+'_Week_Start')].values
        Weekly_PST_sales_1 = Weekly_PST_sales_1.append(tempP1)
        for k in tempD1.index :
            tempD1.loc[k,'Week_Number'] = tempD1.loc[k,'Week_Number'] + all_titles.loc[all_titles['IMDB_Title_Code'] == i,str(j+'_Week_Start')].values
        Weekly_EST_sales_1 = Weekly_EST_sales_1.append(tempD1)
        del tempP1, tempD1
    del tempP, tempD
del i, j, k

# updating list of all IMDB_Title_Codes & their Theatrical, EST & PST Release Dates with last week number
all_titles['EST_Week_Ends'] = np.NaN
all_titles['iVOD_Week_Ends'] = np.NaN
all_titles['cVOD_Week_Ends'] = np.NaN
all_titles['DVD_Week_Ends'] = np.NaN
all_titles['Blu-ray_Week_Ends'] = np.NaN
# all_titles['FB_Week_Start'] = np.NaN
# all_titles['FB_Week_Ends'] = np.NaN
all_titles['BO_Week_Start'] = np.NaN
all_titles['BO_Week_Ends'] = np.NaN
for i in all_titles['IMDB_Title_Code'].unique() :
    if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Week_Start']) != True :
        all_titles.loc[all_titles['IMDB_Title_Code']==i, 'EST_Week_Ends'] = max(Weekly_EST_sales_1.loc[(Weekly_EST_sales_1['IMDB_Title_Code'] == i) & (Weekly_EST_sales_1['Media_Type'] == 'EST'), 'Week'].dropna())
    if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'iVOD_Week_Start']) != True :
        all_titles.loc[all_titles['IMDB_Title_Code']==i, 'iVOD_Week_Ends'] = max(Weekly_EST_sales_1.loc[(Weekly_EST_sales_1['IMDB_Title_Code'] == i) & (Weekly_EST_sales_1['Media_Type'] == 'iVOD'), 'Week'].dropna())
    if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'cVOD_Week_Start']) != True :
        all_titles.loc[all_titles['IMDB_Title_Code']==i, 'cVOD_Week_Ends'] = max(Weekly_EST_sales_1.loc[(Weekly_EST_sales_1['IMDB_Title_Code'] == i) & (Weekly_EST_sales_1['Media_Type'] == 'cVOD'), 'Week'].dropna())
    if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'DVD_Week_Start']) != True :
        all_titles.loc[all_titles['IMDB_Title_Code']==i, 'DVD_Week_Ends'] = max(Weekly_PST_sales_1.loc[(Weekly_PST_sales_1['IMDB_Title_Code'] == i) & (Weekly_PST_sales_1['Media_Type'] == 'DVD'), 'Week'].dropna())
    if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Blu-ray_Week_Start']) != True :
        all_titles.loc[all_titles['IMDB_Title_Code']==i, 'Blu-ray_Week_Ends'] = max(Weekly_PST_sales_1.loc[(Weekly_PST_sales_1['IMDB_Title_Code'] == i) & (Weekly_PST_sales_1['Media_Type'] == 'Blu-ray'), 'Week'].dropna())
    # all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'FB_Week_Start'] = min(gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Week'].dropna())
    # all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'FB_Week_Ends'] = max(gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Week'].dropna())
    all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'BO_Week_Start'] = min(Weekly_BO_sales.loc[Weekly_BO_sales['IMDB_Title_Code'] == i, 'Week'].dropna())
    all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'BO_Week_Ends'] = max(Weekly_BO_sales.loc[Weekly_BO_sales['IMDB_Title_Code'] == i, 'Week'].dropna())
#all_titles['EST_Week_Ends'] = pd.to_numeric(all_titles['EST_Week_Ends'])
del i

# creating the master_AD
# creating a dataframe of IMDB Title Codes and Week ranges for each IMDB Title Codes
unique_week = pd.DataFrame({'IMDB_Title_Code' : [],
                            'Week_Number' : []})
for i in all_titles['IMDB_Title_Code'].unique() :
    unique_week = unique_week.append(pd.DataFrame({'IMDB_Title_Code': [i]*int(np.nanmax(all_titles.loc[all_titles['IMDB_Title_Code']==i, ['BO_Week_Ends', 'EST_Week_Ends', 'iVOD_Week_Ends', 'cVOD_Week_Ends', 'DVD_Week_Ends', 'Blu-ray_Week_Ends']].values)+1),
                                                   'Week_Number': np.arange(0, int(np.nanmax(all_titles.loc[all_titles['IMDB_Title_Code']==i, ['BO_Week_Ends', 'EST_Week_Ends', 'iVOD_Week_Ends', 'cVOD_Week_Ends', 'DVD_Week_Ends', 'Blu-ray_Week_Ends']]))+1)}))
del i
unique_week = pd.merge(left = unique_week,
                     right = HE_sales[['IMDB_Title_Code',
                                       'Theatrical_Release_Date']],
                     how='left',
                     left_on = 'IMDB_Title_Code',
                     right_on = 'IMDB_Title_Code',
                     sort = True,
                     copy = False)
for i in unique_week.index :
    unique_week.loc[i, 'Week_Act'] = unique_week.loc[i, 'Theatrical_Release_Date']+timedelta(days=unique_week.loc[i, 'Week']*7)
del i

# # merging BO Revenue for weeks present
master_AD = pd.merge(left = unique_week,
                     right = Weekly_BO_sales[['IMDB_Title_Code',
                                              'Week_Number',
                                              'Box Office']],
                     how='left',
                     left_on = ['IMDB_Title_Code', 'Week_Number'],
                     right_on = ['IMDB_Title_Code', 'Week_Number'],
                     sort = True,
                     copy = False)
# merging EST Revenue for weeks present
Weekly_EST_sales_1 = pd.pivot_table(data=Weekly_EST_sales_1[['IMDB_Title_Code',
                                                             'Media_Type',
                                                             'Week_Number',
                                                             'Revenue']],
                                    index=['IMDB_Title_Code', 'Week_Number'],
                                    columns=['Media_Type'],
                                    values=['Revenue'],
                                    aggfunc=np.unique).reset_index()
Weekly_EST_sales_1.columns = ['IMDB_Title_Code', 'Week_Number', 'EST_Revenue', 'cVOD_Revenue', 'iVOD_Revenue']
master_AD = pd.merge(left = master_AD,
                     right = Weekly_EST_sales_1,
                     how='left',
                     left_on = ['IMDB_Title_Code', 'Week_Number'],
                     right_on = ['IMDB_Title_Code', 'Week_Number'],
                     sort = True,
                     copy = False)
# merging PST Revenue for weeks present
Weekly_PST_sales_1 = pd.pivot_table(data=Weekly_PST_sales_1[['IMDB_Title_Code',
                                                             'Media_Type',
                                                             'Week_Number',
                                                             'Revenue']],
                                    index=['IMDB_Title_Code', 'Week_Number'],
                                    columns=['Media_Type'],
                                    values=['Revenue'],
                                    aggfunc=np.unique).reset_index()
Weekly_PST_sales_1.columns = ['IMDB_Title_Code', 'Week_Number', 'Blu-ray_Revenue', 'DVD_Revenue']
master_AD = pd.merge(left = master_AD,
                     right = Weekly_PST_sales_1,
                     how='left',
                     left_on = ['IMDB_Title_Code', 'Week_Number'],
                     right_on = ['IMDB_Title_Code', 'Week_Number'],
                     sort = True,
                     copy = False)
del unique_week

# renaming columns for column name consistency across all files
master_AD = master_AD[['IMDB_Title_Code',
                       'Theatrical_Release_Date',
                       'Week_Number',
                       'Box Office',
                       'Blu-ray_Revenue',
                       'DVD_Revenue',
                       'EST_Revenue',
                       'iVOD_Revenue',
                       'cVOD_Revenue']]
master_AD.rename(columns={'Box Office':'BO_Revenue'},
                 inplace=True)

# exporting master_AD
master_AD.to_excel(sharepoint_path+r"\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\weekly_revenue_v1.0.xlsx",
                   sheet_name='Sheet1',
                   index=False)

print("Program Commplete")
print("Time Elapsed: " + str(pd.datetime.now()-start_time))
