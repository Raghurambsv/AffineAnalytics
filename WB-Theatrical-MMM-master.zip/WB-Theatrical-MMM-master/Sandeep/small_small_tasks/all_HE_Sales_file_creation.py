#v1.0

# set local path for synced sharepoint
sharepoint_path = r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/'

# importing packages
import numpy as np
import pandas as pd

# importing all files
Physical_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Physical_Weekly_Sales_v3.csv',
                                    sep = ',',
                                    encoding = 'latin-1')
Digital_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Digital_Weekly_Sales_v3.csv',
                                   sep = ',',
                                   encoding = 'latin-1')
Comp_Release_Schedule = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Comp_Release_Schedule_v3.1.csv',
                                    sep = ',',
                                    encoding = 'latin-1')

# dropping all rows with no EST Dates and IMDB_Title_ID
Comp_Release_Schedule.drop(index=Comp_Release_Schedule.loc[Comp_Release_Schedule['EST_Release'].isnull()].index.values,
                           axis=0,
                           inplace=True)
Comp_Release_Schedule.drop(index=Comp_Release_Schedule.loc[Comp_Release_Schedule['IMDB_Title_ID'].isnull()].index.values,
                           axis=0,
                           inplace=True)

# correcting date_time format
Physical_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Physical_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Street_Date'], infer_datetime_format=True, errors="coerce")
Digital_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Digital_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Street_Date'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['Theatrical_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['Theatrical_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['EST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['EST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['VOD_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['VOD_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Rental_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Rental_Release'], infer_datetime_format=True, errors="coerce")

# row binding Physical Weekly Sales and Digital Weekly Sales files
phys_digi = pd.concat([Physical_Weekly_Sales, Digital_Weekly_Sales], ignore_index=True)
del Digital_Weekly_Sales, Physical_Weekly_Sales # dropping unnecessary objects to free memory

# collating Physical Weekly Sales and Digital Weekly Sales files and converting to Movie level dataset
gp_data = phys_digi.groupby(['IMDB_Title_Code',
                             'Item_Title_WW',
                             'Studio',
                             'Street_Date',
                             'Theatrical_Release_Date',
                             'Media_Type']).agg({'Revenue':'sum',
                                                 'Units':'sum'}).reset_index()
del phys_digi # dropping unnecessary objects to free memory

# fixing double studio issues
for i in gp_data['IMDB_Title_Code'].unique():
    for j in gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Media_Type'].unique():
        temp = gp_data.loc[(gp_data['IMDB_Title_Code'] == i) & (gp_data['Media_Type'] == j)]
        if temp.shape[0] > 1 :
            if temp['Studio'].str.contains('WARNER').sum() > 0 :
                gp_data = gp_data.drop(index=temp.loc[temp['Studio'] != 'WARNER'].index.values, axis=0)
            else:
                if len(temp.loc[temp['Revenue'] != max(temp['Revenue']), 'Studio'].unique()) == 2:
                    gp_data.drop(index=temp.loc[temp['Studio'] == 'ALL OTHERS'].index.values,
                                 axis=0,
                                 inplace=True)
                else:
                    gp_data.drop(index=temp.loc[temp['Revenue'] != max(temp['Revenue'])].index.values,
                                 axis=0,
                                 inplace=True)
del i, j, temp # dropping unnecessary objects to free memory

# fixing same studio, double release date issues
for i in gp_data['IMDB_Title_Code'].unique() :
    for j in gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Media_Type'].unique():
        gp_data.loc[(gp_data["IMDB_Title_Code"] == i) & (gp_data["Media_Type"] == j), 'Street_Date'] = gp_data.loc[(gp_data["IMDB_Title_Code"] == i) & (gp_data["Media_Type"] == j), 'Street_Date'].min()
del i, j # dropping unnecessary objects to free memory

street_date = pd.pivot_table(data=gp_data,
                             index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                             columns=['Media_Type'],
                             values=['Street_Date'],
                             aggfunc=np.unique).reset_index()
studio = pd.pivot_table(data=gp_data,
                        index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                        columns=['Media_Type'],
                        values=['Studio'],
                        aggfunc=np.unique).reset_index()
Revenue = pd.pivot_table(data=gp_data,
                         index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                         columns=['Media_Type'],
                         values=['Revenue'],
                         aggfunc=np.sum).reset_index()
Units = pd.pivot_table(data=gp_data,
                       index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                       columns=['Media_Type'],
                       values=['Units'],
                       aggfunc=np.sum).reset_index()
HE_sales = pd.merge(left=street_date[[('IMDB_Title_Code', ''), ('Theatrical_Release_Date', ''), ('Street_Date', 'Blu-ray'), ('Street_Date', 'DVD'), ('Street_Date', 'EST'), ('Street_Date', 'cVOD'), ('Street_Date', 'iVOD')]],
                    right=studio[[('IMDB_Title_Code', ''), ('Studio', 'Blu-ray'), ('Studio', 'DVD'), ('Studio', 'EST'), ('Studio', 'cVOD'), ('Studio', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
HE_sales = pd.merge(left=HE_sales,
                    right=Revenue[[('IMDB_Title_Code', ''), ('Revenue', 'Blu-ray'), ('Revenue', 'DVD'), ('Revenue', 'EST'), ('Revenue', 'cVOD'), ('Revenue', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
HE_sales = pd.merge(left=HE_sales,
                    right=Units[[('IMDB_Title_Code', ''), ('Units', 'Blu-ray'), ('Units', 'DVD'), ('Units', 'EST'), ('Units', 'cVOD'), ('Units', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
del Revenue, Units, gp_data, street_date, studio # dropping unnecessary objects to free memory
# setting column names for HE_sales file
HE_sales.columns = ['IMDB_Title_Code',
                    'Theatrical_Release_Date',
                    'Blu-ray_Street_Date',
                    'DVD_Street_Date',
                    'EST_Street_Date',
                    'cVOD_Street_Date',
                    'iVOD_Street_Date',
                    'Blu-ray_Studio',
                    'DVD_Studio',
                    'EST_Studio',
                    'cVOD_Studio',
                    'iVOD_Studio',
                    'Blu-ray_Revenue',
                    'DVD_Revenue',
                    'EST_Revenue',
                    'cVOD_Revenue',
                    'iVOD_Revenue',
                    'Blu-ray_Sold',
                    'DVD_Sold',
                    'EST_Sold',
                    'cVOD_Sold',
                    'iVOD_Sold']

# correcting date_time format
HE_sales['Theatrical_Release_Date'] = pd.to_datetime(arg=HE_sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=HE_sales['Blu-ray_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['DVD_Street_Date'] = pd.to_datetime(arg=HE_sales['DVD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['EST_Street_Date'] = pd.to_datetime(arg=HE_sales['EST_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['cVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['cVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['iVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['iVOD_Street_Date'], infer_datetime_format=True, errors="coerce")

# getting EST_Street_Date from Comp_Release_Schedule_v3 whenever missing
# HE_sales = pd.merge(left=HE_sales,
#                     right=Comp_Release_Schedule[['IMDB_Title_ID', 'EST_Release']],
#                     left_on='IMDB_Title_Code',
#                     right_on='IMDB_Title_ID',
#                     how='left',
#                     sort=True,
#                     copy=False)
# del Comp_Release_Schedule # dropping unnecessary objects to free memory
#
# HE_sales['EST_Street_Date'] = HE_sales.apply(
#     lambda x: x['EST_Release'] if pd.isnull(x['EST_Street_Date']) else x['EST_Street_Date'], axis=1)
# HE_sales.drop(['IMDB_Title_ID', 'EST_Release'], axis=1, inplace=True) # dropping unnecessary columns

# deleting titles whose HE release date is before BO release date
# HE_sales['BO_Window'] = (HE_sales['Theatrical_Release_Date'] - HE_sales[['Blu-ray_Street_Date', 'DVD_Street_Date', 'EST_Street_Date', 'cVOD_Street_Date', 'iVOD_Street_Date']].min(axis=1))/pd.offsets.Day(-1)
# for i in HE_sales.index :
#     if HE_sales.loc[i, 'BO_Window'] < 0 :
#         HE_sales = HE_sales.drop(index=i, axis=0)
# HE_sales.drop(['BO_Window'], axis=1, inplace=True) # not keeping BO_Window column in this stage
# del i # dropping unnecessary objects to free memory
HE_sales.drop_duplicates(inplace=True) # removing duplicate rows (if any)

# export Weekly_sales file
HE_sales.to_csv(path_or_buf=sharepoint_path+r'WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\HE_Sales_v1.0.csv',
                index=False)


#v1.01

# set local path for synced sharepoint
sharepoint_path = r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/'

# importing packages
import numpy as np
import pandas as pd

# importing all files
Physical_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Physical_Weekly_Sales_v3.csv',
                                    sep = ',',
                                    encoding = 'latin-1')
Digital_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Digital_Weekly_Sales_v3.csv',
                                   sep = ',',
                                   encoding = 'latin-1')
Comp_Release_Schedule = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Comp_Release_Schedule_v3.1.csv',
                                    sep = ',',
                                    encoding = 'latin-1')

# dropping all rows with no EST Dates and IMDB_Title_ID
Comp_Release_Schedule.drop(index=Comp_Release_Schedule.loc[Comp_Release_Schedule['EST_Release'].isnull()].index.values,
                           axis=0,
                           inplace=True)
Comp_Release_Schedule.drop(index=Comp_Release_Schedule.loc[Comp_Release_Schedule['IMDB_Title_ID'].isnull()].index.values,
                           axis=0,
                           inplace=True)

# correcting date_time format
Physical_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Physical_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Street_Date'], infer_datetime_format=True, errors="coerce")
Digital_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Digital_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Street_Date'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['Theatrical_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['Theatrical_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['EST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['EST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['VOD_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['VOD_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Rental_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Rental_Release'], infer_datetime_format=True, errors="coerce")

# row binding Physical Weekly Sales and Digital Weekly Sales files
phys_digi = pd.concat([Physical_Weekly_Sales, Digital_Weekly_Sales], ignore_index=True)
del Digital_Weekly_Sales, Physical_Weekly_Sales # dropping unnecessary objects to free memory

# collating Physical Weekly Sales and Digital Weekly Sales files and converting to Movie level dataset
gp_data = phys_digi.groupby(['IMDB_Title_Code',
                             'Item_Title_WW',
                             'Studio',
                             'Street_Date',
                             'Theatrical_Release_Date',
                             'Media_Type']).agg({'Revenue':'sum',
                                                 'Units':'sum'}).reset_index()
del phys_digi # dropping unnecessary objects to free memory

# fixing double studio issues
for i in gp_data['IMDB_Title_Code'].unique():
    for j in gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Media_Type'].unique():
        temp = gp_data.loc[(gp_data['IMDB_Title_Code'] == i) & (gp_data['Media_Type'] == j)]
        if temp.shape[0] > 1 :
            if temp['Studio'].str.contains('WARNER').sum() > 0 :
                gp_data = gp_data.drop(index=temp.loc[temp['Studio'] != 'WARNER'].index.values, axis=0)
            else:
                if len(temp.loc[temp['Revenue'] != max(temp['Revenue']), 'Studio'].unique()) == 2:
                    gp_data.drop(index=temp.loc[temp['Studio'] == 'ALL OTHERS'].index.values,
                                 axis=0,
                                 inplace=True)
                else:
                    gp_data.drop(index=temp.loc[temp['Revenue'] != max(temp['Revenue'])].index.values,
                                 axis=0,
                                 inplace=True)
del i, j, temp # dropping unnecessary objects to free memory

# fixing same studio, double release date issues
for i in gp_data['IMDB_Title_Code'].unique() :
    for j in gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Media_Type'].unique():
        gp_data.loc[(gp_data["IMDB_Title_Code"] == i) & (gp_data["Media_Type"] == j), 'Street_Date'] = gp_data.loc[(gp_data["IMDB_Title_Code"] == i) & (gp_data["Media_Type"] == j), 'Street_Date'].min()
del i, j # dropping unnecessary objects to free memory

street_date = pd.pivot_table(data=gp_data,
                             index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                             columns=['Media_Type'],
                             values=['Street_Date'],
                             aggfunc=np.unique).reset_index()
studio = pd.pivot_table(data=gp_data,
                        index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                        columns=['Media_Type'],
                        values=['Studio'],
                        aggfunc=np.unique).reset_index()
Revenue = pd.pivot_table(data=gp_data,
                         index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                         columns=['Media_Type'],
                         values=['Revenue'],
                         aggfunc=np.sum).reset_index()
Units = pd.pivot_table(data=gp_data,
                       index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                       columns=['Media_Type'],
                       values=['Units'],
                       aggfunc=np.sum).reset_index()
HE_sales = pd.merge(left=street_date[[('IMDB_Title_Code', ''), ('Theatrical_Release_Date', ''), ('Street_Date', 'Blu-ray'), ('Street_Date', 'DVD'), ('Street_Date', 'EST'), ('Street_Date', 'cVOD'), ('Street_Date', 'iVOD')]],
                    right=studio[[('IMDB_Title_Code', ''), ('Studio', 'Blu-ray'), ('Studio', 'DVD'), ('Studio', 'EST'), ('Studio', 'cVOD'), ('Studio', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
HE_sales = pd.merge(left=HE_sales,
                    right=Revenue[[('IMDB_Title_Code', ''), ('Revenue', 'Blu-ray'), ('Revenue', 'DVD'), ('Revenue', 'EST'), ('Revenue', 'cVOD'), ('Revenue', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
HE_sales = pd.merge(left=HE_sales,
                    right=Units[[('IMDB_Title_Code', ''), ('Units', 'Blu-ray'), ('Units', 'DVD'), ('Units', 'EST'), ('Units', 'cVOD'), ('Units', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
del Revenue, Units, gp_data, street_date, studio # dropping unnecessary objects to free memory
# setting column names for HE_sales file
HE_sales.columns = ['IMDB_Title_Code',
                    'Theatrical_Release_Date',
                    'Blu-ray_Street_Date',
                    'DVD_Street_Date',
                    'EST_Street_Date',
                    'cVOD_Street_Date',
                    'iVOD_Street_Date',
                    'Blu-ray_Studio',
                    'DVD_Studio',
                    'EST_Studio',
                    'cVOD_Studio',
                    'iVOD_Studio',
                    'Blu-ray_Revenue',
                    'DVD_Revenue',
                    'EST_Revenue',
                    'cVOD_Revenue',
                    'iVOD_Revenue',
                    'Blu-ray_Sold',
                    'DVD_Sold',
                    'EST_Sold',
                    'cVOD_Sold',
                    'iVOD_Sold']

# correcting date_time format
HE_sales['Theatrical_Release_Date'] = pd.to_datetime(arg=HE_sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=HE_sales['Blu-ray_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['DVD_Street_Date'] = pd.to_datetime(arg=HE_sales['DVD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['EST_Street_Date'] = pd.to_datetime(arg=HE_sales['EST_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['cVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['cVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['iVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['iVOD_Street_Date'], infer_datetime_format=True, errors="coerce")

# getting EST_Street_Date from Comp_Release_Schedule_v3 whenever missing
HE_sales = pd.merge(left=HE_sales,
                    right=Comp_Release_Schedule[['IMDB_Title_ID', 'EST_Release']],
                    left_on='IMDB_Title_Code',
                    right_on='IMDB_Title_ID',
                    how='left',
                    sort=True,
                    copy=False)
del Comp_Release_Schedule # dropping unnecessary objects to free memory

HE_sales['EST_Street_Date'] = HE_sales.apply(
    lambda x: x['EST_Release'] if pd.isnull(x['EST_Street_Date']) else x['EST_Street_Date'], axis=1)
HE_sales.drop(['IMDB_Title_ID', 'EST_Release'], axis=1, inplace=True) # dropping unnecessary columns

# deleting titles whose HE release date is before BO release date
# HE_sales['BO_Window'] = (HE_sales['Theatrical_Release_Date'] - HE_sales[['Blu-ray_Street_Date', 'DVD_Street_Date', 'EST_Street_Date', 'cVOD_Street_Date', 'iVOD_Street_Date']].min(axis=1))/pd.offsets.Day(-1)
# for i in HE_sales.index :
#     if HE_sales.loc[i, 'BO_Window'] < 0 :
#         HE_sales = HE_sales.drop(index=i, axis=0)
# HE_sales.drop(['BO_Window'], axis=1, inplace=True) # not keeping BO_Window column in this stage
# del i # dropping unnecessary objects to free memory
HE_sales.drop_duplicates(inplace=True) # removing duplicate rows (if any)

# export Weekly_sales file
HE_sales.to_csv(path_or_buf=sharepoint_path+r'WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\HE_Sales_v1.01.csv',
                index=False)


#v1.1

# set local path for synced sharepoint
sharepoint_path = r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/'

# importing packages
import numpy as np
import pandas as pd

# importing all files
Physical_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Physical_Weekly_Sales_v3.csv',
                                    sep = ',',
                                    encoding = 'latin-1')
Digital_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Digital_Weekly_Sales_v3.csv',
                                   sep = ',',
                                   encoding = 'latin-1')
Comp_Release_Schedule = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Comp_Release_Schedule_v3.1.csv',
                                    sep = ',',
                                    encoding = 'latin-1')

# dropping all rows with no EST Dates and IMDB_Title_ID
Comp_Release_Schedule.drop(index=Comp_Release_Schedule.loc[Comp_Release_Schedule['EST_Release'].isnull()].index.values,
                           axis=0,
                           inplace=True)
Comp_Release_Schedule.drop(index=Comp_Release_Schedule.loc[Comp_Release_Schedule['IMDB_Title_ID'].isnull()].index.values,
                           axis=0,
                           inplace=True)

# correcting date_time format
Physical_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Physical_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Street_Date'], infer_datetime_format=True, errors="coerce")
Digital_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Digital_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Street_Date'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['Theatrical_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['Theatrical_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['EST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['EST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['VOD_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['VOD_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Rental_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Rental_Release'], infer_datetime_format=True, errors="coerce")

# row binding Physical Weekly Sales and Digital Weekly Sales files
phys_digi = pd.concat([Physical_Weekly_Sales, Digital_Weekly_Sales], ignore_index=True)
del Digital_Weekly_Sales, Physical_Weekly_Sales # dropping unnecessary objects to free memory

# collating Physical Weekly Sales and Digital Weekly Sales files and converting to Movie level dataset
gp_data = phys_digi.groupby(['IMDB_Title_Code',
                             'Item_Title_WW',
                             'Studio',
                             'Street_Date',
                             'Theatrical_Release_Date',
                             'Media_Type']).agg({'Revenue':'sum',
                                                 'Units':'sum'}).reset_index()
del phys_digi # dropping unnecessary objects to free memory

# fixing double studio issues
for i in gp_data['IMDB_Title_Code'].unique():
    for j in gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Media_Type'].unique():
        temp = gp_data.loc[(gp_data['IMDB_Title_Code'] == i) & (gp_data['Media_Type'] == j)]
        if temp.shape[0] > 1 :
            if temp['Studio'].str.contains('WARNER').sum() > 0 :
                gp_data = gp_data.drop(index=temp.loc[temp['Studio'] != 'WARNER'].index.values, axis=0)
            else:
                if len(temp.loc[temp['Revenue'] != max(temp['Revenue']), 'Studio'].unique()) == 2:
                    gp_data.drop(index=temp.loc[temp['Studio'] == 'ALL OTHERS'].index.values,
                                 axis=0,
                                 inplace=True)
                else:
                    gp_data.drop(index=temp.loc[temp['Revenue'] != max(temp['Revenue'])].index.values,
                                 axis=0,
                                 inplace=True)
del i, j, temp # dropping unnecessary objects to free memory

# fixing same studio, double release date issues
for i in gp_data['IMDB_Title_Code'].unique() :
    for j in gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Media_Type'].unique():
        gp_data.loc[(gp_data["IMDB_Title_Code"] == i) & (gp_data["Media_Type"] == j), 'Street_Date'] = gp_data.loc[(gp_data["IMDB_Title_Code"] == i) & (gp_data["Media_Type"] == j), 'Street_Date'].min()
del i, j # dropping unnecessary objects to free memory

street_date = pd.pivot_table(data=gp_data,
                             index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                             columns=['Media_Type'],
                             values=['Street_Date'],
                             aggfunc=np.unique).reset_index()
studio = pd.pivot_table(data=gp_data,
                        index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                        columns=['Media_Type'],
                        values=['Studio'],
                        aggfunc=np.unique).reset_index()
Revenue = pd.pivot_table(data=gp_data,
                         index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                         columns=['Media_Type'],
                         values=['Revenue'],
                         aggfunc=np.sum).reset_index()
Units = pd.pivot_table(data=gp_data,
                       index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                       columns=['Media_Type'],
                       values=['Units'],
                       aggfunc=np.sum).reset_index()
HE_sales = pd.merge(left=street_date[[('IMDB_Title_Code', ''), ('Theatrical_Release_Date', ''), ('Street_Date', 'Blu-ray'), ('Street_Date', 'DVD'), ('Street_Date', 'EST'), ('Street_Date', 'cVOD'), ('Street_Date', 'iVOD')]],
                    right=studio[[('IMDB_Title_Code', ''), ('Studio', 'Blu-ray'), ('Studio', 'DVD'), ('Studio', 'EST'), ('Studio', 'cVOD'), ('Studio', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
HE_sales = pd.merge(left=HE_sales,
                    right=Revenue[[('IMDB_Title_Code', ''), ('Revenue', 'Blu-ray'), ('Revenue', 'DVD'), ('Revenue', 'EST'), ('Revenue', 'cVOD'), ('Revenue', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
HE_sales = pd.merge(left=HE_sales,
                    right=Units[[('IMDB_Title_Code', ''), ('Units', 'Blu-ray'), ('Units', 'DVD'), ('Units', 'EST'), ('Units', 'cVOD'), ('Units', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
del Revenue, Units, gp_data, street_date, studio # dropping unnecessary objects to free memory
# setting column names for HE_sales file
HE_sales.columns = ['IMDB_Title_Code',
                    'Theatrical_Release_Date',
                    'Blu-ray_Street_Date',
                    'DVD_Street_Date',
                    'EST_Street_Date',
                    'cVOD_Street_Date',
                    'iVOD_Street_Date',
                    'Blu-ray_Studio',
                    'DVD_Studio',
                    'EST_Studio',
                    'cVOD_Studio',
                    'iVOD_Studio',
                    'Blu-ray_Revenue',
                    'DVD_Revenue',
                    'EST_Revenue',
                    'cVOD_Revenue',
                    'iVOD_Revenue',
                    'Blu-ray_Sold',
                    'DVD_Sold',
                    'EST_Sold',
                    'cVOD_Sold',
                    'iVOD_Sold']

# correcting date_time format
HE_sales['Theatrical_Release_Date'] = pd.to_datetime(arg=HE_sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=HE_sales['Blu-ray_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['DVD_Street_Date'] = pd.to_datetime(arg=HE_sales['DVD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['EST_Street_Date'] = pd.to_datetime(arg=HE_sales['EST_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['cVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['cVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['iVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['iVOD_Street_Date'], infer_datetime_format=True, errors="coerce")

# getting EST_Street_Date from Comp_Release_Schedule_v3 whenever missing
# HE_sales = pd.merge(left=HE_sales,
#                     right=Comp_Release_Schedule[['IMDB_Title_ID', 'EST_Release']],
#                     left_on='IMDB_Title_Code',
#                     right_on='IMDB_Title_ID',
#                     how='left',
#                     sort=True,
#                     copy=False)
# del Comp_Release_Schedule # dropping unnecessary objects to free memory
#
# HE_sales['EST_Street_Date'] = HE_sales.apply(
#     lambda x: x['EST_Release'] if pd.isnull(x['EST_Street_Date']) else x['EST_Street_Date'], axis=1)
# HE_sales.drop(['IMDB_Title_ID', 'EST_Release'], axis=1, inplace=True) # dropping unnecessary columns

# deleting titles whose HE release date is before BO release date
HE_sales['BO_Window'] = (HE_sales['Theatrical_Release_Date'] - HE_sales[['Blu-ray_Street_Date', 'DVD_Street_Date', 'EST_Street_Date', 'cVOD_Street_Date', 'iVOD_Street_Date']].min(axis=1))/pd.offsets.Day(-1)
for i in HE_sales.index :
    if HE_sales.loc[i, 'BO_Window'] < 0 :
        HE_sales = HE_sales.drop(index=i, axis=0)
HE_sales.drop(['BO_Window'], axis=1, inplace=True) # not keeping BO_Window column in this stage
del i # dropping unnecessary objects to free memory
HE_sales.drop_duplicates(inplace=True) # removing duplicate rows (if any)

# export Weekly_sales file
HE_sales.to_csv(path_or_buf=sharepoint_path+r'WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\HE_Sales_v1.1.csv',
                index=False)


# v1.11
# set local path for synced sharepoint
sharepoint_path = r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/'

# importing packages
import numpy as np
import pandas as pd

# importing all files
Physical_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Physical_Weekly_Sales_v3.csv',
                                    sep = ',',
                                    encoding = 'latin-1')
Digital_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Digital_Weekly_Sales_v3.csv',
                                   sep = ',',
                                   encoding = 'latin-1')
Comp_Release_Schedule = pd.read_csv(filepath_or_buffer=sharepoint_path+r'WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Comp_Release_Schedule_v3.1.csv',
                                    sep = ',',
                                    encoding = 'latin-1')

# dropping all rows with no EST Dates and IMDB_Title_ID
Comp_Release_Schedule.drop(index=Comp_Release_Schedule.loc[Comp_Release_Schedule['EST_Release'].isnull()].index.values,
                           axis=0,
                           inplace=True)
Comp_Release_Schedule.drop(index=Comp_Release_Schedule.loc[Comp_Release_Schedule['IMDB_Title_ID'].isnull()].index.values,
                           axis=0,
                           inplace=True)

# correcting date_time format
Physical_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Physical_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Street_Date'], infer_datetime_format=True, errors="coerce")
Digital_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Digital_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Street_Date'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['Theatrical_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['Theatrical_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['EST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['EST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['VOD_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['VOD_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Rental_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Rental_Release'], infer_datetime_format=True, errors="coerce")

# row binding Physical Weekly Sales and Digital Weekly Sales files
phys_digi = pd.concat([Physical_Weekly_Sales, Digital_Weekly_Sales], ignore_index=True)
del Digital_Weekly_Sales, Physical_Weekly_Sales # dropping unnecessary objects to free memory

# collating Physical Weekly Sales and Digital Weekly Sales files and converting to Movie level dataset
gp_data = phys_digi.groupby(['IMDB_Title_Code',
                             'Item_Title_WW',
                             'Studio',
                             'Street_Date',
                             'Theatrical_Release_Date',
                             'Media_Type']).agg({'Revenue':'sum',
                                                 'Units':'sum'}).reset_index()
del phys_digi # dropping unnecessary objects to free memory

# fixing double studio issues
for i in gp_data['IMDB_Title_Code'].unique():
    for j in gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Media_Type'].unique():
        temp = gp_data.loc[(gp_data['IMDB_Title_Code'] == i) & (gp_data['Media_Type'] == j)]
        if temp.shape[0] > 1 :
            if temp['Studio'].str.contains('WARNER').sum() > 0 :
                gp_data = gp_data.drop(index=temp.loc[temp['Studio'] != 'WARNER'].index.values, axis=0)
            else:
                if len(temp.loc[temp['Revenue'] != max(temp['Revenue']), 'Studio'].unique()) == 2:
                    gp_data.drop(index=temp.loc[temp['Studio'] == 'ALL OTHERS'].index.values,
                                 axis=0,
                                 inplace=True)
                else:
                    gp_data.drop(index=temp.loc[temp['Revenue'] != max(temp['Revenue'])].index.values,
                                 axis=0,
                                 inplace=True)
del i, j, temp # dropping unnecessary objects to free memory

# fixing same studio, double release date issues
for i in gp_data['IMDB_Title_Code'].unique() :
    for j in gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Media_Type'].unique():
        gp_data.loc[(gp_data["IMDB_Title_Code"] == i) & (gp_data["Media_Type"] == j), 'Street_Date'] = gp_data.loc[(gp_data["IMDB_Title_Code"] == i) & (gp_data["Media_Type"] == j), 'Street_Date'].min()
del i, j # dropping unnecessary objects to free memory

street_date = pd.pivot_table(data=gp_data,
                             index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                             columns=['Media_Type'],
                             values=['Street_Date'],
                             aggfunc=np.unique).reset_index()
studio = pd.pivot_table(data=gp_data,
                        index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                        columns=['Media_Type'],
                        values=['Studio'],
                        aggfunc=np.unique).reset_index()
Revenue = pd.pivot_table(data=gp_data,
                         index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                         columns=['Media_Type'],
                         values=['Revenue'],
                         aggfunc=np.sum).reset_index()
Units = pd.pivot_table(data=gp_data,
                       index=['IMDB_Title_Code', 'Theatrical_Release_Date','Item_Title_WW'],
                       columns=['Media_Type'],
                       values=['Units'],
                       aggfunc=np.sum).reset_index()
HE_sales = pd.merge(left=street_date[[('IMDB_Title_Code', ''), ('Theatrical_Release_Date', ''), ('Street_Date', 'Blu-ray'), ('Street_Date', 'DVD'), ('Street_Date', 'EST'), ('Street_Date', 'cVOD'), ('Street_Date', 'iVOD')]],
                    right=studio[[('IMDB_Title_Code', ''), ('Studio', 'Blu-ray'), ('Studio', 'DVD'), ('Studio', 'EST'), ('Studio', 'cVOD'), ('Studio', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
HE_sales = pd.merge(left=HE_sales,
                    right=Revenue[[('IMDB_Title_Code', ''), ('Revenue', 'Blu-ray'), ('Revenue', 'DVD'), ('Revenue', 'EST'), ('Revenue', 'cVOD'), ('Revenue', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
HE_sales = pd.merge(left=HE_sales,
                    right=Units[[('IMDB_Title_Code', ''), ('Units', 'Blu-ray'), ('Units', 'DVD'), ('Units', 'EST'), ('Units', 'cVOD'), ('Units', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
del Revenue, Units, gp_data, street_date, studio # dropping unnecessary objects to free memory
# setting column names for HE_sales file
HE_sales.columns = ['IMDB_Title_Code',
                    'Theatrical_Release_Date',
                    'Blu-ray_Street_Date',
                    'DVD_Street_Date',
                    'EST_Street_Date',
                    'cVOD_Street_Date',
                    'iVOD_Street_Date',
                    'Blu-ray_Studio',
                    'DVD_Studio',
                    'EST_Studio',
                    'cVOD_Studio',
                    'iVOD_Studio',
                    'Blu-ray_Revenue',
                    'DVD_Revenue',
                    'EST_Revenue',
                    'cVOD_Revenue',
                    'iVOD_Revenue',
                    'Blu-ray_Sold',
                    'DVD_Sold',
                    'EST_Sold',
                    'cVOD_Sold',
                    'iVOD_Sold']

# correcting date_time format
HE_sales['Theatrical_Release_Date'] = pd.to_datetime(arg=HE_sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=HE_sales['Blu-ray_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['DVD_Street_Date'] = pd.to_datetime(arg=HE_sales['DVD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['EST_Street_Date'] = pd.to_datetime(arg=HE_sales['EST_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['cVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['cVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['iVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['iVOD_Street_Date'], infer_datetime_format=True, errors="coerce")

# getting EST_Street_Date from Comp_Release_Schedule_v3 whenever missing
HE_sales = pd.merge(left=HE_sales,
                    right=Comp_Release_Schedule[['IMDB_Title_ID', 'EST_Release']],
                    left_on='IMDB_Title_Code',
                    right_on='IMDB_Title_ID',
                    how='left',
                    sort=True,
                    copy=False)
del Comp_Release_Schedule # dropping unnecessary objects to free memory

HE_sales['EST_Street_Date'] = HE_sales.apply(
    lambda x: x['EST_Release'] if pd.isnull(x['EST_Street_Date']) else x['EST_Street_Date'], axis=1)
HE_sales.drop(['IMDB_Title_ID', 'EST_Release'], axis=1, inplace=True) # dropping unnecessary columns

# deleting titles whose HE release date is before BO release date
HE_sales['BO_Window'] = (HE_sales['Theatrical_Release_Date'] - HE_sales[['Blu-ray_Street_Date', 'DVD_Street_Date', 'EST_Street_Date', 'cVOD_Street_Date', 'iVOD_Street_Date']].min(axis=1))/pd.offsets.Day(-1)
for i in HE_sales.index :
    if HE_sales.loc[i, 'BO_Window'] < 0 :
        HE_sales = HE_sales.drop(index=i, axis=0)
HE_sales.drop(['BO_Window'], axis=1, inplace=True) # not keeping BO_Window column in this stage
del i # dropping unnecessary objects to free memory
HE_sales.drop_duplicates(inplace=True) # removing duplicate rows (if any)

# export Weekly_sales file
HE_sales.to_csv(path_or_buf=sharepoint_path+r'WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\HE_Sales_v1.11.csv',
                index=False)
