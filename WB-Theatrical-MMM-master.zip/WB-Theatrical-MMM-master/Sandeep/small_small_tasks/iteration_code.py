

df = pd.read_excel(r"C:\Users\v-sanysa\Desktop\HE_modelingAD_v5.xlsx")




analysis_1 = analysis(dataframe = new,
                      numerical_list = ['BO_Window',
                                        'HE_Spend',
                                        'BO_Revenue',
                                        'Budget',
                                        'Runtime',
                                        'franchise_releases_in_last_3_years',
                                        #'time_delta_since_last_franchise_release',
                                        #'avg_earnings_franchise',
                                        'School_Outage',
                                        'count_of_competitor',
                                        'last_competitor_release_delta_days',
                                        'average_previous_Gross_US',
                                        'median_previous_Gross_US',
                                        'Actor_1_rolling_leads',
                                        'Actor_2_rolling_leads',
                                        'Actor_3_rolling_leads',
                                        'Actor_4_rolling_leads',
                                        'Actor_1_rolling_leads_5',
                                        'Actor_2_rolling_leads_5',
                                        'Actor_3_rolling_leads_5',
                                        'Actor_4_rolling_leads_5',
                                        'Actor_1_rolling_roles',
                                        'Actor_2_rolling_roles',
                                        'Actor_3_rolling_roles',
                                        'Actor_4_rolling_roles',
                                        'Actor_1_rolling_roles_5',
                                        'Actor_2_rolling_roles_5',
                                        'Actor_3_rolling_roles_5',
                                        'Actor_4_rolling_roles_5',
                                        'Actor_1_rolling_supporting',
                                        'Actor_2_rolling_supporting',
                                        'Actor_3_rolling_supporting',
                                        'Actor_4_rolling_supporting',
                                        'Actor_1_rolling_supporting_5',
                                        'Actor_2_rolling_supporting_5',
                                        'Actor_3_rolling_supporting_5',
                                        'Actor_4_rolling_supporting_5',
                                        'Actor_1_rolling_avg_earnings_lead',
                                        'Actor_2_rolling_avg_earnings_lead',
                                        'Actor_3_rolling_avg_earnings_lead',
                                        'Actor_4_rolling_avg_earnings_lead',
                                        'Actor_1_rolling_avg_earnings_supporting',
                                        'Actor_2_rolling_avg_earnings_supporting',
                                        'Actor_3_rolling_avg_earnings_supporting',
                                        'Actor_4_rolling_avg_earnings_supporting'],
                      categorical_list = ['HE_Release_Month',
                                          'franchise_flag',
                                          'MPAA_rating',
                                          'Genre_Coales',
                                          'HolidayFlag'],
                      dependent_variable = 'HE_Revenue')


analysis_1.univariate_analysis()
analysis_1.bivariate_analysis()

new=outlier_treatment(data=df, feature_dict={
    'BO_Window' : [5,95],
    'HE_Spend' : [5,95],
    'BO_Revenue' : [5,95],
    'Budget' : [5,95],
    'Runtime' : [5,95],
    'franchise_releases_in_last_3_years' : [5,95],
    #'time_delta_since_last_franchise_release' : [5,95],
    #'avg_earnings_franchise' : [5,95],
    'School_Outage' : [5,95],
    'count_of_competitor' : [5,95],
    'last_competitor_release_delta_days' : [5,95],
    'average_previous_Gross_US' : [5,95],
    'median_previous_Gross_US' : [5,95],
    'Actor_1_rolling_leads' : [5,95],
    'Actor_2_rolling_leads' : [5,95],
    'Actor_3_rolling_leads' : [5,95],
    'Actor_4_rolling_leads' : [5,95],
    'Actor_1_rolling_leads_5' : [5,95],
    'Actor_2_rolling_leads_5' : [5,95],
    'Actor_3_rolling_leads_5' : [5,95],
    'Actor_4_rolling_leads_5' : [5,95],
    'Actor_1_rolling_roles' : [5,95],
    'Actor_2_rolling_roles' : [5,95],
    'Actor_3_rolling_roles' : [5,95],
    'Actor_4_rolling_roles' : [5,95],
    'Actor_1_rolling_roles_5' : [5,95],
    'Actor_2_rolling_roles_5' : [5,95],
    'Actor_3_rolling_roles_5' : [5,95],
    'Actor_4_rolling_roles_5' : [5,95],
    'Actor_1_rolling_supporting' : [5,95],
    'Actor_2_rolling_supporting' : [5,95],
    'Actor_3_rolling_supporting' : [5,95],
    'Actor_4_rolling_supporting' : [5,95],
    'Actor_1_rolling_supporting_5' : [5,95],
    'Actor_2_rolling_supporting_5' : [5,95],
    'Actor_3_rolling_supporting_5' : [5,95],
    'Actor_4_rolling_supporting_5' : [5,95],
    'Actor_1_rolling_avg_earnings_lead' : [5,95],
    'Actor_2_rolling_avg_earnings_lead' : [5,95],
    'Actor_3_rolling_avg_earnings_lead' : [5,95],
    'Actor_4_rolling_avg_earnings_lead' : [5,95],
    'Actor_1_rolling_avg_earnings_supporting' : [5,95],
    'Actor_2_rolling_avg_earnings_supporting' : [5,95],
    'Actor_3_rolling_avg_earnings_supporting' : [5,95],
    'Actor_4_rolling_avg_earnings_supporting' : [5,95]
})

new = variable_transformation(data = new, feature_dict = {
    'BO_Revenue': 'log',
    'Budget': 'log',
    'Runtime': 'log',
    'franchise_releases_in_last_3_years': 'log',
    # 'time_delta_since_last_franchise_release' : 'log',
    # 'avg_earnings_franchise' : 'log',
    'School_Outage': 'log',
    'count_of_competitor': 'log',
    'last_competitor_release_delta_days': 'log',
    'average_previous_Gross_US': 'log',
    'median_previous_Gross_US': 'log',
    'Actor_1_rolling_leads': 'log',
    'Actor_2_rolling_leads': 'log',
    'Actor_3_rolling_leads': 'log',
    'Actor_4_rolling_leads': 'log',
    'Actor_1_rolling_leads_5': 'log',
    'Actor_2_rolling_leads_5': 'log',
    'Actor_3_rolling_leads_5': 'log',
    'Actor_4_rolling_leads_5': 'log',
    'Actor_1_rolling_roles': 'log',
    'Actor_2_rolling_roles': 'log',
    'Actor_3_rolling_roles': 'log',
    'Actor_4_rolling_roles': 'log',
    'Actor_1_rolling_roles_5': 'log',
    'Actor_2_rolling_roles_5': 'log',
    'Actor_3_rolling_roles_5': 'log',
    'Actor_4_rolling_roles_5': 'log',
    'Actor_1_rolling_supporting': 'log',
    'Actor_2_rolling_supporting': 'log',
    'Actor_3_rolling_supporting': 'log',
    'Actor_4_rolling_supporting': 'log',
    'Actor_1_rolling_supporting_5': 'log',
    'Actor_2_rolling_supporting_5': 'log',
    'Actor_3_rolling_supporting_5': 'log',
    'Actor_4_rolling_supporting_5': 'log',
    'Actor_1_rolling_avg_earnings_lead': 'log',
    'Actor_2_rolling_avg_earnings_lead': 'log',
    'Actor_3_rolling_avg_earnings_lead': 'log',
    'Actor_4_rolling_avg_earnings_lead': 'log',
    'Actor_1_rolling_avg_earnings_supporting': 'log',
    'Actor_2_rolling_avg_earnings_supporting': 'log',
    'Actor_3_rolling_avg_earnings_supporting': 'log',
    'Actor_4_rolling_avg_earnings_supporting': 'log'
})


##### whatever#####
# -*- coding: utf-8 -*-
"""
Created on Tue Mar 26 12:36:57 2019

@author: amit
"""

import pandas as pd
import statsmodels.api as sm
from sklearn.metrics import r2_score
import numpy as np
import itertools
from sklearn.model_selection import train_test_split


class BaselineIteration():
    """
    Class to run linear regression on all the possible combinations of the
    independent variables

    Parameters
    ----------
    x_train: Pandas Dataframe
        The train dataframe with only independent variables along with Title Code and Movie Name
    y_train: Pandas Series
        The train series with only dependent variable
    x_test: Pandas Dataframe
        The validation dataframe with only independent variables along with Title Code and Movie Name
    y_test: Pandas Series
        The validation series with only dependent variable
    Print: Bool
        Whether to print the results on hardrive
    always_include_list_list: List of independent variables or None
        A list of those variables which are required to be force fit in every
        iteration. The combinations will be made of all the other remaining
        variables.
    """

    # Initialising the train and test dataframes
    def __init__(self, x_train, y_train, x_test, y_test, Print, always_include_list=None):
        self.x_train = x_train.copy()
        self.y_train = y_train
        self.x_test = x_test.copy()
        self.y_test = y_test
        self.Print = Print
        self.always_include_list = always_include_list

    def metrics_calculator(self, y_true, y_pred):
        """ Function to calculate the relevant regression metrics"""
        self.r_score = r2_score(np.exp(y_true), np.exp(y_pred))
        self.mae = np.mean(abs(np.exp(y_true) - np.exp(y_pred)))
        self.mape = np.mean(abs(np.exp(y_true) - np.exp(y_pred)) / np.exp(y_true))
        self.Wmape = np.sum(abs(np.exp(y_true) - np.exp(y_pred))) / np.sum(np.exp(y_true))
        return [self.r_score * 100, self.mae, self.mape * 100, self.Wmape * 100]

    def combination_maker(self, combi_data, length):
        """ Funtion which returns all the possible 2^(length) combinations"""
        self.combi = [list(combo) for combo in itertools.combinations(
            combi_data, length)]
        return self.combi

    def run_iteration(self):

        """ Function to run linear regression iterations on all possible
        variable combinations and returns a dataframe with beta coefficients,
        p-values, std error, accuracy metrics"""

        # Initialising the final results dataframe in which all the results of
        # intermediate iterations will keep on appending
        results_df = pd.DataFrame()
        train_title_list = self.x_train[['IMDB_Title_Code', 'Movie_Title']]
        train_title_list.reset_index(drop=True, inplace=True)
        test_title_list = self.x_test[['IMDB_Title_Code', 'Movie_Title']]
        test_title_list.reset_index(drop=True, inplace=True)
        self.x_test.drop(['IMDB_Title_Code', 'Movie_Title'], inplace=True, axis=1)
        self.x_train.drop(['IMDB_Title_Code', 'Movie_Title'], inplace=True, axis=1)

        # Making combinations for different number of variables selected at a
        # time. Starting from 1 to the total number of variables present in
        # the training dataframe
        if self.always_include_list is None:
            for combo_length in np.arange(1, len(self.x_train.columns) + 1):
                print("Combo Length: ", combo_length)

                variable_list = self.x_train.columns.values

                # Looping for all the combinations made from the number
                # of variables selected
                combi_list = self.combination_maker(variable_list, combo_length)
                for num, subset_list in enumerate(combi_list):
                    # Subsetting the variables as selected from the combinations
                    # from the actual train and test dataframes
                    x_train_subset = pd.get_dummies(self.x_train[subset_list], drop_first=True)
                    x_test_subset = pd.get_dummies(self.x_test[subset_list], drop_first=True)

                    # Running the Ordinary Least Squares Iteration.Fitting on
                    # the train data
                    x_train_subset = sm.add_constant(x_train_subset)
                    x_test_subset = sm.add_constant(x_test_subset)
                    ols_object = sm.OLS(self.y_train, x_train_subset)
                    model = ols_object.fit()

                    # Making predictions on the validation data
                    predictions = ols_object.predict(
                        params=model.params, exog=x_test_subset)

                    # Outputting the train, test predictions into csv if print is True
                    if self.Print:
                        train_features = pd.DataFrame(x_train_subset.copy())
                        train_actuals = pd.DataFrame(self.y_train.copy())
                        train_features.reset_index(inplace=True, drop=True)
                        train_actuals.reset_index(inplace=True, drop=True)
                        train_predictions = pd.DataFrame(
                            {'Predictions': model.fittedvalues.values})
                        train_results = pd.concat(
                            [train_title_list, train_features, train_predictions, train_actuals], axis=1)
                        train_results.to_csv(
                            str('train_results_') + str(combo_length) + '_' + str(num + 1) + str('.csv'), index=False)
                        test_features = pd.DataFrame(x_test_subset.copy())
                        test_actuals = pd.DataFrame(self.y_test.copy())
                        test_features.reset_index(inplace=True, drop=True)
                        test_actuals.reset_index(inplace=True, drop=True)
                        test_predictions = pd.DataFrame(
                            {'Predictions': predictions})
                        test_results = pd.concat(
                            [test_title_list, test_features, test_predictions, test_actuals], axis=1)
                        test_results.to_csv(
                            str('test_results_') + str(combo_length) + '_' + str(num + 1) + str('.csv'), index=False)

                    # Getting accuracy metrics for the train as well as test data
                    train_metrics_list = self.metrics_calculator(self.y_train, model.fittedvalues)
                    test_metrics_list = self.metrics_calculator(self.y_test, predictions)

                    # Making a list of all the required values (Beta Estimates,
                    # P-values,etc.) which will be further collated into a dataframe
                    subset_variables_list = model.params.index
                    beta_list = model.params.values
                    pvalues_list = model.pvalues.values
                    std_error_list = model.params.values / model.tvalues.values
                    adj_rsquare_list = [model.rsquared_adj * 100] * len(subset_variables_list)
                    iteration_list = [str(combo_length) + '_' + str(num + 1)] * len(subset_variables_list)
                    train_rsquare_list = [train_metrics_list[0]] * len(subset_variables_list)
                    train_mae_list = [train_metrics_list[1]] * len(subset_variables_list)
                    train_mape_list = [train_metrics_list[2]] * len(subset_variables_list)
                    train_wmape_list = [train_metrics_list[3]] * len(subset_variables_list)
                    test_rsquare_list = [test_metrics_list[0]] * len(subset_variables_list)
                    test_mae_list = [test_metrics_list[1]] * len(subset_variables_list)
                    test_mape_list = [test_metrics_list[2]] * len(subset_variables_list)
                    test_wmape_list = [test_metrics_list[3]] * len(subset_variables_list)

                    # Collating all the required values in a temporary dataframe
                    # only for this iteration
                    temp_df = pd.DataFrame({
                        'Iteration': iteration_list,
                        'Variables': subset_variables_list,
                        'Beta_Coeff': beta_list,
                        'P-Values': pvalues_list,
                        'Std_Error': std_error_list,
                        'Train_R_Square': train_rsquare_list,
                        'Train_Adj_R_Square': adj_rsquare_list,
                        'Train_MAE': train_mae_list,
                        'Train_MAPE': train_mape_list,
                        'Train_WMAPE': train_wmape_list,
                        'Test_R_Square': test_rsquare_list,
                        'Test_MAE': test_mae_list,
                        'Test_MAPE': test_mape_list,
                        'Test_WMAPE': test_wmape_list})

                    # Appending the results of this iteration into the final results
                    # dataframe
                    results_df = pd.concat([results_df, temp_df], axis=0)
                    results_df = results_df[['Iteration', 'Variables', 'Beta_Coeff',
                                             'Std_Error', 'P-Values', 'Train_MAE',
                                             'Train_MAPE', 'Train_Adj_R_Square',
                                             'Train_R_Square', 'Train_WMAPE',
                                             'Test_MAE', 'Test_MAPE',
                                             'Test_R_Square', 'Test_WMAPE']]
                    # Emptying the temporary dataframe to make it ready for the
                    # next iteration
                    temp_df = pd.DataFrame()

        else:
            for combo_length in np.arange(1, len(self.x_train.columns) - len(self.always_include_list) + 1):
                print("Combo Length: ", combo_length)
                variable_list = [variable for variable in self.x_train.columns.values
                                 if variable not in self.always_include_list]

                # Looping for all the combinations made from the number
                # of variables selected
                combi_list = self.combination_maker(variable_list, combo_length)
                for num, subset_list in enumerate(combi_list):
                    # Subsetting the variables as selected from the combinations
                    # from the actual train and test dataframes
                    subset_list.extend(self.always_include_list)
                    x_train_subset = pd.get_dummies(self.x_train[subset_list], drop_first=True)
                    x_test_subset = pd.get_dummies(self.x_test[subset_list], drop_first=True)

                    # Running the Ordinary Least Squares Iteration.Fitting on
                    # the train data
                    x_train_subset = sm.add_constant(x_train_subset)
                    x_test_subset = sm.add_constant(x_test_subset)
                    ols_object = sm.OLS(self.y_train, x_train_subset)
                    model = ols_object.fit()

                    # Making predictions on the validation data
                    predictions = ols_object.predict(
                        params=model.params, exog=x_test_subset)

                    # Outputting the train, test predictions into csv if print is True
                    if self.Print:
                        train_features = pd.DataFrame(x_train_subset.copy())
                        train_actuals = pd.DataFrame(self.y_train.copy())
                        train_features.reset_index(inplace=True, drop=True)
                        train_actuals.reset_index(inplace=True, drop=True)
                        train_predictions = pd.DataFrame(
                            {'Predictions': model.fittedvalues.values})
                        train_results = pd.concat(
                            [train_title_list, train_features, train_predictions, train_actuals], axis=1)
                        train_results.to_csv(
                            str('train_results_') + str(combo_length) + '_' + str(num + 1) + str('.csv'), index=False)
                        test_features = pd.DataFrame(x_test_subset.copy())
                        test_actuals = pd.DataFrame(self.y_test.copy())
                        test_features.reset_index(inplace=True, drop=True)
                        test_actuals.reset_index(inplace=True, drop=True)
                        test_predictions = pd.DataFrame(
                            {'Predictions': predictions})
                        test_results = pd.concat(
                            [test_title_list, test_features, test_predictions, test_actuals], axis=1)
                        test_results.to_csv(
                            str('test_results_') + str(combo_length) + '_' + str(num + 1) + str('.csv'), index=False)

                    # Getting accuracy metrics for the train as well as test data
                    train_metrics_list = self.metrics_calculator(self.y_train, model.fittedvalues)
                    test_metrics_list = self.metrics_calculator(self.y_test, predictions)

                    # Making a list of all the required values (Beta Estimates,
                    # P-values,etc.) which will be further collated into a dataframe
                    subset_variables_list = model.params.index
                    beta_list = model.params.values
                    pvalues_list = model.pvalues.values
                    std_error_list = model.params.values / model.tvalues.values
                    adj_rsquare_list = [model.rsquared_adj * 100] * len(subset_variables_list)
                    iteration_list = [str(combo_length) + '_' + str(num + 1)] * len(subset_variables_list)
                    train_rsquare_list = [train_metrics_list[0]] * len(subset_variables_list)
                    train_mae_list = [train_metrics_list[1]] * len(subset_variables_list)
                    train_mape_list = [train_metrics_list[2]] * len(subset_variables_list)
                    train_wmape_list = [train_metrics_list[3]] * len(subset_variables_list)
                    test_rsquare_list = [test_metrics_list[0]] * len(subset_variables_list)
                    test_mae_list = [test_metrics_list[1]] * len(subset_variables_list)
                    test_mape_list = [test_metrics_list[2]] * len(subset_variables_list)
                    test_wmape_list = [test_metrics_list[3]] * len(subset_variables_list)

                    # Collating all the required values in a temporary dataframe
                    # only for this iteration
                    temp_df = pd.DataFrame({
                        'Iteration': iteration_list,
                        'Variables': subset_variables_list,
                        'Beta_Coeff': beta_list,
                        'P-Values': pvalues_list,
                        'Std_Error': std_error_list,
                        'Train_R_Square': train_rsquare_list,
                        'Train_Adj_R_Square': adj_rsquare_list,
                        'Train_MAE': train_mae_list,
                        'Train_MAPE': train_mape_list,
                        'Train_WMAPE': train_wmape_list,
                        'Test_R_Square': test_rsquare_list,
                        'Test_MAE': test_mae_list,
                        'Test_MAPE': test_mape_list,
                        'Test_WMAPE': test_wmape_list})

                    # Appending the results of this iteration into the final results
                    # dataframe
                    results_df = pd.concat([results_df, temp_df], axis=0)
                    results_df = results_df[['Iteration', 'Variables', 'Beta_Coeff',
                                             'Std_Error', 'P-Values', 'Train_MAE',
                                             'Train_MAPE', 'Train_Adj_R_Square',
                                             'Train_R_Square', 'Train_WMAPE',
                                             'Test_MAE', 'Test_MAPE',
                                             'Test_R_Square', 'Test_WMAPE']]
                    # Emptying the temporary dataframe to make it ready for the
                    # next iteration
                    temp_df = pd.DataFrame()

        return results_df


x_train, x_test, y_train, y_test = train_test_split(new[['IMDB_Title_Code',
                                                        'Movie_Title',
                                                        'BO_Window',
                                                    'HE_Spend',
                                                    'BO_Revenue_log',
'Budget_log',
'Runtime_log',
'franchise_releases_in_last_3_years_log',
'School_Outage_log',
'count_of_competitor_log',
'last_competitor_release_delta_days_log',
'average_previous_Gross_US_log',
'median_previous_Gross_US_log',
'Actor_1_rolling_leads_log',
'Actor_2_rolling_leads_log',
'Actor_3_rolling_leads_log',
'Actor_4_rolling_leads_log',
'Actor_1_rolling_leads_5_log',
'Actor_2_rolling_leads_5_log',
'Actor_3_rolling_leads_5_log',
'Actor_4_rolling_leads_5_log',
'Actor_1_rolling_roles_log',
'Actor_2_rolling_roles_log',
'Actor_3_rolling_roles_log',
'Actor_4_rolling_roles_log',
'Actor_1_rolling_roles_5_log',
'Actor_2_rolling_roles_5_log',
'Actor_3_rolling_roles_5_log',
'Actor_4_rolling_roles_5_log',
'Actor_1_rolling_supporting_log',
'Actor_2_rolling_supporting_log',
'Actor_3_rolling_supporting_log',
'Actor_4_rolling_supporting_log',
'Actor_1_rolling_supporting_5_log',
'Actor_2_rolling_supporting_5_log',
'Actor_3_rolling_supporting_5_log',
'Actor_4_rolling_supporting_5_log',
'Actor_1_rolling_avg_earnings_lead_log',
'Actor_2_rolling_avg_earnings_lead_log',
'Actor_3_rolling_avg_earnings_lead_log',
'Actor_4_rolling_avg_earnings_lead_log',
'Actor_1_rolling_avg_earnings_supporting_log',
'Actor_2_rolling_avg_earnings_supporting_log',
'Actor_3_rolling_avg_earnings_supporting_log',
'Actor_4_rolling_avg_earnings_supporting_log']],
                                                    new['HE_Revenue'],
                                                  test_size = 30,
                                                  random_state=100)

vif_calculator(dataframe = x_train, column_list = ['BO_Window',
                                                    'HE_Spend',
                                                    'BO_Revenue_log',
'Budget_log',
'Runtime_log',
'franchise_releases_in_last_3_years_log',
'School_Outage_log',
'count_of_competitor_log',
'last_competitor_release_delta_days_log',
'average_previous_Gross_US_log',
#'median_previous_Gross_US_log',
#'Actor_1_rolling_leads_log',
#'Actor_2_rolling_leads_log',
#'Actor_3_rolling_leads_log',
#'Actor_4_rolling_leads_log',
'Actor_1_rolling_leads_5_log',
'Actor_2_rolling_leads_5_log',
'Actor_3_rolling_leads_5_log',
'Actor_4_rolling_leads_5_log',
'Actor_1_rolling_roles_log',
#'Actor_2_rolling_roles_log',
#'Actor_3_rolling_roles_log',
#'Actor_4_rolling_roles_log',
#'Actor_1_rolling_roles_5_log',
#'Actor_2_rolling_roles_5_log',
#'Actor_3_rolling_roles_5_log',
#'Actor_4_rolling_roles_5_log',
'Actor_1_rolling_supporting_log',
'Actor_2_rolling_supporting_log',
'Actor_3_rolling_supporting_log',
#'Actor_4_rolling_supporting_log',
'Actor_1_rolling_supporting_5_log',
'Actor_2_rolling_supporting_5_log',
'Actor_3_rolling_supporting_5_log',
'Actor_4_rolling_supporting_5_log',
'Actor_1_rolling_avg_earnings_lead_log',
'Actor_2_rolling_avg_earnings_lead_log',
'Actor_3_rolling_avg_earnings_lead_log',
'Actor_4_rolling_avg_earnings_lead_log',
'Actor_1_rolling_avg_earnings_supporting_log',
'Actor_2_rolling_avg_earnings_supporting_log',
'Actor_3_rolling_avg_earnings_supporting_log',
'Actor_4_rolling_avg_earnings_supporting_log'])


instance_1 = BaselineIteration(x_train = x_train[['IMDB_Title_Code',
                                                  'Movie_Title',
                                                  'Actor_1_rolling_avg_earnings_lead_log',
'Actor_1_rolling_avg_earnings_supporting_log',
'Actor_1_rolling_roles_log',
'Actor_1_rolling_supporting_log',
'average_previous_Gross_US_log',
'BO_Window',
'Budget_log',
'count_of_competitor_log',
'franchise_releases_in_last_3_years_log',
'HE_Spend',
'last_competitor_release_delta_days_log',
'Runtime_log',
#'School_Outage_log'
]],
                               y_train = np.log(y_train),
                               x_test = x_test[['IMDB_Title_Code',
                                                  'Movie_Title',
'BO_Window',
'HE_Spend',
                                                  'Actor_1_rolling_avg_earnings_lead_log',
'Actor_1_rolling_avg_earnings_supporting_log',
'Actor_1_rolling_roles_log',
'Actor_1_rolling_supporting_log',
'average_previous_Gross_US_log',
'Budget_log',
'count_of_competitor_log',
'franchise_releases_in_last_3_years_log',
'last_competitor_release_delta_days_log',
'Runtime_log',
#'School_Outage_log'
                                                ]],
                               y_test = np.log(y_test),
                               Print = False,
                               always_include_list = ['BO_Window',
                                                           'HE_Spend'])

result = instance_1.run_iteration()

result.to_excel(r"C:\Users\v-sanysa\Desktop\model_results.xlsx", index=False, sheet_name='Sheet1')
