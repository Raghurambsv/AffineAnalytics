# importing packages
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from scipy.stats.mstats import zscore
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
import statsmodels.api as sm
from sklearn.feature_selection import chi2
import math

# importing dataset
df = pd.read_csv(
    filepath_or_buffer=r"C:\Users\hanaa\Desktop\imputed_data_2.csv",
    sep=',')
df_temp=df
df["like/view"]=df["likes_count"]/df["views_count"]
df["dislike/view"]=df["dislikes_count"]/df["views_count"]
df["Exp_Budget"]=np.exp(df['Budget'])
df["spend/budget"]=df["BO_Media_Spend"]/df["Exp_Budget"]
del df["likes_count"],df["dislikes_count"],df["views_count"],df["Budget"],df["BO_Media_Spend"],df["BO_Log"]

# Data Wrangling
df.replace([np.inf, -np.inf], np.nan) #convert infs to nans
df=df.loc[df['IMDB_Title_Code'].dropna(axis = 0,
                                       how = 'any').index, :] # remove blank IMDB Title Codes

# correcting dates
df['Theatrical_Release_Date'] = pd.to_datetime(arg=df['Theatrical_Release_Date'], format="%d-%m-%Y",)

df = df[['IMDB_Title_Code',
         'Movie_Title',
         'BO_Revenue',
         'Theatrical_Release_Date',
         'Month',
         'Runtime',
         'MPAA_rating',
         'Genre',
         'franchise_flag',
         'time_delta_since_last_franchise_release',
         'any_competitor_release',
         'HolidayFlag',
         'School_Outage',
         'like/view',
         'spend/budget']]

# split train test data by years
train = df.loc[df['Theatrical_Release_Date'].dt.year < 2018, :]
test = df.loc[df['Theatrical_Release_Date'].dt.year == 2018, :]

# standardization
mean_train = np.mean(train[['Runtime','time_delta_since_last_franchise_release','School_Outage','like/view', 'spend/budget']])
sd_train = np.std(train[['Runtime','time_delta_since_last_franchise_release','School_Outage','like/view', 'spend/budget']])
train = pd.concat([train[['IMDB_Title_Code',
                         'Movie_Title',
                         'Theatrical_Release_Date',
                          'BO_Revenue',
                         'Month',
                         'MPAA_rating',
                         'Genre',
                         'franchise_flag',
                         'any_competitor_release',
                         'HolidayFlag']].reset_index(drop=True),
                   ((train[['Runtime',
                           'time_delta_since_last_franchise_release',
                           'School_Outage',
                           'like/view',
                           'spend/budget']]-mean_train)/sd_train).reset_index(drop=True)],
                  axis=1)
test = pd.concat([test[['IMDB_Title_Code',
                       'Movie_Title',
                       'Theatrical_Release_Date',
                        'BO_Revenue',
                       'Month',
                       'MPAA_rating',
                       'Genre',
                       'franchise_flag',
                       'any_competitor_release',
                       'HolidayFlag']].reset_index(drop=True),
                  ((test[['Runtime',
                           'time_delta_since_last_franchise_release',
                           'School_Outage',
                           'like/view',
                           'spend/budget']]-mean_train)/sd_train).reset_index(drop=True)],
                  axis=1)
del mean_train, sd_train

# checking for optimal number of Principal Components
pca = PCA(n_components = 5)
principalComponents  = pca.fit_transform(train[['Runtime','time_delta_since_last_franchise_release','School_Outage','like/view','spend/budget']])
# display variance curve
plt.plot(np.cumsum(np.round(pca.explained_variance_ratio_, decimals=3)*100))
df_lt=(np.cumsum(np.round(pca.explained_variance_ratio_, decimals=3)*100)).tolist()
ratio=[]
for n,i in enumerate(df_lt):
    if((n+1)<len(df_lt)):
        ratio.append(df_lt[n+1]/df_lt[n])
plt.plot(ratio)
plt.ylabel('% Variance Explained')
plt.xlabel('# of Features')
plt.title('PCA Analysis')
plt.ylim(30,100.5)
plt.style.context('seaborn-whitegrid')

# calculating principal components
n_pc = 5
pca = PCA(n_components = n_pc)
pca.fit_transform(train[['Runtime','time_delta_since_last_franchise_release','School_Outage','like/view', 'spend/budget']])
PCs = pca.components_
PC_train = pd.concat([train[['IMDB_Title_Code',
                         'Movie_Title',
                         'Theatrical_Release_Date',
                             'BO_Revenue',
                         'Month',
                         'MPAA_rating',
                         'Genre',
                         'franchise_flag',
                         'any_competitor_release',
                         'HolidayFlag']].reset_index(drop=True),
                      pd.DataFrame(train[['Runtime','time_delta_since_last_franchise_release','School_Outage','like/view', 'spend/budget']].as_matrix().dot(np.transpose(PCs))).reset_index(drop=True)],
                     axis = 1)
PC_test = pd.concat([test[['IMDB_Title_Code',
                         'Movie_Title',
                         'Theatrical_Release_Date',
                           'BO_Revenue',
                         'Month',
                         'MPAA_rating',
                         'Genre',
                         'franchise_flag',
                         'any_competitor_release',
                         'HolidayFlag']].reset_index(drop=True),
                     pd.DataFrame(test[['Runtime','time_delta_since_last_franchise_release','School_Outage','like/view', 'spend/budget']].as_matrix().dot(np.transpose(PCs))).reset_index(drop=True)],
                    axis=1)

col_names_pc = ['IMDB_Title_Code',
                'Movie_Title',
                'Theatrical_Release_Date',
                'BO_Revenue',
                'Theater_Release_Month',
                'MPAA_rating',
                'Genre',
                'franchise_flag',
                'any_competitor_release',
                'HolidayFlag']
for i in range(n_pc):
    col_names_pc.append("PC"+str(i+1))

# final datasets
PC_train.columns = col_names_pc
PC_test.columns = col_names_pc

PC_train
PC_test



# model using statmodels
est = sm.OLS(list(PC_train['BO_Revenue']), sm.add_constant(PC_train[['Theater_Release_Month',
                                                                  'MPAA_rating',
                                                                  'Genre',
                                                                  'franchise_flag',
                                                                  'any_competitor_release',
                                                                  'HolidayFlag',
                                                                  'PC1',
                                                                  'PC2',
                                                                  'PC3',
                                                                  'PC4',
                                                                  'PC5']])) # prepare linear model using OLS estimation
est2 = est.fit() # the model
print(est2.summary()) # get model summary
est2.params # get beta coefficients
est2.pvalues # get p-values
est2.resid # residuals/error when scored on train data

# scoring
Y_test_hat = est.predict(params=est2.params,
                         exog=sm.add_constant(test['Theater_Release_Month',
                'MPAA_rating',
                'Genre',
                'franchise_flag',
                'any_competitor_release',
                'HolidayFlag','PC1','PC2','PC3','PC4','PC5']))

