import pandas as pd

NRG = pd.read_excel(r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Latest\NRG HE Tracking DB_NOV282018.xlsx")

maps = pd.read_excel(r"C:\Users\v-sanysa\Desktop\Final_Mapping_Data_v4.xlsx",
                     sheet_name = 'NRG title code')

NRG_mapped = pd.merge(left=NRG,
                      right=maps,
                      how='left',
                      left_on='title',
                      right_on='name')
del NRG_mapped['name']

NRG_mapped.rename(columns={'code' : 'IMDB_Title_Code',
                           'title' : 'Movie_Title'},
                  inplace=True)
col_names = ['IMDB_Title_Code', 'Movie_Title']+NRG_mapped.columns.values[range(1,NRG_mapped.shape[1]-1)].tolist()
NRG_mapped = NRG_mapped[col_names]
NRG_mapped = NRG_mapped.drop_duplicates(inplace=True)






# NRG_mapped.to_csv(r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\NRG_with_title_id.csv",
#                   index=False,
#                   na_rep='')




# NRG_subset = NRG_mapped.loc[(NRG_mapped['IMDB_Title_Code']=='tt4123430') |
#                             (NRG_mapped['IMDB_Title_Code']=='tt4468740'), :]
# NRG_subset.to_csv(r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\NRG_FB,PD2.csv",
#                   index=False,
#                   na_rep='')
# NRG_subset.drop_duplicates(inplace=True)