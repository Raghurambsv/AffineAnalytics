from bs4 import BeautifulSoup
import requests
import re
import csv

csvfile = open(r"C:\Users\v-sanysa\Desktop\Other_Movies_IMDB.csv", 'w', newline='')
writer = csv.writer(csvfile, delimiter = ",")
writer.writerow(["TitleSearched","ID","Name", "IMDB Url"])

MovieList = open(r"C:\Users\v-sanysa\Desktop\movie_list_04-18_Comp_Spending.csv", 'r', newline='')
MovieReader = csv.reader(MovieList, delimiter=',')

for row in MovieReader:
    error = 0
    MovieName = row[1]
    CleanedMovieName = MovieName.replace(' ','+')
    
    url = 'https://www.imdb.com/find?ref_=nv_sr_fn&q=' + CleanedMovieName + '&s=tt'
    
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')

    MovieChoice = soup.find('td', class_='result_text')
    
    try:
        TitleName = MovieChoice.a.text
    except AttributeError:
        TitleName = "NA"
        error = 1
        
    try:
        TitleURL = MovieChoice.a.get('href')
        if not TitleURL.startswith("https://www.imdb.com"):
            TitleURL = "https://www.imdb.com" + TitleURL
    except AttributeError:
        TitleURL = "NA"      
        error = 1
        
    try:
        TitleID = re.search('/(tt[0-9]{7})/', TitleURL).group(1)
    except AttributeError:
        TitleID = "NA"
        error = 1

    writer.writerow([MovieName, TitleID, TitleName, TitleURL])       
    
    if error == 0:
        print('Movie ' + MovieName + ' done!')
    else:
        print('Movie ' + MovieName + ' had error!')
    
csvfile.close()
MovieList.close()
print ("\nScraping Complete!!!")
