import pandas as pd

title_list = pd.read_excel(io=r"C:\Users\v-sanysa\OneDrive - Affine Analytics Pvt Ltd\Projects\WB TT MMM\temporary_files\Titles_4Sets.xlsx",
                           sheet_name='Sheet1')

BO_WB = pd.read_csv(filepath_or_buffer=r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Analytical Datasets\Set 4 - WB Non-WB CompSpending Imputed\BO_base_AD_WB_v1.3.csv", sep = ',', encoding = 'latin-1')
BO_nonWB = pd.read_csv(filepath_or_buffer=r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Analytical Datasets\Set 4 - WB Non-WB CompSpending Imputed\BO_base_AD_non_WB_v1.3.csv", sep = ',', encoding = 'latin-1')
HE_WB = pd.read_csv(filepath_or_buffer=r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Analytical Datasets\Set 4 - WB Non-WB CompSpending Imputed\HE_base_AD_WB_v1.3.csv", sep = ',', encoding = 'latin-1')
HE_non_WB = pd.read_csv(filepath_or_buffer=r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Analytical Datasets\Set 4 - WB Non-WB CompSpending Imputed\HE_base_AD_non_WB_v1.3.csv", sep = ',', encoding = 'latin-1')


temp = BO_WB[BO_WB['IMDB_Title_Code'].isin(title_list.iloc[:,0].dropna())]
temp.to_csv(path_or_buf = r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Analytical Datasets\Set 1 - WB Base\BO_Base_AD_WB_v1.3.csv", index=False)
temp = HE_WB[HE_WB['IMDB_Title_Code'].isin(title_list.iloc[:,1].dropna())]
temp.to_csv(path_or_buf = r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Analytical Datasets\Set 1 - WB Base\HE_Base_AD_WB_v1.3.csv", index=False)
temp = BO_WB[BO_WB['IMDB_Title_Code'].isin(title_list.iloc[:,2].dropna())]
temp.to_csv(path_or_buf = r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Analytical Datasets\Set 2 - WB - Imputed\BO_Base_AD_WB_v1.3.csv", index=False)
temp = HE_WB[HE_WB['IMDB_Title_Code'].isin(title_list.iloc[:,3].dropna())]
temp.to_csv(path_or_buf = r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Analytical Datasets\Set 2 - WB - Imputed\HE_Base_AD_WB_v1.3.csv", index=False)
temp = BO_WB[BO_WB['IMDB_Title_Code'].isin(title_list.iloc[:,4].dropna())]
temp.to_csv(path_or_buf = r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Analytical Datasets\Set 3 - WB CompSpend Imputed\BO_Base_AD_WB_v1.3.csv", index=False)
temp = HE_WB[HE_WB['IMDB_Title_Code'].isin(title_list.iloc[:,5].dropna())]
temp.to_csv(path_or_buf = r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Analytical Datasets\Set 3 - WB CompSpend Imputed\HE_Base_AD_WB_v1.3.csv", index=False)
