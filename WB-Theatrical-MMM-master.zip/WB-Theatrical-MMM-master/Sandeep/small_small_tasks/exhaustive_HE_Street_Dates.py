import numpy as np
import pandas as pd

# importing datasets
df = pd.read_csv(r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Analytical Datasets\Set 4 - WB Non-WB CompSpending Imputed\BO_base_AD_WB_v1.3.csv")
HE_Sales = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\HE_Sales_v1.0.csv')
comp_release = pd.read_csv(r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Comp_Release_Schedule_v3.1.csv", sep = ',', encoding = 'latin-1')
total_media = pd.read_csv(r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Total Media2_v3.csv")
Jay_s_file = pd.read_excel(r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Latest\Data from Jay\Theatrical Window - Data Validation Report_v1.0.xlsx",
                           sheet_name='Titles - Validation with Affine',
                           header=3)
title_maps = pd.read_csv(filepath_or_buffer=r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Final_Mapping_Data_v4.csv",
                         sep = ',',
                         encoding = 'latin-1')

# assigning date columns
df['Theatrical_Release_Date'] = pd.to_datetime(arg=df['Theatrical_Release_Date'], infer_datetime_format=True)
HE_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=HE_Sales['Theatrical_Release_Date'], infer_datetime_format=True)
HE_Sales['EST_Street_Date'] = pd.to_datetime(arg=HE_Sales['EST_Street_Date'], infer_datetime_format=True)
HE_Sales['iVOD_Street_Date'] = pd.to_datetime(arg=HE_Sales['iVOD_Street_Date'], infer_datetime_format=True)
HE_Sales['cVOD_Street_Date'] = pd.to_datetime(arg=HE_Sales['cVOD_Street_Date'], infer_datetime_format=True)
HE_Sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=HE_Sales['Blu-ray_Street_Date'], infer_datetime_format=True)
HE_Sales['DVD_Street_Date'] = pd.to_datetime(arg=HE_Sales['DVD_Street_Date'], infer_datetime_format=True)
comp_release['Theatrical_Release'] = pd.to_datetime(arg=comp_release['Theatrical_Release'], infer_datetime_format=True)
comp_release['PST_Release'] = pd.to_datetime(arg=comp_release['PST_Release'], infer_datetime_format=True)
comp_release['EST_Release'] = pd.to_datetime(arg=comp_release['EST_Release'], infer_datetime_format=True)
comp_release['VOD_Release'] = pd.to_datetime(arg=comp_release['VOD_Release'], infer_datetime_format=True)
comp_release['PST_Rental_Release'] = pd.to_datetime(arg=comp_release['PST_Rental_Release'], infer_datetime_format=True)
total_media['Video_Rel_Date'] = pd.to_datetime(arg=total_media['Video_Rel_Date'], infer_datetime_format=True)
Jay_s_file['Theatrical'] = pd.to_datetime(arg=Jay_s_file['Theatrical'], infer_datetime_format=True)
Jay_s_file['Street'] = pd.to_datetime(arg=Jay_s_file['Street'], infer_datetime_format=True)

# preparing datasets
# preparing mapping file
temp = title_maps[['Movie_Title', 'IMDB_Title_Code', 'Release Year_WB']]
temp.rename(columns={'Movie_Title' : 'Title'}, inplace=True)
title_maps = temp.append(title_maps[['Title', 'IMDB_Title_Code', 'Release Year_WB']])
del temp
title_maps.drop_duplicates(inplace=True)
title_maps['Title_lowercase'] = title_maps['Title'].str.lower()
# selecting 121 WB IMDB_Title_Codes from our Set-4 Base AD
df = df[['IMDB_Title_Code', 'Theatrical_Release_Date']]
HE_Sales['WS_EST_Street_Date'] = HE_Sales[['EST_Street_Date', 'iVOD_Street_Date', 'cVOD_Street_Date']].min(axis = 1)
HE_Sales['WS_PST_Street_Date'] = HE_Sales[['Blu-ray_Street_Date', 'DVD_Street_Date']].min(axis = 1)
HE_Sales = HE_Sales[['IMDB_Title_Code', 'Theatrical_Release_Date', 'WS_EST_Street_Date', 'WS_PST_Street_Date']]
HE_Sales.rename(columns={'Theatrical_Release_Date' : 'WS_Theatrical_Release_Date'}, inplace=True)
comp_release['CR_EST_Street_Date'] = comp_release[['EST_Release', 'VOD_Release']].min(axis = 1)
comp_release['CR_PST_Street_Date'] = comp_release[['PST_Release', 'PST_Rental_Release']].min(axis = 1)
comp_release.rename(columns={'IMDB_Title_ID' : 'IMDB_Title_Code',
                             'Theatrical_Release' : 'CR_Theatrical_Release_Date'},
                    inplace=True)
comp_release = comp_release[['IMDB_Title_Code', 'CR_Theatrical_Release_Date', 'CR_EST_Street_Date', 'CR_PST_Street_Date']]
total_media = total_media[['IMDB_Title_Code', 'Video_Rel_Date']]
total_media.rename(columns={'Video_Rel_Date' : 'TM_HE_Street_Date'},
                   inplace=True)
Jay_s_file = Jay_s_file[['IMDB Title Code', 'Street']]
Jay_s_file.rename(columns={'IMDB Title Code' : 'IMDB_Title_Code',
                           'Street' : 'Jays_HE_Street_Date'},
                  inplace=True)

# preparing dataset containing all EST and PST release dates  from all files for 121 WB titles
WB_Street_Dates = pd.merge(left=df,
                           right = HE_Sales,
                           how='left',
                           left_on = ['IMDB_Title_Code'],
                           right_on = ['IMDB_Title_Code'],
                           sort = True,
                           copy = False)
WB_Street_Dates = pd.merge(left=WB_Street_Dates,
                           right = comp_release,
                           how='left',
                           left_on = ['IMDB_Title_Code'],
                           right_on = ['IMDB_Title_Code'],
                           sort = True,
                           copy = False)
WB_Street_Dates = pd.merge(left=WB_Street_Dates,
                           right = total_media,
                           how='left',
                           left_on = ['IMDB_Title_Code'],
                           right_on = ['IMDB_Title_Code'],
                           sort = True,
                           copy = False)
WB_Street_Dates = pd.merge(left=WB_Street_Dates,
                           right = Jay_s_file,
                           how='left',
                           left_on = ['IMDB_Title_Code'],
                           right_on = ['IMDB_Title_Code'],
                           sort = True,
                           copy = False)

# exporting WB_Street_Dates
WB_Street_Dates.to_excel(excel_writer = r"C:\Users\v-sanysa\Desktop\WB_Street_Dates1.xlsx",
                         sheet_name='WB_Street_Dates',
                         index=False)
