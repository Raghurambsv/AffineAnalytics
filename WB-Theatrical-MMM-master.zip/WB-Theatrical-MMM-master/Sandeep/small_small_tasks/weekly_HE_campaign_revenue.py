# author=Sandeep Sanyal

# set local path for synced sharepoint
sharepoint_path = r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/'

# importing modules
import pandas as pd
start_time = pd.datetime.now()
import numpy as np
import math

# reading datasets
FB_Data = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 2 Data\Cleaned\FB Data\FB_Data_v1.0.csv",
                      sep = ',',                # Contains Title-Week level Campaign data
                      encoding = 'latin-1')
HE_sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\HE_Sales_v1.0.csv",
                       sep = ',',                       # Contains Title level Blu-ray, DVD, EST, iVOD, cVOD Revenues
                       encoding = 'latin-1')            # used to get unique PST and EST Release dates along with unique Studio per Title
Physical_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Physical_Weekly_Sales_v3.csv",
                                    sep = ',',       # Contains Title-Week level Blu-ray & DVD Revenue
                                    encoding = 'latin-1')
Digital_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Digital_Weekly_Sales_v3.csv",
                                   sep = ',',        # Contains Title-Week level EST, iVOD & cVOD Revenue
                                   encoding = 'latin-1')
title_maps = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Final_Mapping_Data_v4.csv",
                         sep = ',',
                         encoding = 'latin-1')

# correcting date columns
HE_sales['Theatrical_Release_Date'] = pd.to_datetime(arg=HE_sales['Theatrical_Release_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=HE_sales['Blu-ray_Street_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['DVD_Street_Date'] = pd.to_datetime(arg=HE_sales['DVD_Street_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['EST_Street_Date'] = pd.to_datetime(arg=HE_sales['EST_Street_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['cVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['cVOD_Street_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['iVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['iVOD_Street_Date'], format="%Y-%m-%d", errors="coerce")
Physical_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Street_Date'], format="%Y-%m-%d", errors="coerce")
Physical_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Theatrical_Release_Date'], format="%Y-%m-%d", errors="coerce")
Digital_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Street_Date'], format="%Y-%m-%d", errors="coerce")
Digital_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Theatrical_Release_Date'], format="%Y-%m-%d", errors="coerce")
FB_Data['Day'] = pd.to_datetime(arg=FB_Data['Day'], infer_datetime_format=True)

# preparing mapping file
temp = title_maps[['Movie_Title', 'IMDB_Title_Code']]
temp.rename(columns={'Movie_Title' : 'Title'}, inplace=True)
title_maps = temp.append(title_maps[['Title', 'IMDB_Title_Code']])
del temp
title_maps.drop_duplicates(inplace=True)
title_maps['Title_lowercase'] = title_maps['Title'].str.lower()

# mapping IMDB Title Codes with FB_data
FB_Data['Title_lowercase'] = FB_Data['Title_Name'].str.lower()
FB_Data = pd.merge(left=FB_Data,
                   right=title_maps,
                   how='left',
                   left_on=['Title_lowercase'],
                   right_on=['Title_lowercase'],
                   sort=True,
                   copy=False)
# getting Theater Release Dates for FB_Data
FB_Data = pd.merge(left=FB_Data,
                   right=HE_sales[['IMDB_Title_Code',
                                   'Theatrical_Release_Date']],
                   how='left',
                   left_on=['IMDB_Title_Code'],
                   right_on=['IMDB_Title_Code'],
                   sort=True,
                   copy=False)
FB_Data['Year'] = FB_Data['Day'].dt.year
FB_Data['Month'] = FB_Data['Day'].dt.month

# # subseting datasets
titles = pd.merge(left=FB_Data[['IMDB_Title_Code']].drop_duplicates(), # selecting titles with both Campaign and HE Sales data present
                  right=HE_sales[['IMDB_Title_Code']],
                  how='inner',
                  left_on=['IMDB_Title_Code'],
                  right_on=['IMDB_Title_Code'],
                  sort=True,
                  copy=False).iloc[:,0].tolist()
FB_Data = FB_Data.loc[FB_Data['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)
HE_sales = HE_sales.loc[HE_sales['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)
Physical_Weekly_Sales = Physical_Weekly_Sales.loc[Physical_Weekly_Sales['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)
Digital_Weekly_Sales = Digital_Weekly_Sales.loc[Digital_Weekly_Sales['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)

# # fixing double studio issues
# Digital_Weekly_Sales
for i in Digital_Weekly_Sales['IMDB_Title_Code'].unique():
    temp = Digital_Weekly_Sales.loc[Digital_Weekly_Sales['IMDB_Title_Code'] == i, :]
    if len(temp['Studio'].unique()) > 1 :
        if temp['Studio'].str.contains('WARNER').sum() > 0 :
            Digital_Weekly_Sales.drop(index=temp.loc[temp['Studio'] != 'WARNER'].index.values,
                                      axis=0,
                                      inplace=True)
        else :
            gp_data = temp.groupby(['IMDB_Title_Code',
                                    'Item_Title_WW',
                                    'Studio',
                                    'Street_Date',
                                    'Theatrical_Release_Date']).agg({'Revenue': 'sum',
                                                                     'Units': 'sum'}).reset_index()
            if len(gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].unique()) == 2 :
                Digital_Weekly_Sales.drop(index=temp.loc[temp['Studio'] == 'ALL OTHERS'].index.values,
                                          axis=0,
                                          inplace=True)
            elif len(gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].unique()) == 1:
                Digital_Weekly_Sales.drop(index=Digital_Weekly_Sales.loc[(Digital_Weekly_Sales['IMDB_Title_Code'] == i) & (Digital_Weekly_Sales['Studio'] == (gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].values)[0]), :].index.values,
                                          axis=0,
                                          inplace=True)
# Physical_Weekly_Sales
for i in Physical_Weekly_Sales['IMDB_Title_Code'].unique():
    temp = Physical_Weekly_Sales.loc[Physical_Weekly_Sales['IMDB_Title_Code'] == i, :]
    if len(temp['Studio'].unique()) > 1 :
        if temp['Studio'].str.contains('WARNER').sum() > 0 :
            Physical_Weekly_Sales.drop(index=temp.loc[temp['Studio'] != 'WARNER'].index.values,
                                       axis=0,
                                       inplace=True)
        else :
            gp_data = temp.groupby(['IMDB_Title_Code',
                                    'Item_Title_WW',
                                    'Studio',
                                    'Street_Date',
                                    'Theatrical_Release_Date']).agg({'Revenue': 'sum',
                                                                     'Units': 'sum'}).reset_index()
            if len(gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].unique()) == 2 :
                Physical_Weekly_Sales.drop(index=temp.loc[temp['Studio'] == 'ALL OTHERS'].index.values,
                                           axis=0,
                                           inplace=True)
            elif len(gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].unique()) == 1 :
                Physical_Weekly_Sales.drop(index=Physical_Weekly_Sales.loc[(Physical_Weekly_Sales['IMDB_Title_Code'] == i) & (Physical_Weekly_Sales['Studio'] == (gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].values)[0]), :].index.values,
                                           axis=0,
                                           inplace=True)
del i, temp

# fixing same studio, double release date issues
# Digital_Weekly_Sales
for i in Digital_Weekly_Sales['IMDB_Title_Code'].unique() :
    Digital_Weekly_Sales.loc[Digital_Weekly_Sales["IMDB_Title_Code"] == i, 'Street_Date'] = Digital_Weekly_Sales.loc[Digital_Weekly_Sales["IMDB_Title_Code"] == i, 'Street_Date'].min()
# Physical_Weekly_Sales
for i in Physical_Weekly_Sales['IMDB_Title_Code'].unique() :
    Physical_Weekly_Sales.loc[Physical_Weekly_Sales["IMDB_Title_Code"] == i, 'Street_Date'] = Physical_Weekly_Sales.loc[Physical_Weekly_Sales["IMDB_Title_Code"] == i, 'Street_Date'].min()
del i

# calculating EST_Release_Date & PST_Release_Date
HE_sales['EST_Release_Date'] = HE_sales[['EST_Street_Date',
                                         'cVOD_Street_Date',
                                         'iVOD_Street_Date']].min(axis = 1)
HE_sales['PST_Release_Date'] = HE_sales[['Blu-ray_Street_Date',
                                         'DVD_Street_Date']].min(axis = 1)

# creating list of all IMDB_Title_Codes & their Theatrical, EST & PST Release Dates
all_titles = HE_sales[['IMDB_Title_Code',
                       'Theatrical_Release_Date',
                       'EST_Release_Date',
                       'PST_Release_Date']]
all_titles['Week Begin'] = all_titles['Theatrical_Release_Date']

# calculating Week number for FB_data, EST & PST Release dates
for i in all_titles['IMDB_Title_Code'].unique() :
    if pd.isnull(all_titles.loc[all_titles['IMDB_Title_Code']==i, 'Week Begin'].values[0]) :
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code']==i, 'Theatrical_Release_Date'] - all_titles.loc[all_titles['IMDB_Title_Code']==i, 'EST_Release_Date'])/pd.offsets.Day(-1))/7)
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'PST_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Theatrical_Release_Date'] - all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'PST_Release_Date'])/pd.offsets.Day(-1))/7)
    else :
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Week Begin'] - all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Release_Date'])/pd.offsets.Day(-1))/7)
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'PST_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Week Begin'] - all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'PST_Release_Date'])/pd.offsets.Day(-1))/7)
    FB_Data['Week'] = np.floor(((FB_Data['Theatrical_Release_Date'] - FB_Data['Day'])/pd.offsets.Day(-1))/7)
del i

# grouping FB_data
gp_data=FB_Data.groupby(['IMDB_Title_Code',
                         'Week']).agg({'Amt_Spent':'sum',
                                       'Impressions':'sum',
                                       'Clicks':'sum',
                                       'Reach':'sum',
                                       'Engagement':'sum',
                                       'Likes':'sum',
                                       'Comments':'sum',
                                       'Shares':'sum',
                                       'Day':['min', 'max']}).reset_index()

# calculating week numbers since release date
# Physical_Weekly_Sales
Weekly_PST_sales_1 = pd.DataFrame({'IMDB_Title_Code' : [],
                                   'Item_Title_WW' : [],
                                   'Studio' : [],
                                   'Street_Date' : [],
                                   'Theatrical_Release_Date' : [],
                                   'Media_Type' : [],
                                   'Week' : [],
                                   'Revenue' : [],
                                   'Units' : []})
for i in all_titles['IMDB_Title_Code'] :
    temp = Physical_Weekly_Sales.loc[Physical_Weekly_Sales['IMDB_Title_Code'] == i, :]
    for j in temp.index :
        temp.loc[j,'Week'] = temp.loc[j,'Week'] + all_titles.loc[all_titles['IMDB_Title_Code'] == i,'PST_Week_Start'].values
    Weekly_PST_sales_1 = Weekly_PST_sales_1.append(temp)
# Digital_Weekly_Sales
Weekly_EST_sales_1 = pd.DataFrame({'IMDB_Title_Code' : [],
                                   'Item_Title_WW' : [],
                                   'Studio' : [],
                                   'Street_Date' : [],
                                   'Theatrical_Release_Date' : [],
                                   'Media_Type' : [],
                                   'Week' : [],
                                   'Revenue' : [],
                                   'Units' : []})
for i in all_titles['IMDB_Title_Code'] :
    temp = Digital_Weekly_Sales.loc[Digital_Weekly_Sales['IMDB_Title_Code'] == i, :]
    for j in temp.index :
        temp.loc[j,'Week'] = temp.loc[j,'Week'] + all_titles.loc[all_titles['IMDB_Title_Code'] == i,'EST_Week_Start'].values
    Weekly_EST_sales_1 = Weekly_EST_sales_1.append(temp)
del i, j, temp

# combining Blu-ray & DVD Revenue/Units to PST Revenue/Units
Weekly_PST_sales_1 = Weekly_PST_sales_1.groupby(['IMDB_Title_Code',
                                                 'Item_Title_WW',
                                                 'Studio',
                                                 'Street_Date',
                                                 'Theatrical_Release_Date',
                                                 'Week']).agg({'Revenue':'sum',
                                                               'Units':'sum'}).reset_index()
# combining EST,iVod,cVOD Revenue/Units to EST Revenue/Units
Weekly_EST_sales_1 = Weekly_EST_sales_1.groupby(['IMDB_Title_Code',
                                                 'Item_Title_WW',
                                                 'Studio',
                                                 'Street_Date',
                                                 'Theatrical_Release_Date',
                                                 'Week']).agg({'Revenue':'sum',
                                                               'Units':'sum'}).reset_index()

# updating list of all IMDB_Title_Codes & their Theatrical, EST & PST Release Dates with last week number
all_titles['EST_Week_Ends'] = np.NaN
all_titles['PST_Week_Ends'] = np.NaN
all_titles['FB_Week_Start'] = np.NaN
all_titles['FB_Week_Ends'] = np.NaN
for i in all_titles['IMDB_Title_Code'].unique() :
    if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Week_Start']) != True :
        all_titles.loc[all_titles['IMDB_Title_Code']==i, 'EST_Week_Ends'] = max(Weekly_EST_sales_1.loc[Weekly_EST_sales_1['IMDB_Title_Code'] == i, 'Week'].dropna())
    if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'PST_Week_Start']) != True :
        all_titles.loc[all_titles['IMDB_Title_Code']==i, 'PST_Week_Ends'] = max(Weekly_PST_sales_1.loc[Weekly_PST_sales_1['IMDB_Title_Code'] == i, 'Week'].dropna())
    all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'FB_Week_Start'] = min(gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Week'].dropna())
    all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'FB_Week_Ends'] = max(gp_data.loc[gp_data['IMDB_Title_Code'] == i, 'Week'].dropna())
all_titles['EST_Week_Ends'] = pd.to_numeric(all_titles['EST_Week_Ends'])
del i

# creating the master_AD
# creating a dataframe of IMDB Title Codes and Week ranges for each IMDB Title Codes
unique_week = pd.DataFrame({'IMDB_Title_Code' : [],
                            'Week' : []})
for i in all_titles['IMDB_Title_Code'].unique() :
    unique_week = unique_week.append(pd.DataFrame({'IMDB_Title_Code': [i]*int(np.nanmax(all_titles.loc[all_titles['IMDB_Title_Code']==i, ['FB_Week_Ends', 'EST_Week_Ends', 'PST_Week_Ends']].values)+1),
                                                   'Week': np.arange(0, int(np.nanmax(all_titles.loc[all_titles['IMDB_Title_Code']==i, ['FB_Week_Ends', 'EST_Week_Ends', 'PST_Week_Ends']]))+1)}))
del i
# # merging BO Revenue for weeks present
master_AD = pd.merge(left = unique_week,
                     right = gp_data[[('IMDB_Title_Code', ''),
                                      ('Week', ''),
                                      ('Amt_Spent', 'sum'),
                                      ('Impressions', 'sum'),
                                      ('Clicks', 'sum'),
                                      ('Reach', 'sum'),
                                      ('Engagement', 'sum'),
                                      ('Likes', 'sum'),
                                      ('Comments', 'sum'),
                                      ('Shares', 'sum')]],
                     how='left',
                     left_on = ['IMDB_Title_Code', 'Week'],
                     right_on = ['IMDB_Title_Code', 'Week'],
                     sort = True,
                     copy = False)
# merging EST Revenue for weeks present
master_AD = pd.merge(left = master_AD,
                     right = Weekly_EST_sales_1[['IMDB_Title_Code',
                                                 'Week',
                                                 'Revenue']],
                     how='left',
                     left_on = ['IMDB_Title_Code', 'Week'],
                     right_on = ['IMDB_Title_Code', 'Week'],
                     sort = True,
                     copy = False)
# merging PST Revenue for weeks present
master_AD = pd.merge(left = master_AD,
                     right = Weekly_PST_sales_1[['IMDB_Title_Code',
                                                 'Week',
                                                 'Revenue']],
                     how='left',
                     left_on = ['IMDB_Title_Code', 'Week'],
                     right_on = ['IMDB_Title_Code', 'Week'],
                     sort = True,
                     copy = False)
del unique_week
# selecting columns that are required
master_AD = master_AD[['IMDB_Title_Code',
                       'Week',
                       ('Amt_Spent', 'sum'),
                       ('Impressions', 'sum'),
                       ('Clicks', 'sum'),
                       ('Reach', 'sum'),
                       ('Engagement', 'sum'),
                       ('Likes', 'sum'),
                       ('Comments', 'sum'),
                       ('Shares', 'sum'),
                       'Revenue_x',
                       'Revenue_y']]
# renaming columns for column name consistency across all files
master_AD.rename(columns = {('Amt_Spent', 'sum') : 'Campaign_Amount_Spend',
                            ('Impressions', 'sum') : 'Campaign_Impressions',
                            ('Clicks', 'sum') : 'Campaign_Clicks',
                            ('Reach', 'sum') : 'Campaign_Reach',
                            ('Engagement', 'sum') : 'Campaign_Engagement',
                            ('Likes', 'sum') : 'Campaign_Likes',
                            ('Comments', 'sum') : 'Campaign_Comments',
                            ('Shares', 'sum') : 'Campaign_Shares',
                            'Revenue_x' : 'EST_Revenue',
                            'Revenue_y' : 'PST_Revenue'},
                 inplace = True)
master_AD['HE_Revenue'] = master_AD.fillna(0)['EST_Revenue'] + master_AD.fillna(0)['PST_Revenue']

master_AD.to_excel(excel_writer = sharepoint_path+r"WB Theatrical - General\02. Data\Tier 2 Data\Cleaned\weekly_HE_campaign_revenue1.xlsx",
                   sheet_name='Sheet1',
                   index=False)

# exporting master_AD
master_AD.to_excel(excel_writer = r"C:\Users\v-sanysa\Desktop\weekly_HE_campaign_revenue.xlsx",
                   sheet_name='Sheet1',
                   index=False)

print("Program Commplete")
print("Time Elapsed: " + str(pd.datetime.now()-start_time))
