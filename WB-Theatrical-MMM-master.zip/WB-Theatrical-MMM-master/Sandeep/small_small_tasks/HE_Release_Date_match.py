# @author: Sandeep

# importing modules
import numpy as np
import pandas as pd

# importing datasets
Comp_Release_Schedule = pd.read_csv(r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Comp_Release_Schedule_v3.1.csv",
                                    sep=',',
                                    encoding='latin-1')
HE_Sales = pd.read_csv(r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\HE_Sales_v1.0.csv",
                          sep=',',
                          encoding='latin-1')
Comp_Spending = pd.read_csv(r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Comp_Spending_v3.csv",
                                    sep=',',
                                    encoding='latin-1')
jays_file = pd.read_excel(r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Latest\Data from Jay\Theatrical Window - Data Validation Report_v1.0.xlsx",
                          sheet_name="Titles - received from WB",
                          header=4)
jays_file.drop(jays_file.columns[0], axis=1, inplace=True)
title_maps = pd.read_csv(filepath_or_buffer=r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Final_Mapping_Data_v4.csv",
                         sep = ',',
                         encoding = 'latin-1')

# correcting date formats
Comp_Release_Schedule['Theatrical_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['Theatrical_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['EST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['EST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['VOD_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['VOD_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Rental_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Rental_Release'], infer_datetime_format=True, errors="coerce")
HE_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=HE_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=HE_Sales['Blu-ray_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['DVD_Street_Date'] = pd.to_datetime(arg=HE_Sales['DVD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['EST_Street_Date'] = pd.to_datetime(arg=HE_Sales['EST_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['iVOD_Street_Date'] = pd.to_datetime(arg=HE_Sales['iVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['cVOD_Street_Date'] = pd.to_datetime(arg=HE_Sales['cVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
Comp_Spending['Street_Date'] = pd.to_datetime(arg=Comp_Spending['Street_Date'], infer_datetime_format=True, errors="coerce")
jays_file['Street'] = pd.to_datetime(arg=jays_file['Street'], infer_datetime_format=True, errors="coerce")

# preparing input files
Comp_Release_Schedule = Comp_Release_Schedule[['IMDB_Title_ID',         # selecting columns that are required
                                               'Theatrical_Release',
                                               'PST_Release',
                                               'EST_Release',
                                               'VOD_Release',
                                               'PST_Rental_Release']]
Comp_Release_Schedule.dropna(subset=['IMDB_Title_ID'], inplace=True) # dropping rows with missing IMDB_Title_ID
HE_Sales = HE_Sales[['IMDB_Title_Code',             # selecting columns that are required
                     'Theatrical_Release_Date',
                     'Blu-ray_Street_Date',
                     'DVD_Street_Date',
                     'EST_Street_Date',
                     'iVOD_Street_Date',
                     'cVOD_Street_Date']]
# deleting a few entries from Comp Spending data
Comp_Spending.drop(index=Comp_Spending.loc[(Comp_Spending['IMDB_Title_Code']=='tt0762125') & (Comp_Spending['Studio']=='DISNEY'),:].index,
                      axis=0, # as per IMDB, Title Code: 'tt0762125' is not DISNEY's production
                      inplace=True)
Comp_Spending.drop(index=Comp_Spending.loc[(Comp_Spending['IMDB_Title_Code']=='tt0765429') & (Comp_Spending['Street_Date']==pd.Timestamp(year=2008, month=3, day=18)),:].index,
                      axis=0, # deleting duplicate title code with street date later than the other than
                      inplace=True)
Comp_Spending = Comp_Spending[['IMDB_Title_Code',   # selecting columns that are required
                               'Street_Date']]
jays_file.dropna(subset=['IMDB Title Code'], inplace=True) # dropping rows with missing IMDB_Title_ID

# calculating Home Entertainment Street Dates = min(PST(Blu-ray, DVD, Rental), EST(EST, VOD(iVOD, cVOD)))
Comp_Release_Schedule['HE_Street_Date'] = Comp_Release_Schedule[['PST_Release', 'EST_Release', 'VOD_Release', 'PST_Rental_Release']].min(axis=1)
HE_Sales['HE_Street_Date'] = HE_Sales[['Blu-ray_Street_Date', 'DVD_Street_Date', 'EST_Street_Date', 'iVOD_Street_Date', 'cVOD_Street_Date']].min(axis=1)

# preparing master dataset for comparison of HE release dates
all_HE_SD = pd.merge(left = Comp_Release_Schedule,
                     right = HE_Sales,
                     how='outer',
                     left_on = ['IMDB_Title_ID'],
                     right_on = ['IMDB_Title_Code'],
                     sort = True,
                     copy = False)
all_HE_SD.rename(columns={'Theatrical_Release' : 'CRS_TTH_Release_Date',
                          'Theatrical_Release_Date' : 'HES_TTH_Release_Date',
                          'HE_Street_Date_x' : 'CRS_HE_Street_Date',
                          'HE_Street_Date_y' : 'HES_HE_Street_Date'},
                 inplace=True)
for i in all_HE_SD.index : # creating one column containing all IMDB_Title_Codes
    all_HE_SD.loc[i, 'IMDB_Title_Code'] = pd.Series([all_HE_SD.loc[i, 'IMDB_Title_Code'],
                                                     all_HE_SD.loc[i, 'IMDB_Title_ID']])[~pd.Series([all_HE_SD.loc[i, 'IMDB_Title_Code'],
                                                                                                     all_HE_SD.loc[i, 'IMDB_Title_ID']]).isnull()].unique()
del i # removing temporary objects to free bandwidth
all_HE_SD = pd.merge(left = all_HE_SD[['IMDB_Title_Code', 'CRS_TTH_Release_Date', 'CRS_HE_Street_Date', 'HES_TTH_Release_Date', 'HES_HE_Street_Date']],
                     right = Comp_Spending,
                     how='outer',
                     left_on = ['IMDB_Title_Code'],
                     right_on = ['IMDB_Title_Code'],
                     sort = True,
                     copy = False)
all_HE_SD.rename(columns={'Street_Date' : 'Comp_HE_Street_Date'},
                 inplace=True)
all_HE_SD = pd.merge(left = all_HE_SD,
                     right = jays_file[['IMDB Title Code', 'Street']],
                     how='outer',
                     left_on = ['IMDB_Title_Code'],
                     right_on = ['IMDB Title Code'],
                     sort = True,
                     copy = False)
for i in all_HE_SD.index : # creating one column containing all IMDB_Title_Codes
    all_HE_SD.loc[i, 'IMDB_Title_Code'] = pd.Series([all_HE_SD.loc[i, 'IMDB_Title_Code'],
                                                     all_HE_SD.loc[i, 'IMDB Title Code']])[~pd.Series([all_HE_SD.loc[i, 'IMDB_Title_Code'],
                                                                                                     all_HE_SD.loc[i, 'IMDB Title Code']]).isnull()].unique()
del i # removing temporary objects to free bandwidth
all_HE_SD = all_HE_SD[['IMDB_Title_Code',
                       'CRS_TTH_Release_Date',
                       'CRS_HE_Street_Date',
                       'HES_TTH_Release_Date',
                       'HES_HE_Street_Date',
                       'Comp_HE_Street_Date',
                       'Street']]
all_HE_SD.rename(columns={'Street' : 'Jays_HE_Street_Date'},
                 inplace=True)

all_HE_SD['CS_CRS'] = np.NaN
all_HE_SD['CS_HS'] = np.NaN
all_HE_SD['CS_Jay'] = np.NaN
all_HE_SD['CRS_HS'] = np.NaN
all_HE_SD['CRS_Jay'] = np.NaN
all_HE_SD['HS_Jay'] = np.NaN

for i in all_HE_SD.index :
    if (pd.isnull(all_HE_SD.loc[i,'Comp_HE_Street_Date'])!=True) & (pd.isnull(all_HE_SD.loc[i,'CRS_HE_Street_Date'])!=True) :
        if all_HE_SD.loc[i,'Comp_HE_Street_Date']==all_HE_SD.loc[i,'CRS_HE_Street_Date'] :
            all_HE_SD['CS_CRS'] = 'Match'
        else :
            all_HE_SD['CS_CRS'] = 'Mismatch'
    else :
        all_HE_SD['CS_CRS'] = np.NaN

    if (pd.isnull(all_HE_SD.loc[i,'Comp_HE_Street_Date'])!=True) & (pd.isnull(all_HE_SD.loc[i,'HES_HE_Street_Date'])!=True) :
        if all_HE_SD.loc[i,'Comp_HE_Street_Date']==all_HE_SD.loc[i,'HES_HE_Street_Date'] :
            all_HE_SD['CS_HS'] = 'Match'
        else :
            all_HE_SD['CS_HS'] = 'Mismatch'
    else :
        all_HE_SD['CS_HS'] = np.NaN

    if (pd.isnull(all_HE_SD.loc[i,'Comp_HE_Street_Date'])!=True) & (pd.isnull(all_HE_SD.loc[i,'Jays_HE_Street_Date'])!=True) :
        if all_HE_SD.loc[i,'Comp_HE_Street_Date']==all_HE_SD.loc[i,'Jays_HE_Street_Date'] :
            all_HE_SD['CS_Jay'] = 'Match'
        else :
            all_HE_SD['CS_Jay'] = 'Mismatch'
    else :
        all_HE_SD['CS_Jay'] = np.NaN

    if (pd.isnull(all_HE_SD.loc[i,'CRS_HE_Street_Date'])!=True) & (pd.isnull(all_HE_SD.loc[i,'HES_HE_Street_Date'])!=True) :
        if all_HE_SD.loc[i,'CRS_HE_Street_Date']==all_HE_SD.loc[i,'HES_HE_Street_Date'] :
            all_HE_SD['CRS_HS'] = 'Match'
        else :
            all_HE_SD['CRS_HS'] = 'Mismatch'
    else :
        all_HE_SD['CRS_HS'] = np.NaN

    if (pd.isnull(all_HE_SD.loc[i,'CRS_HE_Street_Date'])!=True) & (pd.isnull(all_HE_SD.loc[i,'Jays_HE_Street_Date'])!=True) :
        if all_HE_SD.loc[i,'CRS_HE_Street_Date']==all_HE_SD.loc[i,'Jays_HE_Street_Date'] :
            all_HE_SD['CRS_Jay'] = 'Match'
        else :
            all_HE_SD['CRS_Jay'] = 'Mismatch'
    else :
        all_HE_SD['CRS_Jay'] = np.NaN

    if (pd.isnull(all_HE_SD.loc[i,'HES_HE_Street_Date'])!=True) & (pd.isnull(all_HE_SD.loc[i,'Jays_HE_Street_Date'])!=True) :
        if all_HE_SD.loc[i,'HES_HE_Street_Date']==all_HE_SD.loc[i,'Jays_HE_Street_Date'] :
            all_HE_SD['HS_Jay'] = 'Match'
        else :
            all_HE_SD['HS_Jay'] = 'Mismatch'
    else :
        all_HE_SD['HS_Jay'] = np.NaN


# exporting dataset
all_HE_SD.to_excel(excel_writer=r"C:\Users\v-sanysa\Desktop\all_HE_SD_summary1.xlsx",
                   sheet_name='Sheet1',
                   index=False)
