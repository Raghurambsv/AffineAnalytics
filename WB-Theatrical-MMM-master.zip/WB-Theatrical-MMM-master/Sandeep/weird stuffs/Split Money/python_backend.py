import numpy as np
import pandas as pd

def members_list():
    base_data = pd.read_excel(
        io="/home/sandeepsanyal/PycharmProjects/WB-Theatrical-MMM/Sandeep/weird stuffs/Split Money/backend data.xlsx",
        sheet_name="Sheet1"
    )
    return base_data['Name'].unique()

def split_money(total_bill, paid_by):
    base_data = pd.read_excel(
        io="/home/sandeepsanyal/PycharmProjects/WB-Theatrical-MMM/Sandeep/weird stuffs/Split Money/backend data.xlsx",
        sheet_name="Sheet1"
    )
    base_data['Drinking Habit'] =base_data['Drinking Habit'] + 1
    members = len(base_data['Name'].unique())
    base_data['Share'] = round((total_bill / base_data['Drinking Habit'].sum())*base_data['Drinking Habit'],2)
    base_data['Drinking Habit'] = base_data['Drinking Habit'] - 1
    base_data = base_data[base_data.Name != paid_by]

    return base_data[['Name', 'Team', 'Status', 'Drinking Habit', 'Share']]
