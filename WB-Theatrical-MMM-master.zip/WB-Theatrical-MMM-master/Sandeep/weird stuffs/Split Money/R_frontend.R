library(reticulate)
library(shiny)
library(DT)

source_python('/home/sandeepsanyal/PycharmProjects/WB-Theatrical-MMM/Sandeep/weird stuffs/Split Money/python_backend.py')

ui <- fluidPage(
  titlePanel(
    h1("Warner Bros. Team outing Dues",
       align = "center"
    ),
    windowTitle = "Split Money"
  ),
  # Sidebar layout with input and output definitions ----
  sidebarLayout(
    # Sidebar panel for inputs ----
    sidebarPanel(
      numericInput("input1", "Money:", 10000),
      selectInput(
        "select",
        label = h4("Paid by"),
        choices = members_list()
      ),
      actionButton('insertBtn', 'Calculate')
    ),
    # Main panel for displaying outputs ----
    mainPanel(

      DT::dataTableOutput("table")

    )
  )
)


server <- function(input, output) {

  output$table <- DT::renderDataTable({
    split_money(total_bill=input$input1,
                paid_by=input$select)
  })


}




shinyApp(ui, server)