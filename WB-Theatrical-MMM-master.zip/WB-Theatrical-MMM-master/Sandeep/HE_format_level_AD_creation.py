# final function imports
from tqdm import tqdm
import datetime
import sys
sys.path.insert(0, r"/home/sandeepsanyal/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/02. Base AD Creation")
from HE_format_level_Base_AD import *
from HE_format_level_Modeling_AD import *

# creating Master AD
import pandas as pd
with pd.ExcelWriter(
        path=r"/home/sandeepsanyal/Documents/WB Theatrical/WB_Base AD v1.0.xlsx",
        mode='w',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    pd.read_excel(io=r"/home/sandeepsanyal/Documents/WB Theatrical/Title List.xlsx",
                  sheet_name="Phase 2B 88 titles",
                  na_values=['#NA','#N/A','',' ','na','NA']).to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='Phase 2B 88 titles',
        engine='openpyxl')
with pd.ExcelWriter(
        path=r"/home/sandeepsanyal/Documents/WB Theatrical/WB_Modeling AD v1.0.xlsx",
        mode='w',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    pd.read_excel(io=r"/home/sandeepsanyal/Documents/WB Theatrical/Title List.xlsx",
                  sheet_name="Phase 2B 88 titles",
                  na_values=['#NA','#N/A','',' ','na','NA']).to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='Phase 2B 88 titles',
        engine='openpyxl')

for med in tqdm(['EST', 'PST', 'iVOD', 'VOD']):
    # creating Base AD
    # he_base_ad_creation(media=med,
    #                     sharepoint_path=r"/home/sandeepsanyal/Documents/WB Theatrical/",
    #                     export_path_user=r"/home/sandeepsanyal/Documents/WB Theatrical/WB_Base AD v1.0.xlsx")
    # print(med + ' Base AD' + ' done')

    for snap in [2, 0, -3]:
        # creating Modeling AD
        he_modeling_ad_creation(media=med,
                                snapshot=snap,
                                sharepoint_path=r"/home/sandeepsanyal/Documents/WB Theatrical/",
                                export_path_user=r"/home/sandeepsanyal/Documents/WB Theatrical/WB_Modeling AD v1.0.xlsx")
        print(med+'_TH'+ ['+' + str(snap-1) if len(str(snap-1))==1 else str(snap-1)][0] +' week(s)' + ' done')
