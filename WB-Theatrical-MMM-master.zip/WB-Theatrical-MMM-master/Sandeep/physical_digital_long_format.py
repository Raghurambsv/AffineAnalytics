# importing modules
import numpy as np
import pandas as pd

# File Name: Weekly Sales - 20190129.xlsx
# Sheet Name: Physical Titles 26 Weeks-v8
# physical_sales.csv file was created from the above sheet first and then imported to python for transformation

# importing dataset
physical_sales = pd.read_csv(r"/home/wb/WB-data/Intermediate Output/physical_sales.csv", header=[0,1,2,3])

melted_df = physical_sales.melt(id_vars=physical_sales.columns.tolist()[0:5])
melted_df.drop('variable_3', inplace=True, axis=1)
melted_df.columns = ['IMDB_Title_Code',
                     'Item_Title_WW',
                     'Studio',
                     'Street_Date',
                     'Theatrical_Release_Date',
                     'Amt_Qty',
                     'Media_Type',
                     'Week',
                     'Value']
melted_df['Week'] = melted_df['Week'].str.replace(pat = "Week ",
                                                  repl = "",
                                                  case = False)
melted_df = melted_df.pivot_table(index=['IMDB_Title_Code',
                                         'Item_Title_WW',
                                         'Studio',
                                         'Street_Date',
                                         'Theatrical_Release_Date',
                                         'Media_Type',
                                         'Week'],
                                  columns='Amt_Qty',
                                  values='Value')
melted_df.reset_index(inplace=True)

# correcting data structure
melted_df['Street_Date'] = pd.to_datetime(arg=melted_df['Street_Date'], infer_datetime_format=True, errors="coerce")
melted_df['Theatrical_Release_Date'] = pd.to_datetime(arg=melted_df['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
melted_df['Week'] = melted_df['Week'].astype(str).astype(int)

# Fill-up missing weeks between Week 0 and Week  26 with 0.
unique_movie_media = melted_df[['IMDB_Title_Code', 'Item_Title_WW', 'Studio', 'Street_Date','Theatrical_Release_Date', 'Media_Type']]
unique_movie_media.drop_duplicates(inplace=True)
unique_movie_media['cross_join']=1
unique_week = pd.DataFrame({'Week': np.arange(0,27)})
unique_week['cross_join']=1

unique_movie_media_week = pd.merge(left=unique_movie_media,
                                   right=unique_week,
                                   on='cross_join')
melted_df = pd.merge(left=unique_movie_media_week,
                     right=melted_df,
                     on=['IMDB_Title_Code', 'Item_Title_WW', 'Studio', 'Street_Date','Theatrical_Release_Date', 'Media_Type', 'Week'],
                     how='left')
melted_df = melted_df[['IMDB_Title_Code',
                     'Item_Title_WW',
                     'Studio',
                     'Street_Date',
                     'Theatrical_Release_Date',
                     'Media_Type',
                     'Week',
                     '228-Industry Sold Amt TY',
                     '252-Industry Sold Qty TY']]
melted_df.columns = ['IMDB_Title_Code',
                     'Item_Title_WW',
                     'Studio',
                     'Street_Date',
                     'Theatrical_Release_Date',
                     'Media_Type',
                     'Week',
                     'Revenue',
                     'Units']

# export to csv file
melted_df.to_csv(r"/home/wb/WB-data/Base Data/Physical_Weekly_Sales_v3.csv", index=False, na_rep='')

# removing objects
del physical_sales, melted_df, unique_movie_media, unique_week, unique_movie_media_week


# File Name: Weekly Sales - 20190129.xlsx
# Sheet Name: Digital Titles 26 Weeks-v3
# digital_sales.csv file was created from the above sheet first and then imported to python for transformation

digital_sales = pd.read_csv(r"/home/wb/WB-data/Intermediate Output/digital_sales.csv", header=[0,1,2,3])

melted_df = digital_sales.melt(id_vars=digital_sales.columns.tolist()[0:5])
melted_df.drop('variable_3', inplace=True, axis=1)
melted_df.columns=['IMDB_Title_Code',
                   'Item_Title_WW',
                   'Studio',
                   'Street_Date',
                   'Theatrical_Release_Date',
                   'Amt_Qty',
                   'Media_Type',
                   'Week',
                   'Value']
melted_df['Week'] = melted_df['Week'].str.replace(pat = "Week ",
                                                  repl = "",
                                                  case = False)
melted_df = melted_df.pivot_table(index=['IMDB_Title_Code',
                                         'Item_Title_WW',
                                         'Studio',
                                         'Street_Date',
                                         'Theatrical_Release_Date',
                                         'Media_Type',
                                         'Week'],
                                  columns='Amt_Qty',
                                  values='Value')
melted_df.reset_index(inplace=True)

# correcting data structure
melted_df['Street_Date'] = pd.to_datetime(arg=melted_df['Street_Date'], infer_datetime_format=True, errors="coerce")
melted_df['Theatrical_Release_Date'] = pd.to_datetime(arg=melted_df['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
melted_df['Week'] = melted_df['Week'].astype(str).astype(int)

# Fill-up missing weeks between Week 0 and Week  26 with 0.
unique_movie_media = melted_df[['IMDB_Title_Code', 'Item_Title_WW', 'Studio', 'Street_Date','Theatrical_Release_Date', 'Media_Type']]
unique_movie_media.drop_duplicates(inplace=True)
unique_movie_media['cross_join']=1
unique_week = pd.DataFrame({'Week': np.arange(0,27)})
unique_week['cross_join']=1

unique_movie_media_week = pd.merge(left=unique_movie_media,
                                   right=unique_week,
                                   on='cross_join')
melted_df = pd.merge(left=unique_movie_media_week,
                     right=melted_df,
                     on=['IMDB_Title_Code', 'Item_Title_WW', 'Studio', 'Street_Date','Theatrical_Release_Date', 'Media_Type', 'Week'],
                     how='left')
melted_df = melted_df[['IMDB_Title_Code',
                     'Item_Title_WW',
                     'Studio',
                     'Street_Date',
                     'Theatrical_Release_Date',
                     'Media_Type',
                     'Week',
                     '228-Industry Sold Amt TY',
                     '252-Industry Sold Qty TY']]
melted_df.columns = ['IMDB_Title_Code',
                     'Item_Title_WW',
                     'Studio',
                     'Street_Date',
                     'Theatrical_Release_Date',
                     'Media_Type',
                     'Week',
                     'Revenue',
                     'Units']

# export to csv file
melted_df.to_csv(r"/home/wb/WB-data/Base Data/Digital_Weekly_Sales_v3.csv", index=False)

# removing objects
del digital_sales, melted_df, unique_movie_media, unique_week, unique_movie_media_week

