competition_weeks=13
competitor_effect_weeks=5

# importing modules
import numpy as np
import pandas as pd
import math
import sys
sys.path.insert(0, root_folder+ r"\WB-Theatrical-MMM\Phase 2 Codes\06. Miscellaneous")
import date_manipulations
from tqdm import tqdm
from datetime import timedelta

# importing base titles
gs_data = pd.read_excel(io=GS_data_path,
                        sheet_name="GS Data",
                        na_values=['#NA','#N/A','',' ','na','NA'])
gs_data.dropna(subset=['IMDB Title Name'], inplace=True)
all_titles = pd.concat([pd.read_excel(io=sharepoint_path+"/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Title List.xlsx",
                                      sheet_name="WB Titles",
                                      na_values=['#NA','#N/A','',' ','na','NA'])[['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', ''+media+' Release Date', 'Studio']],
                        pd.read_excel(io=sharepoint_path+"/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Title List.xlsx",
                                      sheet_name="NonWB Titles",
                                      na_values=['#NA', '#N/A', '', ' ', 'na', 'NA'])[['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', ''+media+' Release Date', 'Studio']]],
                       axis=0)
all_titles.drop_duplicates(inplace=True)
all_titles = all_titles.loc[all_titles['IMDB Title Code'].isin(gs_data['IMDB Title Code'].unique().tolist()), :].reset_index(drop=True)
all_titles.dropna(subset = ['Theatrical Release Date', ''+media+' Release Date'], inplace=True)
all_titles.sort_values(by=''+media+' Release Date',
                       axis=0,
                       ascending=False,
                       inplace=True)
all_titles.reset_index(drop=True, inplace=True)

WB_titles = all_titles.loc[all_titles['Studio']=='NonWB',:].reset_index(drop=True)

# creating a dataframe to contain final competitor data index
WB_titles['key'] = 0
Weeks = pd.DataFrame({'Week Number':range(0,competition_weeks+1),})
Weeks['key'] = 0
WB_titles_competitor_effect = pd.merge(
    left=WB_titles[['key','IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', ''+media+' Release Date']],
    right=Weeks,
    how='outer',
    left_on='key',
    right_on='key')
del Weeks, WB_titles['key'], WB_titles_competitor_effect['key']
WB_titles_competitor_effect = date_manipulations.last_sunday(df=WB_titles_competitor_effect,
                                                             date_column_name='Theatrical Release Date',
                                                             sunday_date_column_name='Last Sunday Date')
WB_titles_competitor_effect = date_manipulations.last_sunday(df=WB_titles_competitor_effect,
                                                             date_column_name=''+media+' Release Date',
                                                             sunday_date_column_name='Last '+media+' Sunday Date')
for index in WB_titles_competitor_effect.index:
    WB_titles_competitor_effect.loc[index,'Week Start Date'] = WB_titles_competitor_effect.loc[index,'Last '+media+' Sunday Date']+timedelta(weeks=int(WB_titles_competitor_effect.loc[index,'Week Number']))
del index
WB_titles_competitor_effect['Competitor Index']=np.NaN

# creating an overview of competitor title releases for WB titles
master_competitor_AD = pd.DataFrame()
for WB_title in tqdm(WB_titles['IMDB Title Code'].tolist()):
    small_competitor_AD = WB_titles_competitor_effect.loc[WB_titles_competitor_effect['IMDB Title Code'] == WB_title, ['IMDB Title Code', 'IMDB Title Name', 'Theatrical Release Date', ''+media+' Release Date', 'Week Number', "Week Start Date"]]
    temp = small_competitor_AD.copy()
    small_competitor_AD['Competitors'] = np.NaN
    for title in list(set(all_titles['IMDB Title Code'].tolist()).union(set([WB_title]))-set(all_titles['IMDB Title Code'].tolist()).intersection(set([WB_title]))):
        if np.floor(abs((all_titles.loc[all_titles['IMDB Title Code']==title, ''+media+' Release Date'].reset_index(drop=True)[0] - WB_titles.loc[WB_titles['IMDB Title Code']==WB_title, ''+media+' Release Date'].reset_index(drop=True)[0]) / pd.offsets.Day(1)) / 7) <= competitor_effect_weeks:
            temp2 = pd.DataFrame({'IMDB Title Code' : [WB_title],
                                  'Competitor '+media+' Release Date' : [str(all_titles.loc[all_titles['IMDB Title Code']==title, ''+media+' Release Date'].reset_index(drop=True)[0])[:10]]})
            temp2['Competitor '+media+' Release Date'] = pd.to_datetime(arg=temp2['Competitor '+media+' Release Date'], format="%Y-%m-%d")
            temp2 = date_manipulations.last_sunday(df=temp2,
                                                   date_column_name='Competitor '+media+' Release Date',
                                                   sunday_date_column_name='Competitor '+media+' Release Sunday Date')
            temp2 = pd.merge(left=temp,
                             right=temp2,
                             how='left',
                             left_on='IMDB Title Code',
                             right_on='IMDB Title Code')
            for i in temp2.index:
                if (((temp2.loc[i,'Competitor '+media+' Release Sunday Date'] - temp2.loc[i,'Week Start Date']) / pd.offsets.Day(-1)) / 7 <= 5) & (((temp2.loc[i,'Competitor '+media+' Release Sunday Date'] - temp2.loc[i,'Week Start Date']) / pd.offsets.Day(-1)) / 7 >= 0):
                    if pd.isnull(small_competitor_AD.loc[(small_competitor_AD['IMDB Title Code']==WB_title) &
                                                         (small_competitor_AD['Week Number']==temp2.loc[i,'Week Number']),'Competitors'].reset_index(drop=True)[0]):
                        small_competitor_AD.loc[(small_competitor_AD['IMDB Title Code']==WB_title) &
                                                (small_competitor_AD['Week Number']==temp2.loc[i,'Week Number']), 'Competitors'] = title
                    else:
                        small_competitor_AD.loc[(small_competitor_AD['IMDB Title Code'] == WB_title) &
                                                (small_competitor_AD['Week Number'] == temp2.loc[i, 'Week Number']), 'Competitors'] = small_competitor_AD.loc[(small_competitor_AD['IMDB Title Code'] == WB_title) &
                                                                                                                                                              (small_competitor_AD['Week Number'] == temp2.loc[i, 'Week Number']), 'Competitors']+','+title
            try:
                del i
            except:
                None
        try:
            del temp2
        except:
            None
    del temp, title
    master_competitor_AD = pd.concat([master_competitor_AD,small_competitor_AD],
                                     axis=0)
    del small_competitor_AD
del WB_title

# exporting master_competitor_AD
# with pd.ExcelWriter(
#         path=r"C:\Users\sande\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\Non WB_Competitor Effect_EST_13weeks.xlsx",
#         mode='w',
#         date_format='YYYY-MM-DD',
#         datetime_format='DD-MMM-YYYY') as writer:
#     master_competitor_AD.to_excel(
#         excel_writer=writer,
#         index=False,
#         sheet_name='Competitor View',
#         engine='openpyxl')
with pd.ExcelWriter(
            path=sharepoint_path+r"/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/"+media+" Competitor Effect_v1_Nonwb.xlsx",
            engine='openpyxl',
            mode='w',
            date_format='YYYY-MM-DD',
            datetime_format='DD-MMM-YYYY') as writer:
    master_competitor_AD.to_excel(
            excel_writer=writer,
            index=False,
            sheet_name='Competitor View'
            )
# importing master_competitor_AD
# master_competitor_AD = pd.read_excel(io=r"C:\Users\sande\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\Competitor Effect_EST_top3.xlsx",
#                         sheet_name="Competitor View",
#                         na_values=['#NA','#N/A','',' ','na','NA'])

# creating a relevant competitor map for WB titles
competitor_map = pd.DataFrame({'IMDB Title Code': [],
                               'IMDB Title Name': [],
                               'Competitor Title Code': []})
for title in tqdm(master_competitor_AD['IMDB Title Code'].unique().tolist()):
    temp = master_competitor_AD.loc[master_competitor_AD['IMDB Title Code'] == title, ['IMDB Title Code', 'IMDB Title Name', 'Competitors']]
    temp2 = temp.groupby(['IMDB Title Code', 'IMDB Title Name'], as_index=False).agg({'Competitors':lambda x : str(list(set(x)))})
    temp2['Competitors'] = temp2['Competitors'].str.replace('[',"").str.replace("]","").str.replace("'","")
    temp3 = temp2['Competitors'].str.split(",", expand=True)
    del temp
    temp = pd.melt(pd.concat([temp2[['IMDB Title Code', 'IMDB Title Name']],
                              temp3],
                             axis=1),
                   id_vars=['IMDB Title Code', 'IMDB Title Name'])
    del temp2, temp3
    temp = temp.drop('variable',axis=1).rename(columns={'value':'Competitor Title Code'})
    competitor_map = pd.concat([competitor_map,
                                temp],
                               axis=0)
    del temp
del title
competitor_map.reset_index(drop=True, inplace=True)
competitor_map['Competitor Title Code'] = competitor_map['Competitor Title Code'].str.strip()
competitor_map = competitor_map.loc[competitor_map['Competitor Title Code'] != 'nan',:]
competitor_map.drop_duplicates(inplace=True)

# get Relative competitor index
competitor_map['Relative Competitor Index']=np.NaN
for title in tqdm(competitor_map['IMDB Title Code'].unique().tolist()):
    title_gs_data_latest_week = gs_data.loc[(gs_data['IMDB Title Code'] == title) &
                                            (gs_data['Week Number'] <= min((-competitor_effect_weeks - 2), gs_data.loc[gs_data['IMDB Title Code'] == title, 'Week Number'].max())), 'Week Start Date'].reset_index(drop=True)
    try:
        title_gs_data_latest_week = title_gs_data_latest_week[len(title_gs_data_latest_week)-1]
        title_gs_data_oldest_week = gs_data.loc[gs_data['IMDB Title Code'] == title, 'Week Start Date'].min()
        if (title_gs_data_latest_week - (title_gs_data_oldest_week + timedelta(weeks=1))) / pd.offsets.Day(-1) < 13:
            for competitor in competitor_map.loc[competitor_map['IMDB Title Code'] == title, 'Competitor Title Code'].unique().tolist():
                if competitor in gs_data['IMDB Title Code'].unique().tolist():
                    try:
                        competitor_map.loc[(competitor_map['IMDB Title Code'] == title) & (competitor_map['Competitor Title Code'] == competitor), 'Relative Competitor Index'] = \
                        gs_data.loc[(gs_data['IMDB Title Code'] == competitor) &
                                    (gs_data['Week Start Date'] <= title_gs_data_latest_week) &
                                    (gs_data['Week Start Date'] >= title_gs_data_oldest_week), 'Google Search Volume'].mean()
                    except:
                        competitor_map.loc[(competitor_map['IMDB Title Code'] == title) &
                                           (competitor_map[
                                                'Competitor Title Code'] == competitor), 'Relative Competitor Index'] = 0
            try:
                del competitor
            except:
                None
        del title_gs_data_oldest_week
    except:
        del title_gs_data_latest_week
del title
competitor_map.dropna(subset=['Relative Competitor Index'], inplace=True)

# appending WB Title & Competitor titles release dates together
competitor_map = pd.merge(left=competitor_map,
                          right=WB_titles.drop(['IMDB Title Name','Studio'], axis=1),
                          how='left',
                          left_on='IMDB Title Code',
                          right_on='IMDB Title Code')
competitor_map = pd.merge(left=competitor_map,
                          right=all_titles.rename(columns={'Theatrical Release Date': 'Competitor Theatrical Release Date',
                                                           ''+media+' Release Date': 'Competitor '+media+' Release Date',
                                                           'IMDB Title Code': 'Competitor Title Code',
                                                           'IMDB Title Name' : 'Competitor IMDB Title Name'}).drop('Studio', axis=1),
                          how='left',
                          left_on='Competitor Title Code',
                          right_on='Competitor Title Code')
competitor_map.drop_duplicates(inplace=True)
competitor_map = date_manipulations.last_sunday(df=competitor_map,
                                           date_column_name='Theatrical Release Date',
                                           sunday_date_column_name='Theatrical Release Sunday Date')
competitor_map = date_manipulations.last_sunday(df=competitor_map,
                                           date_column_name='Competitor Theatrical Release Date',
                                           sunday_date_column_name='Competitor Theatrical Release Sunday Date')
competitor_map = date_manipulations.last_sunday(df=competitor_map,
                                           date_column_name=''+media+' Release Date',
                                           sunday_date_column_name=''+media+' Release Sunday Date')
competitor_map = date_manipulations.last_sunday(df=competitor_map,
                                           date_column_name='Competitor '+media+' Release Date',
                                           sunday_date_column_name='Competitor '+media+' Release Sunday Date')
competitor_map['Week Number'] = ((competitor_map[''+media+' Release Sunday Date'] - competitor_map['Competitor '+media+' Release Sunday Date']) / pd.offsets.Day(-1)) / 7

# exporting competitor_map
# with pd.ExcelWriter(
#         path=r"C:\Users\sande\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\Non WB_Competitor Effect_ESTEST_13weeks.xlsx",
#         mode='a',
#         date_format='YYYY-MM-DD',
#         datetime_format='DD-MMM-YYYY') as writer:
#     competitor_map.drop([''+media+' Release Sunday Date', 'Competitor '+media+' Release Sunday Date'], axis=1).to_excel(
#         excel_writer=writer,
#         index=False,
#         sheet_name='Competitor Map',
#         engine='openpyxl')
with pd.ExcelWriter(
            path=sharepoint_path+r"/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/"+media+" Competitor Effect_v1_Nonwb.xlsx",
            engine='openpyxl',
            mode='a',
            date_format='YYYY-MM-DD',
            datetime_format='DD-MMM-YYYY') as writer:
    competitor_map.drop([''+media+' Release Sunday Date', 'Competitor '+media+' Release Sunday Date'], axis=1).to_excel(
            excel_writer=writer,
            index=False,
            sheet_name='Competitor Map'
            )
# importing competitor_map
# competitor_map = pd.read_excel(io=r"C:\Users\sande\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\Competitor Effect_EST_top3.xlsx",
#                         sheet_name="Competitor Map",
#                         na_values=['#NA','#N/A','',' ','na','NA'])

# calculating top X competitors
# topn = 3
# competitor_map2 = pd.DataFrame()
# for title in tqdm(master_competitor_AD['IMDB Title Code'].unique().tolist()):
#     try:
#         comp_list = []
#         for week in range(0,competition_weeks+1):
#             temp = pd.DataFrame()
#             for competitor in (master_competitor_AD.loc[(master_competitor_AD['IMDB Title Code'] == title) &
#                                                         (master_competitor_AD['Week Number'] == week), 'Competitors'].tolist())[0].split(","):
#                 temp = pd.concat([temp,
#                                   competitor_map.loc[(competitor_map['IMDB Title Code']==title) &
#                                           (competitor_map['Competitor Title Code']==competitor),['Competitor Title Code', 'Relative Competitor Index']]],
#                                  axis=0)
#             temp.sort_values(by='Relative Competitor Index',
#                                    axis=0,
#                                    ascending=False,
#                                    inplace=True)
#             temp.reset_index(drop=True, inplace=True)
#             temp = temp.loc[range(min(len(temp),topn)),'Competitor Title Code'].tolist()
#             master_competitor_AD.loc[(master_competitor_AD['IMDB Title Code']==title) &
#                                      (master_competitor_AD['Week Number']==week),'Competitors'] = ','.join(temp)
#             comp_list = comp_list+temp
#             del temp
#             comp_list = list(set(comp_list))
#             competitor_map2 = pd.concat([competitor_map2,
#                                          competitor_map.loc[(competitor_map['IMDB Title Code']==title) &
#                                                             (competitor_map['Competitor Title Code'].isin(comp_list)), :].reset_index(drop=True)],
#                                         axis=0).reset_index(drop=True)
#     except:
#         None
# master_competitor_AD.fillna({'Competitors':''}, inplace=True)
# competitor_map = competitor_map2.copy()
# del competitor_map2

# exporting datasets
# with pd.ExcelWriter(
#         path=r"C:\Users\sande\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\Competitor Effect_EST_top3.xlsx",
#         mode='w',
#         date_format='YYYY-MM-DD',
#         datetime_format='DD-MMM-YYYY') as writer:
#     master_competitor_AD.to_excel(
#         excel_writer=writer,
#         index=False,
#         sheet_name='Competitor View',
#         engine='openpyxl')
#     competitor_map[['IMDB Title Code',
#                     'IMDB Title Name',
#                     'EST Release Date',
#                     'Week Number',
#                     'Competitor Title Code',
#                     'Competitor IMDB Title Name',
#                     'Competitor EST Release Date',
#                     'Relative Competitor Index']].to_excel(
#         excel_writer=writer,
#         index=False,
#         sheet_name='Competitor Map',
#         engine='openpyxl')

# overall competitor index
WB_titles_competitor_effect.drop(['Last Sunday Date', 'Last '+media+' Sunday Date', 'Week Start Date'], axis=1, inplace=True)
WB_titles_competitor_effect['Competitor Index'] = np.NaN
for title in tqdm(master_competitor_AD['IMDB Title Code'].unique().tolist()):
    for week in range(0,competition_weeks+1):
        overall_com_index = 0
        try:
            for competitor in master_competitor_AD.loc[(master_competitor_AD['IMDB Title Code'] == title) &
                                                       (master_competitor_AD['Week Number'] == week), 'Competitors'].str.replace('[',"").str.replace("]", "").str.replace("'","").str.split(",").reset_index(drop=True)[0]:
                if competitor in competitor_map.loc[competitor_map['IMDB Title Code']==title, 'Competitor Title Code'].tolist():
                    week_difference = competitor_map.loc[(competitor_map['IMDB Title Code']==title) &
                                                         (competitor_map['Competitor Title Code']==competitor), 'Week Number'].reset_index(drop=True)[0]
                    if week_difference >= 0:
                        overall_com_index = overall_com_index + (competitor_map.loc[(competitor_map['IMDB Title Code']==title) &
                                                                                    (competitor_map['Competitor Title Code']==competitor), 'Relative Competitor Index'].reset_index(drop=True)[0]) * (abs(week_difference)+1)
                    else:
                        overall_com_index = overall_com_index + (competitor_map.loc[(competitor_map['IMDB Title Code'] == title) &
                                                                                    (competitor_map['Competitor Title Code'] == competitor), 'Relative Competitor Index'].reset_index(drop=True)[0]) / (abs(week_difference)+1)
            del competitor
            WB_titles_competitor_effect.loc[(WB_titles_competitor_effect['IMDB Title Code']==title) &
                                            (WB_titles_competitor_effect['Week Number']==week),'Competitor Index'] = overall_com_index
        except:
            None
    del week, overall_com_index
del title
WB_titles_competitor_effect.dropna(subset=['Competitor Index'], inplace=True)

# with pd.ExcelWriter(
#         path=r"C:\Users\sande\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\04. Other Data Elements\Non WB_Competitor Effect_EST_13weeks.xlsx",
#         mode='a',
#         date_format='YYYY-MM-DD',
#         datetime_format='DD-MMM-YYYY') as writer:
#     WB_titles_competitor_effect.to_excel(
#         excel_writer=writer,
#         index=False,
#         sheet_name='Weekly Competitor Effect',
#         engine='openpyxl')

with pd.ExcelWriter(
            path=sharepoint_path+r"/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/"+media+" Competitor Effect_v1_Nonwb.xlsx",
            engine='openpyxl',
            mode='a',
            date_format='YYYY-MM-DD',
            datetime_format='DD-MMM-YYYY') as writer:
    WB_titles_competitor_effect.to_excel(
            excel_writer=writer,
            index=False,
            sheet_name='Weekly Competitor Effect'
            )