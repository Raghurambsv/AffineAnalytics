# calculating Adstock
import pandas as pd
import sys
sys.path.insert(0, r"C:/Users/Sandeep Sanyal/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/03. Feature Engineering")
from AdstockClass import Adstock
data = pd.read_excel(io=r"C:\Users\Sandeep Sanyal\Affine Analytics Pvt Ltd\WB Theatrical - Documents\04. Media Mix Modelling\Refresh 01\Analytical Datasets\Base AD\Base AD_v1.0.xlsx",
                     sheet_name='Sheet1',
                     na_values=['#NA','#N/A','',' ','na','NA'])
instance = Adstock(
    base_dataframe=data,
    dictionary_spends={
        'BO Digital Spend': [0.1, 'Linear'],
        'BO Digital Video Spend': [0.1, 'Linear']
    },
    week_number_colname='TH Week Number',
    revenue_colname='BO Revenue'
)
updated_data = instance.optimise_adstock()

instance = Adstock(
    base_dataframe=data,
    dictionary_spends={
        'EST DIGITAL Spends': [0.1, 'Linear'],
        'EST DIGITAL VIDEO Spends': [0.65, 'Linear'],
        'EST NON-DIGITAL Spends': [0.65, 'Linear'],
        'EST LINEAR CO-OP Spends': [0.65, 'Linear']
    },
    week_number_colname='EST Week Number',
    revenue_colname='EST Revenue'
)
updated_data2 = instance.optimise_adstock()



import numpy as np
import pandas as pd
titles = ["tt0385887", "tt0448115", "tt0451279", "tt0493405", "tt0918940", "tt0974015", "tt1018765", "tt1292566", "tt1355683", "tt1365519", "tt1386697", "tt1390411", "tt1392190", "tt1396484", "tt1413492", "tt1477834", "tt1489889", "tt1517451", "tt1524930", "tt1617661", "tt1638355", "tt1674771", "tt1677720", "tt1856101", "tt1966359", "tt1972591", "tt1981128", "tt2005151", "tt2006295", "tt2058673", "tt2126355", "tt2140479", "tt2199571", "tt2231461", "tt2268016", "tt2309260", "tt2361317", "tt2361509", "tt2381941", "tt2452244", "tt2561572", "tt2568862", "tt2649554", "tt2674426", "tt2704998", "tt2854926", "tt2967224", "tt2975590", "tt3007512", "tt3014284", "tt3065204", "tt3076658", "tt3104988", "tt3183660", "tt3263904", "tt3332064", "tt3369806", "tt3401882", "tt3462710", "tt3513498", "tt3628584", "tt3731562", "tt3741700", "tt3787590", "tt3799694", "tt3864056", "tt4116284", "tt4123430", "tt4139124", "tt4468740", "tt4481514", "tt4624424", "tt4682786", "tt4779682", "tt4786282", "tt4913966", "tt5001718", "tt5013056", "tt5140878", "tt5164214", "tt5606664", "tt5619332", "tt5814060", "tt5822564", "tt5836706", "tt5884052", "tt6182908", "tt6423362", "tt6802308", "tt7286456", "tt7349950", "tt7424200", "tt7905466", "tt7959026", "tt8266310"]
week_number = range(-44, 42)

df = pd.merge(
    left=pd.DataFrame(
        {
            "IMDB Title Code": titles,
            "Key": np.repeat(1, len(titles))
        }
    ),
    right=pd.DataFrame(
        {
            "Week Number": week_number,
            "Key": np.repeat(1, len(week_number))
        }
    ),
    how="outer",
    left_on="Key",
    right_on="Key"
).drop(
    "Key",
    axis=1
)

with pd.ExcelWriter(
            path=r"C:/Users/Sandeep Sanyal/Desktop/temp.xlsx",
            engine='openpyxl',
            mode='w',
            date_format='DD-MMM-YYYY',
            datetime_format='DD-MMM-YYYY'
) as writer:
    scrapped_data.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='Sheet1'
        )


import sys
import pandas as pd
sys.path.insert(0, r"C:\Users\Sandeep Sanyal\PycharmProjects\WB-Theatrical-MMM\Phase 2 Codes\06. Miscellaneous")
import IMDB_scrapper
df = IMDB_scrapper.scrape_movie_info(
        title_list=pd.read_excel(
            io=r"C:\Users\Sandeep Sanyal\Affine Analytics Pvt Ltd\WB Theatrical - Documents\08. PVOD_MMM Integration\04. Analytical Dataset\PVOD_MMM Modeling AD_v2.1.xlsx",
            usecols=["IMDB Title Code", "IMDB Title Name"]
    ).drop_duplicates()["IMDB Title Code"].values.tolist()
)


import numpy as np
import pandas as pd
from time import time
import datetime
import sys
sys.path.insert(0, r"/home/aain0547/PycharmProjects/WB-Theatrical-MMM/Sandeep")
import Adstock_calculation

data = pd.read_excel(
    io=r"/home/aain0547/Downloads/PVOD_MMM Modeling AD_v2.xlsx",
    sheet_name = "Sheet1",
    usecols=["IMDB Title Code", "IMDB Title Name", "PVOD Week Number", "Digital Spend (PVOD)", "Digital Video Spend (PVOD)",   "Non-Digital Spend (PVOD)", "Linear Co-op Spend (PVOD)"]
    )



    for decay in np.arange(0.001, 1, 0.001):
        data = Adstock_calculation.calculate_adstock(
            spend_column=spend,
            decay_rate=decay,
            df=data
        )
        print("{}% complete :: Spend: {} :: Decay: {} :: Time Elapsed: {} ".format(
            round(t + (decay), 3),
            spend,
            round(decay, 3),
            str(datetime.timedelta(seconds=(time() - time_start)))
        ))
    with pd.ExcelWriter(
            path=r"/home/aain0547/Desktop/PVOD Spend Adstocks.xlsx",
            engine='openpyxl',
            mode='w',
            date_format='DD-MMM-YYYY',
            datetime_format='DD-MMM-YYYY'
    ) as writer:
        data.to_excel(
            excel_writer=writer,
            index=False,
            sheet_name='Sheet1'
        )


import numpy as np
import pandas as pd
import sys
sys.path.insert(0, r"C:\Users\Sandeep Sanyal\PycharmProjects\WB-Theatrical-MMM\Phase 2 Codes\06. Miscellaneous")
import IMDB_scrapper
sys.path.insert(0, r"C:\Users\Sandeep Sanyal\PycharmProjects\WB-Theatrical-MMM\Phase 2 Codes\06. Miscellaneous")
import date_manipulations
nrg = pd.read_csv(
    filepath_or_buffer=r"C:\Users\Sandeep Sanyal\Affine Analytics Pvt Ltd\WB Theatrical - Documents\09. KPI Validation\01. Data Harmonization\01. Base Data - As Received\NRG Data\NRGUS2015_01_thru_2019_10.tsv",
    sep="\t"
)

# scrapping title codes for new titles
IMDB_scrapper.scrape_IMDB_Title_Codes(
    sharepoint_path=r"C:/Users/Sandeep Sanyal/Affine Analytics Pvt Ltd",
    titles=nrg['RELEASETITLE'].unique().tolist()
)
# reading IMDB Title Maps
scrapped_imdb_title_codes = pd.read_excel(
    io=r"C:\Users\Sandeep Sanyal\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\intermediate files\IMDB Mapping Data.xlsx",
    sheet_name='scrapped title ids',
    na_values=['#NA', '#N/A', '', ' ', 'na', 'NA'])

nrg['temp'] = nrg['RELEASETITLE'].str.lower()
nrg['temp'] = (nrg['temp'].str.split(pat='(', expand=True))
nrg['Cleaned Movie Name'] = nrg['temp'].str.rstrip(' ')
nrg = pd.merge(
    left=nrg,
    right=scrapped_imdb_title_codes[
        [
            'Movie Name',
            'IMDB Title Code',
            'IMDB Title Name'
        ]
    ],
    how='left',
    left_on='Cleaned Movie Name',
    right_on='Movie Name'
)


nrg = nrg.groupby(
    [
        'WEEKDAY',
        'MVID',
        'RELEASETITLE',
        'GENRE',
        'RELEASEDATE',
        'STUDIO',
        'FILMCODE',
        'WEEKNUMBER',
        'SEGMENT',
        'COUNTRYCODE',
        'WINDOW'
    ]
).agg(
    {
        'DEFINITEINTERESTAMONGAWARE':np.nanmax,
        'DEFNOTINTERESTED':np.nanmax,
        'DEFINITEINTERESTAMONGALL':np.nanmax,
        'FIRSTCHOICEOPENINGRELEASE':np.nanmax,
        'FIRSTCHOICEALL':np.nanmax,
        'HAVESEEN':np.nanmax,
        'POSITIVEINTEREST':np.nanmax,
        'SAW2TIMES':np.nanmax,
        'SECONDCHOICEAMONGMOVIES':np.nanmax,
        'SECONDTHIRDCHOICE':np.nanmax,
        'TOTALAWARENESS':np.nanmax,
        'UNAIDEDINTENT':np.nanmax,
        'UNAIDEDAWARENESS':np.nanmax
    }
)


with pd.ExcelWriter(
        path=r"C:\Users\Sandeep Sanyal\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\01. Base Data - As received\04. Other Data Elements\NRG Forecasting Decks\NRG_v2.xlsx",
        engine='openpyxl',
        mode='w',
        date_format='DD-MMM-YYYY',
        datetime_format='DD-MMM-YYYY'
) as writer:
    nrg.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='Sheet1'
    )


lc = pd.read_csv(
    filepath_or_buffer=r"C:\Users\Sandeep Sanyal\Affine Analytics Pvt Ltd\WB Theatrical - Documents\09. KPI Validation\01. Data Harmonization\01. Base Data - As Received\Lifecycle Tracker Data\July 16 Update\aggregate_request_wb_upload_all_qualified (2).csv"
)
