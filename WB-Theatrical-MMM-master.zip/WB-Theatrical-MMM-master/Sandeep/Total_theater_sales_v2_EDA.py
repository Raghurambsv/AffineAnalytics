# importing packages
import numpy as np
import pandas as pd
import xlrd
import matplotlib.pyplot as plt
from dateutil.parser import parse
from io import StringIO

# importing all files
Comp_Spending_v2 = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\Sayantan Chakraborty - WB Theatrical - Documents\02. Data\Long formatted data\Comp_Spending_v2.csv',
                               sep = ',',
                               encoding = 'latin-1')
Total_theater_sales_v2 = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\Sayantan Chakraborty - WB Theatrical - Documents\02. Data\Long formatted data\Total_theater_sales_v2.csv',
                               sep = ',',
                               encoding = 'latin-1')
common_imdb_title_codes_v2 = pd.read_csv(r'C:\Users\v-sanysa\Affine Analytics Pvt Ltd\Sayantan Chakraborty - WB Theatrical - Documents\02. Data\Long formatted data\backup_files\common_imdb_title_codes_v2.csv',
                               sep = ',',
                               encoding = 'latin-1')

# preparing dataset
Total_theater_sales_v2 = common_imdb_title_codes_v2.merge(right = Total_theater_sales_v2,
                                                       how = 'left',
                                                       left_on = ['common_title_codes'],
                                                       right_on = ['IMDB_Title_Code'],
                                                     sort = True,
                                                     copy = False)
Total_theater_sales_v2.drop(labels = Total_theater_sales_v2.columns[0],
                            axis = 1,
                            inplace =True)
Total_theater_sales_v2 = Total_theater_sales_v2.merge(right = Comp_Spending_v2,
                                                       how = 'left',
                                                       left_on = ['IMDB_Title_Code'],
                                                       right_on = ['IMDB_Title_Code'],
                                                     sort = True,
                                                     copy = False)

# 2.1.1	: Peak BO month flag for studio
Total_theater_sales_v2['Total_BO'] = Total_theater_sales_v2['Native_BO_2D_Amount']\
                                  + Total_theater_sales_v2['Native_BO_3D_Amount']\
                                  + Total_theater_sales_v2['Native_BO_3D_IMAX_Amount']\
                                  + Total_theater_sales_v2['Native_BO_IMAX_Amount']

Total_theater_sales_v2['Month_of_Release'] = pd.DatetimeIndex(Total_theater_sales_v2['Theatrical_Release_Date']).month

df_grp_studio_month = Total_theater_sales_v2.groupby(['Studio',
                                             'Month_of_Release'])[['Native_BO_2D_Amount',
                                                                   'Native_BO_3D_Amount',
                                                                   'Native_BO_3D_IMAX_Amount',
                                                                   'Native_BO_IMAX_Amount',
                                                                   'Opening_Weekend_BO',
                                                                   'Opening_Weekend_Runs',
                                                                   'Total_BO']].sum().reset_index()

df_grp_studio_month = df_grp_studio_month.loc[df_grp_studio_month.groupby(['Studio'])['Total_BO'].idxmax()]
df_grp_studio_month[['Studio', 'Month_of_Release']].reset_index(drop=True)

# 2.1.2	: Peak BO month flag for studio-genre
df_grp_studio_month = Total_theater_sales_v2.groupby(['Studio',
                                                      'Genre',
                                                      'Month_of_Release'])[['Native_BO_2D_Amount',
                                                                   'Native_BO_3D_Amount',
                                                                   'Native_BO_3D_IMAX_Amount',
                                                                   'Native_BO_IMAX_Amount',
                                                                   'Opening_Weekend_BO',
                                                                   'Opening_Weekend_Runs',
                                                                   'Total_BO']].sum().reset_index()

df_grp_studio_month = df_grp_studio_month.loc[df_grp_studio_month.groupby(['Studio', 'Genre'])['Total_BO'].idxmax()]
df_grp_studio_month[['Studio', 'Genre', 'Month_of_Release']].reset_index(drop=True)

# 2.1.3	: Average, total BO amount by Studio
df_grp_studio_month = Total_theater_sales_v2.groupby(['Studio']).agg({"Total_BO": ['sum', 'mean']})
df_grp_studio_month.columns = ["_".join(x) for x in df_grp_studio_month.columns.ravel()]
df_grp_studio_month = df_grp_studio_month.rename(columns = {'Total_BO_sum' : 'Total_BO', 'Total_BO_mean' : 'Avg_BO'})
df_grp_studio_month

# plot
fig = plt.figure()
bar_width = 0.35
ax = fig.add_subplot(111)
ax2 = ax.twinx()
(df_grp_studio_month['Total_BO']/1000000).plot(kind = 'bar', width = bar_width, color='blue', ax=ax, position = 1)
(df_grp_studio_month['Avg_BO']/1000000).plot(kind = 'bar', width = bar_width, color='red', ax=ax2, position=0)
ax.set_ylabel('Total BO (in Millions)')
ax2.set_ylabel('Average BO (in Millions)')
plt.xlabel('Studio')
plt.title('Total & Average BO by Studio')
plt.show()

# 2.1.4	: Average, total BO amount by Studio-Genre
df_grp_studio_month = Total_theater_sales_v2.groupby(['Genre', 'Studio']).agg({"Total_BO": ['sum', 'mean']})
df_grp_studio_month.columns = ["_".join(x) for x in df_grp_studio_month.columns.ravel()]
df_grp_studio_month = df_grp_studio_month.rename(columns = {'Total_BO_sum' : 'Total_BO',
                                                            'Total_BO_mean' : 'Avg_BO'})
df_grp_studio_month = df_grp_studio_month.reset_index()

df_grp_studio_month.pivot(index='Genre',columns='Studio',values='Total_BO')
df_grp_studio_month.pivot(index='Genre',columns='Studio',values='Avg_BO')

# 2.1.5	: Average, total 2d,3d,IMAX BO amount by Studio
df_grp_studio_month = Total_theater_sales_v2.groupby(['Genre']).agg({"Native_BO_2D_Amount": ['sum', 'mean'],
                                                                               "Native_BO_3D_Amount": ['sum', 'mean'],
                                                                               "Native_BO_3D_IMAX_Amount": ['sum', 'mean'],
                                                                               "Native_BO_IMAX_Amount": ['sum', 'mean']})
df_grp_studio_month.columns = ["_".join(x) for x in df_grp_studio_month.columns.ravel()]
df_grp_studio_month = df_grp_studio_month.rename(columns = {'Native_BO_2D_Amount_sum' : 'Total_BO_2D_Amount',
                                                            'Native_BO_2D_Amount_mean' : 'Avg_BO_2D_Amount',
                                                            'Native_BO_3D_Amount_sum': 'Total_BO_3D_Amount',
                                                            'Native_BO_3D_Amount_mean': 'Avg_BO_3D_Amount',
                                                            'Native_BO_3D_IMAX_Amount_sum': 'Total_BO_3D_IMAX_Amount',
                                                            'Native_BO_3D_IMAX_Amount_mean': 'Avg_BO_3D_IMAX_Amount',
                                                            'Native_BO_IMAX_Amount_sum': 'Total_BO_IMAX_Amount',
                                                            'Native_BO_IMAX_Amount_mean': 'Avg_BO_IMAX_Amount'})
df_grp_studio_month = df_grp_studio_month.reset_index()

#plot
ind = np.arange(df_grp_studio_month.shape[0])
p1 = plt.bar(ind, (df_grp_studio_month.Total_BO_2D_Amount)/1000000, 0.35)
p2 = plt.bar(ind, (df_grp_studio_month.Total_BO_3D_Amount)/1000000, 0.35,
             bottom = (df_grp_studio_month.Total_BO_2D_Amount)/1000000)
p3 = plt.bar(ind, (df_grp_studio_month.Total_BO_3D_IMAX_Amount)/1000000, 0.35,
             bottom = np.array((df_grp_studio_month.Total_BO_3D_Amount)/1000000) + np.array((df_grp_studio_month.Total_BO_2D_Amount)/1000000))
p4 = plt.bar(ind, (df_grp_studio_month.Total_BO_IMAX_Amount)/1000000, 0.35,
             bottom = np.array((df_grp_studio_month.Total_BO_3D_IMAX_Amount)/1000000) + np.array((df_grp_studio_month.Total_BO_3D_Amount)/1000000) + np.array((df_grp_studio_month.Total_BO_2D_Amount)/1000000))

plt.ylabel('BO Sales (in Millions)')
plt.show()
plt.title('BO Sales by Studio')
plt.legend((p1[0], p2[0], p3[0], p4[0]), ('Total_BO_2D_Amount', 'Total_BO_3D_Amount', 'Total_BO_3D_IMAX_Amount', 'Total_BO_IMAX_Amount'))
plt.xticks(ind, (df_grp_studio_month['Genre'].values))










# plot
fig = plt.figure()
bar_width = 0.35
ax = fig.add_subplot(111)
ax2 = ax.twinx()
(df_grp_studio_month['Total_BO']/1000000).plot(kind = 'bar', width = bar_width, color='blue', ax=ax, position = 1)
(df_grp_studio_month['Avg_BO']/1000000).plot(kind = 'bar', width = bar_width, color='red', ax=ax2, position=0)
ax.set_ylabel('Total BO (in Millions)')
ax2.set_ylabel('Average BO (in Millions)')
plt.xlabel('Studio')
plt.title('Total & Average BO by Studio')
plt.show()









# plot
plt.bar(x = range(df_grp_studio_month.shape[0]),
        height = list(df_grp_studio_month['Total_BO']/1000000),
        align='center')
plt.xticks(range(df_grp_studio_month.shape[0]), df_grp_studio_month['Studio'])
plt.ylabel('Total_BO (in millions)')
plt.title('Total BO by Studio')
plt.show()