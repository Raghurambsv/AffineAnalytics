# author=Sandeep Sanyal

# importing modules
import pandas as pd
import numpy as np
import math
from datetime import timedelta

# reading datasets
Total_Theater_Sales = pd.read_csv(filepath_or_buffer=r"C:\Users\sandeep\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Total_Theater_Sales_v3.csv",
                                  sep = ',',                       # Contains Title level BO Revenues
                                  encoding = 'latin-1')            # used to get unique PST and EST Release dates along with unique Studio per Title

title_maps = pd.read_csv(filepath_or_buffer=r"C:\Users\sandeep\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Final_Mapping_Data_v4.csv",
                         sep = ',', # used to map IMDB Movie Names
                         encoding = 'latin-1')

def weekly_sales_spends_activity(df, sharepoint_path, export_path):
    # this function takes in a user provided dataframe containing unique IMDB_Title_Codes and their Theater_Release_Dates
    # and returns a dataframe in a title-week level for which there are sales and(or) spends activity
    # Paramenters
    # df : a dataframe having the following columns:
        # IMDB_Title_Code
        # Theatrical_Release_Date
    # sharepoint_path: the root location where you are syncing WB Theatrical sharedrive
                    # default: r'C:/Users/sandeep/Affine Analytics Pvt Ltd/'
    # export_path : a complete path of where the final excel file will be exported

    titles = df['IMDB_Title_Codes'].to_list()

    # importing  relevant datasets
    Weekly_BO_sales = pd.read_csv(
        filepath_or_buffer=sharepoint_path + r"\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\WARNER\Weekly_BO_sales_WARNER_v1.0.csv",
        sep=',',  # Contains Title-Week level BO Revenue
        encoding='latin-1')
    Weekly_spends = pd.read_csv(
        filepath_or_buffer=sharepoint_path + r"\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\WARNER\Weekly_Spends_BOHE_WARNER_v1.0.csv",
        sep=',',  # Contains Title-Division-Channel-Week level Spends
        encoding='latin-1')  # Contains Title-Week level BO Spends
    Physical_Digital_Weekly_Sales = pd.read_csv(
        filepath_or_buffer=sharepoint_path + r"\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\WARNER\Weekly_HE_Sales_WARNER_v1.0.csv",
        sep=',',  # Contains Title-Week level Blu-ray & DVD, EST, iVOD & cVOD Revenue
        encoding='latin-1')
    title_maps = pd.read_csv(
        filepath_or_buffer=sharepoint_path + r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Final_Mapping_Data_v4.csv",
        sep=',',  # used to map IMDB Movie Names
        encoding='latin-1')

    # subsetting datasets
    Weekly_BO_sales = Weekly_BO_sales.loc[Weekly_BO_sales['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)
    Weekly_spends = Weekly_spends.loc[Weekly_spends['IMDB Title ID'].isin(titles), :].reset_index(drop=True)
    Physical_Digital_Weekly_Sales = Physical_Digital_Weekly_Sales.loc[Physical_Digital_Weekly_Sales['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)

    # correcting date columns
    df['Theatrical_Release_Date'] = pd.to_datetime(arg=df['Theatrical_Release_Date'],
                                                   format="%Y-%m-%d",
                                                   errors="coerce")
    Physical_Digital_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Physical_Digital_Weekly_Sales['Street_Date'],
                                                                  format="%Y-%m-%d",
                                                                  errors="coerce")
    Weekly_BO_sales['Theatrical Release Date'] = pd.to_datetime(arg=Weekly_BO_sales['Theatrical Release Date'],
                                                                infer_datetime_format=True,
                                                                errors="coerce")
    Weekly_BO_sales['Week Begin'] = pd.to_datetime(arg=Weekly_BO_sales['Week Begin'],
                                                   infer_datetime_format=True,
                                                   errors="coerce")
    Weekly_BO_sales['Week End'] = pd.to_datetime(arg=Weekly_BO_sales['Week End'],
                                                 infer_datetime_format=True,
                                                 errors="coerce")
    Weekly_spends['Theatrical_Release_Date'] = pd.to_datetime(arg=Weekly_spends['Theatrical_Release_Date'],
                                                              infer_datetime_format=True,
                                                              errors="coerce")
    Weekly_spends['BroadcastWeekOf'] = pd.to_datetime(arg=Weekly_spends['BroadcastWeekOf'],
                                                      infer_datetime_format=True,
                                                      errors="coerce")

    # creating list of all IMDB_Title_Codes & their Theatrical, EST & PST Release Dates
    all_titles = df

    all_titles['DVD_Street_Date'] = np.NaN
    all_titles['Blu-ray_Street_Date'] = np.NaN
    all_titles['EST_Street_Date'] = np.NaN
    all_titles['iVOD_Street_Date'] = np.NaN
    all_titles['cVOD_Street_Date'] = np.NaN
    for i in all_titles['IMDB_Title_Code'].unique():
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'DVD_Street_Date'] = Physical_Digital_Weekly_Sales.loc[(Physical_Digital_Weekly_Sales['IMDB_Title_Code'] == i) & (Physical_Digital_Weekly_Sales['Media_Type'] == 'DVD'), 'Street_Date'].min()
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Blu-ray_Street_Date'] = Physical_Digital_Weekly_Sales.loc[(Physical_Digital_Weekly_Sales['IMDB_Title_Code'] == i) & (Physical_Digital_Weekly_Sales['Media_Type'] == 'Blu-ray'), 'Street_Date'].min()
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Street_Date'] = Physical_Digital_Weekly_Sales.loc[(Physical_Digital_Weekly_Sales['IMDB_Title_Code'] == i) & (Physical_Digital_Weekly_Sales['Media_Type'] == 'EST'), 'Street_Date'].min()
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'iVOD_Street_Date'] = Physical_Digital_Weekly_Sales.loc[(Physical_Digital_Weekly_Sales['IMDB_Title_Code'] == i) & (Physical_Digital_Weekly_Sales['Media_Type'] == 'iVOD'), 'Street_Date'].min()
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'cVOD_Street_Date'] = Physical_Digital_Weekly_Sales.loc[(Physical_Digital_Weekly_Sales['IMDB_Title_Code'] == i) & (Physical_Digital_Weekly_Sales['Media_Type'] == 'cVOD'), 'Street_Date'].min()
    del i
    # correcting dates i all_titles
    all_titles['Blu-ray_Street_Date'] = pd.to_datetime(arg=all_titles['Blu-ray_Street_Date'],
                                                       format="%Y-%m-%d",
                                                       errors="coerce")
    all_titles['DVD_Street_Date'] = pd.to_datetime(arg=all_titles['DVD_Street_Date'],
                                                   format="%Y-%m-%d",
                                                   errors="coerce")
    all_titles['EST_Street_Date'] = pd.to_datetime(arg=all_titles['EST_Street_Date'],
                                                   format="%Y-%m-%d",
                                                   errors="coerce")
    all_titles['cVOD_Street_Date'] = pd.to_datetime(arg=all_titles['cVOD_Street_Date'],
                                                    format="%Y-%m-%d",
                                                    errors="coerce")
    all_titles['iVOD_Street_Date'] = pd.to_datetime(arg=all_titles['iVOD_Street_Date'],
                                                    format="%Y-%m-%d",
                                                    errors="coerce")

    # calculating Week number for EST & PST Release dates
    all_titles['EST_Week_Start'] = np.nan
    all_titles['iVOD_Week_Start'] = np.nan
    all_titles['cVOD_Week_Start'] = np.nan
    all_titles['DVD_Week_Start'] = np.nan
    all_titles['Blu-ray_Week_Start'] = np.nan
    for i in all_titles['IMDB_Title_Code'].unique():
        if pd.isnull(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Week_Start'].values[0]):
            all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Theatrical_Release_Date'] -all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Street_Date']) / pd.offsets.Day(-1)) / 7) + 1
        if pd.isnull(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'iVOD_Week_Start'].values[0]):
            all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'iVOD_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Theatrical_Release_Date'] -all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'iVOD_Street_Date']) / pd.offsets.Day(-1)) / 7) + 1
        if pd.isnull(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'cVOD_Week_Start'].values[0]):
            all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'cVOD_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Theatrical_Release_Date'] -all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'cVOD_Street_Date']) / pd.offsets.Day(-1)) / 7) + 1
        if pd.isnull(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'DVD_Week_Start'].values[0]):
            all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'DVD_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Theatrical_Release_Date'] -all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'DVD_Street_Date']) / pd.offsets.Day(-1)) / 7) + 1
        if pd.isnull(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Blu-ray_Week_Start'].values[0]):
            all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Blu-ray_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Theatrical_Release_Date'] -all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Blu-ray_Street_Date']) / pd.offsets.Day(-1)) / 7) + 1
    del i

    Weekly_BO_sales['Week_Number'] = np.floor(((Weekly_BO_sales['Week Begin'] - Weekly_BO_sales['Theatrical_Release_Date_TTS']) / pd.offsets.Day(1)) / 7) + 1

    # calculating week numbers since release date
    # Weekly_HE_sales
    Weekly_HE_sales = pd.DataFrame({'IMDB_Title_Code': [],
                                    'Item_Title_WW': [],
                                    'Studio': [],
                                    'Street_Date': [],
                                    'Theatrical_Release_Date': [],
                                    'Media_Type': [],
                                    'Week': [],
                                    'Revenue': [],
                                    'Units': []})

    for i in all_titles['IMDB_Title_Code'].unique():
        temp = Physical_Digital_Weekly_Sales.loc[Physical_Digital_Weekly_Sales['IMDB_Title_Code'] == i, :]
        for j in ['Blu-ray', 'DVD', 'EST', 'iVOD', 'cVOD']:
            temp1 = temp.loc[temp['Media_Type'] == j, :]
            for k in temp1.index:
                temp1.loc[k, 'Week'] = temp1.loc[k, 'Week'] + int(
                    all_titles.loc[all_titles['IMDB_Title_Code'] == i, str(j + '_Week_Start')])
            Weekly_HE_sales = Weekly_HE_sales.append(temp1)
            del temp1
        del temp
    del i, j, k

    # Weekly_spends
    Weekly_spends['Week'] = np.floor(((Weekly_spends['Theatrical_Release_Date'] - Weekly_spends['BroadcastWeekOf']) / pd.offsets.Day(-1)) / 7) + 1

    # look at this later
    Weekly_spends = Weekly_spends.groupby(['Division', 'IMDB_Title_Code', 'Movie_Name', 'Theatrical_Release_Date', 'Channel', 'BroadcastWeekOf','Week']).agg({'Media_Spend': 'sum'}).reset_index()
    # look till this later
    spends_week_range = pd.pivot_table(data=Weekly_spends,
                                       index=['IMDB_Title_Code'],
                                       columns=['Division', 'Channel'],
                                       values=['Week'],
                                       aggfunc=['min', 'max']).reset_index()
    all_titles = pd.merge(left=all_titles,
                          right=spends_week_range,
                          how='left',
                          left_on=['IMDB_Title_Code'],
                          right_on=[('IMDB_Title_Code', '', '', '')])
    all_titles.drop([('IMDB_Title_Code', '', '', '')], axis=1, inplace=True)
    del spends_week_range

    # updating list of all IMDB_Title_Codes & their Theatrical, EST & PST Release Dates with last week number
    all_titles['EST_Week_Ends'] = np.NaN
    all_titles['iVOD_Week_Ends'] = np.NaN
    all_titles['cVOD_Week_Ends'] = np.NaN
    all_titles['DVD_Week_Ends'] = np.NaN
    all_titles['Blu-ray_Week_Ends'] = np.NaN
    all_titles['BO_Week_Start'] = np.float64(0)
    all_titles['BO_Week_Ends'] = np.NaN
    for i in all_titles['IMDB_Title_Code'].unique():
        if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Week_Start']) != True:
            all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Week_Ends'] = max(Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB_Title_Code'] == i) & (Weekly_HE_sales['Media_Type'] == 'EST'), 'Week'].dropna())
        if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'iVOD_Week_Start']) != True:
            all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'iVOD_Week_Ends'] = max(Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB_Title_Code'] == i) & (Weekly_HE_sales['Media_Type'] == 'iVOD'), 'Week'].dropna())
        if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'cVOD_Week_Start']) != True:
            all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'cVOD_Week_Ends'] = max(Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB_Title_Code'] == i) & (Weekly_HE_sales['Media_Type'] == 'cVOD'), 'Week'].dropna())
        if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'DVD_Week_Start']) != True:
            all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'DVD_Week_Ends'] = max(Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB_Title_Code'] == i) & (Weekly_HE_sales['Media_Type'] == 'DVD'), 'Week'].dropna())
        if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Blu-ray_Week_Start']) != True:
            all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Blu-ray_Week_Ends'] = max(Weekly_HE_sales.loc[(Weekly_HE_sales['IMDB_Title_Code'] == i) & (Weekly_HE_sales['Media_Type'] == 'Blu-ray'), 'Week'].dropna())
        if i in Weekly_BO_sales['IMDB_Title_Code']:
            all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'BO_Week_Ends'] = max(Weekly_BO_sales.loc[Weekly_BO_sales['IMDB_Title_Code'] == i, 'Week_Number'].dropna())
    del i

    # creating the master_AD
    # creating a dataframe of IMDB Title Codes and Week ranges for each IMDB Title Codes
    unique_week = pd.DataFrame({'IMDB_Title_Code': [],
                                'Week_Number': []})

    activity_range = pd.DataFrame({'IMDB_Title_Code': all_titles['IMDB_Title_Code'].tolist(),
                                   'Oldest_Week': np.nanmin(all_titles.loc[:, all_titles.loc[:,all_titles.dtypes == np.float64].columns.values],axis=1).tolist(),
                                   'Latest_Week': np.nanmax(all_titles.loc[:, all_titles.loc[:,all_titles.dtypes == np.float64].columns.values],axis=1).tolist()})
    activity_range['Week_Length'] = (activity_range['Latest_Week'] - activity_range['Oldest_Week']) + 1
    activity_range.dropna(axis=0, how='all', thresh=3, inplace=True)

    for i in activity_range['IMDB_Title_Code']:
        temp = pd.DataFrame({'IMDB_Title_Code': [i] * int(activity_range.loc[activity_range['IMDB_Title_Code'] == i, 'Week_Length']),
                             'Week_Number': range(int(activity_range.loc[activity_range['IMDB_Title_Code'] == i, 'Oldest_Week']),
                                                  int(activity_range.loc[activity_range['IMDB_Title_Code'] == i, 'Latest_Week']) + 1)})
        unique_week = unique_week.append(temp, sort=True)
        del temp
    del i
    unique_week.reset_index(drop=True, inplace=True)
    del activity_range

    # merging Theater Release Date with unique_week dataset
    master_AD = pd.merge(left=unique_week,
                         right=all_titles[['IMDB_Title_Code',
                                           'Theatrical_Release_Date']],
                         how='left',
                         left_on='IMDB_Title_Code',
                         right_on='IMDB_Title_Code',
                         sort=True,
                         copy=False)
    del unique_week
    # merging spends for weeks present
    Weekly_spends = pd.pivot_table(data=Weekly_spends,
                                   index=['IMDB_Title_Code', 'Week'],
                                   columns=['Division', 'Channel'],
                                   values=['Media_Spend'],
                                   aggfunc=np.unique).reset_index()
    Weekly_spends.columns = ['IMDB_Title_Code',
                             'Week_Number',
                             'HE_spend_Digital',
                             'HE_spend_Linear',
                             'HE_spend_Outdoor',
                             'HE_spend_Print',
                             'BO_spend_Digital',
                             'BO_spend_Linear',
                             'BO_spend_Outdoor',
                             'BO_spend_Print']
    master_AD = pd.merge(left=master_AD,
                         right=Weekly_spends,
                         how='left',
                         left_on=['IMDB_Title_Code', 'Week_Number'],
                         right_on=['IMDB_Title_Code', 'Week_Number'],
                         sort=True,
                         copy=False)

    # # merging BO Revenue for weeks present
    master_AD = pd.merge(left=master_AD,
                         right=Weekly_BO_sales[['IMDB_Title_Code',
                                                'Week_Number',
                                                'Box Office']],
                         how='left',
                         left_on=['IMDB_Title_Code', 'Week_Number'],
                         right_on=['IMDB_Title_Code', 'Week_Number'],
                         sort=True,
                         copy=False)
    # merging EST Revenue for weeks present
    Weekly_HE_sales = pd.pivot_table(data=Weekly_HE_sales[['IMDB_Title_Code',
                                                           'Media_Type',
                                                           'Week',
                                                           'Revenue']],
                                     index=['IMDB_Title_Code', 'Week'],
                                     columns=['Media_Type'],
                                     values=['Revenue'],
                                     aggfunc=np.unique).reset_index()
    Weekly_HE_sales.columns = ['IMDB_Title_Code', 'Week_Number', 'Blu-ray_Revenue', 'DVD_Revenue', 'EST_Revenue',
                               'cVOD_Revenue', 'iVOD_Revenue']
    master_AD = pd.merge(left=master_AD,
                         right=Weekly_HE_sales,
                         how='left',
                         left_on=['IMDB_Title_Code', 'Week_Number'],
                         right_on=['IMDB_Title_Code', 'Week_Number'],
                         sort=True,
                         copy=False)

    for i in master_AD.index:
        master_AD.loc[i, 'Week'] = master_AD.loc[i, 'Theatrical_Release_Date'] + timedelta(
            days=master_AD.loc[i, 'Week_Number'] * 7)
    del i

    # renaming columns for column name consistency across all files
    master_AD = master_AD[['IMDB_Title_Code',
                           'Theatrical_Release_Date',
                           'Week_Number',
                           'Week',
                           'BO_spend_Digital',
                           'BO_spend_Linear',
                           'BO_spend_Outdoor',
                           'BO_spend_Print',
                           'HE_spend_Digital',
                           'HE_spend_Linear',
                           'HE_spend_Outdoor',
                           'HE_spend_Print',
                           'Box Office',
                           'Blu-ray_Revenue',
                           'DVD_Revenue',
                           'EST_Revenue',
                           'iVOD_Revenue',
                           'cVOD_Revenue']]
    master_AD.rename(columns={'Box Office': 'BO_Revenue'},
                     inplace=True)

    master_AD.drop_duplicates(inplace=True)

    # exporting master_AD
    master_AD.to_excel(sharepoint_path+export_path,
                       sheet_name='Final Data',
                       index=False)

weekly_sales_spends_activity(df = Total_Theater_Sales[['IMDB_Title_Code',
                                                       'Theatrical_Release_Date']],
                             sharepoint_path=r'C:/Users/sandeep/Affine Analytics Pvt Ltd/',
                             export_path=r"C:\Users\sandeep\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\weekly_spend_revenue_v1.1.xlsx")
