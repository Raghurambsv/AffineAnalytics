#Importing required packages

import pandas as pd
import glob
import os

#Getting a list of all FB Data files in the required path

path = r'C:\Users\sayantan\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 2 Data\Base\FB Data'
all_files = glob.glob(path + "/*.csv")

li = []

#For each file, read the csv
#Re-arrange columns as per requirement
#Append to base dataset

for filename in all_files:
    df = pd.read_csv(filename, index_col=None, header=0)
    df = df[['Campaign Name','Ad Set Name','Day','DMA Region','Amount Spent (USD)','Impressions','Clicks (All)','Reach','CPC (All)','CTR (All)','CPM (Cost per 1,000 Impressions)','Page Engagement','Page Likes','Post Comments','Post Shares','Video Watches at 25%','Video Watches at 50%','Video Watches at 75%','Video Watches at 95%','Video Watches at 100%','Video Plays','Reporting Starts','Reporting Ends']]
    df['Title_Name'] = os.path.basename(filename).split("-Home-Ent")[0].replace("-"," ")
	li.append(df)
    print(os.path.basename(filename) + " processed.")

#Create final Output DataFrame
output_df = pd.concat(li, axis=0, ignore_index=True)

#Rename columns of Output DataFrame
output_df.columns=['Campaign_Name','Ad_Set_Name','Day','DMA','Amt_Spent','Impressions','Clicks','Reach','CPC','CTR','CPM','Enagement','Likes','Comments','Shares','Vid_Watches_25','Vid_Watches_50','Vid_Watches_75','Vid_Watches_95','Vid_Watches_100','Vid_Plays','Start_Dt','End_Dt','Title_Name']

# Writing output to a csv file
output_df.to_csv(r'C:\Users\sayantan\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 2 Data\Cleaned\FB Data\FB_Data_v1.0.csv', index = False)

