# author: @Sandeep

# importing packages
import pandas as pd
import os

# set local path for synced sharepoint
sharepoint_path = r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/'

master_data = pd.DataFrame()
for file_name in os.listdir(sharepoint_path+r'/WB Theatrical - General/02. Data/Tier 2 Data/Base/WaveMetrix Data/Option 3/'):
    master_data = pd.concat([master_data,
                             pd.read_csv(filepath_or_buffer=sharepoint_path + r'/WB Theatrical - General/02. Data/Tier 2 Data/Base/WaveMetrix Data/Option 3/' + file_name,
                                         sep=',',
                                         encoding='latin-1')],
                            axis=0)
    print(file_name)
del file_name
