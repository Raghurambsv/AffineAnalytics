# author: @Sandeep

# importing packages
import pandas as pd
import os
from pandas.io.json import json_normalize

# set local path for synced sharepoint
sharepoint_path = r"C:/Users/sandeep/Affine Analytics Pvt Ltd"

for file_name in os.listdir(sharepoint_path+r"/WB Theatrical - Documents/01. Data Harmonization-Cleaning/00. Phase 1 Data Dependencies/05. Scoring Data"):
    json_file = pd.read_json(sharepoint_path+r"/WB Theatrical - Documents/01. Data Harmonization-Cleaning/00. Phase 1 Data Dependencies/05. Scoring Data/" + file_name) # reading json file
    temp_movie_data = json_normalize(json_file.loc[0, 'data'])  # getting dataframe
    # preparing a master dataframe containing all data from each movie titles
    if 'youtube' in file_name:
        movie_data_YouTube = pd.DataFrame()
        movie_data_YouTube = pd.concat([movie_data_YouTube,
                                        pd.concat([pd.DataFrame({'Movie_Title': [json_file.loc[0, 'film']] * temp_movie_data.shape[0], # adding Movie Title
                                                                 'IMDB_Title_Code': [json_file.loc[0, 'imdb_id']] * temp_movie_data.shape[0]}),  # adding IMDB Title Code
                                                   temp_movie_data],
                                                  axis=1)],
                                       axis=0)
        del temp_movie_data, json_file
    elif 'facebook' in file_name:
        movie_data_Facebook = pd.DataFrame()
        movie_data_Facebook = pd.concat([movie_data_Facebook,
                                         pd.concat([pd.DataFrame({'Movie_Title': [json_file.loc[0, 'film']] * temp_movie_data.shape[0], # adding Movie Title
                                                                  'IMDB_Title_Code': [json_file.loc[0, 'imdb_id']] * temp_movie_data.shape[0]}),  # adding IMDB Title Code
                                                    temp_movie_data],
                                                   axis=1)],
                                        axis=0)
        del temp_movie_data, json_file
    elif 'twitter' in file_name:
        movie_data_Twitter = pd.DataFrame()
        movie_data_Twitter = pd.concat([movie_data_Twitter,
                                        pd.concat([pd.DataFrame({'IMDB_Title_Code': [json_file.loc[0, 'imdb_id']] * temp_movie_data.shape[0],
                                                                 'Movie_Title': [json_file.loc[0, 'label']] * temp_movie_data.shape[0]}),
                                                   pd.DataFrame({'views': temp_movie_data['actual.US'],
                                                                 'post_date': temp_movie_data['post_date']})],
                                                  axis=1)],
                                       axis=0)
        del temp_movie_data, json_file
del file_name
# exporting social media data
# exporting master_AD
for i in ['Facebook', 'YouTube', 'Twitter']:
    if not eval('movie_data_'+i).empty:
        with pd.ExcelWriter(path=sharepoint_path+r"/WB Theatrical - Documents/01. Data Harmonization-Cleaning/00. Phase 1 Data Dependencies/05. Scoring Data/WaveMetrix_Scoring_"+i+r"_v1.0.xlsx",
                            mode='w',
                            date_format='YYYY-MM-DD',
                            datetime_format='YYYY-MM-DD HH:MM:SS') as writer:
            eval('movie_data_'+i).to_excel(excel_writer=writer,
                                           index=False,
                                           sheet_name='Sheet1',
                                           engine='openpyxl')
    else:
        print("No "+i+" data available")
