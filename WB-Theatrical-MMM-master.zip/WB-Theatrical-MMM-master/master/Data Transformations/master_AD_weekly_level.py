# importing modules
import pandas as pd
start_time = pd.datetime.now()
import numpy as np
import math

# reading datasets
Weekly_BO_sales = pd.read_csv(filepath_or_buffer=r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Weekly_BO_sales_v1.0.csv",
                              sep = ',',                # Contains Title-Week level BO Revenue
                              encoding = 'latin-1')
HE_sales = pd.read_csv(filepath_or_buffer=r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\HE_Sales_v1.0.csv",
                       sep = ',',                       # Contains Title level Blu-ray, DVD, EST, iVOD, cVOD Revenues
                       encoding = 'latin-1')            # used to get unique PST and EST Release dates along with unique Studio per Title
Physical_Weekly_Sales_v3 = pd.read_csv(filepath_or_buffer=r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Physical_Weekly_Sales_v3.csv',
                                       sep = ',',       # Contains Title-Week level Blu-ray & DVD Revenue
                                       encoding = 'latin-1')
Digital_Weekly_Sales_v3 = pd.read_csv(filepath_or_buffer=r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/WB Theatrical - General/02. Data/Tier 1 Data - Cleaned/Base Data/Digital_Weekly_Sales_v3.csv',
                                      sep = ',',        # Contains Title-Week level EST, iVOD & cVOD Revenue
                                      encoding = 'latin-1')
# titles = pd.read_csv(filepath_or_buffer=r"C:\Users\v-sanysa\Desktop\weekly_BO_Titles_temp1.csv",    # file contains IMDB Title Codes common to all files
#                      sep = ',',                                                                     # Remove this read function when running for all IMDB Title Codes
#                      encoding = 'latin-1')

# correcting date columns
HE_sales['Theatrical_Release_Date'] = pd.to_datetime(arg=HE_sales['Theatrical_Release_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=HE_sales['Blu-ray_Street_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['DVD_Street_Date'] = pd.to_datetime(arg=HE_sales['DVD_Street_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['EST_Street_Date'] = pd.to_datetime(arg=HE_sales['EST_Street_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['cVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['cVOD_Street_Date'], format="%Y-%m-%d", errors="coerce")
HE_sales['iVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['iVOD_Street_Date'], format="%Y-%m-%d", errors="coerce")
Physical_Weekly_Sales_v3['Street_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales_v3['Street_Date'], format="%Y-%m-%d", errors="coerce")
Physical_Weekly_Sales_v3['Theatrical_Release_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales_v3['Theatrical_Release_Date'], format="%Y-%m-%d", errors="coerce")
Digital_Weekly_Sales_v3['Street_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales_v3['Street_Date'], format="%Y-%m-%d", errors="coerce")
Digital_Weekly_Sales_v3['Theatrical_Release_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales_v3['Theatrical_Release_Date'], format="%Y-%m-%d", errors="coerce")
Weekly_BO_sales['Theatrical Release Date'] = pd.to_datetime(arg=Weekly_BO_sales['Theatrical Release Date'], infer_datetime_format=True, errors="coerce")
Weekly_BO_sales['Week Begin'] = pd.to_datetime(arg=Weekly_BO_sales['Week Begin'], infer_datetime_format=True, errors="coerce")
Weekly_BO_sales['Week End'] = pd.to_datetime(arg=Weekly_BO_sales['Week End'], infer_datetime_format=True, errors="coerce")

# uncomment this section when running for all IMDB Title Codes
titles = pd.merge(left=Weekly_BO_sales[['IMDB_Title_Code', 'Theatrical Release Date']].drop_duplicates(inplace=False),
                  right=HE_sales[['IMDB_Title_Code', 'Theatrical_Release_Date']].drop_duplicates(inplace=False),
                  how='outer',
                  left_on=['IMDB_Title_Code'],
                  right_on=['IMDB_Title_Code'],
                  sort=True,
                  copy=False)
for i in titles['IMDB_Title_Code'].unique() : # removing titles with 2 theater release dates (most of these are foreign movies and small movies)
    if (titles.loc[titles['IMDB_Title_Code']==i].shape)[0] > 1 :
        titles.drop(index=titles.loc[titles['IMDB_Title_Code']==i].index.values,
                    axis=0,
                    inplace=True)
for i in titles.index.values : # removing titles with different release dates (if present in both files) in Weekly_BO_Sales & HE_Sales
    if ((pd.isnull(titles.loc[i, 'Theatrical_Release_Date'])==False) & (pd.isnull(titles.loc[i, 'Theatrical Release Date'])==False) & (titles.loc[i, 'Theatrical_Release_Date']!=titles.loc[i, 'Theatrical Release Date']))==True :
        titles.drop(index=i,
                    axis=0,
                    inplace=True)
titles = titles.loc[:,'IMDB_Title_Code'].tolist()

# subseting datasets
Weekly_BO_sales = Weekly_BO_sales.loc[Weekly_BO_sales['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)
HE_sales = HE_sales.loc[HE_sales['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)
Physical_Weekly_Sales_v3 = Physical_Weekly_Sales_v3.loc[Physical_Weekly_Sales_v3['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)
Digital_Weekly_Sales_v3 = Digital_Weekly_Sales_v3.loc[Digital_Weekly_Sales_v3['IMDB_Title_Code'].isin(titles), :].reset_index(drop=True)

# fixing double studio issues
# Weekly_BO_Sales
for i in Weekly_BO_sales['IMDB_Title_Code'].unique():
    temp = Weekly_BO_sales.loc[Weekly_BO_sales['IMDB_Title_Code'] == i, :]
    if len(temp['Studio'].unique()) > 1 :
        if temp['Studio'].str.contains('WARNER').sum() > 0 :
            Weekly_BO_sales.drop(index=temp.loc[temp['Studio'] != 'WARNER'].index.values,
                                 axis=0,
                                 inplace=True)
        else :
            gp_data = temp.groupby(['IMDB_Title_Code', 'Title', 'Genre', 'Studio', 'Theatrical Release Date']).agg({'Box Office': 'sum'}).reset_index()
            if len(gp_data.loc[gp_data['Box Office'] != max(gp_data['Box Office']), 'Studio'].unique()) == 2 :
                Weekly_BO_sales.drop(index=temp.loc[temp['Studio'] == 'ALL OTHERS'].index.values,
                                     axis=0,
                                     inplace=True)
            elif len(gp_data.loc[gp_data['Box Office'] != max(gp_data['Box Office']), 'Studio'].unique()) == 1 :
                Weekly_BO_sales.drop(index=Weekly_BO_sales.loc[(Weekly_BO_sales['IMDB_Title_Code']==i) & (Weekly_BO_sales['Studio']==(gp_data.loc[gp_data['Box Office'] != max(gp_data['Box Office']), 'Studio'].values)[0]), :].index.values,
                                     axis=0,
                                     inplace=True)
# Digital_Weekly_Sales_v3
for i in Digital_Weekly_Sales_v3['IMDB_Title_Code'].unique():
    temp = Digital_Weekly_Sales_v3.loc[Digital_Weekly_Sales_v3['IMDB_Title_Code'] == i, :]
    if len(temp['Studio'].unique()) > 1 :
        if temp['Studio'].str.contains('WARNER').sum() > 0 :
            Digital_Weekly_Sales_v3.drop(index=temp.loc[temp['Studio'] != 'WARNER'].index.values,
                                         axis=0,
                                         inplace=True)
        else :
            gp_data = temp.groupby(['IMDB_Title_Code', 'Item_Title_WW', 'Studio', 'Street_Date', 'Theatrical_Release_Date']).agg({'Revenue': 'sum', 'Units': 'sum'}).reset_index()
            if len(gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].unique()) == 2 :
                Digital_Weekly_Sales_v3.drop(index=temp.loc[temp['Studio'] == 'ALL OTHERS'].index.values,
                                             axis=0,
                                             inplace=True)
            elif len(gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].unique()) == 1:
                Digital_Weekly_Sales_v3.drop(index=Digital_Weekly_Sales_v3.loc[(Digital_Weekly_Sales_v3['IMDB_Title_Code'] == i) & (Digital_Weekly_Sales_v3['Studio'] == (gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].values)[0]), :].index.values,
                                             axis=0,
                                             inplace=True)
# Physical_Weekly_Sales_v3
for i in Physical_Weekly_Sales_v3['IMDB_Title_Code'].unique():
    temp = Physical_Weekly_Sales_v3.loc[Physical_Weekly_Sales_v3['IMDB_Title_Code'] == i, :]
    if len(temp['Studio'].unique()) > 1 :
        if temp['Studio'].str.contains('WARNER').sum() > 0 :
            Physical_Weekly_Sales_v3.drop(index=temp.loc[temp['Studio'] != 'WARNER'].index.values,
                                          axis=0,
                                          inplace=True)
        else :
            gp_data = temp.groupby(['IMDB_Title_Code', 'Item_Title_WW', 'Studio', 'Street_Date', 'Theatrical_Release_Date']).agg({'Revenue': 'sum', 'Units': 'sum'}).reset_index()
            if len(gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].unique()) == 2 :
                Physical_Weekly_Sales_v3.drop(index=temp.loc[temp['Studio'] == 'ALL OTHERS'].index.values,
                                              axis=0,
                                              inplace=True)
            elif len(gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].unique()) == 1 :
                Physical_Weekly_Sales_v3.drop(index=Physical_Weekly_Sales_v3.loc[(Physical_Weekly_Sales_v3['IMDB_Title_Code'] == i) & (Physical_Weekly_Sales_v3['Studio'] == (gp_data.loc[gp_data['Revenue'] != max(gp_data['Revenue']), 'Studio'].values)[0]), :].index.values,
                                              axis=0,
                                              inplace=True)
del i, temp, gp_data

# fixing same studio, double release date issues
# Digital_Weekly_Sales_v3
for i in Digital_Weekly_Sales_v3['IMDB_Title_Code'].unique() :
    Digital_Weekly_Sales_v3.loc[Digital_Weekly_Sales_v3["IMDB_Title_Code"] == i, 'Street_Date'] = Digital_Weekly_Sales_v3.loc[Digital_Weekly_Sales_v3["IMDB_Title_Code"] == i, 'Street_Date'].min()
# Physical_Weekly_Sales_v3
for i in Physical_Weekly_Sales_v3['IMDB_Title_Code'].unique() :
    Physical_Weekly_Sales_v3.loc[Physical_Weekly_Sales_v3["IMDB_Title_Code"] == i, 'Street_Date'] = Physical_Weekly_Sales_v3.loc[Physical_Weekly_Sales_v3["IMDB_Title_Code"] == i, 'Street_Date'].min()
del i

# calculating EST_Release_Date & PST_Release_Date
HE_sales['EST_Release_Date'] = HE_sales[['EST_Street_Date', 'cVOD_Street_Date', 'iVOD_Street_Date']].min(axis = 1)
HE_sales['PST_Release_Date'] = HE_sales[['Blu-ray_Street_Date', 'DVD_Street_Date']].min(axis = 1)

# creating list of all IMDB_Title_Codes & their Theatrical, EST & PST Release Dates
all_titles = HE_sales[['IMDB_Title_Code', 'Theatrical_Release_Date', 'EST_Release_Date', 'PST_Release_Date']]
all_titles['Week Begin'] = np.NaN
for i in all_titles['IMDB_Title_Code'] :
    if len(Weekly_BO_sales.loc[Weekly_BO_sales['IMDB_Title_Code']==i,'Week Begin'].values) > 0 :
        all_titles.loc[all_titles['IMDB_Title_Code']==i,'Week Begin'] = Weekly_BO_sales.loc[Weekly_BO_sales['IMDB_Title_Code']==i,'Week Begin'][Weekly_BO_sales.loc[Weekly_BO_sales['IMDB_Title_Code']==i,'Week Begin'].index[0]]
all_titles['Week Begin'] = pd.to_datetime(arg=all_titles['Week Begin'], format="%Y-%m-%d", errors="coerce")
# calculating Week number for Theatrical, EST & PST Release dates
all_titles['TTH_Week_Start'] = np.floor(((all_titles['Week Begin'] - all_titles['Theatrical_Release_Date'])/pd.offsets.Day(-1))/7)
for i in all_titles['IMDB_Title_Code'].unique() :
    if pd.isnull(all_titles.loc[all_titles['IMDB_Title_Code']==i, 'Week Begin'].values[0]) :
        all_titles.loc[all_titles['IMDB_Title_Code']==i, 'EST_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code']==i, 'Theatrical_Release_Date'] - all_titles.loc[all_titles['IMDB_Title_Code']==i, 'EST_Release_Date'])/pd.offsets.Day(-1))/7)
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'PST_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Theatrical_Release_Date'] - all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'PST_Release_Date'])/pd.offsets.Day(-1))/7)
    else :
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Week Begin'] - all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Release_Date'])/pd.offsets.Day(-1))/7)
        all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'PST_Week_Start'] = np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Week Begin'] - all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'PST_Release_Date'])/pd.offsets.Day(-1))/7)
del i

# calculating week numbers since release date
# Weekly_BO_sales
Weekly_BO_sales_1 = pd.DataFrame({'IMDB_Title_Code' : [],
                                  'Title' : [],
                                  'Genre' : [],
                                  'Studio' : [],
                                  'Theatrical Release Date' : [],
                                  'Fiscal Week' : [],
                                  'Week Begin' : [],
                                  'Week End' : [],
                                  'Box Office' : [],
                                  'Week' : []})
for i in all_titles['IMDB_Title_Code'] :
    temp = Weekly_BO_sales.loc[Weekly_BO_sales['IMDB_Title_Code'] == i, :]
    temp['Week'] = int()
    for j in temp.index :
        temp.loc[j,'Week'] = int(np.floor(((all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'Week Begin'] - temp.loc[j,'Week Begin'])/pd.offsets.Day(-1))/7))
    Weekly_BO_sales_1 = Weekly_BO_sales_1.append(temp)
# Physical_Weekly_Sales_v3
Weekly_PST_sales_1 = pd.DataFrame({'IMDB_Title_Code' : [],
                                   'Item_Title_WW' : [],
                                   'Studio' : [],
                                   'Street_Date' : [],
                                   'Theatrical_Release_Date' : [],
                                   'Media_Type' : [],
                                   'Week' : [],
                                   'Revenue' : [],
                                   'Units' : []})
for i in all_titles['IMDB_Title_Code'] :
    temp = Physical_Weekly_Sales_v3.loc[Physical_Weekly_Sales_v3['IMDB_Title_Code'] == i, :]
    for j in temp.index :
        temp.loc[j,'Week'] = temp.loc[j,'Week'] + all_titles.loc[all_titles['IMDB_Title_Code'] == i,'PST_Week_Start'].values
    Weekly_PST_sales_1 = Weekly_PST_sales_1.append(temp)
# Digital_Weekly_Sales_v3
Weekly_EST_sales_1 = pd.DataFrame({'IMDB_Title_Code' : [],
                                   'Item_Title_WW' : [],
                                   'Studio' : [],
                                   'Street_Date' : [],
                                   'Theatrical_Release_Date' : [],
                                   'Media_Type' : [],
                                   'Week' : [],
                                   'Revenue' : [],
                                   'Units' : []})
for i in all_titles['IMDB_Title_Code'] :
    temp = Digital_Weekly_Sales_v3.loc[Digital_Weekly_Sales_v3['IMDB_Title_Code'] == i, :]
    for j in temp.index :
        temp.loc[j,'Week'] = temp.loc[j,'Week'] + all_titles.loc[all_titles['IMDB_Title_Code'] == i,'EST_Week_Start'].values
    Weekly_EST_sales_1 = Weekly_EST_sales_1.append(temp)
del i, j, temp

# combining Blu-ray & DVD Revenue/Units to PST Revenue/Units
Weekly_PST_sales_1 = Weekly_PST_sales_1.groupby(['IMDB_Title_Code',
                                                 'Item_Title_WW',
                                                 'Studio',
                                                 'Street_Date',
                                                 'Theatrical_Release_Date',
                                                 'Week']).agg({'Revenue':'sum',
                                                               'Units':'sum'}).reset_index()
# combining EST,iVod,cVOD Revenue/Units to EST Revenue/Units
Weekly_EST_sales_1 = Weekly_EST_sales_1.groupby(['IMDB_Title_Code',
                                                 'Item_Title_WW',
                                                 'Studio',
                                                 'Street_Date',
                                                 'Theatrical_Release_Date',
                                                 'Week']).agg({'Revenue':'sum',
                                                               'Units':'sum'}).reset_index()

# updating list of all IMDB_Title_Codes & their Theatrical, EST & PST Release Dates with last week number
all_titles['TTH_Week_Ends'] = np.NaN
all_titles['EST_Week_Ends'] = np.NaN
all_titles['PST_Week_Ends'] = np.NaN
for i in all_titles['IMDB_Title_Code'].unique() :
    if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code']==i,'TTH_Week_Start']) != True :
        all_titles.loc[all_titles['IMDB_Title_Code']==i,'TTH_Week_Ends'] = max(Weekly_BO_sales_1.loc[Weekly_BO_sales_1['IMDB_Title_Code']==i, 'Week'].dropna())
    if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'EST_Week_Start']) != True :
        all_titles.loc[all_titles['IMDB_Title_Code']==i, 'EST_Week_Ends'] = max(Weekly_EST_sales_1.loc[Weekly_EST_sales_1['IMDB_Title_Code'] == i, 'Week'].dropna())
    if math.isnan(all_titles.loc[all_titles['IMDB_Title_Code'] == i, 'PST_Week_Start']) != True :
        all_titles.loc[all_titles['IMDB_Title_Code']==i, 'PST_Week_Ends'] = max(Weekly_PST_sales_1.loc[Weekly_PST_sales_1['IMDB_Title_Code'] == i, 'Week'].dropna())
all_titles['EST_Week_Ends'] = pd.to_numeric(all_titles['EST_Week_Ends'])
del i

# creating the master_AD
# creating a dataframe of IMDB Title Codes and Week ranges for each IMDB Title Codes
unique_week = pd.DataFrame({'IMDB_Title_Code' : [],
                            'Week' : []})
for i in all_titles['IMDB_Title_Code'].unique() :
    unique_week = unique_week.append(pd.DataFrame({'IMDB_Title_Code': [i]*int(np.nanmax(all_titles.loc[all_titles['IMDB_Title_Code']==i, ['TTH_Week_Ends', 'EST_Week_Ends', 'PST_Week_Ends']].values)+1),
                                                   'Week': np.arange(0, int(np.nanmax(all_titles.loc[all_titles['IMDB_Title_Code']==i, ['TTH_Week_Ends', 'EST_Week_Ends', 'PST_Week_Ends']]))+1)}))
del i
# merging BO Revenue for weeks present
master_AD = pd.merge(left = unique_week,
                     right = Weekly_BO_sales_1[['IMDB_Title_Code', 'Title', 'Studio', 'Theatrical Release Date', 'Week', 'Box Office']],
                     how='left',
                     left_on = ['IMDB_Title_Code', 'Week'],
                     right_on = ['IMDB_Title_Code', 'Week'],
                     sort = True,
                     copy = False)
# merging EST Revenue for weeks present
master_AD = pd.merge(left = master_AD,
                     right = Weekly_EST_sales_1[['IMDB_Title_Code', 'Week', 'Revenue']],
                     how='left',
                     left_on = ['IMDB_Title_Code', 'Week'],
                     right_on = ['IMDB_Title_Code', 'Week'],
                     sort = True,
                     copy = False)
# merging PST Revenue for weeks present
master_AD = pd.merge(left = master_AD,
                     right = Weekly_PST_sales_1[['IMDB_Title_Code', 'Week', 'Revenue']],
                     how='left',
                     left_on = ['IMDB_Title_Code', 'Week'],
                     right_on = ['IMDB_Title_Code', 'Week'],
                     sort = True,
                     copy = False)
del unique_week
# selecting columns that are required
master_AD = master_AD[['IMDB_Title_Code',
                       'Week',
                       #'Studio',
                       #'Theatrical Release Date',
                       'Box Office',
                       'Revenue_x',
                       'Revenue_y']]
# renaming columns for column name consistency across all files
master_AD.rename(columns = {#'Theatrical Release Date' : 'Theatrical_Release_Date',
                            'Box Office' : 'BO_Revenue',
                            'Revenue_x' : 'EST_Revenue',
                            'Revenue_y' : 'PST_Revenue'},
                 inplace = True)

# exporting master_AD
master_AD.to_csv(path_or_buf = r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\Weekly_Sales_AD_2763_v1.0.csv",
                 index=False)

print("Program Commplete")
print("Time Elapsed: " + str(pd.datetime.now()-start_time))