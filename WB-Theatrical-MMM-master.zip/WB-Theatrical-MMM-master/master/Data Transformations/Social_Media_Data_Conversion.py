import pandas as pd

# Importing Base file received from Matt
base_data = pd.ExcelFile('WB Titles for Social Data Pull.xlsx')

# Counting # Sheets which is same as # Titles, as well as list of Titles
title_list = base_data.sheet_names

# Creating blank dataframe for final output
output_df = pd.DataFrame(columns=['Title_Name','Date','Volume','Intent_Volume'])

# For each sheet, reading 1st 3 columns, adding Sheet name as Title name
# rearranging columns and appending to Output dataframe

for nm in title_list:
    temp_df = pd.read_excel(base_data, sheetname = nm, parse_cols = 'A:C')
    temp_df['Title_Name'] = nm
    temp_df.columns = ['Date','Volume','Intent_Volume','Title_Name']
    temp_df['Date'] = pd.to_datetime(temp_df.Date)
    temp_df = temp_df[['Title_Name','Date','Volume','Intent_Volume']]
    output_df = output_df.append(temp_df, ignore_index=True)

# Writing output to a csv file
output_df.to_csv('Social_Media_Data_v2.0.csv', index = False)  

