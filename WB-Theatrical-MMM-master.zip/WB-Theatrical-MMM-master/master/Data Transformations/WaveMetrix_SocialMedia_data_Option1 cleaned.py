# author: @Sandeep

# importing packages
import pandas as pd
import os
from pandas.io.json import json_normalize

# set local path for synced sharepoint
sharepoint_path = r'C:/Users/v-sanysa/Affine Analytics Pvt Ltd/'

movie_data_Youtube = pd.DataFrame()
movie_data_Facebook = pd.DataFrame()

for file_name in os.listdir(sharepoint_path+r"/WB Theatrical - General/02. Data/Tier 2 Data/Base/WaveMetrix Data/Option 1/"):
    json_file = pd.read_json(sharepoint_path+r"/WB Theatrical - General/02. Data/Tier 2 Data/Base/WaveMetrix Data/Option 1/"+file_name) # reading json file
    temp_movie_data = json_normalize(json_file.loc[0, 'data']) # getting dataframe
    # preparing a master dataframe containing all data from each movie titles
    if 'youtube' in file_name:
        movie_data_Youtube = pd.concat([movie_data_Youtube,
                                        pd.concat([pd.DataFrame({'Movie_Title': [json_file.loc[0, 'film']] * temp_movie_data.shape[0], # adding Movie Title
                                                                 'IMDB_Title_Code': [json_file.loc[0, 'imdb_id']] * temp_movie_data.shape[0]}), # adding IMDB Title Code
                                                   temp_movie_data],
                                                  axis=1)],
                                       axis=0)
        del  temp_movie_data, json_file
    elif 'facebook' in file_name:
        movie_data_Facebook = pd.concat([movie_data_Facebook,
                                         pd.concat([pd.DataFrame({'Movie_Title': [json_file.loc[0, 'film']] * temp_movie_data.shape[0], # adding Movie Title
                                                                  'IMDB_Title_Code': [json_file.loc[0, 'imdb_id']] * temp_movie_data.shape[0]}), # adding IMDB Title Code
                                                    temp_movie_data],
                                                   axis=1)],
                                        axis=0)
        del  temp_movie_data, json_file
del file_name


# arranging columns
movie_data_Youtube = movie_data_Youtube[['IMDB_Title_Code',
                                         'Movie_Title',
                                         'post_date',
                                         'videos',
                                         'views',
                                         'comments',
                                         'likes',
                                         'dislikes',
                                         'sentiment']]
movie_data_Facebook = movie_data_Facebook[['IMDB_Title_Code',
                                           'Movie_Title',
                                           'post_date',
                                           'videos',
                                           'views',
                                           'comments',
                                           'likes',
                                           'shares',
                                           'ptat']]

# fixing dates
movie_data_Youtube['post_date'] = pd.to_datetime(arg=movie_data_Youtube['post_date'], infer_datetime_format=True, errors="coerce")
movie_data_Facebook['post_date'] = pd.to_datetime(arg=movie_data_Facebook['post_date'], infer_datetime_format=True, errors="coerce")

# exporting data
movie_data_Youtube.to_csv(path_or_buf=sharepoint_path+r"\WB Theatrical - General\02. Data\Tier 2 Data - Cleaned\WaveMetrix_Youtube_Option1_v1.0.csv",
                          na_rep="",
                          sep=",",
                          index=False)
movie_data_Facebook.to_csv(path_or_buf=sharepoint_path+r"\WB Theatrical - General\02. Data\Tier 2 Data - Cleaned\WaveMetrix_Facebook_Option1_v1.0.csv",
                           na_rep="",
                           sep=",",
                           index=False)
