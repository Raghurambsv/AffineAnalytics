# -*- coding: utf-8 -*-
"""
Created on Wed Feb 27 14:58:55 2019

@author: amit
"""

import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import kurtosis, skew, pearsonr
import os

class analysis():
    """
    A class which outputs all the univariate and bivariate plots for the passed
    variables
    
    Parameters
    ----------
    dataframe: Pandas Dataframe
        The dataframe containing the variables
    numerical_list: List of column names
        The list in which all those numerical columns will be passed whose
        plots is to be outputted
    categorical_list: List of column names
        The list of all those categorical columns will be passed whose bivariate
        analysis is to be done
    dependent variable: String
        The column name of the dependent variable against which the bivariate
        plots will be made
    """
    def __init__(self, dataframe, numerical_list=None, categorical_list=None,
                 dependent_variable=None):
        self.dataframe = dataframe
        self.numerical_list = numerical_list
        self.categorical_list = categorical_list
        self.dependent_variable = dependent_variable


    def univariate_analysis(self):
        if self.numerical_list != None:
            for numerical in self.numerical_list:
                try:
                    print(numerical)
                    fig = plt.figure()
                    ax = fig.add_subplot(121)
                    sns.distplot(self.dataframe[numerical], ax=ax)
                    text = "Skewness: "+ str(round(skew(self.dataframe[numerical]),2))
                    ax.text(1, 1,text, horizontalalignment ='right', verticalalignment='top',
                            transform=ax.transAxes)
                    ax.set_ylabel("Kernel Density Estimate")
                    ax1 = fig.add_subplot(122)
                    sns.boxplot(y= self.dataframe[numerical], ax=ax1)
                    plt.tight_layout()
                    fig.savefig(numerical)
                except TypeError:
                    continue
        if self.categorical_list!=None:
            for categorical in self.categorical_list:
                print(categorical)
                fig = plt.figure()
                ax = fig.add_subplot(111)
                sns.countplot(x=self.dataframe[categorical], ax=ax)
                ax.set_xticklabels(ax.get_xticklabels(), rotation=90)
                plt.tight_layout()
                fig.savefig(categorical)
                


    def bivariate_analysis(self):
        if self.numerical_list != None:
            for numerical in self.numerical_list:
                print(numerical)
                try:
                    fig = plt.figure()
                    ax = fig.add_subplot(111)

                    sns.regplot(y=self.dependent_variable,
                                    x=numerical, ax=ax, data = self.dataframe)
                    text = "Correlation: " + str(round(pearsonr(
                            x=self.dataframe[self.dependent_variable],
                            y=self.dataframe[numerical])[0],2))
                    ax.text(1, 1, text, horizontalalignment='right',
                            verticalalignment='top', transform=ax.transAxes)
                    ax.set_xlabel(str(numerical))
                    ax.set_ylabel(str(self.dependent_variable))
                    fig.savefig(numerical)
                except TypeError:
                    continue
        if self.categorical_list!=None:
            for categorical in self.categorical_list:
                print(categorical)
                print(categorical)
                fig = plt.figure()
                ax = fig.add_subplot(111)
                sns.boxplot(x=self.dataframe[categorical],
                            y=self.dataframe[self.dependent_variable], ax= ax)
                ax.set_xticklabels(ax.get_xticklabels(), rotation=90)
                plt.tight_layout()
                fig.savefig(categorical)
                
