# -*- coding: utf-8 -*-
"""
Created on Tue May 14 17:31:16 2019

@author: Sayantan Chakraborty
"""

#Importing required Libraries
from bs4 import BeautifulSoup
import requests
import re
import os
import pandas as pd
import datetime

os.chdir(r"E:\Sayantan_C\Projects\09. Warner Bros - Theatrical MMM\03. Codes")

#Import URLs
base_data = pd.read_excel(r"WB - Daily Sales data extraction.xlsx", sheetname = "Sheet1")

base_data['BoxOfficeMojo URL'] = base_data['BoxOfficeMojo URL'].astype(str)

print("Start time : " + str(datetime.datetime.now()))

#Creating Final Dataframe structure
collated_output = pd.DataFrame(columns = ["Day","Date","Rank","Gross","Screens","Avg. per Screen",
                                              "Cumulative Gross", "Day #", "Title_ID", "Title_Name"])

#Iterating for each URL											  
for url in base_data["BoxOfficeMojo URL"]:
	
	#Looking up Title ID and Title Name
    Title_ID = base_data.loc[base_data["BoxOfficeMojo URL"] == url, "IMDB Title Code"].values[0]
    Title_Name = base_data.loc[base_data["BoxOfficeMojo URL"] == url, "Movie Title"].values[0]
	
	#Extracting response from BoxOfficeMojo
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'lxml')
    
	#Identifying Table in which required information is present
	table = soup.find('table', {'class': 'chart-wide'})
    
	#For each TR in the Table,  all TDs are extracted and concatenated to create 1 List for each Row
	#List for each Row is appended to a Base List
    base_list = []
    for tr in table.find_all('tr')[1:]:
        tds = tr.find_all('td')
        try:
            temp_list = [tds[0].text, tds[1].text, tds[2].text, tds[3].text, tds[6].text, tds[7].text, tds[8].text, tds[9].text]
        except:
            temp_list = []     
        base_list.append(temp_list)
    
	#Base List now contains required data for a single Movie
	#This List of Lists is then converted into a DataFrame; irrelevant rows are dropped
    temp_output = pd.DataFrame(base_list, columns = ["Day","Date","Rank","Gross","Screens","Avg. per Screen",
                                                         "Cumulative Gross", "Day #"])
    temp_output.dropna(axis = 0, how = 'all', inplace = True)
    
	#Title ID and Title Name are added for easier consumption
    temp_output["Title_ID"] = Title_ID
    temp_output["Title_Name"] = Title_Name   
    
	#Rows for each Title is printed for validation purposes
    print("# Days for " + str(Title_Name) + " : " + str(len(temp_output)))
    
	#DataFrame for a single Movie is appended to a master DataFrame which will contain data for all Movies
    collated_output = collated_output.append(temp_output)
    collated_output = collated_output[["Title_ID", "Title_Name", "Day","Date","Rank","Gross","Screens","Avg. per Screen",
                                              "Cumulative Gross", "Day #"]]
    
print("End time   : " + str(datetime.datetime.now()))

#Final DataFrame written back to Excel
collated_output.to_excel(r"WB Titles - Daily BO Sales.xlsx", index = False)

