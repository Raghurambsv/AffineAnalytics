

# Part of code to load all relevant libraries
#### Load Libraries ####
library(sqldf)
library(gtrendsR)
library('xlsx')
library('plyr')
library('lubridate')

#### End ####

# Part of code to load movie trailer stats (Arunav's), add 120 days to trailer load date
# Part of code to create empty data frames to which data is appended

#### Code Part ####

movie_list <- read.xlsx("C:/Users/abhinav/Documents/WB/movie_trailer_statistics_v2.xlsx", sheetName = "in")

movie_list$start <- as.Date(movie_list$videoUploadDate, "%Y-%m-%d")
movie_list$end <- movie_list$start + 120

time_data <- data.frame(" ")
geo_data <- data.frame(" ")
city_data <- data.frame(" ")
keyword_data <- data.frame(" ")
time_data <- data.frame(" ")

test <- movie_list[,]
test$movie_name <- as.character(test$movie_name)

#### End ####


# Loop to get trends data and append (a) Daily search and (b) Geographical data into DF
#### Code Part ####

for(i in c(1:nrow(test))){
  temp_data <- gtrends(keyword = test[i,1],
                       time = paste(test[i,9],test[i,10], sep = " "),gprop = "youtube", geo = "US")
  time_data <- rbind.fill(time_data,temp_data$interest_over_time)
  start_date <- str(test[i,9])
  geo_temp <- data.frame(temp_data$interest_by_region)
  geo_temp$start <- start_date
  geo_data <- rbind.fill(geo_data,geo_temp)
  city_data <- rbind.fill(city_data, temp_data$interest_by_city)
  keyword_data <- rbind.fill(keyword_data,temp_data$related_queries)
  }

geo_data <- geo_data[2:nrow(geo_data),2:6]
time_data <- time_data[2:nrow(time_data),2:7]
city_data <- city_data[2:nrow(city_data),2:6]
keyword_data <- keyword_data[2:nrow(keyword_data),2:7]
#### End ####

# Read the GDP and Population data and merging with Trends (Geo) data

#### Code Part ####

gdp_data <- read.xlsx("State GDP.xlsx",sheetName = "Sheet1")
gdp_data$State <- substr(gdp_data$State,3,nchar(gdp_data$State))
gdp_data$State <- tolower(trimws(gdp_data$State, which = "both"))
head(gdp_data)

population_data <- read.xlsx("Population.xlsx",sheetName = "Sheet1")
head(population_data)
population_data$State <- as.character(population_data$State)
population_data$State <- substr(population_data$State,3,nchar(population_data$State))
population_data$State <- tolower(trimws(population_data$State, which = "both"))
head(population_data)

# Merging with geo_data

geo_data$location <- tolower(geo_data$location)
geo_data$location <- trimws(geo_data$location, which = "both")

gdp_data$State <- substr(gdp_data$State,3,nchar(gdp_data$State))

staging_1 <- merge(x = population_data, y = geo_data, by.x = "State", by.y = "location")
staging_2 <- merge(x = gdp_data,y = staging_1, by.x = "State", by.y = "State",all.y = T)

#### End ####

# product of population, GDP and population growth in absolute numbers (Scaled)

release_temp <- movie_list[,c(1,9)]
release_temp$year <- substr(release_temp$start,1,4)
staging_3 <- merge(x = staging_2, y = release_temp, by.x = "keyword", by.y = "movie_name",all.x = T)



# Taking hits above 50 only

staging_3 <- staging_3[staging_3$hits >= 50,]

staging_3$gdp <- ifelse(staging_3$year == "2011",staging_3$X2011,
                        ifelse(staging_3$year == "2012",staging_3$X2012,
                               ifelse(staging_3$year == "2013",staging_3$X2013,
                                      ifelse(staging_3$year == "2014",staging_3$X2014,
                                             ifelse(staging_3$year == "2015",staging_3$X2015,
                                                    ifelse(staging_3$year == "2016",staging_3$X2016,
                                                           ifelse(staging_3$year == "2017",staging_3$X2017,
                                                                  ifelse(staging_3$year == "2018",staging_3$X2018,
                                                                         NA))))))))

staging_3$gdp <- ifelse(is.na(staging_3$gdp) == T,46264,staging_3$gdp)

staging_3$X2010.Census.51. <- ifelse(is.na(staging_3$X2010.Census.51.) == T,3046355,staging_3$X2010.Census.51.)

staging_3$pop_scaled <- (staging_3$X2010.Census.51. - min(staging_3$X2010.Census.51.))/(max(staging_3$X2010.Census.51.)-min(staging_3$X2010.Census.51.))
summary(staging_3$pop_scaled)

staging_3$gdp_scaled <- (staging_3$gdp - min(staging_3$gdp))/(max(staging_3$gdp)-min(staging_3$gdp))
summary(staging_3$gdp_scaled)

staging_3$composite_var <- staging_3$gdp_scaled*staging_3$pop_scaled*staging_3$hits
summary(staging_3$composite_var)

staging_3 <- staging_3[,-14]

score <- sqldf("select sum(composite_var) as comp, keyword as movie_name from staging_3 group by keyword")

write.xlsx(score, "comp_score.xlsx")
