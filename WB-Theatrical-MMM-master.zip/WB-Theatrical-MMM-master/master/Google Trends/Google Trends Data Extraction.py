# Importing required packages
import pandas as pd
import re
import datetime as dt
from pytrends.request import TrendReq
from random import randint
from time import sleep

YT_Data = r"E:\Sayantan_C\Projects\09. Warner Bros - Theatrical MMM\03. Codes\movie_trailer_statistics_v3.xlsx"

# Import YT Trailer data
base_data = pd.read_excel(YT_Data, sheetname="in")

base_data['movie_name'] = base_data['movie_name'].astype(str)

GT_data = pd.DataFrame(columns=['Date', 'Hits','Partial', 'Movie_name'])

pytrends = TrendReq(hl='en-US', tz=360)

for nm in base_data["movie_name"]:
    
    Start_date = str(base_data[base_data["movie_name"] == nm]["videoUploadDate"].values[0])
    Start_date = Start_date[0:Start_date.find("T")]
    End_date = "2019-04-04"
    Date_range = Start_date+" "+End_date
    
    CleanedKeyword = re.sub("[^A-Za-z0-9']+", ' ',str(nm))
    pytrends.build_payload([CleanedKeyword], cat=0, timeframe=Date_range, geo="US", gprop="youtube")
    temp = pytrends.interest_over_time().reset_index()
    try:
        temp.columns = ['Date', 'Hits','Partial']
        temp['Movie_name'] = nm
        print("Data Scraped for "+nm+" movie!")
        GT_data = GT_data.append(temp)
        sleep(randint(5,30))
    except:
        print("Error for "+str(nm)+" movie!")

output_df = GT_data[['Movie_name','Date','Hits']]
output_df.to_csv(r'E:\Sayantan_C\Projects\09. Warner Bros - Theatrical MMM\03. Codes\Google_Trends_Data_python_vf.csv', index = False)

