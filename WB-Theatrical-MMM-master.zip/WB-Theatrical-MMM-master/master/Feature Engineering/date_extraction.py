# -*- coding: utf-8 -*-
"""
Created on Mon Feb 25 12:00:55 2019

@author: amit
"""
import re
import pandas as pd
import numpy as np


def day(date):
    try:
        day = re.search(r'(\d{1,2})([\s-])', date).group(1)
    except AttributeError:
        day = "None"
    return day


def month(date):
    try:
        month = re.search(r'([\s-])(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|January|\
                February|March|April|May|June|July|August|September|\
                October|November|December|\d{2})', date).group(2)
    except AttributeError:
        month = "None"
    if month == "None":
        return month
    elif len(month)>2:
        return month[0:3]
    else:
        return month


def year(date):
    try:
        year = re.search(r'([\s-])(\d{2,4})', date).group(2)
    except AttributeError:
        year = "None"

    if year == 'None':
        try:
            year = re.search(r'(\d{2,4})', date).group(0)
        except AttributeError:
            year = 'None'

    if year != "None":
        if (len(year) == 2) & (int(year) <= 20):
            year = int(year)+2000
        elif (len(year) == 2) & (int(year) > 20):
            year = int(year)+1900
    return str(year)


def string_to_date(dataframe):
    try:
        dataframe['US_Release_Date'] = pd.to_datetime(
                     dataframe['US_Release_Date'], format='%d-%b-%Y')
    except ValueError:
        dataframe['US_Release_Date'] = np.nan
    return dataframe['US_Release_Date']


def convert_to_date(dataframe):
    dataframe.rename(columns={'US.Release.Date': 'US_Release_Date'},
                     inplace=True)
    dataframe['day'] = dataframe['US_Release_Date'].apply(
            lambda x: day(str(x)))
    dataframe['month'] = dataframe['US_Release_Date'].apply(
            lambda x: month(str(x)))
    dataframe['year'] = dataframe['US_Release_Date'].apply(
            lambda x: year(str(x)))
    dataframe['US_Release_Date'] = dataframe['day']+'-'+dataframe['month']+'-'+dataframe['year']
    dataframe['US_Release_Date'] = dataframe.apply(
            lambda x: string_to_date(x), axis=1)
    return dataframe
