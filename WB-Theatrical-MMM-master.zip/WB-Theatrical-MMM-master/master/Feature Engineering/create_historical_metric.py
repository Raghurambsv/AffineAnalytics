# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 14:56:40 2019

@author: amit
"""

import numpy as np
import pandas as pd
import date_extraction

def create_historical_metric(base_dataframe, scrapped_info, column, movie_segment):
    """
    Function to create past metrics of the movie segment

    Parameters
    ---------
    base_dataframe: Pandas Dataframe
        The original dataframe in which the metric is to be calculated.
        Primary key name must be 'IMDB_Title_Code'
    scrapped_info: Pandas Dataframe
        The exhaustive list of movies dataframe
    column: String
        Name of the column whose metric is to be calculated
    movie_segment: String
        Name of the movie segment column
    Returns
    -------
    Pandas Dataframe: The updated base dataframe with historical metrics of the
    movie titles calculated
    """
    # Extracting the dates out of strings in the scrapped info file
    competitor_info = date_extraction.convert_to_date(scrapped_info)

    # Sorting the resultant dataframe so as to calculate cumulative average
    competitor_info = competitor_info.sort_values(
            by=[movie_segment, 'US_Release_Date'])
    competitor_info.reset_index(inplace=True, drop=True)

    # Creating a lagged column of variable, which will be used to calculate
    # cumulative average in the next step
    competitor_info[str('lagged_')+column] = competitor_info.groupby(
            [movie_segment])[column].shift(1)

    # Creating a cumulative average column
    competitor_info_grouped_mean = competitor_info.groupby(
                [movie_segment],
                as_index=False)[str('lagged_')+column].expanding(1).mean()
    # Creating a cumulative median column
    competitor_info_grouped_median = competitor_info.groupby(
                [movie_segment],
                as_index=False)[str('lagged_')+column].expanding(1).median()
    competitor_info_grouped_mean.reset_index(inplace=True, drop=True)
    competitor_info_grouped_median.reset_index(inplace=True, drop=True)
    # Subsetting the mean and median columns
    competitor_info[str('average_previous_')+column] = competitor_info_grouped_mean
    competitor_info[str('median_previous_')+column] = competitor_info_grouped_median
    competitor_info = competitor_info[
            ['IMDB_Title_Code', str('average_previous_')+column, str('median_previous_')+column]]
    # Left joining with the base dataframe to get the mean and median metrics
    # in the original dataframe
    base_dataframe = pd.merge(base_dataframe, competitor_info, on='IMDB_Title_Code',
                              how='left')
    
    return base_dataframe