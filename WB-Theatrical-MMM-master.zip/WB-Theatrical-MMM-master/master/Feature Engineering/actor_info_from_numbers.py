"""
Created on Mon Mar 11 14:46:53 2019

@author: Arunav Saikia
"""

import pandas as pd
from libraries import *
import numpy as np
import bs4
import json
from requests import get
import re
import difflib

def getPeopleIndex(soup):
    
    if soup.find_all('div')[0].find_all('h1')[1].text == 'People':
        index = 1
    else:
        index = 2
        
    return int(index)

def get_actor_attr(name):
    print(name)
    clean_name = name.replace(' ', '+')
    url =  'https://www.the-numbers.com/search?searchterm=' + clean_name

    try:
        response = get(url)

        soup = bs4.BeautifulSoup(response.text, 'lxml')
        
        index = getPeopleIndex(soup)
        actor_container = soup.find_all('table')[index]
        scrapped_name = actor_container.find_all('td')[1].text
        scrapped_url = 'https://www.the-numbers.com' + actor_container.find_all('td')[1].a.get('href') \
                                                    + '#tab=acting'
        scrapped_match = actor_container.find_all('td')[0].text
        return [name, scrapped_name, scrapped_url, scrapped_match]
    except:
        return [name, None, None, None]

def scrape_actors_from_numbers(modelingAD):
    actors_series = modelingAD['Actors'].\
                    apply(lambda x: str(x).strip().split("[")[1][:-1]).\
                        apply(lambda x : str(x).replace("'","")).\
                            apply(lambda x : list(str(x).split(',')))
    actors_list = list(actors_series)
    flat_list = list(set([item for sublist in actors_list for item in sublist]))
    cleaned_flat_list = list(map(lambda x : str(x).strip(), flat_list))
    
    df = pd.DataFrame(list(map(get_actor_attr, cleaned_flat_list)),\
                  columns = ['query_name', 'scrapped_name', 'URL', 'Match'])
    df.to_csv('./actor_numbers.csv', index = False)
    return df
    

    
def actor_movies_df(actor_movies, n):
    movie_list = []
    for movie in actor_movies:
        release_date = movie.find_all('td')[0].text
        movie_name = movie.find_all('td')[1].text
        movie_gross_us = movie.find_all('td')[n].text
        movie_gross_worldwide = movie.find_all('td')[5].text
        movie_list.append([release_date, movie_name, movie_gross_us, movie_gross_worldwide])
    
    return pd.DataFrame(movie_list, columns = ['Release_Date' ,'Movie_Name', 'Gross US', 'Gross Worldwide'])

def scrape_actors_movies_from_numbers(modelingAD):
    actor_numbers = scrape_actors_from_numbers(modelingAD)

    actors = pd.DataFrame([])

    for url in actor_numbers['URL'][actor_numbers['URL'].notnull()]:
        print(url)
        response = get(url)
        soup = bs4.BeautifulSoup(response.text, 'lxml')
        try:
            try:
                actor_lead_movies = soup.find_all('table')[4].find_all('tr')[1:-3]
    
                actor_supporting_movies = soup.find_all('table')[5].find_all('tr')[1:-3]
    
                actor_lead_df = actor_movies_df(actor_lead_movies, 4)
                actor_lead_df['Role'] = 'Lead'
    
                actor_supporting_df = actor_movies_df(actor_supporting_movies, 4)
                actor_supporting_df['Role'] = 'Supporting'
    
                df_actor = pd.concat([actor_lead_df, actor_supporting_df], axis = 0)
    
                df_actor['URL'] = url
    
            except:
                actor_supporting_movies = soup.find_all('table')[3].find_all('tr')[1:-3]
                df_actor = actor_movies_df(actor_supporting_movies, 3)
                df_actor['Role'] = 'Supporting'
                df_actor['URL'] = url
        except:
            df_actor = pd.DataFrame([[url, None, None, None, None, None]], \
                                    columns = ['URL', 'Role','Gross Worldwide', 'Gross US','Movie_Name', 'Release_Date' ])
        actors = pd.concat([actors, df_actor], axis = 0)

    actors.to_csv('./actor_movies_numbers.csv', index = False)
    actors_numbers_final = actor_numbers.merge(actors, left_on = 'URL',\
                    right_on = 'URL',\
                    how = 'left')
    actors_numbers_final.to_csv('./actors_numbers_final.csv', index = False)
    return actors_numbers_final
