# -*- coding: utf-8 -*-
"""
Created on Tue Feb 26 17:55:26 2019

@author: Arunav Saikia
"""
import pandas as pd

def get_trailer_stats(df):
    """
    Add trailer stats to the base dataframe
    Args:
        df : The dataframe on which the variable is to be calculated
    Returns:
        df : New dataframe with the variable added
    """
    youtube_data = pd.read_csv('./movie_trailer_statistics_v2.csv')
    df = pd.merge(left = df, right = youtube_data, 
                how = 'left', 
                left_on='Movie_Title', 
                right_on='movie_name').\
                drop(['movie_name','videoId', 'videoTitle'], axis = 1)
    return df
    
