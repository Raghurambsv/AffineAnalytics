# -*- coding: utf-8 -*-
"""
Created on Wed Feb 27 17:02:24 2019

@author: Amit
"""
import libraries
import date_extraction
import pandas as pd
import numpy as np


def create_average_earning(df, column, actor_director):
    """
    Function to create average past earnings of the actors/directors
    Parameters
    ---------
    df: Pandas Dataframe
        The original dataframe in which the metric is to be calculated
    column: String
        Name of the column whose metric is to be calculated
    actor_director: String
        Either of one of the two; 'Actor' or 'Director'
    Returns
    -------
    Pandas Dataframe: The updated dataframe with earnings of the
    actors/directors
    """

    # Sorting the resultant dataframe so as to calculate cumulative average
    df = df.sort_values(
            by=[actor_director, 'US_Release_Date'])
    df.reset_index(inplace=True, drop=True)

    # Creating a lagged column of variable, which will be used to calculate
    # cumulative average in the next step
    df[str('lagged_')+column] = df.groupby(
            [actor_director])[column].shift(1)

    # Creating a cumulative average column
    df_grouped = df.groupby(
                [actor_director],
                as_index=False)[str('lagged_')+column].expanding(1).mean()
    df_grouped.reset_index(inplace=True, drop=True)
    df[str('average_previous_')+column] = df_grouped

    return df

def create_average_roi(df, column_1, column_2, actor_director):

    """
    Function to create average past ROI of the actors
    Parameters
    ---------
    df: Pandas Dataframe
        The original dataframe in which the metric is to be calculated
    column_1: String
        Name of the numerator column to calculate ROI
    column_2: String
        Name for the denominator column to calculate ROI
    actor_director: String
        Either of one of the two; 'Actor' or 'Director'
    Returns
    ------
    Pandas Dataframe: The updated dataframe with ROI of the actors/directors
    """

    df = df.sort_values(
            by=[actor_director, 'US_Release_Date'])
    df.reset_index(inplace=True, drop=True)

    for column in [column_1, column_2]:
        df[str('lagged_')+column] = df.groupby(
                [actor_director])[column].shift(1)

        df_grouped = df.groupby(
                    [actor_director],
                    as_index=False)[str('lagged_')+column].expanding(1).sum()

        df_grouped.reset_index(inplace=True, drop=True)
        df[str('cumsum_')+column] = df_grouped
    df['average_previous_roi'] = df[str('cumsum_')+column_1]/df[str('cumsum_')+column_2]

    return df



def imputation(dataframe, actor_director):
    """
    Function to impute NA values with the Average Gross US and Average ROI with
    previous year's average across all actors' first movie appearance.
 
    Parameters
    ----------
    dataframe: Pandas dataframe
        dataframe whose Gross US and ROI has to be imputed
    actor_director: String
        Either of one of the two; 'Actor' or 'Director'
    Returns
    -------
    dataframe: Pandas Dataframe
        Returns an updated dataframe with imputed values
    """

    # Creating a Release Year column
    dataframe = dataframe.loc[dataframe['year']!='None',:]
    dataframe['US_Release_Year'] = dataframe['year'].astype(int)

    # Sorting the dataframe so as to get the first appearance of the
    # actor/director
    dataframe.sort_values(by=[actor_director, 'US_Release_Date'], inplace=True)

    # Getting the first appearance of the actor/director
    temp = dataframe.groupby(actor_director, as_index=False).head(1)

    # For the first appearance calculating the ROI
    temp_for_roi = pd.pivot_table(temp, index=['US_Release_Year'],
                                  values=['Gross_US', 'Budget'],
                                  aggfunc=np.sum).reset_index()
    temp_for_roi['roi'] = temp_for_roi['Gross_US']/temp_for_roi['Budget']
    temp_for_roi = temp_for_roi[['US_Release_Year', 'roi']]

    # Getting the average earnings for all the actor's first appearances
    # across the year
    year_wise_average = pd.pivot_table(temp, index=['US_Release_Year'],
                                       values=['Gross_US'],
                                       aggfunc=np.mean).reset_index()

    # Getting the average ROI for the actor's first appearances across the year
    year_wise_average = pd.merge(year_wise_average, temp_for_roi,
                                 left_on=['US_Release_Year'],
                                 right_on=['US_Release_Year'],
                                 how='left')

    # Renaming for brevity
    year_wise_average.rename(columns={'Gross_US': 'Yearly_Gross_US',
                                      'roi': 'Yearly_roi'}, inplace=True)

    # Joining to get the previous year's average earnings and ROI
    dataframe['previous_year'] = dataframe['US_Release_Year']-1

    dataframe = pd.merge(dataframe, year_wise_average,
                         left_on=['previous_year'],
                         right_on=['US_Release_Year'],
                         how='left')

    # Imputing the NA values with the average ones calculated above
    dataframe.sort_values(by='US_Release_Date', inplace=True)
    dataframe['row_num'] = dataframe.groupby(
            actor_director, as_index=False).cumcount()+1
    dataframe['average_previous_Gross_US'] = dataframe.apply(
            lambda x: x['Yearly_Gross_US'] if
            (pd.isnull(x['average_previous_Gross_US'])&(x['row_num']==1))
            else x['average_previous_Gross_US'], axis=1)

    dataframe['average_previous_roi'] = dataframe.apply(
        lambda x: x['Yearly_roi'] if
        ((pd.isnull(x['average_previous_roi'])& (x['row_num']==1)))
        else x['average_previous_roi'], axis=1)

    return dataframe


#### Main Function ####
def create_cast_metrics(dataframe, actor_director, impute=False):
    """
    Function to calculate the actor/director past average Earnings and ROI
    Parameters
    ----------
    dataframe: Pandas Dataframe
        The original base dataframe in which metrics are to be calculated. It
        must have columns: 'IMDB_Title_Code'
    scrapped_info: Pandas Dataframe
        The actor/director info dataframe at Title ID level. It must have
        columns: 'IMDB_Title_Code','Actors/DirectorsURL', 'Budget',
        'Gross_US'
    actor_director: String
        Either of one of the two; 'Actor' or 'Director'
    Impute: Bool
        True or False whether to impute or not
    Returns
    -------
    Pandas dataframe: The updated dataframe with Average Earnings and Average
    ROI metrics for actors/directors
    """
    scrapped_info = pd.read_csv('./IMDB_scrapped_titles.csv').rename({'titleID':'IMDB_Title_Code'}, axis = 1)
    # Extracting the date column
    scrapped_info = date_extraction.convert_to_date(scrapped_info)

    # Creating a backup version
    scrapped_info_ = scrapped_info.copy()

    # Setting maximum number of actors to 4 and directors to 2
    if actor_director == 'Actor':
        maxlen = 4
    else:
        maxlen = 2

    # Splitting the actors/directors to columns
    temp = scrapped_info_[actor_director+'s'+'URL'].str.replace('[','').str.replace("\'",'').str.replace(']','').\
                                                    str.split(",", expand=True)
    temp = temp.iloc[:, 0:maxlen]
    # Renaming the columns
    temp.columns = [str(actor_director)+'_'+str(i) for i in range(maxlen)]
    scrapped_info_ = pd.concat([scrapped_info_, temp], axis=1)

    # Converting the Title ID level dataframe to an exhaustive
    # ActorID-titleID level dataframe

    cast_level_data = pd.melt(scrapped_info_, 
                              id_vars=['IMDB_Title_Code','US_Release_Date',
                                       'year','Budget','Gross_US'],
                 value_vars = temp.columns)
    
    cast_level_data.dropna(subset=['value'],inplace=True)
    cast_level_data.rename(columns={'value': actor_director}, inplace=True)

    # Calling the helper functions to calculate Average Earnings and ROI
    cast_level_data = create_average_earning(
            cast_level_data, 'Gross_US', actor_director)
    cast_level_data = create_average_roi(
            cast_level_data, 'Gross_US', 'Budget', actor_director)

    # Calling the imputation fucntion if condition is true
    if impute:
            cast_level_data = imputation(cast_level_data, actor_director)

    # Subsetting the required columns
    required_df = cast_level_data[
        ['IMDB_Title_Code', actor_director, 'average_previous_Gross_US',
         'average_previous_roi']]
    required_df.dropna(subset=[actor_director],inplace=True)
    # Merging back the dataframe with metrics to the actors/directors info
    # dataframe and converting back to TitleID level dataframe
    for num in range(maxlen):
        scrapped_info_ = pd.merge(scrapped_info_, required_df,
                                  left_on=[actor_director+'_'+str(num),
                                           'IMDB_Title_Code'],
                                  right_on=[actor_director, 'IMDB_Title_Code'],
                                  how='left')
        scrapped_info_.rename(columns={'average_previous_Gross_US':
                                       actor_director+'_'+str(num)+'_'+'Gross_US',
                                       'average_previous_roi':
                                       actor_director+'_'+str(num)+'_'+'roi'},
                              inplace=True)

    # Making a list of only required columns
    required_columns = [str(actor_director)+'_'+str(i) for i in range(maxlen)]
    required_columns.extend(
            [str(actor_director)+'_'+str(i)+'_'+'Gross_US' for i in range(maxlen)])
    required_columns.extend(
            [str(actor_director)+'_'+str(i)+'_'+'roi' for i in range(maxlen)])
    required_columns.extend(['IMDB_Title_Code'])

    # Merging back with the original Base AD dataframe and returning the
    # updated dataframe
    scrapped_info_2 = scrapped_info_[required_columns]
    dataframe = pd.merge(
        dataframe, scrapped_info_2, how='left',
        left_on=['IMDB_Title_Code'],
        right_on=['IMDB_Title_Code'])

    return dataframe
