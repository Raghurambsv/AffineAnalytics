# -*- coding: utf-8 -*-
"""
Created on Mon Mar 25 18:42:38 2019

@author: amit
"""

import numpy as np
import pandas as pd


def proxy_views_maker(google_trends_data, views_data):
    net_hits = google_trends_data.groupby('IMDB_Title_Code').agg({
            'hits': 'sum'}).reset_index()
    net_hits.rename(columns={'hits': 'net_hits'}, inplace=True)
    google_trends_data = pd.merge(google_trends_data, net_hits, how='left',
                                  on='IMDB_Title_Code')
    google_trends_data = pd.merge(google_trends_data, views_data[['IMDB_Title_Code', 'views_count']],
                                  how='left',
                                  on='IMDB_Title_Code')
    google_trends_data['proxy_views'] = google_trends_data.apply(
            lambda x: (x['hits']/x['net_hits'])*x['views_count'], axis=1)
    return google_trends_data
    
