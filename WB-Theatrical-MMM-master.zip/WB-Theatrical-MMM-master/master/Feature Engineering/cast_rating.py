# -*- coding: utf-8 -*-
"""
Created on Wed Feb 27 17:02:24 2019

@author: Amit
"""

import date_extraction
import pandas as pd
import numpy as np


def create_average_rating(df, column, actor_director):
    """
    Function to create average past ratings of the actors/directors
    Parameters
    ---------
    df: Pandas Dataframe
        The original dataframe in which the metric is to be calculated
    column: String
        Name of the column whose metric is to be calculated
    actor_director: String
        Either of one of the two; 'Actor' or 'Director'
    Returns
    -------
    Pandas Dataframe: The updated dataframe with earnings of the
    actors/directors
    """

    # Sorting the resultant dataframe so as to calculate cumulative average
    df = df.sort_values(
            by=[actor_director, 'US_Release_Date'])
    df.reset_index(inplace=True, drop=True)

    # Creating a lagged column of variable, which will be used to calculate
    # cumulative average in the next step
    df[str('lagged_')+column] = df.groupby(
            [actor_director])[column].shift(1)

    # Creating a cumulative average column
    df_grouped = df.groupby(
                [actor_director],
                as_index=False)[str('lagged_')+column].expanding(1).mean()
    df_grouped.reset_index(inplace=True, drop=True)
    df[str('average_previous_')+column] = df_grouped

    return df

## Helper Function##
def trim(x):
    return str(x).strip()


#### Main Function ####
def create_cast_metrics(dataframe, actor_director):
    """
    Function to calculate the actor/director past ratings
    Parameters
    ----------
    dataframe: Pandas Dataframe
        The original base dataframe in which metrics are to be calculated. It
        must have columns: 'IMDB_Title_Code'
    scrapped_info: Pandas Dataframe
        The actor/director info dataframe at Title ID level. It must have
        columns: 'IMDB_Title_Code','Actors/DirectorsURL', 'Budget',
        'Gross_US'
    actor_director: String
        Either of one of the two; 'Actor' or 'Director'
    Returns
    -------
    Pandas dataframe: The updated dataframe with Average ratings for actors/directors
    """
    scrapped_info = pd.read_csv('./IMDB_scrapped_titles.csv', encoding='latin-1').rename({'titleID':'IMDB_Title_Code'}, axis = 1)
    # Extracting the date column
    scrapped_info = date_extraction.convert_to_date(scrapped_info)

    # Creating a backup version
    scrapped_info_ = scrapped_info.copy()
    scrapped_info_ = scrapped_info_.dropna(subset=['US_Release_Date'])
    # Setting maximum number of actors to 4 and directors to 2
    if actor_director == 'Actor':
        maxlen = 4
    else:
        maxlen = 2

    # Splitting the actors/directors to columns
    temp = scrapped_info_[actor_director+'s'+'URL'].str.replace('[','').str.replace("\'",'').str.replace(']','').\
                                                    str.split(",", expand=True)
    temp = temp.applymap(trim)
    temp = temp.iloc[:, 0:maxlen]
    # Renaming the columns
    temp.columns = [str(actor_director)+'_'+str(i) for i in range(maxlen)]
    scrapped_info_ = pd.concat([scrapped_info_, temp], axis=1)

    # Converting the Title ID level dataframe to an exhaustive
    # ActorID-titleID level dataframe

    cast_level_data = pd.melt(scrapped_info_, 
                              id_vars=['IMDB_Title_Code','US_Release_Date',
                                       'Rating'],
                 value_vars = temp.columns)
    
    cast_level_data.dropna(subset=['value'],inplace=True)
    cast_level_data.rename(columns={'value': actor_director}, inplace=True)

    # Calling the helper functions to calculate Average Earnings and ROI
    cast_level_data = create_average_rating(
            cast_level_data, 'Rating', actor_director)

    # Subsetting the required columns
    required_df = cast_level_data[
        ['IMDB_Title_Code', actor_director, 'average_previous_Rating']]
    required_df.dropna(subset=[actor_director],inplace=True)
    # Merging back the dataframe with metrics to the actors/directors info
    # dataframe and converting back to TitleID level dataframe
    for num in range(maxlen):
        scrapped_info_ = pd.merge(scrapped_info_, required_df,
                                  left_on=[actor_director+'_'+str(num),
                                           'IMDB_Title_Code'],
                                  right_on=[actor_director, 'IMDB_Title_Code'],
                                  how='left')
        scrapped_info_.rename(columns={'average_previous_Rating':
                                       actor_director+'_'+str(num)+'_'+'Rating'
                                       },
                              inplace=True)

    # Making a list of only required columns
    required_columns = [str(actor_director)+'_'+str(i) for i in range(maxlen)]
    required_columns.extend(
            [str(actor_director)+'_'+str(i)+'_'+'Rating' for i in range(maxlen)])
    required_columns.extend(['IMDB_Title_Code'])

    # Merging back with the original Base AD dataframe and returning the
    # updated dataframe
    scrapped_info_2 = scrapped_info_[required_columns]
    scrapped_info_2['actors_avg_rating'] = scrapped_info_2.apply(
            lambda x: np.nanmean([x['Actor_0_Rating'], x['Actor_1_Rating'], x['Actor_2_Rating'],
                                  x['Actor_3_Rating']]), axis=1)
    dataframe = pd.merge(
        dataframe, scrapped_info_2, how='left',
        left_on=['IMDB_Title_Code'],
        right_on=['IMDB_Title_Code'])

    return dataframe
