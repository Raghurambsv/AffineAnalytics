# -*- coding: utf-8 -*-
"""
Created on Wed Mar 13 15:09:02 2019

@author: arunav
"""
import numpy as np
import pandas as pd
from libraries import *
from datetime import timedelta


def holiday_flag(base_dataframe, date_col, before_window, after_window):
    """
    Function to create a holiday flag which will be one if there is any holiday
    in the nearby window of the title releasing date

    Parameters
    ----------
    base_dataframe: Pandas Dataframe
        The base dataframe in the flag has to be added. Primary key name must be
        'IMDB_Title_Code'
    date col : String
        Name of the release date col based on format
    before_window: Integer
        The time in days before the release date to be taken into account
    after_window: Integer
        The time in days after the release date to be taken into account

    Returns
    -------
    The upddated dataframe with the new holiday flag added in the base dataframe
    """
    # Converting the date column to datetime type
    holiday_dataframe = pd.read_csv('./US Holiday Calendar_Exhaustive.csv')
    
    try:
        holiday_dataframe['Date'] = pd.to_datetime(holiday_dataframe['Date'], format='%d-%m-%Y')
    except ValueError:
        holiday_dataframe['Date'] = pd.to_datetime(holiday_dataframe['Date'], format='%d-%m-%y')
    
    base_dataframe[date_col] = pd.to_datetime(
            base_dataframe[date_col])

    # Subsetting the required columns to work with
    required_data = base_dataframe.copy()[['IMDB_Title_Code', date_col]]
    # Creating the minimum date for the lower limit of the window
    required_data['Min_Date'] = required_data[date_col].apply(
            lambda x: x-timedelta(before_window-1))
    # Creating the maximum date for the upper limit of the window
    required_data['Max_Date'] = required_data[date_col].apply(
            lambda x: x+timedelta(after_window+1))
    # Creating a list of range of dates from minimum to maximum date
    required_data['Min_Max_Date'] = required_data.apply(
            lambda x: str(np.arange(x['Min_Date'].date(), x['Max_Date'].date())), axis=1)
    # Converting the list of dates to long format, so for every title we have a
    # date range column from minimum to maximum dates
    long_formatted = to_longformat(
            required_data, 'Min_Max_Date', ['IMDB_Title_Code', date_col])
    long_formatted.rename(columns={'value': 'date_range'}, inplace=True)
    long_formatted['date_range'] = long_formatted['date_range'].str.replace("'", "").str.strip()
    long_formatted['date_range'] = pd.to_datetime(long_formatted['date_range'],
                                                  format='%Y-%m-%d')
    # Now merging the holiday dataframe with the long formatted dataframe, to
    # get the holidays for any of the dates in between the window
    long_formatted = pd.merge(long_formatted, holiday_dataframe,
                              left_on='date_range',
                              right_on='Date', how='left')
    # counting the number of holidays in the winddow for each title
    count_of_holidays = long_formatted.groupby('IMDB_Title_Code').agg(
            {'Holiday': 'count'}).reset_index()
    # Creating the flag whcih will be 1 if there are any holidays, if not then o
    count_of_holidays['Holiday'] = count_of_holidays['Holiday'].apply(
            lambda x: 0 if x == 0 else 1)
    # Left joining with the base dataframe to get the new variable in the original
    # dataframe
    base_dataframe = pd.merge(base_dataframe, count_of_holidays, on='IMDB_Title_Code',
                              how='left').rename({'Holiday':'HolidayFlag'}, axis = 1)
    return base_dataframe

def create_weekday_flag():
    """
    function creates bins taking input as day of month and then catergorizing on the basis of window size 7 days
    Args:
    
    Returns:
    averaged school outage in the period of 7 days
    """
    
    Holiday = pd.read_csv('./School_Outage_1718.csv')
    Holiday['School_Outage'] = Holiday.School_Outage.str.replace('%','').astype('float')
    Holiday['Flag'] = pd.cut(Holiday['Day'],
                             bins=[1,7,14,21,28,32],
                             include_lowest=True,
                             labels=[1,2,3,4,5]) 
    outage_data = Holiday.groupby(['Month','Flag'])['School_Outage'].mean().reset_index()
    return outage_data




def avg_school_outage(AD_data, date_column):
    """
    function returns updated AD dataset with school outage variable added to it
    Args:
    AD_data: Dataframe to which school outage column to be added
    date_column: string, name of theatrical release date column
    
    Returns:
    
    """
    
    outage_data = create_weekday_flag()
    
    AD_data[date_column + '_tmp'] = pd.to_datetime(AD_data[date_column])
    AD_data['month'] = AD_data[date_column + '_tmp'].dt.month.astype('int')
    AD_data['day'] = AD_data[date_column + '_tmp'].dt.day
    AD_data['Flag_th'] = pd.cut(AD_data['day'], 
                                   bins=[1,7,14,21,28,32], 
                                   include_lowest=True, 
                                   labels=[1,2,3,4,5])    
    AD_data = pd.merge(left = AD_data, 
                        right = outage_data, 
                        how = 'left', 
                        left_on = ['Flag_th','month'], 
                        right_on = ['Flag','Month']).\
                        drop([date_column + '_tmp' , 'month','day','Flag_th','Flag','Month'], axis = 1).\
                        fillna({'School_Outage' : 100})
    return AD_data
























    



