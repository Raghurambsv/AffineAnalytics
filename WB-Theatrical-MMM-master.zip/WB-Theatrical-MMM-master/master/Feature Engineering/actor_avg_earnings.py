# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 14:35:47 2019

@author: Arunav Saikia
"""

import pandas as pd
import datetime
import numpy as np
from libraries import *


def lead_supp_earnings(modelingAD):
    df = pd.read_csv('./actors_numbers_final.csv')
    df['year'] = list(map(clean_date_to_year_v2, df['Release_Date']))
    df = df[df['year']< 2030]

    df = df.sort_values(
            by=['query_name', 'Role', 'year'])

    df['Gross US'] = df['Gross US'].str.replace('$','').str.replace(',','').astype('float')

    df.dropna(inplace = True)

    table_grouped = df.groupby(['query_name']).agg({'year': ['min','max']}).reset_index()

    table_grouped.columns = ['name', 'min_year','max_year']
  
    table_grouped['min_max_year'] = table_grouped.apply(lambda X: list(np.arange(X['min_year'],X['max_year']+1,1)),axis=1)

    table_grouped.drop(['min_year','max_year'], axis = 1, inplace = True)

    data_new = to_longformat(table_grouped, 'min_max_year',['name'])

    data_new.value = data_new.value.str.replace(',','').astype('float')
       
    final_data = pd.merge(left= data_new, 
                        right = df, 
                        how = 'left', 
                        left_on=['name', 'value'], 
                        right_on =['query_name','year'])

    final_data.fillna({'Role':'None'}, inplace = True)
    df_grouped = final_data[['name','Role','Gross US', 'Movie_Name','value']].groupby(
            ['name','value', 'Role']).agg({'Gross US' : lambda x : sum(x), 
                                    'Movie_Name' : lambda x : np.size(x) }).reset_index()


    df_grouped['count'] = df_grouped.apply(lambda X : 0 if pd.isnull(X['Gross US']) else X['Movie_Name'] , axis = 1)

    df_grouped.drop(['Movie_Name'], axis = 1, inplace = True)

    df_grouped.set_index('value', inplace = True)

    df_grouped.fillna(0, inplace = True)

    table_new = pd.pivot_table(df_grouped, values=['Gross US', 'count'], 
                       index=['name', 'value'], 
                       columns=['Role']).reset_index().fillna(0)

    table_new.columns = ['name','year','Gross_US_Lead','Gross_US_None','Gross_US_Supporting',
                     'count_Lead','count_None','count_Supporting']

    table_new.drop(['Gross_US_None','count_None'], axis = 1, inplace = True)

    table_new.set_index('year', inplace = True)


    df_grouped_rolling = table_new.groupby(['name']).expanding(1).\
            agg({'Gross_US_Lead' : lambda x : sum(x), 'count_Lead' : lambda x : sum(x),
                 'Gross_US_Supporting' : lambda x : sum(x), 'count_Supporting' : lambda x : sum(x)}).reset_index()
            
    df_grouped_rolling['rolling_avg_earnings_lead'] = df_grouped_rolling['Gross_US_Lead']/df_grouped_rolling['count_Lead']
    df_grouped_rolling['rolling_avg_earnings_supporting'] = df_grouped_rolling['Gross_US_Supporting']/df_grouped_rolling['count_Supporting']

    df_grouped_rolling.fillna(0, inplace = True)

    tmp = pd.read_csv('./actors_tmp.csv')
    tmp_2 = pd.merge(left = tmp[['IMDB_Title_Code','Theatrical_Release_Year','Actors','Rank']],
         right = df_grouped_rolling[['name','year','rolling_avg_earnings_lead','rolling_avg_earnings_supporting']],
         left_on = ['Actors','Theatrical_Release_Year'],
         right_on = ['name','year'],
         how = 'left')

    tmp_2.drop(['name','year'], axis = 1, inplace = True)

    tmp_3 = pd.pivot_table(tmp_2, values=['rolling_avg_earnings_lead' ,'rolling_avg_earnings_supporting'], 
                       index=['IMDB_Title_Code'], 
                       columns=['Rank']).reset_index().fillna(0)
   
    tmp_3.columns = ['IMDB_Title_Code', 'Actor_1_rolling_avg_earnings_lead','Actor_2_rolling_avg_earnings_lead',
                    'Actor_3_rolling_avg_earnings_lead', 'Actor_4_rolling_avg_earnings_lead',
                    'Actor_1_rolling_avg_earnings_supporting','Actor_2_rolling_avg_earnings_supporting',
                    'Actor_3_rolling_avg_earnings_supporting', 'Actor_4_rolling_avg_earnings_supporting']
    modelingAD_new = pd.merge(left = modelingAD,
                   right = tmp_3,
                   how = 'left',
                   left_on = 'IMDB_Title_Code',
                   right_on = 'IMDB_Title_Code')
    return modelingAD_new
