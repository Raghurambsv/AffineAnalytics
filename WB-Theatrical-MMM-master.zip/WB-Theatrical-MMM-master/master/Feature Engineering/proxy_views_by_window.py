# -*- coding: utf-8 -*-
"""
Created on Mon Mar 25 12:44:51 2019

@author: amit
"""

import numpy as np
import pandas as pd
from datetime import timedelta


def proxy_views_by_window(base_ad, views_data, list_of_windows):
    """
    Function to get proxy views at the required number of days before theatrical release
    
    Parameters
    ----------
    base_ad: Pandas Dataframe
        The base dataframe in which the metrics are to be populated
    views_data: Pandas Dataframe
        The google trends views data at week level
    list_of_windows: List
        The list of day number before theatrical release on whcih the views
        are to required
        
    Returns
    -------
    The updated base ad with all the new metrics
    """
    # converting date to pandas datetime object
    views_data['Date'] = pd.to_datetime(views_data['Date'], format='%d-%m-%y')
    base_ad['Theatrical_Release_Date'] = pd.to_datetime(
            base_ad['Theatrical_Release_Date'], format='%d-%m-%y')
    base_ad['videoUploadDate'] = pd.to_datetime(
            base_ad['videoUploadDate'], format='%d-%m-%y')
    views_data = views_data[['Date', 'IMDB_Title_Code','proxy_views']]
    required_data = base_ad.copy()[['IMDB_Title_Code', 'Theatrical_Release_Date', 'videoUploadDate']]

    # For all the windows in the list given, making a BO Release minus window date
    for window in list_of_windows:
        required_data[str('Theatre_minus_')+str(window)] = required_data['Theatrical_Release_Date'].apply(
                lambda x: x - timedelta(window))
        required_data[str('Theatre_minus_')+str(window)+str('_window')] = required_data.apply(
                lambda x: (x[str('Theatre_minus_')+str(window)]-x['videoUploadDate']).days, axis=1)
    views_data = pd.merge(views_data, required_data, how='left',
                          on=['IMDB_Title_Code'])

    # Selecting only those google trend hits which are coming before the BO Release minus window date
    for window in list_of_windows:
        views_data['Theatre_minus_'+str(window)+str('_flag')] = views_data.apply(
                lambda x: 1 if x['Date']<x[str('Theatre_minus_')+str(window)] else 0, axis=1)
        temp = views_data.groupby(['IMDB_Title_Code', 'Theatre_minus_'+str(window)+str('_flag')]).agg({
                'proxy_views': 'sum',
                str('Theatre_minus_')+str(window)+str('_window'): 'mean'}).reset_index()
        temp.rename(columns={'proxy_views': 'Theatre_minus_'+str(window)+str('_proxy_views')}, inplace=True)
        temp[str('Theatre_minus_')+str(window)+str('_variable')] = temp[
                'Theatre_minus_'+str(window)+str('_proxy_views')]/temp[str('Theatre_minus_')+str(window)+str('_window')]
        temp = temp.loc[temp['Theatre_minus_'+str(window)+str('_flag')]==1,:]
        temp.drop('Theatre_minus_'+str(window)+str('_flag'), axis=1, inplace=True)
        temp.drop('Theatre_minus_'+str(window)+str('_proxy_views'), axis=1, inplace=True)
        temp.drop(str('Theatre_minus_')+str(window)+str('_window'), axis=1, inplace=True)
        base_ad = pd.merge(base_ad, temp, how='left', on='IMDB_Title_Code')
        
    return base_ad




