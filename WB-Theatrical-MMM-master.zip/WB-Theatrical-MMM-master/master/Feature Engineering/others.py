# -*- coding: utf-8 -*-
"""
Created on Tue Feb 26 13:22:41 2019

@author: Arunav Saikia
"""
import pandas as pd


def create_macro_economic_vars(df, media):
    """
    This function creates marco economic factors like unemployment rate, CPI, GDP 
    at year - month level
    Args:
        df : The dataframe on which to create these variables
        media : list of media like Theatrical/EST/PST for which dates corresponding 
            economic factors are required
    Returns:
        df : New dataframe with the added variables
    """
    economic_data = pd.read_excel('./monthly_macro_economic_data.xlsx', sheet_name = 1)
    for medium in media:
        keys = [medium + '_Release_Year', medium + '_Release_Month']
        df = df.merge(economic_data, \
                  left_on = keys, \
                  right_on = ['Year', 'Month'], \
                  how = 'left').\
            drop(['Month', 'Year', 'Year-Month'], axis = 1)
    
        df.rename({'Unemployment Rates' : medium + '_Unemployment_Rates', \
            'CPI' : medium + '_CPI',\
            'Monthly Nominal GDP Index': medium + '_Monthly_GDP_Index',\
            'Monthly Real GDP Index': medium + '_Monthly_Real_GDP_Index'}, \
            axis='columns', inplace = True)
    return df


def create_release_year_month(df, date_cols):
  """
  This function creates separate cols for year and month from the date
  Args:
    df : The dataframe on which to create these variables
    date_cols : The date cols for which year and month are to be calculated
  Returns:
    df : New dataframe with the added variables

  """
  for col in date_cols:
    base_str = col.split('_Date')[0]

    df[base_str + '_Year'] = pd.DatetimeIndex(df[col]).year
    df[base_str + '_Month'] = pd.DatetimeIndex(df[col]).month
  
  return df


def get_scrapped_data(df):
    """
    This function add IMDB scrapped info at a title level
    Args:
        df : The dataframe on which to create these variables
   Returns:
    df_new : New dataframe with the added variables
   
    """
    IMDB_scrapped_titles = pd.read_csv('./IMDB_scrapped_titles.csv')
    df_new = df.merge(IMDB_scrapped_titles, \
                  left_on = 'IMDB_Title_Code', \
                  right_on = 'titleID', \
                  how = 'left').\
            drop(['titleID', 'Movie.Name', 'US.Release.Date'], axis = 1)
    return df_new
