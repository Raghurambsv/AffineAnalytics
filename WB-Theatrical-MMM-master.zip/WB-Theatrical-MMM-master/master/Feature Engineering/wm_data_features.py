
import pandas as pd
import numpy as np
from datetime import timedelta
from tqdm import tqdm
tqdm.pandas()


def sentiment_metrics_new(base_ad, youtube_data, min_window, max_window):
    """Function to create basic sentiment related variables
    
    Parameters
    ----------
    base_ad: Pandas Dataframe
        The base dataframe in which the variables need to be added
    youtube_data: Pandas Dataframe
        The week level Youtube Data
    min_window: integer
        The starting window before Theatrical Release date that needs to be 
        considered for variables
    max_window: integer
        The ending window before Theatrical Release date that needs to be 
        considered for variables
        
    Returns
    -------
    The updated dataframe with the new variables added to the base ad
    """
    # Converting the date to python datetime object
    youtube_data['post_date'] = pd.to_datetime(youtube_data['post_date'])
    base_ad['Theatrical_Release_Date'] = pd.to_datetime(base_ad['Theatrical_Release_Date'], format='%d-%m-%y')

    # Getting the Theatrical Release date as a column in the youtube data
    youtube_data = pd.merge(youtube_data, base_ad[['IMDB_Title_Code', 'Theatrical_Release_Date']],
                            on='IMDB_Title_Code', how='left')
    youtube_data.dropna(inplace=True)

    # Making a flag which is 1 if the post date is between the window else 0
    youtube_data['window_date'] = youtube_data.apply(
            lambda x: 1 if 
            (x['post_date']<=(x['Theatrical_Release_Date']-timedelta(min_window)))&
            (x['post_date']>=(x['Theatrical_Release_Date']-timedelta(max_window)))else 0, axis=1)
    youtube_data = youtube_data.loc[youtube_data['window_date']==1,:]
    
    # Simple mean, max of the sentiment in the required window
    youtube_sentiment = youtube_data.groupby('IMDB_Title_Code').agg(
            {'sentiment': ['mean', 'max']}).reset_index()

    # Maximum Percentage growth of the sentiment in between the window
    youtube_data.sort_values(by=['IMDB_Title_Code', 'Theatrical_Release_Date'], inplace=True)
    youtube_data[str('lag_')+str('sentiment')] = youtube_data.groupby('IMDB_Title_Code')['sentiment'].shift(1)
    youtube_data[str('max_percentage_growth_')+str('sentiment')+'_'+str(min_window)] = (youtube_data['sentiment']-youtube_data[str('lag_')+str('sentiment')])/youtube_data[str('lag_')+str('sentiment')]
    youtube_variable = youtube_data.groupby('IMDB_Title_Code').agg({str('max_percentage_growth_')+str('sentiment')+'_'+str(min_window): 'max'}).reset_index()
    youtube_variable[str('max_percentage_growth_')+str('sentiment')+'_'+str(min_window)] = youtube_variable[str('max_percentage_growth_')+str('sentiment')+'_'+str(min_window)]*100
    youtube_sentiment.columns=['IMDB_Title_Code', str('sentiment_avg_')+str(min_window), str('sentiment_max_')+str(min_window)]
    youtube_variable = pd.merge(youtube_variable, youtube_sentiment, on='IMDB_Title_Code', how='left')

    # Percentage Growth between min_window and max_window
    sentiment_min = youtube_data.loc[youtube_data.groupby('IMDB_Title_Code')['post_date'].idxmin(),
                                     ['IMDB_Title_Code', 'sentiment']]
    sentiment_min.rename(columns={'sentiment': 'sentiment_min'}, inplace=True)
    sentiment_max = youtube_data.loc[youtube_data.groupby('IMDB_Title_Code')['post_date'].idxmax(),
                                     ['IMDB_Title_Code', 'sentiment']]
    sentiment_max.rename(columns={'sentiment': 'sentiment_max'}, inplace=True)
    combined = pd.merge(sentiment_min,
                        sentiment_max,
                        how='inner',
                        on='IMDB_Title_Code')
    combined['overall_percentage_growth_sentiment_'+str(min_window)] = (combined['sentiment_max']-combined['sentiment_min'])/combined['sentiment_min']
    combined['overall_percentage_growth_sentiment_'+str(min_window)] = combined['overall_percentage_growth_sentiment_'+str(min_window)]*100 
    base_ad = pd.merge(base_ad, youtube_variable,
                       how='left',
                       on='IMDB_Title_Code')
    base_ad = pd.merge(base_ad, combined[['IMDB_Title_Code', 'overall_percentage_growth_sentiment_'+str(min_window)]],
                       how='left',
                       on='IMDB_Title_Code')
    return base_ad


def sentiment_metrics_percentile(base_ad, youtube_data, min_window, max_window):
     """Function to create advanced sentiment variable which is the average of
     the percentile ranks of the recent sentiment
    
    Parameters
    ----------
    base_ad: Pandas Dataframe
        The base dataframe in which the variables need to be added
    youtube_data: Pandas Dataframe
        The week level Youtube Data
    min_window: integer
        The starting window before Theatrical Release date that needs to be 
        considered for variables
    max_window: integer
        The ending window before Theatrical Release date that needs to be 
        considered for variables
        
    Returns
    -------
    The updated dataframe with the new variables added to the base ad
    """
    # Converting the date to python datetime object
    youtube_data['post_date'] = pd.to_datetime(youtube_data['post_date'])
    base_ad['Theatrical_Release_Date'] = pd.to_datetime(base_ad['Theatrical_Release_Date'], format='%d-%m-%y')
    youtube_data = pd.merge(youtube_data, base_ad[['IMDB_Title_Code', 'Theatrical_Release_Date']],
                            on='IMDB_Title_Code', how='left')
    youtube_data.dropna(inplace=True)
    
     # Making a flag which is 1 if the post date is between the window else 0
    youtube_data['window_date'] = youtube_data.apply(
            lambda x: 1 if 
            (x['post_date']<=(x['Theatrical_Release_Date']-timedelta(min_window))) else 0, axis=1)
    
    # Mapping the percentile values of sentiment
    percentile_mapping_data = youtube_data.loc[youtube_data['window_date']==1, :]
    #percentile_mapping_data['sentiment'] = 1-percentile_mapping_data['sentiment']
    percentile_mapping_data['percentile_'+str(min_window)+"_"+str(max_window)] = percentile_mapping_data.groupby('IMDB_Title_Code')['sentiment'].rank(pct=True)
    percentile_mapping_data['window_date'] = percentile_mapping_data.apply(lambda x: 1 if 
                           (x['post_date']>=(x['Theatrical_Release_Date']-timedelta(max_window))) else 0, axis=1)
    percentile_mapping_data = percentile_mapping_data.loc[percentile_mapping_data['window_date']==1,:]
    percentile_mapping_data = percentile_mapping_data.groupby('IMDB_Title_Code').agg(
            {'percentile_'+str(min_window)+"_"+str(max_window): 'mean'}).reset_index()
    base_ad = pd.merge(base_ad, percentile_mapping_data, how='left', on='IMDB_Title_Code')
    return base_ad




def likes_by_views(base_ad, youtube_data, window):
    """Function to create likes by views of the snapshot date
    
    Parameters
    ----------
    base_ad: Pandas Dataframe
        The base dataframe in which the variables need to be added
    youtube_data: Pandas Dataframe
        The week level Youtube Data
    window: integer
        The snapshot date at which the variables is required
        
    Returns
    -------
    The updated dataframe with the new variables added to the base ad
    """
    # Converting the date to python datetime object
    youtube_data['post_date'] = pd.to_datetime(youtube_data['post_date'],)
    base_ad['Theatrical_Release_Date'] = pd.to_datetime(base_ad['Theatrical_Release_Date'], format='%d-%m-%y')
    
    # Getting the Theatrical Release date as a column in the youtube data
    youtube_data = pd.merge(youtube_data, base_ad[['IMDB_Title_Code', 'Theatrical_Release_Date']],
                            on='IMDB_Title_Code', how='left')
    youtube_data.dropna(inplace=True)
    
    # Making a flag which is 1 if the post date is between the window else 0
    youtube_data['window_date'] = youtube_data['Theatrical_Release_Date']-timedelta(window)
    youtube_data['window_date'] = youtube_data.apply(
            lambda x: 1 if (x['Theatrical_Release_Date']-timedelta(window))==x['post_date'] else 0, axis=1)
    youtube_data = youtube_data.loc[youtube_data['window_date']==1,:]
    
    # Creating the likes by views variables
    youtube_data[str('likes_by_views_')+str(window)] = youtube_data['likes']/youtube_data['views']
    base_ad = pd.merge(base_ad, youtube_data[['IMDB_Title_Code', str('likes_by_views_')+str(window)]],
                       how='left',
                       on='IMDB_Title_Code')
    return base_ad


def raw_metrics(base_ad, youtube_data, window):
     """Function to create some basic YT variables at the snapshot date
    
    Parameters
    ----------
    base_ad: Pandas Dataframe
        The base dataframe in which the variables need to be added
    youtube_data: Pandas Dataframe
        The week level Youtube Data
    window: integer
        The snapshot date at which the variables is required
        
    Returns
    -------
    The updated dataframe with the new variables added to the base ad
    """
    # Converting the date to python datetime object
    youtube_data['post_date'] = pd.to_datetime(youtube_data['post_date'],)
    base_ad['Theatrical_Release_Date'] = pd.to_datetime(base_ad['Theatrical_Release_Date'], format='%d-%m-%y')
    
    # Getting the Theatrical Release date as a column in the youtube data
    youtube_data = pd.merge(youtube_data, base_ad[['IMDB_Title_Code', 'Theatrical_Release_Date']],
                            on='IMDB_Title_Code', how='left')
    youtube_data.dropna(inplace=True)
    
    # Making a flag which is 1 if the post date is between the window else 0
    youtube_data['window_date'] = youtube_data.apply(
            lambda x: 1 if (x['Theatrical_Release_Date']-timedelta(window))==x['post_date'] else 0, axis=1)
    youtube_data = youtube_data.loc[youtube_data['window_date']==1,:]
    youtube_data[str('likes_by_videos_')+str(window)] = youtube_data['likes']/youtube_data['videos']
    youtube_data[str('views_by_videos_')+str(window)] = youtube_data['views']/youtube_data['videos']
    youtube_data[str('comments_by_videos_')+str(window)] = youtube_data['comments']/youtube_data['videos']
    youtube_data[str('vidoes_till_date')+str(window)] = youtube_data['videos']
    base_ad = pd.merge(base_ad, youtube_data[['IMDB_Title_Code', str('likes_by_videos_')+str(window),
                                              str('views_by_videos_')+str(window),
                                              str('comments_by_videos_')+str(window)]],
                       how='left',
                       on='IMDB_Title_Code')
    return base_ad
 

def growth_metrics(base_ad, youtube_data, window):
    """Function to create maximum growth variable
    
    Parameters
    ----------
    base_ad: Pandas Dataframe
        The base dataframe in which the variables need to be added
    youtube_data: Pandas Dataframe
        The week level Youtube Data
    window: integer
        The snapshot date at which the variables is required
        
    Returns
    -------
    The updated dataframe with the new variables added to the base ad
    """
    # Converting the date to python datetime object
    youtube_data['post_date'] = pd.to_datetime(youtube_data['post_date'],)
    base_ad['Theatrical_Release_Date'] = pd.to_datetime(base_ad['Theatrical_Release_Date'], format='%d-%m-%y')
    
    # Getting the Theatrical Release date as a column in the youtube data
    youtube_data = pd.merge(youtube_data, base_ad[['IMDB_Title_Code', 'Theatrical_Release_Date']],
                            on='IMDB_Title_Code', how='left')
    youtube_data.dropna(inplace=True)
    
    # Making a flag which is 1 if the post date is between the window else 0
    youtube_data['window_date'] = youtube_data.apply(
            lambda x: 1 if x['post_date']<=(x['Theatrical_Release_Date']-timedelta(window)) else 0, axis=1)
    youtube_data = youtube_data.loc[youtube_data['window_date']==1,:]
    
    youtube_data.sort_values(by=['IMDB_Title_Code', 'Theatrical_Release_Date'], inplace=True)
    for variable in ['likes', 'views', 'comments']:
        youtube_data[str('lag_')+str(variable)] = youtube_data.groupby('IMDB_Title_Code')[variable].shift(1)
        youtube_data[str('growth_')+str(variable)+'_'+str(window)] = youtube_data[variable]-youtube_data[str('lag_')+str(variable)]
        youtube_variable = youtube_data.groupby('IMDB_Title_Code').agg({str('growth_')+str(variable)+'_'+str(window): 'max'}).reset_index()
        base_ad = pd.merge(base_ad, youtube_variable[['IMDB_Title_Code', str('growth_')+str(variable)+'_'+str(window)]],
                                                      how='left',
                                                      on='IMDB_Title_Code')
    
    return base_ad





