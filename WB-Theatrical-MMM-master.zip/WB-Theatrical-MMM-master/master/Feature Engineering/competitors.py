# -*- coding: utf-8 -*-
"""
Created on Thu Mar 14 18:59:51 2019

@author: Amit
"""

import numpy as np
import pandas as pd
from libraries import *
from datetime import timedelta
import date_extraction

def count_of_competitors(base_dataframe, before_window, after_window):
    """
    Function to get the number of competitor movies releasing in the nearby
    window
    Parameters
    ---------
    base_dataframe: Pandas Dataframe
        The original dataframe in which the metric is to be calculated.
        Primary key name must be 'IMDB_Title_Code'
    scrapped_info: Pandas Dataframe
        The exhaustive list of movies dataframe
    before_window: Integer
        The time in days before the release date to be taken into account
    after_window: Integer
        The time in days after the release date to be taken into account
    Returns
    -------
    The updated dataframe with the new column added in the base dataframe   
    """
    scrapped_info = pd.read_csv('./scrapped_info_segments.csv')

    # Extracting the dates out of strings in the scrapped info file
    competitor_info = date_extraction.convert_to_date(scrapped_info)

    # Dropping cases with release date not found
    competitor_info.dropna(subset = ['US_Release_Date'], inplace=True)
    competitor_info.reset_index(inplace=True, drop=True)
    base_dataframe['Theatrical_Release_Date'] = pd.to_datetime(
            base_dataframe['Theatrical_Release_Date'])

    # Subsettin only the required columns to work with
    required_data = scrapped_info.copy()[
            ['IMDB_Title_Code', 'Genre_Budget', 'US_Release_Date']]
    # Creating the minimum date for the lower limit of the window
    required_data['Min_Date'] = required_data['US_Release_Date'].apply(
            lambda x: x-timedelta(before_window-1))
     # Creating the maximum date for the upper limit of the window
    required_data['Max_Date'] = required_data['US_Release_Date'].apply(
            lambda x: x+timedelta(after_window+1))
     # Creating a list of range of dates from minimum to maximum date
    required_data['Min_Max_Date'] = required_data.apply(
            lambda x: str(np.arange(x['Min_Date'].date(), x['Max_Date'].date())), axis=1)
    # Converting the list of dates to long format, so for every title we have a
    # date range column from minimum to maximum dates
    long_formatted = to_longformat(
            required_data, 'Min_Max_Date',
            ['IMDB_Title_Code', 'Genre_Budget', 'US_Release_Date'])
    long_formatted.rename(columns={'value': 'date_range'}, inplace=True)
    long_formatted['date_range'] = long_formatted['date_range'].str.replace("'","").str.strip()
    long_formatted['date_range'] = pd.to_datetime(long_formatted['date_range'],
                  format='%Y-%m-%d')
    # Making the scrapped info file at Genre_Budget and Release Date and getting
    # the number of titles released for each level
    required_comp_info = competitor_info.groupby(['Genre_Budget', 'US_Release_Date']).agg(
            {'IMDB_Title_Code': 'count'}).reset_index()
    required_comp_info.rename(columns={'IMDB_Title_Code': 'count_of_competitor'}, inplace=True)
    # Merging the Genre_Budget Release Date level dataframe with the long format
    # dataframe, so as to get the titles released for each date within the window
    long_formatted = pd.merge(long_formatted, required_comp_info,
                              left_on=['Genre_Budget', 'date_range'],
                              right_on=['Genre_Budget', 'US_Release_Date'],
                              how='left')
    # Getting the total titles released within the window for every title
    count_of_competitor = long_formatted.groupby('IMDB_Title_Code').agg(
            {'count_of_competitor': 'sum'}).reset_index()
    # Subtracting one to get the total competitors since one will be the title itself
    count_of_competitor['count_of_competitor'] = count_of_competitor['count_of_competitor']-1
    
    base_dataframe = pd.merge(base_dataframe, count_of_competitor,
                              left_on='IMDB_Title_Code',
                              right_on='IMDB_Title_Code',
                              how='left')
    return base_dataframe

def last_competitor_release_delta(base_dataframe):
    """
    Function to get the number of days between the movie release date and
    the last competitor movie release date
    Parameters
    ---------
    base_dataframe: Pandas Dataframe
        The original dataframe in which the metric is to be calculated.
        Primary key name must be 'IMDB_Title_Code'
    scrapped_info: Pandas Dataframe
        The exhaustive list of movies dataframe
    Returns
    -------
    The updated dataframe with the new column added in the base dataframe 
    """
    scrapped_info = pd.read_csv('./scrapped_info_segments.csv')

    # Extracting the dates out of strings in the scrapped info file
    competitor_info = date_extraction.convert_to_date(scrapped_info)

    # Dropping cases with release date not found
    competitor_info.dropna(subset = ['US_Release_Date'], inplace=True)
    competitor_info.reset_index(inplace=True, drop=True)
    base_dataframe['Theatrical_Release_Date'] = pd.to_datetime(
            base_dataframe['Theatrical_Release_Date'])

    # Subsetting only the required columns to work with
    required_data = competitor_info.copy()[
            ['IMDB_Title_Code', 'Genre_Budget', 'US_Release_Date', 'Gross_US']]
    required_data.sort_values(['Genre_Budget', 'US_Release_Date'], inplace=True)
    required_data.reset_index(drop=True, inplace=True)
    
    # Creating a lag column for every title whcih will be ORDER BY Genre_Budget
    # and Release Date
    required_data['lag_date'] = required_data.groupby(
            'Genre_Budget')['US_Release_Date'].shift(1)

    # Getting the differencce of dates between current date and the lagged date
    required_data['days_diff'] = required_data.apply(
            lambda x: (x['US_Release_Date']-x['lag_date']).days, axis=1)
    required_data.rename(columns={
            'days_diff': 'last_competitor_release_delta_days'}, inplace=True)
    # Left joining with the base dataframe
    base_dataframe = pd.merge(base_dataframe, 
                              required_data[['IMDB_Title_Code', 'Genre_Budget','last_competitor_release_delta_days']], 
                              on= 'IMDB_Title_Code',
                              how='left')
    return base_dataframe

def historical_earnings(base_dataframe):
    """
    Function to create past metrics of the movie segment
    Parameters
    ---------
    base_dataframe: Pandas Dataframe
        The original dataframe in which the metric is to be calculated.
        Primary key name must be 'IMDB_Title_Code'
    scrapped_info: Pandas Dataframe
        The exhaustive list of movies dataframe
    column: String
        Name of the column whose metric is to be calculated
    movie_segment: String
        Name of the movie segment column
    Returns
    -------
    Pandas Dataframe: The updated base dataframe with historical metrics of the
    movie titles calculated
    """
    scrapped_info = pd.read_csv('./scrapped_info_segments.csv')
    column = 'Gross_US'
    movie_segment = 'Genre_Budget'
    
    # Extracting the dates out of strings in the scrapped info file
    competitor_info = date_extraction.convert_to_date(scrapped_info)

    # Sorting the resultant dataframe so as to calculate cumulative average
    competitor_info = competitor_info.sort_values(
            by=[movie_segment, 'US_Release_Date'])
    competitor_info.reset_index(inplace=True, drop=True)

    # Creating a lagged column of variable, which will be used to calculate
    # cumulative average in the next step
    competitor_info[str('lagged_')+column] = competitor_info.groupby(
            [movie_segment])[column].shift(1)

    # Creating a cumulative average column
    competitor_info_grouped_mean = competitor_info.groupby(
                [movie_segment],
                as_index=False)[str('lagged_')+column].expanding(1).mean()
    # Creating a cumulative median column
    competitor_info_grouped_median = competitor_info.groupby(
                [movie_segment],
                as_index=False)[str('lagged_')+column].expanding(1).median()
    competitor_info_grouped_mean.reset_index(inplace=True, drop=True)
    competitor_info_grouped_median.reset_index(inplace=True, drop=True)
    # Subsetting the mean and median columns
    competitor_info[str('average_previous_')+column] = competitor_info_grouped_mean
    competitor_info[str('median_previous_')+column] = competitor_info_grouped_median
    competitor_info = competitor_info[
            ['IMDB_Title_Code', str('average_previous_')+column, str('median_previous_')+column]]
    # Left joining with the base dataframe to get the mean and median metrics
    # in the original dataframe
    base_dataframe = pd.merge(base_dataframe, competitor_info, on='IMDB_Title_Code',
                              how='left')
    
    return base_dataframe
    
