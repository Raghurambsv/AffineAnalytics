import pandas as pd
from libraries import *
import numpy as np


def cast_score(Base_AD):
    
    score_data = pd.read_csv('./actors_metrics.csv')
    
    Actors_data = Base_AD[['IMDB_Title_Code', 'ActorsURL','Theatrical_Release_Year']]

	
    temp = to_longformat(Actors_data, 'ActorsURL',['IMDB_Title_Code','Theatrical_Release_Year'])
	
    temp.columns = ['IMDB_Title_Code', 'Release_year','Actors']
	
    temp['Release_year_1'] = temp['Release_year'] - 1
    
    score_data['URL']="'" + score_data.URL + "'"

    final_data = pd.merge(left = temp, 
                       right = score_data[['URL','year','Star_Scores', 'Average_Billing']], 
                       how='left',
                       left_on = ['Actors','Release_year_1'], 
                       right_on = ['URL','year'])
	
    title_score_billing = final_data.groupby('IMDB_Title_Code').agg({'Star_Scores':
                                                        {'Mean_Score': np.mean, 'Median_Score': np.median},
                                                    'Average_Billing': 
                                                        {'Mean_Billing': np.mean, 'Median_Billing': np.median},}).\
                                                            reset_index()
    
    title_score_billing.columns = ['IMDB_Title_Code', 'Mean_Score', 'Median_Score', 'Mean_Billing', 'Median_Billing']
    df = pd.merge(left = Base_AD,
             right = title_score_billing,
             how = 'left',
             left_on = 'IMDB_Title_Code',
             right_on = 'IMDB_Title_Code')
    return df	
