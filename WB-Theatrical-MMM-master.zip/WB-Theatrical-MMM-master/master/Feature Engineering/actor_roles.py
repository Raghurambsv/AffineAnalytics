# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 16:07:29 2019

@author: Arunav Saikia
"""

import pandas as pd
import datetime
import numpy as np
from libraries import *
from actor_info_from_numbers import * 

def count_lead_supp_roles(modelingAD):
    try:
        df = pd.read_csv('./actors_numbers_final.csv')
    except:
        df = scrape_actors_movies_from_numbers(modelingAD)
    
    df['year'] = list(map(clean_date_to_year_v2, df['Release_Date']))
    
    df = df[df['year'] < 2030]

    table = pd.pivot_table(df, values = 'Movie_Name', 
                           index = ['query_name', 'year'], 
                           columns = ['Role'], 
                           aggfunc=np.size).reset_index().fillna(0)

    table['Roles'] = table['Lead'] + table['Supporting']

    table_grouped = table.groupby('query_name').agg({'year': ['min','max']}).reset_index()
    table_grouped.columns = ['name', 'min_year','max_year']

    table_grouped['min_max_year'] = table_grouped.apply(lambda X: np.arange(X['min_year'],X['max_year']+1,1),axis=1)

    table_grouped.drop(['min_year','max_year'], axis =1, inplace = True)

    data_new = to_longformat(table_grouped, 'min_max_year',['name'])


    data_new.value = data_new.value.astype('float')

   
    final_data = pd.merge(left= data_new, 
                          right = table, 
                          how = 'left', 
                          left_on=['name', 'value'], 
                          right_on =['query_name', 'year'])

    fsf = final_data[['name', 'value', 'Lead', 'Supporting', 'Roles']].fillna(0)

    Roles = ['Lead' ,'Supporting', 'Roles']
    for role in Roles:
        fsf['rolling_no_of_' + role.lower()] = fsf.groupby(['name'])[role].\
                                                expanding(min_periods = 1).sum().reset_index(0, drop = True)

        fsf['rolling_no_of_'+role.lower()+'_5'] = fsf.groupby(['name'])[role].\
                                                rolling(window = 5, min_periods = 1).sum().reset_index(0, drop = True)

    fsf['rolling_%_leads'] = fsf['rolling_no_of_lead']/fsf['rolling_no_of_roles']
    fsf['rolling_%_supporting'] = fsf['rolling_no_of_supporting']/fsf['rolling_no_of_roles']
    
    
    df_tmp = modelingAD[['IMDB_Title_Code','Theatrical_Release_Year','Actors']]
    df_tmp_2  = to_longformat_v2(df_tmp, 'Actors',['IMDB_Title_Code','Theatrical_Release_Year'])
    df_tmp_2['Actors'] = df_tmp_2['value'].str.replace("'","").str.strip()
    df_tmp_2['Theatrical_Release_Year'] = df_tmp_2['Theatrical_Release_Year'] - 1
    df_tmp_2.drop('value', axis = 1, inplace = True)
    
    final_df = pd.merge(left= df_tmp_2, 
                      right = fsf, 
                      how = 'left', 
                      left_on=['Theatrical_Release_Year', 'Actors'], 
                      right_on =['value', 'name']) 
    final_df['Rank'] = final_df.groupby(by=['IMDB_Title_Code'])\
                    ['rolling_no_of_roles'].rank(method='first', ascending = False, na_option = 'bottom')
    final_df.to_csv('./actors_tmp.csv',index = False)

    table_new = pd.pivot_table(final_df, values=['rolling_no_of_lead' ,'rolling_no_of_supporting',
                                                'rolling_no_of_lead_5', 'rolling_no_of_supporting_5',
                                                'rolling_no_of_roles','rolling_no_of_roles_5'], 
                           index=['IMDB_Title_Code'], 
                           columns=['Rank']).reset_index().fillna(0)
   
    table_new.columns = ['IMDB_Title_Code', 'Actor_1_rolling_leads','Actor_2_rolling_leads',
                        'Actor_3_rolling_leads', 'Actor_4_rolling_leads',
                        'Actor_1_rolling_leads_5','Actor_2_rolling_leads_5',
                        'Actor_3_rolling_leads_5', 'Actor_4_rolling_leads_5',
                        'Actor_1_rolling_roles','Actor_2_rolling_roles',
                        'Actor_3_rolling_roles', 'Actor_4_rolling_roles',
                        'Actor_1_rolling_roles_5','Actor_2_rolling_roles_5',
                        'Actor_3_rolling_roles_5', 'Actor_4_rolling_roles_5',
                        'Actor_1_rolling_supporting','Actor_2_rolling_supporting',
                        'Actor_3_rolling_supporting', 'Actor_4_rolling_supporting',
                        'Actor_1_rolling_supporting_5','Actor_2_rolling_supporting_5',
                        'Actor_3_rolling_supporting_5', 'Actor_4_rolling_supporting_5']
    modelingAD_new = pd.merge(left = modelingAD,
                   right = table_new,
                   how = 'left',
                   left_on = 'IMDB_Title_Code',
                   right_on = 'IMDB_Title_Code')
    return modelingAD_new
