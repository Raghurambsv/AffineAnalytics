# -*- coding: utf-8 -*-
"""
Created on Tue Feb 26 13:22:54 2019

@author: Arunav Saikia
"""



import pandas as pd
import numpy as np
import others
import franchise
import libraries
import youtube
import holiday_metrics
import competitors
import actor_roles
import actor_avg_earnings

baseAD = pd.read_excel('./HE_master_AD_WB_v1.2.xlsx')

## Preprocessing
baseAD.rename({'Genre' : 'Raw_Genre'}, axis='columns', inplace = True)

baseAD = others.create_release_year_month(baseAD, ['Theatrical_Release_Date', 'EST_Release_Date', \
                                            'PST_Release_Date'])

df_1 = franchise.franchise_flag(baseAD)

df_2 = others.get_scrapped_data(df_1)

df_3 = others.create_macro_economic_vars(df_2, ['Theatrical', 'EST', 'PST'])

df_4 = franchise.count_of_movies_in_franchise(df_3, 3)

df_5 = franchise.last_release_duration(df_4)

df_6 = youtube.get_trailer_stats(df_5)

df_7 = franchise.get_average_earnings(df_6)

df_8 = holiday_metrics.holiday_flag(df_7, 'EST_Release_Date', 5, 5)

df_9 = holiday_metrics.avg_school_outage(df_8, 'EST_Release_Date')

df_10 = competitors.count_of_competitors(df_9, 5 ,5) 

df_11 = competitors.last_competitor_release_delta(df_10)

df_12 = competitors.historical_earnings(df_11)

df_13 = actor_roles.count_lead_supp_roles(df_12)

df_14 = avg_earnings.lead_supp_earnings(df_13)

df_14['HE_Spend'] = df_14['EST_Media_Spend'] + df_14['PST_Media_Spend']
df_14['HE_Revenue'] = df_14['EST_Revenue'] + df_14['PST_Revenue']
df_14['Runtime'] = df_14['Runtime'].str.replace(' min','').astype('int')

df_15 = df_14[['IMDB_Title_Code',	'Movie_Title',	'BO_Window',	'Theatrical_Release_Date',	
               'EST_Release_Date',	'PST_Release_Date',	'BO_Media_Spend',	'HE_Spend',	'BO_Revenue',	
               'HE_Revenue',	'Theatrical_Release_Month',	'Theatrical_Release_Year',	'EST_Release_Month',	
               'EST_Release_Year',	'PST_Release_Month',	'PST_Release_Year',	'franchise_flag',	
               'MajorFranchise',	'Budget',	'Runtime',	'MPAA_rating',	'Genre',	
               'Theatrical_Unemployment_Rates',	'Theatrical_CPI',	'Theatrical_Monthly_GDP_Index',	
               'Theatrical_Monthly_Real_GDP_Index',	'EST_Unemployment_Rates',	'EST_CPI',	
               'EST_Monthly_GDP_Index',	'EST_Monthly_Real_GDP_Index',	'PST_Unemployment_Rates',	
               'PST_CPI',	'PST_Monthly_GDP_Index',	'PST_Monthly_Real_GDP_Index',	
               'franchise_releases_in_last_3_years',	'time_delta_since_last_franchise_release',	
               'videoUploadDate',	'trailer window',	'views_count',	'likes_count',	'dislikes_count',	
               'comments_count',	'avg_earnings_franchise',	'HolidayFlag',	'School_Outage',	
               'count_of_competitor',	'Genre_Budget',	'last_competitor_release_delta_days',	
               'average_previous_Gross_US',	'median_previous_Gross_US','Actor_1_rolling_leads',
               'Actor_2_rolling_leads','Actor_3_rolling_leads', 'Actor_4_rolling_leads',
               'Actor_1_rolling_leads_5','Actor_2_rolling_leads_5',
               'Actor_3_rolling_leads_5', 'Actor_4_rolling_leads_5',
               'Actor_1_rolling_roles','Actor_2_rolling_roles',
               'Actor_3_rolling_roles', 'Actor_4_rolling_roles',
               'Actor_1_rolling_roles_5','Actor_2_rolling_roles_5',
               'Actor_3_rolling_roles_5', 'Actor_4_rolling_roles_5',
               'Actor_1_rolling_supporting','Actor_2_rolling_supporting',
               'Actor_3_rolling_supporting', 'Actor_4_rolling_supporting',
               'Actor_1_rolling_supporting_5','Actor_2_rolling_supporting_5',
               'Actor_3_rolling_supporting_5', 'Actor_4_rolling_supporting_5',
               'Actor_1_rolling_avg_earnings_lead','Actor_2_rolling_avg_earnings_lead',
               'Actor_3_rolling_avg_earnings_lead', 'Actor_4_rolling_avg_earnings_lead',
               'Actor_1_rolling_avg_earnings_supporting','Actor_2_rolling_avg_earnings_supporting',
               'Actor_3_rolling_avg_earnings_supporting', 'Actor_4_rolling_avg_earnings_supporting']]

df_15.to_excel('./WB_HE_modelingAD_v4.xlsx', index = False)

