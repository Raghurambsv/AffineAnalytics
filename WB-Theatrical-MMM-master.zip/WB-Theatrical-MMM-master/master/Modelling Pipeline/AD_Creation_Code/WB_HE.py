# author=Hanaa Khan

# set local path for synced sharepoint
sharepoint_path = r'C:/Users/hanaa/Affine Analytics Pvt Ltd/'

# importing packages
import pandas as pd
import csv
# importing datasets
import numpy as np
HE_Sales = pd.read_csv(filepath_or_buffer=r"C:\Users\hanaa\Desktop\HE_sales_v2.csv",
                       sep = ',',
                       encoding = 'latin-1')
Comp_Release_Schedule=pd.read_csv(r"C:\Users\hanaa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Comp_Release_Schedule_v3.1.csv",
                     sep=',',
                     encoding='latin-1')

Total_Theater_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Total_Theater_Sales_v3.csv",
                                  sep = ',',
                                  encoding = 'latin-1')
jim_Spending = pd.read_excel(r"C:\Users\hanaa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Media Spends Data_Jim_v1.0.xlsx",
                        sheetname="Theatrical")
jim_HE_Spending = pd.read_excel(r"C:\Users\hanaa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Media Spends Data_Jim_v1.0.xlsx",
                        sheetname="Home Ent.")
imdb_scrapped= pd.read_csv(r"C:\Users\hanaa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\External Sources\IMDB_scrapped_titles.csv",
                                  sep = ',',
                                  encoding = 'latin-1')
#Getting the list of 134 titles
titles=list(jim_Spending["IMDB_Title_Code"])

#Correcting date formats(datetime format kept as YYYY-MM-DD)
HE_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=HE_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=HE_Sales['Blu-ray_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['DVD_Street_Date'] = pd.to_datetime(arg=HE_Sales['DVD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['EST_Street_Date'] = pd.to_datetime(arg=HE_Sales['EST_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['cVOD_Street_Date'] = pd.to_datetime(arg=HE_Sales['cVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['iVOD_Street_Date'] = pd.to_datetime(arg=HE_Sales['iVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
Total_Theater_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Total_Theater_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['Theatrical_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['Theatrical_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['EST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['EST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['VOD_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['VOD_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Rental_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Rental_Release'], infer_datetime_format=True, errors="coerce")

#Subsetting the imported files
HE_Sales= HE_Sales.loc[HE_Sales['IMDB_Title_Code'].isin(titles)]
title_lt=list(HE_Sales["IMDB_Title_Code"])
odd_title =list( np.setdiff1d(titles,title_lt))
imdb_scrapped= imdb_scrapped.loc[imdb_scrapped['IMDB_Title_Code'].isin(titles)]
Total_Theater_Sales= Total_Theater_Sales.loc[Total_Theater_Sales['IMDB_Title_Code'].isin(titles)]
jim_HE_Spending= jim_HE_Spending.loc[jim_HE_Spending['IMDB_Title_Code'].isin(titles)]
df_new = pd.DataFrame({'IMDB_Title_Code':odd_title})
# HE_Sales['IMDB_Title_Code']= HE_Sales['IMDB_Title_Code'].append(odd_title)
HE_Sales = (pd.concat([HE_Sales, df_new], ignore_index=True)
        .reindex(columns=HE_Sales.columns))

#Merging HE sales with IMDB scrapped file
HE_Sales = pd.merge(left=HE_Sales,
                    right=imdb_scrapped[['IMDB_Title_Code',
                                                 'Gross_US',
                                         'US.Release.Date',
                                                 'OpeningWeekendUS',
                                                 ]],
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    how='left',
                    sort=True,
                    copy=False)

#Merging HE sales with Comp_Release_Schedule
HE_Sales = pd.merge(left=HE_Sales,
                    right=Comp_Release_Schedule[['IMDB_Title_ID',
                                                 'Theatrical_Release',
                                                 'EST_Release',
                                                 'PST_Release']],
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_ID'],
                    how='left',
                    sort=True,
                    copy=False)

#Merging HE sales with Total_Theater_sales
master_AD = HE_Sales.merge(right = Total_Theater_Sales[['IMDB_Title_Code',
                                                        'Theatrical_Release_Date',
                                                         'Native_BO_2D_Amount',
                                                         'Native_BO_3D_Amount',
                                                         'Native_BO_3D_IMAX_Amount',
                                                         'Native_BO_IMAX_Amount',
                                                         'Opening_Weekend_BO',
                                                         'Opening_Weekend_Runs']],
                            how ='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)

#Finding the EST & PST Release Dates
master_AD["EST_Release Date"] = master_AD[['EST_Street_Date','cVOD_Street_Date','iVOD_Street_Date']].min(axis=1)
master_AD["PST_Release Date"] = master_AD[['Blu-ray_Street_Date','DVD_Street_Date']].min(axis=1)
master_AD.drop(['EST_Street_Date','cVOD_Street_Date','iVOD_Street_Date','Blu-ray_Street_Date','DVD_Street_Date'], axis=1, inplace=True)

#Filling in Theatrical Release dates from Total Theater sales & EST/PST dates from Comp_Release_Schedule
master_AD['Theatrical_Release_Date_x'] = master_AD.apply(
    lambda x: x['Theatrical_Release'] if pd.isnull(x['Theatrical_Release_Date_x']) else x['Theatrical_Release_Date_x'],
    axis=1)
master_AD['EST_Release Date'] = master_AD.apply(
    lambda x: x['EST_Release'] if pd.isnull(x['EST_Release Date']) else x['EST_Release Date'],
    axis=1)
master_AD['PST_Release Date'] = master_AD.apply(
    lambda x: x['PST_Release'] if pd.isnull(x['PST_Release Date']) else x['PST_Release Date'],
    axis=1)
master_AD.drop(['EST_Release','PST_Release'], axis=1,inplace=True)

#Rolling up the Home Ent. dat at a IMDB Title Code level
jim_HE_Spending=jim_HE_Spending.groupby(['IMDB_Title_Code']).agg({'Media_Spends' : 'sum'}).reset_index()

#Merging jim spending with master_AD
master_AD = master_AD.merge(right = jim_Spending[['IMDB_Title_Code','Movie_Name','Total_Media_Spends']],
                            how ='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)

master_AD = master_AD.merge(right = jim_HE_Spending[['IMDB_Title_Code','Media_Spends']],
                            how ='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)


del HE_Sales, jim_Spending,jim_HE_Spending, Total_Theater_Sales # dropping unnecessary objects to free memory

#Filling in missing Theatrical release date from Total Theater sales
master_AD['Theatrical_Release_Date_x'] = master_AD.apply(
    lambda x: x['Theatrical_Release_Date_y'] if pd.isnull(x['Theatrical_Release_Date_x']) else x['Theatrical_Release_Date_x'],
    axis=1)



# calculating Revenues
master_AD['BO_Revenue'] = master_AD[['Native_BO_2D_Amount',
                                     'Native_BO_3D_Amount',
                                     'Native_BO_3D_IMAX_Amount',
                                     'Native_BO_IMAX_Amount']].sum(axis = 1)
master_AD['EST_Revenue'] = master_AD[['EST_Revenue',
                                      'cVOD_Revenue',
                                      'iVOD_Revenue']].sum(axis = 1)
master_AD['PST_Revenue'] = master_AD[['Blu-ray_Revenue',
                                      'DVD_Revenue']].sum(axis = 1)
#Filling in missing BO_Revenue from IMDB Scrapped file
master_AD['BO_Revenue'] = master_AD.apply(
    lambda x: x['Gross_US'] if (x['BO_Revenue'])==0 else x['BO_Revenue'],
    axis=1)
# calculating tickets sold
master_AD['EST_Sold'] = master_AD[['EST_Sold',
                                   'cVOD_Sold',
                                   'iVOD_Sold']].sum(axis = 1)
master_AD['PST_Sold'] = master_AD[['Blu-ray_Sold',
                                   'DVD_Sold']].sum(axis = 1)

# getting only one Studio
master_AD.rename(columns={'EST_Studio' : 'EST_Studio_old'},
                 inplace=True)
################
##Here 3 conditions are being checked for each format:
#if atleast one channel has a studio in the particular format then Warner is given


##################
#Empty columns are created
master_AD['EST_Studio'] = None
master_AD['PST_Studio'] = None
for i in range(master_AD.shape[0]):
    if len(pd.unique(master_AD.loc[i, ['EST_Studio_old', 'cVOD_Studio', 'iVOD_Studio']].dropna())) != 0:
        master_AD.loc[i, ['EST_Studio']] =['WARNER']
    if len(pd.unique(master_AD.loc[i, ['DVD_Studio', 'Blu-ray_Studio']].dropna())) != 0 :
        master_AD.loc[i, ['PST_Studio']] = ['WARNER']
del i # dropping unnecessary objects to free memory

# calculating BO Window
master_AD['HE_Release_Date'] = master_AD[['EST_Release Date',
                                          'PST_Release Date',
                                          ]].min(axis = 1)
master_AD['Theatrical_Release_Date_x'] = master_AD['Theatrical_Release_Date_x'].apply(pd.to_datetime)
print(master_AD['HE_Release_Date'].dtypes)
print(master_AD['Theatrical_Release_Date_x'].dtypes)
master_AD['BO_Window'] = (master_AD['Theatrical_Release_Date_x'] - master_AD['HE_Release_Date'])/pd.offsets.Day(-1)

#Assigning the Theatrical Studio as Warner
master_AD["Theatrical_Studio"]="Warner"
master_AD["PST_Media_Spend"]=0

# preparing columns and keeping column consistency
master_AD = master_AD[['IMDB_Title_Code', 'Movie_Name',
                       'Theatrical_Studio', 'EST_Studio', 'PST_Studio',
                       'Theatrical_Release_Date_x', 'EST_Release Date', 'PST_Release Date', 'BO_Window',
                       'Total_Media_Spends', 'Media_Spends','PST_Media_Spend',
                       'BO_Revenue', 'EST_Revenue', 'PST_Revenue',
                       'EST_Sold', 'PST_Sold',
                       'Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount',
                       'Opening_Weekend_BO', 'Opening_Weekend_Runs']]
master_AD.rename(columns = {'Movie_Name' : 'Movie_Title',
                            'Theatrical_Release_Date_x':'Theatrical_Release_Date',
                            'Media_Spends' : 'EST_Media_Spend',
                            'Total_Media_Spends' : 'BO_Media_Spend'},
                 inplace = True)


master_AD.drop_duplicates(inplace=True) # removing duplicate rows (if any)
he_v1=master_AD
he_v1.to_csv(r"C:\Users\hanaa\Desktop\he_v1.csv")
# exporting dataset
master_AD.to_csv(path_or_buf=sharepoint_path+r'WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\HE ADs\HE_base_AD_WB_v1.5.csv',
                 index = False)

