# author=Hanaa Khan
import pandas as pd
import numpy as np
# set local path for synced sharepoint
sharepoint_path = r'C:/Users/hanaa/Affine Analytics Pvt Ltd/'

# importing datasets
HE_Sales = pd.read_csv(filepath_or_buffer=r"C:\Users\hanaa\Desktop\HE_sales_v2.csv",
                       sep = ',',
                       encoding = 'latin-1')
Comp_Release_Schedule=pd.read_csv(r"C:\Users\hanaa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Comp_Release_Schedule_v3.1.csv",
                     sep=',',
                     encoding='latin-1')
jim_Spending = pd.read_excel(r"C:\Users\hanaa\Desktop\(JIM)_Media Spends Data_Jim_v1.0 _PC.xlsx",
                        sheetname="Theatrical")
                            # sep = ',',
                            # encoding = 'latin-1')
Total_Theater_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Total_Theater_Sales_v3.csv",
                                  sep = ',',
                                  encoding = 'latin-1')
imdb_scrapped= pd.read_csv(r"C:\Users\hanaa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\External Sources\IMDB_scrapped_titles.csv",
                                  sep = ',',
                                  encoding = 'latin-1')


#Getting the list of 134 titles
titles=list(jim_Spending["IMDB_Title_Code"])

#Correcting date formats(datetime format kept as YYYY-MM-DD)
HE_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=HE_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=HE_Sales['Blu-ray_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['DVD_Street_Date'] = pd.to_datetime(arg=HE_Sales['DVD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['EST_Street_Date'] = pd.to_datetime(arg=HE_Sales['EST_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['cVOD_Street_Date'] = pd.to_datetime(arg=HE_Sales['cVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['iVOD_Street_Date'] = pd.to_datetime(arg=HE_Sales['iVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
Total_Theater_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Total_Theater_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['Theatrical_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['Theatrical_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['EST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['EST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['VOD_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['VOD_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Rental_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Rental_Release'], infer_datetime_format=True, errors="coerce")

#Subsetting the imported files
HE_Sales= HE_Sales.loc[HE_Sales['IMDB_Title_Code'].isin(titles)]
title_lt=list(HE_Sales["IMDB_Title_Code"])
odd_title =list( np.setdiff1d(titles,title_lt))
Total_Theater_Sales= Total_Theater_Sales.loc[Total_Theater_Sales['IMDB_Title_Code'].isin(titles)]
Comp_Release_Schedule= Comp_Release_Schedule.loc[Comp_Release_Schedule['IMDB_Title_ID'].isin(titles)]
imdb_scrapped= imdb_scrapped.loc[imdb_scrapped['IMDB_Title_Code'].isin(titles)]

#Adding the IMDB Title codes of 7 odd titles
df_new = pd.DataFrame({'IMDB_Title_Code':odd_title})
HE_Sales = (pd.concat([HE_Sales, df_new], ignore_index=True)
        .reindex(columns=HE_Sales.columns))

#Merging HE sales with IMDB scrapped file
HE_Sales = pd.merge(left=HE_Sales,
                    right=imdb_scrapped[['IMDB_Title_Code',
                                                 'Gross_US',
                                         'US.Release.Date',
                                                 'OpeningWeekendUS',
                                                 ]],
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    how='left',
                    sort=True,
                    copy=False)

#Merging HE sales with Comp_Release_Schedule
HE_Sales = pd.merge(left=HE_Sales,
                    right=Comp_Release_Schedule[['IMDB_Title_ID',
                                                 'Theatrical_Release',
                                                 'EST_Release',
                                                 'PST_Release']],
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_ID'],
                    how='left',
                    sort=True,
                    copy=False)

#Merging HE sales with Total_Theater_sales
master_AD = HE_Sales.merge(right = Total_Theater_Sales[['IMDB_Title_Code',
                                                        'Theatrical_Release_Date',
                                                         'Native_BO_2D_Amount',
                                                         'Native_BO_3D_Amount',
                                                         'Native_BO_3D_IMAX_Amount',
                                                         'Native_BO_IMAX_Amount',
                                                         'Opening_Weekend_BO',
                                                         'Opening_Weekend_Runs']],
                            how ='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)

#Finding the EST & PST Release Dates
master_AD["EST_Release Date"] = master_AD[['EST_Street_Date','cVOD_Street_Date','iVOD_Street_Date']].min(axis=1)
master_AD["PST_Release Date"] = master_AD[['Blu-ray_Street_Date','DVD_Street_Date']].min(axis=1)
master_AD.drop(['EST_Street_Date','cVOD_Street_Date','iVOD_Street_Date','Blu-ray_Street_Date','DVD_Street_Date'], axis=1, inplace=True)

#Merging jim spending with master_AD
master_AD = master_AD.merge(right = jim_Spending[['IMDB_Title_Code',
                                                         'Movie_Name',
                                                         'Total_Media_Spends']],
                            how ='left',
                            left_on = ['IMDB_Title_Code'],
                            right_on = ['IMDB_Title_Code'],
                            sort = True,
                            copy = False)

del HE_Sales, jim_Spending, Total_Theater_Sales # dropping unnecessary objects to free memory

#Filling in Theatrical Release dates from Total Theater sales & EST/PST dates from Comp_Release_Schedule
master_AD['Theatrical_Release_Date_x'] = master_AD.apply(
    lambda x: x['Theatrical_Release_Date_y'] if pd.isnull(x['Theatrical_Release_Date_x']) else x['Theatrical_Release_Date_x'],
    axis=1)

master_AD['EST_Release Date'] = master_AD.apply(
    lambda x: x['EST_Release'] if pd.isnull(x['EST_Release Date']) else x['EST_Release Date'],
    axis=1)
master_AD['PST_Release Date'] = master_AD.apply(
    lambda x: x['PST_Release'] if pd.isnull(x['PST_Release Date']) else x['PST_Release Date'],
    axis=1)

# calculating BO Revenue
master_AD['BO_Revenue'] = master_AD[['Native_BO_2D_Amount',
                                     'Native_BO_3D_Amount',
                                     'Native_BO_3D_IMAX_Amount',
                                     'Native_BO_IMAX_Amount']].sum(axis = 1)
#Filling in Theatrical Release Date and BO_Revenue,Opening_Weekend_BO from IMDB Scrapped file
master_AD['Theatrical_Release_Date_x'] = master_AD.apply(
    lambda x: x['US.Release.Date'] if (x['BO_Revenue'])==0 else x['Theatrical_Release_Date_x'],
    axis=1)
master_AD['BO_Revenue'] = master_AD.apply(
    lambda x: x['Gross_US'] if (x['BO_Revenue'])==0 else x['BO_Revenue'],
    axis=1)
master_AD['Opening_Weekend_BO'] = master_AD.apply(
    lambda x: x['OpeningWeekendUS'] if (x['Opening_Weekend_BO'])==0 else x['Opening_Weekend_BO'],
    axis=1)



# calculating BO Window
master_AD['HE_Release_Date'] = master_AD[['EST_Release Date',
                                          'PST_Release Date',
                                          ]].min(axis = 1)
master_AD['Theatrical_Release_Date_x'] = master_AD['Theatrical_Release_Date_x'].apply(pd.to_datetime)
print(master_AD['HE_Release_Date'].dtypes)
print(master_AD['Theatrical_Release_Date_x'].dtypes)
master_AD['BO_Window'] = (master_AD['Theatrical_Release_Date_x'] - master_AD['HE_Release_Date'])/pd.offsets.Day(-1)

#Assigning the Theatrical studio as Warner
master_AD["Theatrical_Studio"]="Warner"

# preparing columns and keeping column consistency
master_AD = master_AD[['IMDB_Title_Code', 'Movie_Name',
                       'Theatrical_Release_Date_x','HE_Release_Date',
                       'Theatrical_Studio',
                       'Total_Media_Spends', 'BO_Revenue', 'BO_Window',
                       'Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount',
                       'Opening_Weekend_BO', 'Opening_Weekend_Runs']]

master_AD.rename(columns = {'Movie_Name': 'Movie_Title',
                            'Theatrical_Release_Date_x':'Theatrical_Release_Date',
                            'Total_Media_Spends' : 'BO_Media_Spend'},
                 inplace = True)

master_AD.drop_duplicates(inplace=True) # removing duplicate rows (if any)=master_AD

# exporting dataset
master_AD.to_csv(path_or_buf=sharepoint_path+r'WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\BO ADs\BO_base_AD_WB_v1.5.csv',
                 index = False)
