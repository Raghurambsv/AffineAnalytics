# -*- coding: utf-8 -*-
"""
Created on Thu Mar 28 13:59:39 2019

@author: amit
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
import statsmodels.api as sm
from BaselineIteration import BaselineIteration
from SubsetIteration import SubsetIteration

def train_test_snapshot(modelling_ad, list_of_columns, Print):
    """
    Function to output the train test results of the proxy view snapshots
    Parameters
    ----------
    modelling_ad: Pandas Dataframe
        The AD with all the pre processing applied and all the required columns
        along with Title code and Title Name. The ad must also have the proxy
        views window columns
    list_of_columns: List of column names
        The list of names of the column with only the names of the proxy views
        window columns in the order of increasing window number. For Eg: it  should
        look something like ['Theatre_minus_45_variable',
        'Theatre_minus_60_variable','Theatre_minus_75_variable','Theatre_minus_90_variable']
    Print: Bool
        Whether to print the results of the train and test predictions
    
    Returns
    -------
    Pandas dataframe with all the variables and statistical results such as
    Beta values, pvalues, etc
    """
    train_data = modelling_ad.copy().dropna(subset=list_of_columns)
    validation_data = modelling_ad.loc[~modelling_ad['IMDB_Title_Code'].isin(train_data['IMDB_Title_Code'])]
    x_train =  train_data.drop(['HE_Revenue'], axis=1)
    results_df = pd.DataFrame()
    for num, col in enumerate(reversed(list_of_columns)):
        if num==0:
            continue
        x_test = validation_data.copy().dropna(subset=[col])
        x_test_actuals = x_test['HE_Revenue']
        x_test.drop(['HE_Revenue'], axis=1, inplace=True)
        x_test.fillna(0, inplace=True)
        column_list = x_test.drop(['IMDB_Title_Code', 'Movie_Title'], axis=1).columns.values
        instance = SubsetIteration(x_train, train_data['HE_Revenue'], x_test, x_test_actuals,
                                  column_list, Print=Print)
        results = instance.run_iteration()
        results['ID'] = num
        results_df = pd.concat([results_df, results], axis=0)
    results_df = results_df[['ID','Variables','Beta_Coeff',
                                             'Std_Error','P-Values', 'Train_MAE',
                                             'Train_MAPE', 'Train_Adj_R_Square',
                                             'Train_R_Square', 'Train_WMAPE',
                                             'Test_MAE', 'Test_MAPE',
                                             'Test_R_Square', 'Test_WMAPE']]
    return results_df
