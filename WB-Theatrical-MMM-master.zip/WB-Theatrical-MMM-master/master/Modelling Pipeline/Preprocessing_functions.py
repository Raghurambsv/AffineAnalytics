# -*- coding: utf-8 -*-
"""
Created on Fri Mar 15 16:56:28 2019

@author: amit
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import Normalizer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from statsmodels.stats.outliers_influence import variance_inflation_factor




def correlation_matrix(data, features):
	#for taking all the variables of a dataset pass data.columns in features 
    result = data[features]
    corr_matrix = result.corr(method = 'pearson')
    return corr_matrix


def variable_transformation(data, feature_dict):
    """
    function returns dataframe which contains original variable along with their transformation
    Paramaeters:
    data: dataframe to which transformed attributes are to be added
    features_dict: dictionary containing key, value pairs. Keys being variable name and value being transfomation be to performed
    returns:
        dataframe with transformed variables.
    """
    transfomation_list = ['square_root','log','square','cube','inverse','exponential','power','normalize']
    for key, value in feature_dict.items():
        if value not in transfomation_list:
            print("Enter a valid transformation, choose one of the following: ", transformation_list)
        if value == 'square_root':
            data[key +'_sq'] = np.sqrt(data[key])
        elif value=='log':
            data[key +'_log'] = np.log(data[key]+1)
        elif value == 'square':
            data[key +'_sq'] = data[key]**2
        elif value =='cube':
            data[key +'_cu'] = data[key]**3
        elif value =='inverse':
            data[key +'_inv'] = 1/data[key]
        elif value == 'exponential':
            data[key +'_exp'] = np.exp(data[key])
        elif value== 'power':
            n = int(input("Enter the power to which the feature is to be transformed: "))
            data[key+'^_'+ str(n)] = data[key]**n
        else:
            data['norm_'+key] = (data[key]-data[key].mean())/data[key].std()
    return data 


def outlier_treatment(data, feature_dict):
    """
    function returns data containing variable with outlier treatment
    Parameters:
    data: dataframe in which outliers values to be treated
    feature_dict: dictionary consisting of key value pairs. Key being variable name value being a tuple consisting of min
    max percentile values
    """
    #outliers can be deleted, transformed, imputed, binning them or treat them as a separate group
    #Here we will impute outliers with given percentile values
    for key, value in feature_dict.items():
        print(key,value)
        per_val1, per_val2 = np.percentile(data[key].dropna(),[value[0],value[1]])
        print(per_val1, per_val2)
        #datapoints falling above or below the max and min percentile value
        outliers = data[(data[key]<per_val1) | (data[key]>per_val2)]
        #number of outliers present in the dataset
        print("Number of outlier present: ", len(outliers))
        #outlier treament
        data[key] = data[key].apply(lambda x: per_val1 if x<per_val1 else x)
        data[key] = data[key].apply(lambda x: per_val2 if x>per_val2 else x)
    return data  



def calculate_vif(data,features):
	#vif using python inbuilt function
    X = data[features]
    variables = list(range(X.shape[1])) #Index of vars
    vif = pd.DataFrame([variance_inflation_factor(X.iloc[:, variables].values, ix) for ix in range(X.iloc[:, variables].shape[1])],columns=['VIF'], index = X.columns)
    return vif




def vif_calculator(dataframe, column_list):
	#vif calculation using r square
    col_name=[]
    vif_value=[]
    for col in column_list:
        X = [x for x in column_list if x!=col]
        y = col
        lm = LinearRegression(fit_intercept=True)
        lm.fit(X=dataframe[X], y= dataframe[y])
        r_score = r2_score(dataframe[y], lm.predict(dataframe[X]))
        vif = 1/(1-r_score)
        col_name.append(col)
        vif_value.append(vif)
    vif_df = pd.DataFrame({'Variable':col_name,
                      'VIF': vif_value})
    vif_df.sort_values(by='VIF', ascending=False, inplace=True)
    return vif_df 


def imputation(data, feature_dict):
    """function returns a dataframe with null values imputed with either mean, median or mode
       Parameter
       data: dataframe in which null values are to be imputed 
       feature_dict: dictionary with key, value pairs. where key represent variable name and value represents imputation method
       returns:
       dataframe with null value imputed"""
    for key,value in feature_dict.items():
        methods = ['mean','median','mode']
        if value not in  methods:
            print("Enter a valid imputation method, choose one of the following: ", methods)
        if value=='mean':
            data[key].replace(np.NaN, data[key].mean(), inplace = True)
        elif value=='median':
            data[key].replace(np.NaN, data[key].median(), inplace = True)
        elif value=='mode':
            data[key].replace(np.NaN, data[key].mode(), inplace = True)
        else:
            data[key].replace(np.NaN, 0, inplace = True)
    return data


def variable_info(dataframe, numerical_column_list, feature_dict_imputation=None,
                  feature_dict_outlier=None, feature_dict_transformation=None):
    """
    Function to output a dataframe depicting the list of variables and their
    transformations, treatment, VIF values, etc. The only purpose of this function
    is to showcase what all preprocessing was done while sending any modelling results 
    
    Parameters
    ---------
    dataframe: Pandas Dataframe
        The AD with all the variables present before any pre processing
    numerical_columns_list: List of column names
        A list containing all the numerical variables of the dataframe
    feature_dict_imputation: Dictionary
        The same dictionary to be passed here which was passed in the imputation
        function in whcih keys depict the column and values depict the imputation
    feature_dict_outlier: Dictionary
        The same dictionary to be passed here which was passed in the outlier_treatment
        function in which keys depict the column and values depict the percentile list
    feature_dict_transformation: Dictionary
        The same dictionary to be passed here which was passed in the transformation
        function in whcih keys depict the column and values depict the transformation
        to be applied
    
    Returns
    -------
    Pandas Dataframe with all the numerical variables and their corresponding
    pre processing techniques applied information
    """
    required_df = dataframe.copy()[numerical_column_list]
    variable_info = required_df.describe()
    variable_info.reset_index(inplace=True)
    variable_info = variable_info.transpose()
    variable_info.columns = variable_info.iloc[0, :]
    variable_info.drop('index', inplace=True)
    variable_info.reset_index(inplace=True)
    variable_info.rename(columns={'index': 'Variable'}, inplace=True)
    null_values = pd.DataFrame({'Percentage_Nulls': (required_df.isnull().sum()/required_df.shape[0])*100})
    null_values.reset_index(inplace=True)
    null_values.rename(columns={'index': 'Variable'}, inplace=True)
    variable_info = pd.merge(variable_info, null_values, how='left', on='Variable')
    if feature_dict_transformation is not None:
        required_df = variable_transformation(required_df, feature_dict_transformation)
        transformation_df = pd.DataFrame({'Variable': list(feature_dict_transformation.keys()),
                               'Transformation': list(feature_dict_transformation.values())})
        variable_info = pd.merge(variable_info, transformation_df, how='left', on='Variable')

    if feature_dict_outlier is not None:
        required_df = outlier_treatment(required_df, feature_dict_outlier)
        outlier_df = pd.DataFrame({'Variable': list(feature_dict_outlier.keys()),
                               'Outlier_Treated': list(feature_dict_outlier.values())})
        variable_info = pd.merge(variable_info, outlier_df, how='left', on='Variable')

    if feature_dict_imputation is not None:
        required_df = imputation(required_df, feature_dict_imputation)
        imputation_df = pd.DataFrame({'Variable': list(feature_dict_imputation.keys()),
                               'Imputation': list(feature_dict_imputation.values())})
        variable_info = pd.merge(variable_info, imputation_df, how='left', on='Variable')

    vif_values = vif_calculator(required_df, numerical_column_list)
    variable_info = pd.merge(variable_info, vif_values, how='left', on='Variable')
    return variable_info
