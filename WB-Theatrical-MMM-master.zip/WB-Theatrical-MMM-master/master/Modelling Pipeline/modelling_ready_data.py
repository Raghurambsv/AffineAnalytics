# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 14:23:34 2019

@author: amit
"""
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler

def modelling_ready_data(dataframe, dependent_variable, seed, test_size, stratified_sample_column=None):
    if stratified_sample_column is not None:
        x_train, x_test, y_train, y_test = train_test_split(dataframe.drop(stratified_sample_column, axis=1),
                                                          dataframe[stratified_sample_column],
                                                          test_size=test_size, random_state=seed)
        y_train = pd.DataFrame(y_train)
        y_test = pd.DataFrame(y_test)
        x_train = pd.concat([x_train, y_train], axis=1)
        x_test = pd.concat([x_test, y_test], axis=1)
        y_train = x_train[dependent_variable]
        y_test = x_test[dependent_variable]
        x_train.drop(dependent_variable, inplace=True, axis=1)
        x_test.drop(dependent_variable, inplace=True, axis=1)
        y_train.reset_index(inplace=True, drop=True)
        y_test.reset_index(inplace=True, drop=True)

    else:
        x_train, x_test, y_train, y_test = train_test_split(dataframe.drop(dependent_variable, axis=1),
                                                          dataframe[dependent_variable],
                                                          test_size=test_size, random_state=seed)
        
    x_train_titles = x_train['IMDB_Title_Code']
    x_test_titles = x_test['IMDB_Title_Code']
    x_train_titles.reset_index(inplace=True, drop=True)
    x_test_titles.reset_index(inplace=True, drop=True)
    x_train.drop('IMDB_Title_Code', axis=1, inplace=True)
    x_test.drop('IMDB_Title_Code', axis=1, inplace=True)


    x_train_numerical = x_train.select_dtypes(include=['number'])
    x_test_numerical = x_test.select_dtypes(include=['number'])
    x_train_categorical = pd.get_dummies(x_train.select_dtypes(include=[np.object]), drop_first=True)
    x_test_categorical = pd.get_dummies(x_test.select_dtypes(include=[np.object]), drop_first=True)
    x_train_categorical.reset_index(inplace=True, drop=True)
    x_test_categorical.reset_index(inplace=True, drop=True)
    scaler = MinMaxScaler()
    x_train_col = x_train_numerical.columns.values
    x_test_col = x_test_numerical.columns.values
    x_train_numerical = scaler.fit_transform(x_train_numerical) 
    x_train_numerical = pd.DataFrame(x_train_numerical, columns=x_train_col)
    x_test_numerical = scaler.fit_transform(x_test_numerical)
    x_test_numerical = pd.DataFrame(x_test_numerical, columns=x_test_col)
    x_train = pd.concat([x_train_titles, x_train_numerical, x_train_categorical], axis=1)
    x_test = pd.concat([x_test_titles, x_test_numerical, x_test_categorical], axis=1)
    y_train.reset_index(inplace=True, drop=True)
    y_test.reset_index(inplace=True, drop=True)

        
    return x_train, x_test, y_train, y_test
