#import packages
import numpy as np
import pandas as pd
from pandas import DataFrame,Series
import datetime
import random
import timeit
import time


# In[30]:


#importing BO AD for Warner data
AD_data = pd.read_csv(r'C:\Users\hanaa\Desktop\hanaa\Warner Bros\BO_master_AD_WB_v1.0.csv')

# importing scrapped imdb scrapped  titlke wit budgetr info for Warner data
budget_df=pd.read_csv(r'C:/Users/hanaa/Desktop/hanaa/Warner Bros/IMDB_scrapped_titles.csv')


# importing franchise data
fran_data = pd.read_csv('C:/Users/hanaa/Desktop/hanaa/Warner Bros/franchise_data_mapped_v2_csv.csv')
fran_data.rename(columns={'release date': "US_Release_Date"}, inplace=True)

# appending correct franchise information to the input dataset
def franchise_flag(scrapped_info):
"""Function to finde the major Franchise of each of the movies
Parameters:
	scrapped_info : Pandas Dataframe consisting of the franchise info at movie level
Returns:
	A dataframe with the major Franchise of each of the movies
	(Major Franchise: Eg- Avengers fall under the Marvel Cinematic Universe and has a three movies series in itself.
	Here Marvel Cinematic Universe forms the major Franchise for all the three Avengers movies"""    
    title_code = []
    major_franchise = []
    franchise_flag = []
    release_date = []
    movie_lt = []
    scrapped_info.rename(columns={'release date': "US_Release_Date"}, inplace=True)
    df=scrapped_info.replace(np.nan, '', regex=True)
    code=list((df["IMDB title"]))
    for i in set(code):
    if(i!=''):
        print(i)
        title_code.append(i)
        franchise=list(scrapped_info.loc[scrapped_info["IMDB title"]==i,"franchise"])
        count_movies=(list(scrapped_info.loc[(scrapped_info["IMDB title"]==i),"count of movies in the franchise"]))
        print(count_movies)
        mx_ind=count_movies.index(max(count_movies))
        mn_ind=count_movies.index(min(count_movies))
        mj_franch=franchise[mx_ind]
        mn_franch=franchise[mn_ind]
        major_franchise.append(mj_franch)
        minor_franchise.append(mn_franch)
    movie_df=pd.DataFrame({'IMDB Title Code':pd.Series(title_code),'Earnings': pd.Series(random.sample(range(100000000), len(title_code))),'Major Franchise':pd.Series(major_franchise),'Minor Franchise':pd.Series(minor_franchise)})
    return movie_df

# number of previous movies of the franchise since the current one


def create_average_earning(df, column, budget):
    """
    Function to create average past earnings of the Franchise

    Parameters
    ---------
    df: Pandas Dataframe
        The dataframe with the scrapped budget information
    column: String
        Name of the column whose metric is to be calculated (Major Franchise)
    budget: budget at a movie level


    Returns
    -------
    Pandas Dataframe: The updated dataframe with budget of the
    Major Franchise
    """
    column=scrapped_info["Major Franchise"]
    earning=df["Gross_US"]
    df['US.Release.Date(edit)'] = pd.to_datetime(
    df['US.Release.Date(edit)'], format='%d-%m-%Y')

# Sorting the resultant dataframe so as to calculate cumulative average
   df = df.sort_values(
   by=['US.Release.Date(edit)'])
   df.reset_index(inplace=True, drop=True)
#Merging the two data frames together on IMDB Title code
   final_df=pd.merge(df,scrapped_info, left_on='IMDB_Title_Code',right_on='IMDB Title Code')
   avg_earning=[]

   for i in final_df["IMDB_Title_Code"].unique() :
      rel_dt=pd.to_datetime(arg = final_df.loc[final_df["IMDB_Title_Code"] == i, "US.Release.Date(edit)"], infer_datetime_format = True)
      franc = final_df.loc[final_df["IMDB_Title_Code"] == i,"Major Franchise"]

#Checking if the movie is the oldest movie of a Franchise
      if(rel_dt is min(list(final_df["US.Release.Date(edit)"]))!=True):

#Getting subset dataframe of a particular Franchise 
         sub_franc = final_df.loc[final_df["Major Franchise"] == franc, ]

#Getting subset dataframe of a particular Franchise with release dates less than that of the particular movie
         sub_franc = sub_franc.loc[sub_franc["US.Release.Date(edit)"] < pd.to_datetime(arg = rel_dt, infer_datetime_format = True), ]
      else:
         sub_franc = final_df.loc[final_df["IMDB_Title_Code"] == i, ]

#Getting average past earnings of a given movie
      avg_earning.append(sum(sub_franc["Gross_US"])/(len(sub_franc["Gross_US"])))
   final_df=final_df.assign(Average_Earnings=avg_earning)
   return final_df

#Function to get number of movies released in past n years
def to_longformat(dataframe, column_to_unpivot, column_as_id):
    
    """
    column_to_unpivot: String
        The column of the variables to convert to long format
    column_as_id: List
        The list of columns to keep as Index while converting to long format
    """
    dataframe[column_to_unpivot] = dataframe[column_to_unpivot].apply(
            lambda x: str(x).strip().split("[")[1][:-1])
   
    temp = dataframe[column_to_unpivot].str.split(" ", expand=True)

    dataframe = pd.concat([dataframe, temp], axis=1)
    dataframe = pd.melt(dataframe, id_vars=column_as_id,
                        value_vars=range(0, temp.shape[1]))
    dataframe.dropna(inplace=True)
    dataframe.drop('variable', axis=1, inplace=True)
    return dataframe

def count_movies(data, franchise_data, n_years):
    
    """
    Function to return number of titles released in past n years given AD and franchise data
    Parameters
    ----------
    data : python DataFrame
        Dataframe to which column is to be created
    franchise_data : python DataFrame
        Dataframe having franchise information

    Returns:
        dataframe with column containing number of movies released in last n years
    """
    df = franchise_data.groupby('franchise').agg({'ReleaseYear': ['min','max']}).reset_index()
    df.columns = df.columns.droplevel(0)
    df.columns = ['Title', 'min_year','max_year']
    df['min_max_year'] = df.apply(lambda X: np.arange(X['min_year'],X['max_year']+1,1),axis=1)
    df.drop(['min_year','max_year'],axis =1, inplace = True)
    data_new = to_longformat(df, 'min_max_year',['Title'])
    data_new['default'] = 0
    franchise_data=fran_data.groupby(['franchise','ReleaseYear'])['IMDB_title'].count().reset_index()
    final_data = pd.merge(left= data_new, right = franchise_data, how = 'left', left_on=['Title', 'value'], right_on =['franchise', 'ReleaseYear'])
    #add column for rolling sum 
    
    return final_data



#Function to get difference between current and previous release 
def last_release_duration(data,scrapped_data):
    """function to calculate gap (in days from last release)
    Parameters
    ----------
    data : Pandas Dataframe
        Original dataframe in which the variable has to be added
    scrapped_data : Pandas Dataframe
        The dataframe consisting of the franchise info at movie level

    Returns:
        An updated dataframe with the new variable added to the original
        dataframe

    """
    scrapped_data.rename(columns={'release date': "US_Release_Date"}, inplace=True)
    #assumimg franchise data in scrapped data with frachise name, title code and release date in it
    #converting ReleaseDate to datetime in scrapped data
    scrapped_data['US_Release_Date'] = pd.to_datetime(scrapped_data['US_Release_Date'], errors='coerce')
    #sorting release date based on release date
    temp = scrapped_data[['IMDB title','franchise','US_Release_Date']]
    temp = temp.sort_values(['franchise','US_Release_Date'], ascending = True)
    #calculate lag of 1 in sorted scrapped datasets
    temp['lagged_date']=temp.groupby('franchise')['US_Release_Date'].shift(1)
    temp['DiffPR']=temp['US_Release_Date']-temp['lagged_date']

    data = pd.merge(left=data, right=temp[['IMDB title','DiffPR']], how = 'left', left_on='IMDB_Title_Code', right_on='IMDB title')
    return data
print(last_release_duration(AD_data,fran_data))
# print(franchise_flag(fran_data))
