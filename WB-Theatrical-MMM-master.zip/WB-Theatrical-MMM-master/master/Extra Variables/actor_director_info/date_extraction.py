# -*- coding: utf-8 -*-
"""
Created on Mon Feb 25 12:00:55 2019

@author: amit
"""
import re
import pandas as pd
import numpy as np


def day(date):
    """
    Function to extract day part from the date string

    Parameters
    ----------
    date: String
        The date string

    Returns
    day: String
        The day number from the date string
    """
    try:
        day = re.search(r'(\d{1,2})([\s-])', date).group(1)
    except AttributeError:
        day = "None"
    return day


def month(date):
    """
    Function to extract month part from the date string

    Parameters
    ----------
    date: String
        The date string

    Returns
    month: String
        The month initials from the date string
    """
    try:
        month = re.search(
                r'(:?Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|January|\
                February|March|April|May|June|July|August|September|\
                October|November|December)', date).group(0)
    except AttributeError:
        month = "None"
    if month == "None":
        return month
    else:
        return month[0:3]


def year(date):
    """
    Function to extract year part from the date string. If the year is 2 digit
    and if that is less than 20, then it is considered as 21th century year.
    While if the 2 digit year is more than 20 it is considered as 20th century
    year

    Parameters
    ----------
    date: String
        The date string

    Returns
    month: String
        The month initials from the date string
    """
    try:
        year = re.search(r'([\s-])(\d{2,4})', date).group(2)
    except AttributeError:
        year = "None"

    if year == 'None':
        try:
            year = re.search(r'(\d{2,4})', date).group(0)
        except AttributeError:
            year = 'None'

    if year != "None":
        if(len(year) == 2) & (int(year) <= 20):
            year = int(year)+2000
        elif(len(year) == 2) & (int(year) > 20):
            year = int(year)+1900
    return str(year)


def string_to_date(dataframe):
    """
    Function to convert the string date to pandas datetime format

    Parameters
    ----------
    dataframe: Pandas dataframe
        The Pandas Dataframe with column: "US_Release_Date"

    Returns
    dataframe: Pandas Dataframe
        The updated pandas dataframe with date column in datetime format
    """
    try:
        dataframe['US_Release_Date'] = pd.to_datetime(
                     dataframe['US_Release_Date'], format='%d-%b-%Y')
    except ValueError:
        dataframe['US_Release_Date'] = np.nan
    return dataframe['US_Release_Date']


def convert_to_date(dataframe):
    """
    Function to combine all the individual fucntions

    Parameters
    ----------
    dataframe: Pandas Dataframe
        The dataframe to be updated. It must have the column:
        "US.Release.Date"

    Returns
    dataframe: Pandas Dataframe
        The updated dataframe with date in datetime format
    """
    dataframe.rename(columns={'US.Release.Date': 'US_Release_Date'},
                     inplace=True)
    dataframe['day'] = dataframe['US_Release_Date'].apply(
            lambda x: day(str(x)))
    dataframe['month'] = dataframe['US_Release_Date'].apply(
            lambda x: month(str(x)))
    dataframe['year'] = dataframe['US_Release_Date'].apply(
            lambda x: year(str(x)))
    dataframe['US_Release_Date'] = dataframe['day']+'-'+dataframe['month']+'-'+dataframe['year']
    dataframe['US_Release_Date'] = dataframe.apply(
            lambda x: string_to_date(x), axis=1)
    return dataframe


df = pd.read_csv(r"C:\Users\v-sanysa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Scrapped Title Info - IMDB\IMDB_scrapped_titles.csv",
                                       sep = ',',
                                       encoding = 'latin-1')
df2 = convert_to_date(df)

df2.to_csv(r"C:\Users\v-sanysa\Desktop\temp.csv")