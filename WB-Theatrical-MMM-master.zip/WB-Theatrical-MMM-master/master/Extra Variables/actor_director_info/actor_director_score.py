# author: SANDEEP SANYAL (AAIN0547)

########################################################################################################################
# ACTOR SCORE
########################################################################################################################
def actor_score(df, movie_actor_list, actors_data) :
    """
    Calculate actor score for  each movie considering the year of release of the movie
    Args:
        df: dataframe where you wish to append actor score
        movie_actor_list: dataframe of movies with actor ids present
        actors_data: dataframe of actors and their awards

    Returns:
        df: raw dataframe with actor score appended as a column
    """

    # importing libraries
    import pandas as pd

    df = pd.merge(left=df,
                  right=movie_actor_list[['IMDB_Title_Code', 'IMDB_Actor_Code']],
                  how='left',
                  left_on=['IMDB_Title_Code'],
                  right_on=['IMDB_Title_Code'],
                  sort=True,
                  copy=False)

    # preparing actor_data
    actors_data = actors_data[['id', 'award_year', 'award_outcome']]
    actors_data.columns = ['IMDB_Actor_Code', 'Year', 'Award']
    actors_data['temp'] = 1
    actors_data = pd.pivot_table(data=actors_data, index=['IMDB_Actor_Code', 'Year'], columns=['Award'],
                                 values=['temp']).reset_index()
    actors_data.columns = ['IMDB_Actor_Code', 'Year', 'Nominations', 'Wins']
    actors_data = actors_data.fillna(0)

    # preparing movie-actor list
    movie_actor_list = df[['IMDB_Title_Code', 'Theatrical_Release_Date']]
    movie_actor_list = pd.concat([movie_actor_list, df['IMDB_Actor_Code'].str.split(pat=',', expand=True)], axis=1)
    movie_actor_list.columns = ["IMDB_Title_Code", "Theatrical_Release_Date", "Actor1", "Actor2", "Actor3", "Actor4"]

    movie_actor_list = pd.melt(movie_actor_list,
                               id_vars=['IMDB_Title_Code', 'Theatrical_Release_Date'],
                               value_vars=['Actor1', 'Actor2', 'Actor3', 'Actor4'],
                               value_name='IMDB_Actor_Code')
    movie_actor_list = movie_actor_list[['IMDB_Title_Code', 'Theatrical_Release_Date', 'IMDB_Actor_Code']].sort_values(
        by=['IMDB_Title_Code', 'Theatrical_Release_Date'], inplace=False).reset_index(drop=True)
    movie_actor_list['Year_of_Release'] = pd.to_datetime(arg=movie_actor_list['Theatrical_Release_Date'],
                                                         infer_datetime_format=True).dt.year
    movie_actor_list = movie_actor_list[['IMDB_Title_Code', 'Year_of_Release', 'IMDB_Actor_Code']]

    # count number of actor wins and nominations in each years
    unq_actors = pd.DataFrame({'IMDB_Actor_Code': movie_actor_list['IMDB_Actor_Code'].unique()})
    unq_actors['temp'] = 1
    all_years = pd.DataFrame({'Year': list(range(1900, 2019))})
    all_years['temp'] = 1
    temp = pd.merge(left=unq_actors,
                    right=all_years,
                    left_on=['temp'],
                    right_on=['temp'],
                    sort=True,
                    copy=False)
    del all_years
    del unq_actors
    temp = temp[['IMDB_Actor_Code', 'Year']]
    actors_data = pd.merge(left=temp,
                           right=actors_data,
                           how='left',
                           left_on=['IMDB_Actor_Code', 'Year'],
                           right_on=['IMDB_Actor_Code', 'Year'],
                           sort=True,
                           copy=False)
    del temp
    actors_data = actors_data.fillna(0)
    actors_data = pd.concat([actors_data[['IMDB_Actor_Code', 'Year']],
                             actors_data.groupby(['IMDB_Actor_Code']).agg({'Wins': 'cumsum', 'Nominations': 'cumsum'})],
                            axis=1)

    # calculating actor score in each year
    actors_data['actor_score'] = (actors_data['Wins'] * 1) + (actors_data['Nominations'] * 0.5)

    # calculating actor score for each movie titles
    master_AD_act_split = pd.concat([df[['IMDB_Title_Code', 'Theatrical_Release_Date']],
                                     df['IMDB_Actor_Code'].str.split(pat=",", expand=True)], axis=1)
    master_AD_act_split['Theatrical_Release_Year'] = pd.DatetimeIndex(
        master_AD_act_split['Theatrical_Release_Date']).year
    master_AD_act_split.columns = ['IMDB_Title_Code', 'Theatrical_Release_Date', 'Actor1', 'Actor2', 'Actor3', 'Actor4',
                                   'Theatrical_Release_Year']

    master_AD_act_split = pd.melt(master_AD_act_split,
                                  id_vars=['IMDB_Title_Code', 'Theatrical_Release_Year'],
                                  value_vars=['Actor1', 'Actor2', 'Actor3', 'Actor4'],
                                  value_name='Actor')
    master_AD_act_split.sort_values(by=['IMDB_Title_Code', 'Theatrical_Release_Year'], inplace=True)

    temp = pd.merge(left=master_AD_act_split[['IMDB_Title_Code', 'Theatrical_Release_Year', 'Actor']],
                    right=actors_data[['IMDB_Actor_Code', 'Year', 'actor_score']],
                    how='left',
                    left_on=['Theatrical_Release_Year', 'Actor'],
                    right_on=['Year', 'IMDB_Actor_Code'],
                    sort=True,
                    copy=False)
    temp.sort_values(by=['IMDB_Title_Code', 'Theatrical_Release_Year'], inplace=True)

    temp = temp.groupby(['IMDB_Title_Code']).agg({'actor_score': 'sum'}).reset_index()

    df = pd.merge(left=df,
                  right=temp,
                  how='left',
                  left_on=['IMDB_Title_Code'],
                  right_on=['IMDB_Title_Code'],
                  sort=True,
                  copy=False)
    del temp, movie_actor_list, master_AD_act_split, actors_data

    return df


########################################################################################################################
# DIRECTOR SCORE
########################################################################################################################
def director_score(df, movie_director_list, directors_data) :
    """
    Calculate director score for  each movie considering the year of release of the movie
    Args:
        df: dataframe where you wish to append director score
        movie_director_list: dataframe of movies with director ids present
        directors_data: dataframe of directors and their awards

    Returns:
        df: raw dataframe with director score appended as a column
    """

    # importing libraries
    import pandas as pd

    df = pd.merge(left=df,
                  right=movie_director_list[['IMDB_Title_Code', 'IMDB_Director_Code']],
                  how='left',
                  left_on=['IMDB_Title_Code'],
                  right_on=['IMDB_Title_Code'],
                  sort=True,
                  copy=False)

    # preparing director_data
    directors_data = directors_data[['id', 'award_year', 'award_outcome']]
    directors_data.columns = ['IMDB_Director_Code', 'Year', 'Award']
    directors_data['temp'] = 1
    directors_data = pd.pivot_table(data=directors_data, index=['IMDB_Director_Code', 'Year'], columns=['Award'],
                                    values=['temp']).reset_index()
    directors_data.columns = ['IMDB_Director_Code', 'Year', 'Nominations', 'Wins']
    directors_data = directors_data.fillna(0)

    # preparing movie-director list
    movie_director_list = df[['IMDB_Title_Code', 'Theatrical_Release_Date']]
    movie_director_list = pd.concat([movie_director_list, df['IMDB_Director_Code'].str.split(pat=',', expand=True)],
                                    axis=1)
    movie_director_list.columns = ["IMDB_Title_Code", "Theatrical_Release_Date", "Director1", "Director2", "Director3"]

    movie_director_list = pd.melt(movie_director_list,
                                  id_vars=['IMDB_Title_Code', 'Theatrical_Release_Date'],
                                  value_vars=["Director1", "Director2", "Director3"],
                                  value_name='IMDB_Director_Code')
    movie_director_list = movie_director_list[
        ['IMDB_Title_Code', 'Theatrical_Release_Date', 'IMDB_Director_Code']].sort_values(
        by=['IMDB_Title_Code', 'Theatrical_Release_Date'], inplace=False).reset_index(drop=True)
    movie_director_list['Year_of_Release'] = pd.to_datetime(arg=movie_director_list['Theatrical_Release_Date'],
                                                            infer_datetime_format=True).dt.year
    movie_director_list = movie_director_list[['IMDB_Title_Code', 'Year_of_Release', 'IMDB_Director_Code']]

    # count number of director wins and nominations in each years
    unq_directors = pd.DataFrame({'IMDB_Director_Code': movie_director_list['IMDB_Director_Code'].unique()})
    unq_directors['temp'] = 1
    all_years = pd.DataFrame({'Year': list(range(1900, 2019))})
    all_years['temp'] = 1
    temp = pd.merge(left=unq_directors,
                    right=all_years,
                    left_on=['temp'],
                    right_on=['temp'],
                    sort=True,
                    copy=False)
    del all_years
    del unq_directors
    temp = temp[['IMDB_Director_Code', 'Year']]
    directors_data = pd.merge(left=temp,
                              right=directors_data,
                              how='left',
                              left_on=['IMDB_Director_Code', 'Year'],
                              right_on=['IMDB_Director_Code', 'Year'],
                              sort=True,
                              copy=False)
    del temp
    directors_data = directors_data.fillna(0)
    directors_data = pd.concat([directors_data[['IMDB_Director_Code', 'Year']],
                                directors_data.groupby(['IMDB_Director_Code']).agg(
                                    {'Wins': 'cumsum', 'Nominations': 'cumsum'})], axis=1)

    # calculating director score in each year
    directors_data['director_score'] = (directors_data['Wins'] * 1) + (directors_data['Nominations'] * 0.5)

    # calculating director score for each movie titles
    master_AD_dict_split = pd.concat([df[['IMDB_Title_Code', 'Theatrical_Release_Date']],
                                      df['IMDB_Director_Code'].str.split(pat=",", expand=True)], axis=1)
    master_AD_dict_split['Theatrical_Release_Year'] = pd.DatetimeIndex(
        master_AD_dict_split['Theatrical_Release_Date']).year
    master_AD_dict_split.columns = ['IMDB_Title_Code', 'Theatrical_Release_Date', 'Director1', 'Director2', 'Director3',
                                    'Theatrical_Release_Year']

    master_AD_dict_split = pd.melt(master_AD_dict_split,
                                   id_vars=['IMDB_Title_Code', 'Theatrical_Release_Year'],
                                   value_vars=['Director1', 'Director2', 'Director3'],
                                   value_name='Director')
    master_AD_dict_split.sort_values(by=['IMDB_Title_Code', 'Theatrical_Release_Year'], inplace=True)

    temp = pd.merge(left=master_AD_dict_split[['IMDB_Title_Code', 'Theatrical_Release_Year', 'Director']],
                    right=directors_data[['IMDB_Director_Code', 'Year', 'director_score']],
                    how='left',
                    left_on=['Theatrical_Release_Year', 'Director'],
                    right_on=['Year', 'IMDB_Director_Code'],
                    sort=True,
                    copy=False)
    temp.sort_values(by=['IMDB_Title_Code', 'Theatrical_Release_Year'], inplace=True)

    temp = temp.groupby(['IMDB_Title_Code']).agg({'director_score': 'sum'}).reset_index()

    df = pd.merge(left=df,
                  right=temp,
                  how='left',
                  left_on=['IMDB_Title_Code'],
                  right_on=['IMDB_Title_Code'],
                  sort=True,
                  copy=False)
    del temp, movie_director_list, master_AD_dict_split, directors_data

    return df