import pandas as pd
import numpy as np
# code dependancy - run "film_festivals.py"


# This nonwb is essentially wb flag o from the file "Non WB  - PST - Units&Revenue -Comp AD - (T+3)_V_3.0.xlsx" in
# C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\PST - units iteration
nonwb = pd.read_excel(r"C:\Users\hari\Desktop\Non WB  - PST - Units&Revenue -Comp AD - (T+3)_V_3.0.xlsx")

# The below ad is from sandeeps code which spat out a new units ad for pst
PSTunits = pd.read_excel(r"C:\Users\hari\Desktop\WB_Units_Modeling AD v1.0.xlsx",sheet_name="PST_TH+1 week(s)")

postrak = pd.read_excel(io=r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\post_trak_film_lookup_results_2019_10_14__14_49_Week 2.1.xlsx",
                        sheet_name="Recovered_Sheet1")
PSTunits['WB_Flag'] = 1


PSTu2=pd.merge(left=PSTunits,
                right=postrak[['IMDB_Title_Code_new','Locs\nat\nWidest\nRelease', 'Definitely\nRecommend']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code_new")
# dropping the extra title code new from postrak
PSTu2.drop(["IMDB_Title_Code_new"],
            axis=1,
            inplace=True)
lifecycle = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\Genre_allmetrics_HE_Lifecycle.xlsx",sheet_name="T+1")

PSTu3=pd.merge(left=PSTu2,
                right=lifecycle[['Mkt_Genre_Grouped',
'Definitely Interested',
'Definitely Interested among Aware',
'HE First Choice  ALL',
'Interest Any Buy',
'Interest Any Buy Physical',
'Interest Any HE',
'Interest HE Any Only',
'Interest to Rent Phy Disc',
'TOP2 Interested',
'Unaid',]],
                how="left",
                left_on="Mkt_Genre_Grouped",
                right_on="Mkt_Genre_Grouped")

finance_data = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\WB+Comp_Titles_BO_HE_Revenue.xlsx")


PSTu4=pd.merge(left=PSTu3,
                right=finance_data[['IMDB_Title_Code', 'BO Spends(WB Finance)',
       'Total EST Spends(WB Finance)']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code")

# renaming required columns
PSTu4.rename(columns={'BO Spends(WB Finance)':'Total_BO_Spends', 'Total EST Spends(WB Finance)':'Total_EST_Spends'}, inplace=True)

# window_calc = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\NonWB_Modeling AD v1.0.xlsx",sheet_name= "NonWB Titles")

PSTu4.to_excel(r"C:\Users\hari\Desktop\PSTu4.xlsx",index=False)

PSTu4.drop(['Distribution_only',
'Actor_0',
'Actor_1',
'Actor_2',
'Actor_3',
'Director_0',
'Director_1',
'Estimated_BO_Revenue',
'max_combined_likes_till_2',
'avg_combined_likes_till_2',
'total_combined_likes_till_2',
'max_combined_views_till_2',
'avg_combined_views_till_2',
'total_combined_views_till_2',
'max_combined_comments_till_2',
'avg_combined_comments_till_2',
'total_combined_comments_till_2',
'max_combined_likes_by_views_till_2',
'avg_combined_likes_by_views_till_2',
'total_combined_likes_by_views_till_2',
'max_Wikipedia_Page_Views_till_2',
'avg_Wikipedia_Page_Views_till_2',
'total_Wikipedia_Page_Views_till_2',
'combined_likes',
'combined_views',
'combined_comments',
'combined_likes_by_views',
'combined_likes_2',
'combined_views_2',
'combined_comments_2',
'combined_likes_by_views_2',
'Wikipedia_Page_Views_2',
'combined_views_2 Adstock Linear0.9',
'combined_likes_2 Adstock Linear0.9',
'combined_comments_2 Adstock Linear0.9',
'combined_likes_by_views_2 Adstock Linear0.9',
'Google_Search_Volume_2 Adstock Linear0.9',
'Wikipedia_Page_Views_2 Adstock Linear0.873'],
            axis=1,
            inplace=True)

PSTu4.to_excel(r"C:\Users\hari\Desktop\PSTu4.xlsx",index=False)

nonwb.drop(["Google_Search_Volume_2 Adstock Linear0.804"],
            axis=1,
            inplace=True)

nonwb.drop(["avg_earnings_franchise","PST Revenue","PST Revenue_Clubbed","Theatrical_Release_Month"],
            axis=1,
            inplace=True)
dummy=pd.get_dummies(nonwb["Mkt_Genre_Grouped"])
nonwb=pd.concat([nonwb,dummy],axis=1)

dummy2=pd.get_dummies(PSTu4["Mkt_Genre_Grouped"])
PSTu4=pd.concat([PSTu4,dummy2],axis=1)

PSTu4["Total_HE_Spends"] = (PSTu4["Total_EST_Spends"])/(0.45)
nonwb["Total_HE_Spends"] = (nonwb["Total_EST_Spends"])/(0.45)

nonwb.rename(columns={'New PST_Units_Unclubbed':'PST Units',
'New PST_Units_Clubbed':'PST Units_Clubbed'}, inplace=True)

nonwb.drop(["PST Units- Clubbed","Week_Start_Month"],
            axis=1,
            inplace=True)

nonwb = nonwb[['Action/Adventure',
'Actor_0_Rating',
'Actor_1_Rating',
'Actor_2_Rating',
'Actor_3_Rating',
'actors_avg_rating',
'avg_competitor_effect',
'avg_Google_Search_Volume_till_2',
'cast_avg_rating',
'comedy',
'Competitor_Effect',
'count_film_festival',
'Definitely Interested',
'Definitely Interested among Aware',
'DefinitelyRecommend',
'Director_0_Rating',
'Director_1_Rating',
'directors_avg_rating',
'Drama',
'EST_PST_Window',
'Family',
'film_festival_binary_flag',
'film_festival_flag',
'franchise_flag',
'franchise_releases_in_last_2_years',
'franchise_releases_in_last_3_years',
'franchise_releases_in_last_4_years',
'Google_Search_Volume_2',
'HE First Choice  ALL',
'holiday_flag',
'holiday_flag_Clubbed',
'IMDB Title Name',
'IMDB_Title_Code',
'Interest Any Buy',
'Interest Any Buy Physical',
'Interest Any HE',
'Interest HE Any Only',
'Interest to Rent Phy Disc',
'Locsat Widest',
'long_weekend_flag',
'long_weekend_flag_Clubbed',
'MajorFranchise',
'max_Google_Search_Volume_till_2',
'Mkt_Genre',
'Mkt_Genre_Grouped',
'Opening_Weekend_BO',
'Others',
'PST Units',
'PST Units_Clubbed',
'PST_Week_Number',
'TH_Week_Number',
'Theatrical_Release_Date',
'Theatrical_Release_Year',
'time_delta_since_last_franchise_release',
'TOP2 Interested',
'Total_BO_Spends',
'Total_EST_Spends',
'total_Google_Search_Volume_till_2',
'Total_HE_Spends',
'Unaid',
'WB_Flag',
'Week Start Date']]




PSTu4= PSTu4[['Action/Adventure',
'Actor_0_Rating',
'Actor_1_Rating',
'Actor_2_Rating',
'Actor_3_Rating',
'actors_avg_rating',
'avg_competitor_effect',
'avg_Google_Search_Volume_till_2',
'cast_avg_rating',
'comedy',
'Competitor_Effect',
'count_film_festival',
'Definitely Interested',
'Definitely Interested among Aware',
'Definitely\nRecommend',
'Director_0_Rating',
'Director_1_Rating',
'directors_avg_rating',
'Drama',
'Family',
'film_festival_binary_flag',
'film_festival_flag',
'franchise_flag',
'franchise_releases_in_last_2_years',
'franchise_releases_in_last_3_years',
'franchise_releases_in_last_4_years',
'Google_Search_Volume_2',
'HE First Choice  ALL',
'holiday_flag',
'holiday_flag_Clubbed',
'IMDB Title Name',
'IMDB_Title_Code',
'Interest Any Buy',
'Interest Any Buy Physical',
'Interest Any HE',
'Interest HE Any Only',
'Interest to Rent Phy Disc',
'Locs\nat\nWidest\nRelease',
'long_weekend_flag',
'long_weekend_flag_Clubbed',
'MajorFranchise',
'max_Google_Search_Volume_till_2',
'Mkt_Genre',
'Mkt_Genre_Grouped',
'Opening_Weekend_BO',
'Others',
'PST Units',
'PST Units_Clubbed',
'PST_Week_Number',
'TH_Week_Number',
'Theatrical_Release_Date',
'Theatrical_Release_Year',
'time_delta_since_last_franchise_release',
'TOP2 Interested',
'Total_BO_Spends',
'Total_EST_Spends',
'total_Google_Search_Volume_till_2',
'Total_HE_Spends',
'Unaid',
'WB_Flag',
'Week Start Date']]



PSTu4.to_excel(r"C:\Users\hari\Desktop\PST5.xlsx",index=False)
nonwb.to_excel(r"C:\Users\hari\Desktop\nonwbF2.xlsx",index=False)

# vlook up done for pst - la - est pst window for wb
#  vlookup done for tomate
