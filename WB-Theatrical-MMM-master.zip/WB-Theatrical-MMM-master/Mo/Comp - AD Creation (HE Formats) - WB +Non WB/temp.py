import numpy as np
import pandas as pd

base_df = pd.read_excel(r"C:\Users\hari\Desktop\updated gsv1.0 est ad.xlsx")

modell

modeling_ad = wm_data_features_phase2.social_media_metrics(studio=studio,
                                                           root_folder=root_folder,
                                                           base_ad=modeling_ad,
                                                           social_media_data=pd.read_excel(
                                                               io=sharepoint_path + r"/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Social Media Data.xlsx",
                                                               sheet_name="Social Media Data T+3 nonwb",
                                                               na_values=['#NA', '#N/A', '', ' ', 'na', 'NA']).rename(
                                                               columns={'IMDB Title Code': 'IMDB_Title_Code',
                                                                        'IMDB Title Name': 'IMDB_Title_Name',
                                                                        'Theatrical Release Date': 'Theatrical_Release_Date',
                                                                        'Week Start Date': 'Week_Start_Date',
                                                                        'Week Number': 'TH_Week_Number',
                                                                        'Google Search Volume': 'Google_Search_Volume'}),
                                                           snapshot=snapshot + 1,
                                                           week_number_colname='th_week_number',
                                                           revenue_colname=media + ' ' + sale + '')
sale ='revenue'
revenue_colname = 'est_revenue'
modeling_ad = base_df
base_ad = base_df
base_ad.fillna(0,inplace=True)
studio ='est'
snapshot = 2
social_media_data=pd.read_excel(io=sharepoint_path+r"/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Social Media Data.xlsx",
                                sheet_name="all  gs1.0 data for titles")
social_media_data = pd.read_excel(
    io=sharepoint_path + r"/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Social Media Data.xlsx",
    sheet_name="all  gs1.0 data for titles",
    na_values=['#NA', '#N/A', '', ' ', 'na', 'NA']).rename(
    columns={'IMDB Title Code': 'IMDB_Title_Code',
             'IMDB Title Name': 'IMDB_Title_Name',
             'Theatrical Release Date': 'Theatrical_Release_Date',
             'Week Start Date': 'Week_Start_Date',
             'Week Number': 'th_week_number',
             'Google Search Volume': 'Google_Search_Volume'})
# del social_media_data
sys.path.insert(0, root_folder + r"/WB-Theatrical-MMM/Phase 2 Codes/03. Feature Engineering")
from AdstockClass import Adstock

sys.path.insert(0, root_folder + r"/WB-Theatrical-MMM/Phase 2 Codes/03. Feature Engineering")
# import film_festivals
# import franchise
# import cast_rating
# import holiday_metrics
import wm_data_features_phase2

for metric in ['Google_Search_Volume']:
    social_media_data[metric + '_' + str(snapshot)] = social_media_data.apply(
        lambda x: np.nan if x[week_number_colname] >= snapshot else x[metric], axis=1)
    # Creating some basic mean/max variables out of the combined variables
    social_media_data['max_' + metric + '_till_' + str(snapshot)] = social_media_data.groupby(['IMDB_Title_Code'])[
        metric + '_' + str(snapshot)].transform('max')
    social_media_data['avg_' + metric + '_till_' + str(snapshot)] = social_media_data.groupby(['IMDB_Title_Code'])[
        metric + '_' + str(snapshot)].transform('mean')
    social_media_data['total_' + metric + '_till_' + str(snapshot)] = social_media_data.groupby(['IMDB_Title_Code'])[
        metric + '_' + str(snapshot)].transform('sum')
    # Getting title level metrics
    base_ad = pd.merge(base_ad, social_media_data[
        ['IMDB_Title_Code', 'max_' + metric + '_till_' + str(snapshot),
         'avg_' + metric + '_till_' + str(snapshot),
         'total_' + metric + '_till_' + str(snapshot)]].drop_duplicates(),
                       left_on=['imdb_title_code'],
                       right_on=['IMDB_Title_Code'],
                       how='left')
    # Getting BO Revenue column from base ad into this merged data
social_media_data = pd.merge(social_media_data,
                             base_ad[['IMDB_Title_Code', week_number_colname, revenue_colname]],
                             on=['IMDB_Title_Code', week_number_colname],
                             how='outer')
# Creating Adstock for these combined metrics using optimal lambda
class_instance = Adstock(base_dataframe=social_media_data,
                         dictionary_spends={'Google_Search_Volume' + '_' + str(snapshot): [0.1, 'Linear']},
                         week_number_colname=week_number_colname,
                         revenue_colname=revenue_colname)
merged_data = class_instance.optimise_adstock()
# Merging these variables with the base ad
merged_data.drop(columns=['IMDB_Title_Name', 'Theatrical_Release_Date',
                          'Week_Start_Date', 'Google_Search_Volume',
                          revenue_colname], inplace=True)

# Dropping more variables that have been already merged in the base ad

merged_data.drop(columns=[col for col in merged_data.columns if 'max' in col or 'avg' in col or 'total' in col],
                 inplace=True)
base_ad = pd.merge(base_ad, merged_data, on=['IMDB_Title_Code', week_number_colname],
                   how='left')
return base_ad
