import numpy as np
import pandas as pd
from tqdm import tqdm
import math

# adding the wb finance data
def finance_function(comp_dataframe):

    # reading wb data
    finance_wb = pd.read_excel(
        io=r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\02. Spend Data\5. Spends 2019-11-12\Reallocated Spends data - v5.xlsx",
        sheet_name="BO - Redistributed Spends",
        header=3).drop('Unnamed: 0', axis=1)

    finance_wb.rename(columns ={"TITLE ID" : "IMDB_Title_Code"},inplace=True)
    finance_wb["Total_BO_Spends"] = finance_wb.apply(lambda x: x["DIGITAL"]+x["DIGITAL VIDEO"]+x["TOTAL LINEAR"]+x["TOTAL RADIO"]+x["OUTDOOR_PRINT"]+x["OOH - EXPERIENTIAL"],axis =1)
    finance_wb_2= finance_wb.groupby("IMDB_Title_Code").agg({"Total_BO_Spends":'sum'}).reset_index(drop=False)

    # Non WB reading data
    finance_nonwb = pd.read_excel(
        r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\02. Cleaned Data\02. Spend Data\CompSpending_v1.3.xlsx",
    sheet_name="Sheet1")
    finance_nonwb.rename(columns ={"IMDB Title Code" : "IMDB_Title_Code"},inplace=True)

    # multiplying with 9 because of the ratio of BO:EST;PST is 18:1:1
    finance_nonwb["Total_BO_Spends"] = finance_nonwb.apply(lambda x: x["HE Spend"] * 9,axis = 1)
    finance_nonwb_2 = finance_nonwb.groupby("IMDB_Title_Code").agg({"Total_BO_Spends": "sum"}).reset_index(drop=False)

    consolidated_spends = pd.merge(left=finance_nonwb_2.rename(columns={'Total_BO_Spends':'Total_BO_Spends_NonWB'}),
             right=finance_wb_2.rename(columns={'Total_BO_Spends':'Total_BO_Spends_WB'}),
             how='outer',
             left_on='IMDB_Title_Code',
             right_on='IMDB_Title_Code').reset_index(drop=True)

    for i in tqdm(consolidated_spends.index):
        if math.isnan(consolidated_spends.loc[i,'Total_BO_Spends_WB']):
            consolidated_spends.loc[i, 'Total_BO_Spends_WB'] = consolidated_spends.loc[i, 'Total_BO_Spends_NonWB']


    consolidated_spends = consolidated_spends.rename(columns={'Total_BO_Spends_WB':'Total_BO_Spends'}).drop(['Total_BO_Spends_NonWB'], axis=1)
    comp_ad5 = pd.merge(left=comp_dataframe,
             right=consolidated_spends,
             how='left',
             left_on='IMDB_Title_Code',
             right_on='IMDB_Title_Code').reset_index(drop=True)

    return comp_ad5

