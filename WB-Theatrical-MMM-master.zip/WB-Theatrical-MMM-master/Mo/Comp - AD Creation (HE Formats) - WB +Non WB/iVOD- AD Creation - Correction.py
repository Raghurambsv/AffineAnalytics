import pandas as pd
import numpy as np
# code dependancy - run "film_festivals.py"
# File Dependancies:
# Final_Film_Festival_All
# Genre_allmetrics_HE_Lifecycle
# Mkt Genre
# MKT_Genre_Curr_Data_061719
# NonWB_Modeling AD v1.0
# post_trak_film_lookup_results_2019_10_14_14_49_Week 2.1
# WB_Modelling AD v1.0
# WB+Comp_Titles_BO_HE_Revenue

nonwb = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\iVOD - AD Creation\NonWB_Modeling AD v1.0.xlsx",sheet_name="iVOD_TH+1 week(s)")
ivod = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\iVOD - AD Creation\WB_Modeling AD v1.0.xlsx",sheet_name="iVOD_TH+1 week(s)")
postrak = pd.read_excel(io=r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\iVOD - AD Creation\post_trak_film_lookup_results_2019_10_14__14_49_Week 2.1.xlsx",
                        sheet_name="Recovered_Sheet1")
nonwb['WB_Flag'] = 0
ivod['WB_Flag'] = 1

# Dropping the unnecessary columns

nonwb.drop(['Actor_0',
'Actor_1',
'Actor_2',
'Actor_3',
'Director_0',
'Director_1',
'Google_Search_Volume_2 Adstock Linear0.64'], axis=1,inplace=True)

ivod.drop(['Distribution_only',
'Actor_0',
'Actor_1',
'Actor_2',
'Actor_3',
'Director_0',
'Director_1',
'Estimated_BO_Revenue',
'max_combined_likes_till_2',
'avg_combined_likes_till_2',
'total_combined_likes_till_2',
'max_combined_views_till_2',
'avg_combined_views_till_2',
'total_combined_views_till_2',
'max_combined_comments_till_2',
'avg_combined_comments_till_2',
'total_combined_comments_till_2',
'max_combined_likes_by_views_till_2',
'avg_combined_likes_by_views_till_2',
'total_combined_likes_by_views_till_2',
'max_Wikipedia_Page_Views_till_2',
'avg_Wikipedia_Page_Views_till_2',
'total_Wikipedia_Page_Views_till_2',
'combined_likes',
'combined_views',
'combined_comments',
'combined_likes_by_views',
'combined_likes_2',
'combined_views_2',
'combined_comments_2',
'combined_likes_by_views_2',
'Wikipedia_Page_Views_2',
'combined_views_2 Adstock Linear0.848',
'combined_likes_2 Adstock Linear0.841',
'combined_comments_2 Adstock Linear0.9',
'combined_likes_by_views_2 Adstock Linear0.9',
'Google_Search_Volume_2 Adstock Linear0.832',
'Wikipedia_Page_Views_2 Adstock Linear0.808'], axis=1,inplace=True)

#run the film festival code - sandeeps code - to get FF data

nonwb2 = film_festival(df=nonwb,
                       film_festival_data=pd.read_excel(io=r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\iVOD - AD Creation\Final_Film_Festival_All.xlsx",
                                                       sheet_name="Final_Film_Festival_All",
                                                       na_values=["#N/A", "NA", "N/A", "na", " ", ""]).rename(columns={"IMDB Title Code":"IMDB_Title_Code"}))
nonwb2.isnull().sum()

# nonwb4[["count_film_festival",
#        "film_festival_binary_flag", "film_festival_flag"]].fillna(0, inplace=True)


nonwb2.fillna({"count_film_festival":0,
               "film_festival_binary_flag":0,
               "film_festival_flag":0},
              inplace=True)

grpd_genre = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\iVOD - AD Creation\Mkt Genre.xlsx")
base_genre = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\iVOD - AD Creation\MKT_Genre_Curr_Data_061719.xlsx")

nonwb3=pd.merge(left=nonwb2,
                right=base_genre[["IMDB_Title_Code",'Mkt_Genre']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code")
nonwb2.isnull().sum()

nonwb4=pd.merge(left=nonwb3,
                right=grpd_genre[['Mkt_Genre','Mkt_Genre_Grouped']],
                how="left",
                left_on="Mkt_Genre",
                right_on="Mkt_Genre")



# we need to add window so , similar to the excel calculated window for Non wb we need to calculate for wb also in excel
# the we merge it with their base ads

WB_window_calc = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\iVOD - AD Creation\WB_Modeling AD v1.0.xlsx",sheet_name= "Phase 2B 88 titles")
nonwb_window_calc= pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\iVOD - AD Creation\NonWB_Modeling AD v1.0.xlsx",sheet_name= "NonWB Titles")

nonwb5=pd.merge(left=nonwb4,
                right=nonwb_window_calc[['IMDB_Title_Code','iVOD_EST_Window']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code")

ivod2=pd.merge(left=ivod,
                right=WB_window_calc[['IMDB Title Code','iVOD_EST_Window']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB Title Code")
ivod2.drop(["IMDB Title Code"],axis=1,inplace=True)

ivod2.to_excel(r"C:\Users\hari\Desktop\ivod_new.xlsx",index=False)
nonwb5.to_excel(r"C:\Users\hari\Desktop\nonwb.xlsx",index=False)

# cvod3=cvod2
# cvod3.append(nonwb5)

# Concating the 2 dataframes into one single Comp AD - before that check whether the names are same - here it is
temp = pd.concat([ivod2, nonwb5], ignore_index=False, sort =True)
temp.to_excel(r"C:\Users\hari\Desktop\compadla.xlsx",index=False)
# adding the postrak data and Lifecycle data which rely on Title code and mkt genre
# adding postrak to the title

comp_ad=pd.merge(left=temp,
                right=postrak[['IMDB_Title_Code_new','Locs\nat\nWidest\nRelease', 'Definitely\nRecommend']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code_new")
# dropping the xetra title code new from postrak
comp_ad.drop(["IMDB_Title_Code_new"],
            axis=1,
            inplace=True)
# renaming the required columns
comp_ad.rename(columns={'Locs\nat\nWidest\nRelease':'Locations_Widest_Release', 'Definitely\nRecommend':'Definitely_Recommended'}, inplace=True)

# adding the lifecycle data to the Non WB data based on Mkt genre (the column is called genre in the file-"Genre_allmetrics_HE_Lifecycle")
lifecycle = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\iVOD - AD Creation\Genre_allmetrics_HE_Lifecycle.xlsx",sheet_name="T+1")

comp_ad2=pd.merge(left=comp_ad,
                right=lifecycle[['Mkt_Genre_Grouped','Definitely Interested',
'Definitely Interested among Aware',
'HE First Choice  ALL',
'Interest All Rent',
'Interest Any HE',
'Interest HE Any Only',
'Interest to Rent iVod',
'TOP2 Interested',
'Unaid']],
                how="left",
                left_on="Mkt_Genre_Grouped",
                right_on="Mkt_Genre_Grouped")

# adding the wb finance data

finance_data = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\iVOD - AD Creation\WB+Comp_Titles_BO_HE_Revenue.xlsx")


comp_ad3=pd.merge(left=comp_ad2,
                right=finance_data[['IMDB_Title_Code',"BO Spends(WB Finance)",	"HE Spends(WB Finance)"]],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code")

# we add the rotten tomatoes score to it
tomato = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\iVOD - AD Creation\rotten_tomatoes_score.xlsx")

comp_ad4=pd.merge(left=comp_ad3,
                right=tomato[['IMDB Title Code',"tomatometer"]],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB Title Code")
comp_ad4.drop(["IMDB Title Code"],
            axis=1,
            inplace=True)

# now we take it to excel
comp_ad4.to_excel(r"C:\Users\hari\Desktop\comp_ad+temp_ivod.xlsx",index=False)

# create dummmies for mkt genre
dummy=pd.get_dummies(comp_ad4["Mkt_Genre_Grouped"])
comp_ad5=pd.concat([comp_ad4,dummy],axis=1)



# rename the required columns
comp_ad5.rename(columns={'HE Spends(WB Finance)':'Total_HE_Spends', 'BO Spends(WB Finance)':'Total_BO_Spends'}, inplace=True)

# AD Creation
comp_ad5.to_excel(r"C:\Users\hari\Desktop\comp_ad5_ivod.xlsx",index=False)

# next step is to do imputations in excel with median or 0 (check mail) for Column Name	Imputation
# Film festival binary flag and Film festival flag	0
# actors_avg_rating	median
# avg_competitor_effect	median
# avg_Google_Search_Volume_till_2	0
# Competitor_Effect	0
# Locsat widest Release	median
# max_Google_Search_Volume_till_2	0
# Total_BO_Spends	kept it blank
# Total_HE_Spends	kept it blank
# cast_avg_rating	median
# Definitely
# Recommend	median