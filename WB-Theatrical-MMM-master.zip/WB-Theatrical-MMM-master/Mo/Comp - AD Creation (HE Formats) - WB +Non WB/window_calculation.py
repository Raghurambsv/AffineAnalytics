import pandas as pd
import numpy as np
import datetime
from datetime import datetime, timedelta
import math

def wb_window_calculation():

    # ----------------------------------WB Window Calc-----------------------------
    wb_window_calc = pd.read_excel(
            r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\WB_Modeling AD v1.0.xlsx",
            sheet_name="Phase 2B 88 titles")

    wb_est_window_calc = pd.read_excel(
        r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\WB_Modeling AD v1.0.xlsx",
        sheet_name="EST_TH+1 week(s)")
    wb_pst_window_calc = pd.read_excel(
        r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\WB_Modeling AD v1.0.xlsx",
        sheet_name="PST_TH+1 week(s)")
    wb_ivod_window_calc = pd.read_excel(
        r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\WB_Modeling AD v1.0.xlsx",
        sheet_name="iVOD_TH+1 week(s)")
    wb_cvod_window_calc = pd.read_excel(
        r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\WB_Modeling AD v1.0.xlsx",
        sheet_name="VOD_TH+1 week(s)")

    wb_window_calc.drop(['HE Release Date', 'EST Release Date',
                            'PST Release Date', 'iVOD Release Date',
                            'VOD Release Date','cVOD_EST_Window', 'cVOD_PST_Window'], axis=1, inplace=True)

    wb_window_calc = pd.merge(left=wb_window_calc.rename(columns={'IMDB Title Code': 'IMDB_Title_Code'}),
                                 right=
                                 pd.merge(left=wb_est_window_calc.groupby('IMDB_Title_Code').agg({"EST_Week_Number": 'min'}),
                                          right=wb_est_window_calc[['IMDB_Title_Code', 'EST_Week_Number', 'Week Start Date']],
                                          how='left',
                                          right_on=['IMDB_Title_Code', 'EST_Week_Number'],
                                          left_on=['IMDB_Title_Code', 'EST_Week_Number'])[
                                     ['IMDB_Title_Code', 'Week Start Date']],
                                 how='left',
                                 left_on='IMDB_Title_Code',
                                 right_on='IMDB_Title_Code').rename(columns={'Week Start Date': 'EST_Release_Date'})
    wb_window_calc = pd.merge(left=wb_window_calc.rename(columns={'IMDB Title Code': 'IMDB_Title_Code'}),
                                 right=
                                 pd.merge(left=wb_pst_window_calc.groupby('IMDB_Title_Code').agg({"PST_Week_Number": 'min'}),
                                          right=wb_pst_window_calc[['IMDB_Title_Code', 'PST_Week_Number', 'Week Start Date']],
                                          how='left',
                                          right_on=['IMDB_Title_Code', 'PST_Week_Number'],
                                          left_on=['IMDB_Title_Code', 'PST_Week_Number'])[
                                     ['IMDB_Title_Code', 'Week Start Date']],
                                 how='left',
                                 left_on='IMDB_Title_Code',
                                 right_on='IMDB_Title_Code').rename(columns={'Week Start Date': 'PST_Release_Date'})
    wb_window_calc = pd.merge(left=wb_window_calc.rename(columns={'IMDB Title Code': 'IMDB_Title_Code'}),
                                 right=
                                 pd.merge(left=wb_ivod_window_calc.groupby('IMDB_Title_Code').agg({"iVOD_Week_Number": 'min'}),
                                          right=wb_ivod_window_calc[
                                              ['IMDB_Title_Code', 'iVOD_Week_Number', 'Week Start Date']],
                                          how='left',
                                          right_on=['IMDB_Title_Code', 'iVOD_Week_Number'],
                                          left_on=['IMDB_Title_Code', 'iVOD_Week_Number'])[
                                     ['IMDB_Title_Code', 'Week Start Date']],
                                 how='left',
                                 left_on='IMDB_Title_Code',
                                 right_on='IMDB_Title_Code').rename(columns={'Week Start Date': 'iVOD_Release_Date'})
    wb_window_calc = pd.merge(left=wb_window_calc.rename(columns={'IMDB Title Code': 'IMDB_Title_Code'}),
                                 right=
                                 pd.merge(left=wb_cvod_window_calc.groupby('IMDB_Title_Code').agg({"VOD_Week_Number": 'min'}),
                                          right=wb_cvod_window_calc[['IMDB_Title_Code', 'VOD_Week_Number', 'Week Start Date']],
                                          how='left',
                                          right_on=['IMDB_Title_Code', 'VOD_Week_Number'],
                                          left_on=['IMDB_Title_Code', 'VOD_Week_Number'])[
                                     ['IMDB_Title_Code', 'Week Start Date']],
                                 how='left',
                                 left_on='IMDB_Title_Code',
                                 right_on='IMDB_Title_Code').rename(columns={'Week Start Date': 'VOD_Release_Date'})

    wb_window_calc["est_bo"] = round(((wb_window_calc["EST_Release_Date"] - wb_window_calc["Theatrical Release Date"]) / timedelta(7))+1)
    wb_window_calc["pst_est"] = ((wb_window_calc["PST_Release_Date"] - wb_window_calc["EST_Release_Date"]) / timedelta(7))
    wb_window_calc["min_vod_est"] = ((wb_window_calc[["iVOD_Release_Date", "VOD_Release_Date"]].min(axis=1) - wb_window_calc["EST_Release_Date"]) / timedelta(7))

    return wb_window_calc

    #  ------------------------------------Non WB-------------------------------------------
def nonwb_window_calculation():

    nonwb_window_calc = pd.read_excel(
            r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\NonWB_Modeling AD v1.0.xlsx",
            sheet_name="NonWB Titles")

    nonwb_est_window_calc = pd.read_excel(
        r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\NonWB_Modeling AD v1.0.xlsx",
        sheet_name="EST_TH+1 week(s)")
    nonwb_pst_window_calc = pd.read_excel(
        r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\NonWB_Modeling AD v1.0.xlsx",
        sheet_name="PST_TH+1 week(s)")
    nonwb_ivod_window_calc = pd.read_excel(
        r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\NonWB_Modeling AD v1.0.xlsx",
        sheet_name="iVOD_TH+1 week(s)")
    nonwb_cvod_window_calc = pd.read_excel(
        r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\NonWB_Modeling AD v1.0.xlsx",
        sheet_name="VOD_TH+1 week(s)")

    nonwb_window_calc.drop(['HE Release Date', 'EST Release Date',
                            'PST Release Date', 'iVOD Release Date',
                            'VOD Release Date','VOD_PST',
       'VOD_iVOD', 'VOD_EST', 'VOD_BO_Window', 'cVOD_EST_Window',
       'cVOD_PST_Window'], axis=1, inplace=True)

    nonwb_window_calc = pd.merge(left=nonwb_window_calc.rename(columns={'IMDB Title Code': 'IMDB_Title_Code'}),
                                 right=
                                 pd.merge(left=nonwb_est_window_calc.groupby('IMDB_Title_Code').agg({"EST_Week_Number": 'min'}),
                                          right=nonwb_est_window_calc[['IMDB_Title_Code', 'EST_Week_Number', 'Week Start Date']],
                                          how='left',
                                          right_on=['IMDB_Title_Code', 'EST_Week_Number'],
                                          left_on=['IMDB_Title_Code', 'EST_Week_Number'])[
                                     ['IMDB_Title_Code', 'Week Start Date']],
                                 how='left',
                                 left_on='IMDB_Title_Code',
                                 right_on='IMDB_Title_Code').rename(columns={'Week Start Date': 'EST_Release_Date'})
    nonwb_window_calc = pd.merge(left=nonwb_window_calc.rename(columns={'IMDB Title Code': 'IMDB_Title_Code'}),
                                 right=
                                 pd.merge(left=nonwb_pst_window_calc.groupby('IMDB_Title_Code').agg({"PST_Week_Number": 'min'}),
                                          right=nonwb_pst_window_calc[['IMDB_Title_Code', 'PST_Week_Number', 'Week Start Date']],
                                          how='left',
                                          right_on=['IMDB_Title_Code', 'PST_Week_Number'],
                                          left_on=['IMDB_Title_Code', 'PST_Week_Number'])[
                                     ['IMDB_Title_Code', 'Week Start Date']],
                                 how='left',
                                 left_on='IMDB_Title_Code',
                                 right_on='IMDB_Title_Code').rename(columns={'Week Start Date': 'PST_Release_Date'})
    nonwb_window_calc = pd.merge(left=nonwb_window_calc.rename(columns={'IMDB Title Code': 'IMDB_Title_Code'}),
                                 right=
                                 pd.merge(left=nonwb_ivod_window_calc.groupby('IMDB_Title_Code').agg({"iVOD_Week_Number": 'min'}),
                                          right=nonwb_ivod_window_calc[
                                              ['IMDB_Title_Code', 'iVOD_Week_Number', 'Week Start Date']],
                                          how='left',
                                          right_on=['IMDB_Title_Code', 'iVOD_Week_Number'],
                                          left_on=['IMDB_Title_Code', 'iVOD_Week_Number'])[
                                     ['IMDB_Title_Code', 'Week Start Date']],
                                 how='left',
                                 left_on='IMDB_Title_Code',
                                 right_on='IMDB_Title_Code').rename(columns={'Week Start Date': 'iVOD_Release_Date'})
    nonwb_window_calc = pd.merge(left=nonwb_window_calc.rename(columns={'IMDB Title Code': 'IMDB_Title_Code'}),
                                 right=
                                 pd.merge(left=nonwb_cvod_window_calc.groupby('IMDB_Title_Code').agg({"VOD_Week_Number": 'min'}),
                                          right=nonwb_cvod_window_calc[['IMDB_Title_Code', 'VOD_Week_Number', 'Week Start Date']],
                                          how='left',
                                          right_on=['IMDB_Title_Code', 'VOD_Week_Number'],
                                          left_on=['IMDB_Title_Code', 'VOD_Week_Number'])[
                                     ['IMDB_Title_Code', 'Week Start Date']],
                                 how='left',
                                 left_on='IMDB_Title_Code',
                                 right_on='IMDB_Title_Code').rename(columns={'Week Start Date': 'VOD_Release_Date'})

    nonwb_window_calc["est_bo"] = round(((nonwb_window_calc["EST_Release_Date"] - nonwb_window_calc["Theatrical Release Date"])/timedelta(7) )+ 1 )
    nonwb_window_calc["pst_est"] = ((nonwb_window_calc["PST_Release_Date"] - nonwb_window_calc["EST_Release_Date"]) / timedelta(7))
    nonwb_window_calc["min_vod_est"] = ((nonwb_window_calc[["iVOD_Release_Date", "VOD_Release_Date"]].min(axis=1) - nonwb_window_calc["EST_Release_Date"]) / timedelta(7))

    return nonwb_window_calc


