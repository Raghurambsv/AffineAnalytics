import pandas as pd
import numpy as np
import sys
sys.path.insert(0, r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\Mo\Comp - AD Creation (HE Formats) - WB +Non WB")
from postrak_update import*
from Lifecycle_update import*
from finance_update import*
from tomatometer_update import*
from dummy_variables import *
from film_festivals import *
from rename_update import *
from NRG_data import *
from title_metadata_function import *
import IVOD_V2
import EST_V2

# import PST_V2
# import CVOD_V2



format_needed = input ("Enter the format from below for which you would require the comp AD :"
                       "\n"
                       "* EST"
                       "\n"
                       "* PST" 
                       "\n"
                       "* CVOD"
                       "\n"
                       "* iVOD "
                       "\n")
# format_needed = format_needed.upper()
media = format_needed
print(format_needed)
sale = input("Enter the sales data which you would require in the comp AD :"
                       "\n"
                       "* Revenue"
                       "\n"
                       "* Units" 
                       "\n")
print(sale)

snapshot = print("The snapshot Considered is T+1 week / T+3 days : ")
snapshot = "T+3"
                  # "\n"
                  # "* T+3"
                  # "\n"
                  # "* T-7"
                  # "\n"
                  # "* T-30"
                  # "\n")
# snapshot = snapshot.upper()
print(snapshot)
#
# def choose_format(sale,format_needed,nonwb_df,wb_df,snapshot,root_folder,sharepoint_path):
#
#     switcher = {
#         'EST': EST_V2.est_function(sale,format_needed,nonwb_df,wb_df,snapshot,root_folder,sharepoint_path),
#         # 'PST': PST_V2.pst_function(sale,format_needed,nonwb_df,wb_df,snapshot,root_folder,sharepoint_path),
#         # 'CVOD': CVOD_V2.cvod_function(sale,format_needed,nonwb_df,wb_df,snapshot,root_folder,sharepoint_path),
#         'iVOD': IVOD_V2.ivod_function(sale,format_needed,nonwb_df,wb_df,snapshot,root_folder,sharepoint_path)
#     }
#     return switcher[format_needed]

def choose_format(sale,format_needed,nonwb_df,wb_df,snapshot,root_folder,sharepoint_path):
    if  (format_needed == 'EST'):
        comp_ad_required  = EST_V2.est_function(sale, format_needed, nonwb_df, wb_df, snapshot, root_folder, sharepoint_path)
    elif    (format_needed == 'iVOD'):
        comp_ad_required = IVOD_V2.ivod_function(sale, format_needed, nonwb_df, wb_df, snapshot, root_folder, sharepoint_path)
    return comp_ad_required




# sale,format_needed,nonwb_df,wb_df,snapshot,root_folder,sharepoint_path
# "C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/WB HE Format Modelling AD.xlsx"
# "C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/NonWB HE Format Modelling AD.xlsx"
# nonwb = pd.read_excel(
#         sharepoint_path+r"\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\NonWB_Modeling AD v1.0.xlsx",
#         sheet_name="EST_TH+1 week(s)")
# EST = pd.read_excel(
#         r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\WB_Modeling AD v1.0.xlsx",
#         sheet_name="EST_TH+1 week(s)")
# EST_TH+1 week(s)Units
# EST_TH+1 week(s)Revenue

comp_ad_required = choose_format(sale = sale,
                                 format_needed = format_needed,
                                 nonwb_df = pd.read_excel(
                                            "C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/NonWB HE Format Modelling AD.xlsx",
                                            sheet_name=media+'_TH+1 week(s)'+sale),

                                 wb_df = pd.read_excel(
                                            io="C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/WB HE Format Modelling AD.xlsx",
                                            sheet_name=media+'_TH+1 week(s)'+sale),
                                 snapshot = snapshot,
                                 root_folder=r"C:/Users/hari/PycharmProjects",
                                 sharepoint_path=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents")

# ---------------------------------Merging the rest with the comp ad -------------
#Give the Share Point Path
sharepoint_path = r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents"
root_folder=r"C:/Users/hari/PycharmProjects"

# taking the obtained comp_ad_required to merge it with postrak data
comp_ad = postrak_function(comp_ad_required,sharepoint_path)
# adding the lifecycle data to the Non WB data based on Mkt genre (the column is called genre in the file-"Genre_allmetrics_HE_Lifecycle")
comp_ad2= lifecycle_function_latest(comp_ad,sharepoint_path)
# adding the Rotten Tomatoes score
comp_ad3 =rotten_tomato_score(comp_ad2,sharepoint_path)
# adding the Dummy Variables for MKT_Gnere_Grouped
comp_ad4 = dummy_variable_function(comp_ad3)
# Adding the NRG Data - Mkt Genre Grouped level
comp_ad5 = nrg_function(comp_ad4 ,sharepoint_path)
# Adding the Title meta data function
comp_ad6 = metadata_function(comp_ad5 ,sharepoint_path)

# Since the below mentioned dates file was not the best one - (best one is at "06. HE Format level Models\Phase 2\Data Harmonizing - Cleaning\Intermediate Data - Cleaned\All Corrected Release Dates.xlsx") - which has actual not fixed released dates
# if one needs release dates refer the best one  or if one needs corrected with day starting on sunday - apply the formula =if(weekday(a2)=1,a2,a2-weekday(a2)) on the weekday to get the fixe dstart sunday release date
# as of now the dates  file has been moved to this location ("06. HE Format level Models\Phase 2\Data Harmonizing - Cleaning\Archive\all comp Best dates.xlsx")
# dates = pd.read_excel( io=r"C:\Users\hari\Desktop\all comp Best dates.xlsx")
# comp_ad7 = pd.merge(
#     left=comp_ad6,
#     right= dates,
#     how = "left",
#     left_on="IMDB_Title_Code",
#     right_on="IMDB_Title_Code"
# )

comp_ad7 = comp_ad6.copy()

# after this run gs_and_spends_adstock.py - with comp ad 7
# -----

# comp_ad7.to_excel(r"C:\Users\hari\Desktop\tbests_df_till_6pm.xlsx",index=False)
# combined_df

# # Adding the Finance data
# comp_ad5 = finance_function(comp_ad4)
# # Renaming the columns using a separate function
# comp_ad6 = renaming_function(format_needed,comp_ad5)

# AD Creation to excel
# comp_ad6.to_excel(r"C:\Users\hari\Desktop\final_comp_ad5_ivod.xlsx", index=False)

    # next step is to do imputations in excel with median or 0 (check mail) for Column Name	Imputation
    # Film festival binary flag and Film festival flag	0
    # actors_avg_rating	median
    # avg_competitor_effect	median
    # avg_Google_Search_Volume_till_2	0
    # Competitor_Effect	0
    # Locsat widest Release	median
    # max_Google_Search_Volume_till_2	0
    # Total_BO_Spends	kept it blank
    # Total_HE_Spends	kept it blank
    # cast_avg_rating	median
    # Definitely
    # Recommend	median







