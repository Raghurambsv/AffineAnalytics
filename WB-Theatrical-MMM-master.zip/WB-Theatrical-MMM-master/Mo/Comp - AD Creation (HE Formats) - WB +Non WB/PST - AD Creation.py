import pandas as pd
import numpy as np
# code dependancy - run "film_festivals.py"


nonwb = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\NonWB_Modeling AD v1.0.xlsx",sheet_name="PST_TH+1 week(s)")
PST = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\PST_3_v1 - Original Copy.xlsx",sheet_name="PST_3_v1")
window_calc = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\NonWB_Modeling AD v1.0.xlsx",sheet_name= "NonWB Titles")

# postrak 2.4 created from available version 2 and vlookingup titles from v3 - check in est foledr for actual names
# delete top 2 rows in original file and paste as values in the postrak file
postrak = pd.read_excel(io=r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\post_trak_film_lookup_results_2019_10_14__14_49_Week 2.1.xlsx",
                        sheet_name="Recovered_Sheet1")

# add the wb flag to both files
nonwb['WB_Flag'] = 0
PST['WB_Flag'] = 1


# nonwb.columns.values

grpd_genre = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\Mkt Genre.xlsx")
base_genre = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\MKT_Genre_Curr_Data_061719.xlsx")


nonwb2=pd.merge(left=nonwb,
                right=base_genre[["IMDB_Title_Code",'Mkt_Genre']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code")

nonwb2.isnull().sum()

nonwb3=pd.merge(left=nonwb2,
                right=grpd_genre[['Mkt_Genre','Mkt_Genre_Grouped']],
                how="left",
                left_on="Mkt_Genre",
                right_on="Mkt_Genre")

#run the film festival code - sandeeps code - to get FF data

nonwb4 = film_festival(df=nonwb3,
                       film_festival_data=pd.read_excel(io=r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\Final_Film_Festival_All.xlsx",
                                                       sheet_name="Final_Film_Festival_All",
                                                       na_values=["#N/A", "NA", "N/A", "na", " ", ""]).rename(columns={"IMDB Title Code":"IMDB_Title_Code"}))
nonwb4.isnull().sum()

# nonwb4[["count_film_festival",
#        "film_festival_binary_flag", "film_festival_flag"]].fillna(0, inplace=True)


nonwb4.fillna({"count_film_festival":0,
               "film_festival_binary_flag":0,
               "film_festival_flag":0},
              inplace=True)

# nonwb4.loc[nonwb4[["count_film_festival",
#        "film_festival_binary_flag", "film_festival_flag"]==0].sum()

nonwb5=pd.merge(left=nonwb4,
                right=window_calc[['IMDB_Title_Code','EST_PST_Window']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code")

nonwb5.to_excel(r"C:\Users\hari\Desktop\Nonwb5.xlsx",index=False)

# ad_wb = pd.read_excel(r"C:\Users\hari\Desktop\cVOD - Non WB\WB_Modeling AD v1.0.xlsx",sheet_name= "PST_TH+1 week(s)")
# cVOD2=pd.merge(left=cVOD,
#                 right=ad_wb[['IMDB_Title_Code','Actor_0_Rating', 'Actor_1_Rating', 'Actor_2_Rating',
#                              'Actor_3_Rating', 'actors_avg_rating', 'Director_0', 'Director_1']],
#                 how="left",
#                 left_on="IMDB_Title_Code",
#                 right_on="IMDB_Title_Code")
# nonwb5.to_excel(r"C:\Users\hari\Desktop\Nonwb5.xlsx",index=False)
# cVOD2.to_excel(r"C:\Users\hari\Desktop\cVOD2.xlsx",index=False)
# -------------------------------------------------------------------------------------
#next step - drop the unneccsary variables

nonwb5.drop(["Actor_0","Actor_1","Actor_2","Actor_3","Director_0","Director_1"],
            axis=1,
            inplace=True)

nonwb5.to_excel(r"C:\Users\hari\Desktop\Nonwb5.xlsx",index=False)

# cVOD2.drop(["VOD_EST","Actor_0_Rating_y","Actor_1_Rating_y","Actor_2_Rating_y","Actor_3_Rating_y","actors_avg_rating_y","Director_0","Director_1"],
#             axis=1,
#             inplace=True)
# cVOD2.to_excel(r"C:\Users\hari\Desktop\cVOD2.xlsx",index=False)

# nonwb5.drop(["IMDB Title Code"],
#             axis=1,
#             inplace=True)


# temp = pd.concat([cVOD2.rename(columns={'Actor_0_Rating_x':'Actor_0_Rating',
#                                         'Actor_1_Rating_x':'Actor_1_Rating',
#                                         'Actor_2_Rating_x':'Actor_2_Rating',
#                                         'Actor_3_Rating_x':'Actor_3_Rating',
#                                         'actors_avg_rating_x':'actors_avg_rating'}),
#                   nonwb5.rename(columns={
#
#                   })],
#                  sort=True,
#                  axis=0)

# adding the lifecycle data to the Non WB data based on Mkt genre (the column is called genre in the file-"Genre_allmetrics_HE_Lifecycle")
lifecycle = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\Genre_allmetrics_HE_Lifecycle.xlsx",sheet_name="T+1")

nonwb6=pd.merge(left=nonwb5,
                right=lifecycle[['Mkt_Genre_Grouped', 'Definitely Interested',
       'Definitely Interested among Aware', 'HE First Choice  ALL',
       'Interest Any Buy',
       'Interest Any Buy Physical', 'Interest Any HE',
       'Interest HE Any Only',
       'Interest to Rent Phy Disc', 'TOP2 Interested', 'Unaid']],
                how="left",
                left_on="Mkt_Genre_Grouped",
                right_on="Mkt_Genre_Grouped")

nonwb6.to_excel(r"C:\Users\hari\Desktop\Nonwb6.xlsx",index=False)

# adding postrak to the title

nonwb7=pd.merge(left=nonwb6,
                right=postrak[['IMDB_Title_Code_new','Locs\nat\nWidest\nRelease', 'Definitely\nRecommend']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code_new")
# dropping the extra title code new from postrak
nonwb7.drop(["IMDB_Title_Code_new"],
            axis=1,
            inplace=True)

nonwb7.to_excel(r"C:\Users\hari\Desktop\nonwb6.xlsx",index=False)

# adding the wb finance data
#  here we created a new column in the wb finance file - named as Total Est spends - which is 45% of total he spends wb finance
finance_data = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\WB+Comp_Titles_BO_HE_Revenue.xlsx")


nonwb8=pd.merge(left=nonwb7,
                right=finance_data[['IMDB_Title_Code', 'BO Spends(WB Finance)',
       'Total EST Spends(WB Finance)']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code")

# renaming required columns
nonwb8.rename(columns={'BO Spends(WB Finance)':'Total_BO_Spends', 'Total EST Spends(WB Finance)':'Total_EST_Spends'}, inplace=True)

# adding new reqiued columns such as Summer_Flag, Theatrical_Release_Month, Week_Start_Month in EXCEL
nonwb8.to_excel(r"C:\Users\hari\Desktop\nonwb6.xlsx",index=False)

# after adding Theatrical_Release_Month, Week_Start_Month in EXCEL , read the dataframe back to Python
# we didnt add summer flag becaue amit told to drop the seasonality variable
nonwb9 = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\PST - AD Creation\Nonwb6.xlsx")


# nonwb8.to_excel(r"C:\Users\hari\Desktop\nonwb6.xlsx",index=False)

nonwb10 = nonwb9[['Actor_0_Rating',
'Actor_1_Rating',
'Actor_2_Rating',
'Actor_3_Rating',
'actors_avg_rating',
'avg_competitor_effect',
'avg_earnings_franchise',
'avg_Google_Search_Volume_till_2',
'cast_avg_rating',
'Competitor_Effect',
'count_film_festival',
'Definitely Interested',
'Definitely Interested among Aware',
'DefinitelyRecommend',
'Director_0_Rating',
'Director_1_Rating',
'directors_avg_rating',
'EST_PST_Window',
'film_festival_binary_flag',
'film_festival_flag',
'franchise_flag',
'franchise_releases_in_last_2_years',
'franchise_releases_in_last_3_years',
'franchise_releases_in_last_4_years',
'Google_Search_Volume_2',
'Google_Search_Volume_2 Adstock Linear0.804',
'HE First Choice  ALL',
'holiday_flag',
'holiday_flag_Clubbed',
'IMDB Title Name',
'IMDB_Title_Code',
'Interest Any Buy',
'Interest Any Buy Physical',
'Interest Any HE',
'Interest HE Any Only',
'Interest to Rent Phy Disc',
'long_weekend_flag',
'long_weekend_flag_Clubbed',
'MajorFranchise',
'max_Google_Search_Volume_till_2',
'Mkt_Genre',
'Mkt_Genre_Grouped',
'Opening_Weekend_BO',
'PST Revenue',
'PST Revenue_Clubbed',
'PST_Week_Number',
'TH_Week_Number',
'Theatrical_Release_Date',
'Theatrical_Release_Month',
'Theatrical_Release_Year',
'time_delta_since_last_franchise_release',
'TOP2 Interested',
'Total_BO_Spends',
'Total_EST_Spends',
'total_Google_Search_Volume_till_2',
'Unaid',
'WB_Flag',
'Week Start Date',
'Week_Start_Month',
'Widest']]




PST2= PST[['Actor_0_Rating',
'Actor_1_Rating',
'Actor_2_Rating',
'Actor_3_Rating',
'actors_avg_rating',
'avg_competitor_effect',
'avg_earnings_franchise',
'avg_Google_Search_Volume_till_2',
'cast_avg_rating',
'Competitor_Effect',
'count_film_festival',
'Definitely Interested',
'Definitely Interested among Aware',
'DefinitelyRecommed',
'Director_0_Rating',
'Director_1_Rating',
'directors_avg_rating',
'EST_PST_Window',
'film_festival_binary_flag',
'film_festival_flag',
'franchise_flag',
'franchise_releases_in_last_2_years',
'franchise_releases_in_last_3_years',
'franchise_releases_in_last_4_years',
'Google_Search_Volume_2',
'Google_Search_Volume_2 Adstock Linear0.9',
'HE First Choice',
'holiday_flag',
'holiday_flag_Clubbed',
'IMDB Title Name',
'IMDB_Title_Code',
'Interest Any Buy',
'Interest Any Buy Physical',
'Interest Any HE',
'Interest HE Any Only',
'Interest to Rent Phy Disc',
'long_weekend_flag',
'long_weekend_flag_Clubbed',
'MajorFranchise',
'max_Google_Search_Volume_till_2',
'Mkt_Genre',
'Mkt_Genre_Grouped',
'Opening_Weekend_BO',
'PST Revenue',
'PST Revenue_Clubbed',
'PST_Week_Number',
'TH_Week_Number',
'Theatrical_Release_Date',
'Theatrical_Release_Month',
'Theatrical_Release_Year',
'time_delta_since_last_franchise_release',
'TOP2 Interested',
'Total_BO_Spends',
'Total_EST_Spends',
'total_Google_Search_Volume_till_2',
'Unaid',
'WB_Flag',
'Week Start Date',
'Week_Start_Month',
'Widset',
]]



nonwb10.to_excel(r"C:\Users\hari\Desktop\nonwb10.xlsx",index=False)
PST2.to_excel(r"C:\Users\hari\Desktop\PST2.xlsx",index=False)
# changed the Theatrical release month from numbers to dates, similarly for week start month in Non wb AD


# HERE WE CONCATED THE ADS MANUALLY AFTER GETTING THE FINAL BEST ONES PST AND NON WB
# / THEN WE ADDED THE PST UNITS - CLUBBED FROM - "WB_Weekly_HE_Revenue_v4.0" -  Vlook up from pivot of title code and week number to get the pst units then is ans sum if conditions to get the clubbed one
#  check "units - all data " in PST file local

# ------------------------------------

# after this compare the order of both columns in the excel sheets created above
# append both the dataframes into one manually or via code (manually preferred bacz concat not working properly)
# result = pd.concat([df1, df4], axis=1, join='inner')

# comp_ad=pd.concat([nonwb10.drop('Google_Search_Volume_2 Adstock Linear0.804', axis=1),
#                    PST2.rename(columns={'Widset':'Widest'}).drop('Google_Search_Volume_2 Adstock Linear0.9', axis=1)],axis=0,sort=False)
#
# comp_ad.to_excel(r"C:\Users\hari\Desktop\comp_ad.xlsx",index=False)




comp_ad3.to_excel(r"C:\Users\hari\Desktop\comp_ad3.xlsx",index=False)