import numpy as np
import pandas as pd
from tqdm import tqdm
sys.path.insert(0, root_folder+r"/WB-Theatrical-MMM/Phase 2 Codes/03. Feature Engineering")
from AdstockClass import Adstock

sharepoint_path = r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents"
root_folder=r"C:/Users/hari/PycharmProjects"
# sharepoint_path+"/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Google Search Data/Google Search Data_v5.xlsx"

updated_gs_vol=pd.read_excel(io=sharepoint_path+"/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Google Search Data/Google Search Data_v5.xlsx",
                                                                           sheet_name="GS Data",
                                                                            na_values=['#NA','#N/A','',' ','na','NA']).rename(columns={'IMDB Title Code': 'IMDB_Title_Code',
                                                                        'IMDB Title Name': 'IMDB_Title_Name',
                                                                        'Theatrical Release Date': 'Theatrical_Release_Date',
                                                                        'Week Start Date': 'Week_Start_Date',
                                                                        'Week Number': 'TH_Week_Number',
                                                                        'Google Search Volume': 'Google_Search_Volume'})


# Creating the exhaustive dataframe for th-100 to th+99 to add gs and spends data at a title th level

comp_ad7['temp_join'] = 1
#updated_gs_vol['temp_join'] = 1
temp_df = comp_ad7['IMDB_Title_Code'].unique()
all_titles=pd.DataFrame(temp_df)
all_titles['temp_join'] = 1
all_titles.rename(columns = {0:'IMDB_Title_Code'},inplace=True)

all_weeks = pd.DataFrame()
all_weeks['TH_Week_Number'] = np.arange(-100, 100)
all_weeks['temp_join'] = 1

exhaustive_dataframe = pd.merge(all_titles, all_weeks, on=['temp_join'])

# merging the dataframes
combined_df_2 = pd.merge (
    left = exhaustive_dataframe,
    right=comp_ad7,
    how= "left",
    left_on=['IMDB_Title_Code','TH_Week_Number'],
    right_on=['IMDB_Title_Code','TH_Week_Number']
)
combined_df_3= pd.merge(
    left = combined_df_2,
    right=updated_gs_vol,
    how= "left",
    left_on=['IMDB_Title_Code','TH_Week_Number'],
    right_on=['IMDB_Title_Code','TH_Week_Number']
)

#  Now working upon the GSV2.0 data - to append to dataframe
# th+1 > weeks GSV 2.0 is imputed as 0

combined_df_3.loc[combined_df_3['TH_Week_Number'] > 1, ['Google_Search_Volume']] = 0

list1 = combined_df_2.columns


# Creating Adstock for these combined metrics using optimal lambda
        class_instance = Adstock(base_dataframe=combined_df_3,
                                 dictionary_spends={'Google_Search_Volume': [0.1, 'Linear']},
                                 week_number_colname='TH_Week_Number',
                                 revenue_colname=''+media+' Revenue')
        combined_df_3 = class_instance.optimise_adstock()

# combined_df_3.to_excel(r"C:/Users/hari/Desktop/temp_4.xlsx",index=False)

# OLD GSV 1.0 Data and its adstock

old_gs_vol=pd.read_excel(io=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Google Search Data/Google Search Data_1.0 cleaned.xlsx",
                                                                           sheet_name="GS Data",
                                                                            na_values=['#NA','#N/A','',' ','na','NA']).rename(columns={'IMDB Title Code': 'IMDB_Title_Code',
                                                                        'IMDB Title Name': 'IMDB_Title_Name',
                                                                        'Theatrical Release Date': 'Theatrical_Release_Date',
                                                                        'Week Start Date': 'Week_Start_Date',
                                                                        'Week Number': 'TH_Week_Number',
                                                                        'Google Search Volume': 'Google_Search_Volume_old1.0'})

old_gs_vol.loc[old_gs_vol['TH_Week_Number'] > 1, ['Google_Search_Volume_old1.0']] = 0

combined_df_3= pd.merge(
    left = combined_df_3,
    right=old_gs_vol.drop(['IMDB_Title_Name', 'Theatrical_Release_Date','Week_Start_Date'],axis =1),
    how= "left",
    left_on=['IMDB_Title_Code','TH_Week_Number'],
    right_on=['IMDB_Title_Code','TH_Week_Number']
)



# list1 = combined_df_2.columns


# Creating Adstock for these combined metrics using optimal lambda
        class_instance = Adstock(base_dataframe=combined_df_3,
                                 dictionary_spends={'Google_Search_Volume_old1.0': [0.1, 'Linear']},
                                 week_number_colname='TH_Week_Number',
                                 revenue_colname=''+media+' Revenue')
        combined_df_3 = class_instance.optimise_adstock()

# Creating some basic mean/max variables out of the combined variables OLD GSV 1.0 and NEW GSV 2.0
combined_df_3['Google_Search_Volume_new_max'] = combined_df_3.groupby(['IMDB_Title_Code'])['Google_Search_Volume'].transform('max')
combined_df_3['Google_Search_Volume_new_mean'] = combined_df_3.groupby(['IMDB_Title_Code'])['Google_Search_Volume'].transform('mean')
combined_df_3['Google_Search_Volume_new_sum'] = combined_df_3.groupby(['IMDB_Title_Code'])['Google_Search_Volume'].transform('sum')

combined_df_3['Google_Search_Volume_old_max'] = combined_df_3.groupby(['IMDB_Title_Code'])['Google_Search_Volume_old1.0'].transform('max')
combined_df_3['Google_Search_Volume_old_mean'] = combined_df_3.groupby(['IMDB_Title_Code'])['Google_Search_Volume_old1.0'].transform('mean')
combined_df_3['Google_Search_Volume_old_sum'] = combined_df_3.groupby(['IMDB_Title_Code'])['Google_Search_Volume_old1.0'].transform('sum')


updated_finance=pd.read_excel(io=sharepoint_path+r"/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/Intermediate Data - Cleaned/Spends Redistribution File.xlsx",
                                                                           sheet_name="final merged correct",
                                                                            na_values=['#NA','#N/A','',' ','na','NA']).rename(columns={'IMDB Title Code': 'IMDB_Title_Code',
                                                                        'IMDB Title Name': 'IMDB_Title_Name',
                                                                        'HE Release Date':'HE_Release_Date',
                                                                        'BO Spends':'BO_Spends'})

combined_df_4= pd.merge(
    left = combined_df_3,
    right=updated_finance,
    how= "left",
    left_on=['IMDB_Title_Code','TH_Week_Number'],
    right_on=['IMDB_Title_Code','TH_Week_Number']
)
# combined_df_4.to
# del combined_df_4
# combined_df_4['BO_Spends_sum'] = combined_df_4.groupby(combined_df_4['IMDB_Title_Code'])(combined_df_4['BO_Spends']).sum()
combined_df_temp = pd.DataFrame()
combined_df_temp = combined_df_4.groupby('IMDB_Title_Code')['BO_Spends'].sum().reset_index()
combined_df_temp.rename(columns = {'BO_Spends':'BO_Spends_Sum'},inplace = True)
combined_df_4= pd.merge(
    left = combined_df_4,
    right=combined_df_temp,
    how= "left",
    left_on=['IMDB_Title_Code'],
    right_on=['IMDB_Title_Code']
)

combined_df_4.loc[combined_df_4['TH_Week_Number'] > 1, ['BO_Spends']] = 0

        class_instance = Adstock(base_dataframe=combined_df_4,
                                 dictionary_spends={'BO_Spends': [0.1, 'Linear']},
                                 week_number_colname='TH_Week_Number',
                                 revenue_colname=''+media+' Revenue')
        combined_df_4 = class_instance.optimise_adstock()



col_names = list(map(str,list(combined_df_4.columns)))

temp_col_list=[]
for i in col_names:
    temp_col_list.append(i.strip().lower().replace('  ', ' ').replace(' ', '_').replace('(', '').replace(')','').replace(',','').replace("'",""))
combined_df_4.columns = temp_col_list

# Lifecycle 2gb file merge and demo data

Lifecycle_2gb =pd.read_excel(io=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/Intermediate Data - Cleaned/Genre_allmetrics_HE_Lifecycle_v2.xlsx",
                                                                           sheet_name="reading sheet",
                                                                            na_values=['#NA','#N/A','',' ','na','NA']).drop('lc_HE First Choice  ALL_new',axis = 1)
combined_df_4= pd.merge(
    left = combined_df_4,
    right=Lifecycle_2gb,
    how= "left",
    left_on=['mkt_genre_grouped'],
    right_on=['mkt_genre_grouped']
)

# we are doing this here to rename the follwing dup;ocate columns
# imdb_title_name_x -- 2 are there - rename one with_extra
# week_start_date -- 2 are there - rename one with_extra
# imdb_title_name_y -- 2 are there - rename one with_extra
# he_release_date -- 2 are there - rename one with_extra
# combined_df_4.to_excel(r"C:/Users/hari/Desktop/ivod_unit_ad_as_of_dec31_9pm.xlsx",index=False)


# RENAMING SOME REDUNDANT COLUMNS AS MENTIONED ABOVE

cols=pd.Series(combined_df_4.columns)

for dup in cols[cols.duplicated()].unique():
    cols[cols[cols == dup].index.values.tolist()] = [dup + '_' + str(i) if i != 0 else dup for i in range(sum(cols == dup))]

# rename the columns with the cols list.
combined_df_4.columns=cols

# goyala_temp.to_excel(r"C:/Users/hari/Desktop/dlete_aftr_chking.xlsx",index=False)

# combined_df_4 =pd.read_excel(io=r"C:/Users/hari/Desktop/rename ivod units ad.xlsx",sheet_name="Sheet1")

# creating a dataframe to get mkt_genre_grouped populated for all

mkt_df = combined_df_4[combined_df_4['ivod_week_number']==0]
mkt_df2 = mkt_df[['imdb_title_code','mkt_genre_grouped']]

mkt_df = combined_df_4[combined_df_4['est_week_number']==0]
mkt_df2 = mkt_df[['imdb_title_code','mkt_genre_grouped']]

# merging modelling ad with this dataframe to get mkt genre populated for all

combined_df_5 = pd.merge(left=combined_df_4.drop(columns = ['mkt_genre_grouped']) ,
                         right =mkt_df2 ,
                         how= 'left',
                         left_on=['imdb_title_code'],
                         right_on=['imdb_title_code'])

# just_in_case_df =combined_df_5.copy()

# del from goy to goy

#goy

# del_later_ivod =pd.read_excel(io=r"C:/Users/hari/Desktop/ivod_AD_v1.2_demo_comp.xlsx",
#                                                                            sheet_name="Sheet1",
#                                                                             na_values=['#NA','#N/A','',' ','na','NA'])
#
# demo_data =pd.read_excel(io=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/Intermediate Data - Cleaned/audience_demo_cleaned_day1.xlsx",
#                                                                            sheet_name="audience_demo_cleaned_day1",
#                                                                             na_values=['#NA','#N/A','',' ','na','NA']).rename(columns={'IMDB Title Code': 'imdb_title_code'})#.drop(columns = ['mkt_genre_grouped'])
#
# # adding title level mkt_genre_grouped inorder to impute for missing demo data - grouping by available demo data mky_grouped_genre wise
# demo_data= pd.merge(
#     left = mkt_df2,
#     right=demo_data,
#     how= "left",
#     left_on=['imdb_title_code'],
#     right_on=['imdb_title_code']
# )
#
# # demo_data.dropna(subset=['mkt_genre_grouped'], inplace=True)
# final_col = list(demo_data.columns)
# exclude = ['ODID', 'imdb_title_code', 'Film Title', 'Release Period','mkt_genre_grouped']
# for i in tqdm(list(demo_data.columns)):
#     if (i not in exclude):
#         tempNA = demo_data.loc[pd.isnull(demo_data[i]), :]
#         tempNonNA = demo_data.loc[~(pd.isnull(demo_data[i])), :]
#         grouped = tempNonNA.groupby('mkt_genre_grouped').agg({i: 'mean'}).reset_index()
#         tempNA = pd.merge(left=tempNA.drop(i, axis=1),
#                           right=grouped,
#                           how='left',
#                           on='mkt_genre_grouped')
#         demo_data = pd.concat([tempNA, tempNonNA],
#                               axis=0,
#                               sort=True)
# demo_data = demo_data[final_col]
#
# # demo_data.to_excel(r"C:/Users/hari/Desktop/demo_data_imputed.xlsx", index=False)
#
# combined_df_6_temp= pd.merge(
#     left = del_later_ivod,
#     right=demo_data.drop(columns = ['mkt_genre_grouped']),
#     how= "left",
#     left_on=['imdb_title_code'],
#     right_on=['imdb_title_code']
# )
#
# combined_df_6_temp.to_excel(r"C:/Users/hari/Desktop/ivod_AD_v1.3_demo_comp.xlsx",index=False)
#

# goy

demo_data =pd.read_excel(io=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/Intermediate Data - Cleaned/audience_demo_cleaned_day1.xlsx",
                                                                           sheet_name="audience_demo_cleaned_day1",
                                                                            na_values=['#NA','#N/A','',' ','na','NA']).rename(columns={'IMDB Title Code': 'imdb_title_code'})#.drop(columns = ['mkt_genre_grouped'])

# adding title level mkt_genre_grouped inorder to impute for missing demo data - grouping by available demo data mky_grouped_genre wise
demo_data= pd.merge(
    left = mkt_df2,
    right=demo_data,
    how= "left",
    left_on=['imdb_title_code'],
    right_on=['imdb_title_code']
)

# demo_data.dropna(subset=['mkt_genre_grouped'], inplace=True)
final_col = list(demo_data.columns)
exclude = ['ODID', 'imdb_title_code', 'Film Title', 'Release Period','mkt_genre_grouped']
for i in tqdm(list(demo_data.columns)):
    if (i not in exclude):
        tempNA = demo_data.loc[pd.isnull(demo_data[i]), :]
        tempNonNA = demo_data.loc[~(pd.isnull(demo_data[i])), :]
        grouped = tempNonNA.groupby('mkt_genre_grouped').agg({i: 'mean'}).reset_index()
        tempNA = pd.merge(left=tempNA.drop(i, axis=1),
                          right=grouped,
                          how='left',
                          on='mkt_genre_grouped')
        demo_data = pd.concat([tempNA, tempNonNA],
                              axis=0,
                              sort=True)
demo_data = demo_data[final_col]

# demo_data.to_excel(r"C:/Users/hari/Desktop/demo_data_imputed.xlsx", index=False)

combined_df_6= pd.merge(
    left = combined_df_5,
    right=demo_data.drop(columns = ['mkt_genre_grouped']),
    how= "left",
    left_on=['imdb_title_code'],
    right_on=['imdb_title_code']
)

# temp = modelling_ad.loc[modelling_ad['imdb_title_code']!='tt7905466',:]
# temp.columns[temp.isnull().any()]
# combined_df_4.to_excel(r"C:/Users/hari/Desktop/sande est units ad_dec30.xlsx",index=False)

# adding latest comp index for ivod units ad

comp_wb = pd.read_excel(io=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Competitor Effect/WB Titles/WB_Competitor Effect_iVOD.xlsx",sheet_name="Weekly Competitor Effect")
comp_nonwb = pd.read_excel(io=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Competitor Effect/NonWB Titles/NonWB_Competitor Effect_iVOD.xlsx",sheet_name="Weekly Competitor Effect")

combined_comp = pd.concat([comp_wb,comp_nonwb],axis=0)

media = 'ivod'
combined_df_7 = pd.merge(left=combined_df_6,
                       right=combined_comp.drop_duplicates().rename(
                           columns={'IMDB Title Code': 'imdb_title_code',
                                    'Week Number': media + '_week_number',
                                    'Competitor Index': 'new_competitor_effect'}).drop(columns = ['IMDB Title Name','iVOD Release Date']),
                       how='left',
                       left_on=['imdb_title_code', media + '_week_number'],
                       right_on=['imdb_title_code', media + '_week_number'])
combined_df_8 = pd.merge(left=combined_df_7,
                       right=combined_df_7.groupby(['imdb_title_code']).agg(
                           {'new_competitor_effect': np.nanmean}).reset_index().rename(
                           columns={'new_competitor_effect': 'new_avg_competitor_effect'}),
                       how='left',
                       left_on='imdb_title_code',
                       right_on='imdb_title_code')

# Adding correct windows for the AD
window_calc_new =pd.read_excel(io=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/Intermediate Data - Cleaned/calculated_window_est_ivod_revenue_units_dec30.xlsx",
                               sheet_name="est_ivod_units_window")
combined_df_9 = pd.merge(left = combined_df_8,
                         right=window_calc_new[['imdb_title_code','new_iVOD_BO_window','new_EST_BO_window','new_EST_IVOD_window']] ,
                         how = 'left',
                         on = 'imdb_title_code')


combined_df_9.to_excel(r"C:/Users/hari/Desktop/best ivod units ad_dec31_v3_withcomp_effect.xlsx",index=False)


# adding latest comp index for est units ad


comp_wb = pd.read_excel(io=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Competitor Effect/WB Titles/WB_Competitor Effect_EST.xlsx",sheet_name="Weekly Competitor Effect")
comp_nonwb = pd.read_excel(io=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Competitor Effect/NonWB Titles/NonWB_Competitor Effect_EST.xlsx",sheet_name="Weekly Competitor Effect")

combined_comp = pd.concat([comp_wb,comp_nonwb],axis=0)

media = 'est'
combined_df_7 = pd.merge(left=combined_df_6,
                       right=combined_comp.drop_duplicates().rename(
                           columns={'IMDB Title Code': 'imdb_title_code',
                                    'Week Number': media + '_week_number',
                                    'Competitor Index': 'new_competitor_effect'}).drop(columns = ['IMDB Title Name','EST Release Date']),
                       how='left',
                       left_on=['imdb_title_code', media + '_week_number'],
                       right_on=['imdb_title_code', media + '_week_number'])
combined_df_8 = pd.merge(left=combined_df_7,
                       right=combined_df_7.groupby(['imdb_title_code']).agg(
                           {'new_competitor_effect': np.nanmean}).reset_index().rename(
                           columns={'new_competitor_effect': 'new_avg_competitor_effect'}),
                       how='left',
                       left_on='imdb_title_code',
                       right_on='imdb_title_code')

# Adding correct windows for the AD
window_calc_new =pd.read_excel(io=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/Intermediate Data - Cleaned/calculated_window_est_ivod_revenue_units_dec30.xlsx",
                               sheet_name="est_ivod_units_window")
combined_df_9 = pd.merge(left = combined_df_8,
                         right=window_calc_new[['imdb_title_code','new_iVOD_BO_window','new_EST_BO_window','new_EST_IVOD_window']] ,
                         how = 'left',
                         on = 'imdb_title_code')


combined_df_9.to_excel(r"C:/Users/hari/Desktop/best est units ad_dec31_v3_withcomp_effect.xlsx",index=False)


# ------------------------------



# after this added window by vlookup from the file - "C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/Intermediate Data - Cleaned/calculated_window_est_ivod_revenue_units_dec30.xlsx"


# -----------------
# Creating Adstock for these combined metrics using optimal lambda
        class_instance = Adstock(base_dataframe=combined_df_4,
                                 dictionary_spends={'Google_Search_Volume': [0.1, 'Linear']},
                                 week_number_colname='TH_Week_Number',
                                 revenue_colname=''+media+' Revenue')
        combined_df_3 = class_instance.optimise_adstock()

# combined_df_3.to_excel(r"C:/Users/hari/Desktop/temp_4.xlsx",index=False)

# combined_df_4.columns = combined_df_4.columns.str.strip().str.lower().str.replace(' ', '_').str.replace('(', '').str.replace(')', '')
# combined_df_4

# for i in combined_df_4.columns:
#     print(i is str):
#         print(i)






# x = "('TOTAL','(BASE_AWARE)Definitely_Mean')"


# del combined_df_3

# merged_data.rename(columns = {})
# merged_data.columns = merged_data.columns.str.replace(", '", '_')

        # # Merging these variables with the base ad
        # merged_data.drop(columns=['IMDB_Title_Name', 'Theatrical_Release_Date',
        #                           'Week_Start_Date', 'Google_Search_Volume',
        #                           revenue_colname], inplace=True)

# df_title = pd.read_excel(
#     io=sharepoint_path + r"/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Title List.xlsx",
#     sheet_name='Phase 2B 88 titles',
#     na_values=['#NA', '#N/A', '', ' ', 'na', 'NA'])
# df_title = df_title[['IMDB Title Code',
#          'IMDB Title Name',
#          'Theatrical Release Date',
#          media + ' Release Date']].dropna(subset=[media + ' Release Date']).drop([media + ' Release Date'],
#                                                                                  axis=1)

# exhaustive_dataframe

# comp_ad7.shape
# (8734, 140)
# updated_gs_vol.shape
# (90718, 11)

# combined_df = pd.merge (
#     left = df,
#     right=updated_gs_vol,
#     how= "left",
#     left_on=['IMDB_Title_Code','temp_join'],
#     right_on=['IMDB_Title_Code','temp_join']
# )

# comp_ad7.drop_duplicates(subset =['IMDB_Title_Code','TH_Week_Number'],inplace=True)

# del combined_df_3
# combined_df_2.loc[i,'Google_Search_Volume'] = 0 if combined_df_2.loc[i,'TH_Week_Number'] > 1 for i in range(len(combined_df_2))

# for i in range(len(combined_df_2)):
#     if(combined_df_2.iloc[i,'TH_Week_Number'] > 1):
#     combined_df_2.iloc[i, 'Google_Search_Volume'] = 0
#     elif(combined_df_2.iloc[i,'TH_Week_Number'] <= 1):
#     combined_df_2.iloc[i,'Google_Search_Volume'] = combined_df_2.iloc[i,'Google_Search_Volume']