import pandas as pd
import numpy as np
# import datetime

def nrg_function(df,sharepoint_path):
    """
    The following function gives the MKT GENRE GROUPED level data for NRG

    Args: This will take the input of the dataframe

    Return: This will reutrn the data frame with average and maximum values of the NRG data
    """

    #reading NRG data file
    df_nrg = pd.read_excel(sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/04. Other Data Elements/NRG Forecasting Decks/NRG_CT_Historical_20170412_Upto_20190926_v1.xlsx",
                sheet_name = "Raw Data")

    #reading Mkt Genre file
    df_mkt = pd.read_excel(sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/Genre Mapping/MKT_Genre_Curr_Data_061719.xlsx")

    #reading the Mkt genre grouped file
    df_mkt_group = pd.read_excel(sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/Genre Mapping/Mkt Genre_Grouped.xlsx")

    # merging genres of titles in nrg data with the mkt genre
    new_df = pd.merge(left=df_nrg, right=df_mkt[['IMDB_Title_Code', 'Mkt_Genre']],
                      how='left',
                      left_on='IMDB Title Code',
                      right_on='IMDB_Title_Code').drop(['IMDB_Title_Code'], axis=1)
    # merging with mkt grouped genre
    new_grouped = pd.merge(left=new_df, right=df_mkt_group[['Mkt_Genre', 'Mkt_Genre_Grouped']],
                           how='left',
                           left_on='Mkt_Genre',
                           right_on='Mkt_Genre').drop(['Mkt_Genre'], axis=1)
    # Dropping the titles with null value
    new_grouped.dropna(inplace=True)
    # using pivot table to get the mean values of UA, Definitely, Definitely not... etc on genre level
    new_grouped_mean = pd.pivot_table(new_grouped, index=['Mkt_Genre_Grouped'],
                                      columns=['REPTYPE'],
                                      values=['TOTAL'],
                                      aggfunc=np.mean).reset_index()
    # dropping level from the column names
    new_grouped_mean.columns = new_grouped_mean.columns.droplevel()
    # rename the colnum names
    new_grouped_mean.rename(columns={'' : 'Mkt_Genre_Grouped',
                                     'Unaided Total': 'Unaided Total_Mean',
                                     'Total Awareness': 'Total Awareness_Mean',
                                     'Definitely': 'Definitely_Mean',
                                     'Definitely not': 'Definitely not_Mean',
                                     'Positive': 'Positive_Mean',
                                     'Negative': 'Negative_Mean',
                                     '(BASE_AWARE)Definitely': 'BASE_AWARE_Definitely_Mean',
                                     '(BASE_AWARE)Definitely not': 'BASE_AWARE_Definitely not_Mean',
                                     '(BASE_AWARE)Positive': 'BASE_AWARE_Positive_Mean',
                                     '(BASE_AWARE)Negative': 'BASE_AWARE_Negative_Mean',
                                     'FIRST CHOICE': 'FIRST CHOICE_Mean',
                                     'HAVE SEEN': 'HAVE SEEN_Mean',
                                     'UNAID INTENT': 'UNAID INTENT_Mean',
                                     'SC_AMONG_MOVIES': 'SC_AMONG_MOVIES_Mean',
                                     'FC_OP_REL': 'FC_OP_REL_Mean'}, inplace=True)
    # using pivot table to get the maximum values of UA, Definitely, Definitely not... etc on genre level
    new_grouped_max = pd.pivot_table(new_grouped, index=['Mkt_Genre_Grouped'],
                                     columns=['REPTYPE'],
                                     values=['TOTAL'],
                                     aggfunc=np.max).reset_index()
    # dropping levels from the column names
    new_grouped_max.columns = new_grouped_max.columns.droplevel()
    # renaming the column names
    new_grouped_max.rename(columns={'' : 'Mkt_Genre_Grouped',
                                    'Unaided Total': 'Unaided Total_Max',
                                    'Total Awareness': 'Total Awareness_Max',
                                    'Definitely': 'Definitely_Max',
                                    'Definitely not': 'Definitely not_Max',
                                    'Positive': 'Positive_Max',
                                    'Negative': 'Negative_Max',
                                    '(BASE_AWARE)Definitely': 'BASE_AWARE_Definitely_Max',
                                    '(BASE_AWARE)Definitely not': 'BASE_AWARE_Definitely not_Max',
                                    '(BASE_AWARE)Positive': 'BASE_AWARE_Positive_Max',
                                    '(BASE_AWARE)Negative': 'BASE_AWARE_Negative_Max',
                                    'FIRST CHOICE': 'FIRST CHOICE_Max',
                                    'HAVE SEEN': 'HAVE SEEN_Max',
                                    'UNAID INTENT': 'UNAID INTENT_Max',
                                    'SC_AMONG_MOVIES': 'SC_AMONG_MOVIES_Max',
                                    'FC_OP_REL': 'FC_OP_REL_Max'}, inplace=True)
    # Merging original data frame with the nrg data
    df = pd.merge(left=df, right=new_grouped_mean,
                  how='left',
                  left_on='Mkt_Genre_Grouped',
                  right_on='Mkt_Genre_Grouped')
    # merging original data frame with the nrg data
    df = pd.merge(left=df, right=new_grouped_max,
                  how='left',
                  left_on='Mkt_Genre_Grouped',
                  right_on='Mkt_Genre_Grouped')
    return df
