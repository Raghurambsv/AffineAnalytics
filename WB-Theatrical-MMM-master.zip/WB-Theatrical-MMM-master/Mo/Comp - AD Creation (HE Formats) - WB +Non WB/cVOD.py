import pandas as pd
import numpy as np
# code dependancy - run "film_festivals.py"


nonwb = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\cVOD - Non WB\NonWB_Modeling AD v1.0.xlsx",sheet_name= "VOD_TH+1 week(s)")
cVOD = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\cVOD - Non WB\VOD_3_v2_Original - Copy.xlsx",sheet_name= "VOD_3_v2")
window_calc = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\cVOD - Non WB\NonWB_Modeling AD v1.0.xlsx",sheet_name= "NonWB Titles")
# postrak 2.4 created from available version 2 and vlookingup titles from v3 - check in est foledr for actual names
# delete top 2 rows in original file and paste as values in the postrak file
postrak = pd.read_excel(io=r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\cVOD - Non WB\post_trak_film_lookup_results_2019_10_14__14_49_Week 2.1.xlsx",
                        sheet_name="Recovered_Sheet1")

# add the wb flag to both files
nonwb['WB_Flag'] = 0
cVOD['WB_Flag'] = 1


# nonwb.columns.values

grpd_genre = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\cVOD - Non WB\Mkt Genre.xlsx")
base_genre = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\cVOD - Non WB\MKT_Genre_Curr_Data_061719.xlsx")

nonwb2=pd.merge(left=nonwb,
                right=base_genre[["IMDB_Title_Code",'Mkt_Genre']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code")
nonwb2.isnull().sum()

nonwb3=pd.merge(left=nonwb2,
                right=grpd_genre[['Mkt_Genre','Mkt_Genre_Grouped']],
                how="left",
                left_on="Mkt_Genre",
                right_on="Mkt_Genre")

#run the film festival code - sandeeps code - to get FF data

nonwb4 = film_festival(df=nonwb3,
                       film_festival_data=pd.read_excel(io=r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\cVOD - Non WB\Final_Film_Festival_All.xlsx",
                                                       sheet_name="Final_Film_Festival_All",
                                                       na_values=["#N/A", "NA", "N/A", "na", " ", ""]).rename(columns={"IMDB Title Code":"IMDB_Title_Code"}))
nonwb4.isnull().sum()
# nonwb4[["count_film_festival",
#        "film_festival_binary_flag", "film_festival_flag"]].fillna(0, inplace=True)


nonwb4.fillna({"count_film_festival":0,
               "film_festival_binary_flag":0,
               "film_festival_flag":0},
              inplace=True)

# nonwb4.loc[nonwb4[["count_film_festival",
#        "film_festival_binary_flag", "film_festival_flag"]==0].sum()

nonwb5=pd.merge(left=nonwb4,
                right=window_calc[['IMDB_Title_Code','VOD_PST', 'VOD_iVOD', 'VOD_EST', 'VOD_BO_Window']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code")

nonwb5.to_excel(r"C:\Users\hari\Desktop\Nonwb5.xlsx",index=False)

# ad_wb = pd.read_excel(r"C:\Users\hari\Desktop\cVOD - Non WB\WB_Modeling AD v1.0.xlsx",sheet_name= "PST_TH+1 week(s)")
# cVOD2=pd.merge(left=cVOD,
#                 right=ad_wb[['IMDB_Title_Code','Actor_0_Rating', 'Actor_1_Rating', 'Actor_2_Rating',
#                              'Actor_3_Rating', 'actors_avg_rating', 'Director_0', 'Director_1']],
#                 how="left",
#                 left_on="IMDB_Title_Code",
#                 right_on="IMDB_Title_Code")
# nonwb5.to_excel(r"C:\Users\hari\Desktop\Nonwb5.xlsx",index=False)
# cVOD2.to_excel(r"C:\Users\hari\Desktop\cVOD2.xlsx",index=False)
# -------------------------------------------------------------------------------------
#next step - drop the unneccsary variables

nonwb5.drop(["Actor_0","Actor_1","Actor_2","Actor_3","Director_0","Director_1"],
            axis=1,
            inplace=True)

nonwb5.to_excel(r"C:\Users\hari\Desktop\Nonwb5.xlsx",index=False)

# cVOD2.drop(["VOD_EST","Actor_0_Rating_y","Actor_1_Rating_y","Actor_2_Rating_y","Actor_3_Rating_y","actors_avg_rating_y","Director_0","Director_1"],
#             axis=1,
#             inplace=True)
# cVOD2.to_excel(r"C:\Users\hari\Desktop\cVOD2.xlsx",index=False)

# nonwb5.drop(["IMDB Title Code"],
#             axis=1,
#             inplace=True)


# temp = pd.concat([cVOD2.rename(columns={'Actor_0_Rating_x':'Actor_0_Rating',
#                                         'Actor_1_Rating_x':'Actor_1_Rating',
#                                         'Actor_2_Rating_x':'Actor_2_Rating',
#                                         'Actor_3_Rating_x':'Actor_3_Rating',
#                                         'actors_avg_rating_x':'actors_avg_rating'}),
#                   nonwb5.rename(columns={
#
#                   })],
#                  sort=True,
#                  axis=0)

nonwb6 = nonwb5[['Actor_0_Rating',
'Actor_1_Rating',
'Actor_2_Rating',
'Actor_3_Rating',
'actors_avg_rating',
'avg_competitor_effect',
'avg_earnings_franchise',
'avg_Google_Search_Volume_till_2',
'cast_avg_rating',
'Competitor_Effect',
'count_film_festival',
'Director_0_Rating',
'Director_1_Rating',
'directors_avg_rating',
'film_festival_binary_flag',
'film_festival_flag',
'franchise_flag',
'franchise_releases_in_last_2_years',
'franchise_releases_in_last_3_years',
'franchise_releases_in_last_4_years',
'Google_Search_Volume_2',
'Google_Search_Volume_2 Adstock Linear0.635',
'holiday_flag',
'holiday_flag_Clubbed',
'IMDB Title Name',
'IMDB_Title_Code',
'long_weekend_flag',
'long_weekend_flag_Clubbed',
'MajorFranchise',
'max_Google_Search_Volume_till_2',
'Mkt_Genre',
'Mkt_Genre_Grouped',
'Opening_Weekend_BO',
'TH_Week_Number',
'Theatrical_Release_Date',
'Theatrical_Release_Year',
'time_delta_since_last_franchise_release',
'total_Google_Search_Volume_till_2',
'VOD Revenue',
'VOD Revenue_Clubbed',
'VOD_BO_Window',
'VOD_EST',
'VOD_iVOD',
'VOD_PST',
'VOD_Week_Number',
'Week Start Date',
'WB_Flag']]




cVOD3= cVOD[['Actor_0_Rating',
'Actor_1_Rating',
'Actor_2_Rating',
'Actor_3_Rating',
'actors_avg_rating',
'avg_competitor_effect',
'avg_earnings_franchise',
'avg_Google_Search_Volume_till_2',
'cast_avg_rating',
'Competitor_Effect',
'count_film_festival',
'Director_0_Rating',
'Director_1_Rating',
'directors_avg_rating',
'film_festival_binary_flag',
'film_festival_flag',
'franchise_flag',
'franchise_releases_in_last_2_years',
'franchise_releases_in_last_3_years',
'franchise_releases_in_last_4_years',
'Google_Search_Volume_2',
'Google_Search_Volume_2 Adstock Linear0.793',
'holiday_flag',
'holiday_flag_Clubbed',
'IMDB Title Name',
'IMDB_Title_Code',
'long_weekend_flag',
'long_weekend_flag_Clubbed',
'MajorFranchise',
'max_Google_Search_Volume_till_2',
'Mkt_Genre',
'Mkt_Genre_Grouped',
'Opening_Weekend_BO',
'TH_Week_Number',
'Theatrical_Release_Date',
'Theatrical_Release_Year',
'time_delta_since_last_franchise_release',
'total_Google_Search_Volume_till_2',
'VOD Revenue',
'VOD Revenue_Clubbed',
'VOD_BO_Window',
'cVOD_EST',
'VOD_iVOD',
'VOD_PST',
'VOD_Week_Number',
'Week Start Date',
'WB_Flag']]



nonwb6.to_excel(r"C:\Users\hari\Desktop\nonwb6.xlsx",index=False)
cVOD3.to_excel(r"C:\Users\hari\Desktop\cVOD3.xlsx",index=False)

# after this compare the order of both columns in the excel sheets created above
# append both the dataframes into one manually or via code (manually preferred bacz concat not working properly)
# result = pd.concat([df1, df4], axis=1, join='inner')

comp_ad=pd.concat([nonwb6.drop('Google_Search_Volume_2 Adstock Linear0.635', axis=1),
                   cVOD3.rename(columns={'cVOD_EST':'VOD_EST'}).drop('Google_Search_Volume_2 Adstock Linear0.793', axis=1)],axis=0,sort=False)

comp_ad.to_excel(r"C:\Users\hari\Desktop\comp_ad.xlsx",index=False)

# adding postrak to the title

comp_ad2=pd.merge(left=comp_ad,
                right=postrak[['IMDB_Title_Code_new','Locs\nat\nWidest\nRelease', 'Definitely\nRecommend']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code_new")
# dropping the xetra title code new from postrak
comp_ad2.drop(["IMDB_Title_Code_new"],
            axis=1,
            inplace=True)

comp_ad2.to_excel(r"C:\Users\hari\Desktop\comp_ad2.xlsx",index=False)
# adding the wb finance data
finance_data = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Non WB Combined AD - Creation -Bharti's Task\cVOD - Non WB\WB+Comp_Titles_BO_HE_Revenue.xlsx")

comp_ad3=pd.merge(left=comp_ad2,
                right=finance_data[['IMDB_Title_Code',
       'HE Revenue', 'BO Revenue', 'HE Spends (H&S)', 'BO Spends (H&S)',
       'HE Spends(WB Finance)', 'BO Spends(WB Finance)']],
                how="left",
                left_on="IMDB_Title_Code",
                right_on="IMDB_Title_Code")

comp_ad3.to_excel(r"C:\Users\hari\Desktop\comp_ad3.xlsx",index=False)