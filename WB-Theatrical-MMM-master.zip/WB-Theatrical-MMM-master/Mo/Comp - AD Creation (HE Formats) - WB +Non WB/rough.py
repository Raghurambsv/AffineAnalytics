import pandas as pd
import numpy as np
import datetime
import dateutil.parser
from pandas.core.tools.datetimes import _guess_datetime_format_for_array
from datetime import timedelta

flight_data = pd.read_excel(r"C:\Users\hari\Desktop\Warner Bros\Courses and Assignments\Python Assignments\Amit's Assignments - 9-12-19\Data_Train.xlsx",
    sheet_name="Sheet1")
holiday_data = pd.read_csv( r"C:\Users\hari\Desktop\Warner Bros\Courses and Assignments\Python Assignments\Amit's Assignments - 9-12-19\Holiday_Dates.csv")


flight_data['new_date']=pd.to_datetime(flight_data['Date_of_Journey'],dayfirst=True)
flight_data['month'] = pd.DatetimeIndex(flight_data['new_date']).month

april_data = flight_data[flight_data.month == 4].groupby(['Airline','Source']).count()['month'].reset_index()
april_data['rank'] = april_data.groupby(['Airline'])['month'].rank(ascending = False)
april_data = april_data.sort_values(by = ['Airline','rank']).reset_index(drop = True).drop('month',1)

# april_data.to_excel(r"C:/Users/hari/Desktop/q1 answer.xlsx",index=False)

# 2nd Question

all_dates = pd.DataFrame()
all_dates['range'] = np.arange(-4,+5)
all_dates['Flag'] = 1

holiday_dates = pd.merge(left = holiday_data,
         right = all_dates,
         how = 'inner',
         left_on='Flag',
         right_on='Flag')
holiday_dates['new_date_h'] = pd.DatetimeIndex(holiday_dates['Date'],dayfirst=True)


holiday_dates['new_holidays'] = holiday_dates['new_date_h'] + pd.TimedeltaIndex(holiday_dates['range'], unit='D')

flight_data2= flight_data.copy()
flight_data2.drop_duplicates(inplace=True)

holiday_dates2 = holiday_dates.copy()
# holiday_dates2.drop_duplicates('new_holidays',inplace=True)
holiday_dates2.drop_duplicates(subset = ['new_holidays'],inplace=True)
# del holiday_dates2



final_dataframe = pd.merge(left = flight_data,
                           right = holiday_dates2,
                           how= 'left',
                           left_on='new_date',
                           right_on= 'new_holidays')

final_dataframe.drop(columns = ['Date','range','new_date_h','new_holidays'],inplace= True)
final_dataframe['Flag'].fillna(0,inplace=True)

# Question 3

# getting dataframe to a airline DOJ level
count_of_comp = pd.DataFrame()
flight_data['new_date_of_journey']=pd.to_datetime(flight_data['Date_of_Journey'],dayfirst=True)
count_of_comp = flight_data.groupby(['Airline', 'new_date_of_journey'],as_index=False).count()


# dropping everything except 'source' and 'Airline', 'new_date_of_journey',  - acts a proxy for count will be renamed in next step
count_of_comp.drop(['Date_of_Journey','Destination', 'Route', 'Dep_Time', 'Arrival_Time', 'Duration','Total_Stops', 'Additional_Info', 'Price', 'new_date', 'month'],axis =1 ,inplace=True)
count_of_comp.rename(columns={'Source':'count'},inplace=True)

# now getting the count of comp at a date level

count_of_comp2=count_of_comp.copy()
doj_dataframe = pd.DataFrame
doj_dataframe = count_of_comp2.groupby('new_date_of_journey',as_index = False)['count'].sum()
doj_dataframe.rename(columns = {'count':'total_flights_on_that_day'},inplace=True)

# now left joining the count of doj_dataframe to count_of_comp

count_of_comp3 = pd.merge(left=count_of_comp,
                          right = doj_dataframe,
                          how = 'left',
                          left_on='new_date_of_journey',
                          right_on='new_date_of_journey')
#  then subtracting the columns count and total_flights_on_that_day to get the count of competitors Airline -Doj
count_of_comp3['total_comp_flights'] = count_of_comp3['total_flights_on_that_day'] - count_of_comp3['count']
count_of_comp3.to_excel(r"C:/Users/hari/Desktop/q3 answer.xlsx",index=False)

# Question 4 -(Use the same data source): For every Airline-DOJ create a column which is average flight prices of the competitors on that DOJ


price_of_comp = flight_data.groupby(['Airline', 'new_date_of_journey'],as_index=False).aggregate({'Price' : 'mean'})
price_of_comp.rename(columns = {'Price':'average_price_on_airline_doj'},inplace= True)

price_of_comp2 = price_of_comp.copy()

# now grouping by the new date of journey with a condition to get the avg price except the airline being considered
airline = list(price_of_comp['Airline'].unique())
# a=df[df['1']==df['3']].groupby(['1','3'])['2'].mean()    -   .filter(price_of_comp['Airline'] != str(i))
comp_price_exclusive =pd.DataFrame()
# for index,rows in price_of_comp.iterrows() :
#     if rows['Airline'] !=
# comp_price_exclusive =pd.DataFrame
# comp_price_exclusive2 = pd.DataFrame(columns = ['doj','price'])
comp_price_exclusive2 =[]
for i in price_of_comp['Airline']:
    # print (i)
    list_for_i= price_of_comp[price_of_comp['Airline']!=i].groupby(['new_date_of_journey'],as_index=False) ['average_price_on_airline_doj'].mean()
    list_for_i['name'] = i
    # list_for_i = list_for_i.append(list_for_i, ignore_index=True)
    comp_price_exclusive2.append([list_for_i])

# del list_for_i
dfObj = pd.DataFrame(comp_price_exclusive2)

# ---------------------------------------------------------------------------------------------------------------------
df = pd.DataFrame({'col': comp_price_exclusive2})
    # print(len(comp_price_exclusive2))
    # comp_price_exclusive.append(comp_price_exclusive,comp_price_exclusive2,ignore_index=True)

list_for_i = pd.DataFrame
list_for_i['name'] = i
list_for_i = price_of_comp[price_of_comp['Airline']!=i].groupby(['new_date_of_journey'],as_index=False) ['average_price_on_airline_doj'].mean()
price_of_comp[price_of_comp['Airline']!=i].groupby(['new_date_of_journey'],as_index=False) ['average_price_on_airline_doj'].mean().reset_index().rename(columns ={'index':i} )
for i in flight_data['Airline']:
    price_of_comp3 =
    comp_price_exclusive = flight_data[flight_data['Airline']!=i].groupby(['new_date_of_journey'],as_index=False) ['Price'].mean()

doj_dataframe = pd.DataFrame
doj_dataframe = count_of_comp2.groupby('new_date_of_journey',as_index = False)['count'].sum()
doj_dataframe.rename(columns = {'count':'total_flights_on_that_day'},inplace=True)

# now left joining the count of doj_dataframe to count_of_comp

count_of_comp3 = pd.merge(left=count_of_comp,
                          right = doj_dataframe,
                          how = 'left',
                          left_on='new_date_of_journey',
                          right_on='new_date_of_journey')





dfObj.to_excel(r"C:/Users/hari/Desktop/q4 answer.xlsx",index=False)


# final_dataframe_2 = pd.concat([flight_data,holiday_dates],keys=['new_date','new_holidays'],axis=1)

# all_dates['holiday_date'] =
# del all_dates

# temp = april_data.groupby(['Airline'])['month'].rank(ascending=False).reset_index()
# april_data.DataFrameGroupBy.rank()
# # del april_data
#
# ranked_data = check_data.rank('rank','Airline',ascending= False)
#
# ranked_data = april_data.groupby(['Airline','Source'])['month'].rank(ascending=False)
#
# check_data = april_data.groupby(['Airline','Source']).count()[['month']].reset_index()
#
#
# april_data['Airline','Source'].groupby(['month']).mean()
#
# april_data[['Airline','Source']].groupby(['Airline','Source']).count()
#
# flight_data_grouped = flight_data.groupby(['Airline','Source']).count()
# flight_data['day'] = pd.DatetimeIndex(flight_data['Date_of_Journey']).day
# dateutil.parser.parse(flight_data.loc['Date_of_Journey'], dayfirst=True)
# # array = np.array(['2016-05-01T00:00:59.3+10:00'])
# # _guess_datetime_format_for_array(array)
#
# flight_data['Date_of_Journey_new'] = _guess_datetime_format_for_array.(flight_data['Date_of_Journey'])
#
# flight_data['Date_of_Journey_new'] = dateutil.parser.parse(flight_data['Date_of_Journey'])
#
#
# flight_data['Date_of_Journey'] = pd.to_datetime(flight_data['Date_of_Journey'],dayfirst=True)
# flight_data['Month'] = flight_data['Date_of_Journey'].dt.month
#
# flight_data['Date_of_Journey_new'] = flight_data['Date_of_Journey'].dt.strftime('%m/%d/%Y')
#
# flight_data['month_of_travel'] = pd.DatetimeIndex(flight_data['Date_of_Journey']).month
#
# pd.to_datetime(flight_data['Date_of_Journey'],infer_datetime_format=True)
#
# datetime.datetime.strptime("flight_data['Date_of_Journey']", %d-%m-%y).strftime(format2)

#
# holiday_dates['new_holidays'] =  holiday_dates['new_date_h'] + timedelta(holiday_dates['range'])
# holiday_dates.loc['new_holidays'] =  holiday_dates.loc['new_date_h'] + timedelta( days =  holiday_dates.loc['range'])