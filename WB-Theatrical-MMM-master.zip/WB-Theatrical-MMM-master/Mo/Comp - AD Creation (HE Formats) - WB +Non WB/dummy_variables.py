import numpy as np
import pandas as pd

# adding the Dummy Variables for MKT_Gnere_Grouped

def dummy_variable_function(comp_dataframe):
    # create dummmies for mkt genre
    dummy = pd.get_dummies(comp_dataframe["Mkt_Genre_Grouped"])
    comp_ad4 = pd.concat([comp_dataframe, dummy], axis=1)

    return comp_ad4


