# importing modules
import numpy as np
import pandas as pd

def film_festival(df, film_festival_data):

    film_festival_data_original = film_festival_data
    film_festival_data.dropna(subset=['Festival Name'],
                          inplace=True)
    film_festival_data = film_festival_data[['IMDB_Title_Code',
                                             'Festival Name']].drop_duplicates()

    film_festival_data = film_festival_data.groupby(['IMDB_Title_Code']).agg({'Festival Name' : 'count'}).reset_index()
    film_festival_data.rename(columns={'Festival Name':'count_film_festival'},
                          inplace=True)
    film_festival_data['film_festival_binary_flag'] = np.NaN
    film_festival_data['film_festival_flag'] = np.NaN
    for index in film_festival_data.index:
        if film_festival_data.loc[index, 'count_film_festival']==0:
            film_festival_data.loc[index, 'film_festival_binary_flag'] = 0
            film_festival_data.loc[index, 'film_festival_flag'] = '0'
        else:
            if film_festival_data.loc[index, 'count_film_festival'] == 1:
                film_festival_data.loc[index, 'film_festival_binary_flag'] = 1
                film_festival_data.loc[index, 'film_festival_flag'] = '1'
            else:
                film_festival_data.loc[index, 'film_festival_binary_flag'] = 1
                film_festival_data.loc[index, 'film_festival_flag'] = 'more than 1'
    del index

    df = pd.merge(left=df,
                  right=film_festival_data,
                  left_on=['IMDB_Title_Code'],
                  right_on=['IMDB_Title_Code'],
                  how='left')
    return df

def filtered_film_festival(df, film_festival_data):

    film_festival_data_original = film_festival_data
    best_film_festivals = ['Berlin International Film Festival',
                           'Chicago International Film Festival',
                           'Telluride Horror Show',
                           'Sundance Film Festival',
                           'Toronto International Film Festival',
                           'New York Film Festival',
                           'Cannes Film Festival',
                           'Los Angeles Film Festival',
                           'Toronto',
                           'Venice Film Festival',
                           'Telluride Film Festival',
                           'Venice Film Festival premiere',
                           'Toronto Japanese Film Festival',
                           'International Film Festival Rotterdam',
                           'Toronto International Film Festival premiere',
                           'Special Gala Screening Berlin International Film Festival',
                           'Toronto Animation Arts Festival International',
                           'Sprockets Toronto International Film Festival for Children',
                           '3-D version Toronto International Film Festival',
                           "Chicago International Children's Film Festival",
                           'Los Angeles Film Festival premiere',
                           'Sundance Hong Kong Selects',
                           'Cannes Film Festival premiere',
                           'Berlin International Film Festival premiere',
                           'Sundance London',
                           'Toronto Jewish Film Festival',
                           'Toronto LGBT Film Festival',
                           'Sundance Film Festival premiere',
                           'Sundance London Film Festival',
                           'International Film Festival Rotterdam premiere',
                           "Cannes International Critics' Week",
                           'Cannes Film Festival Week',
                           'Toronto Human Rights Watch Film Festival',
                           'Mountainfilm in Telluride premiere',
                           'Toronto European Union Film Festival',
                           'New York Film Festival premiere',
                           'London Sundance Film Festival',
                           'Toronto Black Film Festival',
                           'Toronto International Film Festival Bell Lightbox',
                           'Mountainfilm in Telluride',
                           'Telluride Mountainfilm Festival',
                           'Telluride, Colorado',
                           'Chicago International Movies and Music Festival',
                           'Toronto Inside Out Film Festival',
                           'Telluride Film Festival premiere',
                           'Telluride by the Sea',
                           'Telluride at Dartmouth',
                           'Toronto InsideOut Lesbian and Gay Film and Video Festival',
                           'uncut version Berlin International Film Festival',
                           "Director's cut Venice Film Festival",
                           'Sundance Film Festival London',
                           'Venice Days Venice Film Festival',
                           'Venice International Film Festival premiere',
                           'New York Film Critics Series',
                           'restored version Berlin International Film Festival',
                           'digitally restored version New York Film Festival',
                           'Cannes International Film Festival',
                           'Cannes Independent Film Festival',
                           'Telluride International Film Festival',
                           'Berlin Independent Film Festival',
                           'Summer Screening Toronto After Dark Film Festival',
                           'Cannes Film Festival - Blood Window Midnight Galas',
                           'New York Film Festival: Opening Act',
                           "director's cut New York Film Festival"]

    film_festival_data_2 = film_festival_data_original[film_festival_data_original["Festival Name"].isin(best_film_festivals)]

    film_festival_data_2.dropna(subset=['Festival Name'],
                          inplace=True)
    film_festival_data_2 = film_festival_data_2[['IMDB_Title_Code',
                                             'Festival Name']].drop_duplicates()

    film_festival_data_2 = film_festival_data_2.groupby(['IMDB_Title_Code']).agg({'Festival Name' : 'count'}).reset_index()
    film_festival_data_2.rename(columns={'Festival Name':'count_film_festival_new'},
                          inplace=True)
    film_festival_data_2['film_festival_binary_flag_new'] = np.NaN
    film_festival_data_2['film_festival_flag_new'] = np.NaN
    for index in film_festival_data_2.index:
        if film_festival_data_2.loc[index, 'count_film_festival_new']==0:
            film_festival_data_2.loc[index, 'film_festival_binary_flag_new'] = 0
            film_festival_data_2.loc[index, 'film_festival_flag_new'] = '0'
        else:
            if film_festival_data_2.loc[index, 'count_film_festival_new'] == 1:
                film_festival_data_2.loc[index, 'film_festival_binary_flag_new'] = 1
                film_festival_data_2.loc[index, 'film_festival_flag_new'] = '1'
            else:
                film_festival_data_2.loc[index, 'film_festival_binary_flag_new'] = 1
                film_festival_data_2.loc[index, 'film_festival_flag_new'] = 'more than 1'
    del index

    df = pd.merge(left=df,
                  right=film_festival_data_2,
                  left_on=['IMDB_Title_Code'],
                  right_on=['IMDB_Title_Code'],
                  how='left')

    return df
