import pandas as pd
import numpy as np


def cvod_function(format_needed,snapshot):
    return "cvod is running"

    import pandas as pd
    import numpy as np
    import time
    import progressbar
    import sys
    # sys.path.insert(0, r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\Phase 2 Codes\03. Feature Engineering")
    sys.path.insert(0,
                    r"C:\Users\rolee\PycharmProjects\WB-Theatrical-MMM\Mo\Comp - AD Creation (HE Formats) - WB +Non WB")
    from film_festivals import *
    # import film_festivals
    # from film_festivals import *
    # import window_calculation
    from window_calculation import *
    #
    # sys.path.insert(0, r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\Mo\Comp - AD Creation (HE Formats) - WB +Non WB")
    # from film_festivals import *

    # import sys
    # sys.path.insert(0, r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\Mo\Comp - AD Creation (HE Formats) - WB +Non WB")
    # import window calculation

    def cvod_function(sale, format_needed, nonwb_df, wb_df, snapshot, root_folder, sharepoint_path):
        # sys.path.insert(0,r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\Mo\Comp - AD Creation (HE Formats) - WB +Non WB")
        # from film_festivals import *
        # import film_festivals

        # Run window calculation and film festivals
        # return "ivod is running"
        # code dependancy - run "film_festivals.py"
        # File Dependancies:
        # Final_Film_Festival_All
        # Genre_allmetrics_HE_Lifecycle
        # Mkt Genre
        # MKT_Genre_Curr_Data_061719
        # NonWB_Modeling AD v1.0
        # post_trak_film_lookup_results_2019_10_14_14_49_Week 2.1
        # WB_Modelling AD v1.0
        # WB+Comp_Titles_BO_HE_Revenue

        # "C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\Phase 2\Data Harmonizing - Cleaning\WB HE Format Modelling AD.xlsx"
        # nonwb = pd.read_excel(
        #     sharepoint_path+r"\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\NonWB_Modeling AD v1.0.xlsx",
        #     sheet_name="EST_TH+1 week(s)")
        # EST = pd.read_excel(
        #     r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\WB_Modeling AD v1.0.xlsx",
        #     sheet_name="EST_TH+1 week(s)")
        nonwb = nonwb_df
        cvod = wb_df

        nonwb['WB_Flag'] = 0
        cvod['WB_Flag'] = 1

        # Dropping the unnecessary columns
        columns_to_drop_nonwb = []
        columns_to_drop_nonwb = columns_to_drop_nonwb + [col for col in nonwb.columns if 'adstock' in col.lower()]
        nonwb.drop(columns_to_drop_nonwb, axis=1, inplace=True)

        columns_to_drop_wb = ['Distribution_only',
                              'Estimated_BO_Revenue',
                              'max_combined_likes_till_2',
                              'avg_combined_likes_till_2',
                              'total_combined_likes_till_2',
                              'max_combined_views_till_2',
                              'avg_combined_views_till_2',
                              'total_combined_views_till_2',
                              'max_combined_comments_till_2',
                              'avg_combined_comments_till_2',
                              'total_combined_comments_till_2',
                              'max_combined_likes_by_views_till_2',
                              'avg_combined_likes_by_views_till_2',
                              'total_combined_likes_by_views_till_2',
                              'max_Wikipedia_Page_Views_till_2',
                              'avg_Wikipedia_Page_Views_till_2',
                              'total_Wikipedia_Page_Views_till_2',
                              'combined_likes',
                              'combined_views',
                              'combined_comments',
                              'combined_likes_by_views',
                              'combined_likes_2',
                              'combined_views_2',
                              'combined_comments_2',
                              'combined_likes_by_views_2',
                              'Wikipedia_Page_Views_2']
        columns_to_drop_wb = columns_to_drop_wb + [col for col in cvod.columns if 'adstock' in col.lower()]
        cvod.drop(columns_to_drop_wb, axis=1, inplace=True)

        # run the film festival code - sandeeps code - to get FF data
        #  import sys

        nonwb2 = film_festival(df=nonwb,
                               film_festival_data=pd.read_excel(
                                   io=sharepoint_path + r"\06. HE Format level Models\01. Data Harmonization-Cleaning\02. Cleaned Data\Final_Film_Festival_All.xlsx",
                                   sheet_name="Final_Film_Festival_All",
                                   na_values=["#N/A", "NA", "N/A", "na", " ", ""]).rename(
                                   columns={"IMDB Title Code": "IMDB_Title_Code"}))

        nonwb2.fillna({"count_film_festival": 0,
                       "film_festival_binary_flag": 0,
                       "film_festival_flag": 0},
                      inplace=True)
        # adding FILM FESTIVAL FILTERED (top 10 List in Function)3 new columns similar to previous dataframe as Film_festival_NEW

        nonwb2 = filtered_film_festival(df=nonwb2,
                                        film_festival_data=pd.read_excel(
                                            io=sharepoint_path + r"\06. HE Format level Models\01. Data Harmonization-Cleaning\02. Cleaned Data\Final_Film_Festival_All.xlsx",
                                            sheet_name="Final_Film_Festival_All",
                                            na_values=["#N/A", "NA", "N/A", "na", " ", ""]).rename(
                                            columns={"IMDB Title Code": "IMDB_Title_Code"}))

        nonwb2.fillna({"count_film_festival_new": 0,
                       "film_festival_binary_flag_new": 0,
                       "film_festival_flag_new": 0},
                      inplace=True)
        # adding the same filtered film festival flags for WB - EST/PST/iVOD/VOD
        cvod = filtered_film_festival(df=cvod,
                                      film_festival_data=pd.read_excel(
                                          io=sharepoint_path + r"\06. HE Format level Models\01. Data Harmonization-Cleaning\02. Cleaned Data\Final_Film_Festival_All.xlsx",
                                          sheet_name="Final_Film_Festival_All",
                                          na_values=["#N/A", "NA", "N/A", "na", " ", ""]).rename(
                                          columns={"IMDB Title Code": "IMDB_Title_Code"}))

        cvod.fillna({"count_film_festival_new": 0,
                     "film_festival_binary_flag_new": 0,
                     "film_festival_flag_new": 0},
                    inplace=True)
        # fill 0 for already existing nan in old film festival flag
        cvod.fillna({"count_film_festival": 0,
                     "film_festival_binary_flag": 0,
                     "film_festival_flag": 0},
                    inplace=True)

        grpd_genre = pd.read_excel(
            sharepoint_path + r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/Genre Mapping/Mkt Genre_Grouped.xlsx")
        base_genre = pd.read_excel(
            sharepoint_path + r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/Genre Mapping/MKT_Genre_Curr_Data_061719.xlsx")

        nonwb3 = pd.merge(left=nonwb2,
                          right=base_genre[["IMDB_Title_Code", 'Mkt_Genre']],
                          how="left",
                          left_on="IMDB_Title_Code",
                          right_on="IMDB_Title_Code")

        nonwb4 = pd.merge(left=nonwb3,
                          right=grpd_genre[['Mkt_Genre', 'Mkt_Genre_Grouped']],
                          how="left",
                          left_on="Mkt_Genre",
                          right_on="Mkt_Genre")

        # we need to add window so , similar to the excel calculated window for Non wb we need to calculate for wb also in excel
        # the we merge it with their base ads

        nonwb_window_calc = nonwb_window_calculation()
        wb_window_calc = wb_window_calculation()

        nonwb5 = pd.merge(left=nonwb4,
                          right=nonwb_window_calc[['IMDB_Title_Code', 'est_bo', 'pst_est', 'min_vod_est']],
                          how="left",
                          left_on="IMDB_Title_Code",
                          right_on="IMDB_Title_Code")

        cvod2 = pd.merge(left=cvod,
                         right=wb_window_calc[['IMDB_Title_Code', 'est_bo', 'pst_est', 'min_vod_est']],
                         how="left",
                         left_on="IMDB_Title_Code",
                         right_on="IMDB_Title_Code")

        # check in excel wether the names and list of variables are matching
        # EST2.to_excel(r"C:\Users\hari\Desktop\EST2.xlsx", index=False)
        # nonwb5.to_excel(r"C:\Users\hari\Desktop\nonwb_EST.xlsx", index=False)

        # Concating the 2 dataframes into one single Comp AD - before that check whether the names are same - here it is
        add_wb_nonwb = pd.concat([cvod2, nonwb5], ignore_index=False, sort=True)
        # add_wb_nonwb.to_excel(r"C:\Users\hari\Desktop\compadtemp.xlsx", index=False)

        return add_wb_nonwb

        # temp = ivod_function("IVOD","T+3")

        # elif (sale =='Units'):

    # import pandas as pd
    # import numpy as np
    # import time
    # import progressbar
    # import sys
    # # sys.path.insert(0, r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\Phase 2 Codes\03. Feature Engineering")
    # sys.path.insert(0, r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\Mo\Comp - AD Creation (HE Formats) - WB +Non WB")
    # # from film_festivals import *
    # import film_festivals
    # # import window_calculation
    # from window_calculation import *
    #
    # sys.path.insert(0, r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\Mo\Comp - AD Creation (HE Formats) - WB +Non WB")
    # from film_festivals import *
    #
    # # import sys
    # # sys.path.insert(0, r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\Mo\Comp - AD Creation (HE Formats) - WB +Non WB")
    # # import window calculation
    #
    #
    #
    #
    # def ivod_function(sale,format_needed,nonwb_df,wb_df,snapshot,root_folder,sharepoint_path):
    #         # Run window calculation and film festivals
    #         # return "ivod is running"
    #         # code dependancy - run "film_festivals.py"
    #         # File Dependancies:
    #         # Final_Film_Festival_All
    #         # Genre_allmetrics_HE_Lifecycle
    #         # Mkt Genre
    #         # MKT_Genre_Curr_Data_061719
    #         # NonWB_Modeling AD v1.0
    #         # post_trak_film_lookup_results_2019_10_14_14_49_Week 2.1
    #         # WB_Modelling AD v1.0
    #         # WB+Comp_Titles_BO_HE_Revenue
    #
    #         # "C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\Phase 2\Data Harmonizing - Cleaning\WB HE Format Modelling AD.xlsx"
    #         # nonwb = pd.read_excel(
    #         #     sharepoint_path+r"\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\NonWB_Modeling AD v1.0.xlsx",
    #         #     sheet_name="EST_TH+1 week(s)")
    #         # EST = pd.read_excel(
    #         #     r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\03. Analytical Datasets\WB_Modeling AD v1.0.xlsx",
    #         #     sheet_name="EST_TH+1 week(s)")
    #         nonwb = nonwb_df
    #         iVOD = wb_df
    #
    #         nonwb['WB_Flag'] = 0
    #         iVOD['WB_Flag'] = 1
    #
    #         # Dropping the unnecessary columns
    #         columns_to_drop_nonwb = []
    #         columns_to_drop_nonwb = columns_to_drop_nonwb + [col for col in nonwb.columns if 'adstock' in col.lower()]
    #         nonwb.drop(columns_to_drop_nonwb, axis=1, inplace=True)
    #
    #         columns_to_drop_wb = ['Distribution_only',
    #         'Estimated_BO_Revenue',
    #         'max_combined_likes_till_2',
    #         'avg_combined_likes_till_2',
    #         'total_combined_likes_till_2',
    #         'max_combined_views_till_2',
    #         'avg_combined_views_till_2',
    #         'total_combined_views_till_2',
    #         'max_combined_comments_till_2',
    #         'avg_combined_comments_till_2',
    #         'total_combined_comments_till_2',
    #         'max_combined_likes_by_views_till_2',
    #         'avg_combined_likes_by_views_till_2',
    #         'total_combined_likes_by_views_till_2',
    #         'max_Wikipedia_Page_Views_till_2',
    #         'avg_Wikipedia_Page_Views_till_2',
    #         'total_Wikipedia_Page_Views_till_2',
    #         'combined_likes',
    #         'combined_views',
    #         'combined_comments',
    #         'combined_likes_by_views',
    #         'combined_likes_2',
    #         'combined_views_2',
    #         'combined_comments_2',
    #         'combined_likes_by_views_2',
    #         'Wikipedia_Page_Views_2']
    #         columns_to_drop_wb = columns_to_drop_wb + [col for col in iVOD.columns if 'adstock' in col.lower()]
    #         iVOD.drop(columns_to_drop_wb, axis=1, inplace=True)
    #
    #         # run the film festival code - sandeeps code - to get FF data
    #         #  import sys
    #
    #         nonwb2 = film_festivals.film_festival(df=nonwb,
    #                                film_festival_data=pd.read_excel(
    #                                    io=sharepoint_path+r"\06. HE Format level Models\01. Data Harmonization-Cleaning\02. Cleaned Data\Final_Film_Festival_All.xlsx",
    #                                    sheet_name="Final_Film_Festival_All",
    #                                    na_values=["#N/A", "NA", "N/A", "na", " ", ""]).rename(
    #                                    columns={"IMDB Title Code": "IMDB_Title_Code"}))
    #
    #         nonwb2.fillna({"count_film_festival": 0,
    #                        "film_festival_binary_flag": 0,
    #                        "film_festival_flag": 0},
    #                       inplace=True)
    #         # adding FILM FESTIVAL FILTERED (top 10 List in Function)3 new columns similar to previous dataframe as Film_festival_NEW
    #         nonwb2 = film_festivals.filtered_film_festival(df=nonwb2,
    #                                film_festival_data=pd.read_excel(
    #                                    io=sharepoint_path+r"\06. HE Format level Models\01. Data Harmonization-Cleaning\02. Cleaned Data\Final_Film_Festival_All.xlsx",
    #                                    sheet_name="Final_Film_Festival_All",
    #                                    na_values=["#N/A", "NA", "N/A", "na", " ", ""]).rename(
    #                                    columns={"IMDB Title Code": "IMDB_Title_Code"}))
    #
    #         nonwb2.fillna({"count_film_festival_new": 0,
    #                        "film_festival_binary_flag_new": 0,
    #                        "film_festival_flag_new": 0},
    #                       inplace=True)
    #         # adding the same filtered film festival flags for WB - EST/PST/iVOD/VOD
    #         iVOD = film_festivals.filtered_film_festival(df=iVOD,
    #                                film_festival_data=pd.read_excel(
    #                                    io=sharepoint_path+r"\06. HE Format level Models\01. Data Harmonization-Cleaning\02. Cleaned Data\Final_Film_Festival_All.xlsx",
    #                                    sheet_name="Final_Film_Festival_All",
    #                                    na_values=["#N/A", "NA", "N/A", "na", " ", ""]).rename(
    #                                    columns={"IMDB Title Code": "IMDB_Title_Code"}))
    #
    #         iVOD.fillna({"count_film_festival_new": 0,
    #                        "film_festival_binary_flag_new": 0,
    #                        "film_festival_flag_new": 0},
    #                       inplace=True)
    #         # fill 0 for already existing nan in old film festival flag
    #         iVOD.fillna({"count_film_festival": 0,
    #                        "film_festival_binary_flag": 0,
    #                        "film_festival_flag": 0},
    #                       inplace=True)
    #
    #         grpd_genre = pd.read_excel(sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/Genre Mapping/Mkt Genre_Grouped.xlsx")
    #         base_genre = pd.read_excel(sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/Genre Mapping/MKT_Genre_Curr_Data_061719.xlsx")
    #
    #         nonwb3 = pd.merge(left=nonwb2,
    #                           right=base_genre[["IMDB_Title_Code", 'Mkt_Genre']],
    #                           how="left",
    #                           left_on="IMDB_Title_Code",
    #                           right_on="IMDB_Title_Code")
    #
    #
    #         nonwb4 = pd.merge(left=nonwb3,
    #                           right=grpd_genre[['Mkt_Genre', 'Mkt_Genre_Grouped']],
    #                           how="left",
    #                           left_on="Mkt_Genre",
    #                           right_on="Mkt_Genre")
    #
    #         # we need to add window so , similar to the excel calculated window for Non wb we need to calculate for wb also in excel
    #         # the we merge it with their base ads
    #
    #         nonwb_window_calc= nonwb_window_calculation()
    #         wb_window_calc= wb_window_calculation()
    #
    #         nonwb5 = pd.merge(left=nonwb4,
    #                           right=nonwb_window_calc[['IMDB_Title_Code', 'est_bo','pst_est','min_vod_est']],
    #                           how="left",
    #                           left_on="IMDB_Title_Code",
    #                           right_on="IMDB_Title_Code")
    #
    #         iVOD2 = pd.merge(left=iVOD,
    #                          right=wb_window_calc[['IMDB_Title_Code', 'est_bo','pst_est','min_vod_est']],
    #                          how="left",
    #                          left_on="IMDB_Title_Code",
    #                          right_on="IMDB_Title_Code")
    #
    #         # check in excel wether the names and list of variables are matching
    #         # EST2.to_excel(r"C:\Users\hari\Desktop\EST2.xlsx", index=False)
    #         # nonwb5.to_excel(r"C:\Users\hari\Desktop\nonwb_EST.xlsx", index=False)
    #
    #         # Concating the 2 dataframes into one single Comp AD - before that check whether the names are same - here it is
    #         add_wb_nonwb = pd.concat([iVOD2, nonwb5], ignore_index=False, sort=True)
    #         # add_wb_nonwb.to_excel(r"C:\Users\hari\Desktop\compadtemp.xlsx", index=False)
    #
    #         return add_wb_nonwb
    #
    #     # temp = ivod_function("IVOD","T+3")
    #
    #     # elif (sale =='Units'):
    #
    #
    #
    #

