import numpy as np
import pandas as pd

# lifecycle_with_grouped_genre.to_excel(r"C:\Users\hari\Desktop\agg_lifecycle.xlsx", index=False)

def lifecycle_function(comp_dataframe,sharepoint_path):
    #
    # lifecycle_original_data = pd.read_csv(
    #     r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\Data Engineering - Lifecycle Survey Data\Aggregate Data\aggregate_request_wb_upload.csv",
    #     sheet_name="aggregate_request_wb_upload")

    # adding the lifecycle data to the Non WB data based on Mkt genre (the column is called genre in the file-"Genre_allmetrics_HE_Lifecycle")
    lifecycle = pd.read_excel(
        r"C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\01. Data Harmonization-Cleaning\02. Cleaned Data\Genre_allmetrics_HE_Lifecycle_Mo_Updated.xlsx",
        sheet_name="T+1")

    comp_ad2 = pd.merge(left=comp_dataframe,
                        right=lifecycle[['Mkt_Genre_Grouped', 'Definitely Interested',
       'Definitely Interested among Aware', 'HE First Choice  ALL',
       'Interest All Rent', 'Interest Any Buy', 'Interest Any Buy Physical',
       'Interest Any HE', 'Interest HE Any Only', 'Interest to Buy EST',
       'Interest to Rent cVod', 'Interest to Rent iVod',
       'Interest to Rent Phy Disc', 'TOP2 Interested', 'Unaid']],
                        how="left",
                        left_on="Mkt_Genre_Grouped",
                        right_on="Mkt_Genre_Grouped")

    return comp_ad2


# This function gest the agg_lifecycle data then maps it with Mkt genre and Mkt genre grouped then gives us the updated or wholesome - average of total % Mkt genre and metrics wise

def lifecycle_function_latest(comp_dataframe,sharepoint_path):
    # life cycle --- > imdb code ---> map to genre from wb --- >  that genre to mkt genre grouped --->  then groupby average for the 10 metrics required
    lifecycle_original_data = pd.read_csv(
        sharepoint_path+"/Data Engineering - Lifecycle Survey Data/Aggregate Data/aggregate_request_wb_upload.csv")
    base_genre_lifecycle = pd.read_excel(
        sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/Genre Mapping/MKT_Genre_Curr_Data_061719.xlsx")
    grpd_genre_lifecycle = pd.read_excel(
        sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/Genre Mapping/Mkt Genre_Grouped.xlsx")

    lifecycle_with_basegenre = pd.merge(left=lifecycle_original_data.rename(columns={"imdb_id": "IMDB_Title_Code"}),
                                        right=base_genre_lifecycle[['IMDB_Title_Code', 'Mkt_Genre']],
                                        how="left",
                                        left_on="IMDB_Title_Code",
                                        right_on="IMDB_Title_Code")

    lifecycle_with_grouped_genre = pd.merge(left=lifecycle_with_basegenre,
                                            right=grpd_genre_lifecycle[['Mkt_Genre', 'Mkt_Genre_Grouped']],
                                            how="left",
                                            left_on="Mkt_Genre",
                                            right_on="Mkt_Genre")

    aggregate_lifecycle = pd.pivot_table(lifecycle_with_grouped_genre, values='total',
                                         index=["Mkt_Genre_Grouped"],
                                         columns='metric',
                                         aggfunc="mean")
    # aggregate_lifecycle['Mkt_Genre_Grouped'] = aggregate_lifecycle.index
    aggregate_lifecycle.reset_index(level=0, inplace=True)

    comp_ad2 = pd.merge(left=comp_dataframe,
                        right=aggregate_lifecycle[['Mkt_Genre_Grouped', 'Awareness', 'Definitely Interested',
                                                   'Definitely Interested among Aware',
                                                   'Definitely Interested to take Child', 'First Choice  ALL',
                                                   'First Choice Opened and Released All', 'Interest All Rent',
                                                   'Interest Any Buy', 'Interest Any Buy Physical', 'Interest Any HE',
                                                   'Interest HE Any Only', 'Interest Theatrical and HE  (Both)',
                                                   'Interest Thetrical Only', 'Interest to Buy EST',
                                                   'Interest to Rent Phy Disc', 'Interest to Rent cVod',
                                                   'Interest to Rent iVod', 'Interest to See Theatrical',
                                                   'See in Theater',
                                                   'Seen ALL cVOD', 'Seen ALL iVOD', 'Seen ALL on  DVD',
                                                   'Seen ALL on 4k',
                                                   'Seen ALL on Any BUY', 'Seen ALL on Any HE', 'Seen ALL on Any Rent',
                                                   'Seen ALL on Any VOD', 'Seen ALL on Blu-ray', 'Seen ALL on EST',
                                                   'Seen ALL on Rent Phy', 'TOP2 Interested', 'Unaid']],
                        how="left",
                        left_on="Mkt_Genre_Grouped",
                        right_on="Mkt_Genre_Grouped")

    return comp_ad2


