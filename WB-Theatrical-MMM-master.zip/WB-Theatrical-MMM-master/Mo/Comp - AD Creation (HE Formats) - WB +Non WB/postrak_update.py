import numpy as np
import pandas as pd
import glob
import os
# import sys
# sys.path.insert(0, r"C:\Users\hari\PycharmProjects\WB-Theatrical-MMM\Mo\Comp - AD Creation (HE Formats) - WB +Non WB")
# from Comp_AD_Combined import comp_ad_required

# # Trying to get the Get the latest file - need to get this code done
# postrak_folder  = glob.glob(r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/01. Base Data - As received/04. Other Data Elements/Survey Data/Postrack Survey Data/*")
# # * means all if need specific format then *.csv
# latest_file = max(postrak_folder, key=os.path.getctime)
# print(latest_file)
# latest_file = latest_file.replace("\\","/")
# print(latest_file)
#
# # files_path = os.path.join(folder, '*')
# # files = sorted(
# #     glob.iglob(files_path), key=os.path.getctime, reverse=True)
# # print files[0]
#
# # C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\01. Base Data - As received\04. Other Data Elements\Survey Data\Postrack Survey Data
# # "C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\01. Data Harmonization-Cleaning\01. Base Data - As received\04. Other Data Elements\Survey Data\Postrack Survey Data\post_trak_film_lookup_results_2019_11_04__11_23_week 2.xlsx"

def postrak_function(comp_dataframe,sharepoint_path):


    postrak = pd.read_excel(io = sharepoint_path+r"/06. HE Format level Models/01. Data Harmonization-Cleaning/02. Cleaned Data/post_trak_film_lookup_results_2019_10_14__14_49_Week 2.1.xlsx",
                            Sheet_name = "Recovered_Sheet1")

    postrak.drop_duplicates(subset =['IMDB_Title_Code'] ,inplace=True)
    comp_ad = pd.merge(left=comp_dataframe,
                       right=postrak[['IMDB_Title_Code', 'Locs\nat\nWidest\nRelease', 'Definitely\nRecommend']],
                       how="left",
                       left_on="IMDB_Title_Code",
                       right_on="IMDB_Title_Code")

    #renaming the required columns
    comp_ad.rename(columns={'Locs\nat\nWidest\nRelease': 'Locations_Widest_Release',
                            'Definitely\nRecommend': 'Definitely_Recommended'}, inplace=True)

    return comp_ad