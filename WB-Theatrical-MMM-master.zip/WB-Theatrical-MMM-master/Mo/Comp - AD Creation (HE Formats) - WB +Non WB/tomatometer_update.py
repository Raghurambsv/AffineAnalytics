import numpy as np
import pandas as pd

# adding the Rotten Tomatoes score

def rotten_tomato_score(comp_dataframe,sharepoint_path):

    tomato = pd.read_excel(sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/04. Other Data Elements/rotten_tomatoes_score.xlsx",sheet_name = "rotten_tomatoes_score")
    tomato.rename(columns = {"IMDB Title Code": "IMDB_Title_Code"},inplace= True)

    tomato.drop_duplicates(subset=['IMDB_Title_Code'],inplace = True)
    comp_ad3 = pd.merge(left=comp_dataframe,
                        right =tomato[["IMDB_Title_Code","tomatometer"]],
                        how = "left",
                        left_on="IMDB_Title_Code",
                        right_on="IMDB_Title_Code")
    return comp_ad3