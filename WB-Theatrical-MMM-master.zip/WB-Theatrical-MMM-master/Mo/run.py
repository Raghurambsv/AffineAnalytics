# importing modules
import sys
sys.path.insert(0, r"C:/Users/hari/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/02. Base AD Creation")
from HE_format_level_Base_AD import *
from HE_format_level_Modeling_AD import *


# change the sale(Revenue or Units), studio(wb or nonwb) , export path(WB or NonWB) accordingly for the code to work
# first run for revenue wb and then units wb with the same export path as WB ..
# then run for Revenue nonwb and Units nonwb with export path as NonWB

# root_folder=r"C:/Users/hari/PycharmProjects"
# sharepoint_path=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents"
# media = 'EST'
# "C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/WB HE Format Base AD.xlsx"
# "C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/WB HE Format Modelling AD.xlsx"

for i in ['EST']:
    he_base_ad_creation(sale = 'Units',
                        studio = 'nonwb',
                        media=i,
                        root_folder=r"C:/Users/hari/PycharmProjects",
                        sharepoint_path=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents",
                        export_path_user=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/NonWB HE Format Base AD.xlsx"
                        )
    print(str(i)+" Base AD done")
    for j in [1]:
        he_modeling_ad_creation(sale = 'Units',
                                studio='nonwb',
                                root_folder=r"C:/Users/hari/PycharmProjects",
                                sharepoint_path=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents",
                                export_path_user="C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/NonWB HE Format Modelling AD.xlsx",
                                media=i,
                                snapshot = j)
        print(str(i) + str(j) + " Modelling AD done")

for i in ['EST']:
    he_base_ad_creation(sale = 'Units',
                        studio = 'wb',
                        media=i,
                        root_folder=r"C:/Users/hari/PycharmProjects",
                        sharepoint_path=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents",
                        export_path_user=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/WB HE Format Base AD.xlsx"
                        )
    print(str(i)+" Base AD done")
    for j in [1]:
        he_modeling_ad_creation(sale = 'Units',
                                studio='wb',
                                root_folder=r"C:/Users/hari/PycharmProjects",
                                sharepoint_path=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents",
                                export_path_user="C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/Phase 2/Data Harmonizing - Cleaning/WB HE Format Modelling AD.xlsx",
                                media=i,
                                snapshot = j)
        print(str(i) + str(j) + " Modelling AD done")


# C:\Users\hari\Desktop\Affine Analytics Pvt Ltd\WB Theatrical - Documents\06. HE Format level Models\Phase 2\Data Harmonizing - Cleaning
# GS data cleaning
import sys
sys.path.insert(0, r"C:/Users/hari/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/01. Data Transformation")
import GS_data_cleaning
GS_data_cleaning.GS_data_cleaning(
    root_folder=r"C:/Users/hari/PycharmProjects",
    sharepoint_path=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents",
    raw_file = r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/01. Base Data - As received/04. Other Data Elements/Social Media Data/Google Search Data/search_volume.csv"
)

# # Competitor Effect BO
# import sys
# sys.path.insert(0, r"C:/Users/hari/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/03. Feature Engineering")
# import GS_data_cleaning
# competitor_effect_bo(
#     root_folder=r"C:/Users/hari/PycharmProjects",
#     sharepoint_path=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents",
#     gs_data = r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Google Search Data/Google Search Data_v5.xlsx",
#     export_path = "C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Competitor Effect_BO_top3.xlsx",
#     competition_weeks=9,
#     competitor_effect_weeks=5
# )

# Competitor effect HE - EST, PST and iVOD
import sys
sys.path.insert(0, r"C:/Users/hari/PycharmProjects/WB-Theatrical-MMM/Phase 2 Codes/03. Feature Engineering")
# import GS_data_cleaning
from  HE_competitor import*

for k in ["EST", "iVOD"]:

    # The below function runs the code to give a file with comp index avg - which will be used in the modelling ad code
    # here the export path is techically not used , can be removed
    # the function directly pastes in the given folder - C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements
    competitor_effect_HE(media= k,
        root_folder=r"C:/Users/hari/PycharmProjects",
        sharepoint_path=r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents",
        GS_data_path = r"C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Google Search Data/Google Search Data_v5.xlsx",
        export_path = "C:/Users/hari/Desktop/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/iVOD Competitor Effect_v1.xlsx",
        competition_weeks=9,
        competitor_effect_weeks=5
    )


# gs_data = pd.read_excel(
#     io=sharepoint_path + r"/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Google Search Data/Google Search Data_v5.xlsx",
#     sheet_name="GS Data",
#     na_values=['#NA', '#N\A', '', ' ', 'na', 'NA'])

# baseAD =pd.read_excel(r"C:\Users\hari\Desktop\check_temp\WB HE Format Modelling AD.xlsx",
#                       sheet_name = "EST_TH+1 week(s)")
# n_years = 2

