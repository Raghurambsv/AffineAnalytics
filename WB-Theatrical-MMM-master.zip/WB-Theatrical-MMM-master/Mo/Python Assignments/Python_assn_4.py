import sys
import numpy as np

# defining a function to get the inputs
def user_input():
    global no_of_lines
    no_of_lines = int(input("Enter the number of items, you wish to enter and the items one by one separated by an enter command"))
    print(no_of_lines)
    lines = ""

    # defining a for loop to ensure the user can enter data one by one after a line space
    for i in range(no_of_lines):
        if i < no_of_lines-1:
            lines+=input()+"\n"
        elif i == no_of_lines-1:
            lines += input()
    print(no_of_lines)
    print(lines)

    # defining a list
    list_with_split_input=[]
    list_with_split_input = lines.split("\n")
    print(list_with_split_input)

    return list_with_split_input

list_with_split_input = user_input()


#  defining a function to check the given condition
def train_data_check():
    # storing a copy of the split datasets
    copy_of_list_with_names = list_with_split_input.copy()

    for i in copy_of_list_with_names:
        for j in range(no_of_lines):
            if (i.split()[0] == copy_of_list_with_names[j].split()[0]):
                if (i.split()[1] != copy_of_list_with_names[j].split()[1]):
                    del copy_of_list_with_names[j]
                    # print("amit")

    return print("length of train data required is",len(copy_of_list_with_names))


train_data_check()

# ------

j = 3

copy_of_list_with_names[j].split()[0]

for k in range(8):
    print(k)

for i in copy_of_list_with_names:
    # copy_of_list_with_names[3].split()[1]
    # print(i.split()[1])
    print(i.split()[1])
    # print(i)
    for j in range(7):
        # print(copy_of_list_with_names[j].split()[1])
        if (i.split()[0] == copy_of_list_with_names[j]):
            if (i.split()[1] == copy_of_list_with_names[j].split()[1]):
                print(i)
                print(j)
                print(copy_of_list_with_names[j])
                # print("Hi executih")
