import re

my_word = input("Enter the string you want to play the game with")

vowels = 'AEIOU'

kevin = 0
stuart = 0
for i in range(len(my_word)):
    if my_word[i] in vowels:
        kevin = kevin + (len(my_word)-i)
    else:
        stuart = stuart + (len(my_word)-i)

if kevin > stuart:
    print ("Kevin wins",kevin)
elif kevin < stuart:
    print ("Stuart wins",stuart)
else:
    print ("Draw - game")

# ---------------------------rough ----------------------------------------------
#
# string_from_user = str(input(" enter string you want to play the game with:"))
#
# kevin_1 = re.findall(r"([AEIOU][a-zA-Z0-9])",string_from_user)
# kevin_2 = re.findall(r"([AEIOU][a-zA-Z0-9]{0,3})",string_from_user)
# kevin_3 = re.findall(r"([AEIOU]+)",string_from_user)
# kevin_4 = re.findall(r"(([AEIOU][^AEIOU])+)",string_from_user)
# kevin_5 = re.findall(r"(([AEIOU][^AEIOU][AEIOU])+)",string_from_user)
#
# check_together = re.findall(r"(?=([AEIOU])",string_from_user)
# if re.match(r"([AEIOU])",i):
#     print("Hi")
#
#
#
# print(kevin)
#
# "".join(string_split)
#
# string_split = list(string_from_user)
# my_list = []
# final_list = []
# for letter in string_split:
#     print("letter is running")
#     for i in range(0,len(string_from_user)):
#         print("i is running")
#         for j in range(i,len(string_from_user)):
#             print("j is running")
#             if letter[0] == "A" :
#                 my_list.append(letter)
#                 temp = "".join(string_split)
#                 final_list.append(temp)
# # kevin = re.compile(r"[a]+").search(string_from_user)
#
# import re
# string_from_user = str(input(" enter string you want to play the game with:"))
# sandy = list(string_from_user)
# final_list = []
# for i in range(len(sandy)):
#     for j in range(len(sandy)+1):
#         if re.match("[AEIOU]",sandy[i]):
#
#             final_list = final_list+[''.join(sandy[i:i+j])]
#
# final_list = final_list.drop(0)
#
# for i in range(len(sandy)):
#     if (sandy[i] == 'A'):
#         for j in range(len(sandy)+1):
#             sandy[i:i+j]
