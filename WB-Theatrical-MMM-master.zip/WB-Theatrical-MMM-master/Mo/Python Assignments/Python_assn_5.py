
# defining the function to reverse the number
def rev_number(number_from_user):
    # declaring reverse number as 0 temporarily
    reverse_add = 0

    # performing a while loop for reversing the number from user
    while(number_from_user>0):
        # getting the last digit by using the % operator - which gives the remainder
        last_digit = number_from_user % 10
        # adding the last digit after multiplying 10 at each iteration - which in turn gives us the reversed digits
        reverse_add = (reverse_add*10) + last_digit
        # using the floor division operator to get the digits before decimals after dividing by 10 at each iteration
        number_from_user = number_from_user // 10

    # printing the reversed number
    print("the reversed digit is",reverse_add)


# Getting Input from user
number_from_user = int(input("enter the number  which is to be inverted"))
print(number_from_user)
rev_number(number_from_user)



