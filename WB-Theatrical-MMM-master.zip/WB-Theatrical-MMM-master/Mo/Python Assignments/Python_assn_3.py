import pandas as pd
import numpy as np

# Question 1 - 	Subset all the column of the dataframe except the column containing the word- “item”

# reading the train csv
train_data = pd.read_csv("C:/Users/hari/Desktop/Warner Bros/Courses and Assignments/Python Assignments/Amits Assignments - 21-1-2020 - assn - 3/Train.csv")

# defining an empty list
filtered_col_names = []

# finding the columns which doesnt have the word "Item"
for i in train_data.columns:
    print (i)
    if "Item" not in i:
        filtered_col_names.append(i)

# filtering for the columns without "Item"
train_data_no_item = train_data[filtered_col_names]

# ------------------------------------------------------------

# Question 2 - 	Identify all the columns of a dataframe which has NA's

train_data_na=train_data.loc[:,train_data.isna().any()]

# ------------------------------------------------------------

# Question 3 - 		In the column “Item_Weight” replace each element by “O” if the element is greater than the mean of the column and by “U” if the element is less than or equal to the mean of the column

mean_value = np.mean(train_data["Item_Weight"])

train_data_UO = train_data.copy()

train_data_UO['Item_Weight'] = train_data_UO['Item_Weight'].apply(lambda x: 'O' if x > mean_value else 'U')

# ------------------------------------------------------------

# Question 4 - 		For every “Item_Identifier” find the “Outlet_Identifier” with maximum “Item_Outlet_Sales”

# getting the unique item identifiers
uniq_item_identfiers = train_data["Item_Identifier"].unique()

# grouping by  ["Item_Identifier","Outlet_Identifier"] and maximum of item outlet sales, inorder to get a master grouped dataframe
train_data_grp_item_id = train_data.groupby(["Item_Identifier","Outlet_Identifier"])["Item_Outlet_Sales"].max().reset_index()

# creating 2 new empty dataframes in order to append in the loop
ranked_dataframe_total = pd.DataFrame()
ranked_dataframe_inner = pd.DataFrame()

# subsetting  for every unique item identifier - then ranking them based on the sales - taking this into
for i in uniq_item_identfiers:
    ranked_dataframe_inner = train_data_grp_item_id[train_data_grp_item_id["Item_Identifier"] == i]
 # then ranking them based on the Item_Outlet_Sales
    ranked_dataframe_inner["rank"]= ranked_dataframe_inner[ranked_dataframe_inner["Item_Identifier"] == i]["Item_Outlet_Sales"].rank(method = "first", ascending=False)
 # append the obtained dataframe for an unique Item_Identifier to master dataframe (ranked_dataframe_total)
    ranked_dataframe_total = ranked_dataframe_total.append(ranked_dataframe_inner, ignore_index=True)

    # an observed point here is, for a given item identfier, the top selling outlet identifier(based on Item_Outlet_Sales ) has the same value for certain number of item identifier
    # hence the rank method first has been used, which gives the first rank to alphabetically first occuring maximum value of Item_Outlet_Sales, if the maximum sales are same for the item identifier

# now to obtain the top selling outlet identifier for every item identifier, we suset with rank 1
top_seller = ranked_dataframe_total[ranked_dataframe_total["rank"]==1]




# -----------------------------Rough---------------------------------------------------------------
    # df['MyColumnName'] = df['MyColumnName'].astype('float64')
    # print(len(ranked_dataframe_inner["rank"]))
    # ranked_dataframe_total.append(ranked_dataframe_inner)
# ranked_dataframe_total = ranked_dataframe_total.concat()
#
#
# train_data_grp_item_id["rank_2"] = train_data["Item_Outlet_Sales"][train_data["Outlet_Identifier"] is in uniq_item_identfiers].rank(ascending=True)
#
#
# train_data_grp_item_id["rank"] = train_data.groupby(["Outlet_Identifier"])["Item_Outlet_Sales"].rank("dense", ascending = False)
#
# train_data_grp_item_id = train_data.groupby(["Item_Identifier"])["Item_Outlet_Sales"].rank()
# train_data_grp_item_id = train_data.groupby(["Item_Identifier","Outlet_Identifier"])["Item_Outlet_Sales"].rank().reset_index()
#
#
#
#
#
# train_data["Outlet_Identifier"]
#
#
# train_data_no_item = train_data[train_data.columns.str.contains('item')==False]
#
# train_data_no_item = train_data[~train_data.columns.str.contains("item",na = False)]
#
# train_data_no_item  = train_data[(train_data.columns) not in (["item"])]
#
# train_data_no_item  = train_data[(train_data.columns != "item"]
#
# train_data.columns
# col_names = train_data.columns
# filtered_col_names = []
# # train_data.filter(train_data.columns)
#  for i in col_names:
#      if "item" not in col_names:
#          print (i)
         # filtered_col_names.append(i)