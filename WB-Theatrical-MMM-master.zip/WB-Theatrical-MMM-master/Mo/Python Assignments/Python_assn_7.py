import pandas as pd
import numpy as np

# entering the size of matrix - even number
N = int(input("Enter the number of elements in the array - even number :"))
print(N)

individual_elem=[]
my_array = []
print("enter the individual elements of the array one by one by pressing enter:")
# getting the input from user for elements of the array
for elem in range(N):
    individual_elem = int(input())
    my_array.append(individual_elem)

# sorting the array in ascending order
sorted_array = np.sort(my_array)

# sorting the array in descending order
reverse_array = sorted_array[::-1]

# function inorder to get the maximum sum required
def find_max_sum(reverse_array):
    max_sum = 0
    new_required_list = []
    for elements in range(int(N/2)):
        # subtracting the highest value element minus the lowest value element
        max_sum = max_sum + reverse_array[elements] - reverse_array[N-1-elements]
        # appending the selected elements in order to get the permuted required list
        new_required_list.append(reverse_array[elements])
        new_required_list.append(reverse_array[N-1-elements])

    print("the re arranged array is : ", new_required_list)
    print("the maximum sum of such array is : ",max_sum)

find_max_sum(reverse_array)

