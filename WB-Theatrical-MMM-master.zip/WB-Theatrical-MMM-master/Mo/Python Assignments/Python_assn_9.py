# q9

# in branch main - check - now - again - 10/3 -

n = int(input("enter the number of elements you want in the master array: "))
print (n)

my_array = []
for i in range(0,n):
    print("enter the element",i+1)
    list_element = int(input())
    my_array.append(list_element)
    print(list_element)

print("Your array has the following elements",my_array)

set_a = set([])
o = int(input("enter the number of set A elements you want: "))
print (o)
for i in range(0,o):
    print("enter the element",i+1)
    set_element = int(input())
    set_a.add(set_element)
    print(set_element)

print("Your set A has the following elements",set_a)

set_b = set([])
p = int(input("enter the number of set B elements you want: "))
print (p)
for i in range(0,p):
    print("enter the element",i+1)
    set_element = int(input())
    set_b.add(set_element)
    print(set_element)

print("Your set B has the following elements",set_b)

print(my_array)
print(set_a)
print(set_b)

points = 0
for i in set_a:
    # print(i)
    if i in my_array:
        points = points +1

for i in set_b:
    # print(i)
    if i in my_array:
        points = points -1

print("total happiness points after calculating for set A and set B is ",points)

# -------------------rough------------------
#
# list(set_a)[0]
#
# for i in range(0,len(list(set_a))):
#     print(list(set_a)[i])
#
# for count,elem in enumerate(set_a):
#     print(count)





