import pandas as pd
import numpy as np

# getting the size of the square matrix from the user
N = int(input("Enter the number of rows/columns of the super matrix :"))
print(N)

# entering the elements of the matrix one by one after a enter statement
matrix = []
individual_elem = None
print("enter the elements of matrix")

for i in range(N):
    for j in range(N):
        individual_elem = int(input())
        matrix.append(individual_elem)

matrix_actual = np.array(matrix).reshape(N, N)
print("Your matrix is : \n",matrix_actual)

# converting the array matrix into a dataframe
matrix_actual = pd.DataFrame(matrix_actual)

# defining a function to calculate the transpose of the sub matrix
def calc_transpose_sub_matrix(matrix_actual):
    sum_of_diag = 0
    list_of_all_trace =[]
    # looping through rows
    for row in range(N):
        # looping through columns
        for col in range(N):
            # looping through steps in order to add the trace of the subset matrix
            for step in range(N):
                # applying an if condition such that negative indices for the matrix dont come into play like[-1][-2]
                if (row-step>=0) & (col-step>=0):
                    # adding the elements diagonally  - Trace wise
                    sum_of_diag = sum_of_diag + matrix_actual[row-step][col-step]
                    print(sum_of_diag)
                else:
                    print("off limits")
            # appending the sum of trace of sub matrix to a list
            list_of_all_trace.append(sum_of_diag)
            # re-initialising the sum to 0 , for a new sub matrix
            sum_of_diag = 0
    # printing the max of the appended list - inorder to get the max trace of sub matrix
    print("the maximum of sum of transpose of a sub matrix is : ", max(list_of_all_trace))

calc_transpose_sub_matrix(matrix_actual)


# # ------------Rough--------------
# abhinav's other method
# my_list=[]
# for i in range(N):
#     first = 0
#     second = 0
#     for j in range(N):
#         if(i<=N-1 and (i+j)<=N-1 and j<=N-1):
#             first = first + matrix_actual[i+j][j]
#             second = second+ matrix_actual[j][i+j]
#             print(first)
#             print(second)
#         else:
#             continue
#         my_list.append(first)
#         my_list.append(second)


# for i in range(N):
#     for j in range(N):
#         individual_elem = int(input())
#         elem.append(individual_elem)
#     matrix.append(elem)
#
#
#
# for i in range(N):
#     for j in range(N):
#         print(matrix[i][j], end = " ")
#     print()

# sande's code for subsetting matrix

# sum_of_diag = 0
# list_of_all_trace =[]
# for size in range(1,N+1):
#     for row in range(N):
#         for col in range(N):
#             # sum_of_diag = sum_of_diag + matrix_actual[i-k][j-k]
#             if (row+size<=matrix_actual.shape[0]) & (col+size<=matrix_actual.shape[1]):
#                 matrix_actual.iloc[range(row,row+size),range(col,col+size)].reset_index()
#                 print("break")