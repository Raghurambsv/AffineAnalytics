# author=Sandeep Sanyal

# set local path for synced sharepoint
sharepoint_path = r'C:/Users/hanaa/Affine Analytics Pvt Ltd/'

# importing packages
import pandas as pd
import csv
# importing datasets
HE_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\HE_Sales_v1.4.csv",
                       sep = ',',
                       encoding = 'latin-1')
Comp_Spending = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Comp_Spending_v3.csv",
                            sep = ',',
                            encoding = 'latin-1')
del Comp_Spending['Studio']
Total_Theater_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Total_Theater_Sales_v3.csv",
                                  sep = ',',
                                  encoding = 'latin-1')
Spend_data = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Spends_data_v1.1.csv",
                         sep = ',',
                         encoding = 'latin-1')
all_movie_list = pd.read_csv(filepath_or_buffer=sharepoint_path+r"CWB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\all_movie_mappings.csv",
                             sep = ',',
                             encoding = 'latin-1')

#Correcting date formats(datetime format kept as YYYY-MM-DD)
HE_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=HE_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=HE_Sales['Blu-ray_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['DVD_Street_Date'] = pd.to_datetime(arg=HE_Sales['DVD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['EST_Street_Date'] = pd.to_datetime(arg=HE_Sales['EST_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['cVOD_Street_Date'] = pd.to_datetime(arg=HE_Sales['cVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_Sales['iVOD_Street_Date'] = pd.to_datetime(arg=HE_Sales['iVOD_Street_Date'], infer_datetime_format=True, errors="coerce")

#Subsetting for Warner
# Master AD creation
master_AD = pd.merge(left = HE_Sales,
                     right=Spend_data.loc[Spend_data['Studio']=='WARNER', ['IMDB_Title_Code',
                                                                           'Studio',
                                                                           'BO_Spend',
                                                                           'EST_Spend',
                                                                           'PST_Spend']],
                     how='inner',
                     left_on = ['IMDB_Title_Code'],
                     right_on = ['IMDB_Title_Code'],
                     sort = True,
                     copy = False)
master_AD = pd.merge(left=master_AD,
                     right = Total_Theater_Sales,
                     how='inner',
                     left_on = ['IMDB_Title_Code'],
                     right_on = ['IMDB_Title_Code'],
                     sort = True,
                     copy = False)
master_AD = pd.merge(left=master_AD,
                     right = Comp_Spending,
                     how='left',
                     left_on = ['IMDB_Title_Code'],
                     right_on = ['IMDB_Title_Code'],
                     sort = True,
                     copy = False)
del HE_Sales, Comp_Spending, Total_Theater_Sales, Spend_data # dropping unnecessary objects to free memory

# calculating only one EST and one PST date
master_AD['EST_Release_Date'] = master_AD[['EST_Street_Date',
                                           'cVOD_Street_Date',
                                           'iVOD_Street_Date']].min(axis = 1)
master_AD['PST_Release_Date'] = master_AD[['Blu-ray_Street_Date',
                                           'DVD_Street_Date']].min(axis = 1)

# calculating Revenues
master_AD['BO_Revenue'] = master_AD[['Native_BO_2D_Amount',
                                     'Native_BO_3D_Amount',
                                     'Native_BO_3D_IMAX_Amount',
                                     'Native_BO_IMAX_Amount']].sum(axis = 1)
master_AD['EST_Revenue'] = master_AD[['EST_Revenue',
                                      'cVOD_Revenue',
                                      'iVOD_Revenue']].sum(axis = 1)
master_AD['PST_Revenue'] = master_AD[['Blu-ray_Revenue',
                                      'DVD_Revenue']].sum(axis = 1)

# calculating tickets sold
master_AD['EST_Sold'] = master_AD[['EST_Sold',
                                   'cVOD_Sold',
                                   'iVOD_Sold']].sum(axis = 1)
master_AD['PST_Sold'] = master_AD[['Blu-ray_Sold',
                                   'DVD_Sold']].sum(axis = 1)

# getting only one Studio
master_AD.rename(columns={'EST_Studio' : 'EST_Studio_old'},
                 inplace=True)
################
##Here 3 conditions are being checked for each format:
#if atleast one channel has a studio in the particular format then Warner is given


##################
#Empty columns are created
master_AD['EST_Studio'] = None
master_AD['PST_Studio'] = None
for i in range(master_AD.shape[0]):
    if len(pd.unique(master_AD.loc[i, ['EST_Studio_old', 'cVOD_Studio', 'iVOD_Studio']].dropna())) != 0:
        master_AD.loc[i, ['EST_Studio']] =['WARNER']
    if len(pd.unique(master_AD.loc[i, ['DVD_Studio', 'Blu-ray_Studio']].dropna())) != 0 :
        master_AD.loc[i, ['PST_Studio']] = ['WARNER']
del i # dropping unnecessary objects to free memory

# calculating BO Window
master_AD['HE_Release_Date'] = master_AD[['PST_Release_Date',
                                          'EST_Release_Date']].min(axis = 1)
master_AD['BO_Window'] = (master_AD['Theatrical_Release_Date_x'] - master_AD['HE_Release_Date'])/pd.offsets.Day(-1)

# getting movie titles
master_AD = pd.merge(left=master_AD,
                     right = all_movie_list[['IMDB_Title_Code',
                                             'Movie_Title']],
                     how='left',
                     left_on = ['IMDB_Title_Code'],
                     right_on = ['IMDB_Title_Code'],
                     sort = True,
                     copy = False)
del all_movie_list # dropping unnecessary objects to free memory

# preparing columns and keeping column consistency
master_AD = master_AD[['IMDB_Title_Code', 'Movie_Title',
                       'Genre', 'Studio', 'EST_Studio', 'PST_Studio',
                       'Theatrical_Release_Date_x', 'EST_Release_Date', 'PST_Release_Date', 'BO_Window',
                       'BO_Spend', 'EST_Spend', 'PST_Spend',
                       'BO_Revenue', 'EST_Revenue', 'PST_Revenue',
                       'EST_Sold', 'PST_Sold',
                       'Native_BO_2D_Amount', 'Native_BO_3D_Amount', 'Native_BO_3D_IMAX_Amount', 'Native_BO_IMAX_Amount',
                       'Opening_Weekend_BO', 'Opening_Weekend_Runs']]
master_AD.rename(columns = {'Studio' : 'Theatrical_Studio',
                            'Theatrical_Release_Date_x' : 'Theatrical_Release_Date',
                            'EST_Spend' : 'EST_Media_Spend',
                            'PST_Spend' : 'PST_Media_Spend',
                            'BO_Spend' : 'BO_Media_Spend'},
                 inplace = True)
master_AD.drop_duplicates(inplace=True) # removing duplicate rows (if any)


# exporting dataset
master_AD.to_csv(path_or_buf=sharepoint_path+r'WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\HE ADs\HE_base_AD_WB_v1.4.csv',
                 index = False)
master_AD.to_csv(path_or_buf=sharepoint_path+r"WB Theatrical - General\02. Data\Analytical Datasets\Set 4 - WB Non-WB CompSpending Imputed\HE_base_AD_WB_v1.4.csv",
                 index = False)
