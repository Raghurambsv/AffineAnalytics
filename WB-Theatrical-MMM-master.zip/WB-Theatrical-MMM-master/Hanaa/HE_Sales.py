#importing packages
import numpy as np
import pandas as pd

# set local path for synced sharepoint
sharepoint_path = r'C:/Users/hanaa/Affine Analytics Pvt Ltd/'

#importing files
Physical_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Physical_Weekly_Sales_v3.csv",
                                    sep=',',encoding = 'latin-1')

Digital_Weekly_Sales = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Digital_Weekly_Sales_v3.csv",
                                   sep=',',encoding = 'latin-1')

Comp_Release_Schedule = pd.read_csv(filepath_or_buffer=sharepoint_path+r"WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Comp_Release_Schedule_v3.1.csv",
                                    sep=',',encoding = 'latin-1')

#Dropping all Titles with no EST Dates and IMDB_Title_ID (done for object Comp_Release_Schedule only)
Comp_Release_Schedule.dropna(subset=['EST_Release','IMDB_Title_ID'],inplace=True)

#Correcting date formats(datetime format kept as YYYY-MM-DD)
Physical_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Physical_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Physical_Weekly_Sales['Street_Date'], infer_datetime_format=True, errors="coerce")
Digital_Weekly_Sales['Theatrical_Release_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
Digital_Weekly_Sales['Street_Date'] = pd.to_datetime(arg=Digital_Weekly_Sales['Street_Date'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['Theatrical_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['Theatrical_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['EST_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['EST_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['VOD_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['VOD_Release'], infer_datetime_format=True, errors="coerce")
Comp_Release_Schedule['PST_Rental_Release'] = pd.to_datetime(arg=Comp_Release_Schedule['PST_Rental_Release'], infer_datetime_format=True, errors="coerce")

# row binding Physical Weekly Sales and Digital Weekly Sales files
phys_digi = pd.concat([Physical_Weekly_Sales, Digital_Weekly_Sales],
                      ignore_index=True)

# collating Physical Weekly Sales and Digital Weekly Sales files and converting to Movie level dataset
gp_data = phys_digi.groupby(['IMDB_Title_Code',
                             'Item_Title_WW',
                             'Studio',
                             'Street_Date',
                             'Theatrical_Release_Date',
                             'Media_Type']).agg({'Revenue':'sum',
                                                 'Units':'sum'}).reset_index()

#Creating key for each bunique combination of IMDB_Title_Code and Media Type
gp_data['Key'] = gp_data['IMDB_Title_Code'] +'_'+gp_data['Media_Type']
unique_title_code = gp_data['Key'].unique()

ds_1=[]
ds_2=[]
#Cases where thee are multiple studios for a unique combination of IMDB_Title_Code and Media Type
for i in unique_title_code:
    temp = gp_data[gp_data['Key'] == i] # subsetting dataset in IMDB_Title_Code/
# logic for more than one studios
    if(len(temp) > 1) :

# if studio is WARNER, keep it, remove the rest
        if (temp['Studio'].str.contains('WARNER').sum() > 0 ):
            ds_1.append(list(temp.loc[temp['Studio'] != 'WARNER',"Item_Title_WW"]))
            gp_data.drop(temp[temp['Studio'] != 'WARNER'].index,axis=0,inplace=True)

# if none of the studios are WARNER
        else:
            gp_data.drop(temp[temp['Revenue'] != max(temp['Revenue'])].index,axis=0,inplace=True)
            ds_2.append(list(temp.loc[temp['Revenue']== max(temp['Revenue']),"Item_Title_WW"]))
print(ds_1)
print(gp_data.shape)

######################################
#Casese where there are multiple street release dates
#Minimum of all dates present is taken
########################################
gp_data = gp_data.groupby('Key').agg({'Revenue':'sum',
                                        'Units':'sum',
                                         'Street_Date':'min',
                                         'Theatrical_Release_Date':'first',
                                         'IMDB_Title_Code':'first',
                                         'Item_Title_WW':'first',
                                         'Theatrical_Release_Date':'first',
                                         'Studio':'first',
                                         'Media_Type':'first'}).reset_index()

#Correcting date formats(datetime format kept as YYYY-MM-DD)
gp_data['Theatrical_Release_Date'] = pd.to_datetime(arg=gp_data['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
gp_data['Street_Date'] = pd.to_datetime(arg=gp_data['Street_Date'], infer_datetime_format=True, errors="coerce")

#Changing from wide format to Long Format
street_date = pd.pivot_table(data=gp_data,
                             index=['IMDB_Title_Code',
                                    'Theatrical_Release_Date',
                                    'Item_Title_WW'],
                             columns=['Media_Type'],
                             values=['Street_Date'],
                             aggfunc=np.unique).reset_index()
studio = pd.pivot_table(data=gp_data,
                        index=['IMDB_Title_Code',
                               'Theatrical_Release_Date',
                               'Item_Title_WW'],
                        columns=['Media_Type'],
                        values=['Studio'],
                        aggfunc=np.unique).reset_index()
Revenue = pd.pivot_table(data=gp_data,
                         index=['IMDB_Title_Code',
                                'Theatrical_Release_Date',
                                'Item_Title_WW'],
                         columns=['Media_Type'],
                         values=['Revenue'],
                         aggfunc=np.sum).reset_index()
Units = pd.pivot_table(data=gp_data,
                       index=['IMDB_Title_Code',
                              'Theatrical_Release_Date',
                              'Item_Title_WW'],
                       columns=['Media_Type'],
                       values=['Units'],
                       aggfunc=np.sum).reset_index()
HE_sales = pd.merge(left=street_date[[('IMDB_Title_Code', ''),
                                      ('Theatrical_Release_Date', ''),
                                      ('Street_Date', 'Blu-ray'),
                                      ('Street_Date', 'DVD'),
                                      ('Street_Date', 'EST'),
                                      ('Street_Date', 'cVOD'),
                                      ('Street_Date', 'iVOD')]],
                    right=studio[[('IMDB_Title_Code', ''),
                                  ('Studio', 'Blu-ray'),
                                  ('Studio', 'DVD'),
                                  ('Studio', 'EST'),
                                  ('Studio', 'cVOD'),
                                  ('Studio', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
HE_sales = pd.merge(left=HE_sales,
                    right=Revenue[[('IMDB_Title_Code', ''),
                                   ('Revenue', 'Blu-ray'),
                                   ('Revenue', 'DVD'),
                                   ('Revenue', 'EST'),
                                   ('Revenue', 'cVOD'),
                                   ('Revenue', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
HE_sales = pd.merge(left=HE_sales,
                    right=Units[[('IMDB_Title_Code', ''),
                                 ('Units', 'Blu-ray'),
                                 ('Units', 'DVD'),
                                 ('Units', 'EST'),
                                 ('Units', 'cVOD'),
                                 ('Units', 'iVOD')]],
                    how='left',
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_Code'],
                    sort=True,
                    copy=False)
print(HE_sales.shape)
HE_sales.columns = ['IMDB_Title_Code',
                    'Theatrical_Release_Date',
                    'Blu-ray_Street_Date',
                    'DVD_Street_Date',
                    'EST_Street_Date',
                    'cVOD_Street_Date',
                    'iVOD_Street_Date',
                    'Blu-ray_Studio',
                    'DVD_Studio',
                    'EST_Studio',
                    'cVOD_Studio',
                    'iVOD_Studio',
                    'Blu-ray_Revenue',
                    'DVD_Revenue',
                    'EST_Revenue',
                    'cVOD_Revenue',
                    'iVOD_Revenue',
                    'Blu-ray_Sold',
                    'DVD_Sold',
                    'EST_Sold',
                    'cVOD_Sold',
                    'iVOD_Sold']

#Correcting date formats(datetime format kept as YYYY-MM-DD)
HE_sales['Theatrical_Release_Date'] = pd.to_datetime(arg=HE_sales['Theatrical_Release_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['Blu-ray_Street_Date'] = pd.to_datetime(arg=HE_sales['Blu-ray_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['DVD_Street_Date'] = pd.to_datetime(arg=HE_sales['DVD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['EST_Street_Date'] = pd.to_datetime(arg=HE_sales['EST_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['cVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['cVOD_Street_Date'], infer_datetime_format=True, errors="coerce")
HE_sales['iVOD_Street_Date'] = pd.to_datetime(arg=HE_sales['iVOD_Street_Date'], infer_datetime_format=True, errors="coerce")

#Preparing the final dataset
HE_sales = pd.merge(left=HE_sales,
                    right=Comp_Release_Schedule[['IMDB_Title_ID',
                                                 'EST_Release']],
                    left_on=['IMDB_Title_Code'],
                    right_on=['IMDB_Title_ID'],
                    how='left',
                    sort=True,
                    copy=False)

#Filling in the EST dates from Comp_Release_Schedule in the case of not being present
HE_sales['EST_Street_Date'] = HE_sales.apply(
    lambda x: x['EST_Release'] if pd.isnull(x['EST_Street_Date']) else x['EST_Street_Date'],
    axis=1)

#Dropping extra columns
HE_sales.drop(['IMDB_Title_ID', 'EST_Release'], axis=1, inplace=True)
HE_sales["min_date"] = HE_sales[['Blu-ray_Street_Date','DVD_Street_Date','EST_Street_Date','cVOD_Street_Date','iVOD_Street_Date']].min(axis=1)

#Calculating BO Window
HE_sales['BO_Window'] = (HE_sales['min_date'] - HE_sales["Theatrical_Release_Date"])/np.timedelta64(1,'D')

#Subsetting for only postive BO Window(Theatrical Relaese before HE Release)
HE_sales = HE_sales[HE_sales['BO_Window'] >= 0]

#Dropping duplicates
HE_sales.drop_duplicates(inplace=True) # removing duplicate rows (if any)

# exporting dataset
master_AD.to_csv(path_or_buf=sharepoint_path+r'WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\AD Archive\HE_Sales_v1.0.csv',
                 index = False)
