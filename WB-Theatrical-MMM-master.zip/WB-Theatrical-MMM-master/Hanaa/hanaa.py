import pandas as pd
import numpy as np

df = pd.read_csv(r"C:\Users\hanaa\Desktop\hanaa\Warner Bros\all_spend_data.csv")
BO_Spend = pd.read_csv(
    r"C:\Users\hanaa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\BO_Spend.csv",
    sep=',',
    encoding='latin-1')
# BO_Spend['Studio'] = 'WARNER' # Since this file only contain WB titles
Comp_Spending_v3 = pd.read_csv(
    r"C:\Users\hanaa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Comp_Spending_v3.csv",
    sep=',',
    encoding='latin-1')
Comp_Spending_v3['Street_Date'] = pd.to_datetime(arg=Comp_Spending_v3['Street_Date'], infer_datetime_format=True,
                                                 errors="coerce")
Comp_Spending_v3.drop(index=Comp_Spending_v3.loc[(Comp_Spending_v3['IMDB_Title_Code'] == 'tt0762125') & (
            Comp_Spending_v3['Studio'] == 'DISNEY'), :].index,
                      axis=0,  # as per IMDB, Title Code: 'tt0762125' is not DISNEY's production
                      inplace=True)
Comp_Spending_v3.drop(index=Comp_Spending_v3.loc[(Comp_Spending_v3['IMDB_Title_Code'] == 'tt0765429') & (
            Comp_Spending_v3['Street_Date'] == pd.Timestamp(year=2008, month=3, day=18)), :].index,
                      axis=0,  # deleting duplicate title code with street date later than the other than
                      inplace=True)
Total_Media2_v3 = pd.read_csv(
    r"C:\Users\hanaa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\Total Media2_v3.csv",
    sep=',',
    encoding='latin-1')
all_movie_list = pd.read_csv(
    r"C:\Users\hanaa\Affine Analytics Pvt Ltd\WB Theatrical - General\02. Data\Tier 1 Data - Cleaned\Base Data\all_movie_mappings.csv",
    sep=',',  # file contains IMDB Title Codes and IMDB Title Names of all movies received from client
    encoding='latin-1')

# merging available BO spend data for all titles
spend_data = pd.merge(left=all_movie_list,
                      right=BO_Spend[['IMDB_Title_Code', 'BO_Spend']],
                      how='left',
                      left_on=['IMDB_Title_Code'],
                      right_on=['IMDB_Title_Code'],
                      sort=True,
                      copy=False)

# merging HE spend data from Comp_Spending file, for all titles
spend_data = pd.merge(left=spend_data,
                      right=Comp_Spending_v3[['IMDB_Title_Code', 'Total_Media_Spend']],
                      how='left',
                      left_on=['IMDB_Title_Code'],
                      right_on=['IMDB_Title_Code'],
                      sort=True,
                      copy=False)

# merging Total HE, EST, VOD and PST spend data from Total_Media2 file, for all titles
spend_data = pd.merge(left=spend_data,
                      right=Total_Media2_v3[
                          ['IMDB_Title_Code', 'TOTAL_CONSUMER_MEDIA', 'PHYSICAL_MEDIA', 'EST', 'VOD']],
                      how='left',
                      left_on=['IMDB_Title_Code'],
                      right_on=['IMDB_Title_Code'],
                      sort=True,
                      copy=False)

# dropping all titles with no spend data
spend_data.dropna(subset=['BO_Spend',
                          'Total_Media_Spend',
                          'TOTAL_CONSUMER_MEDIA',
                          'PHYSICAL_MEDIA',
                          'EST',
                          'VOD'],
                  how='all',
                  inplace=True)

spend_data.reset_index(inplace=True, drop=True)

df = spend_data

df = df.assign(Final_EST=(df["EST"] + df["VOD"]))
del df["EST"]
del df["VOD"]
bo = []
he = []
pst = []
est = []
code = []
# edit_df=df.loc[(df["BO_Spend"]!=" ")|(df["Total_Media_Spend"]!=" ")]
bo_lt = list(df["BO_Spend"])
he_cs = list(df["Total_Media_Spend"])
he_tm = list(df["TOTAL_CONSUMER_MEDIA"])
pst_lt = list(df["PHYSICAL_MEDIA"])
est_lt = list(df["Final_EST"])
code_lt = list(df["IMDB_Title_Code"])
c = 0
ln = len(df)
while c < len(df):
    if ((np.isnan(bo_lt[c]) != True) & ((np.isnan(he_tm[c]) == True) & (np.isnan(he_cs[c]) == True))):
        #         if(np.isnan(bo_lt[c])!=True):
        print("1")
        code.append(code_lt[c])
        bo.append(bo_lt[c])
        he.append(bo_lt[c])
        pst.append(((bo_lt[c]) * 2) / 5)
        est.append(((bo_lt[c]) * 3) / 5)
    elif ((np.isnan(bo_lt[c]) == True) & ((np.isnan(he_tm[c]) != True) & (np.isnan(he_cs[c]) != True))):
        print("2")
        code.append(code_lt[c])
        bo.append(he_tm[c])
        he.append(he_tm[c])
        pst.append((pst_lt[c]))
        est.append((est_lt[c]))
    elif ((np.isnan(bo_lt[c]) == True) & ((np.isnan(he_tm[c]) != True) & (np.isnan(he_cs[c]) == True))):
        print("3")
        code.append(code_lt[c])
        bo.append(he_tm[c])
        he.append(he_tm[c])
        pst.append((pst_lt[c]))
        est.append((est_lt[c]))

    elif ((np.isnan(bo_lt[c]) == True) & ((np.isnan(he_tm[c]) == True) & (np.isnan(he_cs[c]) != True))):
        print("4")
        code.append(code_lt[c])
        bo.append(he_cs[c])
        he.append(he_cs[c])
        pst.append(((he_cs[c]) * 4) / 10)
        est.append(((he_cs[c]) * 6) / 10)
    elif ((np.isnan(bo_lt[c]) != True) & (np.isnan(he_tm[c]) != True) & (np.isnan(he_cs[c]) == True)):
        print("5")
        code.append(code_lt[c])
        pst.append((pst_lt[c]))
        est.append((est_lt[c]))
        he.append(he_tm[c])
        bo.append(bo_lt[c])
    elif ((np.isnan(bo_lt[c]) != True) & (np.isnan(he_tm[c]) == True) & (np.isnan(he_cs[c]) != True)):
        print("6")
        code.append(code_lt[c])
        pst.append(((he_cs[c]) * 4) / 10)
        est.append(((he_cs[c]) * 6) / 10)
        he.append(he_cs[c])
        bo.append(bo_lt[c])

    elif ((np.isnan(bo_lt[c]) != True) & ((np.isnan(he_tm[c]) != True) & (np.isnan(he_cs[c]) != True))):
        print("7")
        code.append(code_lt[c])
        bo.append(bo_lt[c])
        he.append(he_tm[c])
        pst.append((pst_lt[c]))
        est.append((est_lt[c]))

    c = c + 1
final_df = pd.DataFrame(
    {'IMDB Title Code': pd.Series(code), 'BO Spends': pd.Series(bo), 'HE Spends': pd.Series(he), 'PST': pd.Series(pst),
     'EST': pd.Series(est)})
lm = len(final_df)
sm = (final_df[["BO Spends"]]).sum() + (final_df["EST"]).sum() + (final_df["PST"]).sum()
print("Length:", ln)
print("BO", ((final_df["BO Spends"]).sum()))
print("EST", ((final_df["EST"]).sum()))
print("PST", ((final_df["PST"]).sum()))
print("Total", sm / 100000)