#Importing the required libraries
import pandas as pd
import time
import sys

def data_cleaning(
        root_folder: str,
        sharepoint_path: str,
        cleaning_these: list
) -> dict:
    """
    This script cleans raw data files

    Parameters
    ----------
    root_folder : string
        Home folder containing codes after a github pull
    sharepoint_path : string
        Home folder for shared drive
    cleaning_these : list of strings
        A list of strings containing what files are needed to be cleaned
        Options:    Weekly Home Ent. Sales
                    Google Search Volume
                    Postrak
                    Audience Demographics
                    Metadata
                    Rotten Tomatoes
    Returns
    -------
    cleaned_dict : dictionary
        A dictionary containing cleaned data files

    """

    #Declaring the root folder & Sharepoint folder and importing the required files
    sys.path.insert(0, root_folder+r"/Phase 2 Codes/01. Data Transformation")
    import HE_revenue_cleaning
    import GS_1_0_data_cleaning
    import Metadata_cleaning
    sys.path.insert(0, root_folder + r"/Phase 2 Codes/03. Feature Engineering")
    import Audience_Demo_merge


    cleaned_dict = {}

    # HE sales_cleaning

    if "Weekly Home Ent. Sales" in cleaning_these:
        Weekly_HE_sales1, bo_rev_df1 = HE_revenue_cleaning.HE_sales_cleaning(
            raw_file=sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/01. Sales Data/HE Sales/Priyanka.2019.12.09.xlsx",
            HE_sales_export_path=False,
            Total_BO_sales_export_path=False
        )
        Weekly_HE_sales2, bo_rev_df2 = HE_revenue_cleaning.HE_sales_cleaning(
            raw_file=sharepoint_path + r"/01. Data Harmonization-Cleaning/01. Base Data - As received/01. Sales Data/HE Sales/Priyanka.2020.02.20.xlsx",
            HE_sales_export_path=False,
            Total_BO_sales_export_path=False
        )
        Weekly_HE_sales=pd.concat([Weekly_HE_sales1,Weekly_HE_sales2],sort=False)
        bo_rev_df=pd.concat([bo_rev_df1,bo_rev_df2],sort=False)

        cleaned_dict["Cleaned Weekly HE sales"] = Weekly_HE_sales
        cleaned_dict["Cleaned Total Theater Sales"] = bo_rev_df

    # Google Search cleaning
    if "Google Search Volume" in cleaning_these:
        gsv_clean_df=GS_1_0_data_cleaning.GS_data_cleaning(
            sharepoint_path=sharepoint_path,
                         root_folder=root_folder,
                         raw_file=sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/04. Other Data Elements/Social Media Data/Google Search Data/2020-03-09 Google Search Tracker Update.csv",
                         export_path=False
        )
        cleaned_dict["Cleaned GSV"] = gsv_clean_df

    # Post_trak cleaning
    """
    Raw file for this data is "C:/Users/rolee/Affine Analytics Pvt Ltd/WB Theatrical - Documents/01. Data Harmonization-Cleaning/01. Base Data - As received/04. Other Data Elements/Survey Data/Postrack Survey Data/post_trak_film_lookup_results_2019_10_14__14_49_Week 2.xlsx"
    Map title code and Release year to the file. We add release year to help in fuzzy lookup.
    Final file can be found at :"C:/Users/rolee/Affine Analytics Pvt Ltd/WB Theatrical - Documents/06. HE Format level Models/01. Data Harmonization-Cleaning/02. Cleaned Data/post_trak_film_lookup_results_2019_10_14__14_49_Week 2.1.xlsx"
    Drop duplicate IMDB title codes. For eg: IMDB has same title codes for the movies:Deadpool and Once Upon a Deadpool
    
    """
    if "Postrak" in cleaning_these:
        posttrak_df=pd.read_excel(sharepoint_path+r"/06. HE Format level Models/01. Data Harmonization-Cleaning/02. Cleaned Data/post_trak_film_lookup_results_2019_10_14__14_49_Week 2.1.xlsx")
        posttrak_df.rename(columns={'Locs\nat\nWidest\nRelease':'Number of Theatres released','Definitely\nRecommend':'Definitely Recommended','IMDB_Title_Code':'IMDB Title Code'},inplace=True)
        cleaned_dict["Cleaned Postrak"] = posttrak_df

    #Audience Demo data cleaning

    """
    The raw file for Audience Demo data has to be first mapped with the title codes
    Then passing that mapped title code file as an argument to the function below
    """
    # if "Audience Demographics" in cleaning_these:
    #     audi_df=Audience_Demo_clean.audience_demo_cleaning(raw_file=sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/04. Other Data Elements/Survey Data/Audience Demographics/2019-12-20_Audience-Demos.csv",
    #                            export_path=False)
    #     cleaned_dict["Cleaned Audience Demographics"] = audi_df

    if "Audience Demographics" in cleaning_these:
        audi_df=Audience_Demo_merge.audience_merge(root_folder=root_folder,
                                                   sharepoint_path=sharepoint_path,
                                                   old_raw_file=pd.read_csv(sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/04. Other Data Elements/Survey Data/Audience Demographics/2019-12-20_Audience-Demos.csv"),
                                                   new_raw_file=pd.read_excel(io = sharepoint_path+r"/01. Data Harmonization-Cleaning/02. Cleaned Data/04. Other Data Elements/Audience Demographics data/20200304_rohan_query_mapped_cleaned.xlsx",sheet_name= "20200304_rohan_query"))
        cleaned_dict["Cleaned Audience Demographics"] = audi_df

    #Metadata cleaning
    if "Metadata" in cleaning_these:
        md_csv = pd.read_csv(
            filepath_or_buffer=sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/title_metadata_widerel_2015plus.tsv",
            sep='\t'
        )
        """
        Title Codes need to be mapped to this exported file using Vlookup or fuzzy lookup. 
        That mapped title code file is to be directly used in the metadata_cleaning code below.
        """
        metadata_df = pd.read_excel(sharepoint_path+r"/02. Exploratory Analysis/Movie Metadata - Eric.xlsx",
                                        sheet_name = "Metadata")
        md_df=Metadata_cleaning.metadata_cleaning(metadata_df,
                                            export_path=False)
        cleaned_dict["Cleaned Metadata"] = md_df



    #Rotten Tomatoes cleaning
    """
     For recent movies, tomatometer scores might be missing. Has to be manually tagged
     No other cleaning required
     NOTE: Remove titles with the same title code. For ex, Deadpool2 & Once Upon a Time in Deadpool
     
    """
    if "Rotten Tomatoes" in cleaning_these:
        tomatometer_df=pd.read_excel(sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/04. Other Data Elements/rotten_tomatoes_score.xlsx")
        tomatometer_df = tomatometer_df[tomatometer_df.titles!= 'Once Upon a Deadpool']
        cleaned_dict["Cleaned Tomatometer"] = tomatometer_df

    return cleaned_dict
