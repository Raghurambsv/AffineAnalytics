import sys
import pandas as pd
sys.path.insert(0, r"C:/Users/rolee/PycharmProjects/WB-Theatrical-MMM/Rolee/HE Forecasting")
import temp_modeling_AD

modeling_AD = temp_modeling_AD.he_modeling_ad_creation(
    sale='Units',
    media = 'VOD',
    root_folder = r"C:/Users/rolee/PycharmProjects/WB-Theatrical-MMM",
    sharepoint_path = r"C:/Users/rolee/Affine Analytics Pvt Ltd/WB Theatrical - Documents"
)

with pd.ExcelWriter(
        path=r"C:/Users/rolee/Desktop/VOD_Units_trial_modeling_AD_unimputed.xlsx",
        mode='w',
        engine='openpyxl',
        date_format='YYYY-MM-DD',
        datetime_format='DD-MMM-YYYY') as writer:
    modeling_AD.to_excel(
        excel_writer=writer,
        index=False,
        sheet_name='HE Refresh v1.0')








