def feature_engg(root_folder,sharepoint_path):

    # Importing the required libaries
    import pandas as pd
    import sys

    # Passing the root folder and sharepoint folder and importing the required files

    sys.path.insert(0, root_folder+r"/Phase 2 Codes/03. Feature Engineering")
    import franchise
    import GSV
    import marketing_genre_grouping
    import Lifecycle_Feature_Engineering

    #Marketing_genre_grouped_creation
    mg_df=marketing_genre_grouping.marketing_genre_grouped_creation(raw_file=sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/Genre Mapping/MKT_Genre_Curr_Data_061719 -Ungrouped.xlsx",
                                     mapping_file=sharepoint_path+r"/01. Data Harmonization-Cleaning/01. Base Data - As received/03. Movie Metadata/Genre Mapping/Mkt Genre_Grouped.xlsx",
                                     export_path=False)

    #Lifecycle_variables_
    lifecycle_df=Lifecycle_Feature_Engineering.lifecycle_feature_engg(sharepoint_path=sharepoint_path,
                                                                      root_folder=root_folder,
                                                                      input_path=sharepoint_path+r"/05. Ad Hoc Requests/Unaided vs EST/Version 2/Archive/aggregate_request_wb_upload.csv",
                                                                      export_path=False)


    #Google Search Volume(Mean, Max, Sum)
    gsv_df=GSV.gsv(root_folder=root_folder,
                   sharepoint_path=sharepoint_path,
                   export_path=False)

    #Franchise variables
    """
    Creates Franchise Flag and DC/Marvel Flag
    We first get the list of titles for which franchise has to be mapped
    
    """
    fran_data = pd.read_excel(sharepoint_path + r"/General/02. Data/Tier 1 Data - Cleaned/External Sources/franchise_data_mapped_v2.xlsm",
                              sheet_name="franchise_data_mapped_v1",
                              header=1)
    wb_title_AD = pd.read_excel(sharepoint_path + r"/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Title List.xlsx",
                             sheet_name='WB Titles',
                             na_values=['#NA', '#N/A', '', ' ', 'na', 'NA'])
    nonwb_title_AD = pd.read_excel(
        sharepoint_path + r"/01. Data Harmonization-Cleaning/03. Analytical Datasets/Archive/Title List.xlsx",
        sheet_name='NonWB Titles',
        na_values=['#NA', '#N/A', '', ' ', 'na', 'NA'])
    title_AD=pd.concat([wb_title_AD,nonwb_title_AD],sort=False)

    franchise_df=franchise.franchise_flag_dc_marvel_flag(fran_data,title_AD)

    return mg_df,lifecycle_df,gsv_df,franchise_df
    #Runtime
    # runtime_df=runtime_creation(input_path=sharepoint_path+r"/01. Data Harmonization-Cleaning/00. Phase 1 Data Dependencies/03. Movie Metadata/IMDB_scrapped_titles_v5.csv",

    #Holiday Metrics(Easter Flag, Fourth july flag, holiday_flag, long_weekend_flag

    # base_AD=pd.read_excel(baseAD_file,sheet_name=media+' Base AD'+sale)
    # holiday_df=holiday_metrics.holiday_flag(root_folder = root_folder,
    #                                 base_dataframe=base_AD,
    #                                 date_col_calendar='Date',
    #                                 date_col_base_dataframe='Week Start Date',
    #                                 holiday_calendar=pd.read_excel(io=sharepoint_path+r"/03. Feature Engineering/02. Codes/Modelling AD Folder/US Holiday Calendar Exhaustive.xlsx",
    #                                                                   sheet_name="Sheet1",
    #                                                                   na_values=['#NA','#N/A','',' ','na','NA']))
    #
    #
    # long_df=holiday_metrics.long_weekend_flag(root_folder = root_folder,
    #                                         base_dataframe=base_AD,
    #                                         date_col_calendar='Date',
    #                                         date_col_base_dataframe='Week Start Date',
    #                                         holiday_calendar=pd.read_excel(io=sharepoint_path+r"/03. Feature Engineering/02. Codes/Modelling AD Folder/US Holiday Calendar Exhaustive.xlsx",
    #                                                                        sheet_name="Sheet1",
    #                                                                        na_values=['#NA','#N/A','',' ','na','NA']))
    #
    # easter_df=holiday_metrics.easter_flag(root_folder=root_folder,
    #                             base_dataframe=base_AD,
    #                             date_col_calendar='Date',
    #                             date_col_base_dataframe='Week Start Date',
    #                             holiday_calendar=pd.read_excel(io=sharepoint_path+r"/03. Feature Engineering/02. Codes/Modelling AD Folder/US Holiday Calendar Exhaustive.xlsx",
    #                                                                        sheet_name="Sheet1",
    #                                                                        na_values=['#NA','#N/A','',' ','na','NA']))
    #
    # fourth_df=holiday_metrics.fourth_july(root_folder=root_folder,
    #                             base_dataframe=base_AD,
    #                             date_col_calendar='Date',
    #                             date_col_base_dataframe='Week Start Date',
    #                             holiday_calendar=pd.read_excel(io=sharepoint_path+r"/03. Feature Engineering/02. Codes/Modelling AD Folder/US Holiday Calendar Exhaustive.xlsx",
    #                                                                        sheet_name="Sheet1",
    #                                                                        na_values=['#NA','#N/A','',' ','na','NA']))
