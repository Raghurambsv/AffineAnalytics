# author : Arunav

import bs4
import pandas as pd
import json
from requests import get
import re
import ast

def replicate_tag(tag, n):
  import numpy as np
  return list(np.repeat(tag,n))

def create_extended_list(dic):
  tmp = []
  for item in dic:
    tmp.extend(replicate_tag(item[0], item[1]))
  return tmp

def parse_award_info(actor_id):
  url = 'https://www.imdb.com/'+ actor_id +'awards'
  response = get(url)
  
  soup = bs4.BeautifulSoup(response.text, 'lxml')
  year_container = soup.find_all('td', class_ = 'award_year')
  outcome_container = soup.find_all('td', class_ = 'award_outcome')
  
  try:
    name = soup.find('div', class_ = 'parent').a.text.strip()
  except:
    name = None
  
  award_year_dic = [(award_year.a.text.strip(), int(award_year.get('rowspan'))) for award_year in year_container]
  
  award_outcome_dic = [(award_outcome.b.text.strip(), int(award_outcome.get('rowspan')))  for award_outcome in outcome_container]

  award_category_dic = [(award_category.span.text.strip(), int(award_category.get('rowspan')))  for award_category in outcome_container]
  
  return award_year_dic, award_outcome_dic, award_category_dic, name

def get_actor_award_data(actor_id):
  year, outcome, category, name = parse_award_info(actor_id)
  
  year_extended = create_extended_list(year )
  outcome_extended = create_extended_list(outcome )
  category_extended = create_extended_list(category )
  id_extended = create_extended_list([(actor_id, len(year_extended))])
  name_extended = create_extended_list([(name, len(year_extended))])
  
  return [year_extended, outcome_extended, category_extended, id_extended, name_extended]
  
def create_awards_dataframe(list_of_actors):
  year_list = []
  outcome_list = []
  category_list = []
  name_list = []
  id_list = []
  
  i = 1
  total_actors = len(list_of_actors)
  for actor in list_of_actors:
    print(actor+" "+str(i)+"/"+str(total_actors))
    years, outcomes, categories, actor_id, names = get_actor_award_data(actor)
    year_list.extend(years)
    outcome_list.extend(outcomes)
    category_list.extend(categories)
    name_list.extend(names)
    id_list.extend(actor_id)
    i += 1
  
  df = pd.DataFrame({'award_year':year_list, 'award_outcome': outcome_list, 'award_category': category_list, 'name': name_list, 'id': id_list})
  return df.groupby(['name', 'id','award_year', 'award_category', 'award_outcome']).size().reset_index(name = 'count')


## Usage ##
# actors_list = ['/name/nm1569276/', '/name/nm0430107/', '/name/nm2143282/', '/name/nm1775091/']
# directors = ['/name/nm0923736/']


# Download data from here
# https://affineindia.sharepoint.com/:x:/s/WBTheatrical/Ed6PeCPHbb9PpsRmuW89RvEB_Fxh2DD9Mr1VGuMOAE4P_Q?e=ilY9kc

df_scrapped = pd.read_csv('./IMDB_scrapped_titles.csv')

actors_list = []
for actorsURL in df_scrapped['ActorsURL'].dropna():
    try:
        actors_list.extend(ast.literal_eval(actorsURL))
    except:
        actors_list.extend([actorsURL])

        
df = create_awards_dataframe(set(actors_list))

df.to_csv("./actors_data.csv", index = False)
