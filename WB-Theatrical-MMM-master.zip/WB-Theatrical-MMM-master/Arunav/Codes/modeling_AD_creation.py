# author : Arunav


import pandas as pd

baseAD = pd.read_excel('./Warner Bros - Home Ent. AD.xlsx', sheet_name = 2)

franchise_data = pd.read_excel('./franchise_data_mapped_v2.xlsm', sheet_name = 1)
franchise_data['franchise_flag'] = 1

IMDB_scrapped_titles = pd.read_csv('./IMDB_scrapped_titles.csv')

macro_economic_data = pd.read_excel('./monthly_macro_economic_data.xlsx', sheet_name = 1)

baseAD.rename({'Genre' : 'Raw_Genre'}, axis='columns', inplace = True)

def create_release_year_month(df, date_cols):
  for col in date_cols:
    base_str = col.split('_Date')[0]

    baseAD[base_str + '_Year'] = pd.DatetimeIndex(baseAD[col]).year
    baseAD[base_str + '_Month'] = pd.DatetimeIndex(baseAD[col]).month
  
  return baseAD

baseAD = create_release_year_month(baseAD, ['Theatrical_Release_Date', 'EST_Release_Date', \
                                            'PST_Release_Date'])

df_1 = baseAD.merge(franchise_data[['IMDB title', 'franchise_flag']].drop_duplicates(), \
                                  left_on = 'IMDB_Title_Code', \
                                  right_on = 'IMDB title', how = 'left').\
              drop(['IMDB title'], axis = 1)

df_1.fillna({'franchise_flag':0}, inplace=True)


df_2 = df_1.merge(IMDB_scrapped_titles, \
                  left_on = 'IMDB_Title_Code', \
                  right_on = 'titleID', \
                  how = 'left').\
            drop(['titleID', 'Movie.Name', 'US.Release.Date'], axis = 1)

def create_macro_economic_vars(df, economic_data, media):
  for medium in media:
    keys = [medium + '_Release_Year', medium + '_Release_Month']
    df = df.merge(economic_data, \
                  left_on = keys, \
                  right_on = ['Year', 'Month'], \
                  how = 'left').\
            drop(['Month', 'Year', 'Year-Month'], axis = 1)

    df.rename({'Unemployment Rates' : medium + '_Unemployment_Rates', \
            'CPI' : medium + '_CPI',\
            'Monthly Nominal GDP Index': medium + '_Monthly_GDP_Index',\
            'Monthly Real GDP Index': medium + '_Monthly_Real_GDP_Index'}, \
            axis='columns', inplace = True)
  return df

df_3 = create_macro_economic_vars(df_2, macro_economic_data, ['Theatrical', 'EST', 'PST'])
df_3



