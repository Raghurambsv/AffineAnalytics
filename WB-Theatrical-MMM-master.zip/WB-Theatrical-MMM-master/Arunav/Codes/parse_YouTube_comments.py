# author : Arunav

from apiclient.discovery import build
import datetime
import pandas as pd

api_key = "AIzaSyCfGXkXLbSUIXoTNtBweZIF13O3GyEElQU"
youtube = build('youtube', 'v3' , developerKey = api_key)


def get_comment_threads(videoId):
  
  pageToken = None
  commentThread = []
  
  while 1:
    req = youtube.commentThreads().list(videoId = videoId, 
                                        part = "snippet", 
                                        order = "time", 
                                        textFormat = "plainText", 
                                        maxResults = 100, 
                                        pageToken = pageToken)
    re = req.execute()
    
    try:
      pageToken = re['nextPageToken']
    except:
      pageToken = None
      
    for item in re["items"]:
      commentThread.append([item["id"], item["snippet"]["topLevelComment"]["snippet"]["textDisplay"], \
                            item["snippet"]["topLevelComment"]["snippet"]["likeCount"], \
                            item["snippet"]["topLevelComment"]["snippet"]["publishedAt"], \
                            item["snippet"]["totalReplyCount"]])

    if pageToken == None:
      break
    else:
      pass
  
  return commentThread

def create_comments_df(videoIds):
  
  df = pd.DataFrame([], columns = ["videoId","threadId", "text", "likes","upload_date", "replyCount"])
  
  for id in videoIds:
    df_tmp = pd.DataFrame(get_comment_threads(id), 
                          columns = ["threadId", "text", "likes","upload_date", "replyCount"])
    df_tmp["videoId"] = id
    df = pd.concat([df, df_tmp])
  
  df['upload_date']= list(map(lambda x : str(datetime.datetime.strptime(x, '%Y-%m-%dT%H:%M:%S.%fZ').date()), df['upload_date']))

  return df.reset_index(drop = True)


## Usage
## df_trailers = pd.read_csv('./trailer_statistics.csv')['trailerId']
## df = create_comments_df(df_trailers)
## df.to_csv('./trailer_comment_threads.cvs', index = False)

def get_replies_from_commentid(commentId):
  req = youtube.comments().list(parentId = commentId, 
                                part = "snippet", 
                                textFormat = "plainText")
  re = req.execute()
  replies = []
  for item in re["items"]:
    replies.append([commentId, item['id'],item['snippet']['textDisplay'], item['snippet']['likeCount'], item['snippet']['publishedAt']])
  
  return replies

def create_replies_df(commentIds):
  df = pd.DataFrame([], columns = ["threadId", "replyId", "reply","likesCount", "publishDate"])
  for commentId in commentIds:
    tmp_df = pd.DataFrame(get_replies_from_commentid(commentId), 
                          columns = ["threadId", "replyId", "reply","likesCount", "publishDate"])
    
    df = pd.concat([df , tmp_df])
  df['publishDate']= list(map(lambda x : str(datetime.datetime.strptime(x, '%Y-%m-%dT%H:%M:%S.%fZ').date()), df['publishDate']))

  return df.reset_index(drop = True)

## Usage
## df_commentThreads = pd.read_csv('./trailer_comment_threads.csv')['threadId']
## df = create_replies_df(df_commentThreads)
## df.to_csv('./trailer_comment_thread_replies.cvs', index = False)

