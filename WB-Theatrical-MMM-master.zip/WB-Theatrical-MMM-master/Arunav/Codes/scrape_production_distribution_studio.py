# -*- coding: utf-8 -*-
"""
Created on Tue May 21 11:14:10 2019

@author: Arunav Saikia
"""

import bs4
import pandas as pd
import json
from requests import get
import re

title = 'tt5140878'
def scrape_production_distribution_studio(title):
    url = 'https://www.imdb.com/title/'+ title + '/companycredits?ref_=tt_dt_co'
    print(title)
    response = get(url)
    soup = bs4.BeautifulSoup(response.text, 'lxml')
    movie_containers = soup.find('div', class_ = 'header')
      
    production_companies = movie_containers.find_all('ul')[0].find_all('li')
    production_company_list = []
    for production_company in production_companies:
        production_company_list.append(production_company.find('a').text)
        
    distribution_companies = movie_containers.find_all('ul')[1].find_all('li')
    distribution_company_list = []
    for distribution_company in distribution_companies:
        distribution_company_list.append(re.sub('[0-9]','',distribution_company.text.replace(' ' ,'').strip()))
        
    for company in production_company_list:
        if 'Warner Bros.' in company or 'New Line Cinema' in company:
            production_company = 'WARNER'
            break
        else:
            production_company = 'OTHER'
    for company in distribution_company_list:
        if 'WarnerBros.()(USA)(theatrical)' in company:
            distribution_company = 'WARNER'
            break
        else:
            distribution_company = 'OTHER'
     
    return [title, production_company, distribution_company]
       
titles = pd.read_csv('./HE_modelingAD_new_v2.2.csv')['IMDB_Title_Code']
df = pd.DataFrame(list(map(scrape_production_distribution_studio, titles)), 
                  columns = ["titleID", "Production_Studio", "Distribution_Studio"])
      
df.to_csv('./title_production_distribution_studio_v2.csv', index = False)