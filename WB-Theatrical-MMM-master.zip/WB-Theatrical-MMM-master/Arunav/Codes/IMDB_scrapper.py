# author : Arunav

import bs4
import pandas as pd
import json
from requests import get
import re

def getIndex(movie_containers, tag):
  for index, container in enumerate(movie_containers):
      try:
        if container.h4.text == tag:
          return index
          break
      except:
        pass
  
def scrape_description(title, response):
  
  soup = bs4.BeautifulSoup(response.text, 'lxml')
  
  try:
    movie_container = soup.find('div', class_ = 'summary_text')
    description = movie_container.text.strip()
  except:
    description = None
    
  return description
  
  
def scrape_rating(title, response):

  soup = bs4.BeautifulSoup(response.text, 'lxml')
  
  try:
    movie_container = soup.find('div', class_ = 'ratingValue')
    rating = movie_container.span.text
  except:
    rating = None
    
  return rating
  
def scrape_monetary_info(title, response):

  soup = bs4.BeautifulSoup(response.text, 'lxml')
  movie_containers = soup.find_all('div', class_ = 'txt-block')
  
  budgetIndex = getIndex(movie_containers, 'Budget:')
  grossUSIndex = getIndex(movie_containers, 'Gross USA:')
  openingWeekendUSIndex = getIndex(movie_containers, 'Opening Weekend USA:')
  runTimeIndex = getIndex(movie_containers, 'Runtime:')
  releaseDateIndex = getIndex(movie_containers, 'Release Date:')
  
  try:
    release_date = movie_containers[releaseDateIndex].text.split(':')[1].split('(USA)')[0].strip()
  except:
    release_date = None
  
  try:
    run_time = movie_containers[runTimeIndex].time.text
  except:
    run_time = None
  
  try:
    budget = ''.join(re.findall(r'\d+', re.search(r'\$(.+?)(\n?\s)', movie_containers[budgetIndex].text).group(1)))
  except:
    budget = None
  
  try:
    gross_US = ''.join(re.findall(r'\d+', re.search(r'\$(.+?)(\n?\s)', movie_containers[grossUSIndex].text).group(1)))
  except:
    gross_US = None
  
  try:
    opening_weekend_US = ''.join(re.findall(r'\d+', re.search(r'\$(.+?)(\n?\s)', movie_containers[openingWeekendUSIndex].text).group(1)))
  except:
    opening_weekend_US = None
  
  return budget, gross_US, opening_weekend_US, run_time, release_date


def scrape_other_info(title, response):

  soup = bs4.BeautifulSoup(response.text, 'html.parser')
  json_data = json.loads(soup.find('script',{"type":"application/ld+json"}).getText())

    
  try:
    MPAA_rating = json_data['contentRating']
  except:
    MPAA_rating = None
  
  try:
    genres = json_data['genre']
  except:
    genres = None
  
  try:
    try:
      directors = [person['name'] for person in json_data['director']]
    except:
      directors = json_data['director']['name']
  except:
    directors  = None

  try:
    try:
      actors = [person['name'] for person in json_data['actor']]
    except:
      actors = json_data['actor']['name']
  except:
    actors  = None

  try:
    name = json_data['name']
  except:
    name  = None

  try:
    try:
      actors_link = [person['url'] for person in json_data['actor']]
    except:
      actors_link = json_data['actor']['url']
  except:
    actors_link = None
    
  try:
    try:
      directors_link = [person['url'] for person in json_data['director']]
    except:
      directors_link = json_data['director']['url']
  except:
    directors_link = None
    
  return MPAA_rating, genres, directors, actors, name, actors_link, directors_link


def scrape_title(title):
  url = 'https://www.imdb.com/title/'+ title + '/'
  print(title)
  response = get(url)
  titleBudget, titleGross_US, titleOpeningWeekendUS, titleRuntime, titleReleaseDate = scrape_monetary_info(title, response)
  title_MPAA_rating, titleGenres, titleDirectors, titleActors, titleName, titleActorsURL, titleDirectorsURL = scrape_other_info(title, response)
  titleDescription = scrape_description(title, response)
  titleRating = scrape_rating(title, response)
  
  return [titleName, title, titleBudget, titleGross_US, titleOpeningWeekendUS, titleRuntime, titleReleaseDate ,title_MPAA_rating, \
          titleGenres, titleDirectors, titleActors, titleActorsURL, titleDirectorsURL, titleDescription, titleRating]


def getDataframe(titles):
  return pd.DataFrame(list(map(scrape_title, titles)), columns = ["Movie Name", "titleID", "Budget", "Gross_US", \
                                                         "OpeningWeekendUS", "Runtime", "US Release Date", "MPAA_rating", \
                                                          "Genre", "Directors", "Actors", "ActorsURL", \
                                                            "DirectorsURL", "Description", "Rating"])
      

### Usage ###

#titles  = ['tt2488496',	'tt1825683',	'tt4154756',	'tt0369610',	'tt0848228',	'tt2527336',	'tt3606756','tt3748528']
##  Download data from
##  https://affineindia.sharepoint.com/:x:/s/WBTheatrical/Ec7V9avYlvpBlru2fjKJpVkB_Na35sRkNPBqHc8zm4i43g?e=9vwoqg
#
## titles = pd.read_csv('./mapped_titles.csv')['ID']
#
#df = getDataframe(titles)
#
#df.to_csv("IMDB_scrapped_data.csv", index = False)
#
#
    
