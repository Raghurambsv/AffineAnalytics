# author : Arunav

import bs4
import pandas as pd
import json
from requests import get
import re
import difflib


def parse_all_franchise():

  url =  'https://www.the-numbers.com/movies/franchises'
  
  response = get(url)
  soup = bs4.BeautifulSoup(response.text, 'lxml')
  franchise_container = soup.find('div')

  all_franchises = franchise_container.table.tbody.find_all('tr')
  all_franchise_list_tmp = [(franchise.td.b.a.text, franchise.td.b.a.get('href'), int(franchise.find_all('td')[1].text))  for franchise in all_franchises]
  all_franchise_list = [franchise for franchise in all_franchise_list_tmp if franchise[2] > 1]
  return all_franchise_list

all_franchises = parse_all_franchise()
len(all_franchises)


def check_tokens(tokens):
  if tokens[-1] == 'The':
    new_tokens = [tokens[-1]]
    new_tokens.extend(tokens[:-1])
    return ' '.join(new_tokens)
  else:
    return ' '.join(tokens)

def clean_movie_name(text):
  cleaned_tmp = text.replace('#tab=summary', '').replace('/movie/','')
  cleaned_tokens = cleaned_tmp.split('-')
  cleaned_name = check_tokens(cleaned_tokens)
  return cleaned_name


def get_all_movies_in_franchise(franchise):
  url =  'https://www.the-numbers.com/' + franchise +'#tab=summary'
  
  response = get(url)

  soup = bs4.BeautifulSoup(response.text, 'lxml')

  franchise_container = soup.find('div')

  try:
    all_movies = franchise_container.table.find_all('tr')[1:-3]

    all_movies_list = [(clean_movie_name(movie.find('td' and 'b').a.get('href')), movie.find('td').text.replace('\xa0',' ')) \
                       for movie in all_movies]
  
    return all_movies_list
  except:
    return [(None, None)]

def getIMDBtitle(movie_name):
  try:
    print(movie_name)
    CleanedMovieName = movie_name.replace(' ','+')
    url = 'https://www.imdb.com/find?ref_=nv_sr_fn&q=' + CleanedMovieName + '&s=tt'
    response = get(url)
    soup = bs4.BeautifulSoup(response.text, 'lxml')

    MovieChoice = soup.find('td', class_= 'result_text')
    TitleURL = MovieChoice.a.get('href')
    TitleName = MovieChoice.a.text

    TitleID = re.search('/(tt[0-9]{7})/', TitleURL).group(1)
    similarity_score = difflib.SequenceMatcher(None,movie_name,TitleName).ratio()*100

    return [movie_name, TitleID, TitleName, similarity_score]
  except:
    return [movie_name , None, None, None]
    print(movie_name+ ' not mapped')

init_df = pd.DataFrame([], columns = ['movie', 'release date', 'franchise'])

i = 1
for franchise in all_franchises:
  print(franchise, str(i)+ "/" + str(len(all_franchises)))
  all_movies = get_all_movies_in_franchise(franchise[1])
  tmp_df = pd.DataFrame(all_movies, columns = ['movie', 'release date'])
  tmp_df['franchise'] = franchise[0]
  tmp_df['count of movies in the franchise'] = int(franchise[2])
  init_df = pd.concat([init_df, tmp_df])
  i += 1
  
final_df = init_df.reset_index(drop = True)

final_df.to_csv('franchise_data.csv', index = False)

movie_names = pd.read_csv('./franchise_data.csv')['movie'].unique()

df = pd.DataFrame(list(map(getIMDBtitle, movie_names)), columns = ['movie_name', 'IMDB title', 'IMDB name', 'confidence'])

df.to_csv('franchise_data_names.csv', index = False)

df1 = pd.read_csv('./franchise_data.csv')
df2 = pd.read_csv('./franchise_data_names.csv')

df3 = df1.merge(df2, left_on = 'movie', right_on = 'movie_name').drop(['movie_name'], axis = 1)
df3.to_csv('./franchise_data_mapped_v1.csv', index = False)
