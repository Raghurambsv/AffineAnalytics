# author : Arunav

import bs4
from requests import get
import pandas as pd
import urllib.request

def get_title_poster(title):
    print(title)
    url = 'https://www.imdb.com/title/'+ title + '/'
    response = get(url)
    soup = bs4.BeautifulSoup(response.text, 'lxml')
    try:
        img_url = soup.find('div', class_ =  'poster').a.img.get('src')
        urllib.request.urlretrieve(img_url,  title + '.jpg')
    except:
        pass


# Data can be dowloaded from
# https://affineindia.sharepoint.com/:x:/s/WBTheatrical/Ec7V9avYlvpBlru2fjKJpVkB_Na35sRkNPBqHc8zm4i43g?e=6fvWZG

titles = pd.read_csv('./mapped_titles.csv')['ID']
i = 1
total_titles = len(titles)

for title in titles:
    print(str(i)+"/"+str(total_titles))
    get_title_poster(title)
    i+=1
