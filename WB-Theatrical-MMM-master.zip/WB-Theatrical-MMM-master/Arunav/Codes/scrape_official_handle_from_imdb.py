# -*- coding: utf-8 -*-
"""
Created on Thu Jun 27 13:09:33 2019

@author: Arunav Saikia
"""

import bs4
import pandas as pd
import json
from requests import get
import re

all_titles = pd.read_csv('./official_sites.csv')['IMDB Title Code']

tmp = pd.DataFrame([], columns = ['site_name','link','title'])

def get_official_sites(title):
    url = 'https://www.imdb.com/title/'+ title + '/externalsites?ref_=tt_ql_rel_2'
    print(title)
    response = get(url)
    soup = bs4.BeautifulSoup(response.text, 'lxml')
    movie_containers = soup.find('div', class_ = 'header')
    
    if movie_containers.find_all('h4')[0].text.strip() == 'Official Sites':
        official_sites = movie_containers.find_all('ul')[0].find_all('li')
        site_name = []
        link = []
        for site in official_sites:
            site_name.append(site.find('a').text)
            link.append(site.a.get('href'))
            
        df = pd.DataFrame([site_name,link]).transpose()
        df.columns = ['site_name','link']
        df['title'] = title
    else:
        df = pd.DataFrame([[None, None,title]], 
                          columns = ['site_name','link','title'])
    return df

for title in all_titles:
    title_df = get_official_sites(title)
    tmp = pd.concat([tmp,title_df], axis = 0)


all_handles = []
for link in tmp['link']:
    try:
        response = get('https://www.imdb.com'+link)
        soup = bs4.BeautifulSoup(response.text, 'lxml') 
        handle = soup.find('link').get('href')
        print(handle)
        if 'facebook' in handle:
            all_handles.append(handle)
        else:
            all_handles.append(None)
    except:
        all_handles.append(None)
tmp['handle'] = all_handles
tmp.to_csv('./official_sites.csv',index = False)