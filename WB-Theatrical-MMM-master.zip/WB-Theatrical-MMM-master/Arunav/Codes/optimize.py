# -*- coding: utf-8 -*-
"""
Created on Mon Apr  1 12:27:55 2019

@author: Arunav Saikia
"""

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.optimize import Bounds


Spend_HE = 0.0554
Window_HE  = 0.0223
YT_HE = 0.004
Runtime_HE = 0.00344
intercept_HE = 0.044

Spend_BO = 0.554
Window_BO  = 0.223
YT_BO = 0.04
Runtime_BO = 0.0344
intercept_BO = 0.032

e = 2.718

HE_data = pd.read_excel('./mock_data.xlsx', sheet_name = 1)
BO_data = pd.read_excel('./mock_data.xlsx', sheet_name = 0)

l_HE = len(HE_data)
l_BO = len(BO_data)

if l_HE != l_BO:
    print('Both ADs do not have the same # of movies')

HE_cons = np.array(HE_data['Runtime'].apply(lambda x: x**Runtime_HE)) \
                *np.array(HE_data['YT view'].apply(lambda x: x**YT_HE)) *\
                    np.array([e**intercept_HE] * l_HE)
                        

BO_cons = np.array(BO_data['Runtime'].apply(lambda x: x**Runtime_BO)) \
                *np.array(BO_data['YT view'].apply(lambda x: x**YT_BO)) *\
                    np.array([e**intercept_BO] * l_BO)


def raise_to_e(x):
    num = 2718**x
    den = 1000**x
    
    l = len(str(den))-1
    result = str(num)[:-l]
    
    return result

def objective_function(x, sign = -1.0):
    l = len(x)
    
    a = x[np.arange(0, l-2, 3)]
    b = x[np.arange(1, l-1, 3)]
    c = x[np.arange(2, l, 3)]
        
    return sign*(sum((e**((a*np.array([Spend_HE]*l_HE))+(b*np.array([Window_HE]*l_HE))) * HE_cons)+
                 (e**((c*np.array([Spend_BO]*l_BO))+(b*np.array([Window_BO]*l_BO))) * BO_cons)

def obj_func_derivative(x, sign = -1.0, )

spend_limit = 40000000
bounds = Bounds([0, 60, 0], [inf, 120, inf])

cons = ({'type': 'ineq',
    'fun' : lambda x: sum(x*np.array([-1,0,-1]*l_HE))+spend_limit,
    'jac' : lambda x: np.array([-1,0,-1]*l_HE)})

res = minimize(objective_function,np.array([100000,70,100000]*l_HE) , jac=obj_func_derivative,
    constraints=cons, method='SLSQP', options={'disp': True})
