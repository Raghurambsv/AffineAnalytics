# author : Arunav

from apiclient.discovery import build
import datetime
import pandas as pd

amit = "AIzaSyDAGQM_-zO3ghrLKiw6joPPT-lgw9hGXPY"
sayantan =  "AIzaSyBgu0Y62BVKeVHDpjD6WuUnVohTY4CfwIQ"
arunav = "AIzaSyCfGXkXLbSUIXoTNtBweZIF13O3GyEElQU"
sandeep = "AIzaSyCDXnVdmjwZoYnyRMECtcMIts64JSThaxw"
akash = "AIzaSyCE6PN0KoJYB_XFTej5lzEZAfeAMg975S0"
sarthak = "AIzaSyBx5TP3Wc0IFgHk8ukBE0mkFirbzqq-YKg"
priyankar = "AIzaSyAjdNo3t1jWb7t8gUYKpPaBihxmzEoTIaU"
rohan = "AIzaSyBSAuXRLH8e1qqK_tt0goAOOt_7Req9qdk"
abhinav = "AIzaSyAaxwinuHgym2PMZg-WBgg3zq0FcOyKVQI"
lokeshwar = "AIzaSyAFXDq-Wj9pBgL93K_Qyo9PoT2QlByAfuc"
rahul = "AIzaSyDi4PdOV9-SHTgWpROzgCcF9Q06jkDXvK0"


def get_official_video(movie_name, key):
  """
  Function to get the official trailer id from the name of the movie
  Args:
    movie_name: The name of the movie as a string
    key: API developer key to call the API

  Returns:
    videoId: The youtube id of the trailer
    title: The title of the trailer as seen on youtube
    upload_date: The date on which the trailer has been uploaded
  """
  print(movie_name)
  youtube = build('youtube', 'v3' , developerKey = key)
  req = youtube.search().list(q = movie_name + "official trailer", 
                              part= "snippet", 
                              type = "videos", 
                              channelId = "UCjmJDM5pRKbUlVIzDYYWb6g",
                              order = "relevance" )
  re = req.execute()
  try:
    videoId = re['items'][0]['id']['videoId']
    upload_date_tmp = re['items'][0]['snippet']['publishedAt']
    title = re['items'][0]['snippet']['title']
    upload_date = str(datetime.datetime.strptime(upload_date_tmp, '%Y-%m-%dT%H:%M:%S.%fZ').date())

  except:
    videoId = None
    title = None
    upload_date = None

  return [movie_name, videoId, title, upload_date]
  

movie_names = pd.read_excel('./Warner Bros - Home Ent. AD.xlsx', sheet_name = 2)['IMDB_Title_Name']

api_key = [arunav, amit,sandeep]
key = sayantan


tmp = []
for movie in movie_names:
  try:
    tmp.append(get_official_video(movie, key))
  except:
    key = api_key.pop()
    tmp.append(get_official_video(movie, key))
    
df_trailer = pd.DataFrame(tmp, columns = ["movie_name", "videoId", "videoTitle", "videoUploadDate"])
df_trailer.to_csv('./movie_trailer.csv', index = False)



def get_video_statistics(videoId, key):
  """
  Function to get the statistics of a trailer
  Args:
    videoId: The youtube id of the trailer
    key: API developer key to call the API

  Returns:
    views: # of views the trailer has
    likes: # of likes the trailer has
    dislikes: # of dislikes the trailer has
    comments: # of comments the trailer has
  """
  print(videoId)
  youtube = build('youtube', 'v3' , developerKey = key)

  req = youtube.videos().list(id = videoId, 
                              part ="statistics")
  re = req.execute()
  
  try:
    views = re['items'][0]['statistics']['viewCount']
    likes = re['items'][0]['statistics']['likeCount']
    dislikes = re['items'][0]['statistics']['dislikeCount']
    comments = re['items'][0]['statistics']['commentCount']
  
  except:
    views, likes, dislikes, comments = None
  
  return [videoId, int(views), int(likes), int(dislikes), int(comments)]

api_key = [sarthak, priyankar,rohan]
key = akash


tmp = []
for videoId in df_trailer['videoId'].dropna():
  try:
    tmp.append(get_video_statistics(videoId, key))
  except:
    key = api_key.pop()
    tmp.append(get_video_statistics(videoId, key))
    
video_stats = pd.DataFrame(tmp,columns = ["trailerId", "views_count", "likes_count", 
                                          "dislikes_count", "comments_count"])
video_stats.to_csv('./trailer_stats.csv', index = False)


df_trailer_stats = df_trailer.merge(video_stats, left_on = 'videoId', right_on = 'trailerId').\
                                drop(['trailerId'], axis = 1)
  

df_trailer_stats.to_csv('./movie_trailer_statistics.csv', index = False)

## NOTE ##
# After the merge their might some discrepencies which might need to be manually corrected
