#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug  7 15:46:47 2018

@author: affine
"""
import pandas as pd
import itertools


## To create Index for quater years
def QuarterIndex():
    ##Creating a list of seasons in an year
    years =[ str(i) for i in list(range(2005,2022))]
    ##Naming the 4 seasons
    Quarters = ["Q1", "Q2", "Q3", "Q4"]    
    concat_both = list(itertools.product(years,Quarters))
    QuarterYear =  list(map(lambda x: x[1]+x[0], concat_both)) 
    QuarterYear_index =   list(range(1,len(QuarterYear)+1))
    
    temp_keys = ['QuarterYr','QuarterNbr']
    temp_vals = [QuarterYear,QuarterYear_index]
    temp_dict = dict(zip(temp_keys,temp_vals))
    ##Creating Year-Season table that will be used in main script
    year_quarter_df = pd.DataFrame(temp_dict)
    return(year_quarter_df)


# To create Base AD Structure
def CreateBaseAD(df_raw1,CurrentQuarter):
    w, h = 8, 70;
    Matrix = [[0 for x in range(w)] for y in range(h)]
    year_quarter_df = QuarterIndex()
    FourSeasonIndex = int(year_quarter_df[year_quarter_df['QuarterYr'] ==CurrentQuarter]['QuarterNbr'].values )+5   
    for l in range(1,FourSeasonIndex-7):  
        for  j in range(1,w+1):
            Matrix[l-1][j-1] = l+j-1
    cols = ['QuarterNbr1','QuarterNbr2','QuarterNbr3','QuarterNbr4',
    'QuarterNbr5','QuarterNbr6','QuarterNbr7','QuarterNbr8']
    x = pd.DataFrame(Matrix,columns = cols)
    Season =year_quarter_df
    y =  pd.merge(x, Season,  left_on='QuarterNbr1', right_on = 'QuarterNbr')
    y = y.rename(index=str, columns={"QuarterYr": "Quarter1"})  
    y = y.drop(['QuarterNbr'], axis=1)
    
    
    y =  pd.merge(y, Season,  left_on='QuarterNbr2', right_on = 'QuarterNbr')
    y = y.rename(index=str, columns={"QuarterYr": "Quarter2"})  
    y = y.drop(['QuarterNbr'], axis=1)
    
    y =  pd.merge(y, Season,  left_on='QuarterNbr3', right_on = 'QuarterNbr')
    y = y.rename(index=str, columns={"QuarterYr": "Quarter3"})  
    y = y.drop(['QuarterNbr'], axis=1)
    
    y =  pd.merge(y, Season,  left_on='QuarterNbr4', right_on = 'QuarterNbr')
    y = y.rename(index=str, columns={"QuarterYr": "Quarter4"})  
    y = y.drop(['QuarterNbr'], axis=1)
    
    y =  pd.merge(y, Season,  left_on='QuarterNbr5', right_on = 'QuarterNbr')
    y = y.rename(index=str, columns={"QuarterYr": "NextQuarter1"})  
    y = y.drop(['QuarterNbr'], axis=1)
    
    y =  pd.merge(y, Season,  left_on='QuarterNbr6', right_on = 'QuarterNbr')
    y = y.rename(index=str, columns={"QuarterYr": "NextQuarter2"})  
    y = y.drop(['QuarterNbr'], axis=1)
    
    y =  pd.merge(y, Season,  left_on='QuarterNbr7', right_on = 'QuarterNbr')
    y = y.rename(index=str, columns={"QuarterYr": "NextQuarter3"})  
    y = y.drop(['QuarterNbr'], axis=1)
    
    y =  pd.merge(y, Season,  left_on='QuarterNbr8', right_on = 'QuarterNbr')
    y = y.rename(index=str, columns={"QuarterYr": "NextQuarter4"})  
    y = y.drop(['QuarterNbr'], axis=1)
    
    
    z =  y.loc[y.Quarter4.str[0:2].isin([CurrentQuarter[0:2]])]
    z['QuarterGrp'] = sorted(list(range(0,len(z))), reverse=True)
    
    z = z.drop(cols, axis=1)
    z['key'] = 'key'
    
    
    key_comp = 'Company'
    
    val_comp = df_raw1
    comp_data = pd.DataFrame(val_comp,columns= [key_comp])
    comp_data['key'] ='key' 
    #Cross join companies with quater-year
    Base_AD = pd.merge(comp_data,z,how = 'outer' ).drop(['key'],axis = 1)
    return(Base_AD)


def get_quarteryr(samp_date):    
    month = int(samp_date.split('-')[1])
    if month in range(1,4):
        quat = 'Q1'
    elif month in range(4,7):
        quat = 'Q2'
    elif month in range(7,10):
        quat = 'Q3'
    else:
        quat = 'Q4'
    year = str(samp_date.split('-')[0])
    quarter_yr = quat+year
    return(quarter_yr)


#df_raw1 = pd.read_csv('/media/affine/New Volume/Chubb/20180807/cals_comp_date.csv')
#CurrentQuarter  = 'Q32018'
#Base_AD_check = CreateBaseAD(df_raw1,CurrentQuarter)

#pd.DataFrame(Base_AD).to_csv("Base_AD.csv")
