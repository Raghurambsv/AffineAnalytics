#==============================================================================
## Import required Packages
import matplotlib.pyplot as plt
import numpy as np
import sklearn.cross_validation as cv
import sklearn.metrics as metrics
import pandas as pd
import os
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import log_loss, accuracy_score
import sklearn.grid_search as gs
import datetime
import re
import pandasql as ps
import xgboost as xgb
import pickle


#=============================== Section1 ==================================
                ## RF_PCA() function for Variable Reduction ##
#===========================================================================

def RF_PCA(AD_new,req_flags,variance_cutoff,importance_cutoff,feature_flag,dv2,outof_time):
    AD_new["published_date_time"] = AD_new["published_date_time"].apply(pd.to_datetime)
    AD_new["published_date_time"] = AD_new["published_date_time"].apply(pd.Timestamp.date)
    AD_new['year'] = pd.DatetimeIndex(AD_new['published_date_time']).year
    AD_new['month'] = pd.DatetimeIndex(AD_new['published_date_time']).month

    all_cols = list(AD_new.columns)
    feature_flag.columns
    #set(feature_flag['Map'])

    ## Flag type variables
    flag_features  = list(feature_flag[feature_flag['Map'] == 'F']['Variable'])
    ## Variables for which PCA is not required
    As_is_features = list(feature_flag[feature_flag['Map'] == 'As_is']['Variable'])

    try:
        AD_new.drop('Unnamed: 0', axis=1, inplace=True)
    except ValueError:
        pass

    ## Split
    non_numeric = ['Company', 'published_date_time', 'Sector','year','month']
    ## Remove
    dv = ['is_cals_90',
     'is_cals_180',
     'is_cals_270',
     'is_cals_90_180',
     'is_cals_180_270',
     'is_cals_270_360',
     'is_cals_360']
    rem_cols = dv + non_numeric
    # import datetime
    AD_new["published_date_time"] = AD_new["published_date_time"].apply(pd.to_datetime)
    AD_new["published_date_time"] = AD_new["published_date_time"].apply(pd.Timestamp.date)

    AD_test = AD_new[(AD_new["published_date_time"].apply(pd.to_datetime) >= outof_time)]

    AD_Train_master = AD_new[(AD_new["published_date_time"].apply(pd.to_datetime) < outof_time)]

    pca_ad = AD_new[['Company', 'published_date_time', 'Sector']]

    # These features are not being used in model
    rm_cols_q4 = list(filter(lambda x: re.findall('4Q', x), all_cols))
    rm_cols_q2 = list(filter(lambda x: re.findall('2Q', x), all_cols))
    rm_cols_q3 = list(filter(lambda x: re.findall('3Q', x), all_cols))
    rem_cols_stan = list(filter(lambda x: re.findall('standard', x), all_cols))
    rem_cols_ans =  list(filter(lambda x: re.findall('Answers',x),all_cols))
    rem_cols_q = rm_cols_q4+rm_cols_q2+rm_cols_q3+rem_cols_stan+rem_cols_ans

    ## select variable dependent variable based on model
    AD_Train = AD_Train_master.drop(rem_cols_q, axis=1)


    for flag in req_flags:
        readability_features = list(feature_flag[feature_flag['Map'] == flag]['Variable'])
        readability_features = list(set(readability_features) - {'1Q_Back_text_standard_Combined' ,
                                                                '1Q_Back_count_QA_x',
                                                                '1Q_Back_count_QA_y',
                                                                 '1Q_Back_text_standard_Preamble',
                                                                 '1Q_Back_text_standard_QA'})



        # feature selection using rf feature_importance

        AD_Train = AD_Train_master[non_numeric + list(readability_features) + dv]
        pred = AD_Train
        pred = pred.drop(rem_cols, axis=1)

        target = AD_Train[dv2]
        SEED = 777
        ## RF to get varaible importance

        # Split train and validation data
        x_train, x_test, y_train, y_test = cv.train_test_split(pred, target, test_size=0.10, random_state=0)

        # nitialize random forest
        clf = RandomForestClassifier(bootstrap=True, class_weight={0: 1, 1: 10}, criterion='gini',
                                     max_depth=4, max_features='auto', max_leaf_nodes=None,
                                     min_samples_leaf=1, min_samples_split=0.2,
                                     n_estimators=200, n_jobs=1,
                                     oob_score=True, random_state=0, warm_start=False)

        clf.fit(x_train, y_train)

        # Get Varaible impotance from RF
        importances = clf.feature_importances_

        importances = pd.DataFrame(importances, index=x_train.columns,
                                   columns=["Importance"])
        importances.reset_index(level=0, inplace=True)
        importances = importances.rename(columns={'index': 'Variables'})
        imp_var1 = importances.sort_values(by=['Importance'], ascending=False)
        imp_var1['cum_sum'] = imp_var1.Importance.cumsum()
        # Select top variables whose cumulative sum  of impotance reaches 90% of
        imp_col = list(imp_var1[imp_var1['cum_sum'] < importance_cutoff]['Variables'])

        try:
            os.mkdir(os.path.join(data_path, 'pca/20180807'))
        except:
            pass
        #imp_var1.to_csv('pca/20180807/' + 'rf_varimp_newcals' + flag + '.csv')



        ## PCA on importannt features based on RF importance
        data_pca = AD_new[imp_col].fillna(0)
        # scale the data and fill nan with zero
        data_pca_s = data_pca / np.std(data_pca, 0)
        data_pca_s = data_pca_s.fillna(0)

        ## Maximum number of compnents from pCA is equal to number features passed into PCA
        max_components= len(imp_col)
        ## Consider the minimum number of compnenets whch can explain 80% of total variance
        for n_components in range(1, max_components+1):
            pca = PCA()
            pca.set_params(n_components=n_components)
            pca.fit(data_pca_s)
            variance_explained = sum(pca.explained_variance_ratio_)

            if variance_explained >= variance_cutoff:
                break
        if n_components == max_components + 1:
            raise Exception('Cannot find %d components that explains %f variance!' % (n_components, max_components))
        print('Aggregated Explained Variance', 100 * round(variance_explained, 2))
        print('*' * 65)
        print('Explained Variance per  PC:')
        print('*' * 65)
        print(pca.explained_variance_ratio_)
        print('*' * 65)

        ## Store the components from PCA and rename the columns
        data_pca_s_comp = pd.DataFrame(pca.transform(data_pca_s))
        new_col = [flag + '_' + str(i) for i in list(range(0, pca.n_components))]
        data_pca_s_comp.columns = new_col

        ## Store the Eigenvectors from PCA and rename the columns

        data_pca_s_eigen = pd.DataFrame(pca.components_)
        data_pca_s_eigen.columns = imp_col

        ## JOin PCA components from each set of variables
        pca_ad.reset_index(inplace=True, drop=True)
        data_pca_s_comp.reset_index(inplace=True, drop=True)
        pca_ad = pd.concat([pca_ad, data_pca_s_comp], axis=1)

    ## Join remanining IV and all Dependent variables
    pca_ad1 = pd.merge(pca_ad,
                       AD_new[['Company', 'published_date_time'] + flag_features + As_is_features + [dv2]],
                       how='left', left_on=['Company', 'published_date_time'],
                       right_on=['Company', 'published_date_time'])
    #data_pca_s_comp.to_csv('pca/20180807/90_180_pca_data' + flag + '.csv')

    #data_pca_s_eigen.to_csv('pca/20180807/90_180_pca_EIGEN' + flag + '.csv')

    pca_ad1.drop(['1Q_Back_Sector_Others'], axis=1, inplace=True)

    #pca_ad1.to_csv('PCA_AD_'+dv2+'.csv', index=False)
    return(pca_ad1,AD_Train_master,AD_test)

#=============================== Section2 ==================================
                            ##  Grid Search ##
#==============================================================================
def XGB_parameter(X_train,y_train):

    param_test1 = {'max_depth':list(range(5,30,3)),
    'min_child_weight':list(range(1,10,2)),
    'n_estimators':list(range(300,1000,300))}
    gsearch1 = gs.GridSearchCV(estimator = xgb.XGBClassifier(
                               objective='multi:softprob',
                               eval_metric='mlogloss',
                               num_class = 2,nthread=1),
                               param_grid = param_test1,cv=5,
                               scoring = 'roc_auc',verbose =25)
    gsearch1.fit(X_train,y_train)
    gsearch1.grid_scores_, gsearch1.best_params_, gsearch1.best_score_
    depth=gsearch1.best_params_['max_depth']
    child_weight=gsearch1.best_params_['min_child_weight']
    trees =gsearch1.best_params_['n_estimators']



    param_test2 = {'gamma':[i/10.0 for i in range(0,6)]}
    gsearch2 = gs.GridSearchCV(estimator = xgb.XGBClassifier(
                            max_depth=depth,
                            min_child_weight=child_weight,
                            n_estimators = trees,
                            objective='multi:softprob',
                            eval_metric='mlogloss',
                            num_class = 2,nthread=1),
                            param_grid = param_test2,cv=5,
                            scoring = 'roc_auc', verbose = 25)
    gsearch2.fit(X_train,y_train)
    gsearch2.grid_scores_, gsearch2.best_params_, gsearch2.best_score_
    g= gsearch2.best_params_['gamma']


    param_test3 = {'subsample':[i/10.0 for i in range(1,9)],'colsample_bytree':[i/10.0 for i in range(1,9)]}

    gsearch3 = gs.GridSearchCV(estimator = xgb.XGBClassifier(
                                max_depth=depth,
                                min_child_weight=child_weight,
                                gamma=g,
                                n_estimators = trees,
                                objective='multi:softprob',
                                eval_metric='mlogloss',
                                num_class = 2,nthread=1),
                                param_grid = param_test3,cv=5,
                                scoring = 'roc_auc',verbose = 25)
    gsearch3.fit(X_train,y_train)
    gsearch3.grid_scores_, gsearch3.best_params_, gsearch3.best_score_
    subsample=gsearch3.best_params_['subsample']
    colsample=gsearch3.best_params_['colsample_bytree']


    param_test4 = {'reg_alpha':[i/10.0 for i in range(1,9)]}
    gsearch4 = gs.GridSearchCV(estimator = xgb.XGBClassifier(
                                 max_depth=depth,
                                 min_child_weight=child_weight,
                                 gamma=g,
                                 colsample_bytree=colsample,
                                 subsample=subsample,
                                 n_estimators = trees,
                                 objective='multi:softprob',
                                 eval_metric='mlogloss',
                                 num_class = 2,nthread=16),
                                 param_grid = param_test4,cv=5,
                                 scoring = 'roc_auc',verbose = 25)
    gsearch4.fit(X_train,y_train)
    gsearch4.grid_scores_, gsearch4.best_params_, gsearch4.best_score_
    alpha=gsearch4.best_params_['reg_alpha']



    param_test5 = {'learning_rate' : [0.0001, 0.001, 0.01, 0.1, 0.2, 0.3]}
    gsearch5 = gs.GridSearchCV(estimator = xgb.XGBClassifier(
                                 max_depth=depth,
                                 min_child_weight=child_weight,
                                 gamma=g,
                                 colsample_bytree=colsample,
                                 subsample=subsample,
                                 reg_alpha=alpha,
                                 n_estimators = trees,
                                 objective='multi:softprob',
                                 eval_metric='mlogloss',
                                 num_class = 2,nthread=16),
                                 param_grid = param_test5,cv=5,scoring = 'roc_auc')

    gsearch5.fit(X_train,y_train)

    gsearch5.grid_scores_, gsearch5.best_params_, gsearch5.best_score_

    learn_rate = gsearch5.best_params_['learning_rate']
    return (depth,child_weight,trees,g,subsample,colsample,alpha,learn_rate)



## Read AD and create AD from importanve features and PCA
from model_config import *
AD_Raw = pd.read_csv(AD_filepath)
## Read variables and their respective groups (to filter for required variables from AD)
feature_flag = pd.read_csv(IV_Groups_path)

#=============================== Section3 ==================================
                            ##  XGBoost code ##
#==============================================================================

try:
    os.mkdir(op_path)
except:
    pass

from itertools import chain
all_sectors = set(list(chain.from_iterable(sector_dict.values())))
sector_dict['Remaining_Sector'].extend(list(set(AD_Raw['Sector'])-all_sectors))
for key in sector_dict:
    ## Flter for given sector
    
    AD_new_sec = AD_Raw[AD_Raw['Sector'].isin(sector_dict[key])]

    AD_new,AD_Train_master,AD_test = RF_PCA(AD_new_sec,req_groups,variance_cutoff,importance_cutoff,feature_flag,dv2,outof_time)

    ## Date conversion
    AD_new["published_date_time"] = AD_new["published_date_time"].apply(pd.to_datetime)
    AD_new["published_date_time"] = AD_new["published_date_time"].apply(pd.Timestamp.date)
    AD_new['year'] = pd.DatetimeIndex(AD_new['published_date_time']).year
    AD_new['month'] = pd.DatetimeIndex(AD_new['published_date_time']).month
    
    
    ## Split data into training and testing
    AD_oosamp = AD_new[(AD_new["published_date_time"].apply(pd.to_datetime) >= outof_time)]
    AD_Train_master = AD_new[(AD_new["published_date_time"].apply(pd.to_datetime) < outof_time)]
    AD_train_test = AD_Train_master
    
    ## Remove the columns from AD. These are my dependent variable for diff time periods
    dv = [dv2]
    
    ## Create list of non-numeric coumns
    non_numeric = ['Company','published_date_time','Sector']
    
    ## Combine the columns whihc has to be removed
    rem_cols = dv+non_numeric
    
    ## Create dataframe with predictors/training features
    pred = AD_train_test
    
    ## Create dataframe with target variable
    target = AD_train_test[dv2]
    
    ## Split data for training and testing
    SEED = 777
    x_train, x_test, y_train, y_test = cv.train_test_split(pred, target, test_size=0.10, random_state=0)
    x_train_backup = x_train
    x_test_backup = x_test
    pred_backup = pred
    
    ## Drop categorical and dependent variables stored in rem_col variable
    x_train= x_train.drop(rem_cols,axis = 1)
    x_test = x_test.drop(rem_cols,axis = 1)
    pred = pred.drop(rem_cols,axis = 1)
    
    ## XGB Classifier
    if not run_grid_search:
        
        best_params = xgb.XGBClassifier(**XGB_parameters_fixed, **params[key])
        
    else:
        depth,child_weight,trees,g,subsample,colsample,alpha,learn_rate = XGB_parameter(X_train, y_train)
        best_params = xgb.XGBClassifier(base_score=0.5,
        booster='gbtree',
        child_weight=child_weight,
        colsample_bylevel=1,
        colsample_bytree=colsample,
        subsample=subsample,
        eta=learn_rate,
        eval_metric='mlogloss',
        gamma=g,
        reg_alpha=alpha,
        max_delta_step=1,
        max_depth=depth,
        min_child_weight=1,
        n_estimators=trees,
        n_jobs=1,
        nthread=16,
        num_class=2,
        objective='multi:softprob',
        random_state=0,
        reg_lambda=1,
        scale_pos_weight=1,
        seed=0,
        silent=1)
    
    ## Run the xgb model as per best parameters
    best_params.fit(x_train, y_train,verbose = True)
    
    ## Variable Imporatnce
    importances = best_params.feature_importances_
    imp_var = pd.DataFrame({'importance':importances})
    imp_var['Variables'] = x_train.columns
    imp_var1 = imp_var.sort_values(by=['importance'],ascending = False )
    imp_var1['cum_sum'] = imp_var1.importance.cumsum()
    
    
    ## Print training and validation error
    print('Training Score',best_params.score(x_train,y_train))
    print('Training Error',1 - best_params.score(x_train,y_train))
    y_train_p = best_params.predict_proba(x_train)
    print('Overall Training Log-Loss Error', metrics.log_loss(y_train,y_train_p))
    print('Test Score',best_params.score(x_test,y_test))
    print('Test Error',1 - best_params.score(x_test,y_test))
    y_test_p = best_params.predict_proba(x_test)
    print('Overall Test Log-Loss Error', metrics.log_loss(y_test,y_test_p))
    
    
    ## Create dataframe of actuals and predicted for test data
    y_test_p1_xgb = pd.DataFrame(y_test_p)
    y_test_p1_xgb['actuals'] = list(y_test)
    x_test_backup.reset_index(inplace = True,drop=True)
    y_test_p1_xgb = pd.concat([x_test_backup[['Company','published_date_time','Sector']],y_test_p1_xgb],axis = 1)
    
    ## Create dataframe of actuals and predicted for Training data
    y_train_p1_xgb= pd.DataFrame(y_train_p)
    y_train_p1_xgb['actuals'] = list(y_train)
    x_train_backup.reset_index(inplace = True,drop=True)
    y_train_p1_xgb = pd.concat([x_train_backup[['Company','published_date_time','Sector']],y_train_p1_xgb],axis = 1)
    
    ## Create dataframe of actuals and predicted for Out of Time
    y_outsample = AD_oosamp[dv2]
    y_outsample_p = best_params.predict_proba(AD_oosamp[x_train.columns])
    y_outsample_p1_xgb= pd.DataFrame(y_outsample_p)
    y_outsample_p1_xgb['actuals'] = list(y_outsample)
    AD_oosamp.reset_index(inplace = True,drop=True)
    y_outsample_p1_xgb = pd.concat([AD_oosamp[['Company','published_date_time','Sector']],y_outsample_p1_xgb],axis = 1)
    
    ## Function to create KS table
    def create_ks_table(data,Score_Column,Target):
        #deciles = pd.qcut(data[Score_Column], 10)
        data['score_dec_bucket'] = pd.qcut(data[Score_Column], 10)
        df = data.groupby('score_dec_bucket',as_index=True).agg({Target: ['sum','count']})
        df.columns = ['_'.join(col).strip() for col in df.columns.values]
        df['cum_sum_'+Target] = np.cumsum(df['Target_sum'])
        df['cum_sum_'+Target+'Perc'] = df['cum_sum_'+Target]/df['Target_sum'].sum()
        df = df.reset_index()
        x = reversed(np.cumsum([i for i in reversed(df['Target_sum'])]))
        df['reversed_cumsum'] = [i for i in x]
        deciles = df['score_dec_bucket'].values
        deciles = list(map(lambda x: eval(x.replace('(', '[')), deciles))
                                               
        buckets = np.array([0, deciles[-3][0],  deciles[-1][0], 1])
    
        return df, buckets
    
    
    def find_risk(probability, buckets):
        return {0: 'very low', 1:'low', 2: 'medium', 3:'high'}[(buckets >= probability).argmax()]
    
    
    ## KS Table Outsample Dataset
    y_outsample_p1_xgb_1 = y_outsample_p1_xgb[[1,'actuals']].rename(columns = {1: 'Score', 'actuals':'Target'})
    ks_table_outsample, _ = create_ks_table(y_outsample_p1_xgb_1,'Score','Target')
    
    ## KS Table Test Dataset
    y_test_p1_xgb_1 = y_test_p1_xgb[[1,'actuals']].rename(columns = {1: 'Score', 'actuals':'Target'})
    ks_table_test, _ = create_ks_table(y_test_p1_xgb_1,'Score','Target')
    
    ## KS Table Train Dataset
    y_train_p1_xgb_1 = y_train_p1_xgb[[1,'actuals']].rename(columns = {1: 'Score', 'actuals':'Target'})
    ks_table_train, buckets = create_ks_table(y_train_p1_xgb_1,'Score','Target')
    
    # write buckets and model in storage:
    pickle.dump(buckets, open(op_bucket_filepath.replace('.pic', '_%s.pic' % (key)), 'wb'))
    pickle.dump(best_params, open(op_model_filepath.replace('.pic', '_%s.pic' % (key)), 'wb'))
    
    #print('test risk: %s' % (find_risk(0.06, buckets)))
    
    y_outsample_p1_xgb_1['Risk_Bucket'] = y_outsample_p1_xgb_1['Score'].apply(lambda x: find_risk(x,buckets))
    y_test_p1_xgb_1['Risk_Bucket'] = y_test_p1_xgb_1['Score'].apply(lambda x: find_risk(x,buckets))
    y_train_p1_xgb_1['Risk_Bucket'] = y_train_p1_xgb_1['Score'].apply(lambda x: find_risk(x,buckets))
    
    ## AUC, True Positive and False Positive
    auc_outsample = metrics.roc_auc_score(y_outsample, y_outsample_p1_xgb[1] )
    auc_test = metrics.roc_auc_score(y_test, y_test_p1_xgb[1] )
    auc_train = metrics.roc_auc_score(y_train, y_train_p1_xgb[1] )
    
    tprsample=sum(ks_table_outsample['Target_sum'][8:])/sum(ks_table_outsample['Target_sum'])
    tprtest=sum(ks_table_test['Target_sum'][8:])/sum(ks_table_test['Target_sum'])
    tprtrain=sum(ks_table_train['Target_sum'][8:])/sum(ks_table_train['Target_sum'])
    
    fprsample=(sum(ks_table_outsample['Target_count'][8:]) - sum(ks_table_outsample['Target_sum'][8:]))/sum(ks_table_outsample['Target_count'])
    fprtest=(sum(ks_table_test['Target_count'][8:])- sum(ks_table_test['Target_sum'][8:]))/sum(ks_table_test['Target_count'])
    fprtrain=(sum(ks_table_train['Target_count'][8:]) -sum(ks_table_train['Target_sum'][8:]))/sum(ks_table_train['Target_count'])
    
    iteration  = key
    ## Save all the files
    imp_var1.to_csv(os.path.join(op_path,iteration+'_var_imp.csv'))
    y_test_p1_xgb.to_csv(os.path.join(op_path,iteration+'_test.csv'))
    
    y_train_p1_xgb.to_csv(os.path.join(op_path,iteration+'_train.csv'))
    
    y_outsample_p1_xgb.to_csv(os.path.join(op_path,iteration+'_outsample.csv'))
    
    ks_table_test.to_csv(os.path.join(op_path,iteration+'_ks_table_test.csv'))
    ks_table_outsample.to_csv(os.path.join(op_path,iteration+'_ks_table_outsample.csv'))
    
    ks_table_train.to_csv(os.path.join(op_path,iteration+'_ks_table_train.csv'))
