
import pandas as pd
from fuzzywuzzy import fuzz, process
import re
from generatefeatures import GenerateFeatures
import os
from utils import TextUtils
import numpy as np
from multiprocessing import cpu_count
from pathos.multiprocessing import ProcessingPool as Pool



## Function to extract  executives with designation and Analysts

def get_analysts_from_preamble(preamble):
    '''input_parameter:preamble
       output_parameter:a tuple with lists of executives names,analyst names and designation of executives
       objectives: to get the executive,analysts and designation in a given preamble 
    '''
    if not preamble:
        return
    try:
        # Split preamble with ^ operator
        lines_raw = list(map(lambda x: x.strip(), preamble.split('^')))
        lines = list(zip(range(len(lines_raw)), lines_raw))
        B_index = list(map(lambda x: x[0], filter(lambda x: x[1].startswith('~'), lines)))
        B_index += [len(lines)]
        executive_index = list(filter(lambda x: x[1].lower().startswith('~executive'), lines))[0][0]
        executive_index_range = executive_index, B_index[B_index.index(executive_index)+1]
        executives_lines = lines_raw[executive_index_range[0]+1: executive_index_range[1]]
        executives_lines = list(filter(bool, executives_lines))
        # Get executive name
        executives = list(map(lambda x: re.split('[\,\-\–]', x)[0].strip(), executives_lines))
        
        # Get Designation for Executives
        cxo = list()
        for l in executives_lines:
            try: 
                designation = re.split('[\,\-\–]', l)[1].strip()
                if len(re.split('[\,\-\–]', l)[1:])>1:
                    designation = "-".join(re.split('[\,\-\–]', l)[1:]).strip()
            except:
                designation = l.split('–')[1].strip()
            
            cxo.append(designation)
            
         # Get Analyst
        analysts_index = list(filter(lambda x: x[1].lower().startswith('~analyst'), lines))[0][0]
        analysts_index_range = analysts_index, B_index[B_index.index(analysts_index)+1]
        analysts_lines = lines_raw[analysts_index_range[0]+1: analysts_index_range[1]]
        analysts_lines = list(filter(bool, analysts_lines))
        analysts = list(map(lambda x: re.split('[\,\-\–]', x)[0].strip(), analysts_lines))

    except Exception as e:
        
        return None 
    
    return(executives,analysts,cxo)

## Function to split Questions ans Answers
def get_q_a(heading, transcript, executives_analysts):
    '''input_parameter:transcript page heading, whole transcript,output of get_analysts_from_preamble function
       output_parameter:Dataframe of Designation,Executive Names,Question and Answers
       objectives: to get the dataframe using input_parameters 
    '''
    executives = executives_analysts[0]
    analysts = executives_analysts[1]    
    cxos = dict(zip(executives,executives_analysts[2]  )) 
    def if_analyst(line):
        if not line.startswith('~'):
            return False
        
        for analyst in analysts:
            if fuzz.partial_ratio(line, analyst) > 93:
            # Print(line, analyst)
                return analyst
        return False
    
    def if_executive(line):
        if not line.startswith('~'):
            return False

        for executive in executives:
            if fuzz.partial_ratio(line, executive) > 93:
                return executive
        return False
    
    def return_name(B):
        name = process.extractOne(B, executives + analysts)[0][0]
        # Return name[0]
        if fuzz.partial_ratio(B, name) > 0.90:
            return name
        else:
            return 
    def return_desgnation(B):
        name = process.extractOne(B, executives + analysts)[0][0]
        # Return name[0]
        if fuzz.partial_ratio(B, name) > 0.90:
            return name
        else:
            return 
        
    
    lines_raw = list(map(lambda x: x.strip(), transcript.split('^')))
    lines = []
    for i in range(len(lines_raw)):
        if if_analyst(lines_raw[i]):
            
            lines.append(('analyst', if_analyst(lines_raw[i]),'designation', lines_raw[i+1]))
            #Lines.append('designation')
            i = i + 2
            
        elif if_executive(lines_raw[i]):
            
            executive_name = if_executive(lines_raw[i])
            lines.append(('executive', executive_name, cxos[executive_name],lines_raw[i+1]))
            # Lines.append()
            i = i + 2
            
        else:
            i = i + 1 
        if i >= len(lines_raw):
            break

    return(pd.DataFrame(lines))

## Filtering Questions
def filter_ques(text):
    return bool(re.search('\w+',text))

## Questions Level Feature Generation
def question_features(question_doc,direc):
    '''input_parameter:Dataframe with Designation,Executive Names,QA,company name and date earning call
       output_parameter:AD_with_question_feature_sample_Groupby and AD_with_analyst_count
       objectives: to get the dataframe of question level features using input_parameters 
    '''
    # Pre-process question dataframe
    question=question_doc[(question_doc['Exe_Ana']=='analyst')]
    question=question.drop(['Designation'],axis=1)
    question=question[~question.isnull()]
    question=question.drop_duplicates()
    question['Q_filter'] = question['QA'].apply(filter_ques)
    question = question[question['Q_filter']]
    
    # Generate Features using Multi-Processing
    
    question.reset_index(inplace=True,drop=True)
    textutils = TextUtils() 
    generatefeatures = GenerateFeatures(textutils=textutils, lm_filepath=os.path.join(direc,'data/LoughranMcDonald_MasterDictionary_2016.csv'))
    
    cores = cpu_count() #Number of CPU cores on your system
    partitions = cores #Define as many partitions as you want 
    pool = Pool(cores) 
    
    data_split = np.array_split(question['QA'], partitions)
    
    data3 = pd.concat(pool.map(lambda series: pd.Series(map(generatefeatures.generate_features,series)),\
                              data_split),axis=0, ignore_index=True).apply(pd.Series)
    
    data3.columns = [c+'_Questions' for c in data3.columns]
    # Create AD at Question level with Features
    AD_with_question_feature_sample = pd.concat([question,data3],axis=1)
   
    # AD with count of Analyst
    AD_with_analyst_count=(AD_with_question_feature_sample.groupby(['Company','date_earning_call'])
       .agg({'Name':'nunique'}))
    
    # Rename Count of Analyst
    AD_with_analyst_count=AD_with_analyst_count.rename(columns={"Name":"Count_of_Analyst"})
    

    # Aggregate the question level features at transcript level 
    AD_with_question_feature_sample_Groupby=(AD_with_question_feature_sample.groupby(['Company','date_earning_call'])
       .agg({'QA':'count',
         'automated_readibility_index_Questions':'mean',
         'coleman_liau_index_Questions':'mean',
         'constraint_frequency_Questions':'mean',
         'constraint_frequency_rel_Questions':'mean',
         'difficult_words_Questions':'mean',
        'flesch_kincaid_grade_Questions':'mean',
         'flesch_reading_ease_Questions':'mean',
          'gunning_fox_Questions':'mean',
         'hiv4_score_negative_Questions':'mean',
       'hiv4_score_polarity_Questions':'mean', 
         'hiv4_score_postive_Questions':'mean',
       'hiv4_score_subjectivity_Questions':'mean',
         'interesting_frequency_Questions':'mean',
       'interesting_frequency_rel_Questions':'mean',
       'irreg_verbs_frequency_Questions':'mean',
       'irreg_verbs_frequency_rel_Questions':'mean',
       'linsear_write_formula_Questions':'mean', 
         'litigious_frequency_Questions':'mean',
       'litigious_frequency_rel_Questions':'mean', 
         'lm_score_negative_Questions':'mean',
       'lm_score_polarity_Questions':'mean',
         'lm_score_postive_Questions':'mean',
       'lm_score_subjectivity_Questions':'mean', 
         'mid_modal_frequency_Questions':'mean',
       'mid_modal_frequency_rel_Questions':'mean',
         'n_sents_Questions':'mean',
       'n_syllables_Questions':'mean',
        'negative_frequency_Questions':'mean',
       'negative_frequency_rel_Questions':'mean',
         'padding_Questions':'mean',
       'positive_frequency_Questions':'mean', 
         'positive_frequency_rel_Questions':'mean',
         'size_Questions':'mean',
    'smog_grade_index_Questions':'mean',
    'strong_modal_frequency_Questions':'mean',
         'superflous_frequency_Questions':'mean',
         'superflous_frequency_rel_Questions':'mean',
       'dale_chall_readability_score_Questions':'mean',
           'uncertainty_frequency_Questions':'mean',
       'uncertainty_frequency_rel_Questions':'mean', 
         'vader_compound_score_Questions':'mean',
       'vader_negative_score_Questions':'mean', 
         'vader_neutral_score_Questions':'mean',
       'vader_positive_score_Questions':'mean', 
         'weak_modal_frequency_Questions':'mean',
       'weak_modal_frequency_rel_Questions':'mean'
        
         }))

    agg_dict = {'QA':'count',
         'automated_readibility_index_Questions':'mean',
         'coleman_liau_index_Questions':'mean',
         'constraint_frequency_Questions':'mean',
         'constraint_frequency_rel_Questions':'mean',
         'difficult_words_Questions':'mean',
        'flesch_kincaid_grade_Questions':'mean',
         'flesch_reading_ease_Questions':'mean',
          'gunning_fox_Questions':'mean',
         'hiv4_score_negative_Questions':'mean',
       'hiv4_score_polarity_Questions':'mean', 
         'hiv4_score_postive_Questions':'mean',
       'hiv4_score_subjectivity_Questions':'mean',
         'interesting_frequency_Questions':'mean',
       'interesting_frequency_rel_Questions':'mean',
       'irreg_verbs_frequency_Questions':'mean',
       'irreg_verbs_frequency_rel_Questions':'mean',
       'linsear_write_formula_Questions':'mean', 
         'litigious_frequency_Questions':'mean',
       'litigious_frequency_rel_Questions':'mean', 
         'lm_score_negative_Questions':'mean',
       'lm_score_polarity_Questions':'mean',
         'lm_score_postive_Questions':'mean',
       'lm_score_subjectivity_Questions':'mean', 
         'mid_modal_frequency_Questions':'mean',
       'mid_modal_frequency_rel_Questions':'mean',
         'n_sents_Questions':'mean',
       'n_syllables_Questions':'mean',
        'negative_frequency_Questions':'mean',
       'negative_frequency_rel_Questions':'mean',
         'padding_Questions':'mean',
       'positive_frequency_Questions':'mean', 
         'positive_frequency_rel_Questions':'mean',
         'size_Questions':'mean',
    'smog_grade_index_Questions':'mean',
    'strong_modal_frequency_Questions':'mean',
         'superflous_frequency_Questions':'mean',
         'superflous_frequency_rel_Questions':'mean',
       'dale_chall_readability_score_Questions':'mean',
           'uncertainty_frequency_Questions':'mean',
       'uncertainty_frequency_rel_Questions':'mean', 
         'vader_compound_score_Questions':'mean',
       'vader_negative_score_Questions':'mean', 
         'vader_neutral_score_Questions':'mean',
       'vader_positive_score_Questions':'mean', 
         'weak_modal_frequency_Questions':'mean',
       'weak_modal_frequency_rel_Questions':'mean'
        
         }


    # Rename the columns of Questions level Features 
    rename_dict = { k: v+'_'+k for k, v in agg_dict.items() }
    
    AD_with_question_feature_sample_Groupby=AD_with_question_feature_sample_Groupby.rename(columns=rename_dict)
    ## Reset Index to get Company and publish date tme
    AD_with_question_feature_sample_Groupby = AD_with_question_feature_sample_Groupby.reset_index()
    
    ## Remove Duplicates and rename the columns
    AD_with_question_feature_sample_Groupby = AD_with_question_feature_sample_Groupby.drop_duplicates()
    AD_with_question_feature_sample_Groupby = AD_with_question_feature_sample_Groupby[~AD_with_question_feature_sample_Groupby.isnull()]
    AD_with_question_feature_sample_Groupby = AD_with_question_feature_sample_Groupby.rename(columns = {'date_earning_call':'published_date_time', 'company_name':'Company'})


    ## Reset Index to get Company and publish date tme
    AD_with_analyst_count= AD_with_analyst_count.reset_index()
    
    ## Remove Duplicates and rename the columns
    AD_with_analyst_count = AD_with_analyst_count.drop_duplicates()
    AD_with_analyst_count = AD_with_analyst_count.rename(columns = {'date_earning_call':'published_date_time', 'company_name':'Company'})


    return(AD_with_question_feature_sample_Groupby,AD_with_analyst_count)
 

## Answers Level Feature Generation

# Read answer AD after splitting
def answer_features(question_doc,direc):
    '''input_parameter:Dataframe with Designation,Executive Names,QA,company name and date earning call
       output_parameter:AD_with_answers_feature_sample_Groupby and AD_with_executive_count
       objectives: to get the dataframe of answer level features using input_parameters 
    '''
    # Pre-process answer dataframe
    answer=question_doc[question_doc['Exe_Ana']=='executive']
    answer=answer[~answer['QA'].isnull()]
    answer=answer.drop_duplicates()
    answer['A_filter'] = answer['QA'].apply(filter_ques)
    answer = answer[answer['A_filter']]
    
    # Generate Answers features using multiprocessing
        
    answer.reset_index(inplace=True,drop=True)
    textutils = TextUtils()
    generatefeatures = GenerateFeatures(textutils=textutils, lm_filepath=os.path.join(direc,'data/LoughranMcDonald_MasterDictionary_2016.csv'))
    cores = cpu_count() #Number of CPU cores on your system
    partitions = cores #Define as many partitions as you want
    
   
    
    data_split = np.array_split(answer['QA'], partitions)
    pool = Pool(cores)
    data3 = pd.concat(pool.map(lambda series: pd.Series(map(generatefeatures.generate_features,series)),\
                              data_split),axis=0, ignore_index=True).apply(pd.Series)
   
    data3.columns = [c+'_Answers' for c in data3.columns]
    
    # Create AD at Answer level with Features
    AD_with_answers_feature_sample = pd.concat([answer,data3],axis=1)
    
    # AD with count of Executives
    AD_with_executive_count=(AD_with_answers_feature_sample.groupby(['Company','date_earning_call'])
   .agg({'Name':'nunique'}))

    # Rename Count of Executive
    AD_with_executive_count=AD_with_executive_count.rename(columns={"Name":"Count_of_Executive" })
    
    # Aggregate the Answers level features at transcript level 
    AD_with_answers_feature_sample_Groupby=(AD_with_answers_feature_sample.groupby(['Company','date_earning_call'])
       .agg({'QA':'count',
         'automated_readibility_index_Answers':'mean',
         'coleman_liau_index_Answers':'mean',
         'constraint_frequency_Answers':'mean',
         'constraint_frequency_rel_Answers':'mean',
         'difficult_words_Answers':'mean',
        'flesch_kincaid_grade_Answers':'mean',
         'flesch_reading_ease_Answers':'mean',
          'gunning_fox_Answers':'mean',
         'hiv4_score_negative_Answers':'mean',
       'hiv4_score_polarity_Answers':'mean', 
         'hiv4_score_postive_Answers':'mean',
       'hiv4_score_subjectivity_Answers':'mean',
         'interesting_frequency_Answers':'mean',
       'interesting_frequency_rel_Answers':'mean',
       'irreg_verbs_frequency_Answers':'mean',
       'irreg_verbs_frequency_rel_Answers':'mean',
       'linsear_write_formula_Answers':'mean', 
         'litigious_frequency_Answers':'mean',
       'litigious_frequency_rel_Answers':'mean', 
         'lm_score_negative_Answers':'mean',
       'lm_score_polarity_Answers':'mean',
         'lm_score_postive_Answers':'mean',
       'lm_score_subjectivity_Answers':'mean', 
         'mid_modal_frequency_Answers':'mean',
       'mid_modal_frequency_rel_Answers':'mean',
         'n_sents_Answers':'mean',
       'n_syllables_Answers':'mean',
        'negative_frequency_Answers':'mean',
       'negative_frequency_rel_Answers':'mean',
         'padding_Answers':'mean',
       'positive_frequency_Answers':'mean', 
         'positive_frequency_rel_Answers':'mean',
         'size_Answers':'mean',
    'smog_grade_index_Answers':'mean',
    'strong_modal_frequency_Answers':'mean',
         'superflous_frequency_Answers':'mean',
         'superflous_frequency_rel_Answers':'mean',
       'dale_chall_readability_score_Answers':'mean',
           'uncertainty_frequency_Answers':'mean',
       'uncertainty_frequency_rel_Answers':'mean', 
         'vader_compound_score_Answers':'mean',
       'vader_negative_score_Answers':'mean', 
         'vader_neutral_score_Answers':'mean',
       'vader_positive_score_Answers':'mean', 
         'weak_modal_frequency_Answers':'mean',
       'weak_modal_frequency_rel_Answers':'mean'
        
         }))
    
    agg_dict = {'QA':'count',
         'automated_readibility_index_Answers':'mean',
         'coleman_liau_index_Answers':'mean',
         'constraint_frequency_Answers':'mean',
         'constraint_frequency_rel_Answers':'mean',
         'difficult_words_Answers':'mean',
        'flesch_kincaid_grade_Answers':'mean',
         'flesch_reading_ease_Answers':'mean',
          'gunning_fox_Answers':'mean',
         'hiv4_score_negative_Answers':'mean',
       'hiv4_score_polarity_Answers':'mean', 
         'hiv4_score_postive_Answers':'mean',
       'hiv4_score_subjectivity_Answers':'mean',
         'interesting_frequency_Answers':'mean',
       'interesting_frequency_rel_Answers':'mean',
       'irreg_verbs_frequency_Answers':'mean',
       'irreg_verbs_frequency_rel_Answers':'mean',
       'linsear_write_formula_Answers':'mean', 
         'litigious_frequency_Answers':'mean',
       'litigious_frequency_rel_Answers':'mean', 
         'lm_score_negative_Answers':'mean',
       'lm_score_polarity_Answers':'mean',
         'lm_score_postive_Answers':'mean',
       'lm_score_subjectivity_Answers':'mean', 
         'mid_modal_frequency_Answers':'mean',
       'mid_modal_frequency_rel_Answers':'mean',
         'n_sents_Answers':'mean',
       'n_syllables_Answers':'mean',
        'negative_frequency_Answers':'mean',
       'negative_frequency_rel_Answers':'mean',
         'padding_Answers':'mean',
       'positive_frequency_Answers':'mean', 
         'positive_frequency_rel_Answers':'mean',
         'size_Answers':'mean',
    'smog_grade_index_Answers':'mean',
    'strong_modal_frequency_Answers':'mean',
         'superflous_frequency_Answers':'mean',
         'superflous_frequency_rel_Answers':'mean',
       'dale_chall_readability_score_Answers':'mean',
           'uncertainty_frequency_Answers':'mean',
       'uncertainty_frequency_rel_Answers':'mean', 
         'vader_compound_score_Answers':'mean',
       'vader_negative_score_Answers':'mean', 
         'vader_neutral_score_Answers':'mean',
       'vader_positive_score_Answers':'mean', 
         'weak_modal_frequency_Answers':'mean',
       'weak_modal_frequency_rel_Answers':'mean'
        
         }

    ## Rename the columns of Questions level Features 
    
    rename_dict = { k: v+'_'+k for k, v in agg_dict.items() }
    
    AD_with_answers_feature_sample_Groupby=AD_with_answers_feature_sample_Groupby.rename(columns=rename_dict)
    
    ## Reset Index to get Company and publish date tme
    AD_with_answers_feature_sample_Groupby.reset_index(level=0, inplace=True)
    AD_with_answers_feature_sample_Groupby= AD_with_answers_feature_sample_Groupby.reset_index()
    
    ## Remove Duplicates and rename the columns
    AD_with_answers_feature_sample_Groupby = AD_with_answers_feature_sample_Groupby.drop_duplicates()
    AD_with_answers_feature_sample_Groupby = AD_with_answers_feature_sample_Groupby[~AD_with_answers_feature_sample_Groupby.isnull()]
    AD_with_answers_feature_sample_Groupby = AD_with_answers_feature_sample_Groupby.rename(columns = {'date_earning_call':'published_date_time', 'company_name':'Company'})

    ## Reset Index to get Company and publish date tme
    AD_with_executive_count= AD_with_executive_count.reset_index()
    
    ## Remove Duplicates and rename the columns
    AD_with_executive_count = AD_with_executive_count.drop_duplicates()
    AD_with_executive_count = AD_with_executive_count.rename(columns = {'date_earning_call':'published_date_time', 'company_name':'Company'})

    return(AD_with_answers_feature_sample_Groupby,AD_with_executive_count,AD_with_answers_feature_sample)



## To create flag for Designation
def designation_flag(input_str):
    '''input_parameter:AD_with_answers_feature
       output_parameter:Designation Features
       objectives: to make a designation flag for respective designations
    ''' 
    if fuzz.token_set_ratio(input_str, "CEO") > 93 or fuzz.token_set_ratio(input_str, "Chief Executive Officer" ) > 93: 
        DesignationFlag = 'CEO'       
    elif fuzz.token_set_ratio(input_str, "CFO") > 93 or fuzz.token_set_ratio(input_str, "Chief Finance Officer" ) > 93: 
        DesignationFlag = 'CFO'
    elif fuzz.token_set_ratio(input_str, "CTO") > 93 or fuzz.token_set_ratio(input_str, "Chief Technical Officer" ) > 93: 
        DesignationFlag  = 'CTO'
    elif fuzz.token_set_ratio(input_str, "COO") > 93 or fuzz.token_set_ratio(input_str, "Chief Operating Officer" ) > 93: 
        DesignationFlag  = 'COO'
    elif fuzz.token_set_ratio(input_str, "CIO") > 93 or fuzz.token_set_ratio(input_str, "Chief Information Officer" ) > 93: 
        DesignationFlag  = 'CTO'
    elif "President" in input_str or "president" in input_str:
        DesignationFlag = 'PRESIDENT'
    else: 
        DesignationFlag= 'OTHERS'
       
    return DesignationFlag


## Aggregate features at designation, transcript level
def designation_features(AD_with_answers_feature):
    '''input_parameter:AD_with_answers_feature
       output_parameter:Designation features
       objectives: to extract designation features for Answers level
    ''' 
    # Pre-process AD_with_answers_feature dataframe
    AD_with_answers_feature=AD_with_answers_feature[~AD_with_answers_feature.isnull()]
    AD_with_answers_feature = AD_with_answers_feature.dropna(subset=['Designation'])
    AD_with_answers_feature['Designation_Flag']=AD_with_answers_feature['Designation'].apply(designation_flag)
        
    AD_with_answers_feature_Groupby_with_Designation=(AD_with_answers_feature.groupby(['Company','date_earning_call','Designation_Flag'])
   .agg({'QA':'count',
         'automated_readibility_index_Answers':'mean',
         'coleman_liau_index_Answers':'mean',
         'constraint_frequency_Answers':'mean',
         'constraint_frequency_rel_Answers':'mean',
         'difficult_words_Answers':'mean',
        'flesch_kincaid_grade_Answers':'mean',
         'flesch_reading_ease_Answers':'mean',
          'gunning_fox_Answers':'mean',
         'hiv4_score_negative_Answers':'mean',
       'hiv4_score_polarity_Answers':'mean', 
         'hiv4_score_postive_Answers':'mean',
       'hiv4_score_subjectivity_Answers':'mean',
         'interesting_frequency_Answers':'mean',
       'interesting_frequency_rel_Answers':'mean',
       'irreg_verbs_frequency_Answers':'mean',
       'irreg_verbs_frequency_rel_Answers':'mean',
       'linsear_write_formula_Answers':'mean', 
         'litigious_frequency_Answers':'mean',
       'litigious_frequency_rel_Answers':'mean', 
         'lm_score_negative_Answers':'mean',
       'lm_score_polarity_Answers':'mean',
         'lm_score_postive_Answers':'mean',
       'lm_score_subjectivity_Answers':'mean', 
         'mid_modal_frequency_Answers':'mean',
       'mid_modal_frequency_rel_Answers':'mean',
         'n_sents_Answers':'mean',
       'n_syllables_Answers':'mean',
        'negative_frequency_Answers':'mean',
       'negative_frequency_rel_Answers':'mean',
         'padding_Answers':'mean',
       'positive_frequency_Answers':'mean', 
         'positive_frequency_rel_Answers':'mean',
         'size_Answers':'mean',
    'smog_grade_index_Answers':'mean',
    'strong_modal_frequency_Answers':'mean',
         'superflous_frequency_Answers':'mean',
         'superflous_frequency_rel_Answers':'mean',
       'dale_chall_readability_score_Answers':'mean',
           'uncertainty_frequency_Answers':'mean',
       'uncertainty_frequency_rel_Answers':'mean', 
         'vader_compound_score_Answers':'mean',
       'vader_negative_score_Answers':'mean', 
         'vader_neutral_score_Answers':'mean',
       'vader_positive_score_Answers':'mean', 
         'weak_modal_frequency_Answers':'mean',
       'weak_modal_frequency_rel_Answers':'mean',
         'Name':'nunique'
        
         }))



    AD_with_answers_feature_Groupby_with_Designation=AD_with_answers_feature_Groupby_with_Designation.rename(columns={"Name":"Count_of_Executive" })
    
    agg_dict = {'QA':'count',
         'automated_readibility_index_Answers':'mean',
         'coleman_liau_index_Answers':'mean',
         'constraint_frequency_Answers':'mean',
         'constraint_frequency_rel_Answers':'mean',
         'difficult_words_Answers':'mean',
        'flesch_kincaid_grade_Answers':'mean',
         'flesch_reading_ease_Answers':'mean',
          'gunning_fox_Answers':'mean',
         'hiv4_score_negative_Answers':'mean',
       'hiv4_score_polarity_Answers':'mean', 
         'hiv4_score_postive_Answers':'mean',
       'hiv4_score_subjectivity_Answers':'mean',
         'interesting_frequency_Answers':'mean',
       'interesting_frequency_rel_Answers':'mean',
       'irreg_verbs_frequency_Answers':'mean',
       'irreg_verbs_frequency_rel_Answers':'mean',
       'linsear_write_formula_Answers':'mean', 
         'litigious_frequency_Answers':'mean',
       'litigious_frequency_rel_Answers':'mean', 
         'lm_score_negative_Answers':'mean',
       'lm_score_polarity_Answers':'mean',
         'lm_score_postive_Answers':'mean',
       'lm_score_subjectivity_Answers':'mean', 
         'mid_modal_frequency_Answers':'mean',
       'mid_modal_frequency_rel_Answers':'mean',
         'n_sents_Answers':'mean',
       'n_syllables_Answers':'mean',
        'negative_frequency_Answers':'mean',
       'negative_frequency_rel_Answers':'mean',
         'padding_Answers':'mean',
       'positive_frequency_Answers':'mean', 
         'positive_frequency_rel_Answers':'mean',
         'size_Answers':'mean',
    'smog_grade_index_Answers':'mean',
    'strong_modal_frequency_Answers':'mean',
         'superflous_frequency_Answers':'mean',
         'superflous_frequency_rel_Answers':'mean',
       'dale_chall_readability_score_Answers':'mean',
           'uncertainty_frequency_Answers':'mean',
       'uncertainty_frequency_rel_Answers':'mean', 
         'vader_compound_score_Answers':'mean',
       'vader_negative_score_Answers':'mean', 
         'vader_neutral_score_Answers':'mean',
       'vader_positive_score_Answers':'mean', 
         'weak_modal_frequency_Answers':'mean',
       'weak_modal_frequency_rel_Answers':'mean'
        
}
    
    # Rename the columns
    rename_dict = { k: v+'_'+k  for k, v in agg_dict.items() }
    AD_with_answers_feature_Groupby_with_Designation=AD_with_answers_feature_Groupby_with_Designation.rename(columns=rename_dict)
    
    # Create Pivot Table
    cols = [c for c in AD_with_answers_feature_Groupby_with_Designation.columns]
    
    AD_with_answers_feature_Groupby_with_Designation = AD_with_answers_feature_Groupby_with_Designation.reset_index()
    
    AD_Designation_Level = pd.pivot_table(AD_with_answers_feature_Groupby_with_Designation,
                                          values=cols,
                                          index=['Company', 'date_earning_call'], columns=['Designation_Flag'])
    
    Designation_features=pd.concat([AD_Designation_Level[c].rename(columns={k:k+'_'+c for k in AD_Designation_Level[c].columns}) for c in AD_Designation_Level.columns.levels[0]],axis=1)
    Designation_features.fillna(0,inplace = True)
    Designation_features = Designation_features.reset_index()
    Designation_features = Designation_features.rename(columns = {'date_earning_call':'published_date_time', 'company_name':'Company'})


    return(Designation_features)


## Function to Split Preamble for Executive Level
def get_executive_from_preamble(preamble):
    '''input_parameter:preamble
       output_parameter:a tuple with lists of executives names and designation of executives
       objectives: to get the executives and designation in a given preamble 
    '''
   
    if not preamble:
        return
    try:
        # Split preamble with ^ operator
        lines_raw = list(map(lambda x: x.strip(), preamble.split('^')))
        lines = list(zip(range(len(lines_raw)), lines_raw))
        B_index = list(map(lambda x: x[0], filter(lambda x: x[1].startswith('~'), lines)))
        B_index += [len(lines)]
        executive_index = list(filter(lambda x: x[1].lower().startswith('~executive'), lines))[0][0]
        executive_index_range = executive_index, B_index[B_index.index(executive_index)+1]
        executives_lines = lines_raw[executive_index_range[0]+1: executive_index_range[1]]
        executives_lines = list(filter(bool, executives_lines))
        # Get executive name
        executives = list(map(lambda x: re.split('[\,\-\–]', x)[0].strip(), executives_lines))
        
         # Get Designation for Executives
        cxo = list()
        for l in executives_lines:
            try: 
                designations = re.split('[\,\-\–]', l)[1:]
                designation = re.split('[\,\-\–]', l)[1].strip()
                if len(designations)>1:
                    designation = "-".join([d.strip() for d in designations])
            except:
                try:
                    designation = l.split('–')[1].strip()
                except:
                    designation = "undefined"

          
            cxo.append(designation)
        
    except Exception as e:
        
        return None 

    
    return(executives,cxo)

## Function to extract text spoken by CXO's from Preamble
def get_pream(heading, preamble, executives_analysts):
    executives = executives_analysts[0]
    cxos = dict(zip(executives,executives_analysts[1]))

    def if_executive(line):
        if not line.startswith('~'):
            return False
  
        for executive in executives:
            if fuzz.partial_ratio(line, executive) > 93:
                return executive
        return False        
    
    lines_raw = list(filter(lambda x:x and filter_ques(x),(map(lambda x: x.strip(), preamble.split('^')))))
    lines = []
    for i in range(len(lines_raw)):
        try:    
            if if_executive(lines_raw[i]):
                executive_name = if_executive(lines_raw[i])
                lines.append(('executive', executive_name,cxos[executive_name],lines_raw[i+1]))
              
                i = i + 2

            else:
                i = i + 1 
            if i >= len(lines_raw):
                break
        except:
            pass

    return(pd.DataFrame(lines))

def Designation_features_preamble(question_doc_preamble,direc):
    '''input_parameter:Dataframe with Designation,Executive Names,QA,company name and date earning call
       output_parameter:AD_with_question_feature_sample_Groupby and AD_with_analyst_count
       objectives: to get the dataframe of question level features using input_parameters 
    '''
    # Pre-process question dataframe
    question_doc_preamble=question_doc_preamble[~question_doc_preamble['Preamble'].isnull()]
    question_doc_preamble=question_doc_preamble.drop_duplicates()
    question_doc_preamble['P_filter'] = question_doc_preamble['Preamble'].apply(filter_ques)
    question_doc_preamble = question_doc_preamble[question_doc_preamble['P_filter']]
    
    # Generate Features using Multi-Processing
    
    question_doc_preamble.reset_index(inplace=True,drop=True)
    textutils = TextUtils()
    generatefeatures = GenerateFeatures(textutils=textutils, lm_filepath=os.path.join(direc,'data/LoughranMcDonald_MasterDictionary_2016.csv'))

    cores = cpu_count() #Number of CPU cores on your system
    partitions = cores #Define as many partitions as you want    
    
    data_split = np.array_split(question_doc_preamble['Preamble'], partitions)
    pool = Pool(cores)
    data3 = pd.concat(pool.map(lambda series: pd.Series(map(generatefeatures.generate_features,series)),\
                              data_split),axis=0, ignore_index=True).apply(pd.Series)
#    pool.close()
#    pool.join()
    data3.columns = [c+'_CXO_Level_Preamble' for c in data3.columns]
    # Create AD at Preamble level with Features for CXO
    AD_with_CXO_level_for_preamble = pd.concat([question_doc_preamble,data3],axis=1)    
    AD_with_CXO_level_for_preamble.rename(columns = {'company_name':'Company'},inplace =True)    
    AD_with_CXO_level_for_preamble = AD_with_CXO_level_for_preamble.dropna(subset=['Designation'])    
    AD_with_CXO_level_for_preamble['Designation_Flag']=AD_with_CXO_level_for_preamble['Designation'].apply(designation_flag)
    
    
    AD_with_CXO_level_for_preamble=(AD_with_CXO_level_for_preamble.groupby(['Company','date_earning_call','Designation_Flag'])
       .agg({'automated_readibility_index_CXO_Level_Preamble':'mean',
         'coleman_liau_index_CXO_Level_Preamble':'mean',
         'constraint_frequency_CXO_Level_Preamble':'mean',
         'constraint_frequency_rel_CXO_Level_Preamble':'mean',
         'dale_chall_readability_score_CXO_Level_Preamble':'mean',
         'difficult_words_CXO_Level_Preamble':'mean',
         'flesch_kincaid_grade_CXO_Level_Preamble':'mean',
         'flesch_reading_ease_CXO_Level_Preamble':'mean',
         'gunning_fox_CXO_Level_Preamble':'mean',
         'hiv4_score_negative_CXO_Level_Preamble':'mean',
         'hiv4_score_polarity_CXO_Level_Preamble':'mean',
         'hiv4_score_postive_CXO_Level_Preamble':'mean',
         'hiv4_score_subjectivity_CXO_Level_Preamble':'mean',
         'interesting_frequency_CXO_Level_Preamble':'mean',
         'interesting_frequency_rel_CXO_Level_Preamble':'mean',
         'irreg_verbs_frequency_CXO_Level_Preamble':'mean',
         'irreg_verbs_frequency_rel_CXO_Level_Preamble':'mean',
         'linsear_write_formula_CXO_Level_Preamble':'mean',
         'litigious_frequency_CXO_Level_Preamble':'mean',
         'litigious_frequency_rel_CXO_Level_Preamble':'mean',
         'lm_score_negative_CXO_Level_Preamble':'mean',
         'lm_score_polarity_CXO_Level_Preamble':'mean',
         'lm_score_postive_CXO_Level_Preamble':'mean',
         'lm_score_subjectivity_CXO_Level_Preamble':'mean',
         'mid_modal_frequency_CXO_Level_Preamble':'mean',
         'mid_modal_frequency_rel_CXO_Level_Preamble':'mean',
         'n_sents_CXO_Level_Preamble':'mean',
         'n_syllables_CXO_Level_Preamble':'mean',
         'negative_frequency_CXO_Level_Preamble':'mean',
         'negative_frequency_rel_CXO_Level_Preamble':'mean',
         'padding_CXO_Level_Preamble':'mean',
         'positive_frequency_CXO_Level_Preamble':'mean',
         'positive_frequency_rel_CXO_Level_Preamble':'mean',
         'size_CXO_Level_Preamble':'mean',
         'smog_grade_index_CXO_Level_Preamble':'mean',
         'strong_modal_frequency_CXO_Level_Preamble':'mean',
         'strong_modal_frequency_rel_CXO_Level_Preamble':'mean',
         'superflous_frequency_CXO_Level_Preamble':'mean',
         'superflous_frequency_rel_CXO_Level_Preamble':'mean',
         'uncertainty_frequency_CXO_Level_Preamble':'mean',
         'uncertainty_frequency_rel_CXO_Level_Preamble':'mean',
         'vader_compound_score_CXO_Level_Preamble':'mean',
         'vader_negative_score_CXO_Level_Preamble':'mean',
         'vader_neutral_score_CXO_Level_Preamble':'mean',
         'vader_positive_score_CXO_Level_Preamble':'mean',
         'weak_modal_frequency_CXO_Level_Preamble':'mean',
         'weak_modal_frequency_rel_CXO_Level_Preamble':'mean'
         }))


    agg_dict = {'automated_readibility_index_CXO_Level_Preamble':'mean',
         'coleman_liau_index_CXO_Level_Preamble':'mean',
         'constraint_frequency_CXO_Level_Preamble':'mean',
         'constraint_frequency_rel_CXO_Level_Preamble':'mean',
         'dale_chall_readability_score_CXO_Level_Preamble':'mean',
         'difficult_words_CXO_Level_Preamble':'mean',
         'flesch_kincaid_grade_CXO_Level_Preamble':'mean',
         'flesch_reading_ease_CXO_Level_Preamble':'mean',
         'gunning_fox_CXO_Level_Preamble':'mean',
         'hiv4_score_negative_CXO_Level_Preamble':'mean',
         'hiv4_score_polarity_CXO_Level_Preamble':'mean',
         'hiv4_score_postive_CXO_Level_Preamble':'mean',
         'hiv4_score_subjectivity_CXO_Level_Preamble':'mean',
         'interesting_frequency_CXO_Level_Preamble':'mean',
         'interesting_frequency_rel_CXO_Level_Preamble':'mean',
         'irreg_verbs_frequency_CXO_Level_Preamble':'mean',
         'irreg_verbs_frequency_rel_CXO_Level_Preamble':'mean',
         'linsear_write_formula_CXO_Level_Preamble':'mean',
         'litigious_frequency_CXO_Level_Preamble':'mean',
         'litigious_frequency_rel_CXO_Level_Preamble':'mean',
         'lm_score_negative_CXO_Level_Preamble':'mean',
         'lm_score_polarity_CXO_Level_Preamble':'mean',
         'lm_score_postive_CXO_Level_Preamble':'mean',
         'lm_score_subjectivity_CXO_Level_Preamble':'mean',
         'mid_modal_frequency_CXO_Level_Preamble':'mean',
         'mid_modal_frequency_rel_CXO_Level_Preamble':'mean',
         'n_sents_CXO_Level_Preamble':'mean',
         'n_syllables_CXO_Level_Preamble':'mean',
         'negative_frequency_CXO_Level_Preamble':'mean',
         'negative_frequency_rel_CXO_Level_Preamble':'mean',
         'padding_CXO_Level_Preamble':'mean',
         'positive_frequency_CXO_Level_Preamble':'mean',
         'positive_frequency_rel_CXO_Level_Preamble':'mean',
         'size_CXO_Level_Preamble':'mean',
         'smog_grade_index_CXO_Level_Preamble':'mean',
         'strong_modal_frequency_CXO_Level_Preamble':'mean',
         'strong_modal_frequency_rel_CXO_Level_Preamble':'mean',
         'superflous_frequency_CXO_Level_Preamble':'mean',
         'superflous_frequency_rel_CXO_Level_Preamble':'mean',
         'uncertainty_frequency_CXO_Level_Preamble':'mean',
         'uncertainty_frequency_rel_CXO_Level_Preamble':'mean',
         'vader_compound_score_CXO_Level_Preamble':'mean',
         'vader_negative_score_CXO_Level_Preamble':'mean',
         'vader_neutral_score_CXO_Level_Preamble':'mean',
         'vader_positive_score_CXO_Level_Preamble':'mean',
         'weak_modal_frequency_CXO_Level_Preamble':'mean',
         'weak_modal_frequency_rel_CXO_Level_Preamble':'mean'
         }



    rename_dict = { k: v+'_'+k  for k, v in agg_dict.items() }
    AD_with_CXO_level_for_preamble=AD_with_CXO_level_for_preamble.rename(columns=rename_dict)

    # Create Pivot Table
    cols = [c for c in AD_with_CXO_level_for_preamble.columns]
   
    

    AD_with_CXO_level_for_preamble = AD_with_CXO_level_for_preamble.reset_index()
    
    AD_with_CXO_level_for_preamble = pd.pivot_table(AD_with_CXO_level_for_preamble,
                                          values=cols,
                                          index=['Company', 'date_earning_call'], columns=['Designation_Flag'])
    
    Designation_features_preamble_df=pd.concat([AD_with_CXO_level_for_preamble[c].rename(columns={k:k+'_'+c for k in AD_with_CXO_level_for_preamble[c].columns}) for c in AD_with_CXO_level_for_preamble.columns.levels[0]],axis=1)          
    Designation_features_preamble_df.fillna(0,inplace = True)
    Designation_features_preamble_df = Designation_features_preamble_df.reset_index()
    Designation_features_preamble_df = Designation_features_preamble_df.rename(columns = {'date_earning_call':'published_date_time', 'company_name':'Company'})

    return(Designation_features_preamble_df)

