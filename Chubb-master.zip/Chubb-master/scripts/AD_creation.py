
#==============================================================================
## Import  required packages
from tqdm import tqdm
import pandas as pd
from datetime import datetime as dt, timedelta as td
import pandasql as ps
import os
from generatefeatures import TextUtils,GenerateFeatures
from multiprocessing import cpu_count
from pathos.multiprocessing import ProcessingPool as Pool
import numpy as np
from Preprocessing_Data import preprocessing
from utils import TextUtils
from ad_config import *
#============================ Section1 ===================================
## Read raw transcript files

## Data preprocessing

transcripts_raw  = pd.read_csv(raw_transcripts_filepath, sep='|')
transcripts_raw = transcripts_raw[1:10]
req_cols = transcripts_raw.columns
data_raw = preprocessing(transcripts_raw,req_cols)


#=========================== Section2 =====================================
## Convert the date_earning_call into date format to fiter the data from 2014
data_raw["date_earning_call"] = data_raw["date_earning_call"].apply(pd.to_datetime)
data_raw["date_earning_call"] = data_raw["date_earning_call"].apply(pd.Timestamp.date)
data_raw['year'] = pd.DatetimeIndex(data_raw['date_earning_call']).year
data_raw = data_raw[data_raw['year'].isin(sel_year)]

data_raw.columns
dataraw_old_names = ['input company name', 'About', 'Transcript page heading',
       'Transcript heading', 'Preamble', 'transcript after preamble',
       'date_earning_call', 'year']
new_names = ['input_company_name', 'About',
        'Transcript_page_heading', 'Transcript_heading', 'Preamble',
        'transcript_after_preamble', 'date_earning_call',
        'year']
cols = dict(zip(dataraw_old_names,new_names))
data_raw = data_raw.rename(columns = cols)
## Select required Columns
data_raw = data_raw[['input_company_name', 'About',
        'Transcript_page_heading', 'Transcript_heading', 'Preamble',
        'transcript_after_preamble', 'date_earning_call',
        'year']]
#==============================================================================
## Drop duplicates (check point)
data_raw = data_raw.drop_duplicates()
len(data_raw)

data_raw = data_raw[~data_raw['Preamble'].isnull()]
len(data_raw)

## Count unique transcripts and in case if
## they are repeated due to filling date drop duplicates based on index
data_raw['date_earning_call_str'] = [str(i) for i in list(data_raw['date_earning_call'])]
data_raw['key'] = data_raw['input_company_name'] + data_raw['date_earning_call_str']
data_raw['Count'] = data_raw.groupby('key')['key'].transform('count')
data_temp = data_raw[data_raw['Count']>1 ]
data_temp['index'] = data_temp.index
data_temp['rank'] = data_temp.groupby('key')['index'].rank(ascending=1)
data_temp2 = data_temp[data_temp['rank'] == 1]
data_temp2 = data_temp2.drop(['rank','index'],axis = 1)
data_temp1 = data_raw[data_raw['Count']==1]
data = data_temp1.append(data_temp2,ignore_index =True)

#=========================== Section3 =====================================
df = data
df = df.rename(columns = {'input_company_name':'Company'})
df = df.rename(columns = {'transcript_after_preamble':'QA'})
df['combined']=df['Preamble'].astype(str)+df['QA'].astype(str)
del(data_temp1,data_temp,data_temp2,data,data_raw)

## Create features using GenerateFeatures function

textutils = TextUtils(stopword_file='../data/stopwords.csv', use_spacy=False)
generatefeatures = GenerateFeatures(textutils=textutils, lm_filepath=os.path.join(direc,'data/LoughranMcDonald_MasterDictionary_2016.csv'))

## Extract Features from Question&Answers , Preamble, Complete transcript

cores = cpu_count() #Number of CPU cores on your system
partitions = cores #Define as many partitions as you want

# Questions
data_split_qa = np.array_split(df['QA'], partitions)
pool = Pool(cores)
question_features = pd.concat(pool.map(lambda series: pd.Series(map(generatefeatures.generate_features,series)),\
                          data_split_qa),axis=0, ignore_index=True).apply(pd.Series)

question_features.columns = [c+'_QA' for c in question_features.columns]

# Preamble
data_split_preamb = np.array_split(df['Preamble'], partitions)
pool = Pool(cores)
preamble_features = pd.concat(pool.map(lambda series: pd.Series(map(generatefeatures.generate_features,series)),\
                          data_split_preamb),axis=0, ignore_index=True).apply(pd.Series)
preamble_features.columns = [c+'_Preamble' for c in preamble_features.columns]

# Complete Transcript
data_split_comb = np.array_split(df['combined'], partitions)
pool = Pool(cores)
combined_features = pd.concat(pool.map(lambda series: pd.Series(map(generatefeatures.generate_features,series)),\
                          data_split_comb),axis=0, ignore_index=True).apply(pd.Series)
combined_features.columns = [c+'_Combined' for c in combined_features.columns]

pool.close()

# Combine all features
df2_features = pd.concat([df, question_features], axis=1)
df2_features = pd.concat([df2_features, preamble_features], axis=1)
df2_features = pd.concat([df2_features, combined_features], axis=1)

# Create flags based on size of transcipts
df2_features['Avg_QA_Size'] = df2_features.groupby('Company')['size_QA'].transform('mean')
df2_features['Avg_QA_Size_maxflag'] = (df2_features['size_QA']>df2_features['Avg_QA_Size']*1.5).astype('int')
df2_features['Avg_QA_Size_minflag']=  (df2_features['size_QA']<df2_features['Avg_QA_Size']*0.5).astype('int')

df2_features['Avg_Preamble_Size'] = df2_features.groupby('Company')['size_Preamble'].transform('mean')
df2_features['Avg_Preamble_Size_maxflag'] = (df2_features['size_Preamble']>df2_features['Avg_Preamble_Size']*1.5).astype('int')
df2_features['Avg_Preamble_Size_minflag']=  (df2_features['size_Preamble']<df2_features['Avg_Preamble_Size']*0.5).astype('int')

df2_features['Avg_Combined_Size'] = df2_features.groupby('Company')['size_Combined'].transform('mean')
df2_features['Avg_Combined_Size_maxflag'] = (df2_features['size_Combined']>df2_features['Avg_Combined_Size']*1.5).astype('int')
df2_features['Avg_Combined_Size_minflag']=  (df2_features['size_Combined']<df2_features['Avg_Combined_Size']*0.5).astype('int')


## Drop uncessary columns
df3_features = df2_features.drop(['Transcript_page_heading', 'Transcript_heading',
'Preamble', 'QA', 'date_earning_call_str','About','combined','year','key', 'Count'],axis = 1)


df3_features = df3_features.drop(['Avg_Combined_Size','Avg_Preamble_Size','Avg_QA_Size'],axis = 1)
AD_raw = df3_features

#=========================== Section4 =====================================
## Create and Join Question level features and Answer level features to AD

from Feature_Extraction import get_analysts_from_preamble,get_q_a,get_pream,question_features,answer_features,designation_features,get_executive_from_preamble,Designation_features_preamble

## Apply get_analysts_from_preamble function  for executive_analysts column
df['executives_analysts'] = df['Preamble'].apply(get_analysts_from_preamble)

## Create a dataframe with below mentioned columns
cols = ['Company','date_earning_call',"Exe_Ana","Name","Designation","QA"]
question_doc = pd.DataFrame(columns = cols)

## Iterate through the rows of the Dataframe to split Questions ans Answers
for _, row in df.iterrows():
    try:
        #apply get_q_a function
        q_a = get_q_a(row['Transcript_page_heading'],
                      row['QA'],
                      row['executives_analysts'])
        q_a=q_a.rename(columns={0:"Exe_Ana", 1:"Name",2:"Designation",3:"QA"})
        q_a['Company'] = row['Company']
        q_a['date_earning_call'] =  row['date_earning_call']

        # Dataframe with Designation,Executive Names,QA,company name and date earning call
        question_doc = pd.concat([question_doc,q_a])

    except:
        
        pass

#pool.restart()
## Question Level Feature Generation
all_qus_feat,AD_with_analyst_count=question_features(question_doc,direc)

#all_qus_feat.to_csv('all_qus_feat_set1.csv',index = False)
#AD_with_analyst_count.to_csv('AD_with_analyst_count_set1.csv',index = False)

## Answers Level Feature Generation
all_ans_feat,AD_with_executive_count,AD_with_answers_feature=answer_features(question_doc,direc)

#all_ans_feat.to_csv('all_ans_feat_set1.csv',index = False)
#AD_with_executive_count.to_csv('AD_with_executive_count_set1.csv',index = False)
#AD_with_answers_feature.to_csv('AD_with_answers_feature_set1.csv',index = False)


## Join number of analysts variable to the AD
AD_raw = AD_raw.rename(columns = {'date_earning_call':'published_date_time'})

AD_raw = pd.merge(AD_with_analyst_count,AD_raw, how = 'inner',
                   left_on = ['Company','published_date_time'],
                             right_on = ['Company','published_date_time'])

## Join number of executives variable to the AD
AD_raw = pd.merge(AD_with_executive_count,AD_raw, how = 'inner',
                   left_on = ['Company','published_date_time'],
                             right_on = ['Company','published_date_time'])

## Join only Question level variable to the AD
AD_raw = pd.merge(all_qus_feat,AD_raw, how = 'inner',
                   left_on = ['Company','published_date_time'],
                             right_on = ['Company','published_date_time'])

## Join only Question level variable to the AD
AD_raw = pd.merge(all_ans_feat,AD_raw, how = 'inner',
                   left_on = ['Company','published_date_time'],
                             right_on = ['Company','published_date_time'])

#=========================== Section5 =====================================
## Create and Join Designation level features from Preamble and Answers

## Aggregate Answer level features at designation, transcript level
Designation_features_answer=designation_features(AD_with_answers_feature)

#Designation_features_answer.to_csv('Designation_features_answer_set1.csv',index = False)
AD_raw = pd.merge(AD_raw,Designation_features_answer, how = 'inner',
                   left_on = ['Company','published_date_time'],
                             right_on = ['Company','published_date_time'])

## Apply get_analysts_from_preamble function  for executive_analysts column
df['executives_analysts'] = df['Preamble'].apply(get_executive_from_preamble)

## Create a dataframe with below mentioned columns
cols = ['Company','date_earning_call',"Exe_Ana","Name","Designation","Preamble"]
question_doc_preamble = pd.DataFrame(columns = cols)

## Iterate through the rows of the Dataframe
for _, row in df.iterrows():
    try:
        #apply get_q_a function
        q_a = get_pream(row['Transcript_page_heading'],
                      row['Preamble'],
                      row['executives_analysts'])
        q_a=q_a.rename(columns={0:"Exe_Ana", 1:"Name",2:"Designation",3:"Preamble"})
        q_a['Company'] = row['Company']
        q_a['date_earning_call'] =  row['date_earning_call']

        # Dataframe with Designation,Executive Names,QA,company name and date earning call
        question_doc_preamble = pd.concat([question_doc_preamble,q_a])

    except:
        pass

## Aggregate Preamble level features at designation, transcript level
Designation_features_preamble_df=Designation_features_preamble(question_doc_preamble,direc)
#Designation_features_preamble_df.to_csv('Designation_features_preamble_df_set1.csv',index = False)

AD_raw = pd.merge(AD_raw,Designation_features_preamble_df, how = 'inner',
                   left_on = ['Company','published_date_time'],
                             right_on = ['Company','published_date_time'])

#=========================== Section6 =====================================
## Join sector information of a compnay to AD

sector = pd.read_csv(sector_filepath)

# Drop duplicates
sector_req = sector[['Company Input','Sector']].drop_duplicates()

# Replace NULL in sector column with 'Others'
sector_req1 = sector_req[sector_req['Sector'].isnull()]
sector_req1['Sector'] ='Others'
sector_req2 = sector_req[~sector_req['Sector'].isnull()]

# Assign 'Others' as sector for the compnies which are presnet in AD but in yahoo summary
AD_not_comp = list(set(AD_raw['Company'])-set(sector_req['Company Input']))
sector_comp = 'Others'
sector_req3 = pd.DataFrame({'Company Input':AD_not_comp,'Sector': 'Others'})

# Combine all sets of sector information
sector_req_final= sector_req1.append([sector_req2,sector_req3])
sector_req_final = sector_req_final.rename(columns = {'Company Input':'Company'})

# Merge the sector flags to AD_raw
AD_raw = pd.merge(AD_raw,sector_req_final,how = 'left',left_on = 'Company',right_on = 'Company')


#=========================== Section7 =====================================
## Create STOCK features and join with AD
from Stock_Features import generate_stock_features
# Read  Stock Data
stock_prices = pd.read_csv(stock_filepath)
stock_data = generate_stock_features(df, stock_prices)
## merge AD and stcok price at key level
stock_data['Company'] = list(map(lambda x:x.split('-')[0],(stock_data['key'])))
stock_data['published_date_time'] = list(map(lambda x:('-').join(x.split('-')[1:]),(stock_data['key'])))
stock_data["published_date_time"] = stock_data["published_date_time"].apply(pd.to_datetime)
stock_data["published_date_time"] = stock_data["published_date_time"].apply(pd.Timestamp.date)

stock_data.drop(['key','opening_price','closing_price','highest_price','lowest_price','trade_volume'],axis = 1,inplace = True)
final_AD= pd.merge(AD_raw,stock_data, how = 'left', left_on = ['Company','published_date_time'],
                        right_on = ['Company','published_date_time'])


final_AD = final_AD[~final_AD['rsi_index'].isnull()]
#=========================== Section8 =====================================
## Create features at quarter level

# Get features from 1 Quarter Back, 2 Quarter Back, 3 Quarter Back , 4 Quarter back Transcripts
only_features = list(set(final_AD.columns) - set(['Company','published_date_time','Sector']))


## Generate key to  based on date to create variables from previous quarter transcripts
# 1 quarter previous transcipts
final_AD["1Q_Back"] =  final_AD['published_date_time']
#2 quarter previous transcipts
final_AD["2Q_Back"] =  final_AD.sort_values(by='published_date_time').groupby(['published_date_time'])['published_date_time'].shift(1)

# 3 quarter previous transcipts
final_AD["3Q_Back"] =  final_AD.sort_values(by='published_date_time').groupby(['published_date_time'])['published_date_time'].shift(2)

# 4 quarter previous transcipts
final_AD["4Q_Back"] =  final_AD.sort_values(by='published_date_time').groupby(['published_date_time'])['published_date_time'].shift(3)

df2_temp = final_AD[['Company','published_date_time','Sector']]

for feature in only_features:
    for quarter in select_quarters:
        df2_temp = pd.merge(df2_temp,final_AD[['Company','published_date_time',feature]],how = 'left',left_on = ['Company','published_date_time'],
                        right_on =['Company','published_date_time'])

        old_name =only_features
        new_name =[quarter+'_'+i for i in old_name]
        cols = dict(zip(old_name,new_name))
        df2_temp = df2_temp.rename(columns=cols)

#=========================== Section9 =====================================
## Join Dependent Variable
AD_raw = df2_temp
AD_raw["published_date_time"] = AD_raw["published_date_time"].apply(pd.to_datetime)
AD_raw["published_date_time"] = AD_raw["published_date_time"].apply(pd.Timestamp.date)

AD_raw_check = AD_raw[['Company','published_date_time']]

# Get Cals Data
cals_data = pd.read_csv(CALS_data)

# Double check the filing dates
cals_data["filing_date_2"] = cals_data["Filing Date"].apply(pd.to_datetime)

# Create flag for CALS
cals_data["is_cals"] = 1

# Cals happend within 360 days from the transcript realsed
sql_query0 = '''Select a.* ,b.filing_date_2,coalesce(b.is_cals,0) as is_cals_360
FROM AD_raw_check a left join
cals_data b ON a."Company" = b.Ticker
AND a.published_date_time < b.filing_date_2
and date(a.published_date_time ,'+360 day') >= b.filing_date_2'''
data2 = ps.sqldf(sql_query0)
data2 = data2.drop(["filing_date_2"],axis = 1).drop_duplicates()
data2["published_date_time"] = data2["published_date_time"].apply(pd.to_datetime)
data2["published_date_time"] = data2["published_date_time"].apply(pd.Timestamp.date)

# Cals happend within 90 days from the transcript realsed
sql_query = '''Select a.* ,b.filing_date_2,coalesce(b.is_cals,0) as is_cals_90
FROM data2 a left join
cals_data b ON a."Company" = b.Ticker
AND a.published_date_time < b.filing_date_2
and date(a.published_date_time ,'+90 day') >= b.filing_date_2'''
data3 = ps.sqldf(sql_query)
data3 = data3.drop(["filing_date_2"],axis = 1).drop_duplicates()
data3["published_date_time"] = data3["published_date_time"].apply(pd.to_datetime)
data3["published_date_time"] = data3["published_date_time"].apply(pd.Timestamp.date)

# Cals happend within 180 days from the transcript realsed
sql_query1 = '''Select a.* ,b.filing_date_2,coalesce(b.is_cals,0) as is_cals_180
FROM data3 a left join
cals_data b ON a."Company" = b.Ticker
AND a.published_date_time < b.filing_date_2
and date(a.published_date_time ,'+180 day') >= b.filing_date_2'''
data4 = ps.sqldf(sql_query1)
data4 = data4.drop(["filing_date_2"],axis = 1).drop_duplicates()
data4["published_date_time"] = data4["published_date_time"].apply(pd.to_datetime)
data4["published_date_time"] = data4["published_date_time"].apply(pd.Timestamp.date)


# Cals happend within 270 days from the transcript realsed
sql_query2 = '''Select a.* ,b.filing_date_2,coalesce(b.is_cals,0) as is_cals_270
FROM data4 a left join
cals_data b ON a."Company" = b.Ticker
AND a.published_date_time < b.filing_date_2
and date(a.published_date_time ,'+270 day') >= b.filing_date_2'''
data5 = ps.sqldf(sql_query2)
data5 = data5.drop(["filing_date_2"],axis = 1).drop_duplicates()
data5["published_date_time"] = data5["published_date_time"].apply(pd.to_datetime)
data5["published_date_time"] = data5["published_date_time"].apply(pd.Timestamp.date)


# Cals happend within 90-180 days from the transcript realsed
sql_query3 = '''Select a.* ,b.filing_date_2,coalesce(b.is_cals,0) as is_cals_90_180
FROM data5 a left join
cals_data b ON a."Company" = b.Ticker
AND date(a.published_date_time ,'+90 day') < b.filing_date_2
and date(a.published_date_time ,'+180 day') >= b.filing_date_2'''
data6 = ps.sqldf(sql_query3)
data6 = data6.drop(["filing_date_2"],axis = 1).drop_duplicates()
data6["published_date_time"] = data6["published_date_time"].apply(pd.to_datetime)
data6["published_date_time"] = data6["published_date_time"].apply(pd.Timestamp.date)


# Cals happend within 180-270 days from the transcript realsed
sql_query4 = '''Select a.* ,b.filing_date_2,coalesce(b.is_cals,0) as is_cals_180_270
FROM data6 a left join
cals_data b ON a."Company" = b.Ticker
AND date(a.published_date_time ,'+180 day') < b.filing_date_2
and date(a.published_date_time ,'+270 day') >= b.filing_date_2'''
data7 = ps.sqldf(sql_query4)
data7 = data7.drop(["filing_date_2"],axis = 1).drop_duplicates()
data7["published_date_time"] = data7["published_date_time"].apply(pd.to_datetime)
data7["published_date_time"] = data7["published_date_time"].apply(pd.Timestamp.date)

#Cals happend within 270-360 days from the transcript realsed
sql_query5 = '''Select a.* ,b.filing_date_2,coalesce(b.is_cals,0) as is_cals_270_360
FROM data7 a left join
cals_data b ON a."Company" = b.Ticker
AND date(a.published_date_time ,'+270 day') < b.filing_date_2 and
date(a.published_date_time ,'+360 day') >= b.filing_date_2'''
data8 = ps.sqldf(sql_query5)
data8 = data8.drop(["filing_date_2"],axis = 1).drop_duplicates()
data8["published_date_time"] = data8["published_date_time"].apply(pd.to_datetime)
data8["published_date_time"] = data8["published_date_time"].apply(pd.Timestamp.date)

## Create Varibles based on CALS
sql_query6 = '''Select a.* ,b.filing_date_2
FROM AD_raw_check a inner join
cals_data b ON a."Company" = b.Ticker
AND  b.filing_date_2 <a.published_date_time'''

AD_CALS_iv = ps.sqldf(sql_query6)

sql_query7 = '''Select * ,
count(filing_date_2) as Historical_CALS_Event,
max(filing_date_2) as last_CALS
FROM AD_CALS_iv
group by Company,published_date_time'''

AD_CALS_iv2 = ps.sqldf(sql_query7)

AD_CALS_iv2["published_date_time"] = AD_CALS_iv2["published_date_time"].apply(pd.to_datetime)
AD_CALS_iv2["published_date_time"] = AD_CALS_iv2["published_date_time"].apply(pd.Timestamp.date)
AD_CALS_iv2["last_CALS"] = AD_CALS_iv2["last_CALS"].apply(pd.to_datetime)
AD_CALS_iv2["last_CALS"] = AD_CALS_iv2["last_CALS"].apply(pd.Timestamp.date)
AD_CALS_iv2['time_from_last_cals'] =(AD_CALS_iv2['published_date_time'] - AD_CALS_iv2['last_CALS']).astype('timedelta64[D]').astype('int')
AD_CALS_iv2 = AD_CALS_iv2.drop(['filing_date_2','last_CALS'],axis = 1)
AD_raw = pd.merge(AD_raw,AD_CALS_iv2,how = 'left', left_on = ('Company','published_date_time'),
              right_on = ('Company', 'published_date_time'))


# Merging all dv's to AD
AD_raw = pd.merge(AD_raw,data8,how = 'left',left_on = ['Company','published_date_time'],
right_on =['Company','published_date_time'] )

#==============================================================================
if merge_w:
    AD_raw = pd.concat([pd.read_csv(merge_w), AD_raw], axis=0)

AD_raw.to_csv(op_ad_filepath, index = False)
