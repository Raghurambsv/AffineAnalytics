

# Import libraries

import pandas as pd
import pandasql as ps
import datetime
import numpy as np

## Defining function to get the features from yahoo financial data

# Standard deviation of price/avg(price)
def relative_standard_dev(ip_list):
    ip_avg_val = np.mean(ip_list)
    mod_relative_list = list(map(lambda x: x/ip_avg_val, ip_list))
    return np.std(mod_relative_list)

# % Change in the quarter (Need Confirmation)
def perc_change_over_period(ip_list):
    ip_avg_val = np.mean(ip_list)
    perc_change = (ip_list[-1] - ip_list[0])/ip_avg_val
    return perc_change

# Days when price increased compared to previous
def days_gained_over_prev(ip_list):
    print(ip_list)
    counter = sum([1 if x[0]<=x[1] else 0 for x in zip(ip_list[:-1],ip_list[1:])])
    return counter

# Days when price decreased compared to previous
def days_lost_over_prev(ip_list):
    print(ip_list)
    counter = sum([1 if x[1]<x[0] else 0 for x in zip(ip_list[:-1],ip_list[1:])])
    return counter

# Min Stock Price : avg stick price
def min_to_avg_ratio(ip_list):
    ip_avg_val = np.mean(ip_list)
    return np.min(ip_list)/ip_avg_val

# Max Stock Price: avg stock price
def max_to_avg_ratio(ip_list):
    ip_avg_val = np.mean(ip_list)
    return np.max(ip_list)/ip_avg_val

# Gain Ratio
def gain_ratio(ip_list):
    gain = days_gained_over_prev(ip_list)
    loss = days_lost_over_prev(ip_list)
    return gain/(gain+loss)

# Loss Ratio
def loss_ratio(ip_list):
    gain = days_gained_over_prev(ip_list)
    loss = days_lost_over_prev(ip_list)
    return loss/(gain+loss)

# Get slope of moving average
def perc_change_moving_average(ip_list):
    new_list = [np.mean(ip_list[:i+1]) for i in range(len(ip_list))]
    return (new_list[-1]-new_list[0])/new_list[0]

# Get average % one return
def average_perc_daily_return(ip_list):
    new_list = [(x[1]/x[0]) - 1 for x in zip(ip_list[:-1],ip_list[1:])]
    return np.mean(new_list)

# Average upward price change abs
def average_upward_price_change(ip_list, op_type = 'ABS'):
    new_list = [(x[1] - x[0]) for x in zip(ip_list[:-1],ip_list[1:]) if x[1] >= x[0]]
    if (str.upper(op_type) == 'ABS'):
        return np.mean(new_list)
    else:
        return np.mean(new_list)/np.mean(ip_list)

# Average downward price change abs
def average_downward_price_change(ip_list, op_type = 'ABS'):
    new_list = [(x[0] - x[1]) for x in zip(ip_list[:-1],ip_list[1:]) if x[1] < x[0]]
    if (str.upper(op_type) == 'ABS'):
        return np.mean(new_list)
    else:
        return np.mean(new_list)/np.mean(ip_list)

# Get RSI Index
def rsi_index(ip_list):
    return 100 - (100/(1 + average_upward_price_change(ip_list)/average_downward_price_change(ip_list)))

# To get the date of any form from a string
def get_date(date,form):
    return datetime.datetime.strptime(date, form).date()

# To add a time delta to a given date
def add_delta(ts,days):
    offset = datetime.timedelta(days=days)
    delta = pd.Timedelta(offset)
    ts = ts-delta
    return ts

# To get the stock price features added to Analytical Dataset
def generate_stock_features(df,stock_prices):
    AD = df[["Company","date_earning_call"]]
    # Converting inti date format
    AD['Date_before_90_days'] = AD['date_earning_call'].apply(add_delta,days=90)
    # Getting the maximum date for extracting stock data
    max_stock_date = AD['date_earning_call'].max()
    # Getting the minimum data for extracting stock data
    min_stock_date = AD['Date_before_90_days'].min()
    # Removing empty records
    stock_prices = stock_prices.dropna(axis=0, subset=['close'])
    # Getting the list of all the companies for which we have to extract the stock features
    required_set_companies = list(set(AD['Company']))
    # Renaming columns
    stock_prices.rename(columns={'Company Input': 'Company'},inplace=True)
    # Filtering the stock price data for only required companies
    stock_prices = stock_prices[stock_prices['Company'].isin(required_set_companies)]
    # Converting date format
    stock_prices["stock_date"] = stock_prices["date"].apply(get_date,form='%Y-%m-%d %H:%M:%S')
    # Filtering the stock data for required time period
    stock_prices = stock_prices[(stock_prices['stock_date']>=min_stock_date)
                                & (stock_prices['stock_date']<=max_stock_date)]
    query = '''select AD.Company,AD.date_earning_call,
    stock_prices.stock_date,stock_prices.open,stock_prices.close,stock_prices.high,
    stock_prices.low,stock_prices.volume
    from AD inner join stock_prices on AD.Date_before_90_days<=stock_prices.stock_date 
    and AD.date_earning_call>=stock_prices.stock_date 
    and AD.Company=stock_prices.Company'''
    
    
    # Getting the required stock prices for generating features against each transcript
    ref = ps.sqldf(query)
    # Renaming columns
    ref.rename(columns = {'open':'opening_price', 'close':'closing_price', 'high':'highest_price', 'low':'lowest_price', 'volume':'trade_volume'}, inplace=True)
    ref['key'] = ref['Company']+'-'+ref['date_earning_call']
    # Generating all the features
    agg_chart_price_q = ref.sort_values(by=['Company', 'stock_date']).groupby(['key']).agg({'opening_price':lambda x:list(x), 'closing_price':lambda x:list(x), 'highest_price':lambda x:list(x), 'lowest_price':lambda x:list(x), 'trade_volume':lambda x:list(x)})
    agg_chart_price_q['rsi_index'] = agg_chart_price_q['closing_price'].apply(rsi_index)
    agg_chart_price_q['average_perc_daily_return'] = agg_chart_price_q['closing_price']\
        .apply(average_perc_daily_return)
    agg_chart_price_q['perc_change_moving_average_cp'] = agg_chart_price_q['closing_price']\
        .apply(perc_change_moving_average)
    agg_chart_price_q['perc_change_moving_average_op'] = agg_chart_price_q['opening_price']\
        .apply(perc_change_moving_average)
    agg_chart_price_q['perc_change_moving_average_h'] = agg_chart_price_q['highest_price']\
        .apply(perc_change_moving_average)
    agg_chart_price_q['perc_change_moving_average_l'] = agg_chart_price_q['lowest_price']\
        .apply(perc_change_moving_average)
    agg_chart_price_q['gain_ratio_cp'] = agg_chart_price_q['closing_price']\
        .apply(gain_ratio)
    agg_chart_price_q['gain_ratio_op'] = agg_chart_price_q['opening_price']\
        .apply(gain_ratio)
    agg_chart_price_q['gain_ratio_h'] = agg_chart_price_q['highest_price']\
        .apply(gain_ratio)
    agg_chart_price_q['gain_ratio_l'] = agg_chart_price_q['lowest_price']\
        .apply(gain_ratio)
    agg_chart_price_q['loss_ratio_cp'] = agg_chart_price_q['closing_price']\
        .apply(loss_ratio)
    agg_chart_price_q['loss_ratio_op'] = agg_chart_price_q['opening_price']\
        .apply(loss_ratio)
    agg_chart_price_q['loss_ratio_h'] = agg_chart_price_q['highest_price']\
        .apply(loss_ratio)
    agg_chart_price_q['loss_ratio_l'] = agg_chart_price_q['lowest_price']\
        .apply(loss_ratio)
    agg_chart_price_q['max_to_avg_ratio_cp'] = agg_chart_price_q['closing_price']\
        .apply(max_to_avg_ratio)
    agg_chart_price_q['max_to_avg_ratio_op'] = agg_chart_price_q['opening_price']\
        .apply(max_to_avg_ratio)
    agg_chart_price_q['max_to_avg_ratio_h'] = agg_chart_price_q['highest_price']\
        .apply(max_to_avg_ratio)
    agg_chart_price_q['max_to_avg_ratio_l'] = agg_chart_price_q['lowest_price']\
        .apply(max_to_avg_ratio)
    agg_chart_price_q['min_to_avg_ratio_cp'] = agg_chart_price_q['closing_price']\
        .apply(min_to_avg_ratio)
    agg_chart_price_q['min_to_avg_ratio_op'] = agg_chart_price_q['opening_price']\
        .apply(min_to_avg_ratio)
    agg_chart_price_q['min_to_avg_ratio_h'] = agg_chart_price_q['highest_price']\
        .apply(min_to_avg_ratio)
    agg_chart_price_q['min_to_avg_ratio_l'] = agg_chart_price_q['lowest_price']\
        .apply(min_to_avg_ratio)
    agg_chart_price_q['perc_change_over_period_cp'] = agg_chart_price_q['closing_price']\
        .apply(perc_change_over_period)
    agg_chart_price_q['perc_change_over_period_op'] = agg_chart_price_q['opening_price']\
        .apply(perc_change_over_period)
    agg_chart_price_q['perc_change_over_period_h'] = agg_chart_price_q['highest_price']\
        .apply(perc_change_over_period)
    agg_chart_price_q['perc_change_over_period_l'] = agg_chart_price_q['lowest_price']\
        .apply(perc_change_over_period)
    agg_chart_price_q['relative_standard_dev_cp'] = agg_chart_price_q['closing_price']\
        .apply(relative_standard_dev)
    agg_chart_price_q['relative_standard_dev_op'] = agg_chart_price_q['opening_price']\
        .apply(relative_standard_dev)
    agg_chart_price_q['relative_standard_dev_h'] = agg_chart_price_q['highest_price']\
        .apply(relative_standard_dev)
    agg_chart_price_q['relative_standard_dev_l'] = agg_chart_price_q['lowest_price']\
        .apply(relative_standard_dev)
    agg_chart_price_q.reset_index(inplace=True)
    return agg_chart_price_q

