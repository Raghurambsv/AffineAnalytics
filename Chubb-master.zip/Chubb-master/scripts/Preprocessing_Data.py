#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 20 10:32:15 2018

@author: affine
"""

import pandas as pd
from fuzzywuzzy import fuzz
import re
import nltk
from utils import get_date_from_preamble

def get_company_name(transcript_head):
    #head = re.split('[\'\.\,\-\–\!\&\*\s\(\)]', transcript_head)[0].strip()
    return([w.lower() for w in nltk.word_tokenize(transcript_head) if w.lower() not in ['the']][0])

def clean(text):
    r = r"[.]|\'s|\-"    
    return re.split(r,text)[0]

def fuzzy_match_score(row):
    try:
        return (fuzz.partial_ratio( str(row["About"]).lower(), str(row["clean_head1"])))
    except:
        pass
def fuzzy_match_score_head(row):
    return (fuzz.partial_ratio( str(row["about_head"]).lower(), str(row["clean_head1"])))
    
def preprocessing(data_raw,req_cols):
    data = data_raw.drop_duplicates()
    data = data[~data['Preamble'].isnull()]
	## Extract the date from preamble section of transcript
    data['date_earning_call'] = data.apply( lambda x: get_date_from_preamble(x['Preamble'], x['Date published'], print_error=True), axis=1)
    data["published_date_time"] = data["Date published"].apply(pd.to_datetime)
    data['date_earning_call_str'] = [str(i) for i in list(data['date_earning_call'])]
    data['key'] = data['input company name'] + data['date_earning_call_str']
    ## Count the number of transcripts at key level 
    data['Count'] = data.groupby('key')['key'].transform('count')
    data['max_published_date'] = data.groupby(['key'])['published_date_time'].transform('max')
    if len(data[data['Count']>1 ])>0:
        data_temp = data[data['Count']>1 ]
        ## Remove the duplicate transcripts based on latest published date
        data_temp2 = data_temp[data_temp['published_date_time'] == data_temp['max_published_date']]
        data_temp1 = data[data['Count']==1]
        data = data_temp1.append(data_temp2,ignore_index =True)
        
    unique_key = data[['input company name','About']].drop_duplicates()
    unique_key =unique_key[~unique_key['About'].isnull()]
    data6 = data
    data6 = data6.drop(['About'],axis = 1)
    data6 = pd.merge(data6,unique_key, how ='left', left_on = 'input company name',right_on = 'input company name' )
    data6['clean_head'] = data6['Transcript page heading'].apply(get_company_name)
    data6['clean_head1'] = data6['clean_head'].apply(clean)
    
    data6['count_comp'] = data6.groupby('input company name')['clean_head1'].transform('nunique')
    data7_temp1 = data6[data6['count_comp']==1]
    data7_temp2 = data6[data6['count_comp']>1]
    if len(data7_temp2)==0:
        req_cols=['input company name', 'About', 'Transcript page heading',
           'Transcript heading', 'Preamble','transcript after preamble',  'date_earning_call','date_earning_call_str']
        final =data6[req_cols]
    else:
        data7_temp2['score'] = data7_temp2.apply(fuzzy_match_score,axis =1)
        data7_temp5 = data7_temp2[(data7_temp2['score']>70) & (data7_temp2['score']!=100)]

        data7_temp3 = data7_temp2[data7_temp2['score']==100]
        data7_temp3['count_comp2'] = data7_temp3.groupby('input company name')['clean_head1'].transform('nunique')
        data7_temp4 = data7_temp3[data7_temp3['count_comp2']>1]
        data7_temp6 = data7_temp3[data7_temp3['count_comp2']==1]
        if len(data7_temp4)==0:
            req_cols=['input company name', 'About', 'Transcript page heading',
           'Transcript heading', 'Preamble','transcript after preamble',  'date_earning_call','date_earning_call_str']
            final = data7_temp1[req_cols].append([data7_temp5[req_cols],data7_temp6[req_cols]])
        else:
            data7_temp4['about_head'] = data7_temp4['About'].apply(get_company_name)
            data7_temp4['score_2'] = data7_temp4.apply(fuzzy_match_score_head,axis =1)
            data7_temp4 = data7_temp4[data7_temp4['score_2']>60]
            req_cols=['input company name', 'About', 'Transcript page heading',
           'Transcript heading', 'Preamble','transcript after preamble',  'date_earning_call','date_earning_call_str']
            final = data7_temp1[req_cols].append([data7_temp5[req_cols],data7_temp4[req_cols],data7_temp6[req_cols]])
    return(final)


