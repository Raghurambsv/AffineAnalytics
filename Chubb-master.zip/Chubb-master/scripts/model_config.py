import os
import datetime
## Directory
data_path = '/media/affine/New Volume/Chubb/Github/Chubb_local/data'

## Path to read AD 
AD_filepath = os.path.join(data_path, 'AD_with_only_overall_Features.csv')

# Mapping File of variables and their respective flags
IV_Groups_path =  os.path.join(data_path,'Variable_Bucket_v1.csv')

# Cutoff for Feature Importance in RF (Cumulative sum of feature importance of variables should have minimum of 90%)
importance_cutoff = 0.9

# Cutoff for aggregated variance in PCA (It should be greater than or equal to 80%)
variance_cutoff = 0.8

# ip_path = '/media/affine/New Volume/Chubb/Github/Chubb/data/AD'
op_path = os.path.join(data_path,'results/')

## Select the required variables by selecting their respective groups
req_groups = { 'Freq_C', 'Freq_P', 'Freq_QA',
         'R_C', 'R_P', 'R_QA',
           'STOCK',
         'S_C', 'S_P', 'S_QA',
         'Size_C', 'Size_P', 'Size_QA'}

# Select Dependent variable based on required model
dv2 = 'is_cals_90'               

# Out of Time Prediction
outof_time = datetime.datetime(2018, 4, 1)

# Condition to run execute grid search or not
run_grid_search = False


XGB_parameters_fixed = dict(base_score=0.5,
    booster='gbtree',
    child_weight=1,
    colsample_bylevel=1,
    eta=0.1,
    eval_metric='mlogloss',
    max_delta_step=1,
    min_child_weight=1,
    n_jobs=-1,
    nthread=16,
    num_class=2,
    objective='multi:softprob',
    random_state=0,
    reg_lambda=1,
    scale_pos_weight=1,
    seed=0,
    silent=1)

## Best Parameters for each model 
params = dict(Healthcare=dict(n_estimators=500,colsample_bytree=0.4,gamma=0.1,max_depth=5,
                              reg_alpha=6,subsample=0.2),
Finance = dict(n_estimators=500,colsample_bytree=0.4,gamma=0.2,
               max_depth=5,reg_alpha=6,subsample=0.2),
BasicMat_ConsumerDefen = dict(n_estimators=500,colsample_bytree=0.3,gamma=0.5,
        max_depth=5,reg_alpha=6,subsample=0.3),
Tech_Industry = dict(n_estimators=300,colsample_bytree=0.5,gamma=0.3,
                     max_depth=5,reg_alpha=5,subsample=0.2), 
Remaining_Sector= dict(n_estimators=300,colsample_bytree=0.2,gamma=0.1,
                       max_depth=4,reg_alpha=5,subsample=0.1))


# Path to save the models
op_bucket_filepath = "../results/buckets.pic"
op_model_filepath = "../results/model.pic"

## Grouping of sectors 
sector_dict = {'Healthcare' :['Healthcare'],
'Finance' :['Financial Services'],
'Tech_Industry' :['Industrials','Technology'],
'BasicMat_ConsumerDefen' :['Basic Materials','Consumer Defensive'],
'Remaining_Sector' :[]}

