import requests
import time
from time import strftime
import csv
import random
import sys
import logging


def add_sleep_time(short=False):
    """
    Adds the sleep time.
    :param short: boolean OPTIONAL parameter
    """
    if short:
        delay = float("{0:.2f}".format(random.uniform(0, 0.5)))
    else:
        delay = float("{0:.2f}".format(random.uniform(0.5, 3)))
    logger.info("applying " + str(delay) + " seconds delay")
    time.sleep(delay)


if __name__ == '__main__':
    main_folder='../data/yahoo_input'
    log_folder_path=main_folder+'/log'
    ProgramStartTime = strftime("%Y%m%d %H:%M:%S")
    # set up logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    consoleHandler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s  - %(levelname)s - %(message)s')
    consoleHandler.setFormatter(formatter)
    logger.addHandler(consoleHandler)
    handler = logging.FileHandler(log_folder_path + '/yahoo_chart_-' + strftime("%Y%m%d-%H-%M-%S") + '.log')
    handler.setLevel(logging.INFO)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    #create output file and write header
    summary_file_writer = csv.writer(open(main_folder+'/output/yahoo_chart_'+strftime("%Y%m%d-%H-%M-%S")+".csv", 'w',newline=''))
    summary_file_writer.writerow(['Company Input','date', "open", "close", 'high', 'low', 'volume'])
    # read tickers from file
    input_file = open(main_folder+'/input/chart_tickers','rb')

    for line_counter,line in enumerate(input_file):
        logger.info(str(line_counter)+'->'+line.strip())
        company_name=line.strip()
        # setting up epoch which is a parameter to URL
        pattern='%Y%m%d %H:%M:%S'
        epoch=int(time.mktime(time.strptime(strftime(pattern), pattern)))

        url_to_hit_summary = 'https://query1.finance.yahoo.com/v8/finance/chart/'\
                    +company_name+'?symbol='+company_name+'&period1=-712663017&period2='\
                    +str(epoch)+'&interval=1d&includePrePost=true'\
                    +'&events=div%7Csplit%7Cearn&lang=en-US&region=US&crumb=T%2FVzxU8ccFr&corsDomain=finance.yahoo.com'
        # hit url
        response = requests.get(url_to_hit_summary,timeout=30)
        #get and parse JSON, convert timestamps from epoch
        chart_json = response.json()['chart']['result'][0]
        quotes = chart_json['indicators']['quote'][0]
        timestamps_epoch = chart_json['timestamp']
        timestamps = [time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(i)) for i in timestamps_epoch]
        # write results in order
        for price_list in zip(timestamps,quotes['open'],quotes['close'],quotes['high'],quotes['low'],quotes['volume']):
            summary_file_writer.writerow([company_name]+list(price_list))
        add_sleep_time()
    input_file.close()
