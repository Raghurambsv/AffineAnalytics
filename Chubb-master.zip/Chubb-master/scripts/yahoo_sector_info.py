import requests
import time
from time import strftime
import csv
import random
import logging
import sys


def add_sleep_time(short=False):
    """
    Adds the sleep time.
    :param short: boolean OPTIONAL parameter
    """
    if short:
        delay = float("{0:.2f}".format(random.uniform(0, 0.2)))
    else:
        delay = float("{0:.2f}".format(random.uniform(0.1, 2)))
    logger.info("applying " + str(delay) + " seconds delay")
    time.sleep(delay)


def parse_summary(json_raw):
    """
    This function parses summary page's  JSON response
    output: list of parsed values from website source(JSON)
    """
    summary_json = json_raw['quoteResponse']['result'][0]
    summary_json_message_board_id,summary_json_quote_type,summary_json_quote_type='','',''
    summary_json_long_name,summary_json_market,summary_json_exchange_timezone_name='','',''
    summary_json_uuid,summary_json_exchange,summary_json_full_exchange_name='','',''
    summary_json_symbol,summary_json_region='', ''
    if 'messageBoardId' in summary_json:
        summary_json_message_board_id=summary_json['messageBoardId']
    if 'quoteType' in summary_json:
        summary_json_quote_type=summary_json['quoteType']
    if 'currency' in summary_json:
        summary_json_currency=summary_json['currency']
    if 'longName' in summary_json:
        summary_json_long_name=summary_json['longName']
    if 'market' in summary_json:
        summary_json_market=summary_json['market']
    if 'exchangeTimezoneName' in summary_json:
        summary_json_exchange_timezone_name=summary_json['exchangeTimezoneName']

    if 'uuid' in summary_json:
        summary_json_uuid=summary_json['uuid']
    if 'exchange' in summary_json:
        summary_json_exchange=summary_json['exchange']
    if 'fullExchangeName' in summary_json:
        summary_json_full_exchange_name=summary_json['fullExchangeName']
    if 'symbol' in summary_json:
        summary_json_symbol=summary_json['symbol']
    if 'region' in summary_json:
        summary_json_region=summary_json['region']
    summary_json_market_cap_raw,summary_json_market_cap_formated,summary_json_market_cap_long_formated='','',''
    if 'marketCap' in summary_json:
        summary_json_market_cap_raw= str(summary_json['marketCap']['raw'])
        summary_json_market_cap_formated= summary_json['marketCap']['fmt']
        summary_json_market_cap_long_formated= summary_json['marketCap']['longFmt']
    return [summary_json_symbol,summary_json_market_cap_raw,summary_json_market_cap_formated,summary_json_market_cap_long_formated,summary_json_message_board_id, summary_json_quote_type, summary_json_currency, summary_json_long_name, summary_json_market,
            summary_json_exchange_timezone_name, summary_json_uuid, summary_json_exchange, summary_json_full_exchange_name,
            summary_json_region]


def parse_profile(json_raw,comany_name_input):
    """
    This function parses profile page's  JSON response
    output: list of parsed values from website source(JSON)
    """
    if json_raw['quoteSummary']['result'] is None:
        return []
    if 'assetProfile' not in json_raw['quoteSummary']['result'][0]:
        return []
    profile_json = json_raw['quoteSummary']['result'][0]['assetProfile']
    if 'website' in profile_json:
        profile_json_website = profile_json['website']
    else:
        profile_json_website = ''
    if 'city' in profile_json:
        profile_json_city = profile_json['city']
    else:
        profile_json_city = ''
    if 'zip' in profile_json:
        profile_json_zip = profile_json['zip']
    else:
        profile_json_zip =''
    if 'sector' in profile_json:
        profile_json_sector = profile_json['sector']
    else:
        profile_json_sector = ''
    if 'address1' in profile_json:
        profile_json_address1 = profile_json['address1']
    else:
        profile_json_address1 = ''
    if 'industry' in profile_json:
        profile_json_industry = profile_json['industry']
    else:
        profile_json_industry = ''

    if 'overallRisk' in profile_json:
        profile_json_overall_risk = profile_json['overallRisk']
    else:
        profile_json_overall_risk = ''

    if 'maxAge' in profile_json:
        profile_json_max_age = profile_json['maxAge']
    else:
        profile_json_max_age = ''

    if 'phone' in profile_json:
        profile_json_phone = profile_json['phone']
    else:
        profile_json_phone = ''

    if 'state' in profile_json:
        profile_json_state = profile_json['state']
    else:
        profile_json_state = ''
    if 'governanceEpochDate' in profile_json:
        profile_json_governance_date = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(profile_json['governanceEpochDate']))
    else:
        profile_json_governance_date = ''
    if 'industrySymbol' in profile_json:
        profile_json_industry_symbol = profile_json['industrySymbol']
    else:
        profile_json_industry_symbol = ''
    if 'fullTimeEmployees' in profile_json:
        profile_json_full_time_employees = profile_json['fullTimeEmployees']
    else:
        profile_json_full_time_employees = ''
    if 'country' in profile_json:
        profile_json_country = profile_json['country']
    else:
        profile_json_country =''
    if 'boardRisk' in profile_json:
        profile_json_board_risk = profile_json['boardRisk']
    else:
        profile_json_board_risk = ''
    if 'auditRisk' in profile_json:
        profile_json_audit_risk = profile_json['auditRisk']
    else:
        profile_json_audit_risk = ''
    if 'compensationRisk' in profile_json:
        profile_json_compensation_risk = profile_json['compensationRisk']
    else:
        profile_json_compensation_risk = ''
    if 'compensationAsOfEpochDate' in profile_json:
        profile_json_compensation_as_of_date = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(profile_json['compensationAsOfEpochDate']))
    else:
        profile_json_compensation_as_of_date = ''

    if 'shareHolderRightsRisk' in profile_json:
        profile_json_share_holder_rights_risk = profile_json['shareHolderRightsRisk']
    else:
        profile_json_share_holder_rights_risk = ''

    if 'secFilings' in json_raw['quoteSummary']['result'][0] :
        for sec_json in json_raw['quoteSummary']['result'][0]['secFilings']['filings']:
            sec_title=sec_json['title']
            sec_url=sec_json['url']
            sec_max_age=sec_json['maxAge']
            sec_edgar_url=sec_json['edgarUrl']
            sec_date=sec_json['date']
            sec_type=sec_json['type']
            sec_file_writer.writerow([comany_name_input,sec_title, sec_url, sec_max_age, sec_edgar_url, sec_date, sec_type])
    return [profile_json_industry,profile_json_industry_symbol,profile_json_sector,
            profile_json_overall_risk,profile_json_audit_risk,profile_json_compensation_risk, profile_json_board_risk,
            profile_json_share_holder_rights_risk,profile_json_max_age, profile_json_full_time_employees,
            profile_json_address1, profile_json_city, profile_json_zip,
            profile_json_phone,profile_json_state,profile_json_country,profile_json_governance_date,
            profile_json_compensation_as_of_date,profile_json_website]


if __name__ == '__main__':
    main_folder = '../data/sector_input'
    log_folder_path=main_folder+'/log'
    ProgramStartTime = strftime("%Y%m%d %H:%M:%S")
    # set logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    consoleHandler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s  - %(levelname)s - %(message)s')
    consoleHandler.setFormatter(formatter)
    logger.addHandler(consoleHandler)
    handler = logging.FileHandler(log_folder_path + '/yahoo_finance_-' + strftime("%Y%m%d-%H-%M-%S") + '.log')
    handler.setLevel(logging.INFO)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    # create output file & write header row
    summary_file_writer = csv.writer(open(main_folder+'/output/yahoo_summary_'+strftime("%Y%m%d-%H-%M-%S")+".csv", 'w',newline=''))
    summary_file_writer.writerow(['Company Input','Symbol',"Industry", "Industry Symbol", "Sector", "Overall Risk", "Audit Risk", "Compensation Risk",
                                  "Board Risk", "Share Holder Rights Risk", "Max Age", "Full Time Employees", "Address1",
                                  "City", "Zip", "Phone", "State", "Country", "Governance Date", "Compensation As Of Date",
                                  "Website", "Market Cap Raw", "Market Cap Formated", "Market Cap Long Formated",
                                  "Message Board Id", "Quote Type", "Currency", "Long Name", "Market",
                                  "Exchange Timezone Name", "Uuid", "Exchange", "Full Exchange Name", "Region"])
    sec_file_writer = csv.writer(open(main_folder+'/output/yahoo_sec_'+strftime("%Y%m%d-%H-%M-%S")+".csv", 'w',newline=''))
    sec_file_writer.writerow(["Company Name Input", "SEC Title", "SEC URL", "SEC  Max Age", "SEC Edgar Url", "SEC Date", "SEC Type"])

    # read the ticker(each ticker in one line) from file
    input_file = open(main_folder+'/input/input_tickers','r')

    for line_counter, line in enumerate(input_file):
        # if ticker is invalid
        if ' ' in line.strip():
            logger.info('skipping'+line.strip())
            continue

        logger.info(str(line_counter)+'->'+line.strip())
        company_name = line.strip()


        url_to_hit_profile='https://query2.finance.yahoo.com/v10/finance/quoteSummary/' + \
                           company_name+'?formatted=true&crumb=T%2FVzxU8ccFr&lang=en-US&region=US&modules=assetProfile%2CsecFilings&corsDomain=finance.yahoo.com'
        # hit url to get chart data
        response = requests.get(url_to_hit_profile, timeout=30)
        profile_list = parse_profile(response.json(), company_name)
        # for some companies profile data might not be available
        if not profile_list:
            logger.info('Profile data not available for this company')
            continue
        # get summary page data
        url_to_hit_summary = 'https://query1.finance.yahoo.com/v7/finance/quote?formatted=true&crumb=T%2FVzxU8ccFr&lang=en-US&region=US&symbols='+ \
                             company_name+'&fields=messageBoardId%2ClongName%2CshortName%2CmarketCap%2CunderlyingSymbol%2CunderlyingExchangeSymbol%2CheadSymbolAsString%2CregularMarketPrice%2CregularMarketChange%2C'+ \
                             'regularMarketChangePercent%2CregularMarketVolume%2Cuuid%2CregularMarketOpen%2CfiftyTwoWeekLow%2CfiftyTwoWeekHigh&corsDomain=finance.yahoo.com'

        response = requests.get(url_to_hit_summary, timeout=30)
        summary_list = parse_summary(response.json())
        summary_file_writer.writerow([company_name, summary_list[0]]+profile_list+summary_list[1:])
        add_sleep_time()
    input_file.close()
