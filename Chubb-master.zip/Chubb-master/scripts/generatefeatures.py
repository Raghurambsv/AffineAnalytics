
import pandas as pd
import pandas as pd
import textstat
import re
from textstat.textstat import textstat
import pysentiment as ps
from nltk.corpus import stopwords
import numpy as np
from nltk.sentiment.vader import SentimentIntensityAnalyzer

from utils import TextUtils


class GenerateFeatures:
    
    def __init__(self, textutils, lm_filepath='data/LM.csv'):
        self.lm_df = pd.read_csv(lm_filepath)
        self.pos_l = self.lm_df.loc[(self.lm_df['Positive'] != 0)]['Word'].str.lower()
        self.neg_l = self.lm_df.loc[(self.lm_df['Negative'] != 0)]['Word'].str.lower()
        self.unc_l = self.lm_df.loc[(self.lm_df['Uncertainty'] != 0)]['Word'].str.lower()
        self.lit_l = self.lm_df.loc[(self.lm_df['Litigious'] != 0)]['Word'].str.lower()
        self.cons_l = self.lm_df.loc[(self.lm_df['Constraining'] != 0)]['Word'].str.lower()
        self.sup_l = self.lm_df.loc[(self.lm_df['Superfluous'] != 0)]['Word'].str.lower()
        self.int_l = self.lm_df.loc[(self.lm_df['Interesting'] != 0)]['Word'].str.lower()
        self.strong_mod_l = list(self.lm_df.loc[(self.lm_df['Modal'] == 1)]['Word'].str.lower())
        self.mid_mod_l = self.lm_df.loc[(self.lm_df['Modal'] == 2)]['Word'].str.lower()
        self.weak_mod_l =self.lm_df.loc[(self.lm_df['Modal'] == 3)]['Word'].str.lower()# no binary as it has got 3 intensity categories (1,2,3) + 0
        self.irv_l = self.lm_df.loc[(self.lm_df['Irr_Verb'] != 0)]['Word'].str.lower()
        self.textutils = textutils
        self.analyzer = SentimentIntensityAnalyzer() 
        self.lmanalyser = ps.LM()
        self.hiv4analyser = ps.HIV4()

    def generate_features(self, text):
        words = self.textutils.tokenize(text) 
        words = list(map(lambda x: x.lower(), words))
        n_words = textstat.lexicon_count(text)
        count_pos_words = len([w for w in words if w in list(self.pos_l)])
        count_neg_words = len([w for w in words if w in list(self.neg_l)])
        count_unc_words = len([w for w in words if w in list(self.unc_l)])
        count_lit_words = len([w for w in words if w in list(self.lit_l)])
        count_cons_words = len([w for w in words if w in list(self.cons_l)])
        count_sup_words = len([w for w in words if w in list(self.sup_l)])
        count_interesting_words = len([w for w in words if w in list(self.int_l)])
        count_strong_modals = len([w for w in words if w in list(self.strong_mod_l)])
        count_mid_modals = len([w for w in words if w in list(self.mid_mod_l)])
        count_weak_modals = len([w for w in words if w in list(self.weak_mod_l)])
        count_irreg_verbs = len([w for w in words if w in list(self.irv_l)])
        n_lm_words = count_pos_words+count_neg_words+count_unc_words+count_lit_words+count_cons_words+count_sup_words\
                    +count_interesting_words+count_strong_modals+count_mid_modals+count_weak_modals+count_irreg_verbs
        vs = self.analyzer.polarity_scores(text)
        lm_score = self.lmanalyser.get_score(words)
        hiv4_score = self.hiv4analyser.get_score(words)
        features = {
            'size': n_words,
            'n_syllables': textstat.syllable_count(text),
            'n_sents': textstat.sentence_count(text),
            'flesch_reading_ease': 100 - textstat.flesch_reading_ease(text),
            'dale_chall_readability_score': textstat.dale_chall_readability_score(text),
            'difficult_words': textstat.difficult_words(text),
            'smog_grade_index': textstat.smog_index(text),
            'flesch_kincaid_grade': textstat.flesch_kincaid_grade(text),
            'coleman_liau_index': textstat.coleman_liau_index(text),
            'automated_readibility_index': textstat.automated_readability_index(text),
            'linsear_write_formula': textstat.linsear_write_formula(text),
            'gunning_fox': textstat.gunning_fog(text),
            'text_standard': textstat.text_standard(text),
            'vader_negative_score' : vs['neg'],
            'vader_neutral_score' :vs['neu'],
            'vader_positive_score' : vs['pos'],
            'vader_compound_score' :vs['compound'],
            'padding': len(set(words).intersection(set(self.textutils.stopwords)))/n_words,
            'lm_score_polarity': lm_score['Polarity'],
            'lm_score_subjectivity': lm_score['Subjectivity'],
            'lm_score_postive': lm_score['Positive'],
            'lm_score_negative': lm_score['Negative'],
            'hiv4_score_polarity': hiv4_score['Polarity'],
            'hiv4_score_subjectivity': hiv4_score['Subjectivity'],
            'hiv4_score_postive': hiv4_score['Positive'],
            'hiv4_score_negative': hiv4_score['Negative'],
        }
        
        try:
            features['positive_frequency']= count_pos_words / n_words
            features['negative_frequency']= count_neg_words / n_words
            features['uncertainty_frequency']= count_unc_words/ n_words
            features['litigious_frequency']= count_lit_words / n_words
            features['constraint_frequency']= count_cons_words / n_words
            features['superflous_frequency']= count_sup_words / n_words
            features['interesting_frequency']= count_interesting_words / n_words
            features['strong_modal_frequency']= count_strong_modals / n_words
            features['mid_modal_frequency']= count_mid_modals / n_words
            features['weak_modal_frequency']= count_weak_modals / n_words
            features['irreg_verbs_frequency']= count_irreg_verbs / n_words
        except ZeroDivisionError as e:
            features['positive_frequency']= 0
            features['negative_frequency']= 0
            features['uncertainty_frequency']= 0
            features['litigious_frequency']= 0
            features['constraint_frequency']= 0
            features['superflous_frequency']= 0
            features['interesting_frequency']= 0
            features['strong_modal_frequency']= 0
            features['mid_modal_frequency']= 0
            features['weak_modal_frequency']= 0
            features['irreg_verbs_frequency']= 0
        try:
            features['positive_frequency_rel']= count_pos_words / n_lm_words
            features['negative_frequency_rel']= count_neg_words / n_lm_words
            features['uncertainty_frequency_rel']= count_unc_words / n_lm_words
            features['litigious_frequency_rel']= count_lit_words / n_lm_words
            features['constraint_frequency_rel']= count_cons_words / n_lm_words
            features['superflous_frequency_rel']= count_sup_words / n_lm_words
            features['interesting_frequency_rel']= count_interesting_words / n_lm_words
            features['strong_modal_frequency_rel']= count_strong_modals / n_lm_words
            features['mid_modal_frequency_rel']= count_mid_modals / n_lm_words
            features['weak_modal_frequency_rel']= count_weak_modals / n_lm_words
            features['irreg_verbs_frequency_rel']= count_irreg_verbs / n_lm_words
        except ZeroDivisionError as e:
            features['positive_frequency_rel']= 0
            features['negative_frequency_rel']= 0
            features['uncertainty_frequency_rel']= 0
            features['litigious_frequency_rel']= 0
            features['constraint_frequency_rel']= 0
            features['superflous_frequency_rel']= 0
            features['interesting_frequency_rel']= 0
            features['strong_modal_frequency_rel']= 0
            features['mid_modal_frequency_rel']= 0
            features['weak_modal_frequency_rel']= 0
            features['irreg_verbs_frequency_rel']= 0
        return features
    
    def generate_sentiment_diff_features(df,sentiment_indices,lvl1,lvl2):
        for index in sentiment_indices:
            df[index+'_difference_'+lvl1+'vs'+lvl2] = df[index+'_'+lvl1]-df[index+'_'+lvl2]
        return df


