import StringIO
from bs4 import BeautifulSoup
import ConfigParser
import csv
import logging
from time import strftime
import time
import random
from selenium import webdriver
import sys
from selenium.common.exceptions import NoSuchElementException


def add_sleep_time(short=False):
    if short:
        delay = float("{0:.2f}".format(random.uniform(0.1, 1)))
    else:
        delay = float("{0:.2f}".format(random.uniform(0.5, 5)))
    logger.info("applying " + str(delay) + " seconds delay")
    time.sleep(delay)


def login():
    """
    This function performce automated login
    :return: True if login successful, False if login fails
    """
    driver.find_element_by_id('sign-in').click()
    time.sleep(5)
    user_name_element = driver.find_element_by_id('authentication_login_email')
    password_element = driver.find_element_by_id('authentication_login_password')
    user_name_element.send_keys(email)
    password_element.send_keys(password)
    time.sleep(2)
    driver.find_element_by_id('authentication_login_button').click()
    try:
        driver.find_element_by_id('authentication_login_email')
        logger.info('Login failed')
        return False
    except NoSuchElementException:
        logger.info("NO login issue")
        return True

if __name__ == '__main__':
    main_folder = '../data/seeking_alpha_input'
    input_file_full_path = sys.argv[2]
    gecko_driver_location = sys.argv[3]
    # set logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    consoleHandler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s  - %(levelname)s - %(message)s')
    consoleHandler.setFormatter(formatter)
    logger.addHandler(consoleHandler)
    handler = logging.FileHandler(main_folder + '/LOG_2/seeking_alpha_get_transcripts-' + strftime("%Y%m%d-%H-%M-%S") + '.log')
    handler.setLevel(logging.INFO)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    # read username,password and other details from file
    rulesFileName = main_folder+'/INPUT/credential_config.properties'
    config = ConfigParser.RawConfigParser()
    config.read(rulesFileName)
    url_to_hit = config.get('siteConfigs', 'main_url')
    email = config.get('siteConfigs', 'user_name')
    company_lists = config.get('siteConfigs', 'company_lists').split(',')
    password = config.get('siteConfigs', 'password')
    # create output file and write header line
    output_file = csv.writer(open(main_folder + '/raw_transcripts/seekingAlpha_transcript_single_page_' + strftime("%Y%m%d-%H-%M-%S")+'.csv', 'w',newline= ''),delimiter='|')
    output_file.writerow(["input company name","About","Transcript page heading","Transcript heading",
                          "Date published",
                          "Preamble","transcript after preamble","Transcript link",'Scraped date'])
    # open browser
    driver = webdriver.Firefox(executable_path=gecko_driver_location)
    driver.get(url_to_hit)
    time.sleep(6)
    if not login():
        logger.info('login failed')
        sys.exit(1)
    time.sleep(5)
    time.sleep(5)
    recaptcha = False
    visited_link = set()
    # read link (step1) file data here
    input_file=open(input_file_full_path, 'rb')
    #read stop links(ticker->first link)
    #store into dict stop_links=dict()

    for counter,line in enumerate(input_file, 1):
        
        line_input = csv.reader(StringIO.StringIO(line)).next()
        company_name = line_input[0]
        #s
        
        transcript_link = line_input[3]
#        if transcript_link == top_links[company_name],strip():
#            break
        # if transcript already scraped, no need to scrape again
        if transcript_link not in visited_link:
            visited_link.add(transcript_link)
        else:
            logger.info("duplicate link skipping:"+str(counter)+": "+transcript_link)
            continue

        logger.info(str(counter)+" company: "+company_name+' current link '+transcript_link.strip())
        if 'earnings-call-transcript' not in transcript_link.lower() and 'earnings-conference-call-transcript' not in transcript_link.lower():
            logger.info('skipping '+transcript_link)
            continue
        # visit single page transcript
        driver.get(transcript_link.strip()+'?part=single')
        add_sleep_time(True)
        try:
            about_text = driver.find_element_by_xpath('//span[@id="about_primary_stocks"]/a[@class="ticker-link"]').text.replace("|",' ').replace('\n',' ').replace("\r",' ').replace('\t',' ').strip()
        except:
            about_text = ''
        # parsing starts here
        soup = BeautifulSoup(driver.page_source, 'lxml')
        # captcha check
        if 'Please click "I am not a robot" to continue' in soup.text:
            logger.info('recaptcha page')
            raw_input()
            soup = BeautifulSoup(driver.page_source,'lxml')

        if 'We have encountered an error' in soup.find('title').text:
            logger.info('500 error sleeping for 1 minute')
            time.sleep(60)
            driver.get(transcript_link.strip()+'?part=single')
            add_sleep_time(True)
            soup = BeautifulSoup(driver.page_source, 'lxml')
        # secondary recaptcha check
        try:
            transcript_page_heading = soup.find('h1',{'itemprop':'headline'}).text.replace("|",' ').replace('\n',' ').replace("\r",' ').replace('\t',' ').strip()
        except:
            logger.info('Secondary Recaptcha test, please enter Recaptcha & enter any key to continue')
            raw_input()
            soup = BeautifulSoup(driver.page_source,'lxml')
        transcript_page_heading=soup.find('h1',{'itemprop':'headline'}).text.replace("|",' ').replace('\n',' ').replace("\r",' ').replace('\t',' ').strip()
        date_published=soup.find('time',{'itemprop':'datePublished'})['content'].replace('T',' ').replace('Z','')

        try:
            transcript_heading = soup.find('div',{'id':'earnings-widget'}).find('div',{'class':'title'}).text.replace("|",' ').replace('\n',' ').replace("\r",' ').replace('\t',' ').strip()
        except:
            transcript_heading = ''
        articles = soup.find('div',{'itemprop':'articleBody'})

        article_string = ''
        preamble = ''
        qna_string = ''
        # below block has logic to separate the preamble from question and answer , not 100% accurate
        for article in articles.find_all('p', {'class' : 'p'}):
            if article.has_attr('id') and 'question-answer-session' in article['id']:
                preamble = article_string
                article_string = ''
            content = article.text.replace("|",' ').replace('\n',' ').replace("\r",' ').replace('\t',' ')
            if article.find('strong'):
                content = ' ~'+article.text.strip() + '~ '

            if article_string.strip():
                article_string = article_string+'^'+content
            else:
                article_string = content

        qna_string = article_string
        write_list = [company_name, about_text, transcript_page_heading, transcript_heading, date_published,
                      preamble, qna_string, transcript_link, strftime("%Y%m%d")]
        output_file.writerow(write_list)
        #add_sleep_time()
