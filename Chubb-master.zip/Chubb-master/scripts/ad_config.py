import os
# AD Creation parameters:
direc = '/media/affine/New Volume/Chubb/Github/Chubb_local/'

## Sector file path
sector_filepath = '../data/sector_input/output/yahoo_summary_20180807.csv'

## Stock price information file path
stock_filepath = '../data/yahoo_input/output/yahoo_chart_price_date.csv'
## CALS data

CALS_data = '../data/stanford_input/output/Stanford CALS Database 0727.csv'

## Input folder
ip_path =  '..data/'

## Path to read raw transcripts
raw_transcripts_filepath = os.path.join(direc,"data/seeking_alpha_input/raw_transcripts/Transcripts_batch1_656.txt")

## Path to save cleaned transcripts
raw_clean_data_otp = os.path.join(direc+'data/Trancripts_Clean_Data/')

## To save the updated AD created by new transcripts and old transcripts
op_ad_filepath = "../data/AD_with_only_overall_Features.csv"

## Condition to join Old AD(else give the name of old AD including the path)
merge_w = None


## Filter the transcripts in required years
sel_year = list(range(2014,2019))

## Create all features considering latest transcripts. 
select_quarters = ['1Q_Back']

