import requests
from bs4 import BeautifulSoup
import time
from time import strftime
import csv
import logging
import sys


if __name__ == '__main__':
    main_folder = '../data/stanford_input'
    log_folder_path = main_folder+'/log'
    ProgramStartTime = strftime("%Y%m%d %H:%M:%S")
    # set up logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    consoleHandler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s  - %(levelname)s - %(message)s')
    consoleHandler.setFormatter(formatter)
    logger.addHandler(consoleHandler)
    handler = logging.FileHandler(log_folder_path + '/stanford_-' + strftime("%Y%m%d-%H-%M-%S") + '.log')
    handler.setLevel(logging.INFO)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    listing_file_writer = csv.writer(open(main_folder+'/output/standford_filing_database_'+strftime("%Y%m%d")+".csv", 'w',newline=''))
    listing_file_writer.writerow(['Filing Name','Filing Date','District Court','Exchange','Ticker'])
    headers = {
            'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Encoding':'gzip, deflate',
            'Accept-Language':'en-US,en;q=0.5',
            'Connection':'keep-alive',
            'DNT':'1',
            'Host':'securities.stanford.edu',
            'Referer':'http://securities.stanford.edu',
            'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36'
            }
    for page_counter in range(1,300):
        # once all pages exhausted, website will start showing page1 results again
        # choose the range end (currently 300) carefully.
        logger.info('page number '+str(page_counter))
        if page_counter == 1:
            url_to_hit='http://securities.stanford.edu/filings.html'
        else:
            url_to_hit='http://securities.stanford.edu/filings.html?page='+str(page_counter)
        response = requests.get(url_to_hit,headers=headers,timeout=30)
        soup_details = BeautifulSoup(response.content, "html.parser")
        logger.info(str(len(soup_details.find('div',{'id':'records'}).find('table').find('tbody').find_all('tr'))))
        for tr_elem in soup_details.find('div',{'id':'records'}).find('table').find('tbody').find_all('tr'):
            filing_name = tr_elem.find_all('td')[0].text.strip()
            filing_date = tr_elem.find_all('td')[1].text.strip()
            district_count = tr_elem.find_all('td')[2].text.strip()
            exchange = tr_elem.find_all('td')[3].text.strip()
            ticker = tr_elem.find_all('td')[4].text.strip()
            listing_file_writer.writerow([filing_name,filing_date,district_count,exchange,ticker])
        time.sleep(2)
