from bs4 import BeautifulSoup
import ConfigParser
import csv
import logging
from time import strftime
import time
import random
import sys
import simplejson
import requests
from selenium import webdriver
import wrapper_helper
from selenium.common.exceptions import NoSuchElementException


def add_sleep_time(short=False):
    if short:
        delay = float("{0:.2f}".format(random.uniform(0.1, 2)))
    else:
        delay = float("{0:.2f}".format(random.uniform(0.5, 4)))
    logger.info("applying " + str(delay) + " seconds delay")
    time.sleep(delay)


def login():
    """
    This function performce automated login
    :return: True if login successful, False if login fails
    """
    driver.find_element_by_id('sign-in').click()
    time.sleep(5)
    user_name_element = driver.find_element_by_id('authentication_login_email')
    password_element = driver.find_element_by_id('authentication_login_password')
    user_name_element.send_keys(email)
    password_element.send_keys(password)
    time.sleep(2)
    driver.find_element_by_id('authentication_login_button').click()
    try:
        driver.find_element_by_id('authentication_login_email')
        logger.info('Login failed')
        return False
    except NoSuchElementException:
        logger.info("NO login issue")
        return True


if __name__ == '__main__':
    main_folder = '../data/seeking_alpha_input'
    gecko_driver_location = sys.argv[2]
    # set logger
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    consoleHandler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s  - %(levelname)s - %(message)s')
    consoleHandler.setFormatter(formatter)
    logger.addHandler(consoleHandler)
    handler = logging.FileHandler(main_folder + '/LOG_1/seeking_alpha_get_links-' + strftime("%Y%m%d-%H-%M-%S") + '.log')
    handler.setLevel(logging.INFO)
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    # read credentials from input file
    rulesFileName=main_folder+'/INPUT/credential_config.properties'
    config = ConfigParser.RawConfigParser()
    config.read(rulesFileName)
    url_to_hit = config.get('siteConfigs', 'main_url')
    email = config.get('siteConfigs', 'user_name')
    company_lists = config.get('siteConfigs', 'company_lists').split(',')
    password = config.get('siteConfigs', 'password')
    # create output file & write header line
    output_file = csv.writer(open(main_folder + '/output/seekingAlpha_links' + strftime("%Y%m%d-%H-%M-%S")+'.csv', 'w',newline = ''))
    output_file.writerow(['Company Symbol','transcript name','date','link','Scraped date'])
    # open broswer,login and get cookies
    driver=webdriver.Firefox(executable_path=gecko_driver_location)
    driver.get(url_to_hit)
    time.sleep(6)
    if not login():
        logger.info('login failed')
        sys.exit(1)
    time.sleep(5)
    time.sleep(5)
    cookie_value_to_set=''
    for cookie_current in driver.get_cookie():
        cookie_value_to_set += cookie_current['name'] + '=' + cookie_current["value"] + ";"
    driver.quit()
    # now simulate broswer without actually using the broswer
    fail_counter=0
    rescrape_company=[]
    cookie_value_to_set= cookie_value_to_set

    for counter,company_symbol in enumerate(company_lists):
        if fail_counter >8:
            logger.info('Continuous error, breaking, second recaptch scenario')
            break
        logger.info("current company symbol is "+ str(counter+1)+' of '+str(len(company_lists))+" ->"+company_symbol)
        referer_url='https://seekingalpha.com/symbol/'+company_symbol+'/earnings/transcripts'
        headers=wrapper_helper.return_headers_link(referer_url,cookie_value_to_set)
        init_url='https://seekingalpha.com/symbol/'+company_symbol+'/earnings/transcripts.json'
        # till there are no transcripts are pending, continue calling transcript scraping URLs
        for i in range(100):
            if i == 0:
                url_to_hit=init_url
            else:
                url_to_hit='https://seekingalpha.com/symbol/'+company_symbol+'/earnings/more_transcripts?page='+str(i+1)
            r = requests.get(url_to_hit, headers=headers, timeout=60)
            if r.url.split('mbol/')[1].split('/earnings')[0] != company_symbol:
                logger.info('company symbol doesnot match with url '+company_symbol+' '+r.url.split('mbol/')[1].split('/earnings')[0])
                break
            if r.status_code == 404:
                logger.info("No page 404")
                break
            try:
                json_to_parse=r.json()
                fail_counter=0
            except simplejson.scanner.JSONDecodeError:
                # recaptcha check
                if 'Please click "I am not a robot" to continue' in r.content:
                    logger.info('recaptcha page')
                    logger.info('current company  will have to be scraped again:'+company_symbol)
                    rescrape_company.append(company_symbol)
                    logger.info('waiting for user to complete recaptcha, enter cookie')
                    cookie_value_to_set=raw_input()
                    headers = wrapper_helper.return_headers_link(referer_url,cookie_value_to_set)
                    r = requests.get(url_to_hit, headers=headers, timeout=30)
                    json_to_parse=r.json()
                else:
                    # some companies doesnt have transcripts
                    logger.info('NO JSON')
                    logger.info('skipping this company at '+str(i))
                    logger.info('bucket list '+company_symbol)
                    fail_counter +=1
                    break
            # parse transcripts
            soup = BeautifulSoup(json_to_parse['html'],'lxml')
            if i == 0:
                transcripts=soup.find('ul').find_all('li')
            else:
                transcripts=soup.find_all('li')
            # write parsed transcripts to file
            for transcript in transcripts:
                date = transcript.find('div',{'class':'date_on_by'}).find(text=True,recursive=False).strip()
                link = 'https://seekingalpha.com'+transcript.find('div', {'class':'symbol_article'}).find('a')['href']
                link_text = 'https://seekingalpha.com'+transcript.find('div', {'class':'symbol_article'}).find('a').text.strip()
                write_list = [company_symbol,link_text,date,link]
                output_file.writerow(write_list+[strftime("%Y%m%d")])
            # break the loop when there are no transcripts left
            if i and json_to_parse['count'] < 20:
                logger.info('\t\t Breaking loop '+str(i))
                break

            add_sleep_time(short=True)
        logger.info('remaining to scrape is '+str(rescrape_company))
        add_sleep_time()
