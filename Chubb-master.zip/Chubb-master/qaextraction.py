#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Aug 12 22:15:24 2018

@author: affine
"""


def get_analysts_from_preamble(preamble):
    if not preamble:
        return
    try:
        lines_raw = list(map(lambda x: x.strip(), preamble.split('^')))
        lines = list(zip(range(len(lines_raw)), lines_raw))
        B_index = list(map(lambda x: x[0], filter(lambda x: x[1].startswith('~'), lines)))
        B_index += [len(lines)]
        executive_index = list(filter(lambda x: x[1].lower().startswith('~executive'), lines))[0][0]
        executive_index_range = executive_index, B_index[B_index.index(executive_index)+1]
        executives_lines = lines_raw[executive_index_range[0]+1: executive_index_range[1]]
        executives_lines = list(filter(bool, executives_lines))
        executives = list(map(lambda x: re.split('[\,\-\–]', x)[0].strip(), executives_lines))
        
        #get executive name and ceo,cfo
        cxo = list()
        for l in executives_lines:
            try: 
                designation = re.split('[\,\-\–]', l)[1].strip()
                if len(re.split('[\,\-\–]', l)[1:])>1:
                    designation = "-".join(re.split('[\,\-\–]', l)[1:]).strip()
            except:
                designation = l.split('–')[1].strip()
            
            cxo.append(designation)
            
    #   get analyst
        analysts_index = list(filter(lambda x: x[1].lower().startswith('~analyst'), lines))[0][0]
        analysts_index_range = analysts_index, B_index[B_index.index(analysts_index)+1]
        analysts_lines = lines_raw[analysts_index_range[0]+1: analysts_index_range[1]]
        analysts_lines = list(filter(bool, analysts_lines))
        analysts = list(map(lambda x: re.split('[\,\-\–]', x)[0].strip(), analysts_lines))

    except Exception as e:
        #print(traceback.print_exc)
        return None 
    
    return(executives,analysts,cxo)


def get_q_a(heading, transcript, executives_analysts):
    executives = executives_analysts[0]
    analysts = executives_analysts[1]    
    cxos = dict(zip(executives,executives_analysts[2]  )) 
    def if_analyst(line):
        if not line.startswith('~'):
            return False
#         name = B.strip('|B').strip().split('-')[0].strip()
        for analyst in analysts:
            if fuzz.partial_ratio(line, analyst) > 93:
#                 print(line, analyst)
                return analyst
        return False
    
    def if_executive(line):
        if not line.startswith('~'):
            return False
#         name = B.strip('|B').strip().split('-')[0].strip()
        for executive in executives:
            if fuzz.partial_ratio(line, executive) > 93:
                return executive
        return False
    
    def return_name(B):
        name = process.extractOne(B, executives + analysts)[0][0]
#         return name[0]
        if fuzz.partial_ratio(B, name) > 0.90:
            return name
        else:
            return 
    def return_desgnation(B):
        name = process.extractOne(B, executives + analysts)[0][0]
#         return name[0]
        if fuzz.partial_ratio(B, name) > 0.90:
            return name
        else:
            return 
        
    
    lines_raw = list(map(lambda x: x.strip(), transcript.split('^')))
    lines = []
    for i in range(len(lines_raw)):
        if if_analyst(lines_raw[i]):
            
            lines.append(('analyst', if_analyst(lines_raw[i]),'designation', lines_raw[i+1]))
            #lines.append('designation')
            i = i + 2
            
        elif if_executive(lines_raw[i]):
            
            executive_name = if_executive(lines_raw[i])
            lines.append(('executive', executive_name, cxos[executive_name],lines_raw[i+1]))
#            lines.append()
            i = i + 2
            
        else:
            i = i + 1 
        if i >= len(lines_raw):
            break

    q_a = defaultdict(list)
    for line in lines:
        if line[0] == 'analyst':
            q = line
        elif line[0] == 'executive':
            q_a[q].append(line)
    q_a['heading'] = heading 
    return q_a
 
# To create dataframe for each documnet which stores question, answer, 
#analyst name, executive name, designation of executive 
def create_df_QA(q_a):
    data_temp = list()
    for key in q_a:
        try:       
            cols = ['Analyst_Name' ,'Executive_Name', 'Designation', 'Questions',
                                           'Answers']
            vals = [key[1],q_a[key][0][1],q_a[key][0][2],key[3],
                     q_a[key][0][3]]
            temp =dict(zip(cols,vals))
        except:
            pass
        # data_qa_level = pd.concat([temp, data_qa_level])
        data_temp.append(temp)
    return(data_temp)

