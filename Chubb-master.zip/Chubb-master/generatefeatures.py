
import pandas as pd
import traceback
from fuzzywuzzy import fuzz, process
from collections import defaultdict
import gensim

import os
import pandas as pd
import textstat
import re
from textstat.textstat import textstat
import pysentiment as ps
import nltk
from nltk.corpus import stopwords
import pysentiment as ps
import numpy as np
import re
from nltk.sentiment.vader import SentimentIntensityAnalyzer

from utils import TextUtils


class GenerateFeatures:
    
    def __init__(self, textutils, lm_filepath='data/LM.csv'):
        self.lm_df = pd.read_csv(lm_filepath)
        self.pos_l = self.lm_df.loc[(self.lm_df['Positive'] != 0)]['Word'].str.lower()
        self.neg_l = self.lm_df.loc[(self.lm_df['Negative'] != 0)]['Word'].str.lower()
        self.unc_l = self.lm_df.loc[(self.lm_df['Uncertainty'] != 0)]['Word'].str.lower()
        self.lit_l = self.lm_df.loc[(self.lm_df['Litigious'] != 0)]['Word'].str.lower()
        self.cons_l = self.lm_df.loc[(self.lm_df['Constraining'] != 0)]['Word'].str.lower()
        self.sup_l = self.lm_df.loc[(self.lm_df['Superfluous'] != 0)]['Word'].str.lower()
        self.int_l = self.lm_df.loc[(self.lm_df['Interesting'] != 0)]['Word'].str.lower()
        self.strong_mod_l = list(self.lm_df.loc[(self.lm_df['Modal'] == 1)]['Word'].str.lower())
        self.mid_mod_l = self.lm_df.loc[(self.lm_df['Modal'] == 2)]['Word'].str.lower()
        self.weak_mod_l =self.lm_df.loc[(self.lm_df['Modal'] == 3)]['Word'].str.lower()# no binary as it has got 3 intensity categories (1,2,3) + 0
        self.irv_l = self.lm_df.loc[(self.lm_df['Irr_Verb'] != 0)]['Word'].str.lower()
        self.textutils = textutils
        self.analyzer = SentimentIntensityAnalyzer() 
        self.lmanalyser = ps.LM()
        self.hiv4analyser = ps.HIV4()

    def generate_features(self, text):
        words = self.textutils.tokenize(text) 
        words = list(map(lambda x: x.lower(), words))
        n_words = textstat.lexicon_count(text) if textstat.lexicon_count(text) != 0 else 1
        n_lm_words = len([w for w in words if w in list(self.pos_l)]+[w for w in words if w in list(self.neg_l)]\
			+[w for w in words if w in list(self.unc_l)]+[w for w in words if w in list(self.lit_l)]\
                        +[w for w in words if w in list(self.cons_l)]+[w for w in words if w in list(self.sup_l)]\
                        +[w for w in words if w in list(self.int_l)]+[w for w in words if w in list(self.strong_mod_l)]\
                        +[w for w in words if w in list(self.mid_mod_l)]+[w for w in words if w in list(self.weak_mod_l)]\
                        +[w for w in words if w in list(self.irv_l)])
        
        n_lm_words = n_lm_words if n_lm_words != 0 else 1 
        list_neg=[]; list_neu=[]; list_pos=[]; list_comp=[]
        for sentence in self.textutils.sentence_tokenize(text):
            sentence = str(sentence)
            vs = self.analyzer.polarity_scores(sentence)
            list_neg.append(vs['neg'])
            list_neu.append(vs['neu'])
            list_pos.append(vs['pos'])
            list_comp.append(vs['compound'])
        # print(words)
        lm_score = self.lmanalyser.get_score(words)
        hiv4_score = self.hiv4analyser.get_score(words)

        features = {
            'size': n_words,
            'positive_frequency': float(len([w for w in words if w in list(self.pos_l)])) / n_words,
            'negative_frequency': float(len([w for w in words if w in list(self.neg_l)])) / n_words,
            'uncertainty_frequency': float(len([w for w in words if w in list(self.unc_l)])) / n_words,
            'litigious_frequency': float(len([w for w in words if w in list(self.lit_l)])) / n_words,
            'constraint_frequency': float(len([w for w in words if w in list(self.cons_l)])) / n_words,
            'superflous_frequency': float(len([w for w in words if w in list(self.sup_l)])) / n_words,
            'interesting_frequency': float(len([w for w in words if w in list(self.int_l)])) / n_words,
            'strong_modal_frequency': float(len([w for w in words if w in list(self.strong_mod_l)])) / n_words,
            'mid_modal_frequency': float(len([w for w in words if w in list(self.mid_mod_l)])) / n_words,
            'weak_modal_frequency': float(len([w for w in words if w in list(self.weak_mod_l)])) / n_words,
            'irreg_verbs_frequency': float(len([w for w in words if w in list(self.irv_l)])) / n_words,
            'positive_frequency_rel': float(len([w for w in words if w in list(self.pos_l)])) / n_lm_words,
            'negative_frequency_rel': float(len([w for w in words if w in list(self.neg_l)])) / n_lm_words,
            'uncertainty_frequency_rel': float(len([w for w in words if w in list(self.unc_l)])) / n_lm_words,
            'litigious_frequency_rel': float(len([w for w in words if w in list(self.lit_l)])) / n_lm_words,
            'constraint_frequency_rel': float(len([w for w in words if w in list(self.cons_l)])) / n_lm_words,
            'superflous_frequency_rel': float(len([w for w in words if w in list(self.sup_l)])) / n_lm_words,
            'interesting_frequency_rel': float(len([w for w in words if w in list(self.int_l)])) / n_lm_words,
            'strong_modal_frequency_rel': float(len([w for w in words if w in list(self.strong_mod_l)])) / n_lm_words,
            'mid_modal_frequency_rel': float(len([w for w in words if w in list(self.mid_mod_l)])) / n_lm_words,
            'weak_modal_frequency_rel': float(len([w for w in words if w in list(self.weak_mod_l)])) / n_lm_words,
            'irreg_verbs_frequency_rel': float(len([w for w in words if w in list(self.irv_l)])) / n_lm_words,
            'n_syllables': textstat.syllable_count(text),
            'n_sents': textstat.sentence_count(text),
            'flesch_reading_ease': 100 - textstat.flesch_reading_ease(text),
            'dale_chall_readability_score': textstat.dale_chall_readability_score(text),
            'difficult_words': textstat.difficult_words(text),
            'smog_grade_index': textstat.smog_index(text),
            'flesch_kincaid_grade': textstat.flesch_kincaid_grade(text),
            'coleman_liau_index': textstat.coleman_liau_index(text),
            'automated_readibility_index': textstat.automated_readability_index(text),
            'linsear_write_formula': textstat.linsear_write_formula(text),
            'gunning_fox': textstat.gunning_fog(text),
            'text_standard': textstat.text_standard(text),
            'vader_negative_score' : np.average(list(filter(lambda x: x!=0, list_neg))),
            'vader_neutral_score' :np.average(list(filter(lambda x: x!=0, list_neu))),
            'vader_positive_score' : np.average(list(filter(lambda x: x!=0, list_pos))),
            'vader_compoun_score' :np.average(list(filter(lambda x: x!=0, list_comp))),
            'padding': len(set(words).intersection(set(self.textutils.stopwords)))/n_words,
            'lm_score_polarity': lm_score['Polarity'],
            'lm_score_subjectivity': lm_score['Subjectivity'],
            'lm_score_postive': lm_score['Positive'],
            'lm_score_negative': lm_score['Negative'],
            'hiv4_score_polarity': hiv4_score['Polarity'],
            'hiv4_score_subjectivity': hiv4_score['Subjectivity'],
            'hiv4_score_postive': hiv4_score['Positive'],
            'hiv4_score_negative': hiv4_score['Negative'],

        }
        return features


if __name__ == '__main__':
    textutils = TextUtils(stopword_file='data/final_stopword list.csv', use_spacy=True)
    generatefeatures = GenerateFeatures(textutils=textutils, lm_filepath='data/LoughranMcDonald_MasterDictionary_2016.csv')
    print(generatefeatures.generate_features('hello how are you, this is dubious and loss'))


