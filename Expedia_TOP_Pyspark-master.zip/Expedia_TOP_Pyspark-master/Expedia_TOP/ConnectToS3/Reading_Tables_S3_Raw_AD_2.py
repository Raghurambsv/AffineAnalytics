##starting the pyspark shell
PYSPARK_PYTHON=/usr/bin/python27
./bin/pyspark --master spark://10.0.83.198:7077 --packages com.databricks:spark-csv_2.10:1.1.0

##IMPORTING THE REQUIRED LIBRARIES

from datetime import timedelta, date
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import *
import time


##CREATE THE LIST OF DATES FOR WHICH DATA IS REQUIRED
from datetime import *
import time
start_date = datetime.strptime(time.strftime("%Y-%m-%d"), "%Y-%m-%d") #STARTING DATE
no_days = 14  #NO. OF DAYS FOR WHICH DATA IS REQUIRED
date_list = []
for i in range(no_days):
    x = (start_date - timedelta(i))
    x = x.strftime("%Y-%m-%d")
    date_list.append(x)

start_date_last = start_date.replace(year = start_date.year - 1)
last_yr = 7
for i in range(last_yr):
    x = (start_date_last + timedelta(i))
    x = x.strftime("%Y-%m-%d")
    date_list.append(x)
	

##SCHEMA FOR HCBA TABLE
HCBAschema = StructType([	StructField('PARTNER_POS',StringType(), True),
							StructField('DEVICE_TYPE',StringType(), True),
							StructField('CLICKED_HOTEL_ID',IntegerType(), True),
							StructField('SRCH_WINDOW',IntegerType(), True),
							StructField('SRCH_LOS',IntegerType(), True),
							StructField('TRAFFIC',IntegerType(), True),
							StructField('COST',DoubleType(), True),
							StructField('BOOKED_FLAG',StringType(), True),
							StructField('BOOKED_HOTEL_ID',IntegerType(), True),
							StructField('BOOKED_LOS',IntegerType(), True),
							StructField('BOOKED_BKG_WINDOW',IntegerType(), True),
							StructField('GROSS_PROFIT',DoubleType(), True),
							StructField('PARTNER_ORG',StringType(), True),
							StructField('ACTIVITY_DATE',StringType(), True)
						])
 

##CREATE EMPTY DATAFRAME 
HCBA = sqlContext.createDataFrame(sc.emptyRDD(), HCBAschema)

##APPENDING THE DATA IN ABOVE CREATED HCBA TABLE 
for dates in date_list:
	path_HCBA = 's3n://ewe-core-meta-prod/CORE/HOTEL_CLICK_BOOK_AGG/local_date='+dates+'/*'  
	print (path_HCBA)
	try :
		temp_HCBA = sqlCtx.read.format("com.databricks.spark.csv").options(header = False, inferschema = True, delimiter = "\t",nullValue= '\\N').load(path_HCBA)
		print('file exist')
		temp_HCBA = temp_HCBA.select('C1','C3','C7','C8','C9','C13','C14','C19','C20','C21','C22','C45','C65')
		temp_HCBA = temp_HCBA.filter((temp_HCBA.C65 == 'TRIPADVISOR') & (temp_HCBA.C1 == 'CA') & (temp_HCBA.C7 != 0) & (temp_HCBA.C13 != 0) ) 
		temp_HCBA = temp_HCBA.withColumn('ACTIVITY_DATE',lit(dates))
		HCBA = HCBA.unionAll(temp_HCBA)
	except: print('file does not exist')

##sanity checks
HCBA_CA = HCBA.cache()
#HCBA_CA.count()

##CHANGING THE DATA TYPE 
def data_type_change_int(df,cols):
    temp = df
    for col in cols:
        temp = temp.withColumn(col+'_1',df[col].cast(IntegerType())).drop(col).withColumnRenamed(col+'_1',col)
    return temp

def data_type_change_float(df,cols):
    temp = df
    for col in cols:
        temp = temp.withColumn(col+'_1',df[col].cast(DoubleType())).drop(col).withColumnRenamed(col+'_1',col)
    return temp

cols_int = ['SRCH_LOS','SRCH_WINDOW','TRAFFIC','BOOKED_BKG_WINDOW','BOOKED_LOS']
cols_float = ['COST','GROSS_PROFIT']

HCBA_CA = data_type_change_int(HCBA_CA,cols_int)
HCBA_CA = data_type_change_float(HCBA_CA,cols_float)

#writing the user-defined functions for binning/bucketing Length of Stay, Booking Window (Search and Booking parameters)

def searchToCategory(srch_los):
    if srch_los == 0: return '0'
    elif srch_los == 1: return'1'
    elif srch_los == 2: return'2'
    elif srch_los ==3: return '3'
    elif srch_los ==4: return '4'
    elif srch_los ==5: return '5'
    elif srch_los ==6: return '6'
    elif srch_los ==7: return '7'
    elif srch_los >= 8 and srch_los <= 14: return '8-14'
    else: return '>14'    
    
def searchbucketToCategory(SRCH_WINDOW):
    if SRCH_WINDOW <= 0: return '<=0'    
    elif SRCH_WINDOW == 1: return '1'
    elif SRCH_WINDOW == 2: return '2'
    elif SRCH_WINDOW >= 3 and SRCH_WINDOW <= 4: return '3-4'
    elif SRCH_WINDOW >= 5 and SRCH_WINDOW <= 7: return '5-7'
    elif SRCH_WINDOW >= 8 and SRCH_WINDOW <= 14: return '8-14'
    elif SRCH_WINDOW >= 15 and SRCH_WINDOW <= 20: return '15-20'
    elif SRCH_WINDOW >= 21 and SRCH_WINDOW <= 30: return '21-30'
    elif SRCH_WINDOW >= 31 and SRCH_WINDOW <= 40: return '31-40'
    elif SRCH_WINDOW >= 41 and SRCH_WINDOW <= 60: return '41-60'
    elif SRCH_WINDOW >= 61 and SRCH_WINDOW <= 90: return '61-90'
    elif SRCH_WINDOW >= 91 and SRCH_WINDOW <= 120: return '91-120'
    elif SRCH_WINDOW >= 121 and SRCH_WINDOW <= 180: return '121-180'
    elif SRCH_WINDOW >= 181 and SRCH_WINDOW <= 240: return '181-240'
    else: return '>240'   
	
def srchBOOKED_LOS_BUCKET(booked_los):
    if booked_los is None: return '0'
    elif booked_los == 0: return '0'
    elif booked_los == 1: return '1'
    elif booked_los == 2: return '2'
    elif booked_los == 3: return '3'
    elif booked_los == 4: return '4'
    elif booked_los == 5: return '5'
    elif booked_los == 6: return '6'
    elif booked_los == 7: return '7'
    elif booked_los >= 8 and booked_los <= 14: return '8-14'
    else: return '>14'   

def srchBOOKED_BW_BUCKET(BOOKED_BKG_WINDOW):
    if BOOKED_BKG_WINDOW is None: return '0'
    elif BOOKED_BKG_WINDOW <= 0: return '<= 0'
    elif BOOKED_BKG_WINDOW == 1: return '1'
    elif BOOKED_BKG_WINDOW == 2: return '2'
    elif BOOKED_BKG_WINDOW >= 3 or BOOKED_BKG_WINDOW <= 4: return '3-4'
    elif BOOKED_BKG_WINDOW >= 5 or BOOKED_BKG_WINDOW <= 7: return '5-7'
    elif BOOKED_BKG_WINDOW >= 8 or BOOKED_BKG_WINDOW <= 14: return '8-14'
    elif BOOKED_BKG_WINDOW >= 15 or BOOKED_BKG_WINDOW <= 20: return '15-20'
    elif BOOKED_BKG_WINDOW >= 21 or BOOKED_BKG_WINDOW <= 30: return '21-30'
    elif BOOKED_BKG_WINDOW >= 31 or BOOKED_BKG_WINDOW <= 40: return '31-40'
    elif BOOKED_BKG_WINDOW >= 41 or BOOKED_BKG_WINDOW <= 60: return '41-60'
    elif BOOKED_BKG_WINDOW >= 61 or BOOKED_BKG_WINDOW <= 90: return '61-90'
    elif BOOKED_BKG_WINDOW >= 91 or BOOKED_BKG_WINDOW <= 120: return '91-120'
    elif BOOKED_BKG_WINDOW >= 121 or BOOKED_BKG_WINDOW <= 180: return '121-180'
    elif BOOKED_BKG_WINDOW >= 181 or BOOKED_BKG_WINDOW <= 240: return '181-240'
    else: return '>240'

def booking_flag(booked_flag):
    if booked_flag == 'Y': return 1
    else: return 0

# Registering Functions as UDF's

udfsearchToCategory=udf(searchToCategory, StringType())
udfsearchbucketToCategory=udf(searchbucketToCategory, StringType())
udfsrchBOOKED_LOS_BUCKET=udf(srchBOOKED_LOS_BUCKET, StringType())
udfsrchsrchBOOKED_BW_BUCKET=udf(srchBOOKED_BW_BUCKET, StringType())
booking_flag_udf=udf(booking_flag, IntegerType())

# Adding UDF's as columns to existing data frame.

HCBA_CA = HCBA_CA.withColumn("SRCH_LOS_BUCKET", udfsearchToCategory("SRCH_LOS")).withColumn("SRCH_BW_BUCKET", udfsearchbucketToCategory("SRCH_WINDOW")).withColumn("BOOKED_LOS_BUCKET", udfsrchBOOKED_LOS_BUCKET("BOOKED_LOS")).withColumn("BOOKED_BW_BUCKET", udfsrchsrchBOOKED_BW_BUCKET("BOOKED_BKG_WINDOW")).withColumn("BOOKING", booking_flag_udf("BOOKED_FLAG"))

#--Replacing the rows with negative Booking Window and LOS search parameters with the Booking Parameters---#
#Selecting the required data

HCBA_CA_LOS_BW_NEGATIVE_CONV = HCBA_CA.filter((HCBA_CA['BOOKED_FLAG'] == 'Y') & ((HCBA_CA['SRCH_WINDOW'] < -1) | (HCBA_CA['SRCH_LOS'] <= 0)))
HCBA_CA_LOS_BW_NEGATIVE_CONV = HCBA_CA_LOS_BW_NEGATIVE_CONV.withColumnRenamed('BOOKED_BKG_WINDOW', 'BOOKING_WINDOW').withColumnRenamed('BOOKED_BW_BUCKET', 'BW_BUCKET').withColumnRenamed('BOOKED_LOS_BUCKET', 'LOS_BUCKET').withColumnRenamed('BOOKED_HOTEL_ID', 'HOTEL_ID').withColumnRenamed('BOOKED_LOS', 'LOS')
HCBA_CA_LOS_BW_NEGATIVE_CONV=HCBA_CA_LOS_BW_NEGATIVE_CONV.select('PARTNER_POS','DEVICE_TYPE','HOTEL_ID','PARTNER_ORG','ACTIVITY_DATE','TRAFFIC','BOOKING_WINDOW','LOS','COST','GROSS_PROFIT','LOS_BUCKET','BW_BUCKET','BOOKING')

#-------------------------------------Selecting all the non converted rows---------------------#
#Selecting the required data
HCBA_CA_NON_CONV = HCBA_CA.filter((HCBA_CA['BOOKED_FLAG'] == 'N') & (HCBA_CA['SRCH_WINDOW'] >= -1) & (HCBA_CA['SRCH_LOS'] > 0) & (HCBA_CA['GROSS_PROFIT'] == 0.0) )

#Renaming the columns as required
HCBA_CA_NON_CONV = HCBA_CA_NON_CONV.withColumnRenamed('CLICKED_HOTEL_ID', 'HOTEL_ID').withColumnRenamed('SRCH_WINDOW', 'BOOKING_WINDOW').withColumnRenamed('SRCH_BW_BUCKET', 'BW_BUCKET').withColumnRenamed('SRCH_LOS', 'LOS').withColumnRenamed('SRCH_LOS_BUCKET', 'LOS_BUCKET')
HCBA_CA_NON_CONV=HCBA_CA_NON_CONV.select('PARTNER_POS','DEVICE_TYPE','HOTEL_ID','PARTNER_ORG','ACTIVITY_DATE','TRAFFIC','BOOKING_WINDOW','LOS','COST','GROSS_PROFIT','LOS_BUCKET','BW_BUCKET','BOOKING')

#----------------------------------Selecting all converted rows-------------------------------------#
#Selecting the required data
HCBA_CA_CONV = HCBA_CA.filter((HCBA_CA['BOOKED_FLAG'] == 'Y') & (HCBA_CA['SRCH_WINDOW'] >= -1) & (HCBA_CA['SRCH_LOS'] > 0))

#Renaming the columns as required
HCBA_CA_CONV = HCBA_CA_CONV.withColumnRenamed('CLICKED_HOTEL_ID', 'HOTEL_ID').withColumnRenamed('SRCH_WINDOW', 'BOOKING_WINDOW').withColumnRenamed('SRCH_BW_BUCKET', 'BW_BUCKET').withColumnRenamed('SRCH_LOS', 'LOS').withColumnRenamed('SRCH_LOS_BUCKET', 'LOS_BUCKET')
HCBA_CA_CONV=HCBA_CA_CONV.select('PARTNER_POS','DEVICE_TYPE','HOTEL_ID','PARTNER_ORG','ACTIVITY_DATE','TRAFFIC','BOOKING_WINDOW','LOS','COST','GROSS_PROFIT','LOS_BUCKET','BW_BUCKET','BOOKING')


#---Union of all the above 3 tables HCBA_CA_NON_CONV,HCBA_CA_CONV,HCBA_CA_LOS_BW_NEGATIVE_CONV----------#
HCBA_CA_UNION = HCBA_CA_LOS_BW_NEGATIVE_CONV.unionAll(HCBA_CA_NON_CONV).unionAll(HCBA_CA_CONV)

# code for reading and defining distinct hotel_dim
countofdims = 1
for dates in date_list:
	path_HOTELDIM = 's3n://ewe-meta-prod/EXPEDIA/output/'+dates+'/HOTEL_INFO/archive/*'
	print (path_HOTELDIM)
	try:
		temp_HOTELDIM = sqlCtx.read.format("com.databricks.spark.csv").\
			options(header = True, inferSchema = True, delimiter = "\t", nullValue= '\\N').\
			load(path_HOTELDIM)
		temp_HOTELDIM = temp_HOTELDIM.select("hotel_id","city","region","market","brand","star_rating","hotel_type")
		print('file exist')
		if countofdims == 1:
			HOTELDIM = temp_HOTELDIM
		else:
			HOTELDIM = HOTELDIM.unionAll(temp_HOTELDIM)
		countofdims +=1
	except: print('file does not exist')

HOTELDIM = HOTELDIM.distinct()
Hotel_Dim = HOTELDIM.cache()

#creating dataframe subset from original hotel dimension dataframe.
Hotel_Dim = Hotel_Dim.filter((Hotel_Dim['hotel_id'].isNotNull()))

TripAdvisor_AD = HCBA_CA_UNION.join(Hotel_Dim,HCBA_CA_UNION.HOTEL_ID==Hotel_Dim.hotel_id,"left_outer")

#canada region table
#filter the outliers and selecting the required data
Canada_AD = TripAdvisor_AD.filter(TripAdvisor_AD["region"] =='CANADA')

#writing the user-defined functions for binning/bucketing
def srchbcanada_region_city(city): 
    if city == 'TORONTO': return 'TORONTO'
    elif city == 'NIAGARA FALLS': return 'NIAGARA FALLS'
    elif city == 'MONTREAL': return 'MONTREAL'
    elif city == 'VANCOUVER': return 'VANCOUVER'
    elif city == 'QUEBEC': return 'QUEBEC'
    elif city == 'BANFF': return 'BANFF'
    elif city == 'OTTAWA': return 'OTTAWA'
    elif city == 'EDMONTON': return 'EDMONTON'
    elif city == 'VICTORIA': return 'VICTORIA'
    elif city == 'CALGARY': return 'CALGARY'
    elif city == 'WHISTLER': return 'WHISTLER'
    elif city == 'NIAGARA-ON-THE-LAKE' or 'CANMORE' or 'JASPER' or 'KELOWNA' or 'HALIFAX' or 'MISSISSAUGA' or  \
    'LAKE LOUISE' or 'COLLINGWOOD' or 'VERNON' or 'PENTICTON' or 'GATINEAU' or 'DORVAL' or 'MARKHAM': return 'G12'
    elif city == 'MONT-TREMBLANT' or 'TOFINO' or 'BLUE MOUNTAINS' or 'OSOYOOS' or 'UCLUELET' or 'SAINT-SAUVEUR' or \
    'WEST KELOWNA' or 'LA MALBAIE' or 'SAINTE-ADELE': return 'G13'
    elif city == 'WINNIPEG' or 'LONDON' or 'RICHMOND' or 'BARRIE' or 'REVELSTOKE' or 'VAUGHAN' or 'ORILLIA' or  \
    'BURNABY' or 'SURREY': return 'G14'
    else : 'others'
        
def srchbcanada_region_star_rating(star_rating):
    if star_rating == '2.0': return '2'
    elif star_rating == '2.5': return '2.5'
    elif star_rating == '3.0': return '3'
    elif star_rating == '3.5': return '3.5'
    elif star_rating == '4.0': return '4'
    elif star_rating == '1.0' or star_rating == '1.5': return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0': return '4.5-5'
    else : '0'

def srchbcanada_region_Hotel_type(Hotel_type):
    if Hotel_type == 'HOTEL': return 'HOTEL'
    elif Hotel_type == 'HOTEL RESORT': return 'HOTEL RESORT'
    elif Hotel_type == 'CONDOMINIUM RESORT' and Hotel_type == 'CONDO': return 'CONDO'
    elif Hotel_type == 'LODGE' or Hotel_type == 'BED & BREAKFAST' or Hotel_type == 'HOSTEL/BACKPACKER ACCOMMODATION' or \
      'CABIN' or Hotel_type == 'GUEST HOUSE': return 'Budget_hotel'
    elif Hotel_type == 'APART-HOTEL' and Hotel_type == 'INN': return 'Family_Premium'
    else : 'Others'

def srchbcanada_region_market(market):
    if market == 'TORONTO, ON, CAN': return 'TORONTO, ON, CAN'
    elif market == 'NIAGARA FALLS, ON, CAN': return 'NIAGARA FALLS, ON, CAN'
    elif market == 'MONTREAL, QC, CAN' : return 'MONTREAL, QC, CAN'
    elif market == 'BANFF AREA, AB, CAN' : return 'BANFF AREA, AB, CAN'
    elif market == 'VANCOUVER, BC, CAN' : return 'VANCOUVER, BC, CAN'
    elif market == 'QUEBEC CITY, QC, CAN' : return 'QUEBEC CITY, QC, CAN'
    elif market == 'EDMONTON, AB, CAN' : return 'EDMONTON, AB, CAN'
    elif market == 'OTTAWA, ON, CAN' : return 'OTTAWA, ON, CAN'
    elif market == 'OKANAGAN VALLEY, BC, CAN' : return 'OKANAGAN VALLEY, BC, CAN'
    elif market == 'VICTORIA, BC, CAN' or market == 'CALGARY, AB, CAN'or market == 'JASPER AREA, AB, CAN' : return 'G10'
    elif market == 'WHISTLER, BC, CAN' or market == 'NIAGARA-ON-THE-LAKE, ON, CAN' or market == 'MONT TREMBLANT, QC, CAN' or market == 'UCLUELET, BC, CAN': return 'G11'
    elif market == 'COLLINGWOOD, ON, CAN' or market == 'BC INTERIOR SKI, BC, CAN' or market == 'HALIFAX, NS, CAN' or market == 'WINNIPEG, MB, CAN' or \
    market == 'LONDON, ON, CAN' or market == 'KAMLOOPS, BC, CAN': return 'G12'   
    else : 'others' 
        
#Registering functions as UDF
udfsrchbcanada_region_city=udf(srchbcanada_region_city, StringType())
udfsrchbcanada_region_star_rating=udf(srchbcanada_region_star_rating, StringType())
udfsrchbcanada_region_Hotel_type=udf(srchbcanada_region_Hotel_type, StringType())
udfsrchbcanada_region_market=udf(srchbcanada_region_market, StringType())

#adding udf's to existing dataframe as coloumns.
Canada_AD = Canada_AD.withColumn("CITY_BUCKET", udfsrchbcanada_region_city("city")).\
            withColumn("STAR_RATING_BUCKET", udfsrchbcanada_region_star_rating("star_rating")).\
            withColumn("HOTEL_TYPE_BUCKET", udfsrchbcanada_region_Hotel_type("hotel_type")).\
            withColumn("MARKET_BUCKET", udfsrchbcanada_region_market("market")).\
            withColumn("REGION_BUCKET", lit("NA")).withColumn("MODEL_NAME", lit("Canada"))

# US region tabel
#filter the outliers and selecting the required data
US_AD = TripAdvisor_AD.filter((TripAdvisor_AD["region"] == 'FLORIDA') |(TripAdvisor_AD["region"] == 'NEW YORK CITY') \
                          |(TripAdvisor_AD["region"] == 'CALIFORNIA') |(TripAdvisor_AD["region"] == 'GAMING') \
                          |(TripAdvisor_AD["region"] == 'NORTHEAST') |(TripAdvisor_AD["region"] == 'MOUNTAIN') \
                          | (TripAdvisor_AD["region"] == 'MIDWEST') |(TripAdvisor_AD["region"] == 'CENTRAL') \
                          | (TripAdvisor_AD["region"] == 'SF PACNW') |(TripAdvisor_AD["region"] == 'ORLANDO') \
                          | (TripAdvisor_AD["region"] == 'SF PACNW')) 

#writing the user-defined functions for binning/bucketing
def srchbUS_region_star_rating(star_rating):
    if star_rating == '2.0': return '2'
    elif star_rating == '2.5': return '2.5'
    elif star_rating == '3.0': return '3'
    elif star_rating == '3.5': return '3.5'
    elif star_rating == '4.0': return '4'
    elif star_rating == '1.0' or star_rating == '1.5': return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0': return '4.5-5'
    else : '0'
        
        
def srchbUS_region_Hotel_type(Hotel_type):
    if Hotel_type == 'HOTEL': return 'HOTEL'
    elif Hotel_type == 'HOTEL RESORT': return 'HOTEL RESORT'
    elif Hotel_type == 'CONDOMINIUM RESORT' or Hotel_type == 'CONDO': return 'CONDO'
    elif Hotel_type == 'LODGE' or Hotel_type == 'BED & BREAKFAST' or Hotel_type == 'HOSTEL/BACKPACKER ACCOMMODATION' or \
      'CABIN' or Hotel_type == 'GUEST HOUSE': return 'Budget_hotel'
    elif Hotel_type == 'APART-HOTEL' or Hotel_type == 'INN': return 'Family_Premium'
    else : 'Others'
        


#registering functions as UDF
udfsrchbUS_region_star_rating=udf(srchbUS_region_star_rating, StringType())
udfsrchbUS_region_Hotel_type=udf(srchbUS_region_Hotel_type, StringType())

#adding udf's to existing dataframe as coloumns.
US_AD = US_AD.withColumn("STAR_RATING_BUCKET", udfsrchbUS_region_star_rating("star_rating"))\
        .withColumn("HOTEL_TYPE_BUCKET", udfsrchbUS_region_Hotel_type("hotel_type"))\
        .withColumn("CITY_BUCKET", lit("NA")).withColumn("MARKET_BUCKET", lit("NA")).withColumn("REGION_BUCKET", lit("NA")).withColumn("MODEL_NAME", lit("US"))

		
##Mexico region tabel
#filter the outliers and selecting the required data
Mexico_AD = TripAdvisor_AD.filter(TripAdvisor_AD["region"] == "MEXICO & CENTRAL AMERICA")


#writing the user-defined functions for binning/bucketing
def srchbMexico_region_star_rating(star_rating):
    if star_rating == '2.0': return '2'
    elif star_rating == '2.5': return '2.5'
    elif star_rating == '3.0': return '3'
    elif star_rating == '3.5': return '3.5'
    elif star_rating == '4.0': return '4'
    elif star_rating == '1.0' or star_rating == '1.5': return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0': return '4.5-5'
    else : '0'
                
def srchbMexico_region_Hotel_type(Hotel_type):
    if Hotel_type == 'HOTEL': return 'HOTEL'
    elif Hotel_type == 'HOTEL RESORT': return 'HOTEL RESORT'
    elif Hotel_type == 'ALL-INCLUSIVE' : return 'ALL-INCLUSIVE'
    elif Hotel_type == 'CONDOMINIUM RESORT' or Hotel_type == 'CONDO': return 'CONDO'
    elif Hotel_type == 'LODGE' or Hotel_type == 'BED & BREAKFAST' or Hotel_type == 'HOSTEL/BACKPACKER ACCOMMODATION' or \
      'CABIN' or Hotel_type == 'GUEST HOUSE': return 'Budget_hotel'
    elif Hotel_type == 'APART-HOTEL' or Hotel_type == 'INN': return 'Family_Premium'
    else : 'Others'
        
def srchbMexico_region_market(market):
    if market == 'MEXICO - RIVIERA MAYA, PLAYA DEL CARMEN & TULUM': return 'MEXICO - RIVIERA MAYA, PLAYA DEL CARMEN & TULUM'
    elif market == 'MEXICO - CANCUN & ISLA MUJERES': return 'MEXICO - CANCUN & ISLA MUJERES'
    elif market == 'MEXICO - PUERTO VALLARTA, NUEVO VALLARTA & RIVIERA NAYARIT' : return 'MEXICO - PUERTO VALLARTA, NUEVO VALLARTA & RIVIERA NAYARIT'
    elif market == 'MEXICO - LOS CABOS' : return 'MEXICO - LOS CABOS'
    elif market == 'CENTRAL AMERICA - COSTA RICA - GUANACASTE' : return 'CENTRAL AMERICA - COSTA RICA - GUANACASTE'
    elif market == 'CENTRAL AMERICA - BELIZE' : return 'CENTRAL AMERICA - BELIZE'
    elif market == 'CENTRAL AMERICA - COSTA RICA - PUNTARENAS' : return 'CENTRAL AMERICA - COSTA RICA - PUNTARENAS'
    elif market == 'CENTRAL AMERICA - COSTA RICA - OTHER' : return 'CENTRAL AMERICA - COSTA RICA - OTHER'
    elif market == 'MEXICO - COZUMEL' : return 'MEXICO - COZUMEL'
    elif market == 'MEXICO - HUATULCO' : return 'MEXICO - HUATULCO'
    elif market == 'MEXICO - IXTAPA & ZIHUATANEJO' : return 'MEXICO - IXTAPA & ZIHUATANEJO'
    elif market == 'CENTRAL AMERICA - HONDURAS' : return 'CENTRAL AMERICA - HONDURAS'
    elif market == 'CENTRAL AMERICA - PANAMA - OTHER' : return 'CENTRAL AMERICA - PANAMA - OTHER'
    elif market == 'CENTRAL AMERICA - COSTA RICA - SAN JOSE' or market == 'CENTRAL AMERICA - PANAMA - PANAMA CITY' or \
         market == 'MEXICO - MEXICO CITY' or market == 'MEXICO - MEXICO CITY' : return 'hclt'
    elif market == 'CENTRAL AMERICA - NICARAGUA' or market == 'MEXICO - MAZATLAN' or \
         market == 'MEXICO - MANZANILLO' or market == 'CENTRAL AMERICA - EL SALVADOR'  or market == 'MEXICO - ACAPULCO': return 'hclt'
      
    else : 'Low_traffic'  
        
#Registering functions as UDF's        
udfsrchbMexico_region_star_rating=udf(srchbMexico_region_star_rating, StringType())
udfsrchbMexico_region_Hotel_type=udf(srchbMexico_region_Hotel_type, StringType())
udfsrchbMexico_region_market=udf(srchbMexico_region_market, StringType())

#Adding the udf as coloumns to existing data frame.
Mexico_AD = Mexico_AD.withColumn("STAR_RATING_BUCKET", udfsrchbMexico_region_star_rating("star_rating")).\
            withColumn("HOTEL_TYPE_BUCKET", udfsrchbMexico_region_Hotel_type("hotel_type")).\
            withColumn("MARKET_BUCKET", udfsrchbMexico_region_market("market")).withColumn("CITY_BUCKET", lit("NA")).\
            withColumn("REGION_BUCKET", lit("NA")).withColumn("MODEL_NAME", lit("Mexico"))

## Caribbean region table
#filter the outliers and selecting the required data
Caribbean_AD = TripAdvisor_AD.filter(TripAdvisor_AD["region"] == "CARIBBEAN")

#writing the user-defined functions for binning/bucketing
def srchbCaribbean_region_star_rating(star_rating):
    if star_rating == '2.0': return '2'
    elif star_rating == '2.5': return '2.5'
    elif star_rating == '3.0': return '3'
    elif star_rating == '3.5': return '3.5'
    elif star_rating == '4.0': return '4'
    elif star_rating == '1.0' or star_rating == '1.5': return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0': return '4.5-5'
    else : '0'
         
def srchbCaribbean_region_Hotel_type(Hotel_type):
    if Hotel_type == 'HOTEL': return 'HOTEL'
    elif Hotel_type == 'HOTEL RESORT': return 'HOTEL RESORT'
    elif Hotel_type == 'ALL-INCLUSIVE' : return 'ALL-INCLUSIVE'
    elif Hotel_type == 'CONDOMINIUM RESORT' or Hotel_type == 'CONDO': return 'CONDO'
    elif Hotel_type == 'APART-HOTEL' or Hotel_type == 'INN': return 'Family_Premium'
    else : 'Others'
        
        
def srchbCaribbean_region_market(market):
    if market == 'PUNTA CANA, DOMINICAN REPUBLIC': return 'PUNTA CANA, DOMINICAN REPUBLIC'
    elif market == 'TURKS AND CAICOS': return 'TURKS AND CAICOS'
    elif market == 'MONTEGO BAY, JAMAICA' : return 'MONTEGO BAY, JAMAICA'
    elif market == 'ST. LUCIA' : return 'ST. LUCIA'
    elif market == 'OCHO RIOS, JAMAICA' : return 'OCHO RIOS, JAMAICA'
    elif market == 'NEGRIL, JAMAICA' : return 'NEGRIL, JAMAICA'
    elif market == 'BARBADOS' : return 'BARBADOS'
    elif market == 'ARUBA' or market == 'PUERTO PLATA, DOMINICAN REPUBLIC' or market == 'ANTIGUA AND BARBUDA' : return 'G8'
    elif market == 'NASSAU, BAHAMAS' or market == 'DOMINICAN REPUBLIC ALL OTHER' or \
         market == 'BERMUDA' or market == 'BAHAMAS, OUT ISLANDS' : return 'G9'
    elif market == 'SAN JUAN, PUERTO RICO' or market == 'PARADISE ISLAND, BAHAMAS' or market == 'CAYMAN ISLANDS' or \
          market == 'SINT MAARTEN, DUTCH'  or market == 'CURACAO' or market == 'ST. MARTIN, FRENCH': return 'G10'  
    else : 'Others'  
        
#Registering functions to UDF's
udfsrchbCaribbean_region_star_rating=udf(srchbCaribbean_region_star_rating, StringType())
udfsrchbCaribbean_region_Hotel_type=udf(srchbCaribbean_region_Hotel_type, StringType())
udfsrchbCaribbean_region_market=udf(srchbCaribbean_region_market, StringType())

#adding udf as coloumn to existing dataframe
Caribbean_AD = Caribbean_AD.withColumn("STAR_RATING_BUCKET", udfsrchbCaribbean_region_star_rating("star_rating")).\
                withColumn("HOTEL_TYPE_BUCKET", udfsrchbCaribbean_region_Hotel_type("hotel_type")).\
                withColumn("MARKET_BUCKET", udfsrchbCaribbean_region_market("market")).withColumn("CITY_BUCKET",lit("NA"))\
                .withColumn("REGION_BUCKET",lit("NA")).withColumn("MODEL_NAME",lit("CARIBBEAN"))

#other region table
#filter the outliers and selecting the required data
Other_Region_AD = TripAdvisor_AD.filter((TripAdvisor_AD["region"] == 'SPAIN & PORTUGAL') |(TripAdvisor_AD["region"] == 'ROME & ITALY RESORTS')\
                                    |(TripAdvisor_AD["region"] == 'MID-ATLANTIC') |(TripAdvisor_AD["region"] == 'GREECE & TURKEY') \
                                   |(TripAdvisor_AD["region"] == 'PARIS') |(TripAdvisor_AD["region"] == 'OCEANIA') \
                                   | (TripAdvisor_AD["region"] == 'ITALY NORTH') |(TripAdvisor_AD["region"] == 'LONDON, ENGLAND') \
                                   | (TripAdvisor_AD["region"] == 'THAILAND') |(TripAdvisor_AD["region"] == 'MIDDLE EAST AND INDIAN OCEAN') \
                                   | (TripAdvisor_AD["region"] == 'EUROPE REGIONAL TERRITORIES') |(TripAdvisor_AD["region"] == 'UK & IRELAND') \
                                   | (TripAdvisor_AD["region"] == 'AFRICA AND EAST MED') |(TripAdvisor_AD["region"] == 'EASTERN EUROPE') \
                                   | (TripAdvisor_AD["region"] == 'GERMANY, AUSTRIA & SWITZERLAND') |(TripAdvisor_AD["region"] == 'JAPAN & MICRONESIA') \
                                   | (TripAdvisor_AD["region"] == 'PHILIPPINES') |(TripAdvisor_AD["region"] == 'BENELUX') |(TripAdvisor_AD["region"] == 'FRANCE') \
                                   | (TripAdvisor_AD["region"] == 'INDONESIA') |(TripAdvisor_AD["region"] == 'INDIAN SUBCONTINENT') |(TripAdvisor_AD["region"] == 'HONG KONG & MACAU') \
                                   | (TripAdvisor_AD["region"] == 'SOUTHEAST ASIA EMERGING') |(TripAdvisor_AD["region"] == 'NORDIC') \
                                   | (TripAdvisor_AD["region"] == 'MAINLAND CHINA') |(TripAdvisor_AD["region"] == 'SOUTH KOREA')  |(TripAdvisor_AD["region"] == 'SINGAPORE (REGION)') \
                                   | (TripAdvisor_AD["region"] == 'MALAYSIA') |(TripAdvisor_AD["region"] == 'TAIWAN') |(TripAdvisor_AD["region"] == 'UNKNOWN') \
                                   | (TripAdvisor_AD["region"] == 'SOUTH AMERICA'))

#writing the user-defined functions for binning/bucketing
def srchbother_region_star_rating(star_rating):
    if star_rating == '2.0': return '2'
    elif star_rating == '2.5': return '2.5'
    elif star_rating == '3.0': return '3'
    elif star_rating == '3.5': return '3.5'
    elif star_rating == '4.0': return '4'
    elif star_rating == '1.0' or star_rating == '1.5': return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0': return '4.5-5'
    else : '0'
        
        
def srchbother_region_Hotel_type(Hotel_type):
    if Hotel_type == 'HOTEL': return 'HOTEL'
    elif Hotel_type == 'HOTEL RESORT': return 'HOTEL RESORT'
    elif Hotel_type == 'APART-HOTEL' : return 'APART-HOTEL'
    elif Hotel_type == 'GUEST HOUSE' or Hotel_type == 'BED & BREAKFAST' or Hotel_type == 'HOSTEL/BACKPACKER ACCOMMODATION'  \
     or Hotel_type == 'MOTEL'or Hotel_type == 'HOSTAL': return 'Budget_hotel'
    elif Hotel_type == 'APARTMENT' or Hotel_type == 'RESIDENCE' or Hotel_type == 'TOWNHOUSE'  \
     or Hotel_type == 'INN': return 'Budget_hotel'
    else : 'Others'
        
               
def srchbother_region_REGION_BUCKET(region):
    if region == 'SPAIN & PORTUGAL': return 'SPAIN & PORTUGAL'
    elif region == 'ROME & ITALY RESORTS': return 'ROME & ITALY RESORTS'
    elif region == 'MID-ATLANTIC': return 'MID-ATLANTIC'
    elif region == 'GREECE & TURKEY': return 'GREECE & TURKEY'
    elif region == 'OCEANIA': return 'OCEANIA'
    elif region == 'ITALY NORTH': return 'ITALY NORTH'
    elif region == 'THAILAND': return 'THAILAND'
    elif region == 'MIDDLE EAST AND INDIAN OCEAN': return 'MIDDLE EAST AND INDIAN OCEAN'
    elif region == 'PARIS' or region == 'LONDON' or region == 'ENGLAND': return 'G9'
    elif region == 'EUROPE REGIONAL TERRITORIES' or region == 'UK & IRELAND' : return 'G10'
    elif region == 'SOUTH AMERICA' or region == 'AFRICA AND EAST MED' : return 'G11'
    elif region == 'EASTERN EUROPE' or region == 'GERMANY, AUSTRIA & SWITZERLAND' or region == 'BENELUX' or region == 'FRANCE' or region == 'NORDIC': return 'G12'
    elif region == 'JAPAN & MICRONESIA' or region == 'HONG KONG & MACAU' or region == 'SOUTHEAST ASIA EMERGING' or region == 'MAINLAND CHINA' : return 'G13'
    else : 'Others'
        
#Registering functions to UDF's   
udfsrchbother_region_star_rating=udf(srchbother_region_star_rating, StringType())
udfsrchbother_region_Hotel_type=udf(srchbother_region_Hotel_type, StringType())
udfsrchbother_region_REGION_BUCKET=udf(srchbother_region_REGION_BUCKET, StringType())

#adding udf as coloumn to existing dataframe
Other_Region_AD = Other_Region_AD.withColumn("STAR_RATING_BUCKET", udfsrchbother_region_star_rating("star_rating")).\
                    withColumn("HOTEL_TYPE_BUCKET", udfsrchbother_region_Hotel_type("hotel_type")).\
                    withColumn("MARKET_BUCKET",lit("NA")).\
                    withColumn("REGION_BUCKET", udfsrchbother_region_REGION_BUCKET("region"))\
                    .withColumn("CITY_BUCKET", lit("NA")).withColumn("MODEL_NAME", lit("Other Region"))

 
# North America region table
#filter the outliers and selecting the required data
NA_AD = TripAdvisor_AD.filter(TripAdvisor_AD["region"] == "NORTH AMERICA REGIONAL TERRITORIES")

#writing the user-defined functions for binning/bucketing
def srchbNAdf_region_star_rating(star_rating):
    if star_rating == '2.0': return '2'
    elif star_rating == '2.5': return '2.5'
    elif star_rating == '3.0': return '3'
    elif star_rating == '3.5': return '3.5'
    elif star_rating == '4.0': return '4'
    elif star_rating == '1.0' or star_rating == '1.5': return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0': return '4.5-5'
    else : '0'
        
        
def srchbNA_region_Hotel_type(Hotel_type):
    if Hotel_type == 'HOTEL': return 'HOTEL'
    elif Hotel_type == 'MOTEL': return 'MOTEL'
    elif Hotel_type == 'LODGE' or Hotel_type == 'BED & BREAKFAST' or Hotel_type == 'COTTAGE'  \
     or Hotel_type == 'GUEST HOUSE'or Hotel_type == 'CABIN': return 'Budget_hotel'
    elif Hotel_type == 'APARTMENT' or Hotel_type == 'HOTEL RESORT' or Hotel_type == 'CONDO'  \
     or Hotel_type == 'INN' or Hotel_type == 'APART-HOTEL' or Hotel_type == 'CARAVAN PARK': return 'Family_Premium'
    else : 'Others'
        
        
def srchbNA_region_market(market):
    if market == 'GRAVENHURST - BRACEBRIDGE - HUNTSVILLE, ON, CAN' or market == 'ONTARIO WEST, ON, CAN' or market == 'ABBOTSFORD - CHILLIWACK, BC, CAN' or market =='MAINE - COAST' \
    or market == 'ONTARIO EAST, ON, CAN' or market == 'VANCOUVER ISLAND, BC, CAN' or market == 'BURLINGTON, VT' \
    or market == 'CHARLOTTETOWN, PEI, CAN': return 'G1'
    
    elif market == 'ALBERTA EAST, AB, CAN' or market == 'REGINA, SK, CAN' or market == 'KINGSTON, ON, CAN' or market == 'SASKATOON, SK, CAN'  \
    or market == 'MONCTON, NB, CAN' or market == 'TRI-CITIES (KW-GUELPH-CAMBRIDGE), ON, CAN': return 'G2'
    
    elif market == 'WINDSOR, ON, CAN' or market == 'RED DEER, AB, CAN' or market == 'BRITISH COLUMBIA SOUTH, BC, CAN' or market == 'GRAND FORKS, ND'  \
    or market == 'SUDBURY, ON, CAN' or market == 'ONTARIO NORTH, ON, CAN'or market == 'BANGOR, ME' \
    or market == 'HAMILTON - BRANTFORD, ON, CAN' or market == 'BELLEVILLE - TRENTON - COBOURG, ON, CAN'or market == 'FARGO, ND': return 'G3'
    
    elif market == 'LAKE PLACID, NY' or market == 'PARKSVILLE, VANCOUVER ISLAND, BC, CAN' or market == 'LAKE GEORGE, NY' or market == 'OGUNQUIT, ME' or market =='EVERETT, WA'  \
    or market == 'COASTAL, BC, CAN' or market == 'GROVE CITY, PA' or market == 'BELLINGHAM, WA' \
    or market == 'NORTH CONWAY, NH' or market == 'NEWFOUNDLAND OTHER, NL, CAN' or market == 'NOVA SCOTIA SOUTH, NS, CAN' \
    or market == 'PORTSMOUTH, NH' : return 'G4'
        
    elif market == 'LETHBRIDGE, AB, CAN' or market == 'FREDERICTON, NB, CAN' or market == 'BRANDON, MB, CAN' or market == 'ERIE, PA'  \
    or market == 'NANAIMO, VANCOUVER ISLAND, BC, CAN' or market == 'SASKATCHEWAN SOUTH, SK, CAN' or market == 'PRINCE GEORGE - QUESNEL, BC, CAN' \
    or market == 'MEDICINE HAT, AB, CAN' or market == 'GRANDE PRAIRIE, AB, CAN' or market == 'ALBERTA NORTH, AB, CAN' \
    or market == 'DURHAM, ON, CAN' or market == 'BRITISH COLUMBIA CENTRAL, BC, CAN' or market == 'ONTARIO SOUTHWEST, ON, CAN' \
    or market == 'SAULT STE. MARIE, ON, CAN' or market == 'THUNDER BAY, ON, CAN' or market == 'SAINT JOHN, NB, CAN' \
    or market == 'GREAT FALLS, MT' or market == 'MINOT, ND (AREA)' or market == 'BRITISH COLUMBIA NORTH, BC, CAN' \
    or market == 'NORTH BAY, ON, CAN' or market == 'PETERBOROUGH, ON, CAN' or market == 'CAPE BRETON ISLAND, NS, CAN' \
    or market == 'ALBERTA WEST, AB, CAN' or market == 'HUDSON VALLEY - POUGHKEEPSIE, NY' or market == 'FORT MCMURRAY, AB, CAN' \
    or market == 'NOVA SCOTIA NORTH, NS, CAN' or market == 'WATERTOWN, NY' or market == 'EDMUNSTON, NB, CAN' \
    or market == 'OLYMPIC NATIONAL PARK AREA, WA' or market == 'CEDAR CITY - BRYCE CANYON NATIONAL PARK, UT' or market == 'SUMMERSIDE, PEI, CAN' \
    or market == 'SALEM, OR (AREA)' or market == 'BUTTE - HELENA, MT' or market == 'BECKLEY, WV': return 'G5'
    
    elif market == 'SAGINAW, MI' or market == 'WHITE MOUNTAINS, NH' or market == 'FINGER LAKES NEW YORK' or market == 'NEW YORK - WEST' or market =='NEW BRUNSWICK NORTH, NB, CAN'  \
    or market == 'SASKATCHEWAN NORTH, SK, CAN' or market == 'MANITOBA SOUTH, MB, CAN' or market == 'BAR HARBOR, ME' \
    or market == 'WASHINGTON NORTHWEST' or market == 'VERMONT CENTRAL' or market == 'ALBERTA SOUTH, AB, CAN' \
    or market == 'WENATCHEE-LEAVENWORTH,WA' or market == 'GANANOQUE, ON, CAN' or market == 'PLATTSBURGH, (NY)' \
    or market == 'STRAITS OF MACKINAC, MI' or market == 'SANDUSKY, OH' or market == 'MANCHESTER, NH' \
    or market == 'ITHACA, NY' or market == 'MINNESOTA NORTHWEST' or market == 'MISSOULA, MT (AREA)' \
    or market == 'YELLOWKNIFE, NT, CAN' or market == 'PEI OTHER, PEI, CAN' or market == 'BILLINGS, MT (AREA)' \
    or market == 'RAPID CITY - MOUNT RUSHMORE, SD' or market == 'ANDOVER, MA'or market =='YUMA, AZ' or market == 'PORT HURON, MI' \
    or market == 'LANCASTER, PA' or market == 'FORT LEE - PARAMUS, NJ' or market == 'LEXINGTON, KY' \
    or market == 'MANITOBA NORTH, MB, CAN' or market == 'ABERDEEN - OCEAN SHORES, WA' or market == 'CANADA TERRITORIES, YT, CAN' \
    or market == 'KNOXVILLE, TN' or market == 'BURLINGTON - MOUNT VERNON, WA' or market == 'FREDERICKSBURG, VA' \
    or market == 'ARIZONA SOUTHEAST' or market == 'WINDHAM COUNTY, VT' or market == 'KENAI PENINSULA, AK' \
    or market == 'COLUMBIA, SC' or market == 'CALIFORNIA DESERTS SOUTH'  : return 'G6'
    
    elif market == 'ROME-UTICA, NY' or market == 'SANDPOINT, ID (AREA)' or market == 'MOAB - GREEN RIVER, UT' or market == 'WHITEHORSE, YT, CAN' or market =='NEW YORK - NORTHEAST'  \
    or market == 'SARNIA, ON, CAN' or market == 'AUGUSTA, ME' or market == 'LAKE POWELL - GLEN CANYON NATIONAL PARK, AZ' \
    or market == 'NEW YORK - SOUTH' or market == 'BISMARK, ND' or market == 'ALABAMA NORTH' \
    or market == 'ASHLAND - MEDFORD, OR' or market == 'WASHINGTON NORTHEAST' or market == 'THE BERKSHIRES, MA' \
    or market == 'EUGENE, OR (AREA)' or market == 'GRAND RAPIDS, MI' or market == 'WASHINGTON SOUTHWEST' \
    or market == 'LAKE HAVASU CITY, AZ' or market == 'SARATOGA, NY' or market == 'WYTHEVILLE - VA' \
    or market == 'ARCATA - EUREKA, CA' or market == 'SOUTH CAROLINA EAST' or market == 'CHATTANOOGA, TN' \
    or market == 'TOLEDO, OH' or market == 'IDAHO FALLS, ID' or market == 'WEST VIRGINIA SOUTH' \
    or market == 'SPRINGFIELD, MA' or market == 'OLYMPIA, WA' or market == 'GETTYSBURG - PA' : return 'G7'
    
    else : 'Others'

#Registering functions to UDF's
udfsrchbNAdf_region_star_rating=udf(srchbNAdf_region_star_rating, StringType())
udfsrchbNA_region_Hotel_type=udf(srchbNA_region_Hotel_type, StringType())
udfsrchbNA_region_market=udf(srchbNA_region_market, StringType())

#adding these UDF's as columns for existing dataframes
NA_AD = NA_AD.withColumn("STAR_RATING_BUCKET", udfsrchbNAdf_region_star_rating("star_rating")).\
        withColumn("HOTEL_TYPE_BUCKET", udfsrchbNA_region_Hotel_type("hotel_type")).\
        withColumn("MARKET_BUCKET", udfsrchbNA_region_market("market")).withColumn("CITY_BUCKET", lit("NA"))\
        .withColumn("REGION_BUCKET", lit("NA")).withColumn("MODEL_NAME", lit("North America"))

## All super region tables completed need to do union of all tables.
TripAdvisor_AD_Final = Canada_AD.unionAll(Mexico_AD).unionAll(Caribbean_AD).unionAll(Other_Region_AD).unionAll(NA_AD).unionAll(US_AD)


##CREATE EMPTY DATAFRAME
MBAP_schema = StructType([StructField('ACTIVITY_DATE',StringType(),True),
                          StructField('DEVICE_TYPE',StringType(),True),
                          StructField('HOTEL_ID',IntegerType(),True),
                          StructField('CPC',DoubleType(),True),
                          StructField('SELLER_RANK',DoubleType(),True)
                         ])
MBAP = sqlContext.createDataFrame(sc.emptyRDD(),MBAP_schema)

##APPENDING THE DATA IN ABOVE CREATED HCBA TABLE 
date_list_MBAP = []
for i in range(21):
    x = (start_date - timedelta(i))
    x = x.strftime("%Y-%m-%d")
    date_list_MBAP.append(x)

start_date_last = start_date.replace(year = start_date.year - 1)
last_yr = 7
for i in range(last_yr):
    x = (start_date_last + timedelta(i))
    x = x.strftime("%Y-%m-%d")
    date_list_MBAP.append(x)
	

for dates in date_list_MBAP:
	path_MBAP =  's3n://ewe-meta-prod/EXPEDIA/ARCHIVE/bidding/TRIPADVISOR_mBAP_bidoutput_'+dates.replace("-","")+'.tab.gz'   
	print (path_MBAP)
	try :
		temp_MBAP = sqlCtx.read.format("com.databricks.spark.csv").options(header = True, inferschema = True, delimiter = "\t",nullValue= '\\N').load(path_MBAP)
		print('file exist')
		temp_MBAP = temp_MBAP.filter(temp_MBAP.posa == 'CA')
		temp_MBAP = temp_MBAP.select('snapshot_day','device','hotelid','final_bid_value_cpc','expected_rank')
		MBAP = MBAP.unionAll(temp_MBAP)
	except: print('file does not exist')

MBAP = MBAP.cache()

TripAdvisor_AD_Final1 = TripAdvisor_AD_Final.join(MBAP,['ACTIVITY_DATE','HOTEL_ID','DEVICE_TYPE'],'left_outer')
#TripAdvisor_AD_Final1 = HCBA_CA_UNION.join(MBAP,['ACTIVITY_DATE','HOTEL_ID','DEVICE_TYPE'],'left_outer')

###Seller rank for previous year data
Seller_Rank_Look_Up = MBAP[MBAP.SELLER_RANK.isNotNull()]
Seller_Rank_Look_Up = Seller_Rank_Look_Up.groupBy('HOTEL_ID','SELLER_RANK').count()
Seller_Rank_Look_Up = Seller_Rank_Look_Up.withColumn("Rank",rank().over(Window.partitionBy('HOTEL_ID').orderBy(Seller_Rank_Look_Up["count"].desc())))
Seller_Rank_Look_Up = Seller_Rank_Look_Up.filter(Seller_Rank_Look_Up.Rank == 1).drop('Rank').drop('count').withColumnRenamed('SELLER_RANK','Rank_Freq')
#Seller_Rank_Look_Up.show(3)

###Seller rank for missing values in current year data
TripAdvisor_AD_Final1 = TripAdvisor_AD_Final1.join(Seller_Rank_Look_Up,'HOTEL_ID','inner')
TripAdvisor_AD_Final1 = TripAdvisor_AD_Final1.withColumnRenamed('SELLER_RANK','seller_rank_0').withColumnRenamed('ACTIVITY_DATE','ACTIVITY_DATE_ACT')
						
MBAP_without_cpc = MBAP.select('HOTEL_ID','SELLER_RANK','ACTIVITY_DATE','DEVICE_TYPE')
days = [1,2,3,4,5,6,7]
rank_col_name=['seller_rank_1','seller_rank_2','seller_rank_3','seller_rank_4','seller_rank_5','seller_rank_6','seller_rank_7']

for day in days:
	from datetime import date, timedelta
	d = day
	def date_change(date):
		date = date - timedelta(d)
		date = date.strftime("%Y-%m-%d")
	
	date_change_udf = udf(date_change,StringType())
		
	TripAdvisor_AD_Final1 = TripAdvisor_AD_Final1.withColumn('ACTIVITY_DATE',date_change_udf('ACTIVITY_DATE_ACT'))
	TripAdvisor_AD_Final1 = TripAdvisor_AD_Final1.join(MBAP_without_cpc,['ACTIVITY_DATE','HOTEL_ID','DEVICE_TYPE'],'left_outer').\
							withColumnRenamed('SELLER_RANK',rank_col_name[day-1]).drop('ACTIVITY_DATE')

							
TripAdvisor_AD_Final1=TripAdvisor_AD_Final1.withColumn("SELLER_RANK",coalesce('Rank_Freq','seller_rank_0','seller_rank_1','seller_rank_2''seller_rank_3','seller_rank_4','seller_rank_5','seller_rank_6','seller_rank_7'))
TripAdvisor_AD_Final1 = TripAdvisor_AD_Final1.select([col for col in TripAdvisor_AD_Final1.columns if c not in ('Rank_Freq','seller_rank_0','seller_rank_1','seller_rank_2''seller_rank_3','seller_rank_4','seller_rank_5','seller_rank_6','seller_rank_7')])

TripAdvisor_AD_Final1 = TripAdvisor_AD_Final1.withColumnRenamed('ACTIVITY_DATE_ACT','ACTIVITY_DATE')


###RF MODEL CREATION
import numpy
from pyspark.ml.feature import *
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.mllib.linalg import *
from pyspark.sql.functions import *


##subset the data for canada region
Training_AD = TripAdvisor_AD_Final1.filter(TripAdvisor_AD_Final1.MODEL_NAME == 'Canada')\
			  .select("TRAFFIC","BOOKING","BW_BUCKET","LOS_BUCKET","HOTEL_TYPE_BUCKET","STAR_RATING_BUCKET","MARKET_BUCKET","SELLER_RANK_BUCKET")


#Aggregating the data to the required level
Training_AD_T = Training_AD.groupBy(Training_AD.BW_BUCKET,Training_AD.LOS_BUCKET \
                      ,Training_AD.HOTEL_TYPE_BUCKET,Training_AD.STAR_RATING_BUCKET,Training_AD.MARKET_BUCKET \
                      ,Training_AD.SELLER_RANK_BUCKET).sum("TRAFFIC","BOOKING")

Training_AD_T1 = Training_AD_T.withColumnRenamed('sum(TRAFFIC)','TRAFFIC')
Training_AD_T1 = Training_AD_T1.withColumnRenamed('sum(BOOKING)','BOOKING')

######Filtering out the TRAFFIC (Outliers) from data
Training_AD_T1 = Training_AD_T1[~((Training_AD_T1.TRAFFIC<=4) & (Training_AD_T1.BOOKING>0))]
Training_AD_T1 = Training_AD_T1[~((Training_AD_T1.TRAFFIC==5) & (Training_AD_T1.BOOKING==2))]
Training_AD_T1 = Training_AD_T1[~((Training_AD_T1.TRAFFIC==6) & (Training_AD_T1.BOOKING==2))]

#####Converting the data type of required columns to factor
def indexStringColumns(df,cols):
    tempdf = df
    for col in cols:
        stringIndexer = StringIndexer(inputCol=col,outputCol=col+"-num")
        si_model = stringIndexer.fit(tempdf)
        tempdf = si_model.transform(tempdf)
    return tempdf

cols = {"BW_BUCKET","LOS_BUCKET","HOTEL_TYPE_BUCKET","STAR_RATING_BUCKET","MARKET_BUCKET","SELLER_RANK_BUCKET"}
dfnumeric = indexStringColumns(Training_AD_T1,cols)

def oneHotEncodeColumns(df,cols):
    tempdf = df
    for col in cols:
        onehotenc = OneHotEncoder(inputCol=col+"-num",outputCol=col+"-onehot")
        tempdf = onehotenc.transform(tempdf).drop(col+"-num")
    return tempdf
Training_AD_T1_Class = oneHotEncodeColumns(dfnumeric,{"BW_BUCKET","LOS_BUCKET","HOTEL_TYPE_BUCKET","STAR_RATING_BUCKET","MARKET_BUCKET","SELLER_RANK_BUCKET"})

#####Transforming the training dataset
#Defining function for the same
def genRows(row):
    TRAFFIC = row[6]
    BOOKING = row[7]
    BOOKINGcounter = 0
    rowList = []
    
    for i in range(TRAFFIC):
        row1 = row[:]                   
        #row1[6]=1
        row1= list(row1)
        row1[6]=1
        row1 = tuple(row1)
        if BOOKINGcounter < int(BOOKING):
            #row1[7]=1
            row1= list(row1)
            row1[7]=1
            row1 = tuple(row1)
        else :
            #row1[7]=0
            row1= list(row1)
            row1[7]=0
            row1 = tuple(row1)
        BOOKINGcounter += 1
        rowList.append(row1)
    return rowList

#Applying function on the complete dataset (after converting to rdd)
Training_AD_T1_Class_rdd = Training_AD_T1_Class.rdd
Training_AD_T1_Class_rdd = Training_AD_T1_Class_rdd.flatMap(lambda x : genRows(x))

#Reconverting to dataframe
schema = StructType([StructField('BW_BUCKET', StringType(), True),
                     StructField('LOS_BUCKET', StringType(), True),
                     StructField('HOTEL_TYPE_BUCKET', StringType(), True),
                     StructField('STAR_RATING_BUCKET', StringType(), True),
                     StructField('MARKET_BUCKET', StringType(), True),
                     StructField('SELLER_RANK_BUCKET', StringType(), True),
                     StructField('TRAFFIC', IntegerType(), True),
                     StructField('BOOKING', IntegerType(), True),
                     StructField('HOTEL_TYPE_BUCKET-onehot', VectorUDT(), True),
                     StructField('BW_BUCKET-onehot',  VectorUDT(), True),
                     StructField('region_bucket-onehot',  VectorUDT(), True),
                     StructField('LOS_BUCKET-onehot',  VectorUDT(), True),
                     StructField('SELLER_RANK_BUCKET-onehot',  VectorUDT(), True),
                     StructField('STAR_RATING_BUCKET-onehot',  VectorUDT(), True)])
Training_AD_T1_Class_df = sqlContext.createDataFrame(Training_AD_T1_Class_rdd, schema)


#Converting label to double datatype
toDouble = udf(lambda x : float(x * 1.00) , DoubleType())
Training_AD_T1_Class_df = Training_AD_T1_Class_df.withColumn('BOOKING' , toDouble(Training_AD_T1_Class_df.BOOKING))


#Taking only relevant columns as features
colList = Training_AD_T1_Class_df.columns 
colList.remove('BOOKING')
colList.remove('TRAFFIC')
colList.remove('BW_BUCKET')
colList.remove('LOS_BUCKET')
colList.remove('HOTEL_TYPE_BUCKET')
colList.remove('STAR_RATING_BUCKET')
colList.remove('MARKET_BUCKET')
colList.remove('SELLER_RANK_BUCKET')
vecAssembler = VectorAssembler(inputCols=colList,outputCol="features")
Train_AD = vecAssembler.transform(Training_AD_T1_Class_df).select("BOOKING","TRAFFIC","BW_BUCKET","LOS_BUCKET","HOTEL_TYPE_BUCKET","STAR_RATING_BUCKET","MARKET_BUCKET","SELLER_RANK_BUCKET","features").withColumnRenamed("BOOKING", "label")

####Random Forest model building
from pyspark.ml import Pipeline
from pyspark.ml.regression import RandomForestRegressor
from pyspark.ml.feature import StringIndexer, VectorIndexer

labelIndexer = StringIndexer(inputCol="label", outputCol="indexedLabel").fit(Train_AD)
featureIndexer = VectorIndexer(inputCol="features", outputCol="indexedFeatures").fit(Train_AD)
rf = RandomForestRegressor(labelCol="indexedLabel", featuresCol="indexedFeatures",featureSubsetStrategy="onethird",\
                           numTrees=1000,impurity="variance",maxBins=32)
pipeline = Pipeline(stages=[labelIndexer, featureIndexer, rf])
model = pipeline.fit(Train_AD)
RF_Model_Canada = model.stages[2]




