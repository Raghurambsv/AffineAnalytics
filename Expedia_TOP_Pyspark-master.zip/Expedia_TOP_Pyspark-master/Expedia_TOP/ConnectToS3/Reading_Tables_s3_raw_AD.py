##starting the pyspark shell
./bin/pyspark --packages com.databricks:spark-csv_2.10:1.1.0

from pyspark.sql import SQLContext
sqlContext = SQLContext(sc)

##IMPORTING THE REQUIRED LIBRARIES

from datetime import timedelta, date
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import *


##CREATE THE LIST OF DATES FOR WHICH DATA IS REQUIRED

start_date = date(2016, 5, 10) #STARTING DATE
no_days = 9  #NO. OF DAYS FOR WHICH DATA IS REQUIRED
date_list = []
for i in range(no_days):
    x = (start_date + timedelta(i))
    x = x.strftime("%Y-%m-%d")
    date_list.append(x)

###rdd
#data = sc.textFile("s3n://AKIAJVBONNCWBW2HIUIA:Y3v2WiB19OzQc9m30VKQ8eV31iNGWwABbiSZCFeL@ewe-core-meta-prod/CORE/HOTEL_CLICK_BOOK_AGG/local_date=2015-04-01/000208_0.gz",delimeter = '\t')

###data frame
#path_HCBA = 's3n://AKIAJVBONNCWBW2HIUIA:Y3v2WiB19OzQc9m30VKQ8eV31iNGWwABbiSZCFeL@ewe-core-meta-prod/CORE/HOTEL_CLICK_BOOK_AGG/local_date=2015-04-01/000208_0.gz'
#temp_HCBA = sqlContext.read.format("com.databricks.spark.csv").options(header = False, inferschema = False, delimiter = "\t").schema(HCBAschema).load(path_HCBA)


##SCHEMA FOR HCBA TABLE
HCBAschema = StructType([StructField('PARTNER_NAME',StringType(), True),
                 StructField('PARTNER_POS',StringType(), True),
                 StructField('PLACEMENT_NAME',StringType(), True),
                 StructField('DEVICE_TYPE',StringType(), True),
                 StructField('PLATFORM',StringType(), True),
                 StructField('XP_POS',StringType(), True),
                 StructField('HOTEL_CORE_IND',StringType(), True),
                 StructField('CLICKED_HOTEL_ID',IntegerType(), True),
                 StructField('SRCH_WINDOW',IntegerType(), True),
                 StructField('SRCH_LOS',IntegerType(), True),
                 StructField('SRCH_TOTL_PERSN_CNT',IntegerType(), True),
                 StructField('SRCH_ADULT_CNT',IntegerType(), True),
                 StructField('SRCH_CHILD_CNT',IntegerType(), True),
                 StructField('XCLICK',IntegerType(), True),
                 StructField('XCOST',DoubleType(), True),
                 StructField('PCLICK',IntegerType(), True),
                 StructField('PCOST',DoubleType(), True),
                 StructField('PIMPRESSION',DoubleType(), True),
                 StructField('WEIGHTED_PIMPRESSION',DoubleType(), True),
                 StructField('BOOKED_FLAG',StringType(), True),
                 StructField('BOOKED_HOTEL_ID',StringType(), True),
                 StructField('BOOKED_LOS',StringType(), True),
                 StructField('BOOKED_BKG_WINDOW',StringType(), True),
                 StructField('BOOKED_TOTAL_PERSON_CNT',StringType(), True),
                 StructField('BOOKED_ADULT_CNT',StringType(), True),
                 StructField('BOOKED_CHILD_CNT',StringType(), True),
                 StructField('RLT_TRUE_UP_TRX',DoubleType(), True),
                 StructField('RLT_TRUE_UP_GP_USD',DoubleType(), True),
                 StructField('RLT_NON_TRUE_UP_GP_USD',DoubleType(), True),
                 StructField('RLT_BID_GP_USD',DoubleType(), True),
                 StructField('RLT_TRUE_UP_GBV_USD',DoubleType(), True),
                 StructField('RLT_NON_TRUE_UP_GBV_USD',DoubleType(), True),
                 StructField('RLT_RN',IntegerType(), True),
                 StructField('RLT_TRUE_UP_NET_REV_USD',DoubleType(), True),
                 StructField('RLT_NON_TRUE_UP_NET_REV_USD',DoubleType(), True),
                 StructField('SS_TRUE_UP_TRX',DoubleType(), True),
                 StructField('SS_TRUE_UP_GP_USD',DoubleType(), True),
                 StructField('SS_NON_TRUE_UP_GP_USD',DoubleType(), True),
                 StructField('SS_BID_GP_USD',DoubleType(), True),
                 StructField('SS_TRUE_UP_GBV_USD',DoubleType(), True),
                 StructField('SS_NON_TRUE_UP_GBV_USD',DoubleType(), True),
                 StructField('SS_RN',IntegerType(), True),
                 StructField('SS_TRUE_UP_NET_REV_USD',DoubleType(), True),
                 StructField('SS_NON_TRUE_UP_NET_REV_USD',DoubleType(), True),
                 StructField('LT_TRUE_UP_TRX',DoubleType(), True),
                 StructField('LT_TRUE_UP_GP_USD',DoubleType(), True),
                 StructField('LT_NON_TRUE_UP_GP_USD',DoubleType(), True),
                 StructField('LT_BID_GP_USD',DoubleType(), True),
                 StructField('LT_TRUE_UP_GBV_USD',DoubleType(), True),
                 StructField('LT_NON_TRUE_UP_GBV_USD',DoubleType(), True),
                 StructField('LT_RN',IntegerType(), True),
                 StructField('LT_TRUE_UP_NET_REV_USD',DoubleType(), True),
                 StructField('LT_NON_TRUE_UP_NET_REV_USD',DoubleType(), True),
                 StructField('HOTEL_CANCEL_FLAG',StringType(), True),
                 StructField('HOTEL_CANCEL_HOTEL_ID',StringType(), True),
                 StructField('HOTEL_CANCEL_GBV_USD',StringType(), True),
                 StructField('HOTEL_CANCEL_GP_USD',StringType(), True),
                 StructField('HOTEL_CANCEL_RN',StringType(), True),
                 StructField('HOTEL_LOB_FLAG',StringType(), True),
                 StructField('SAME_HOTEL_FLAG',StringType(), True),
                 StructField('SAME_CITY_FLAG',StringType(), True),
                 StructField('SAME_BKG_WINDOW_FLAG',StringType(), True),
                 StructField('SAME_LOS_FLAG',StringType(), True),
                 StructField('SAME_DAY_CANCEL_FLAG',StringType(), True),
                 StructField('BRAND',StringType(), True),
                 StructField('PARTNER_ORG',StringType(), True)
                 ,StructField('ACTIVITY_DATE',StringType(), True)
                ])
 

##CREATE EMPTY DATAFRAME 
HCBA = sqlContext.createDataFrame(sc.emptyRDD(), HCBAschema)

##APPENDING THE DATA IN ABOVE CREATED HCBA TABLE 

for dates in date_list:
    
	path_HCBA = 's3n://AKIAJVBONNCWBW2HIUIA:Y3v2WiB19OzQc9m30VKQ8eV31iNGWwABbiSZCFeL@ewe-core-meta-prod/CORE/HOTEL_CLICK_BOOK_AGG/local_date='+dates+'/*'  
	print (path_HCBA)
	
	try :
		temp_HCBA = sqlCtx.read.format("com.databricks.spark.csv").options(header = False, inferschema = True, delimiter = "\t").load(path_HCBA)
		print('file exist')
		temp_HCBA = temp_HCBA.filter(temp_HCBA.C65 == 'TRIPADVISOR')
		temp_HCBA = temp_HCBA.withColumn('ACTIVITY_DATE',lit(dates))
		HCBA = HCBA.unionAll(temp_HCBA)
		
		
	except: print('file doen not exist')

##sanity checks
HCBA = HCBA.cache()
HCBA.count()

#selecting the required coloumns
HCBA = HCBA.select('ACTIVITY_DATE','PARTNER_ORG','PARTNER_POS','DEVICE_TYPE','CLICKED_HOTEL_ID','SRCH_WINDOW','SRCH_LOS','XCLICK','XCOST','BOOKED_FLAG','BOOKED_HOTEL_ID','BOOKED_BKG_WINDOW','BOOKED_LOS','LT_TRUE_UP_GP_USD','LT_TRUE_UP_GBV_USD','LT_TRUE_UP_NET_REV_USD')

#filter the outliers and selecting the required data
HCBA_CA = HCBA.filter((HCBA['PARTNER_POS'] == 'CA') & (HCBA['CLICKED_HOTEL_ID'] != 0) & (HCBA['XCLICK'] != 0))

#Renaming the existing coloumns for better understanding
HCBA_CA = HCBA_CA.withColumnRenamed('SRCH_WINDOW', 'srch_booking_window').withColumnRenamed('XCLICK', 'traffic').withColumnRenamed('XCOST', 'cost').withColumnRenamed('BOOKED_BKG_WINDOW', 'booked_booking_window').withColumnRenamed('LT_TRUE_UP_GP_USD', 'gross_profit').withColumnRenamed('LT_TRUE_UP_GBV_USD', 'gross_booking_value').withColumnRenamed('LT_TRUE_UP_NET_REV_USD', 'net_revenue')


def data_type_change_int(df,cols):
    temp = df
    
    for col in cols:
        temp = temp.withColumn(col+'_1',df[col].cast(IntegerType())).drop(col).withColumnRenamed(col+'_1',col)
    
    return temp


def data_type_change_float(df,cols):
    temp = df
    
    for col in cols:
        temp = temp.withColumn(col+'_1',df[col].cast(DoubleType())).drop(col).withColumnRenamed(col+'_1',col)
    
    return temp

cols_int = ['SRCH_LOS','srch_booking_window','traffic','booked_booking_window','BOOKED_LOS']
cols_float = ['cost','gross_profit','gross_booking_value','net_revenue']

HCBA_CA = data_type_change_int(HCBA_CA,cols_int)
HCBA_CA = data_type_change_float(HCBA_CA,cols_float)

#writing the user-defined functions for binning/bucketing Length of Stay, Booking Window (Search and Booking parameters)

def searchToCategory(srch_los):
    if srch_los == 0: return '0'
    elif srch_los == 1: return'1'
    elif srch_los == 2: return'2'
    elif srch_los ==3: return '3'
    elif srch_los ==4: return '4'
    elif srch_los ==5: return '5'
    elif srch_los ==6: return '6'
    elif srch_los ==7: return '7'
    elif srch_los >= 8 and srch_los <= 14: return '8-14'
    else: return '>14'    
    
def searchbucketToCategory(srch_booking_window):
    if srch_booking_window <= 0: return '<=0'    
    elif srch_booking_window == 1: return '1'
    elif srch_booking_window == 2: return '2'
    elif srch_booking_window >= 3 and srch_booking_window <= 4: return '3-4'
    elif srch_booking_window >= 5 and srch_booking_window <= 7: return '5-7'
    elif srch_booking_window >= 8 and srch_booking_window <= 14: return '8-14'
    elif srch_booking_window >= 15 and srch_booking_window <= 20: return '15-20'
    elif srch_booking_window >= 21 and srch_booking_window <= 30: return '21-30'
    elif srch_booking_window >= 31 and srch_booking_window <= 40: return '31-40'
    elif srch_booking_window >= 41 and srch_booking_window <= 60: return '41-60'
    elif srch_booking_window >= 61 and srch_booking_window <= 90: return '61-90'
    elif srch_booking_window >= 91 and srch_booking_window <= 120: return '91-120'
    elif srch_booking_window >= 121 and srch_booking_window <= 180: return '121-180'
    elif srch_booking_window >= 181 and srch_booking_window <= 240: return '181-240'
    else: return '>240'   
	
def srchbooked_los_bucket(booked_los):
    if booked_los is None: return '0'
    elif booked_los == 0: return '0'
    elif booked_los == 1: return '1'
    elif booked_los == 2: return '2'
    elif booked_los == 3: return '3'
    elif booked_los == 4: return '4'
    elif booked_los == 5: return '5'
    elif booked_los == 6: return '6'
    elif booked_los == 7: return '7'
    elif booked_los >= 8 and booked_los <= 14: return '8-14'
    else: return '>14'   
	
def srchbooked_bw_bucket(booked_booking_window):
    if booked_booking_window is None: return '0'
    elif booked_booking_window <= 0: return '<= 0'
    elif booked_booking_window == 1: return '1'
    elif booked_booking_window == 2: return '2'
    elif booked_booking_window >= 3 or booked_booking_window <= 4: return '3-4'
    elif booked_booking_window >= 5 or booked_booking_window <= 7: return '5-7'
    elif booked_booking_window >= 8 or booked_booking_window <= 14: return '8-14'
    elif booked_booking_window >= 15 or booked_booking_window <= 20: return '15-20'
    elif booked_booking_window >= 21 or booked_booking_window <= 30: return '21-30'
    elif booked_booking_window >= 31 or booked_booking_window <= 40: return '31-40'
    elif booked_booking_window >= 41 or booked_booking_window <= 60: return '41-60'
    elif booked_booking_window >= 61 or booked_booking_window <= 90: return '61-90'
    elif booked_booking_window >= 91 or booked_booking_window <= 120: return '91-120'
    elif booked_booking_window >= 121 or booked_booking_window <= 180: return '121-180'
    elif booked_booking_window >= 181 or booked_booking_window <= 240: return '181-240'
    else: return '>240'

# Regestering Functions as UDF's

udfsearchToCategory=udf(searchToCategory, StringType())
udfsearchbucketToCategory=udf(searchbucketToCategory, StringType())
udfsrchbooked_los_bucket=udf(srchbooked_los_bucket, StringType())
udfsrchsrchbooked_bw_bucket=udf(srchbooked_bw_bucket, StringType())


# Adding UDF's as coloumns to existing dataframe.

HCBA_CA = HCBA_CA.withColumn("srch_los_bucket", udfsearchToCategory("SRCH_LOS")).withColumn("srch_bw_bucket", udfsearchbucketToCategory("srch_booking_window")).withColumn("booked_los_bucket", udfsrchbooked_los_bucket("BOOKED_LOS")).withColumn("booked_bw_bucket", udfsrchsrchbooked_bw_bucket("booked_booking_window"))

#--Replacing the rows with negative Booking Window and LOS search parameters with the Booking Parameters---#
#Selecting the required data

HCBA_CA_LOS_BW_NEGATIVE_CONV = HCBA_CA.filter((HCBA_CA['BOOKED_FLAG'] == 'Y') & ((HCBA_CA['srch_booking_window'] < -1) | (HCBA_CA['SRCH_LOS'] <= 0)))


HCBA_CA_LOS_BW_NEGATIVE_CONV = HCBA_CA_LOS_BW_NEGATIVE_CONV.withColumnRenamed('booked_booking_window', 'booking_window').withColumnRenamed('booked_bw_bucket', 'bw_bucket').withColumnRenamed('booked_los_bucket', 'los_bucket').withColumnRenamed('BOOKED_HOTEL_ID', 'hotel_id').withColumnRenamed('booked_los', 'los')


def booking_flag(booked_flag):
    if booked_flag == 'Y': return 1
    else: return 0
	
booking_flag_udf=udf(booking_flag, IntegerType())
HCBA_CA_LOS_BW_NEGATIVE_CONV = HCBA_CA_LOS_BW_NEGATIVE_CONV.withColumn("booking", booking_flag_udf("BOOKED_FLAG"))

#-------------------------------------Selecting all the non convereted rows---------------------#
#Selecting the required data

HCBA_CA_NON_CONV = HCBA_CA.filter((HCBA_CA['BOOKED_FLAG'] == 'N') & (HCBA_CA['srch_booking_window'] >= -1) & (HCBA_CA['SRCH_LOS'] > 0) & (HCBA_CA['gross_profit'] == 0.0) & (HCBA_CA['gross_booking_value'] == 0.0))


#Renaming the coloumns as required

HCBA_CA_NON_CONV = HCBA_CA_NON_CONV.withColumnRenamed('CLICKED_HOTEL_ID', 'hotel_id').withColumnRenamed('srch_booking_window', 'booking_window').withColumnRenamed('srch_bw_bucket', 'bw_bucket').withColumnRenamed('SRCH_LOS', 'los').withColumnRenamed('srch_los_bucket', 'los_bukcet')

HCBA_CA_NON_CONV = HCBA_CA_NON_CONV.withColumn("booking", booking_flag_udf("BOOKED_FLAG"))

#----------------------------------Selecting all converted rows-------------------------------------#
#Selecting the required data

HCBA_CA_CONV = HCBA_CA.filter((HCBA_CA['BOOKED_FLAG'] == 'Y') & (HCBA_CA['srch_booking_window'] >= -1) & (HCBA_CA['SRCH_LOS'] > 0))

#Renaming the coloumns as required
HCBA_CA_CONV = HCBA_CA_CONV.withColumnRenamed('clicked_hotel_id', 'hotel_id').withColumnRenamed('srch_booking_window', 'booking_window').withColumnRenamed('srch_bw_bucket', 'bw_bucket').withColumnRenamed('SRCH_LOS', 'los').withColumnRenamed('srch_los_bucket', 'los_bukcet')


HCBA_CA_CONV = HCBA_CA_CONV.withColumn("booking", booking_flag_udf("BOOKED_FLAG"))

#---unionall - Union of all the above 3 tables HCBA_CA_NON_CONV,HCBA_CA_CONV,HCBA_CA_LOS_BW_NEGATIVE_CONV----------#

HCBA_CA_UNION = HCBA_CA_LOS_BW_NEGATIVE_CONV.unionAll(HCBA_CA_NON_CONV).unionAll(HCBA_CA_CONV)
