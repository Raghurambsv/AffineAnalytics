##starting the pyspark shell
'''
PYSPARK_PYTHON=/usr/bin/python27
./bin/pyspark --packages com.databricks:spark-csv_2.10:1.1.0 --master spark://10.0.83.198:7077 --executor-memory 13G --total-executor-cores 12
'''


##IMPORTING THE REQUIRED LIBRARIES

from datetime import timedelta, date
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import *
import time

#code for reading and defining distinct hotel_dim

#path_HOTELDIM = 's3n://ewe-meta-prod/EXPEDIA/output/'+date_hotel_dim+'/HOTEL_INFO/archive/*'
path_HOTELDIM = '/home/vireddy/Hotel_Dim.filepart'
HOTELDIM = sqlCtx.read.format("com.databricks.spark.csv").\
			options(header = True, inferSchema = True, delimiter = ",", nullValue= 'NULL').\
			load(path_HOTELDIM)
HOTELDIM = HOTELDIM.distinct()
HOTELDIM = HOTELDIM.filter(HOTELDIM.has_inv_ind == 'BOOKABLE')
HOTELDIM = HOTELDIM.select("hotel_id","city","region","market","brand","star_rating","hotel_type")

#creating dataframe subset from original hotel dimension dataframe.
Hotel_Dim = Hotel_Dim.filter((Hotel_Dim['hotel_id'].isNotNull()))
Hotel_Dim = Hotel_Dim.withColumnRenamed('hotel_id','HOTEL_ID')
Hotel_Dim = Hotel_Dim.cache()

LOS_BUCKET = ['1','2','3','4','5','6','7','8-14','>14']
BW_BUCKET =  ['0','1','2','3-4','5-7','8-14','15-20','21-30','31-40','41-60','61-90','91-120','121-180','181-240','>240']

import pandas as pd
LOS = pd.DataFrame(LOS_BUCKET)
BW = pd.DataFrame(BW_BUCKET)

LOS_BUCKET_DF = sqlContext.createDataFrame(LOS).withColumnRenamed('0','LOS_BUCKET')
BW_BUCKET_DF = sqlContext.createDataFrame(BW).withColumnRenamed('0','BW_BUCKET')

##canada table
Canada_AD = Hotel_Dim.filter(Hotel_Dim["region"] =='CANADA')

#writing the user-defined functions for binning/bucketing
def srchbcanada_region_city(city):
    if city == 'TORONTO':
        return 'TORONTO'
    elif city == 'NIAGARA FALLS':
        return 'NIAGARA FALLS'
    elif city == 'MONTREAL':
        return 'MONTREAL'
    elif city == 'VANCOUVER':
        return 'VANCOUVER'
    elif city == 'QUEBEC':
        return 'QUEBEC'
    elif city == 'BANFF':
        return 'BANFF'
    elif city == 'OTTAWA':
        return 'OTTAWA'
    elif city == 'EDMONTON':
        return 'EDMONTON'
    elif city == 'VICTORIA':
        return 'VICTORIA'
    elif city == 'CALGARY':
        return 'CALGARY'
    elif city == 'WHISTLER':
        return 'WHISTLER'
    elif city == 'NIAGARA-ON-THE-LAKE' or 'CANMORE' or 'JASPER' \
        or 'KELOWNA' or 'HALIFAX' or 'MISSISSAUGA' or 'LAKE LOUISE' \
        or 'COLLINGWOOD' or 'VERNON' or 'PENTICTON' or 'GATINEAU' \
        or 'DORVAL' or 'MARKHAM':
        return 'G12'
    elif city == 'MONT-TREMBLANT' or 'TOFINO' or 'BLUE MOUNTAINS' \
        or 'OSOYOOS' or 'UCLUELET' or 'SAINT-SAUVEUR' or 'WEST KELOWNA' \
        or 'LA MALBAIE' or 'SAINTE-ADELE':
        return 'G13'
    elif city == 'WINNIPEG' or 'LONDON' or 'RICHMOND' or 'BARRIE' \
        or 'REVELSTOKE' or 'VAUGHAN' or 'ORILLIA' or 'BURNABY' \
        or 'SURREY':
        return 'G14'
    else: 'others'


def srchbcanada_region_star_rating(star_rating):
    if star_rating == '2.0':
        return '2'
    elif star_rating == '2.5':
        return '2.5'
    elif star_rating == '3.0':
        return '3'
    elif star_rating == '3.5':
        return '3.5'
    elif star_rating == '4.0':
        return '4'
    elif star_rating == '1.0' or star_rating == '1.5':
        return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0':
        return '4.5-5'
    else: '0'


def srchbcanada_region_Hotel_type(Hotel_type):
    if Hotel_type == 'HOTEL':
        return 'HOTEL'
    elif Hotel_type == 'HOTEL RESORT':
        return 'HOTEL RESORT'
    elif Hotel_type == 'CONDOMINIUM RESORT' or Hotel_type == 'CONDO':
        return 'CONDO'
    elif Hotel_type == 'LODGE' or Hotel_type == 'BED & BREAKFAST' \
        or Hotel_type == 'HOSTEL/BACKPACKER ACCOMMODATION' or 'CABIN' \
        or Hotel_type == 'GUEST HOUSE':
        return 'Budget_hotel'
    elif Hotel_type == 'APART-HOTEL' or Hotel_type == 'INN':
        return 'Family_Premium'
    else:'Others'


def srchbcanada_region_market(market):
    if market == 'TORONTO, ON, CAN':
        return 'TORONTO, ON, CAN'
    elif market == 'NIAGARA FALLS, ON, CAN':
        return 'NIAGARA FALLS, ON, CAN'
    elif market == 'MONTREAL, QC, CAN':
        return 'MONTREAL, QC, CAN'
    elif market == 'BANFF AREA, AB, CAN':
        return 'BANFF AREA, AB, CAN'
    elif market == 'VANCOUVER, BC, CAN':
        return 'VANCOUVER, BC, CAN'
    elif market == 'QUEBEC CITY, QC, CAN':
        return 'QUEBEC CITY, QC, CAN'
    elif market == 'EDMONTON, AB, CAN':
        return 'EDMONTON, AB, CAN'
    elif market == 'OTTAWA, ON, CAN':
        return 'OTTAWA, ON, CAN'
    elif market == 'OKANAGAN VALLEY, BC, CAN':
        return 'OKANAGAN VALLEY, BC, CAN'
    elif market == 'VICTORIA, BC, CAN' or market == 'CALGARY, AB, CAN' \
        or market == 'JASPER AREA, AB, CAN':
        return 'G10'
    elif market == 'WHISTLER, BC, CAN' or market \
        == 'NIAGARA-ON-THE-LAKE, ON, CAN' or market \
        == 'MONT TREMBLANT, QC, CAN' or market == 'UCLUELET, BC, CAN':
        return 'G11'
    elif market == 'COLLINGWOOD, ON, CAN' or market \
        == 'BC INTERIOR SKI, BC, CAN' or market == 'HALIFAX, NS, CAN' \
        or market == 'WINNIPEG, MB, CAN' or market == 'LONDON, ON, CAN' \
        or market == 'KAMLOOPS, BC, CAN':
        return 'G12'
    else: 'others' 
        
#Registering functions as UDF
udfsrchbcanada_region_city=udf(srchbcanada_region_city, StringType())
udfsrchbcanada_region_star_rating=udf(srchbcanada_region_star_rating, StringType())
udfsrchbcanada_region_Hotel_type=udf(srchbcanada_region_Hotel_type, StringType())
udfsrchbcanada_region_market=udf(srchbcanada_region_market, StringType())

#adding udf's to existing dataframe as coloumns.
Canada_AD = Canada_AD.withColumn("CITY_BUCKET", udfsrchbcanada_region_city("city")).\
            withColumn("STAR_RATING_BUCKET", udfsrchbcanada_region_star_rating("star_rating")).\
            withColumn("HOTEL_TYPE_BUCKET", udfsrchbcanada_region_Hotel_type("hotel_type")).\
            withColumn("MARKET_BUCKET", udfsrchbcanada_region_market("market")).\
            withColumn("REGION_BUCKET", lit("NA")).withColumn("MODEL_NAME", lit("Canada"))

# US region tabel
#filter the outliers and selecting the required data
US_AD = Hotel_Dim.filter((Hotel_Dim["region"] == 'FLORIDA (USA)') |(Hotel_Dim["region"] == 'NEW YORK CITY') \
                          |(Hotel_Dim["region"] == 'CALIFORNIA') |(Hotel_Dim["region"] == 'GAMING (USA)') \
                          |(Hotel_Dim["region"] == 'NORTHEAST (USA)') |(Hotel_Dim["region"] == 'MOUNTAIN (USA)') \
                          | (Hotel_Dim["region"] == 'MIDWEST (USA)') |(Hotel_Dim["region"] == 'CENTRAL (USA)') \
                          | (Hotel_Dim["region"] == 'SF PACNW ') |(Hotel_Dim["region"] == 'ORLANDO') ) 

#writing the user-defined functions for binning/bucketing
def srchbUS_region_star_rating(star_rating):
    if star_rating == '2.0':
        return '2'
    elif star_rating == '2.5':
        return '2.5'
    elif star_rating == '3.0':
        return '3'
    elif star_rating == '3.5':
        return '3.5'
    elif star_rating == '4.0':
        return '4'
    elif star_rating == '1.0' or star_rating == '1.5':
        return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0':
        return '4.5-5'
    else:'0'


def srchbUS_region_Hotel_type(Hotel_type):
    if Hotel_type == 'HOTEL':
        return 'HOTEL'
    elif Hotel_type == 'HOTEL RESORT':
        return 'HOTEL RESORT'
    elif Hotel_type == 'CONDOMINIUM RESORT' or Hotel_type == 'CONDO':
        return 'CONDO'
    elif Hotel_type == 'LODGE' or Hotel_type == 'BED & BREAKFAST' \
        or Hotel_type == 'HOSTEL/BACKPACKER ACCOMMODATION' or 'CABIN' \
        or Hotel_type == 'GUEST HOUSE':
        return 'Budget_hotel'
    elif Hotel_type == 'APART-HOTEL' or Hotel_type == 'INN':
        return 'Family_Premium'
    else:'others'
        


#registering functions as UDF
udfsrchbUS_region_star_rating=udf(srchbUS_region_star_rating, StringType())
udfsrchbUS_region_Hotel_type=udf(srchbUS_region_Hotel_type, StringType())

#adding udf's to existing dataframe as coloumns.
US_AD = US_AD.withColumn("STAR_RATING_BUCKET", udfsrchbUS_region_star_rating("star_rating"))\
        .withColumn("HOTEL_TYPE_BUCKET", udfsrchbUS_region_Hotel_type("hotel_type"))\
        .withColumn("CITY_BUCKET", lit("NA")).withColumn("MARKET_BUCKET", lit("NA")).withColumn("REGION_BUCKET", lit("NA")).withColumn("MODEL_NAME", lit("US"))

		
##Mexico region tabel
#filter the outliers and selecting the required data
Mexico_AD = Hotel_Dim.filter((Hotel_Dim["region"] == "MEXICO - DOMESTIC REGION")|(Hotel_Dim["region"] == ' MEXICO - RESORTS REGION'))


#writing the user-defined functions for binning/bucketing
def srchbMexico_region_star_rating(star_rating):
    if star_rating == '2.0':
        return '2'
    elif star_rating == '2.5':
        return '2.5'
    elif star_rating == '3.0':
        return '3'
    elif star_rating == '3.5':
        return '3.5'
    elif star_rating == '4.0':
        return '4'
    elif star_rating == '1.0' or star_rating == '1.5':
        return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0':
        return '4.5-5'
    else:'0'


def srchbMexico_region_Hotel_type(Hotel_type):
    if Hotel_type == 'HOTEL':
        return 'HOTEL'
    elif Hotel_type == 'HOTEL RESORT':
        return 'HOTEL RESORT'
    elif Hotel_type == 'ALL-INCLUSIVE':
        return 'ALL-INCLUSIVE'
    elif Hotel_type == 'CONDOMINIUM RESORT' or Hotel_type == 'CONDO':
        return 'CONDO'
    elif Hotel_type == 'LODGE' or Hotel_type == 'BED & BREAKFAST' \
        or Hotel_type == 'HOSTEL/BACKPACKER ACCOMMODATION' or 'CABIN' \
        or Hotel_type == 'GUEST HOUSE':
        return 'Budget_hotel'
    elif Hotel_type == 'APART-HOTEL' or Hotel_type == 'INN':
        return 'Family_Premium'
    else:'others'


def srchbMexico_region_market(market):
    if market == 'MEXICO - RIVIERA MAYA, PLAYA DEL CARMEN & TULUM':
        return 'MEXICO - RIVIERA MAYA, PLAYA DEL CARMEN & TULUM'
    elif market == 'MEXICO - CANCUN & ISLA MUJERES':
        return 'MEXICO - CANCUN & ISLA MUJERES'
    elif market \
        == 'MEXICO - PUERTO VALLARTA, NUEVO VALLARTA & RIVIERA NAYARIT':
        return 'MEXICO - PUERTO VALLARTA, NUEVO VALLARTA & RIVIERA NAYARIT'
    elif market == 'MEXICO - LOS CABOS':
        return 'MEXICO - LOS CABOS'
    elif market == 'CENTRAL AMERICA - COSTA RICA - GUANACASTE':
        return 'CENTRAL AMERICA - COSTA RICA - GUANACASTE'
    elif market == 'CENTRAL AMERICA - BELIZE':
        return 'CENTRAL AMERICA - BELIZE'
    elif market == 'CENTRAL AMERICA - COSTA RICA - PUNTARENAS':
        return 'CENTRAL AMERICA - COSTA RICA - PUNTARENAS'
    elif market == 'CENTRAL AMERICA - COSTA RICA - OTHER':
        return 'CENTRAL AMERICA - COSTA RICA - OTHER'
    elif market == 'MEXICO - COZUMEL':
        return 'MEXICO - COZUMEL'
    elif market == 'MEXICO - HUATULCO':
        return 'MEXICO - HUATULCO'
    elif market == 'MEXICO - IXTAPA & ZIHUATANEJO':
        return 'MEXICO - IXTAPA & ZIHUATANEJO'
    elif market == 'CENTRAL AMERICA - HONDURAS':
        return 'CENTRAL AMERICA - HONDURAS'
    elif market == 'CENTRAL AMERICA - PANAMA - OTHER':
        return 'CENTRAL AMERICA - PANAMA - OTHER'
    elif market == 'CENTRAL AMERICA - COSTA RICA - SAN JOSE' or market \
        == 'CENTRAL AMERICA - PANAMA - PANAMA CITY' or market \
        == 'MEXICO - MEXICO CITY' or market == 'MEXICO - MEXICO CITY':
        return 'hclt'
    elif market == 'CENTRAL AMERICA - NICARAGUA' or market \
        == 'MEXICO - MAZATLAN' or market == 'MEXICO - MANZANILLO' \
        or market == 'CENTRAL AMERICA - EL SALVADOR' or market \
        == 'MEXICO - ACAPULCO':
        return 'hclt'
    else:'others'
        
#Registering functions as UDF's        
udfsrchbMexico_region_star_rating=udf(srchbMexico_region_star_rating, StringType())
udfsrchbMexico_region_Hotel_type=udf(srchbMexico_region_Hotel_type, StringType())
udfsrchbMexico_region_market=udf(srchbMexico_region_market, StringType())

#Adding the udf as coloumns to existing data frame.
Mexico_AD = Mexico_AD.withColumn("STAR_RATING_BUCKET", udfsrchbMexico_region_star_rating("star_rating")).\
            withColumn("HOTEL_TYPE_BUCKET", udfsrchbMexico_region_Hotel_type("hotel_type")).\
            withColumn("MARKET_BUCKET", udfsrchbMexico_region_market("market")).withColumn("CITY_BUCKET", lit("NA")).\
            withColumn("REGION_BUCKET", lit("NA")).withColumn("MODEL_NAME", lit("Mexico"))

## Caribbean region table
#filter the outliers and selecting the required data
Caribbean_AD = Hotel_Dim.filter(Hotel_Dim["region"] == "CARIBBEAN")

#writing the user-defined functions for binning/bucketing
def srchbCaribbean_region_star_rating(star_rating):
    if star_rating == '2.0':
        return '2'
    elif star_rating == '2.5':
        return '2.5'
    elif star_rating == '3.0':
        return '3'
    elif star_rating == '3.5':
        return '3.5'
    elif star_rating == '4.0':
        return '4'
    elif star_rating == '1.0' or star_rating == '1.5':
        return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0':
        return '4.5-5'
    else:'0'


def srchbCaribbean_region_Hotel_type(Hotel_type):
    if Hotel_type == 'HOTEL':
        return 'HOTEL'
    elif Hotel_type == 'HOTEL RESORT':
        return 'HOTEL RESORT'
    elif Hotel_type == 'ALL-INCLUSIVE':
        return 'ALL-INCLUSIVE'
    elif Hotel_type == 'CONDOMINIUM RESORT' or Hotel_type == 'CONDO':
        return 'CONDO'
    elif Hotel_type == 'APART-HOTEL' or Hotel_type == 'INN':
        return 'Family_Premium'
    else:'others'


def srchbCaribbean_region_market(market):
    if market == 'PUNTA CANA, DOMINICAN REPUBLIC':
        return 'PUNTA CANA, DOMINICAN REPUBLIC'
    elif market == 'TURKS AND CAICOS':
        return 'TURKS AND CAICOS'
    elif market == 'MONTEGO BAY, JAMAICA':
        return 'MONTEGO BAY, JAMAICA'
    elif market == 'ST. LUCIA':
        return 'ST. LUCIA'
    elif market == 'OCHO RIOS, JAMAICA':
        return 'OCHO RIOS, JAMAICA'
    elif market == 'NEGRIL, JAMAICA':
        return 'NEGRIL, JAMAICA'
    elif market == 'BARBADOS':
        return 'BARBADOS'
    elif market == 'ARUBA' or market \
        == 'PUERTO PLATA, DOMINICAN REPUBLIC' or market \
        == 'ANTIGUA AND BARBUDA':
        return 'G8'
    elif market == 'NASSAU, BAHAMAS' or market \
        == 'DOMINICAN REPUBLIC ALL OTHER' or market == 'BERMUDA' \
        or market == 'BAHAMAS, OUT ISLANDS':
        return 'G9'
    elif market == 'SAN JUAN, PUERTO RICO' or market \
        == 'PARADISE ISLAND, BAHAMAS' or market == 'CAYMAN ISLANDS' \
        or market == 'SINT MAARTEN, DUTCH' or market == 'CURACAO' \
        or market == 'ST. MARTIN, FRENCH':
        return 'G10'
    else:'others'

#Registering functions to UDF's
udfsrchbCaribbean_region_star_rating=udf(srchbCaribbean_region_star_rating, StringType())
udfsrchbCaribbean_region_Hotel_type=udf(srchbCaribbean_region_Hotel_type, StringType())
udfsrchbCaribbean_region_market=udf(srchbCaribbean_region_market, StringType())

#adding udf as coloumn to existing dataframe
Caribbean_AD = Caribbean_AD.withColumn("STAR_RATING_BUCKET", udfsrchbCaribbean_region_star_rating("star_rating")).\
                withColumn("HOTEL_TYPE_BUCKET", udfsrchbCaribbean_region_Hotel_type("hotel_type")).\
                withColumn("MARKET_BUCKET", udfsrchbCaribbean_region_market("market")).withColumn("CITY_BUCKET",lit("NA"))\
                .withColumn("REGION_BUCKET",lit("NA")).withColumn("MODEL_NAME",lit("CARIBBEAN"))

#other region table
#filter the outliers and selecting the required data
Other_Region_AD = Hotel_Dim.filter((Hotel_Dim["region"] == 'SPAIN & PORTUGAL') |(Hotel_Dim["region"] == 'ROME & ITALY RESORTS')\
                                    |(Hotel_Dim["region"] == 'MID-ATLANTIC') |(Hotel_Dim["region"] == 'GREECE & TURKEY') \
                                   |(Hotel_Dim["region"] == 'PARIS') |(Hotel_Dim["region"] == 'OCEANIA') \
                                   | (Hotel_Dim["region"] == 'ITALY NORTH') |(Hotel_Dim["region"] == 'LONDON, ENGLAND') \
                                   | (Hotel_Dim["region"] == 'THAILAND') |(Hotel_Dim["region"] == 'MIDDLE EAST AND INDIAN OCEAN') \
                                   | (Hotel_Dim["region"] == 'EUROPE REGIONAL TERRITORIES') |(Hotel_Dim["region"] == 'UK & IRELAND') \
                                   | (Hotel_Dim["region"] == 'AFRICA AND EAST MED') |(Hotel_Dim["region"] == 'EASTERN EUROPE') \
                                   | (Hotel_Dim["region"] == 'GERMANY, AUSTRIA & SWITZERLAND') |(Hotel_Dim["region"] == 'JAPAN & MICRONESIA') \
                                   | (Hotel_Dim["region"] == 'PHILIPPINES') |(Hotel_Dim["region"] == 'BENELUX') |(Hotel_Dim["region"] == 'FRANCE') \
                                   | (Hotel_Dim["region"] == 'INDONESIA') |(Hotel_Dim["region"] == 'INDIAN SUBCONTINENT') |(Hotel_Dim["region"] == 'HONG KONG & MACAU') \
                                   | (Hotel_Dim["region"] == 'SOUTHEAST ASIA EMERGING') |(Hotel_Dim["region"] == 'NORDIC') \
                                   | (Hotel_Dim["region"] == 'MAINLAND CHINA') |(Hotel_Dim["region"] == 'SOUTH KOREA')  |(Hotel_Dim["region"] == 'SINGAPORE (REGION)') \
                                   | (Hotel_Dim["region"] == 'MALAYSIA') |(Hotel_Dim["region"] == 'TAIWAN') |(Hotel_Dim["region"] == 'UNKNOWN') \
                                   | (Hotel_Dim["region"] == 'SOUTH AMERICA'))

#writing the user-defined functions for binning/bucketing
def srchbother_region_star_rating(star_rating):
    if star_rating == '2.0':
        return '2'
    elif star_rating == '2.5':
        return '2.5'
    elif star_rating == '3.0':
        return '3'
    elif star_rating == '3.5':
        return '3.5'
    elif star_rating == '4.0':
        return '4'
    elif star_rating == '1.0' or star_rating == '1.5':
        return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0':
        return '4.5-5'
    else:'0'


def srchbother_region_Hotel_type(Hotel_type):
    if Hotel_type == 'HOTEL':
        return 'HOTEL'
    elif Hotel_type == 'HOTEL RESORT':
        return 'HOTEL RESORT'
    elif Hotel_type == 'APART-HOTEL':
        return 'APART-HOTEL'
    elif Hotel_type == 'GUEST HOUSE' or Hotel_type == 'BED & BREAKFAST' \
        or Hotel_type == 'HOSTEL/BACKPACKER ACCOMMODATION' \
        or Hotel_type == 'MOTEL' or Hotel_type == 'HOSTAL':
        return 'Budget_hotel'
    elif Hotel_type == 'APARTMENT' or Hotel_type == 'RESIDENCE' \
        or Hotel_type == 'TOWNHOUSE' or Hotel_type == 'INN':
        return 'Budget_hotel'
    else:'others'


def srchbother_region_REGION_BUCKET(region):
    if region == 'SPAIN & PORTUGAL':
        return 'SPAIN & PORTUGAL'
    elif region == 'ROME & ITALY RESORTS':
        return 'ROME & ITALY RESORTS'
    elif region == 'MID-ATLANTIC':
        return 'MID-ATLANTIC'
    elif region == 'GREECE & TURKEY':
        return 'GREECE & TURKEY'
    elif region == 'OCEANIA':
        return 'OCEANIA'
    elif region == 'ITALY NORTH':
        return 'ITALY NORTH'
    elif region == 'THAILAND':
        return 'THAILAND'
    elif region == 'MIDDLE EAST AND INDIAN OCEAN':
        return 'MIDDLE EAST AND INDIAN OCEAN'
    elif region == 'PARIS' or region == 'LONDON' or region == 'ENGLAND':
        return 'G9'
    elif region == 'EUROPE REGIONAL TERRITORIES' or region \
        == 'UK & IRELAND':
        return 'G10'
    elif region == 'SOUTH AMERICA' or region == 'AFRICA AND EAST MED':
        return 'G11'
    elif region == 'EASTERN EUROPE' or region \
        == 'GERMANY, AUSTRIA & SWITZERLAND' or region == 'BENELUX' \
        or region == 'FRANCE' or region == 'NORDIC':
        return 'G12'
    elif region == 'JAPAN & MICRONESIA' or region \
        == 'HONG KONG & MACAU' or region == 'SOUTHEAST ASIA EMERGING' \
        or region == 'MAINLAND CHINA':
        return 'G13'
    else:'others'
        
#Registering functions to UDF's   
udfsrchbother_region_star_rating=udf(srchbother_region_star_rating, StringType())
udfsrchbother_region_Hotel_type=udf(srchbother_region_Hotel_type, StringType())
udfsrchbother_region_REGION_BUCKET=udf(srchbother_region_REGION_BUCKET, StringType())

#adding udf as coloumn to existing dataframe
Other_Region_AD = Other_Region_AD.withColumn("STAR_RATING_BUCKET", udfsrchbother_region_star_rating("star_rating")).\
                    withColumn("HOTEL_TYPE_BUCKET", udfsrchbother_region_Hotel_type("hotel_type")).\
                    withColumn("MARKET_BUCKET",lit("NA")).\
                    withColumn("REGION_BUCKET", udfsrchbother_region_REGION_BUCKET("region"))\
                    .withColumn("CITY_BUCKET", lit("NA")).withColumn("MODEL_NAME", lit("Other Region"))

 
# North America region table
#filter the outliers and selecting the required data
NA_AD = Hotel_Dim.filter(Hotel_Dim["region"] == "NORTH AMERICA REGIONAL TERRITORIES")

#writing the user-defined functions for binning/bucketing
def srchbNAdf_region_star_rating(star_rating):
    if star_rating == '2.0':
        return '2'
    elif star_rating == '2.5':
        return '2.5'
    elif star_rating == '3.0':
        return '3'
    elif star_rating == '3.5':
        return '3.5'
    elif star_rating == '4.0':
        return '4'
    elif star_rating == '1.0' or star_rating == '1.5':
        return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0':
        return '4.5-5'
    else:'0'


def srchbNA_region_Hotel_type(Hotel_type):
    if Hotel_type == 'HOTEL':
        return 'HOTEL'
    elif Hotel_type == 'MOTEL':
        return 'MOTEL'
    elif Hotel_type == 'LODGE' or Hotel_type == 'BED & BREAKFAST' \
        or Hotel_type == 'COTTAGE' or Hotel_type == 'GUEST HOUSE' \
        or Hotel_type == 'CABIN':
        return 'Budget_hotel'
    elif Hotel_type == 'APARTMENT' or Hotel_type == 'HOTEL RESORT' \
        or Hotel_type == 'CONDO' or Hotel_type == 'INN' or Hotel_type \
        == 'APART-HOTEL' or Hotel_type == 'CARAVAN PARK':
        return 'Family_Premium'
    else:'others'

	
def srchbNA_region_market(market):
    if market == 'GRAVENHURST - BRACEBRIDGE - HUNTSVILLE, ON, CAN' or market == 'ONTARIO WEST, ON, CAN' or market == 'ABBOTSFORD - CHILLIWACK, BC, CAN' or market =='MAINE - COAST' \
    or market == 'ONTARIO EAST, ON, CAN' or market == 'VANCOUVER ISLAND, BC, CAN' or market == 'BURLINGTON, VT' \
    or market == 'CHARLOTTETOWN, PEI, CAN': return 'G1'
    
    elif market == 'ALBERTA EAST, AB, CAN' or market == 'REGINA, SK, CAN' or market == 'KINGSTON, ON, CAN' or market == 'SASKATOON, SK, CAN'  \
    or market == 'MONCTON, NB, CAN' or market == 'TRI-CITIES (KW-GUELPH-CAMBRIDGE), ON, CAN': return 'G2'
    
    elif market == 'WINDSOR, ON, CAN' or market == 'RED DEER, AB, CAN' or market == 'BRITISH COLUMBIA SOUTH, BC, CAN' or market == 'GRAND FORKS, ND'  \
    or market == 'SUDBURY, ON, CAN' or market == 'ONTARIO NORTH, ON, CAN'or market == 'BANGOR, ME' \
    or market == 'HAMILTON - BRANTFORD, ON, CAN' or market == 'BELLEVILLE - TRENTON - COBOURG, ON, CAN'or market == 'FARGO, ND': return 'G3'
    
    elif market == 'LAKE PLACID, NY' or market == 'PARKSVILLE, VANCOUVER ISLAND, BC, CAN' or market == 'LAKE GEORGE, NY' or market == 'OGUNQUIT, ME' or market =='EVERETT, WA'  \
    or market == 'COASTAL, BC, CAN' or market == 'GROVE CITY, PA' or market == 'BELLINGHAM, WA' \
    or market == 'NORTH CONWAY, NH' or market == 'NEWFOUNDLAND OTHER, NL, CAN' or market == 'NOVA SCOTIA SOUTH, NS, CAN' \
    or market == 'PORTSMOUTH, NH' : return 'G4'
        
    elif market == 'LETHBRIDGE, AB, CAN' or market == 'FREDERICTON, NB, CAN' or market == 'BRANDON, MB, CAN' or market == 'ERIE, PA'  \
    or market == 'NANAIMO, VANCOUVER ISLAND, BC, CAN' or market == 'SASKATCHEWAN SOUTH, SK, CAN' or market == 'PRINCE GEORGE - QUESNEL, BC, CAN' \
    or market == 'MEDICINE HAT, AB, CAN' or market == 'GRANDE PRAIRIE, AB, CAN' or market == 'ALBERTA NORTH, AB, CAN' \
    or market == 'DURHAM, ON, CAN' or market == 'BRITISH COLUMBIA CENTRAL, BC, CAN' or market == 'ONTARIO SOUTHWEST, ON, CAN' \
    or market == 'SAULT STE. MARIE, ON, CAN' or market == 'THUNDER BAY, ON, CAN' or market == 'SAINT JOHN, NB, CAN' \
    or market == 'GREAT FALLS, MT' or market == 'MINOT, ND (AREA)' or market == 'BRITISH COLUMBIA NORTH, BC, CAN' \
    or market == 'NORTH BAY, ON, CAN' or market == 'PETERBOROUGH, ON, CAN' or market == 'CAPE BRETON ISLAND, NS, CAN' \
    or market == 'ALBERTA WEST, AB, CAN' or market == 'HUDSON VALLEY - POUGHKEEPSIE, NY' or market == 'FORT MCMURRAY, AB, CAN' \
    or market == 'NOVA SCOTIA NORTH, NS, CAN' or market == 'WATERTOWN, NY' or market == 'EDMUNSTON, NB, CAN' \
    or market == 'OLYMPIC NATIONAL PARK AREA, WA' or market == 'CEDAR CITY - BRYCE CANYON NATIONAL PARK, UT' or market == 'SUMMERSIDE, PEI, CAN' \
    or market == 'SALEM, OR (AREA)' or market == 'BUTTE - HELENA, MT' or market == 'BECKLEY, WV': return 'G5'
    
    elif market == 'SAGINAW, MI' or market == 'WHITE MOUNTAINS, NH' or market == 'FINGER LAKES NEW YORK' or market == 'NEW YORK - WEST' or market =='NEW BRUNSWICK NORTH, NB, CAN'  \
    or market == 'SASKATCHEWAN NORTH, SK, CAN' or market == 'MANITOBA SOUTH, MB, CAN' or market == 'BAR HARBOR, ME' \
    or market == 'WASHINGTON NORTHWEST' or market == 'VERMONT CENTRAL' or market == 'ALBERTA SOUTH, AB, CAN' \
    or market == 'WENATCHEE-LEAVENWORTH,WA' or market == 'GANANOQUE, ON, CAN' or market == 'PLATTSBURGH, (NY)' \
    or market == 'STRAITS OF MACKINAC, MI' or market == 'SANDUSKY, OH' or market == 'MANCHESTER, NH' \
    or market == 'ITHACA, NY' or market == 'MINNESOTA NORTHWEST' or market == 'MISSOULA, MT (AREA)' \
    or market == 'YELLOWKNIFE, NT, CAN' or market == 'PEI OTHER, PEI, CAN' or market == 'BILLINGS, MT (AREA)' \
    or market == 'RAPID CITY - MOUNT RUSHMORE, SD' or market == 'ANDOVER, MA'or market =='YUMA, AZ' or market == 'PORT HURON, MI' \
    or market == 'LANCASTER, PA' or market == 'FORT LEE - PARAMUS, NJ' or market == 'LEXINGTON, KY' \
    or market == 'MANITOBA NORTH, MB, CAN' or market == 'ABERDEEN - OCEAN SHORES, WA' or market == 'CANADA TERRITORIES, YT, CAN' \
    or market == 'KNOXVILLE, TN' or market == 'BURLINGTON - MOUNT VERNON, WA' or market == 'FREDERICKSBURG, VA' \
    or market == 'ARIZONA SOUTHEAST' or market == 'WINDHAM COUNTY, VT' or market == 'KENAI PENINSULA, AK' \
    or market == 'COLUMBIA, SC' or market == 'CALIFORNIA DESERTS SOUTH'  : return 'G6'
    
    elif market == 'ROME-UTICA, NY' or market == 'SANDPOINT, ID (AREA)' or market == 'MOAB - GREEN RIVER, UT' or market == 'WHITEHORSE, YT, CAN' or market =='NEW YORK - NORTHEAST'  \
    or market == 'SARNIA, ON, CAN' or market == 'AUGUSTA, ME' or market == 'LAKE POWELL - GLEN CANYON NATIONAL PARK, AZ' \
    or market == 'NEW YORK - SOUTH' or market == 'BISMARK, ND' or market == 'ALABAMA NORTH' \
    or market == 'ASHLAND - MEDFORD, OR' or market == 'WASHINGTON NORTHEAST' or market == 'THE BERKSHIRES, MA' \
    or market == 'EUGENE, OR (AREA)' or market == 'GRAND RAPIDS, MI' or market == 'WASHINGTON SOUTHWEST' \
    or market == 'LAKE HAVASU CITY, AZ' or market == 'SARATOGA, NY' or market == 'WYTHEVILLE - VA' \
    or market == 'ARCATA - EUREKA, CA' or market == 'SOUTH CAROLINA EAST' or market == 'CHATTANOOGA, TN' \
    or market == 'TOLEDO, OH' or market == 'IDAHO FALLS, ID' or market == 'WEST VIRGINIA SOUTH' \
    or market == 'SPRINGFIELD, MA' or market == 'OLYMPIA, WA' or market == 'GETTYSBURG - PA' : return 'G7'
    
    else : return 'Others'

	
#Registering functions to UDF's
udfsrchbNAdf_region_star_rating=udf(srchbNAdf_region_star_rating, StringType())
udfsrchbNA_region_Hotel_type=udf(srchbNA_region_Hotel_type, StringType())
udfsrchbNA_region_market=udf(srchbNA_region_market, StringType())

#adding these UDF's as columns for existing dataframes
NA_AD = NA_AD.withColumn("STAR_RATING_BUCKET", udfsrchbNAdf_region_star_rating("star_rating")).\
        withColumn("HOTEL_TYPE_BUCKET", udfsrchbNA_region_Hotel_type("hotel_type")).\
        withColumn("MARKET_BUCKET", udfsrchbNA_region_market("market")).withColumn("CITY_BUCKET", lit("NA"))\
        .withColumn("REGION_BUCKET", lit("NA")).withColumn("MODEL_NAME", lit("North America"))

## All super region tables completed need to do union of all tables.
Hotel_Dim_Final = Canada_AD.unionAll(Mexico_AD).unionAll(Caribbean_AD).unionAll(Other_Region_AD).unionAll(NA_AD).unionAll(US_AD)

Hotel_Dim_Final = Hotel_Dim_Final.drop('city').drop('region').drop('market').drop('brand').drop('star_rating').drop('hotel_type')

##creating search query universe
bkts = LOS_BUCKET_DF.join(BW_BUCKET_DF)
optimization_ad = Hotel_Dim_Final.join(bkts)

##HCBA DATA for average weekly traffic
##CREATE THE LIST OF DATES FOR WHICH DATA IS REQUIRED
from datetime import *
import time
start_date = datetime.strptime(time.strftime("%Y-%m-%d"), "%Y-%m-%d") #STARTING DATE
no_days = 4  #NO. OF DAYS FOR WHICH DATA IS REQUIRED
date_list = []
for i in range(no_days):
    x = (start_date - timedelta(i))
    x = x.strftime("%Y-%m-%d")
    date_list.append(x)

##SCHEMA FOR HCBA TABLE
HCBAschema = StructType([	StructField('PARTNER_POS',StringType(), True),
							StructField('DEVICE_TYPE',StringType(), True),
							StructField('CLICKED_HOTEL_ID',IntegerType(), True),
							StructField('SRCH_WINDOW',IntegerType(), True),
							StructField('SRCH_LOS',IntegerType(), True),
							StructField('TRAFFIC',IntegerType(), True),
							StructField('COST',DoubleType(), True),
							StructField('BOOKED_FLAG',StringType(), True),
							StructField('BOOKED_HOTEL_ID',IntegerType(), True),
							StructField('BOOKED_LOS',IntegerType(), True),
							StructField('BOOKED_BKG_WINDOW',IntegerType(), True),
							StructField('GROSS_PROFIT',DoubleType(), True),
							StructField('PARTNER_ORG',StringType(), True),
							StructField('ACTIVITY_DATE',StringType(), True)
						])
 

##CREATE EMPTY DATAFRAME 
HCBA = sqlContext.createDataFrame(sc.emptyRDD(), HCBAschema)

##APPENDING THE DATA IN ABOVE CREATED HCBA TABLE 
for dates in date_list:
	path_HCBA = 's3n://ewe-core-meta-prod/CORE/HOTEL_CLICK_BOOK_AGG/local_date='+dates+'/*'  
	print (path_HCBA)
	try :
		temp_HCBA = sqlCtx.read.format("com.databricks.spark.csv").options(header = False, inferschema = True, delimiter = "\t",nullValue= '\\N').load(path_HCBA)
		print('file exist')
		temp_HCBA = temp_HCBA.select('C1','C3','C7','C8','C9','C13','C14','C19','C20','C21','C22','C45','C65')
		temp_HCBA = temp_HCBA.filter((temp_HCBA.C65 == 'TRIPADVISOR') & (temp_HCBA.C1 == 'CA') & (temp_HCBA.C7 != 0) & (temp_HCBA.C13 != 0) ) 
		temp_HCBA = temp_HCBA.withColumn('ACTIVITY_DATE',lit(dates))
		HCBA = HCBA.unionAll(temp_HCBA)
	except: print('file does not exist')

##sanity checks
HCBA_CA = HCBA.cache()
#HCBA_CA.count()

##CHANGING THE DATA TYPE 
def data_type_change_int(df,cols):
    temp = df
    for col in cols:
        temp = temp.withColumn(col+'_1',df[col].cast(IntegerType())).drop(col).withColumnRenamed(col+'_1',col)
    return temp

def data_type_change_float(df,cols):
    temp = df
    for col in cols:
        temp = temp.withColumn(col+'_1',df[col].cast(DoubleType())).drop(col).withColumnRenamed(col+'_1',col)
    return temp

cols_int = ['SRCH_LOS','SRCH_WINDOW','TRAFFIC','BOOKED_BKG_WINDOW','BOOKED_LOS']
cols_float = ['COST','GROSS_PROFIT']

HCBA_CA = data_type_change_int(HCBA_CA,cols_int)
HCBA_CA = data_type_change_float(HCBA_CA,cols_float)

#writing the user-defined functions for binning/bucketing Length of Stay, Booking Window (Search and Booking parameters)


def searchToCategory(srch_los):
    if srch_los == 0:
        return '0'
    elif srch_los == 1:
        return '1'
    elif srch_los == 2:
        return '2'
    elif srch_los == 3:
        return '3'
    elif srch_los == 4:
        return '4'
    elif srch_los == 5:
        return '5'
    elif srch_los == 6:
        return '6'
    elif srch_los == 7:
        return '7'
    elif srch_los >= 8 and srch_los <= 14:
        return '8-14'
    else:
        return '>14'


def searchbucketToCategory(SRCH_WINDOW):
    if SRCH_WINDOW <= 0:
        return '<=0'
    elif SRCH_WINDOW == 1:
        return '1'
    elif SRCH_WINDOW == 2:
        return '2'
    elif SRCH_WINDOW >= 3 and SRCH_WINDOW <= 4:
        return '3-4'
    elif SRCH_WINDOW >= 5 and SRCH_WINDOW <= 7:
        return '5-7'
    elif SRCH_WINDOW >= 8 and SRCH_WINDOW <= 14:
        return '8-14'
    elif SRCH_WINDOW >= 15 and SRCH_WINDOW <= 20:
        return '15-20'
    elif SRCH_WINDOW >= 21 and SRCH_WINDOW <= 30:
        return '21-30'
    elif SRCH_WINDOW >= 31 and SRCH_WINDOW <= 40:
        return '31-40'
    elif SRCH_WINDOW >= 41 and SRCH_WINDOW <= 60:
        return '41-60'
    elif SRCH_WINDOW >= 61 and SRCH_WINDOW <= 90:
        return '61-90'
    elif SRCH_WINDOW >= 91 and SRCH_WINDOW <= 120:
        return '91-120'
    elif SRCH_WINDOW >= 121 and SRCH_WINDOW <= 180:
        return '121-180'
    elif SRCH_WINDOW >= 181 and SRCH_WINDOW <= 240:
        return '181-240'
    else:
        return '>240'


def srchBOOKED_LOS_BUCKET(booked_los):
    if booked_los is None:
        return '0'
    elif booked_los == 0:
        return '0'
    elif booked_los == 1:
        return '1'
    elif booked_los == 2:
        return '2'
    elif booked_los == 3:
        return '3'
    elif booked_los == 4:
        return '4'
    elif booked_los == 5:
        return '5'
    elif booked_los == 6:
        return '6'
    elif booked_los == 7:
        return '7'
    elif booked_los >= 8 and booked_los <= 14:
        return '8-14'
    else:
        return '>14'


def srchBOOKED_BW_BUCKET(BOOKED_BKG_WINDOW):
    if BOOKED_BKG_WINDOW is None:
        return '0'
    elif BOOKED_BKG_WINDOW <= 0:
        return '<= 0'
    elif BOOKED_BKG_WINDOW == 1:
        return '1'
    elif BOOKED_BKG_WINDOW == 2:
        return '2'
    elif BOOKED_BKG_WINDOW >= 3 or BOOKED_BKG_WINDOW <= 4:
        return '3-4'
    elif BOOKED_BKG_WINDOW >= 5 or BOOKED_BKG_WINDOW <= 7:
        return '5-7'
    elif BOOKED_BKG_WINDOW >= 8 or BOOKED_BKG_WINDOW <= 14:
        return '8-14'
    elif BOOKED_BKG_WINDOW >= 15 or BOOKED_BKG_WINDOW <= 20:
        return '15-20'
    elif BOOKED_BKG_WINDOW >= 21 or BOOKED_BKG_WINDOW <= 30:
        return '21-30'
    elif BOOKED_BKG_WINDOW >= 31 or BOOKED_BKG_WINDOW <= 40:
        return '31-40'
    elif BOOKED_BKG_WINDOW >= 41 or BOOKED_BKG_WINDOW <= 60:
        return '41-60'
    elif BOOKED_BKG_WINDOW >= 61 or BOOKED_BKG_WINDOW <= 90:
        return '61-90'
    elif BOOKED_BKG_WINDOW >= 91 or BOOKED_BKG_WINDOW <= 120:
        return '91-120'
    elif BOOKED_BKG_WINDOW >= 121 or BOOKED_BKG_WINDOW <= 180:
        return '121-180'
    elif BOOKED_BKG_WINDOW >= 181 or BOOKED_BKG_WINDOW <= 240:
        return '181-240'
    else:
        return '>240'


def booking_flag(booked_flag):
    if booked_flag == 'Y':
        return 1
    else:
        return 0
		
# Registering Functions as UDF's

udfsearchToCategory=udf(searchToCategory, StringType())
udfsearchbucketToCategory=udf(searchbucketToCategory, StringType())
udfsrchBOOKED_LOS_BUCKET=udf(srchBOOKED_LOS_BUCKET, StringType())
udfsrchsrchBOOKED_BW_BUCKET=udf(srchBOOKED_BW_BUCKET, StringType())
booking_flag_udf=udf(booking_flag, IntegerType())

# Adding UDF's as columns to existing data frame.

HCBA_CA = HCBA_CA.withColumn("SRCH_LOS_BUCKET", udfsearchToCategory("SRCH_LOS")).withColumn("SRCH_BW_BUCKET", udfsearchbucketToCategory("SRCH_WINDOW")).withColumn("BOOKED_LOS_BUCKET", udfsrchBOOKED_LOS_BUCKET("BOOKED_LOS")).withColumn("BOOKED_BW_BUCKET", udfsrchsrchBOOKED_BW_BUCKET("BOOKED_BKG_WINDOW")).withColumn("BOOKING", booking_flag_udf("BOOKED_FLAG"))

#--Replacing the rows with negative Booking Window and LOS search parameters with the Booking Parameters---#
#Selecting the required data

HCBA_CA_LOS_BW_NEGATIVE_CONV = HCBA_CA.filter((HCBA_CA['BOOKED_FLAG'] == 'Y') & ((HCBA_CA['SRCH_WINDOW'] < -1) | (HCBA_CA['SRCH_LOS'] <= 0)))
HCBA_CA_LOS_BW_NEGATIVE_CONV = HCBA_CA_LOS_BW_NEGATIVE_CONV.withColumnRenamed('BOOKED_BKG_WINDOW', 'BOOKING_WINDOW').withColumnRenamed('BOOKED_BW_BUCKET', 'BW_BUCKET').withColumnRenamed('BOOKED_LOS_BUCKET', 'LOS_BUCKET').withColumnRenamed('BOOKED_HOTEL_ID', 'HOTEL_ID').withColumnRenamed('BOOKED_LOS', 'LOS')
HCBA_CA_LOS_BW_NEGATIVE_CONV=HCBA_CA_LOS_BW_NEGATIVE_CONV.select('PARTNER_POS','DEVICE_TYPE','HOTEL_ID','PARTNER_ORG','ACTIVITY_DATE','TRAFFIC','BOOKING_WINDOW','LOS','COST','GROSS_PROFIT','LOS_BUCKET','BW_BUCKET','BOOKING')

#-------------------------------------Selecting all the non converted rows---------------------#
#Selecting the required data
HCBA_CA_NON_CONV = HCBA_CA.filter((HCBA_CA['BOOKED_FLAG'] == 'N') & (HCBA_CA['SRCH_WINDOW'] >= -1) & (HCBA_CA['SRCH_LOS'] > 0) & (HCBA_CA['GROSS_PROFIT'] == 0.0) )

#Renaming the columns as required
HCBA_CA_NON_CONV = HCBA_CA_NON_CONV.withColumnRenamed('CLICKED_HOTEL_ID', 'HOTEL_ID').withColumnRenamed('SRCH_WINDOW', 'BOOKING_WINDOW').withColumnRenamed('SRCH_BW_BUCKET', 'BW_BUCKET').withColumnRenamed('SRCH_LOS', 'LOS').withColumnRenamed('SRCH_LOS_BUCKET', 'LOS_BUCKET')
HCBA_CA_NON_CONV=HCBA_CA_NON_CONV.select('PARTNER_POS','DEVICE_TYPE','HOTEL_ID','PARTNER_ORG','ACTIVITY_DATE','TRAFFIC','BOOKING_WINDOW','LOS','COST','GROSS_PROFIT','LOS_BUCKET','BW_BUCKET','BOOKING')

#----------------------------------Selecting all converted rows-------------------------------------#
#Selecting the required data
HCBA_CA_CONV = HCBA_CA.filter((HCBA_CA['BOOKED_FLAG'] == 'Y') & (HCBA_CA['SRCH_WINDOW'] >= -1) & (HCBA_CA['SRCH_LOS'] > 0))

#Renaming the columns as required
HCBA_CA_CONV = HCBA_CA_CONV.withColumnRenamed('CLICKED_HOTEL_ID', 'HOTEL_ID').withColumnRenamed('SRCH_WINDOW', 'BOOKING_WINDOW').withColumnRenamed('SRCH_BW_BUCKET', 'BW_BUCKET').withColumnRenamed('SRCH_LOS', 'LOS').withColumnRenamed('SRCH_LOS_BUCKET', 'LOS_BUCKET')
HCBA_CA_CONV=HCBA_CA_CONV.select('PARTNER_POS','DEVICE_TYPE','HOTEL_ID','PARTNER_ORG','ACTIVITY_DATE','TRAFFIC','BOOKING_WINDOW','LOS','COST','GROSS_PROFIT','LOS_BUCKET','BW_BUCKET','BOOKING')


#---Union of all the above 3 tables HCBA_CA_NON_CONV,HCBA_CA_CONV,HCBA_CA_LOS_BW_NEGATIVE_CONV----------#
HCBA_CA_UNION = HCBA_CA_LOS_BW_NEGATIVE_CONV.unionAll(HCBA_CA_NON_CONV).unionAll(HCBA_CA_CONV)
HCBA_CA_UNION = HCBA_CA_UNION.withColumn('WEEK',weekofyear(HCBA_CA_UNION.ACTIVITY_DATE))

##populating average weekly traffic
import pyspark.sql.functions as func
HCBA_CA_UNION_agg = HCBA_CA_UNION.groupBy('HOTEL_ID','LOS_BUCKET','BW_BUCKET')
HCBA_CA_UNION_agg1 = HCBA_CA_UNION_agg.agg({'TRAFFIC':'sum'}).withColumnRenamed('sum(TRAFFIC)','TOTAL_TRAFFIC')
HCBA_CA_UNION_agg2 = HCBA_CA_UNION_agg.agg(func.countDistinct('WEEK')).withColumnRenamed('count(WEEK)','NO_WEEKS')

HCBA_CA_UNION = HCBA_CA_UNION.join(HCBA_CA_UNION_agg1,['HOTEL_ID','LOS_BUCKET','BW_BUCKET'],'inner')
HCBA_CA_UNION = HCBA_CA_UNION.join(HCBA_CA_UNION_agg2,['HOTEL_ID','LOS_BUCKET','BW_BUCKET'],'inner')

HCBA_CA_UNION = HCBA_CA_UNION.withColumn('AVERAGE_WEEKLY_TRAFFIC',HCBA_CA_UNION.TOTAL_TRAFFIC/HCBA_CA_UNION.NO_WEEKS)
HCBA_CA_UNION = HCBA_CA_UNION.select('HOTEL_ID','LOS_BUCKET','BW_BUCKET','AVERAGE_WEEKLY_TRAFFIC','DEVICE_TYPE')

optimization_ad = optimization_ad.join(HCBA_CA_UNION,['HOTEL_ID','LOS_BUCKET','BW_BUCKET'],'left_outer')

##

##CREATE EMPTY DATAFRAME
MBAP_schema = StructType([StructField('ACTIVITY_DATE',StringType(),True),
                          StructField('DEVICE_TYPE',StringType(),True),
                          StructField('HOTEL_ID',IntegerType(),True),
                          StructField('CPC',DoubleType(),True),
                          StructField('SELLER_RANK',DoubleType(),True)
                         ])
MBAP = sqlContext.createDataFrame(sc.emptyRDD(),MBAP_schema)

##APPENDING THE DATA IN ABOVE CREATED HCBA TABLE 
date_list_MBAP = []
for i in range(4):
    x = (start_date - timedelta(i))
    x = x.strftime("%Y-%m-%d")
    date_list_MBAP.append(x)


for dates in date_list_MBAP:
	path_MBAP =  's3n://ewe-meta-prod/EXPEDIA/ARCHIVE/bidding/TRIPADVISOR_mBAP_bidoutput_'+dates.replace("-","")+'.tab.gz'   
	print (path_MBAP)
	try :
		temp_MBAP = sqlCtx.read.format("com.databricks.spark.csv").options(header = True, inferschema = True, delimiter = "\t",nullValue= '\\N').load(path_MBAP)
		print('file exist')
		temp_MBAP = temp_MBAP.filter(temp_MBAP.posa == 'CA')
		temp_MBAP = temp_MBAP.select('snapshot_day','device','hotelid','final_bid_value_cpc','expected_rank')
		MBAP = MBAP.unionAll(temp_MBAP)
	except: print('file does not exist')

MBAP = MBAP.cache()

MBAP1 = MBAP.withColumnRenamed('SELLER_RANK','seller_rank_0').withColumnRenamed('CPC','cpc_0').withColumnRenamed('ACTIVITY_DATE','ACTIVITY_DATE_ACT')
						
days = [1,2,3,4,5,6,7]
rank_col_name=['seller_rank_1','seller_rank_2','seller_rank_3','seller_rank_4','seller_rank_5','seller_rank_6','seller_rank_7']
cpc_col_name=['cpc_1','cpc_2','cpc_3','cpc_4','cpc_5','cpc_6','cpc_7']

for day in days:
	d = day
	def date_change(date):
		date = datetime.strptime(date,'%Y-%m-%d') - timedelta(d)
		date = date.strftime("%Y-%m-%d")
	
	date_change_udf = udf(date_change,StringType())
		
	MBAP1 = MBAP1.withColumn('ACTIVITY_DATE',date_change_udf('ACTIVITY_DATE_ACT'))
	MBAP1 = MBAP1.join(MBAP,['ACTIVITY_DATE','HOTEL_ID','DEVICE_TYPE'],'left_outer').\
							withColumnRenamed('SELLER_RANK',rank_col_name[day-1]).withColumnRenamed('CPC',cpc_col_name[day-1]).drop('ACTIVITY_DATE')

							
MBAP1 = MBAP1.withColumn("SELLER_RANK",coalesce('seller_rank_0','seller_rank_1','seller_rank_2','seller_rank_3','seller_rank_4','seller_rank_5','seller_rank_6','seller_rank_7'))
MBAP1 = MBAP1.select([col for col in MBAP1.columns if col not in ('seller_rank_0','seller_rank_1','seller_rank_2','seller_rank_3','seller_rank_4','seller_rank_5','seller_rank_6','seller_rank_7')])

MBAP1 = MBAP1.withColumn("CPC",coalesce('cpc_0','cpc_1','cpc_2','cpc_3','cpc_4','cpc_5','cpc_6','cpc_7'))
MBAP1 = MBAP1.select([col for col in MBAP1.columns if col not in ('cpc_0','cpc_1','cpc_2','cpc_3','cpc_4','cpc_5','cpc_6','cpc_7')])

MBAP1 = MBAP1.withColumnRenamed('ACTIVITY_DATE_ACT','ACTIVITY_DATE')

def seller_rank_bucket(seller_rank):
	if seller_rank <=3 :
		return str(seller_rank)
	else:
		return ">=4"

seller_rank_bucket_udf = udf(seller_rank_bucket,StringType())
MBAP1 = MBAP1.withColumn('SELLER_RANK_BUCKET',seller_rank_bucket_udf(MBAP1.SELLER_RANK)).select('HOTEL_ID','DEVICE_TYPE','SELLER_RANK','CPC','SELLER_RANK_BUCKET')

optimization_ad = optimization_ad.join(MBAP1,['HOTEL_ID','DEVICE_TYPE'],'left_outer')


####net revenue columns
##CREATE THE LIST OF DATES FOR WHICH DATA IS REQUIRED
from datetime import *
import time
start_date = datetime.strptime(time.strftime("%Y-%m-%d"), "%Y-%m-%d") #STARTING DATE

no_days = 4  #NO. OF DAYS FOR WHICH DATA IS REQUIRED
date_list_THPA = []
for i in range(no_days):
    x = (start_date - timedelta(i))
    x = x.strftime("%Y-%m-%d")
    date_list_THPA.append(x)

TOP_schema = StructType([
						   StructField('DEVICE_TYPE',StringType(), True),
						   StructField('HOTEL_ID',IntegerType(), True),
						   StructField('BOOKING_WINDOW',IntegerType(), True),
						   StructField('LOS',IntegerType(), True),
						   StructField('ADULT_COUNT',DoubleType(), True), 
						   StructField('BASE_RATE_MIN',DoubleType(), True),
						   StructField('COMMISION_AVG',DoubleType(), True),
						   StructField('VARIABLE_MARGIN_AVG',DoubleType(), True),
						   StructField('LOCAL_DATE',StringType(), True),
						 
						 ])

THPA = sqlContext.createDataFrame(sc.emptyRDD(), TOP_schema)


	
for dates in date_list_THPA:
	path_THPA = 's3n://ewe-core-meta-prod/CORE/TOP_HOTEL_PRICE_AGG/local_date='+dates+'/*'  
	print (path_THPA)
	try :
		temp_THPA = sqlCtx.read.format("com.databricks.spark.csv").options(header = False, inferschema = True, delimiter = "\t",nullValue= '\\N').load(path_THPA)
		temp_THPA = temp_THPA.select('C2','C3','C9','C8','C10','C14','C29','C31','C32')  
		print('file exist')
		THPA = THPA.unionAll(temp_THPA)
	except: print('file does not exist')
	
THPA = THPA.distinct()
THPA = THPA.cache()
THPA = data_type_change_float(THPA, ['BASE_RATE_MIN','COMMISION_AVG','VARIABLE_MARGIN_AVG'])

def Net_rev(commission_avg, variable_margin_avg):
    x = float(commission_avg) + float(variable_margin_avg)
    return x
	
Net_revenue_udf = udf(Net_rev, DoubleType())

THPA = THPA.withColumn("NET_REVENUE",Net_revenue_udf(THPA.COMMISION_AVG,THPA.VARIABLE_MARGIN_AVG))


THPA = THPA.groupBy("HOTEL_ID","LOS","BOOKING_WINDOW","LOCAL_DATE","BASE_RATE_MIN").agg({'NET_REVENUE':'avg'}).withColumnRenamed('avg(NET_REVENUE)','NET_REVENUE_0')
THPA  = THPA.withColumn("LOS_BUCKET", udfsearchToCategory("LOS")).withColumn("BW_BUCKET", udfsearchbucketToCategory("BOOKING_WINDOW"))

optimization_ad = optimization_ad.join(THPA,["HOTEL_ID","LOS_BUCKET","BW_BUCKET"],'left_outer')


optimization_ad_Hotel_Agg = optimization_ad.groupBy("HOTEL_ID").agg({'BASE_RATE_MIN':'sum','NET_REVENUE_0':'sum'})
optimization_ad_Hotel_Agg = optimization_ad_Hotel_Agg.withColumn('NET_REVENUE_1',optimization_ad_Hotel_Agg['sum(NET_REVENUE_0)']/optimization_ad_Hotel_Agg['sum(BASE_RATE_MIN)']).\
							drop('sum(NET_REVENUE_0)').drop('sum(BASE_RATE_MIN)')

optimization_ad_Region_Agg = optimization_ad.groupBy("MODEL_NAME").agg({'BASE_RATE_MIN':'sum','NET_REVENUE_0':'sum'})
optimization_ad_Region_Agg = optimization_ad_Region_Agg.withColumn('NET_REVENUE_2',optimization_ad_Region_Agg['sum(NET_REVENUE_0)']/optimization_ad_Region_Agg['sum(BASE_RATE_MIN)']).\
							drop('sum(NET_REVENUE_0)').drop('sum(BASE_RATE_MIN)')

optimization_ad = optimization_ad.join(optimization_ad_Hotel_Agg,'HOTEL_ID','inner')
optimization_ad = optimization_ad.join(optimization_ad_Region_Agg,'MODEL_NAME','inner')
optimization_ad = optimization_ad.withColumn('NET_REVENUE',coalesce('NET_REVENUE_0','NET_REVENUE_1','NET_REVENUE_2')).drop('NET_REVENUE_1').drop('NET_REVENUE_0').drop("BASE_RATE_MIN").drop('NET_REVENUE_2')

