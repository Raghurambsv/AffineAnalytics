from pyspark import SparkContext, SparkConf
from pyspark.sql import SQLContext
from pyspark.sql.types import Row, StructField, StructType, StringType, IntegerType, DoubleType
import pandas as pd

conf = SparkConf().setAppName('ReadfromS3').setMaster('spark://10.0.83.198:7077')
sc = SparkContext(conf=conf)

sqlContext = SQLContext(sc)

headerfile = 's3://ewe-core-meta-prod/CORE/HOTEL_CLICK_BOOK_AGG/local_date=2016-05-11/header.tab'
headerdf = pd.read_csv(headerfile,sep='\t')
headersonly = headerdf.columns
headeronlyvals = headerdf.columns.values
headerlist = list(headeronlyvals)

firstfile = 's3://ewe-core-meta-prod/CORE/HOTEL_CLICK_BOOK_AGG/local_date=2016-05-11/000000_0.gz'
pdfirst = pd.read_csv(firstfile,sep='\t',compression='gzip',header=None,names=headerlist)

HCBAschema = ([StructField('PARTNER_NAME',StringType(), True),
                StructField('PARTNER_POS',StringType(), True),
                StructField('PLACEMENT_NAME',StringType(), True),
                StructField('DEVICE_TYPE',StringType(), True),
                StructField('PLATFORM',StringType(), True),
                StructField('XP_POS',StringType(), True),
                StructField('HOTEL_CORE_IND',StringType(), True),
                StructField('CLICKED_HOTEL_ID',IntegerType(), True),
                StructField('SRCH_WINDOW',IntegerType(), True),
                StructField('SRCH_LOS',IntegerType(), True),
                StructField('SRCH_TOTL_PERSN_CNT',IntegerType(), True),
                StructField('SRCH_ADULT_CNT',IntegerType(), True),
                StructField('SRCH_CHILD_CNT',IntegerType(), True),
                StructField('XCLICK',IntegerType(), True),
                StructField('XCOST',DoubleType(), True),
                StructField('PCLICK',IntegerType(), True),
                StructField('PCOST',DoubleType(), True),
                StructField('PIMPRESSION',DoubleType(), True),
                StructField('WEIGHTED_PIMPRESSION',DoubleType(), True),
                StructField('BOOKED_FLAG',StringType(), True),
                StructField('BOOKED_HOTEL_ID',StringType(), True),
                StructField('BOOKED_LOS',StringType(), True),
                StructField('BOOKED_BKG_WINDOW',StringType(), True),
                StructField('BOOKED_TOTAL_PERSON_CNT',StringType(), True),
                StructField('BOOKED_ADULT_CNT',StringType(), True),
                StructField('BOOKED_CHILD_CNT',StringType(), True),
                StructField('RLT_TRUE_UP_TRX',DoubleType(), True),
                StructField('RLT_TRUE_UP_GP_USD',DoubleType(), True),
                StructField('RLT_NON_TRUE_UP_GP_USD',DoubleType(), True),
                StructField('RLT_BID_GP_USD',DoubleType(), True),
                StructField('RLT_TRUE_UP_GBV_USD',DoubleType(), True),
                StructField('RLT_NON_TRUE_UP_GBV_USD',DoubleType(), True),
                StructField('RLT_RN',IntegerType(), True),
                StructField('RLT_TRUE_UP_NET_REV_USD',DoubleType(), True),
                StructField('RLT_NON_TRUE_UP_NET_REV_USD',DoubleType(), True),
                StructField('SS_TRUE_UP_TRX',DoubleType(), True),
                StructField('SS_TRUE_UP_GP_USD',DoubleType(), True),
                StructField('SS_NON_TRUE_UP_GP_USD',DoubleType(), True),
                StructField('SS_BID_GP_USD',DoubleType(), True),
                StructField('SS_TRUE_UP_GBV_USD',DoubleType(), True),
                StructField('SS_NON_TRUE_UP_GBV_USD',DoubleType(), True),
                StructField('SS_RN',IntegerType(), True),
                StructField('SS_TRUE_UP_NET_REV_USD',DoubleType(), True),
                StructField('SS_NON_TRUE_UP_NET_REV_USD',DoubleType(), True),
                StructField('LT_TRUE_UP_TRX',DoubleType(), True),
                StructField('LT_TRUE_UP_GP_USD',DoubleType(), True),
                StructField('LT_NON_TRUE_UP_GP_USD',DoubleType(), True),
                StructField('LT_BID_GP_USD',DoubleType(), True),
                StructField('LT_TRUE_UP_GBV_USD',DoubleType(), True),
                StructField('LT_NON_TRUE_UP_GBV_USD',DoubleType(), True),
                StructField('LT_RN',IntegerType(), True),
                StructField('LT_TRUE_UP_NET_REV_USD',DoubleType(), True),
                StructField('LT_NON_TRUE_UP_NET_REV_USD',DoubleType(), True),
                StructField('HOTEL_CANCEL_FLAG',StringType(), True),
                StructField('HOTEL_CANCEL_HOTEL_ID',StringType(), True),
                StructField('HOTEL_CANCEL_GBV_USD',StringType(), True),
                StructField('HOTEL_CANCEL_GP_USD',StringType(), True),
                StructField('HOTEL_CANCEL_RN',StringType(), True),
                StructField('HOTEL_LOB_FLAG',StringType(), True),
                StructField('SAME_HOTEL_FLAG',StringType(), True),
                StructField('SAME_CITY_FLAG',StringType(), True),
                StructField('SAME_BKG_WINDOW_FLAG',StringType(), True),
                StructField('SAME_LOS_FLAG',StringType(), True),
                StructField('SAME_DAY_CANCEL_FLAG',StringType(), True),
                StructField('BRAND',StringType(), True),
                StructField('PARTNER_ORG',StringType(), True)])

sdfirst = sqlContext.createDataFrame(pdfirst,schema=HCBAschema)

