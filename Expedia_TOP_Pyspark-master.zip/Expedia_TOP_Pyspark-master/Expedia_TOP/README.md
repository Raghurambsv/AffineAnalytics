# Expedia_TOP

Note : Do not ADD or REMOVE anything directly from GitHub.

Clone it to your local System and create a new branch

Please follow this strictly

This project contains code for Meta Channel Optimization

The project directory is 


ipython_notebook -> Contains all the Python Codes

Sql -> Contains all the Sql Codes

R -> Contains all the R codes

datasets -> Contains all the Datasets


