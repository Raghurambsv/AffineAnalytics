
# coding: utf-8

# In[ ]:

from datetime import timedelta, date
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import *
import time

##fucntion for chaging the datatype
def data_type_change_int(df,cols):
    temp = df
    for col in cols:
        temp = temp.withColumn(col+'_1',df[col].cast(IntegerType())).drop(col).withColumnRenamed(col+'_1',col)
    return temp

def data_type_change_float(df,cols):
    temp = df
    for col in cols:
        temp = temp.withColumn(col+'_1',df[col].cast(DoubleType())).drop(col).withColumnRenamed(col+'_1',col)
    return temp

#star rating buckets
def srch_region_star_rating(star_rating):
    if star_rating == '2.0':
        return '2'
    elif star_rating == '2.5':
        return '2.5'
    elif star_rating == '3.0':
        return '3'
    elif star_rating == '3.5':
        return '3.5'
    elif star_rating == '4.0':
        return '4'
    elif star_rating == '1.0' or star_rating == '1.5':
        return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0':
        return '4.5-5'
    else:
        return '0'

#udf for creating city buckets
def srch_region_city(city,model_name):
	if model_name == 'CANADA':
		if city in ('TORONTO' , 'NIAGARA FALLS' , 'MONTREAL' , 'VANCOUVER' , 'QUEBEC' , 'BANFF' , 'OTTAWA' , 'EDMONTON' , 'VICTORIA','CALGARY' , 'WHISTLER'):
			return city
		elif city in ('NIAGARA-ON-THE-LAKE','CANMORE','JASPER','KELOWNA','HALIFAX','MISSISSAUGA','LAKELOUISE','COLLINGWOOD','VERNON','PENTICTON','GATINEAU','DORVAL','MARKHAM'):
			return'G12'
		elif city in ('MONT-TREMBLANT','TOFINO','BLUEMOUNTAINS','OSOYOOS','UCLUELET','SAINT-SAUVEUR','WESTKELOWNA','LAMALBAIE','SAINTE-ADELE'):
			return'G13'
		elif city in ('WINNIPEG','LONDON','RICHMOND','BARRIE','REVELSTOKE','VAUGHAN','ORILLIA','BURNABY','SURREY'):
			return 'G14'
		else:
			return 'others'
	else:
		return 'NA'

#udf for hotel type
def srch_region_Hotel_type(Hotel_type,model_name):
	if model_name == 'CANADA':
		if Hotel_type in  ('HOTEL' , 'HOTEL RESORT' , 'MOTEL'):
			return Hotel_type
		elif Hotel_type in ('CONDOMINIUM RESORT' , 'CONDO'):
			return 'CONDO'
		elif Hotel_type in ('LODGE' , 'BED & BREAKFAST' , 'HOSTEL/BACKPACKER ACCOMMODATION' , 'CABIN' , 'GUEST HOUSE'):
			return 'Budget_hotel'
		elif Hotel_type in ('APART-HOTEL', 'INN'):
			return 'Family_Premium'
		else:
			return 'Others'
	
	elif model_name == 'US':
		if Hotel_type in  ('HOTEL' , 'HOTEL RESORT' , 'MOTEL'):
			return Hotel_type
		elif Hotel_type in ('CONDOMINIUM RESORT' ,'CONDO'):
			return 'CONDO'
		elif Hotel_type in ('LODGE' , 'BED & BREAKFAST' , 'HOSTEL/BACKPACKER ACCOMMODATION' , 'CABIN' , 'GUEST HOUSE'):
			return 'Budget_hotel'
		elif Hotel_type in ('APART-HOTEL' ,  'INN' , 'APARTMENT', 'VILLA', 'PRIVATE VACATION HOME'):
			return 'Family_Premium'
		else:
			return 'others'
		
	elif model_name == 'Mexico':
		if Hotel_type in  ('HOTEL' , 'HOTEL RESORT' , 'ALL-INCLUSIVE'):
			return Hotel_type
		elif Hotel_type in ('CONDOMINIUM RESORT' ,'CONDO'):
			return 'CONDO'
		elif Hotel_type in ('LODGE' , 'BED & BREAKFAST' , 'HOSTEL/BACKPACKER ACCOMMODATION'):
			return 'Budget_hotel'
		elif Hotel_type in ('APART-HOTEL' ,'INN' , 'VILLA' , 'APARTMENT'):
			return 'Family_Premium'
		else:
			return 'others'
		
	elif model_name=="CARIBBEAN":
		if Hotel_type in ('HOTEL' , 'HOTEL RESORT' , 'ALL-INCLUSIVE') :
			return Hotel_type
		elif Hotel_type in ('CONDOMINIUM RESORT' ,'CONDO'):
			return 'CONDO'
		elif Hotel_type in ('APART-HOTEL' ,'INN' , 'VILLA' , 'APARTMENT'):
			return 'Family_Premium'
		else:
			return 'others'
		
	elif model_name == 'Other Region':
		if Hotel_type in ('HOTEL' , 'HOTEL RESORT' , 'APART-HOTEL') :
			return Hotel_type
		elif Hotel_type in ('GUEST HOUSE' ,'BED & BREAKFAST', 'HOSTEL/BACKPACKER ACCOMMODATION', 'MOTEL' , 'HOSTAL (BUDGET HOTEL)'):
			return 'Budget_hotel'
		elif Hotel_type in ('APARTMENT','RESIDENCE','TOWNHOUSE','INN'):
			return 'Budget_hotel'
		else:
			return 'others'
	
	elif model_name=="North America":
		if Hotel_type in ('HOTEL' , 'MOTEL') :
			return Hotel_type
		elif Hotel_type in ('LODGE' ,  'BED & BREAKFAST' ,  'COTTAGE' ,  'GUEST HOUSE' ,  'CABIN'):
			return 'Budget_hotel'
		elif Hotel_type in ( 'APARTMENT' ,  'HOTEL RESORT' ,  'CONDO' ,  'INN' ,  'APART-HOTEL' ,  'CARAVAN PARK'):
			return 'Family_Premium'
		else:
			return 'others'
	else:
		return 'NOT APPLICABLE'

##udf for market bucket
def srch_region_market(market,model_name):
	if model_name == 'CANADA':
		if market in  ('TORONTO, ON, CAN' , 'NIAGARA FALLS, ON, CAN' , 'MONTREAL, QC, CAN' , 'BANFF AREA, AB, CAN' ,'VANCOUVER, BC, CAN' ,'QUEBEC CITY, QC, CAN' , 'EDMONTON, AB, CAN' , 'OTTAWA, ON, CAN' , 'OKANAGAN VALLEY, BC, CAN'):
			return market
		elif market in ('VICTORIA, BC, CAN' ,'CALGARY, AB, CAN' ,'JASPER AREA, AB, CAN'):
			return 'G10'
		elif market in ('WHISTLER, BC, CAN' ,'NIAGARA-ON-THE-LAKE, ON, CAN' ,'MONT TREMBLANT, QC, CAN' , 'UCLUELET, BC, CAN','TOFINO - UCLUELET, BC, CAN'):
			return 'G11'
		elif market in ('COLLINGWOOD, ON, CAN' , 'BC INTERIOR SKI, BC, CAN' ,'HALIFAX, NS, CAN','WINNIPEG, MB, CAN' ,'LONDON, ON, CAN' , 'KAMLOOPS, BC, CAN'):
			return 'G12'
		else:
			return 'others'
	
	elif model_name == 'US':
		return 'NA'
		
	elif model_name == 'Mexico':
		if market in  ('MEXICO - RIVIERA MAYA, PLAYA DEL CARMEN & TULUM' , 'MEXICO - CANCUN & ISLA MUJERES' ,'MEXICO - PUERTO VALLARTA, NUEVO VALLARTA & RIVIERA NAYARIT' , 'MEXICO - LOS CABOS' , 'CENTRAL AMERICA - COSTA RICA - GUANACASTE' ,'CENTRAL AMERICA - BELIZE' , 'CENTRAL AMERICA - COSTA RICA - PUNTARENAS' , 'CENTRAL AMERICA - COSTA RICA - OTHER' , 'MEXICO - COZUMEL''MEXICO - HUATULCO' , 'MEXICO - IXTAPA & ZIHUATANEJO' , 'CENTRAL AMERICA - HONDURAS' , 'CENTRAL AMERICA - PANAMA - OTHER') :
			return market
		elif market in ( 'CENTRAL AMERICA - COSTA RICA - SAN JOSE' , 'CENTRAL AMERICA - PANAMA - PANAMA CITY' ,'MEXICO - MEXICO CITY' ,'MEXICO - MEXICO CITY'						,'CENTRAL AMERICA - NICARAGUA','MEXICO - MAZATLAN','MEXICO - MANZANILLO','CENTRAL AMERICA - EL SALVADOR','MEXICO - ACAPULCO'):
			return 'hclt'
		elif market in ('CENTRAL AMERICA - NICARAGUA','MEXICO - MAZATLAN','MEXICO - MANZANILLO','CENTRAL AMERICA - EL SALVADOR',                        'MEXICO - ACAPULCO'):
			return 'lclt'
		else:
			return 'others'
		
	elif model_name=="CARIBBEAN":
		if market in ('PUNTA CANA, DOMINICAN REPUBLIC' , 'TURKS AND CAICOS' , 'MONTEGO BAY, JAMAICA' , 'ST. LUCIA' ,'OCHO RIOS, JAMAICA' ,                      'NEGRIL, JAMAICA' , 'BARBADOS'):
			return market
		elif market in ('ARUBA' , 'PUERTO PLATA, DOMINICAN REPUBLIC' , 'ANTIGUA AND BARBUDA'):
			return 'G8'
		elif market in ('NASSAU, BAHAMAS', 'DOMINICAN REPUBLIC ALL OTHER' , 'BERMUDA','BAHAMAS, OUT ISLANDS'):
			return 'G9'
		elif market in ('SAN JUAN, PUERTO RICO' ,'PARADISE ISLAND, BAHAMAS' ,'CAYMAN ISLANDS','SINT MAARTEN, DUTCH' ,'CURACAO','ST. MARTIN, FRENCH'):
			return 'G10'
		else:
			return 'others'
		
	elif model_name == 'Other Region':
		return 'NA'
	
	elif model_name=="North America":
		if  market in (  'GRAVENHURST - BRACEBRIDGE - HUNTSVILLE, ON, CAN','ONTARIO WEST, ON, CAN','ABBOTSFORD - CHILLIWACK, BC, CAN',                       'MAINE - COAST','ONTARIO EAST, ON, CAN','VANCOUVER ISLAND, BC, CAN','BURLINGTON, VT','CHARLOTTETOWN, PEI, CAN'): 
			return 'G1'
		elif market in ('ALBERTA EAST, AB, CAN','REGINA, SK, CAN','KINGSTON, ON, CAN','SASKATOON, SK, CAN','MONCTON, NB, CAN',                        'TRI-CITIES (KW-GUELPH-CAMBRIDGE), ON, CAN'): 
			return 'G2'
		elif market in ('WINDSOR, ON, CAN','RED DEER, AB, CAN','BRITISH COLUMBIA SOUTH, BC, CAN','GRAND FORKS, ND','SUDBURY, ON, CAN',                        'ONTARIO NORTH, ON, CAN','BANGOR, ME','HAMILTON - BRANTFORD, ON, CAN','BELLEVILLE - TRENTON - COBOURG, ON, CAN','FARGO, ND'): 
			return 'G3'
		elif market in ('LAKE PLACID, NY','PARKSVILLE, VANCOUVER ISLAND, BC, CAN','LAKE GEORGE, NY','OGUNQUIT, ME','EVERETT, WA',                        'COASTAL, BC, CAN','GROVE CITY, PA','BELLINGHAM, WA','NORTH CONWAY, NH','NEWFOUNDLAND OTHER, NL, CAN',                        'NOVA SCOTIA SOUTH, NS, CAN','PORTSMOUTH, NH'): 
			return 'G4'
		elif market in ('LETHBRIDGE, AB, CAN','FREDERICTON, NB, CAN','BRANDON, MB, CAN','ERIE, PA','NANAIMO, VANCOUVER ISLAND, BC, CAN',                        'SASKATCHEWAN SOUTH, SK, CAN','PRINCE GEORGE - QUESNEL, BC, CAN','MEDICINE HAT, AB, CAN','GRANDE PRAIRIE, AB, CAN',                        'ALBERTA NORTH, AB, CAN','DURHAM, ON, CAN','BRITISH COLUMBIA CENTRAL, BC, CAN','ONTARIO SOUTHWEST, ON, CAN',                        'SAULT STE. MARIE, ON, CAN','THUNDER BAY, ON, CAN','SAINT JOHN, NB, CAN','GREAT FALLS, MT','MINOT, ND (AREA)',                        'BRITISH COLUMBIA NORTH, BC, CAN','NORTH BAY, ON, CAN','PETERBOROUGH, ON, CAN','CAPE BRETON ISLAND, NS, CAN','ALBERTA WEST, AB, CAN',                        'HUDSON VALLEY - POUGHKEEPSIE, NY','FORT MCMURRAY, AB, CAN','NOVA SCOTIA NORTH, NS, CAN','WATERTOWN, NY','EDMUNSTON, NB, CAN',                        'OLYMPIC NATIONAL PARK AREA, WA','CEDAR CITY - BRYCE CANYON NATIONAL PARK, UT','SUMMERSIDE, PEI, CAN','SALEM, OR (AREA)','BUTTE - HELENA, MT'                        ,'BECKLEY, WV'): 
			return 'G5'
		elif market in ('SAGINAW, MI','WHITE MOUNTAINS, NH','FINGER LAKES NEW YORK','NEW YORK - WEST','NEW BRUNSWICK NORTH, NB, CAN',                        'SASKATCHEWAN NORTH, SK, CAN','MANITOBA SOUTH, MB, CAN','BAR HARBOR, ME','WASHINGTON NORTHWEST','VERMONT CENTRAL','ALBERTA SOUTH, AB, CAN',                        'WENATCHEE-LEAVENWORTH,WA','GANANOQUE, ON, CAN','PLATTSBURGH, (NY)','STRAITS OF MACKINAC, MI','SANDUSKY, OH','MANCHESTER, NH','ITHACA, NY',                        'MINNESOTA NORTHWEST','MISSOULA, MT (AREA)','YELLOWKNIFE, NT, CAN','PEI OTHER, PEI, CAN','BILLINGS, MT (AREA)','RAPID CITY - MOUNT RUSHMORE, SD',                        'ANDOVER, MA','YUMA, AZ','PORT HURON, MI','LANCASTER, PA','FORT LEE - PARAMUS, NJ','LEXINGTON, KY','MANITOBA NORTH, MB, CAN','ABERDEEN - OCEAN SHORES, WA',                        'CANADA TERRITORIES, YT, CAN','KNOXVILLE, TN','BURLINGTON - MOUNT VERNON, WA','FREDERICKSBURG, VA','ARIZONA SOUTHEAST',                        'WINDHAM COUNTY, VT','KENAI PENINSULA, AK','COLUMBIA, SC','CALIFORNIA DESERTS SOUTH'): 
			return 'G6'
		elif  market in ('ROME-UTICA, NY','SANDPOINT, ID (AREA)','MOAB - GREEN RIVER, UT','WHITEHORSE, YT, CAN','NEW YORK - NORTHEAST',                         'SARNIA, ON, CAN','AUGUSTA, ME','LAKE POWELL - GLEN CANYON NATIONAL PARK, AZ','NEW YORK - SOUTH','BISMARK, ND',                         'ALABAMA NORTH','ASHLAND - MEDFORD, OR','WASHINGTON NORTHEAST','THE BERKSHIRES, MA','EUGENE, OR (AREA)',                         'GRAND RAPIDS, MI','WASHINGTON SOUTHWEST','LAKE HAVASU CITY, AZ','SARATOGA, NY','WYTHEVILLE - VA',                         'ARCATA - EUREKA, CA','SOUTH CAROLINA EAST','CHATTANOOGA, TN','TOLEDO, OH','IDAHO FALLS, ID','WEST VIRGINIA SOUTH',                         'SPRINGFIELD, MA','OLYMPIA, WA','GETTYSBURG - PA'): 
			return 'G7'
		else:return 'Others'
	else:return 'NOT APPLICABLE'
		
def srch_model_name(region):
	if region == 'CANADA':
		return region
		
	elif region in ('FLORIDA (USA)','NEW YORK CITY','CALIFORNIA','GAMING (USA)','NORTHEAST (USA)','MOUNTAIN (USA)',                    'MIDWEST (USA)','CENTRAL (USA)','SF PACNW','ORLANDO','HAWAII'):
		return 'US'
		
	elif region in ("MEXICO - DOMESTIC REGION",'MEXICO - RESORTS REGION','CENTRAL AMERICA REGION'):
		return 'Mexico'
		
	elif region=="CARIBBEAN":
		return 'CARIBBEAN'
    
	elif region=="NORTH AMERICA REGIONAL TERRITORIES":
		return 'North America'
		
	else :
		return "Other Region"

def srch_region_bucket(region,model_name):
	if model_name == 'Other Region':
		if region in ('SPAIN & PORTUGAL' , 'ROME & ITALY RESORTS' , 'MID-ATLANTIC' , 'GREECE & TURKEY' , 'OCEANIA' , 'ITALY NORTH' ,                      'THAILAND' , 'MIDDLE EAST AND INDIAN OCEAN'):
			return region
		elif region in ('PARIS' , 'LONDON' , 'ENGLAND'):
			return 'G9'
		elif region in ('EUROPE REGIONAL TERRITORIES' , 'UK & IRELAND'):
			return 'G10'
		elif region in ('SOUTH AMERICA' , 'AFRICA AND EAST MED'):
			return 'G11'
		elif region in ('EASTERN EUROPE' , 'GERMANY, AUSTRIA & SWITZERLAND' , 'BENELUX' , 'FRANCE' , 'NORDIC'):
			return 'G12'
		elif region in ('JAPAN & MICRONESIA' , 'HONG KONG & MACAU' , 'SOUTHEAST ASIA EMERGING' , 'MAINLAND CHINA'):
			return 'G13'
		else:
			return 'others'
	else :
		return 'NA'


udfsrch_region_star_rating=udf(srch_region_star_rating, StringType())
udfsrch_region_city=udf(srch_region_city, StringType())
udfsrch_region_hotel_type=udf(srch_region_Hotel_type, StringType())
udfsrch_region_market=udf(srch_region_market, StringType())
udfsrch_model_name= udf(srch_model_name,StringType())
udfsrch_region_bucket = udf (srch_region_bucket,StringType())


# In[ ]:

path_hotel_dim = 's3n://ewe-core-meta-prod/CORE/HOTEL_DIM/*'
hotel_dim = sqlCtx.read.format("com.databricks.spark.csv").options(header = False, inferSchema = True, delimiter = "\t", nullValue= '\\N').			load(path_hotel_dim)
hotel_dim1 = hotel_dim.distinct().filter("C12 = 'BOOKABLE' or C12 ='NOT BOOKABLE' or C12 ='NOT APPLICABLE'").                select("C0","C7","C25","C26","C4","C13","C3")
hotel_dim4 = hotel_dim1.withColumnRenamed("C0","hotel_id").withColumnRenamed("C7" , "city").withColumnRenamed("C25","region").                withColumnRenamed("C26","market").withColumnRenamed("C4","brand").withColumnRenamed("C13","star_rating").                withColumnRenamed("C3","hotel_type")

#removing the records with hotel id 0
hotel_dim5 = hotel_dim4.filter((hotel_dim4['hotel_id'].isNotNull())).withColumnRenamed('hotel_id','HOTEL_ID')


# In[ ]:

hotel_dim_model_name = hotel_dim5.withColumn("MODEL_NAME", udfsrch_model_name("region"))
hotel_dim_bkts = hotel_dim_model_name.withColumn("STAR_RATING_BUCKET", udfsrch_region_star_rating("star_rating")).                    withColumn("HOTEL_TYPE_BUCKET", udfsrch_region_hotel_type("hotel_type","MODEL_NAME")).                    withColumn("MARKET_BUCKET",udfsrch_region_market("market","MODEL_NAME")).                    withColumn("REGION_BUCKET", udfsrch_region_bucket("region","MODEL_NAME"))                    .withColumn("CITY_BUCKET", udfsrch_region_city("city","MODEL_NAME"))

hotel_dim_final = hotel_dim_bkts.drop('city').drop('market').drop('brand').drop('star_rating').drop('hotel_type')



# In[ ]:

def data_type_change_int(df,cols):
    temp = df
    for col in cols:
        temp = temp.withColumn(col+'_1',df[col].cast(IntegerType())).drop(col).withColumnRenamed(col+'_1',col)
    return temp

def data_type_change_float(df,cols):
    temp = df
    for col in cols:
        temp = temp.withColumn(col+'_1',df[col].cast(DoubleType())).drop(col).withColumnRenamed(col+'_1',col)
    return temp

def searchToCategory(srch_los,):
    if srch_los in (0,1,2,3,4,5,6,7):
        return str(srch_los)
    elif srch_los >= 8 and srch_los <= 14:
        return '8-14'
    else:
        return '>14'

def searchbucketToCategory(SRCH_WINDOW):
    if SRCH_WINDOW <= 0:
        return '<=0'
    elif SRCH_WINDOW == 1:
        return '1'
    elif SRCH_WINDOW == 2:
        return '2'
    elif SRCH_WINDOW >= 3 and SRCH_WINDOW <= 4:
        return '3-4'
    elif SRCH_WINDOW >= 5 and SRCH_WINDOW <= 7:
        return '5-7'
    elif SRCH_WINDOW >= 8 and SRCH_WINDOW <= 14:
        return '8-14'
    elif SRCH_WINDOW >= 15 and SRCH_WINDOW <= 20:
        return '15-20'
    elif SRCH_WINDOW >= 21 and SRCH_WINDOW <= 30:
        return '21-30'
    elif SRCH_WINDOW >= 31 and SRCH_WINDOW <= 40:
        return '31-40'
    elif SRCH_WINDOW >= 41 and SRCH_WINDOW <= 60:
        return '41-60'
    elif SRCH_WINDOW >= 61 and SRCH_WINDOW <= 90:
        return '61-90'
    elif SRCH_WINDOW >= 91 and SRCH_WINDOW <= 120:
        return '91-120'
    elif SRCH_WINDOW >= 121 and SRCH_WINDOW <= 180:
        return '121-180'
    elif SRCH_WINDOW >= 181 and SRCH_WINDOW <= 240:
        return '181-240'
    else:
        return '>240'


def srchBookedLosBucket(booked_los):
    if booked_los is None:
        return '0'
    elif booked_los  in (0,1,2,3,4,5,6,7):
        return str(booked_los)
    elif booked_los >= 8 and booked_los <= 14:
        return '8-14'
    else:
        return '>14'


def srchBookedBwBucket(BOOKED_BKG_WINDOW):
    if BOOKED_BKG_WINDOW is None:
        return '0'
    elif BOOKED_BKG_WINDOW <= 0:
        return '<= 0'
    elif BOOKED_BKG_WINDOW == 1:
        return '1'
    elif BOOKED_BKG_WINDOW == 2:
        return '2'
    elif BOOKED_BKG_WINDOW >= 3 and BOOKED_BKG_WINDOW <= 4:
        return '3-4'
    elif BOOKED_BKG_WINDOW >= 5 and BOOKED_BKG_WINDOW <= 7:
        return '5-7'
    elif BOOKED_BKG_WINDOW >= 8 and BOOKED_BKG_WINDOW <= 14:
        return '8-14'
    elif BOOKED_BKG_WINDOW >= 15 and BOOKED_BKG_WINDOW <= 20:
        return '15-20'
    elif BOOKED_BKG_WINDOW >= 21 and BOOKED_BKG_WINDOW <= 30:
        return '21-30'
    elif BOOKED_BKG_WINDOW >= 31 and BOOKED_BKG_WINDOW <= 40:
        return '31-40'
    elif BOOKED_BKG_WINDOW >= 41 and BOOKED_BKG_WINDOW <= 60:
        return '41-60'
    elif BOOKED_BKG_WINDOW >= 61 and BOOKED_BKG_WINDOW <= 90:
        return '61-90'
    elif BOOKED_BKG_WINDOW >= 91 and BOOKED_BKG_WINDOW <= 120:
        return '91-120'
    elif BOOKED_BKG_WINDOW >= 121 and BOOKED_BKG_WINDOW <= 180:
        return '121-180'
    elif BOOKED_BKG_WINDOW >= 181 and BOOKED_BKG_WINDOW <= 240:
        return '181-240'
    else:
        return '>240'


def booking_flag(booked_flag):
    if booked_flag == 'Y':
        return 1
    else:
        return 0
    
# Registering Functions as UDF's

udfsearchToCategory=udf(searchToCategory, StringType())
udfsearchbucketToCategory=udf(searchbucketToCategory, StringType())
udfsrchBookedLosBucket=udf(srchBookedLosBucket, StringType())
udfsrchsrchBookedBwBucket=udf(srchBookedBwBucket, StringType())
booking_flag_udf=udf(booking_flag, IntegerType())


# In[ ]:

from datetime import *
import time

date_list = ["2016-05-29","2016-05-28","2016-05-27","2016-05-25","2016-05-24","2016-05-22","2016-05-21","2016-05-20","2016-05-18","2016-05-15",             "2016-05-14","2016-05-13","2016-05-11","2016-05-10"]

start_date = (datetime.strptime(time.strftime("%Y-%m-%d"), "%Y-%m-%d")-timedelta(13))             
start_date_last = start_date.replace(year=start_date.year - 1)

for i in range(1,8):
    x = (start_date_last + timedelta(i))  ##need to change this while giving for final recommendations
    x = x.strftime("%Y-%m-%d")
    date_list.append(x)
    
##SCHEMA FOR hcba TABLE
hcba_schema = StructType([
                            StructField('PARTNER_POS',StringType(), True),
                            StructField('DEVICE_TYPE',StringType(), True),
                            StructField('CLICKED_HOTEL_ID',IntegerType(), True),
                            StructField('SRCH_WINDOW',IntegerType(), True),
                            StructField('SRCH_LOS',IntegerType(), True),
                            StructField('TRAFFIC',IntegerType(), True),
                            StructField('COST',DoubleType(), True),
                            StructField('BOOKED_FLAG',StringType(), True),
                            StructField('BOOKED_HOTEL_ID',IntegerType(), True),
                            StructField('BOOKED_LOS',IntegerType(), True),
                            StructField('BOOKED_BKG_WINDOW',IntegerType(), True),
                            StructField('GROSS_PROFIT',DoubleType(), True),
                            StructField('PARTNER_ORG',StringType(), True),
                            StructField('ACTIVITY_DATE',StringType(), True)
                          ])
 

##CREATE EMPTY DATAFRAME 
hcba = sqlContext.createDataFrame(sc.emptyRDD(), hcba_schema)

##APPENDING THE DATA IN ABOVE CREATED hcba TABLE 
for dates in date_list:
    path_hcba = 's3n://ewe-core-meta-prod/CORE/HOTEL_CLICK_BOOK_AGG/local_date='+dates+'/*'  
    print (path_hcba)
    try :
        temp_hcba = sqlCtx.read.format("com.databricks.spark.csv").options(header = False, inferschema = True, delimiter = "\t",nullValue= '\\N').load(path_hcba)
        print('file exist')
        temp_hcba = temp_hcba.select('C1','C3','C7','C8','C9','C13','C14','C19','C20','C21','C22','C45','C65')
        temp_hcba = temp_hcba.filter((temp_hcba.C65 == 'TRIPADVISOR') & (temp_hcba.C1 == 'CA') & (temp_hcba.C7 != '0') & (temp_hcba.C13 != '0') ) 
        temp_hcba = temp_hcba.withColumn('ACTIVITY_DATE',lit(dates))
        hcba = hcba.unionAll(temp_hcba)
    except: print('file does not exist')


# In[ ]:

cols_int = ['SRCH_LOS','SRCH_WINDOW','TRAFFIC','BOOKED_BKG_WINDOW','BOOKED_LOS']
cols_float = ['COST','GROSS_PROFIT']

hcba_int = data_type_change_int(hcba,cols_int)
hcba_float = data_type_change_float(hcba_int,cols_float)

hcba = hcba_float.withColumn("SRCH_LOS_BUCKET", udfsearchToCategory("SRCH_LOS")).            withColumn("SRCH_BW_BUCKET", udfsearchbucketToCategory("SRCH_WINDOW")).            withColumn("BOOKED_LOS_BUCKET", udfsrchBookedLosBucket("BOOKED_LOS")).            withColumn("BOOKED_BW_BUCKET", udfsrchsrchBookedBwBucket("BOOKED_BKG_WINDOW")).            withColumn("BOOKING", booking_flag_udf("BOOKED_FLAG"))


# In[ ]:

hcba_los_bw_negative_conv = hcba.filter((hcba['BOOKED_FLAG'] == 'Y') & ((hcba['SRCH_WINDOW'] < -1) | (hcba['SRCH_LOS'] <= 0)))
hcba_los_bw_negative_conv = hcba_los_bw_negative_conv.withColumnRenamed('BOOKED_BKG_WINDOW', 'BOOKING_WINDOW').withColumnRenamed('BOOKED_BW_BUCKET', 'BW_BUCKET').withColumnRenamed('BOOKED_LOS_BUCKET', 'LOS_BUCKET').withColumnRenamed('BOOKED_HOTEL_ID', 'HOTEL_ID').withColumnRenamed('BOOKED_LOS', 'LOS')
hcba_los_bw_negative_conv=hcba_los_bw_negative_conv.select('PARTNER_POS','DEVICE_TYPE','HOTEL_ID','PARTNER_ORG','ACTIVITY_DATE','TRAFFIC','BOOKING_WINDOW','LOS','COST','GROSS_PROFIT','LOS_BUCKET','BW_BUCKET','BOOKING')

#-------------------------------------Selecting all the non converted rows---------------------#
#Selecting the required data
hcba_non_conv = hcba.filter((hcba['BOOKED_FLAG'] == 'N') & (hcba['SRCH_WINDOW'] >= -1) & (hcba['SRCH_LOS'] > 0) & (hcba['GROSS_PROFIT'] == 0.0) )

#Renaming the columns as required
hcba_non_conv = hcba_non_conv.withColumnRenamed('CLICKED_HOTEL_ID', 'HOTEL_ID').withColumnRenamed('SRCH_WINDOW', 'BOOKING_WINDOW').withColumnRenamed('SRCH_BW_BUCKET', 'BW_BUCKET').withColumnRenamed('SRCH_LOS', 'LOS').withColumnRenamed('SRCH_LOS_BUCKET', 'LOS_BUCKET')
hcba_non_conv=hcba_non_conv.select('PARTNER_POS','DEVICE_TYPE','HOTEL_ID','PARTNER_ORG','ACTIVITY_DATE','TRAFFIC','BOOKING_WINDOW','LOS','COST','GROSS_PROFIT','LOS_BUCKET','BW_BUCKET','BOOKING')

#----------------------------------Selecting all converted rows-------------------------------------#
#Selecting the required data
hcba_conv = hcba.filter((hcba['BOOKED_FLAG'] == 'Y') & (hcba['SRCH_WINDOW'] >= -1) & (hcba['SRCH_LOS'] > 0))

#Renaming the columns as required
hcba_conv = hcba_conv.withColumnRenamed('CLICKED_HOTEL_ID', 'HOTEL_ID').withColumnRenamed('SRCH_WINDOW', 'BOOKING_WINDOW').withColumnRenamed('SRCH_BW_BUCKET', 'BW_BUCKET').withColumnRenamed('SRCH_LOS', 'LOS').withColumnRenamed('SRCH_LOS_BUCKET', 'LOS_BUCKET')
hcba_conv=hcba_conv.select('PARTNER_POS','DEVICE_TYPE','HOTEL_ID','PARTNER_ORG','ACTIVITY_DATE','TRAFFIC','BOOKING_WINDOW','LOS','COST','GROSS_PROFIT','LOS_BUCKET','BW_BUCKET','BOOKING')


#---Union of all the above 3 tables hcba_non_conv,hcba_conv,hcba_los_bw_negative_conv----------#
hcba_union = hcba_los_bw_negative_conv.unionAll(hcba_non_conv).unionAll(hcba_conv)


# In[ ]:

hcba_opti_union1 = hcba_union.filter(hcba_union.ACTIVITY_DATE >= '2016-05-10').filter(hcba_union.DEVICE_TYPE == 'DESKTOP')

##populating week column
hcba_opti_union2 = hcba_opti_union1.withColumn('WEEK',weekofyear(hcba_opti_union1.ACTIVITY_DATE))

##populating average weekly traffic
import pyspark.sql.functions as func
hcba_opti_union3 = hcba_opti_union2.groupBy('HOTEL_ID','LOS_BUCKET','BW_BUCKET').agg({'TRAFFIC':'sum'}).                    withColumnRenamed('sum(TRAFFIC)','TOTAL_TRAFFIC')
hcba_opti_union =  hcba_opti_union3.withColumn("AVERAGE_WEEKLY_TRAFFIC",(hcba_opti_union3.TOTAL_TRAFFIC/2)).drop("TOTAL_TRAFFIC")


# In[ ]:

hcba_rf_union = hcba_union


# In[ ]:

def seller_rank_bucket(seller_rank):
	seller_rank = int(seller_rank)
	if seller_rank <=3 :
		return str(seller_rank)
	else:
		return ">=4"

seller_rank_bucket_udf = udf(seller_rank_bucket,StringType())



##CREATE EMPTY DATAFRAME
mbap_schema = StructType([StructField('ACTIVITY_DATE',StringType(),True),
                          StructField('DEVICE_TYPE',StringType(),True),
                          StructField('HOTEL_ID',IntegerType(),True),
                          StructField('CPC',DoubleType(),True),
                          StructField('SELLER_RANK',DoubleType(),True)
                         ])
mbap = sqlContext.createDataFrame(sc.emptyRDD(),mbap_schema)


# In[ ]:

##APPENDING THE DATA IN ABOVE CREATED HCBA TABLE 
from datetime import *
import time

date_list_mbap = ["2016-05-29","2016-05-28","2016-05-27","2016-05-25","2016-05-24","2016-05-22","2016-05-21","2016-05-20","2016-05-18","2016-05-15",             "2016-05-14","2016-05-13","2016-05-11","2016-05-10"]

for dates in date_list_mbap:
    path_mbap =  's3n://ewe-meta-prod/EXPEDIA/ARCHIVE/bidding/TRIPADVISOR_mBAP_bidoutput_'+dates.replace("-","")+'.tab.gz'   
    print (path_mbap)
    try :
        temp_mbap = sqlCtx.read.format("com.databricks.spark.csv").options(header = True, inferschema = True, delimiter = "\t",nullValue= '\\N').load(path_mbap)
        print('file exist')
        temp_mbap = temp_mbap.filter(temp_mbap.posa == 'CA')
        temp_mbap = temp_mbap.select('snapshot_day','device','hotelid','final_bid_value_cpc','expected_rank')
        mbap = mbap.unionAll(temp_mbap)
    except: print('file does not exist')


# In[ ]:

mbap1 = mbap.groupBy('HOTEL_ID','DEVICE_TYPE').agg({"SELLER_RANK":"avg","CPC":"avg"}).withColumnRenamed("avg(SELLER_RANK)","SELLER_RANK").            withColumnRenamed("avg(CPC)","CPC")
mbap_final = mbap1.withColumn('SELLER_RANK_BUCKET',seller_rank_bucket_udf(mbap1.SELLER_RANK)).select('HOTEL_ID','DEVICE_TYPE','SELLER_RANK','CPC','SELLER_RANK_BUCKET')


# In[ ]:

tripadvisor_ad_final = hcba_rf_union.join(hotel_dim_final,"HOTEL_ID","inner")

tripadvisor_ad_final1 = tripadvisor_ad_final.join(mbap_final,['HOTEL_ID','DEVICE_TYPE'],'left_outer')

tripadvisor_ad_final_tmp = tripadvisor_ad_final1.withColumn("SELLER_RANK_BUCKET_1",lit('3')).                            withColumnRenamed("SELLER_RANK_BUCKET","SELLER_RANK_BUCKET_0")

tripadvisor_ad_final2 = tripadvisor_ad_final_tmp.withColumn("SELLER_RANK_BUCKET",coalesce("SELLER_RANK_BUCKET_0","SELLER_RANK_BUCKET_1")).                        drop("SELLER_RANK_BUCKET_1").drop("SELLER_RANK_BUCKET_0")


# In[ ]:

from datetime import *
import time
start_date = (datetime.strptime(time.strftime("%Y-%m-%d"), "%Y-%m-%d")-timedelta(13))  #STARTING DATE

no_days = 1  #NO. OF DAYS FOR WHICH DATA IS REQUIRED
date_list_thpa = []
for i in range(no_days):
    x = (start_date - timedelta(i))
    x = x.strftime("%Y-%m-%d")
    date_list_thpa.append(x)
    
TOP_schema = StructType([
                            StructField('DEVICE_TYPE',StringType(), True),
                            StructField('HOTEL_ID',IntegerType(), True),
                            StructField('BOOKING_WINDOW',IntegerType(), True),
                            StructField('LOS',IntegerType(), True),
                            StructField('ADULT_COUNT',DoubleType(), True), 
                            StructField('BASE_RATE_MIN',DoubleType(), True),
                            StructField('COMMISION_AVG',DoubleType(), True),
                            StructField('VARIABLE_MARGIN_AVG',DoubleType(), True),
                            StructField('LOCAL_DATE',StringType(), True),

                            ])

thpa = sqlContext.createDataFrame(sc.emptyRDD(), TOP_schema)


# In[ ]:

for dates in date_list_thpa:
    path_thpa = 's3n://ewe-core-meta-prod/CORE/TOP_HOTEL_PRICE_AGG/local_date='+dates+'/*'  
    print (path_thpa)
    try :
        temp_thpa = sqlCtx.read.format("com.databricks.spark.csv").options(header = False, inferschema = True, delimiter = "\t",nullValue= '\\N').load(path_thpa)
        temp_thpa = temp_thpa.filter((temp_thpa.C2 == 'DESKTOP')&(temp_thpa.C0 == 'CA')&(temp_thpa.C33 == 'EXPEDIA'))
        temp_thpa = temp_thpa.select('C2','C3','C9','C8','C10','C14','C28','C30','C32')
        print('file exist')
        thpa = thpa.unionAll(temp_thpa)
    except: print('file does not exist')

thpa1 = thpa.distinct()
thpa_float = data_type_change_float(thpa1, ['BASE_RATE_MIN','COMMISION_AVG','VARIABLE_MARGIN_AVG'])
thpa_int = data_type_change_int(thpa_float, ['LOS','BOOKING_WINDOW'])


# In[ ]:

thpa_opti_rm_nulls = thpa_int.dropna()


# In[ ]:

thpa_opti1 = thpa_opti_rm_nulls.withColumn("NET_REVENUE",(thpa_opti_rm_nulls.COMMISION_AVG+thpa_opti_rm_nulls.VARIABLE_MARGIN_AVG))
thpa_opti2 = thpa_opti1.groupBy("HOTEL_ID","LOS","BOOKING_WINDOW").agg({'NET_REVENUE':'avg',"BASE_RATE_MIN":"avg"}).                withColumnRenamed('avg(NET_REVENUE)','NET_REVENUE').withColumnRenamed('avg(BASE_RATE_MIN)','BASE_RATE_MIN')
thpa_opti3  = thpa_opti2.withColumn("LOS_BUCKET", udfsearchToCategory("LOS")).                withColumn("BW_BUCKET", udfsearchbucketToCategory("BOOKING_WINDOW"))


# In[ ]:

thpa_opti4 = thpa_opti3.groupBy("HOTEL_ID","LOS_BUCKET","BW_BUCKET").agg({"NET_REVENUE":"avg","BASE_RATE_MIN":"avg"}) .            withColumnRenamed('avg(NET_REVENUE)','NET_REVENUE').withColumnRenamed('avg(BASE_RATE_MIN)','BASE_RATE_MIN')
thpa_opti5 = thpa_opti4.withColumn("NET_REVENUE_0",round(thpa_opti4.NET_REVENUE,2)).drop("NET_REVENUE")


# In[ ]:

thpa_opti6 = thpa_opti5.filter(thpa_opti5["NET_REVENUE_0"] != 0.00).withColumnRenamed("NET_REVENUE_0","NET_REVENUE")


# In[ ]:

tripadvisor_ad_final_rf = tripadvisor_ad_final2


# In[ ]:

optimization_ad_sq_univ = thpa_opti6.join(hcba_opti_union,["HOTEL_ID","LOS_BUCKET","BW_BUCKET"],'left_outer')


# In[ ]:

optimization_ad_sq_univ2 = optimization_ad_sq_univ.join(hotel_dim_final,"HOTEL_ID","inner")


# In[ ]:

optimization_ad_sq_univ_traffic = optimization_ad_sq_univ2.repartition(300,['HOTEL_ID'])


# In[ ]:

mbap_final1 = mbap_final[mbap_final.DEVICE_TYPE=='DESKTOP']


# In[ ]:

optimization_ad_sq_univ_traffic_mbap = optimization_ad_sq_univ_traffic.join(mbap_final1,['HOTEL_ID'],'inner')


# In[ ]:

optimization_ad = optimization_ad_sq_univ_traffic_mbap.drop("DEVICE_TYPE")


# In[ ]:

optimization_ad1 = optimization_ad.withColumn("SELLER_RANK_BUCKET_1",lit('3'))
optimization_ad2 = optimization_ad1.withColumn("SELLER_RANK_BUCKET_FINAL",coalesce("SELLER_RANK_BUCKET","SELLER_RANK_BUCKET_1"))


# In[ ]:

optimization_ad_final = optimization_ad2.drop("SELLER_RANK_BUCKET").drop("SELLER_RANK_BUCKET_1").                        withColumnRenamed("SELLER_RANK_BUCKET_FINAL","SELLER_RANK_BUCKET")


# In[ ]:

optimization_ad_final.cache()


# In[ ]:

tripadvisor_ad_final_rf.cache()


# In[ ]:

import numpy
from pyspark.ml.feature import *
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.mllib.linalg import *
from pyspark.sql.functions import *
from pyspark.ml import Pipeline
from pyspark.ml.regression import RandomForestRegressor
from pyspark.ml.feature import StringIndexer, VectorIndexer


# In[36]:

name = 'US'

if name == 'CANADA':
    region_level = 'CITY_BUCKET'
elif name == 'US':
    region_level = 'region'
elif name in ['Mexico', 'CARIBBEAN', 'North America']:
    region_level = 'MARKET_BUCKET'
else:
    region_level = 'REGION_BUCKET'

training_ad = tripadvisor_ad_final_rf.filter(tripadvisor_ad_final_rf.MODEL_NAME == name).filter(tripadvisor_ad_final_rf.DEVICE_TYPE=='DESKTOP').                withColumnRenamed(region_level, 'REGION_LEVEL_BUCKET')


# In[37]:

optimization_test = optimization_ad_final.filter(optimization_ad_final.MODEL_NAME == name)    .withColumnRenamed(region_level, 'REGION_LEVEL_BUCKET')


# In[38]:


# for training the data
# Aggregating the data to the required level
training_ad_T = training_ad.groupBy("BW_BUCKET", "LOS_BUCKET", "HOTEL_TYPE_BUCKET", "STAR_RATING_BUCKET", "REGION_LEVEL_BUCKET",                                     "SELLER_RANK_BUCKET").sum("TRAFFIC", "BOOKING")

training_ad_T1 = training_ad_T.withColumnRenamed('sum(TRAFFIC)', 'TRAFFIC')
training_ad_T1 = training_ad_T1.withColumnRenamed(
    'sum(BOOKING)', 'BOOKING')



# In[39]:

# Filtering out the TRAFFIC (Outliers) from data
training_ad_T1 = training_ad_T1[
    ~((training_ad_T1.TRAFFIC <= 4) & (training_ad_T1.BOOKING > 0))]
training_ad_T1 = training_ad_T1[
    ~((training_ad_T1.TRAFFIC == 5) & (training_ad_T1.BOOKING == 2))]
training_ad_T1 = training_ad_T1[
    ~((training_ad_T1.TRAFFIC == 6) & (training_ad_T1.BOOKING == 2))]


# In[40]:

training_ad_T2 = training_ad_T1.withColumn("chk_data",lit("train")).                    withColumn('MODEL_NAME',lit(name)).                    withColumn("region",lit("NA"))                    .withColumn('HOTEL_ID',lit("NA")).                    withColumn('DEVICE_TYPE',lit("NA")).                    withColumn('AVERAGE_WEEKLY_TRAFFIC',lit(0.0))                    .withColumn('SELLER_RANK',lit("0")).                    withColumn('CPC',lit(0.0)).                    withColumn('BASE_RATE_MIN',lit(0.00)).                    withColumn('NET_REVENUE',lit(0.00))                  .withColumn('MARKET_BUCKET',lit("NA")).                  withColumn('REGION_BUCKET',lit("NA"))
training_ad_T2= training_ad_T2.select("MODEL_NAME","HOTEL_ID","LOS_BUCKET","BW_BUCKET","DEVICE_TYPE","region","STAR_RATING_BUCKET",                                      "HOTEL_TYPE_BUCKET","MARKET_BUCKET","REGION_BUCKET","REGION_LEVEL_BUCKET","AVERAGE_WEEKLY_TRAFFIC",                                      "SELLER_RANK","CPC","SELLER_RANK_BUCKET","BASE_RATE_MIN",                                      "NET_REVENUE","TRAFFIC","BOOKING","chk_data")


# In[41]:

optimization_test2 = optimization_test.withColumn("TRAFFIC",lit(0)).withColumn("BOOKING",lit(0)).withColumn("chk_data",lit("test"))                        .withColumn("DEVICE_TYPE",lit("DESKTOP"))
optimization_test2 = optimization_test2.select("MODEL_NAME","HOTEL_ID","LOS_BUCKET","BW_BUCKET","DEVICE_TYPE","region","STAR_RATING_BUCKET",                                      "HOTEL_TYPE_BUCKET","MARKET_BUCKET","REGION_BUCKET","REGION_LEVEL_BUCKET","AVERAGE_WEEKLY_TRAFFIC",                                      "SELLER_RANK","CPC","SELLER_RANK_BUCKET","BASE_RATE_MIN",                                      "NET_REVENUE","TRAFFIC","BOOKING","chk_data")


# In[42]:

test_train_data = optimization_test2.unionAll(training_ad_T2)


# In[43]:

test_train_data.cache()


# In[44]:

# Converting the data type of required columns to factor
def indexStringColumns(df, cols):
    tempdf = df
    for col in cols:
        stringIndexer = StringIndexer(inputCol=col, outputCol=col + "-num")
        si_model = stringIndexer.fit(tempdf)
        tempdf = si_model.transform(tempdf)
    return tempdf

cols = {"BW_BUCKET", "LOS_BUCKET", "HOTEL_TYPE_BUCKET",
        "STAR_RATING_BUCKET", "REGION_LEVEL_BUCKET", "SELLER_RANK_BUCKET"}
dfnumeric = indexStringColumns(test_train_data, cols)


# In[45]:

def oneHotEncodeColumns(df, cols):
    tempdf = df
    for col in cols:
        onehotenc = OneHotEncoder(
            inputCol=col + "-num", outputCol=col + "-onehot")
        tempdf = onehotenc.transform(tempdf).drop(col + "-num")
    return tempdf
test_train_data_class = oneHotEncodeColumns(dfnumeric, {
                                           "BW_BUCKET", "LOS_BUCKET", "HOTEL_TYPE_BUCKET", "STAR_RATING_BUCKET", "REGION_LEVEL_BUCKET", "SELLER_RANK_BUCKET"})


# In[46]:

training_ad_T1_Class = test_train_data_class.filter(test_train_data_class.chk_data=="train").drop("chk_data").                        select("BW_BUCKET","LOS_BUCKET","HOTEL_TYPE_BUCKET","STAR_RATING_BUCKET","REGION_LEVEL_BUCKET","SELLER_RANK_BUCKET",                               "TRAFFIC","BOOKING","STAR_RATING_BUCKET-onehot","REGION_LEVEL_BUCKET-onehot","BW_BUCKET-onehot",                               "HOTEL_TYPE_BUCKET-onehot","LOS_BUCKET-onehot","SELLER_RANK_BUCKET-onehot")


# In[47]:

# Transforming the training dataset
# Defining function for the same
def genRows(row):
    TRAFFIC = row[6]
    BOOKING = row[7]
    BOOKINGcounter = 0
    rowList = []

    for i in range(TRAFFIC):
        row1 = row[:]
        # row1[6]=1
        row1 = list(row1)
        row1[6] = 1
        row1 = tuple(row1)
        if BOOKINGcounter < int(BOOKING):
            # row1[7]=1
            row1 = list(row1)
            row1[7] = 1
            row1 = tuple(row1)
        else:
            # row1[7]=0
            row1 = list(row1)
            row1[7] = 0
            row1 = tuple(row1)
        BOOKINGcounter += 1
        rowList.append(row1)
    return rowList

# Applying function on the complete dataset (after converting to rdd)
training_ad_T1_Class_rdd = training_ad_T1_Class.rdd
training_ad_T1_Class_rdd = training_ad_T1_Class_rdd.flatMap(
    lambda x: genRows(x))


# In[48]:

# Reconverting to dataframe

from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark.mllib.linalg import SparseVector, VectorUDT

schema = StructType([StructField('BW_BUCKET', StringType(), True),
                     StructField('LOS_BUCKET', StringType(), True),
                     StructField('HOTEL_TYPE_BUCKET', StringType(), True),
                     StructField('STAR_RATING_BUCKET', StringType(), True),
                     StructField('REGION_LEVEL_BUCKET',
                                 StringType(), True),
                     StructField('SELLER_RANK_BUCKET', StringType(), True),
                     StructField('TRAFFIC', IntegerType(), True),
                     StructField('BOOKING', IntegerType(), True),
                     StructField('HOTEL_TYPE_BUCKET-onehot',
                                 VectorUDT(), True),
                     StructField('BW_BUCKET-onehot',  VectorUDT(), True),
                     StructField('REGION_LEVEL_BUCKET-onehot',
                                 VectorUDT(), True),
                     StructField('LOS_BUCKET-onehot',  VectorUDT(), True),
                     StructField('SELLER_RANK_BUCKET-onehot',
                                 VectorUDT(), True),
                     StructField('STAR_RATING_BUCKET-onehot',  VectorUDT(), True)])
training_ad_T1_Class_df = sqlContext.createDataFrame(
    training_ad_T1_Class_rdd, schema)

# Converting label to double datatype
toDouble = udf(lambda x: float(x * 1.00), DoubleType())
training_ad_T1_Class_df = training_ad_T1_Class_df.withColumn(
    'BOOKING', toDouble(training_ad_T1_Class_df.BOOKING))



# In[49]:

# Taking only relevant columns as features
colList = training_ad_T1_Class_df.columns
colList.remove('BOOKING')
colList.remove('TRAFFIC')
colList.remove('BW_BUCKET')
colList.remove('LOS_BUCKET')
colList.remove('HOTEL_TYPE_BUCKET')
colList.remove('STAR_RATING_BUCKET')
colList.remove('REGION_LEVEL_BUCKET')
colList.remove('SELLER_RANK_BUCKET')
vecAssembler = VectorAssembler(inputCols=colList, outputCol="features")
train_ad = vecAssembler.transform(training_ad_T1_Class_df).select("BOOKING", "TRAFFIC", "BW_BUCKET", "LOS_BUCKET", "HOTEL_TYPE_BUCKET",
                                                                  "STAR_RATING_BUCKET", "REGION_LEVEL_BUCKET", "SELLER_RANK_BUCKET", "features").withColumnRenamed("BOOKING", "label")


train_ad = train_ad.cache()


# In[50]:

optimization_onehot = test_train_data_class.filter(test_train_data_class.chk_data=="test").drop("chk_data")
col =colList
vecAssembler = VectorAssembler(inputCols=col, outputCol="indexedFeatures")
optimization_df = vecAssembler.transform(optimization_onehot)


# In[51]:

# Random Forest model building
from pyspark.ml import Pipeline
from pyspark.ml.regression import RandomForestRegressor
from pyspark.ml.feature import StringIndexer, VectorIndexer

labelIndexer = StringIndexer(
    inputCol="label", outputCol="indexedLabel").fit(train_ad)
featureIndexer = VectorIndexer(
    inputCol="features", outputCol="indexedFeatures").fit(train_ad)
rf = RandomForestRegressor(labelCol="indexedLabel", featuresCol="indexedFeatures", featureSubsetStrategy="onethird",
                           numTrees=1000, impurity="variance", maxBins=32,maxDepth=10)
pipeline = Pipeline(stages=[labelIndexer, featureIndexer, rf])
model = pipeline.fit(train_ad)
RF_Model = model.stages[2]


# In[52]:

optimization_df_predict = RF_Model.transform(optimization_df).drop(
    "indexedFeatures").withColumnRenamed("prediction", "CONVERSION_RATE")

optimization_rf = optimization_df_predict


# In[53]:

optimization_rf.describe("CONVERSION_RATE").show()


# In[54]:

from pyspark.sql.functions import udf
from pyspark.sql.types import *
from pyspark.sql.functions import monotonicallyIncreasingId
import pandas

##Pulp package for Linear Programming Optimization algorithm
import pulp
from pulp import *


# In[55]:

def net(net_revenue):
    return net_revenue/10.00

net_udf = udf(net,DoubleType())
optimization_rf1 = optimization_rf.withColumn("net_revenue_1",net_udf("NET_REVENUE"))
#optimization_rf1 = optimization_ad_final.filter("MODEL_NAME = 'CANADA'")


# In[140]:

def predicted(predicted):
    if predicted < 0.0005:
        predicted = 0.0
    else:
        predicted
    return predicted


##If Net revenue is negative then making it positive 
def net_revenue(net_revenue):
    if net_revenue < 0.0 :
        net_revenue = net_revenue*(-1)
    else:
        net_revenue
    return net_revenue

##Creating the objective function at search query level, combining it while running lp_solve algorithm
def objective_fun(net_revenue,predicted):
    return net_revenue * predicted

##Lower limit for the average weekly Traffic
def lower_limit_fun(net_revenue,average_weekly_traffic):
    if net_revenue >= 100.00:
        limit=0.6*average_weekly_traffic
    else:
        limit=0.3*average_weekly_traffic
    return limit 

##creating unique id for each search query
def var_name(id):
    return "T_" + str(id)

##registering the above defined functions as uoptimization_rf
objective_fun_udf = udf(objective_fun, DoubleType())
lower_limit_fun_udf = udf(lower_limit_fun, DoubleType())
var_name_udf= udf(var_name,StringType())
net_revenue_udf = udf(net_revenue, DoubleType())
predicted_udf = udf(predicted , DoubleType())



# In[141]:

optimization_rf_algo = optimization_rf1[~optimization_rf1.AVERAGE_WEEKLY_TRAFFIC.isNull()]


# In[142]:

optimization_t_predict = optimization_rf_algo.withColumn("predicted_new",predicted_udf(optimization_rf_algo.CONVERSION_RATE))


# In[143]:

##removing the searech queries with 0 Traffic , for such queries we will giving rule base throttle value
optimization_t_Traffic =  optimization_t_predict

##creating new column net_revenue_new by making -ve values of net revenue +ve
optimization_t = optimization_t_Traffic.withColumn("net_revenue_new",net_revenue_udf(optimization_t_Traffic.NET_REVENUE))


# In[144]:

optimization_t_temp = optimization_t.withColumn("objective_fun",objective_fun_udf(optimization_t.net_revenue_new ,optimization_t.predicted_new)).                      withColumn("Lower_Limit", lower_limit_fun_udf(optimization_t.net_revenue_new , optimization_t.AVERAGE_WEEKLY_TRAFFIC)).					  withColumn("id", monotonicallyIncreasingId())


# In[145]:

optimization_t_final = optimization_t_temp.withColumn("var_name" ,var_name_udf(optimization_t_temp.id))


# In[146]:

col_remove = ["STAR_RATING_BUCKET-onehot",
                "REGION_LEVEL_BUCKET-onehot",
                "BW_BUCKET-onehot",
                "HOTEL_TYPE_BUCKET-onehot",
                "LOS_BUCKET-onehot",
                "SELLER_RANK_BUCKET-onehot"]

optimization_t_final1 = optimization_t_final.select([col for col in optimization_t_final.columns if col not in col_remove ])


# In[147]:

region_df = optimization_t_final1.filter(optimization_t_final1['MODEL_NAME']=='CANADA')


# In[148]:

region_count = region_df.count()
region_count


# In[149]:

len(region_df.rdd.first())


# In[150]:

region_df.rdd.first()


# In[ ]:

t_list = region_df.rdd.map(lambda x  : x[26]).collect()

objective_list =  region_df.rdd.map(lambda x  : x[23]).collect()

final_objective = {t_list[i]: objective_list[i] for i in range(0, region_count)}
                          
lower_limit_list =  region_df.rdd.map(lambda x  : x[24]).collect()
upper_limit_list =  region_df.rdd.map(lambda x  : x[11]).collect()

lower_limit_final = {t_list[i]: lower_limit_list[i] for i in range(0, region_count)}
upper_limit_final = {t_list[i]: upper_limit_list[i] for i in range(0, region_count)}


# In[ ]:

cnt = 0.0
lp_status = "Start"
region_name = region_df.rdd.first()[0]

while ((lp_status != "Optimal")  & (cnt <=2.0)):
	a = cnt
	def constraint_fun(row):
		last_row = row[13] - a * row[23]
		return last_row
	last_row_RDD = region_df.rdd.map(lambda x: constraint_fun(x))
	last_row = last_row_RDD.collect()
	final_constraint = {t_list[i]: last_row[i] for i in range(0, region_count)}
	prob = LpProblem("The Optimization Problem", LpMaximize)
	lp_var = {}
	for variable in t_list:
		variable = LpVariable(variable,lower_limit_final[variable],upper_limit_final[variable])
		lp_var[str(variable)] = variable
	prob += lpSum([final_objective[i]*lp_var[i] for i in t_list])
	prob += lpSum([final_constraint[i]*lp_var[i] for i in t_list]) == 0
	prob.solve()
	lp_status = LpStatus[prob.status]
	var_values = {"start":0}
	for v in prob.variables():
		var_values.update({v.name[2:]:v.varValue})
	lp_status = LpStatus[prob.status]
	results={"region_name":region_name,"lp_status":LpStatus[prob.status],"cnt":(cnt), "gp":value(prob.objective),"var_list":var_values}
	cnt += 0.1
	print(cnt)
    


# In[ ]:

results


# In[ ]:




# In[ ]:




# In[139]:

results_canada_5 = results


# In[121]:

results_canada_4 = results


# In[102]:

results_canada_3 = results


# In[ ]:

results_canada_2 = results


# In[70]:

results_canada_1 = results


# In[ ]:



