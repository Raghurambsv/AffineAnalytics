path="/home/affine/vishnu/Inputs/HOTEL_CLICK_BOOK_AGG_20150629.tab"
newdf = sqlCtx.read.format('com.databricks.spark.csv').options(header='true', inferschema='true',delimiter='\t').load(path)
newdf.registerTempTable("new_ytd_feb14to23jun15")
newdf2 =sqlContext.sql("select local_date,partner_org,partner_pos,device_type,clicked_hotel_id,srch_window as srch_booking_window,srch_los,xclick as traffic,xcost as cost,booked_flag,booked_hotel_id,booked_bkg_window as booked_booking_window,          booked_los,lt_true_up_gp_usd as gross_profit,lt_true_up_gbv_usd as gross_booking_value,lt_true_up_net_rev_usd as net_revenue from new_ytd_feb14to23jun15")

def searchToCategory(srch_los):
    if srch_los == 1: return '1'
    elif srch_los == 2: return '2'
    elif srch_los ==3: return '3'
    elif srch_los ==4: return '4'
    elif srch_los ==5: return '5'
    elif srch_los ==6: return '6'
    elif srch_los ==7: return '7'
    elif srch_los >= 8 and srch_los <= 14: return '8-14'
    else: return '32'
from pyspark.sql.types import Row, StructField, StructType, StringType, IntegerType
from pyspark.sql.functions import udf
udfsearchToCategory=udf(searchToCategory, StringType())
newdf2 = newdf2.withColumn("srch_los_bucket", udfsearchToCategory("srch_los"))
def searchbucketToCategory(srch_booking_window):
    if srch_booking_window== 1: return '1'
    elif srch_booking_window == 2: return '2'
    elif srch_booking_window >= 3 and srch_booking_window <= 4: return '3-4'
    elif srch_booking_window >= 5 and srch_booking_window <= 7: return '5-7'
    elif srch_booking_window >= 8 and srch_booking_window <= 14: return '8-14'
    elif srch_booking_window >= 15 and srch_booking_window <= 20: return '15-20'
    elif srch_booking_window >= 21 and srch_booking_window <= 30: return '21-30'
    elif srch_booking_window >= 31 and srch_booking_window <= 40: return '31-40'
    elif srch_booking_window >= 41 and srch_booking_window <= 60: return '41-60'
    elif srch_booking_window >= 61 and srch_booking_window <= 90: return '61-90'
    elif srch_booking_window >= 91 and srch_booking_window <= 120: return '91-120'
    elif srch_booking_window >= 121 and srch_booking_window <= 180: return '121-180'
    elif srch_booking_window >= 181 and srch_booking_window <= 240: return '181-240'
    else: return '>240'
from pyspark.sql.types import Row, StructField, StructType, StringType, IntegerType
from pyspark.sql.functions import udf
udfsearchbucketToCategory=udf(searchbucketToCategory, StringType())
newdf2 =newdf2.withColumn("srch_bw_bucket", udfsearchbucketToCategory("srch_booking_window"))
def srchbooked_los_bucket(booked_los):
    if booked_los == 1: return '1'
    elif booked_los == 2: return '2'
    elif booked_los == 3: return '3'
    elif booked_los == 4: return '4'
    elif booked_los == 5: return '5'
    elif booked_los == 6: return '6'
    elif booked_los == 7: return '7'
    elif srch_window >= 8 and srch_window <= 14: return '8-14'
    else: return '>14'
from pyspark.sql.types import Row, StructField, StructType, StringType, IntegerType
from pyspark.sql.functions import udf
udfsrchbooked_los_bucket=udf(srchbooked_los_bucket, StringType())
newdf2 = newdf2.withColumn("booked_los_bucket", udfsearchbucketToCategory("booked_los"))
def srchbooked_bw_bucket(booked_booking_window):
    if booked_bkg_window == 1: return '1'
    elif booked_bkg_window == 2: return '2'
    elif srch_window >= 3 and srch_window <= 4: return '3-4'
    elif srch_window >= 5 and srch_window <= 7: return '5-7'
    elif srch_window >= 8 and srch_window <= 14: return '8-14'
    elif srch_window >= 21 and srch_window <= 30: return '21-30'
    elif srch_window >= 31 and srch_window <= 40: return '31-40'
    elif srch_window >= 41 and srch_window <= 60: return '41-60'
    elif srch_window >= 61 and srch_window <= 90: return '61-90'
    elif srch_window >= 91 and srch_window <= 120: return '91-120'
    elif srch_window >= 121 and srch_window <= 180: return '121-180'
    elif srch_window >= 181 and srch_window <= 240: return '181-240'
    else: return '>240'
from pyspark.sql.types import Row, StructField, StructType, StringType, IntegerType
from pyspark.sql.functions import udf
udfsrchsrchbooked_bw_bucket=udf(srchbooked_bw_bucket, StringType())
newdf2 = newdf2.withColumn("booked_bw_bucket", udfsearchbucketToCategory("booked_booking_window"))
newdf2 = newdf2.filter(newdf2['partner_pos'] == 'CA')
newdf2 = newdf2.filter(newdf2['clicked_hotel_id'] <> 0)
newdf2.registerTempTable("new_ytd_feb14to23jun15_temp")
newdf3 = sqlContext.sql("select local_date,partner_org,partner_pos,device_type,booked_hotel_id as hotel_id,                  Booked_Booking_window as booking_window,Booked_BW_bucket as bw_bucket,Booked_LOS as los,Booked_LOS_Bucket as los_bucket,traffic,cost,1 as booking,booked_flag,gross_profit,gross_booking_value,net_revenue from new_ytd_feb14to23jun15_temp")
newdf3= newdf3.filter(newdf3['booked_flag'] == 'Y')
newdf3= newdf3.filter(newdf3['booking_window'] >= -1)
newdf4 = sqlContext.sql("select local_date,partner_org,partner_pos,device_type,clicked_hotel_id as hotel_id,                          srch_booking_window as booking_window,srch_bw_bucket as bw_bucket,srch_LOS as los,Srch_LOS_Bucket as los_bukcet,traffic,cost,0 as booking,booked_flag,gross_profit,gross_booking_value,Net_revenue from new_ytd_feb14to23jun15_temp")
newdf4= newdf4.filter(newdf4['booked_flag'] == 'N')
newdf4= newdf4.filter(newdf4['booking_window'] >= -1)
newdf4= newdf4.filter(newdf4['los'] > 0)
newdf4= newdf4.filter(newdf4['gross_profit'] == 0.0)
newdf4= newdf4.filter(newdf4['gross_booking_value'] == 0.0)
newdf5 = sqlContext.sql("select local_date,partner_org,partner_pos,device_type,clicked_hotel_id as hotel_id,                          Srch_Booking_window as booking_window,Srch_BW_bucket as bw_bucket,srch_LOS as los,                           Srch_LOS_Bucket as los_bucket,traffic,cost,1 as booking,booked_flag,gross_profit,                          gross_booking_value,net_revenue from new_ytd_feb14to23jun15_temp")
newdf5 = newdf5.filter(newdf5['booked_flag'] == 'Y')
newdf5 = newdf5.filter(newdf5['booking_window'] >= 1)
newdf5 = newdf5.filter(newdf5['los'] > 0)
