#creating a dataframe
path="/home/affine/inputs/RF_AD.csv"
AD_Region_Mar = sqlCtx.read.format('com.databricks.spark.csv').options(header='true', inferschema='true',delimiter=',').load(path)

#Displaying column of a dataframe
AD_Region_Mar.select("activity_date").show()

#Displaying the datatype for each column
AD_Region_Mar.dtypes

#converting activity date from string to date
#from pyspark.sql.functions import *
#adconv = AD_Region_Mar.select(date_format(unix_timestamp("activity_date", "MM/dd/yyyy").cast("timestamp"), \
 #                                "yyyy-MM-dd").alias("activity_date"))

#df = (adconv.withColumn('activity_date', adconv.activity_date.cast('date')))
#print df.dtypes
#df.show()

#storing distinct values of column and sorting it
#df2 = df.distinct()
#df2.show()

#df2.sort(df2.activity_date.desc()).show()

#creating training and validation datasets
from pyspark.sql.functions import *
AD_Region_Mar_new = AD_Region_Mar.select("*").withColumn("activity_date_new", date_format(unix_timestamp("activity_date", "MM/dd/yyyy").cast("timestamp"), \
                                 "yyyy-MM-dd"))
AD_Region_Mar_train = AD_Region_Mar_new.filter((AD_Region_Mar_new["activity_date_new"] >= "2015-01-01") & (AD_Region_Mar_new["activity_date_new"] <= "2015-01-27"))
AD_Region_Mar_val = AD_Region_Mar_new.filter((AD_Region_Mar_new["activity_date_new"] < "2015-01-01") | (AD_Region_Mar_new["activity_date_new"] > "2015-01-27"))

#Aggregating the data to the required level
from pyspark.sql.functions import *
AD_Region_Mar_T = AD_Region_Mar_train.groupBy(AD_Region_Mar_train.bw_bucket,AD_Region_Mar_train.los_bucket \
                      ,AD_Region_Mar_train.hotel_type_bucket,AD_Region_Mar_train.star_rating_bucket,AD_Region_Mar_train.market_bucket \
                      ,AD_Region_Mar_train.seller_rank_bucket).sum("traffic","booking")

AD_Region_Mar_T1 = AD_Region_Mar_T.withColumnRenamed('sum(traffic)','Traffic')
AD_Region_Mar_T1 = AD_Region_Mar_T1.withColumnRenamed('sum(booking)','Booking')


AD_Region_Mar_V = AD_Region_Mar_val.groupBy(AD_Region_Mar_val.bw_bucket,AD_Region_Mar_val.los_bucket \
                      ,AD_Region_Mar_val.hotel_type_bucket,AD_Region_Mar_val.star_rating_bucket,AD_Region_Mar_val.market_bucket \
                      ,AD_Region_Mar_val.seller_rank_bucket).sum("traffic","booking")

AD_Region_Mar_V1 = AD_Region_Mar_V.withColumnRenamed('sum(traffic)','Traffic')
AD_Region_Mar_V1 = AD_Region_Mar_V1.withColumnRenamed('sum(booking)','Booking')

######Filtering out the Traffic (Outliers) from data
AD_Region_Mar_T1 = AD_Region_Mar_T1[~((AD_Region_Mar_T1.Traffic<=4) & (AD_Region_Mar_T1.Booking>0))]
AD_Region_Mar_T1 = AD_Region_Mar_T1[~((AD_Region_Mar_T1.Traffic==5) & (AD_Region_Mar_T1.Booking==2))]
AD_Region_Mar_T1 = AD_Region_Mar_T1[~((AD_Region_Mar_T1.Traffic==6) & (AD_Region_Mar_T1.Booking==2))]

#####Converting the data type of required columns to factor
from pyspark.ml.feature import *
def indexStringColumns(df,cols):
    tempdf = df
    for col in cols:
        stringIndexer = StringIndexer(inputCol=col,outputCol=col+"-num")
        si_model = stringIndexer.fit(tempdf)
        tempdf = si_model.transform(tempdf)
    return tempdf
cols = {"bw_bucket","los_bucket","hotel_type_bucket","star_rating_bucket","market_bucket","seller_rank_bucket"}
dfnumeric = indexStringColumns(AD_Region_Mar_T1,cols)
#dfnumeric.show()

def oneHotEncodeColumns(df,cols):
    tempdf = df
    for col in cols:
        onehotenc = OneHotEncoder(inputCol=col+"-num",outputCol=col+"-onehot")
        tempdf = onehotenc.transform(tempdf).drop(col+"-num")
    return tempdf
AD_Region_Mar_T1_Class = oneHotEncodeColumns(dfnumeric,{"bw_bucket","los_bucket","hotel_type_bucket","star_rating_bucket","market_bucket","seller_rank_bucket"})
#AD_Region_Mar_T1_Class.show()
#AD_Region_Mar_T1_Class.dtypes

#####Transforming the training dataset
#Defining function for the same
def genRows(row):
    traffic = row[6]
    booking = row[7]
    bookingcounter = 0
    rowList = []
    
    for i in range(traffic):
        row1 = row[:]                   
        #row1[6]=1
        row1= list(row1)
        row1[6]=1
        row1 = tuple(row1)
        if bookingcounter < int(booking):
            #row1[7]=1
            row1= list(row1)
            row1[7]=1
            row1 = tuple(row1)
        else :
            #row1[7]=0
            row1= list(row1)
            row1[7]=0
            row1 = tuple(row1)
        bookingcounter += 1
        rowList.append(row1)
    return rowList

#Applying function on the complete dataset (after converting to rdd)
rdd1 = AD_Region_Mar_T1_Class.rdd
rdd2 = rdd1.flatMap(lambda x : genRows(x))
#rdd1.take(1)
rdd2.take(1)

#Reconverting to dataframe
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark.mllib.linalg import SparseVector, VectorUDT


schema = StructType([StructField('bw_bucket', StringType(), True),
                     StructField('los_bucket', StringType(), True),
                     StructField('hotel_type_bucket', StringType(), True),
                     StructField('star_rating_bucket', StringType(), True),
                     StructField('market_bucket', StringType(), True),
                     StructField('seller_rank_bucket', StringType(), True),
                     StructField('Traffic', IntegerType(), True),
                     StructField('Booking', IntegerType(), True),
                     StructField('hotel_type_bucket-onehot', VectorUDT(), True),
                     StructField('bw_bucket-onehot',  VectorUDT(), True),
                     StructField('market_bucket-onehot',  VectorUDT(), True),
                     StructField('los_bucket-onehot',  VectorUDT(), True),
                     StructField('seller_rank_bucket-onehot',  VectorUDT(), True),
                     StructField('star_rating_bucket-onehot',  VectorUDT(), True)])
df7 = sqlContext.createDataFrame(rdd2, schema)
#type(df7)
#df7.printSchema()
df7.show(10)

#Converting label to double datatype
toDouble = udf(lambda x : float(x * 1.00) , DoubleType())
df8 = df7.withColumn('Booking' , toDouble(df7.Booking))
#df8.dtypes

#Taking only relevant columns as features
colList = df8.columns 
colList.remove('Booking')
colList.remove('Traffic')
colList.remove('bw_bucket')
colList.remove('los_bucket')
colList.remove('hotel_type_bucket')
colList.remove('star_rating_bucket')
colList.remove('market_bucket')
colList.remove('seller_rank_bucket')
vecAssembler = VectorAssembler(inputCols=colList,outputCol="features")
Train_AD = vecAssembler.transform(df8).select("features", "Booking").withColumnRenamed("Booking", "label")

#####Transforming the validation dataset
cols = {"bw_bucket","los_bucket","hotel_type_bucket","star_rating_bucket","market_bucket","seller_rank_bucket"}
dfnumeric_V1 = indexStringColumns(AD_Region_Mar_V1,cols)
#dfnumeric_V1.show()
AD_Region_Mar_V1_Class = oneHotEncodeColumns(dfnumeric_V1,{"bw_bucket","los_bucket","hotel_type_bucket","star_rating_bucket","market_bucket","seller_rank_bucket"})
#AD_Region_Mar_V1_Class.show()
rddV1 = AD_Region_Mar_V1_Class.rdd
rddV2 = rdd1.flatMap(lambda x : genRows(x))
#rddV2.take(1)
schema = StructType([StructField('bw_bucket', StringType(), True),
                     StructField('los_bucket', StringType(), True),
                     StructField('hotel_type_bucket', StringType(), True),
                     StructField('star_rating_bucket', StringType(), True),
                     StructField('market_bucket', StringType(), True),
                     StructField('seller_rank_bucket', StringType(), True),
                     StructField('Traffic', IntegerType(), True),
                     StructField('Booking', IntegerType(), True),
                     StructField('hotel_type_bucket-onehot', VectorUDT(), True),
                     StructField('bw_bucket-onehot',  VectorUDT(), True),
                     StructField('market_bucket-onehot',  VectorUDT(), True),
                     StructField('los_bucket-onehot',  VectorUDT(), True),
                     StructField('seller_rank_bucket-onehot',  VectorUDT(), True),
                     StructField('star_rating_bucket-onehot',  VectorUDT(), True)])
df9 = sqlContext.createDataFrame(rddV2, schema)
#df9.printSchema()
toDoubleV = udf(lambda x : float(x * 1.00) , DoubleType())
df10 = df9.withColumn('Booking' , toDoubleV(df9.Booking))
#df10.dtypes
col = df10.columns 
col.remove('Booking')
col.remove('Traffic')
col.remove('bw_bucket')
col.remove('los_bucket')
col.remove('hotel_type_bucket')
col.remove('star_rating_bucket')
col.remove('market_bucket')
col.remove('seller_rank_bucket')
vecAssembler = VectorAssembler(inputCols=col,outputCol="indexedFeatures")
Valid_AD = vecAssembler.transform(df10).select("indexedFeatures")
#Valid_AD.show()
Valid_DF = Valid_AD.distinct()
#Valid_DF.show()

####Random Forest model building
from pyspark.ml import Pipeline
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.feature import StringIndexer, VectorIndexer

labelIndexer = StringIndexer(inputCol="label", outputCol="indexedLabel").fit(Train_DF)
featureIndexer = VectorIndexer(inputCol="features", outputCol="indexedFeatures").fit(Train_DF)
rf = RandomForestClassifier(labelCol="indexedLabel", featuresCol="indexedFeatures",impurity="gini",numTrees=1000,maxDepth=2,maxBins=32)
pipeline = Pipeline(stages=[labelIndexer, featureIndexer, rf])
model = pipeline.fit(Train_DF)
rfModel = model.stages[2]
print rfModel

####Prediction on validation dataset
predictions = rfModel.transform(Valid_DF)
#predictions.printSchema()
predicted = predictions.select("indexedFeatures","probability")
predicted.show(10)
