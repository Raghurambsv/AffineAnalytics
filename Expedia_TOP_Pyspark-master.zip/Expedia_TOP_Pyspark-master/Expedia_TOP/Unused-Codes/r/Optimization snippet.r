################# Optimization TripAdvisor Canada #################

setwd("D:/Codes/expedia/Optimization/New RF Models") ###setting working directory
### loading required packages
library("lpSolve") ### used for Optimization 
library("RODBC") #### used for establishing connection with server
library("randomForest") ##### used to load random forest models and predict the conversion rates
library("SOAR") ### to save memory(RAM)
library("RPostgreSQL") ####)( to connect to postgresql) 


### The below code just contains the optimization part of the complete code.

### before this point we have already created a table Optimization_T for point of sale TripAdvisor Canada (combining all different regions)
## which follows the similar structure as Illustration 3 table in Optimization Approach document


Opt <- NULL  ###initiating a Null file so as we can store the final output in the file

Model_Name <- as.character(unique(Optimization_T$model_name)) ## storing the different model names i.e. Canada, US, Mexico etc in a variable

for (i in Model_Name) ###initiating Optimization for each model in a loop
  
{
  cnt=0.7 #### initiating a value for efficiency
  
  Optimization_T1 <- subset(Optimization_T,Optimization_T$model_name==i) ####sub-setting the combined data for each for the models
  
  ### Creating Objective Function
  
  objective.in <- c(Optimization_T1$Predicted*Optimization_T1$epb) ### Objective function for Optimization. 
 ### The lpsolve package works on the principle of Matrix multiplication. variable to be determined from optimization i.e. Traffic is not passed in the
 ###equation. The above objective function should be interpreted as 
 ## objective.in<- Predicted1*epb1*Traffic1 + Predicted2*epb2*Traffic2 + Predicted3*epb3*Traffic3 ..........+ Predictedn*epbn*Trafficn
 
 length(objective.in) #### Quality check step to check if the number of elements in the objective function is equal to number of records in the Optimization_T1
  
  ### Setting Constraints:
  
  ## Step 1: Creating the Left hand side of equation of constraint
  
  
  diag_11 <- rbind(diag(1,nrow(Optimization_T1),length(objective.in)),diag(1,nrow(Optimization_T1),length(objective.in)))
  ## Creating identity matrix which on multiplication with Traffic matrix should result in the following equation:
  ##T1, T2, T3,.........Tn, T1,T2,T3...............,Tn
  
  Store(diag_11)
  
  diag_12 <- Optimization_T1$cpc-(cnt*Optimization_T1$epb*Optimization_T1$Predicted)
  ### The above equation is writing efficiency which should be interpreted as:
  ###T1*(cpc1-(cnt * EPB1* Predicted1)) + T2*(cpc2-(cnt * EPB2* Predicted2))+......... + Tn*(cpc_n-(cnt * EPBn* Predicted_n))
  
  diag_1 <- rbind(diag_11,diag_12)
  
  ### Step 2: Setting the signs 
  
  nrow(diag_1)
  dir <- rep(c(">=","<="),c(nrow(Optimization_T1),nrow(Optimization_T1))) 
  dir <- c(dir,"=")
  
  length(dir)
  
  ### Step 3 :Setting the RHS for constraint equation
  
  lower_limit <- ifelse(Optimization_T1$epb>=100,0.5,  
                        ifelse(Optimization_T1$epb>=50 & Optimization_T1$epb<100,0.2,0.2)) 

  sum(lower_limit)
  ####Defining a variable to determine the minimum value of fraction. The minimum value is set as 0.5 if the epb is greater than 100$
  ##and is set as 0.2 for every thing else
  
  ## By setting the minimum value of allowed traffic as 0.2 we ensure that none of the queries are throttled more than 80%
  
  constraint <- c(lower_limit*(Optimization_T1$average_weekly_traffic),Optimization_T1$average_weekly_traffic)
  ## setting the min and max values of traffic to be predicted from algorithm
  
  length(Optimization_T1$average_weekly_traffic)
  constraint <- c(constraint,0)
  ##setting efficiency as 0
  
  ##### final constraint equations created are:
  
  ### T1>=0.2*AWT1 , T2>=0.2*AWT2,T3>=0.5*AWT3 (if epb3 >100$),........ ,Tn>=0.2*AWTn (minimum value of allowed Traffic cannot be less than 20% of AWT)
  ### T1<= AWT1, T2<=AWT2,.............Tn<=AWTn (where AWT is average weekly traffic) (maximum value for allowed traffic cannot be greater than AWT)
  
  #### T1*(CPC1-(0.7*EPB1*Predicted1))+ T2*(CPC2-(0.7*EPB2*Predicted2))+..............+Tn*(CPCn-(0.7*EPBn*Predicted_n))=0 (Efficiency should be equal to 0.7)
  
  length(constraint)                
  Lp <- lp (direction = "max", objective.in, diag_1, dir, constraint,
            transpose.constraints = TRUE, all.int=F) ### Running the optimization algorithm
  
  
  ##if solution not found at cnt(efficiency value)=0.7 then we iterate and run the same algorithm by changing the values of efficiency
  cnt=0.71
  while(sum(Lp$solution)==0 & cnt<=2.0) #### maximum value hard-coded for simplicity but is set as the efficiency of region in current week
  {
    print(i)
    print(cnt)
    
    diag_12 <- Optimization_T1$cpc-(cnt*Optimization_T1$epb*Optimization_T1$Predicted)
    diag_1 <- rbind(diag_11,diag_12)
    
    dir <- rep(c(">=","<="),c(nrow(Optimization_T1),nrow(Optimization_T1)))
    dir <- c(dir,"=")
    
    constraint <- c(lower_limit*(Optimization_T1$average_weekly_traffic),Optimization_T1$average_weekly_traffic)  
    constraint <- c(constraint,0)
    
    Lp <- lp (direction = "max", objective.in, diag_1, dir, constraint,
              transpose.constraints = TRUE, all.int=F) 
    
    cnt=cnt+0.01
  }
  
  
  Opt_1 <- data.frame(Optimization_T1,Lp$solution,Flag=ifelse(sum(Lp$solution)==0
                                                              ,"No Solution Found","Solution_Found"),Efficiency=cnt-0.01) ## Getting optimization output for each loop
															
  Opt <- rbind(Opt,Opt_1) ### Combining outputs in each loop to get final optimization output
}

#####calculating the final throttle value from Optimization solution

Opt_s <- Opt

Opt_s_final$fraction <- Opt_s_final$Lp.solution/Opt_s_final$average_weekly_traffic ### determining fraction i.e. solution by average_weekly_traffic
Opt_s_final$throttle <- 1-Opt_s_final$fraction ### determining throttle i.e 1 - fraction

Opt_s_out <- Opt_s_final[,c(1,13,14,29)] ### selecting hotel_id, bw_bucket, los_bucket, throttle
Opt_s_out$throttle <-round(Opt_s_out$throttle,2) ## rounding the throttle values
unique(Opt_s_out$throttle) 

nrow(subset(Opt_s_out,Opt_s_out$throttle==0)) 

Out_final_oldquery <- subset(Opt_s_out,Opt_s_out$throttle!=0.0) ## removing the rows where recommended throttle is 0

