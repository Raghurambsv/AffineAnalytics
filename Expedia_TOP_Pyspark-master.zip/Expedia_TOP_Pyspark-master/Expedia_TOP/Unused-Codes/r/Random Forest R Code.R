############################ Random Forest ###############################

setwd("F:/Expedia/Final Expedia/Expedia Postgres/Trivago 7132015")
library("randomForest")
library("data.table")
library("date")
library("RPostgreSQL")

#####Connecting to PostgreSQL

drv <- dbDriver("PostgreSQL")
con <- dbConnect(drv,dbname="postgres",host="192.168.0.186",port=5432,user="postgres",password="test@123")

#####Retriving the data from PostgreSQL

AD_Region_Mar <- dbGetQuery(con,"select * from triv_europe2")

#####Changingig the datatype

AD_Region_Mar$activity_date <- as.Date(AD_Region_Mar$activity_date)
unique((AD_Region_Mar$activity_date))

#####Creating the training and Validation datasets from the data

AD_Region_Mar_val <- subset(AD_Region_Mar,AD_Region_Mar$activity_date>=as.Date("2015-07-12") & AD_Region_Mar$activity_date<=as.Date("2015-07-18"))
unique((AD_Region_Mar_val$activity_date))
AD_Region_Mar_train <- AD_Region_Mar[!(AD_Region_Mar$activity_date %in% unique(AD_Region_Mar_val$activity_date)),]

#####Aggregationg the data to the required level

AD_Region_Mar_train <- as.data.table(AD_Region_Mar_train)
AD_Region_Mar_val <- as.data.table(AD_Region_Mar_val)

AD_Region_Mar_T1 <- AD_Region_Mar_train[,list(traffic=sum(traffic),booking=sum(booking)),by=c("bw_bucket","los_bucket","hotel_type_bucket",
                                                                                              "star_rating_bucket","market_bucket","seller_rank_bucket")]

AD_Region_Mar_V1 <- AD_Region_Mar_val[,list(traffic=sum(traffic),booking=sum(booking)),by=c("bw_bucket","los_bucket","hotel_type_bucket",
                                                                                            "star_rating_bucket","market_bucket","seller_rank_bucket")]
AD_Region_Mar_T1 <- as.data.frame(AD_Region_Mar_T1)
AD_Region_Mar_V1 <- as.data.frame(AD_Region_Mar_V1)

#####Filtering out the Traffic (Outliers) from training data

AD_Region_Mar_T1 <- AD_Region_Mar_T1[!(AD_Region_Mar_T1$booking>0 & AD_Region_Mar_T1$traffic<=4),]
AD_Region_Mar_T1 <- AD_Region_Mar_T1[!(AD_Region_Mar_T1$booking==2 & AD_Region_Mar_T1$traffic==5),]
AD_Region_Mar_T1 <- AD_Region_Mar_T1[!(AD_Region_Mar_T1$booking==2 & AD_Region_Mar_T1$traffic==6),]


#####Converting the data type of required columns to factor

AD_Region_Mar_T1_Class <- AD_Region_Mar_T1[rep(1:nrow(AD_Region_Mar_T1),AD_Region_Mar_T1$traffic),]
sapply(AD_Region_Mar_T1_Class,class)

for(i in colnames(AD_Region_Mar_T1_Class)[1:6])
{
  AD_Region_Mar_T1_Class[[i]] <- as.factor(AD_Region_Mar_T1_Class[[i]])
}
sum(is.na(AD_Region_Mar_T1_Class))

#####Transforming the training the data

sum(AD_Region_Mar_T1$traffic)
Vec1=rep(c(1,0),nrow(AD_Region_Mar_T1))
length(Vec1)
x=rep(1,2*nrow(AD_Region_Mar_T1))
odd=seq(1,2*nrow(AD_Region_Mar_T1),by=2)
even <- seq(2,2*nrow(AD_Region_Mar_T1),by=2)
length(odd)+length(even)
length(x)
x[odd] <- AD_Region_Mar_T1$booking
x[even] <- AD_Region_Mar_T1$traffic-AD_Region_Mar_T1$booking
AD_Region_Mar_T1_Class$Flag=rep(Vec1,x)
names(AD_Region_Mar_T1_Class)
AD_Region_Mar_T1_Class=AD_Region_Mar_T1_Class[,c(1:6,9)]

#####Creating the equation for running Random Forest

AD_Region_Model_Eq_Class<- as.formula(paste("Flag",paste(names(AD_Region_Mar_T1_Class)[1:6],collapse="+"),sep="~"))


#####Running Randam Forest

library("foreach")
Start_Time <- Sys.time()
RF_AD_Region_Mar <- foreach(ntree=rep(125,8),.combine=combine) %do%
  randomForest(AD_Region_Model_Eq_Class,AD_Region_Mar_T1_Class,ntree=ntree,mtry=2)
End_Time <- Sys.time()
Duration  <- Start_Time-End_Time

#####Checking Variable Importance

importance(RF_AD_Region_Mar)

#####Save the RF Model Result

save(RF_AD_Region_Mar,file = "RF_Europe2.RData")
save.image("WS_Europe2_rf.RData")

#####Predicting the Training,Validation and creating error buckets

RF_AD_Region_T1_pred <- data.frame(AD_Region_Mar_T1,Predicted=predict(RF_AD_Region_Mar,AD_Region_Mar_T1[,1:6]))
RF_AD_Region_T1_pred$Actual_Conversion <- round((RF_AD_Region_T1_pred$Booking/RF_AD_Region_T1_pred$Traffic)*100,3)
RF_AD_Region_T1_pred$Predicted <- round(RF_AD_Region_T1_pred$Predicted*100,3)
RF_AD_Region_T1_pred$diff <- round(abs(RF_AD_Region_T1_pred$Actual_Conversion-RF_AD_Region_T1_pred$Predicted),3)
RF_AD_Region_T1_pred$diff_bucket <- ifelse(RF_AD_Region_T1_pred$diff<1,"0%-1%",
                                           ifelse(RF_AD_Region_T1_pred$diff>=1 & RF_AD_Region_T1_pred$diff<2,"1%-2%",
                                                  ifelse(RF_AD_Region_T1_pred$diff>=2 & RF_AD_Region_T1_pred$diff<3,"2%-3%",
                                                         ifelse(RF_AD_Region_T1_pred$diff>=3 & RF_AD_Region_T1_pred$diff<4,"3%-4%",
                                                                ifelse(RF_AD_Region_T1_pred$diff>=4 & RF_AD_Region_T1_pred$diff<5,"4%-5%",
                                                                       ifelse(RF_AD_Region_T1_pred$diff>=5 & RF_AD_Region_T1_pred$diff<10,"5%-10%",
                                                                              ifelse(RF_AD_Region_T1_pred$diff>=10 & RF_AD_Region_T1_pred$diff<30,"10%-30%",
                                                                                     ifelse(RF_AD_Region_T1_pred$diff>=30 & RF_AD_Region_T1_pred$diff<50,"30%-50%",
                                                                                            ifelse(RF_AD_Region_T1_pred$diff>=50 & RF_AD_Region_T1_pred$diff<90,"50%-90%","90+%")))))))))



RF_AD_Region_V1_pred <- data.frame(AD_Region_Mar_V1,Predicted=predict(RF_AD_Region_Mar,AD_Region_Mar_V1[,1:6]))
RF_AD_Region_V1_pred$Actual_Conversion <- round((RF_AD_Region_V1_pred$Booking/RF_AD_Region_V1_pred$Traffic)*100,3)
RF_AD_Region_V1_pred$Predicted <- round(RF_AD_Region_V1_pred$Predicted*100,3)
RF_AD_Region_V1_pred$diff <- round(abs(RF_AD_Region_V1_pred$Actual_Conversion-RF_AD_Region_V1_pred$Predicted),3)
RF_AD_Region_V1_pred$diff_bucket <- ifelse(RF_AD_Region_V1_pred$diff<1,"0%-1%",
                                           ifelse(RF_AD_Region_V1_pred$diff>=1 & RF_AD_Region_V1_pred$diff<2,"1%-2%",
                                                  ifelse(RF_AD_Region_V1_pred$diff>=2 & RF_AD_Region_V1_pred$diff<3,"2%-3%",
                                                         ifelse(RF_AD_Region_V1_pred$diff>=3 & RF_AD_Region_V1_pred$diff<4,"3%-4%",
                                                                ifelse(RF_AD_Region_V1_pred$diff>=4 & RF_AD_Region_V1_pred$diff<5,"4%-5%",
                                                                       ifelse(RF_AD_Region_V1_pred$diff>=5 & RF_AD_Region_V1_pred$diff<10,"5%-10%",
                                                                              ifelse(RF_AD_Region_V1_pred$diff>=10 & RF_AD_Region_V1_pred$diff<30,"10%-30%",
                                                                                     ifelse(RF_AD_Region_V1_pred$diff>=30 & RF_AD_Region_V1_pred$diff<50,"30%-50%",
                                                                                            ifelse(RF_AD_Region_V1_pred$diff>=50 & RF_AD_Region_V1_pred$diff<90,"50%-90%","90+%")))))))))

####Write the Required files

write.csv(RF_AD_Region_V1_pred,"RF_Canada_OR_Wk4_Mobile_V1.csv",row.names=F)
write.csv(RF_AD_Region_T1_pred,"RF_Canada_OR_Wk4_Mobile_T1.csv",row.names=F)

