﻿/*-----------------------------------------------------------------------------------------------------------------------------------------------------------------*/
/*--------------------------------------------Creating ADs for Random Forest - TripAdvisor CA----------------------------------------------*/
/*------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

/*------------------------Enter the Reququired dates and create a Temporary Table------------------------*/

Create temporary table dates
as
(
SELECT date_trunc('day', dd):: date
FROM generate_series
        ( '2015-07-05'::timestamp 
        , '2015-07-18'::timestamp
        , '1 day'::interval) dd
);

Create temporary table date1
as
(
Select date_trunc,rank() over(order by date_trunc) as date_rank from dates
);

/*------------------------Drop and recreate the rank_ad table to upadte it with the new data------------------------*/

---drop table rank_ad
Create table postgres.public.rank_ad
(
      hotel_id varchar(50)
     ,region varchar(1000)
     ,region_bucket varchar(1000)
     ,market_bucket varchar(1000)
     ,market varchar(1000)
     ,model_name varchar(50)
     ,city_bucket varchar(1000)
     ,city varchar(1000)
     ,hotel_type varchar(50)
     ,hotel_type_bucket varchar(50)
     ,star_rating varchar(50)
     ,star_rating_bucket varchar(50)
     ,los_bucket varchar(50)
     ,bw_bucket varchar(50)
     ,device_type varchar(50)
     ,activity_date date
     ,traffic int
     ,booking int 
     ,total_cost float
     ,cpc float
     ,gross_profit float
     ,seller_rank int
)

/*-------------------------------------Function  to Populate Seller Rank--------------------------------------------------*/
/*---------------------Note: Not necessary to recreate the function every time (Already Created) -------------------------*/

create function insert_rank_ad() RETURNS void as 
$$

Declare cnt INTEGER = 1;

Begin

WHILE (cnt <= (Select max(date_rank) from date1)) LOOP

drop table date_loop;

Create table date_loop
as
(
Select date_trunc from date1 where date_rank=cnt
);
cnt:= cnt + 1;

INSERT INTO rank_ad (hotel_id,region,region_bucket,market_bucket,market,model_name,city_bucket,city,hotel_type,hotel_type_bucket,star_rating,star_rating_bucket
,los_bucket,bw_bucket,device_type,activity_date
,traffic,booking,total_cost,cpc
,gross_profit,seller_rank)

Select C.*
,coalesce(R0.seller_Rank,R1.seller_Rank,R2.seller_Rank,R3.seller_Rank,R4.seller_Rank,R5.seller_Rank,R6.seller_Rank,R7.seller_Rank) as seller_Rank
from 
(Select Hotel_ID,Region,Region_Bucket,Market_Bucket,Market,Model_Name,City_Bucket,City,Hotel_Type,Hotel_type_bucket,Star_Rating,Star_Rating_Bucket
,LOS_Bucket,BW_Bucket,Device_Type,Activity_Date
,Traffic,Booking,cost,Round(cast((cost*1.0)/Traffic as numeric),3)  as CPC
,Gross_Profit 
from Canada_Raw_AD where Activity_Date in (Select date_trunc from date_loop)
) C
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE)in (Select date_trunc from date_loop)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R0
on C.Hotel_ID=R0.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int)as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE)in (Select date_trunc-1 from date_loop)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R1
on C.Hotel_ID=R1.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE)in (Select date_trunc-2 from date_loop)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R2
on C.Hotel_ID=R2.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE)in (Select date_trunc-3 from date_loop)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R3
on C.Hotel_ID=R3.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE)in (Select date_trunc-4 from date_loop)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R4
on C.Hotel_ID=R4.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE)in (Select date_trunc-5 from date_loop)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R5
on C.Hotel_ID=R5.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE)in (Select date_trunc-6 from date_loop)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R6
on C.Hotel_ID=R6.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE)in (Select date_trunc-7 from date_loop)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R7
on C.Hotel_ID=R7.Expedia_Hotel_ID
;

END LOOP;

END;
$$ LANGUAGE plpgsql


/*-----------------Retriving the data from Function----------------------*/
/*----------------Note: Every time retrive the function------------------------*/

select * from insert_rank_ad()

/*-----------------------------------------------------------------------------------------------------------*/
/*---------------------Creating Analytical Data sets for Random Forests for individual models----------------*/
/*-----------------------------------------------------------------------------------------------------------*/

/*---------------------Creating RF Analytical dataset for Model_name - Canada-----------------------------------*/
Create temporary table canada
as
(
SELECT hotel_id
      ,Region
      ,Region_Bucket
      ,Market_Bucket
      ,Market
      ,Model_Name
      ,City_Bucket
      ,City
      ,Hotel_Type
      ,Hotel_Type_Bucket
      ,Star_Rating
      ,Star_Rating_Bucket
      ,LOS_Bucket
      ,BW_Bucket
      ,Device_Type
      ,Activity_Date
      ,Traffic
      ,Booking
      ,total_cost
      ,Gross_Profit
      ,case when seller_Rank is null then 3 else seller_rank end as seller_rank
  FROM rank_ad
  where Model_Name='Canada'
  Union 
  (SELECT a.Hotel_ID
      ,a.Region
      ,a.Region_Bucket
      ,a.Market_Bucket
      ,a.Market
      ,a.Model_Name
      ,a.City_Bucket
      ,a.City
      ,a.Hotel_Type
      ,a.Hotel_Type_Bucket
      ,a.Star_Rating
      ,a.Star_Rating_Bucket
      ,a.LOS_Bucket
      ,a.BW_Bucket
      ,a.Device_Type
      ,a.Activity_Date
      ,a.Traffic
      ,a.Booking
      ,a.Cost as total_cost
      ,a.Gross_Profit
      ,case when (a.Cost*1.0/a.Traffic)>2.0*(cast(b.final_bid_value_cpc as numeric)) then 1
	 when (a.Cost*1.0/a.Traffic)>1.0*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=2.0*(cast(b.final_bid_value_cpc as numeric)) then 2
	 when (a.Cost*1.0/a.Traffic)>0.6*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=1.0*(cast(b.final_bid_value_cpc as numeric)) then 3
	 when (a.Cost*1.0/a.Traffic)>0.2*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=0.6*(cast(b.final_bid_value_cpc as numeric)) then 4
	 else 5
	 end as seller_Rank
 FROM 
 (Select * from canada_raw_ad
 where Activity_Date>='2014-07-20' and Activity_Date<='2014-07-26'
 and Model_Name='Canada') a
 join 
 (Select * from new_cpc_values_may25 WHERE partner_org='TRIPADVISOR' and pos='CA') b
 on a.Hotel_ID=b.hotel_ID ) 
);

/*-------------------------AD for Canada Desktop--------------------------*/
--drop table ta_canada_desktop
Create table ta_canada_desktop 
as 
(
Select *,Case when seller_rank>=5 then '>=5' else cast(seller_rank as varchar(50)) end as seller_rank_bucket
 from canada
 where Device_Type='DESKTOP'
);

/*-------------------------AD for Canada Mobile--------------------------*/
---drop table ta_canada_mobile
 Create table ta_canada_mobile
 as
 (
 Select *,Case when seller_rank>=5 then '>=5' else cast(seller_rank as varchar(50)) end as seller_rank_bucket
 from canada
 where Device_Type='MOBILE'
);

/*---------------------Creating RF Analytical dataset for Model_name - US-----------------------------------*/
Create temporary table us
as
(
SELECT hotel_id
      ,Region
      ,Region_Bucket
      ,Market_Bucket
      ,Market
      ,Model_Name
      ,City_Bucket
      ,City
      ,Hotel_Type
      ,Hotel_Type_Bucket
      ,Star_Rating
      ,Star_Rating_Bucket
      ,LOS_Bucket
      ,BW_Bucket
      ,Device_Type
      ,Activity_Date
      ,Traffic
      ,Booking
      ,total_cost
      ,Gross_Profit
      ,case when seller_Rank is null then 3 else seller_rank end as seller_rank
  FROM rank_ad
  where Model_Name='US'
  Union 
  (SELECT a.Hotel_ID
      ,a.Region
      ,a.Region_Bucket
      ,a.Market_Bucket
      ,a.Market
      ,a.Model_Name
      ,a.City_Bucket
      ,a.City
      ,a.Hotel_Type
      ,a.Hotel_Type_Bucket
      ,a.Star_Rating
      ,a.Star_Rating_Bucket
      ,a.LOS_Bucket
      ,a.BW_Bucket
      ,a.Device_Type
      ,a.Activity_Date
      ,a.Traffic
      ,a.Booking
      ,a.Cost as total_cost
      ,a.Gross_Profit
      ,case when (a.Cost*1.0/a.Traffic)>2.0*(cast(b.final_bid_value_cpc as numeric)) then 1
	 when (a.Cost*1.0/a.Traffic)>1.0*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=2.0*(cast(b.final_bid_value_cpc as numeric)) then 2
	 when (a.Cost*1.0/a.Traffic)>0.6*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=1.0*(cast(b.final_bid_value_cpc as numeric)) then 3
	 when (a.Cost*1.0/a.Traffic)>0.2*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=0.6*(cast(b.final_bid_value_cpc as numeric)) then 4
	 else 5
	 end as seller_Rank
 FROM 
 (Select * from canada_raw_ad
 where Activity_Date>='2014-07-20' and Activity_Date<='2014-07-26'
 and Model_Name='US') a
 join 
 (Select * from new_cpc_values_may25 WHERE partner_org='TRIPADVISOR' and pos='CA') b
 on a.Hotel_ID=b.hotel_ID ) 
);

/*-------------------------AD for US Desktop--------------------------*/
--drop table ta_us_desktop
Create table ta_us_desktop 
as 
(
Select *,Case when seller_rank>=5 then '>=5' else cast(seller_rank as varchar(50)) end as seller_rank_bucket
 from us
 where Device_Type='DESKTOP'
);

/*-------------------------AD for US Mobile--------------------------*/
--drop table ta_us_mobile
 Create table ta_us_mobile
 as
 (
 Select *,Case when seller_rank>=5 then '>=5' else cast(seller_rank as varchar(50)) end as seller_rank_bucket
 from us
 where Device_Type='MOBILE'
);

Select distinct model_name from rank_ad

/*---------------------Creating RF Analytical dataset for Model_name - Other Region-----------------------------------*/
Create temporary table other_region
as
(
SELECT hotel_id
      ,Region
      ,Region_Bucket
      ,Market_Bucket
      ,Market
      ,Model_Name
      ,City_Bucket
      ,City
      ,Hotel_Type
      ,Hotel_Type_Bucket
      ,Star_Rating
      ,Star_Rating_Bucket
      ,LOS_Bucket
      ,BW_Bucket
      ,Device_Type
      ,Activity_Date
      ,Traffic
      ,Booking
      ,total_cost
      ,Gross_Profit
      ,case when seller_Rank is null then 3 else seller_rank end as seller_rank
  FROM rank_ad
  where Model_Name='Other Region'
  Union 
  (SELECT a.Hotel_ID
      ,a.Region
      ,a.Region_Bucket
      ,a.Market_Bucket
      ,a.Market
      ,a.Model_Name
      ,a.City_Bucket
      ,a.City
      ,a.Hotel_Type
      ,a.Hotel_Type_Bucket
      ,a.Star_Rating
      ,a.Star_Rating_Bucket
      ,a.LOS_Bucket
      ,a.BW_Bucket
      ,a.Device_Type
      ,a.Activity_Date
      ,a.Traffic
      ,a.Booking
      ,a.Cost as total_cost
      ,a.Gross_Profit
      ,case when (a.Cost*1.0/a.Traffic)>2.0*(cast(b.final_bid_value_cpc as numeric)) then 1
	 when (a.Cost*1.0/a.Traffic)>1.0*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=2.0*(cast(b.final_bid_value_cpc as numeric)) then 2
	 when (a.Cost*1.0/a.Traffic)>0.6*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=1.0*(cast(b.final_bid_value_cpc as numeric)) then 3
	 when (a.Cost*1.0/a.Traffic)>0.2*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=0.6*(cast(b.final_bid_value_cpc as numeric)) then 4
	 else 5
	 end as seller_Rank
 FROM 
 (Select * from canada_raw_ad
 where Activity_Date>='2014-07-20' and Activity_Date<='2014-07-26'
 and Model_Name='Other Region') a
 join 
 (Select * from new_cpc_values_may25 WHERE partner_org='TRIPADVISOR' and pos='CA') b
 on a.Hotel_ID=b.hotel_ID ) 
);

/*-------------------------AD for Other region Desktop--------------------------*/
--drop table ta_other_region_desktop
Create table ta_other_region_desktop 
as 
(
Select *,Case when seller_rank>=5 then '>=5' else cast(seller_rank as varchar(50)) end as seller_rank_bucket
 from other_region
 where Device_Type='DESKTOP'
);

/*-------------------------AD for Other region Mobile--------------------------*/
--drop table ta_other_region_mobile
 Create table ta_other_region_mobile
 as
 (
 Select *,Case when seller_rank>=5 then '>=5' else cast(seller_rank as varchar(50)) end as seller_rank_bucket
 from other_region
 where Device_Type='MOBILE'
);



/*---------------------Creating RF Analytical dataset for Model_name - Caribbean-----------------------------------*/
--drop table caribbean
Create temporary table caribbean
as
(
SELECT hotel_id
      ,Region
      ,Region_Bucket
      ,Market_Bucket
      ,Market
      ,Model_Name
      ,City_Bucket
      ,City
      ,Hotel_Type
      ,Hotel_Type_Bucket
      ,Star_Rating
      ,Star_Rating_Bucket
      ,LOS_Bucket
      ,BW_Bucket
      ,Device_Type
      ,Activity_Date
      ,Traffic
      ,Booking
      ,total_cost
      ,Gross_Profit
      ,case when seller_Rank is null then 3 else seller_rank end as seller_rank
  FROM rank_ad
  where Model_Name='CARIBBEAN'
  Union 
  (SELECT a.Hotel_ID
      ,a.Region
      ,a.Region_Bucket
      ,a.Market_Bucket
      ,a.Market
      ,a.Model_Name
      ,a.City_Bucket
      ,a.City
      ,a.Hotel_Type
      ,a.Hotel_Type_Bucket
      ,a.Star_Rating
      ,a.Star_Rating_Bucket
      ,a.LOS_Bucket
      ,a.BW_Bucket
      ,a.Device_Type
      ,a.Activity_Date
      ,a.Traffic
      ,a.Booking
      ,a.Cost as total_cost
      ,a.Gross_Profit
      ,case when (a.Cost*1.0/a.Traffic)>2.0*(cast(b.final_bid_value_cpc as numeric)) then 1
	 when (a.Cost*1.0/a.Traffic)>1.0*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=2.0*(cast(b.final_bid_value_cpc as numeric)) then 2
	 when (a.Cost*1.0/a.Traffic)>0.6*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=1.0*(cast(b.final_bid_value_cpc as numeric)) then 3
	 when (a.Cost*1.0/a.Traffic)>0.2*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=0.6*(cast(b.final_bid_value_cpc as numeric)) then 4
	 else 5
	 end as seller_Rank
 FROM 
 (Select * from canada_raw_ad
 where Activity_Date>='2014-07-20' and Activity_Date<='2014-07-26'
 and Model_Name='CARIBBEAN') a
 join 
 (Select * from new_cpc_values_may25 WHERE partner_org='TRIPADVISOR' and pos='CA') b
 on a.Hotel_ID=b.hotel_ID ) 
);

/*-------------------------AD for Caribbean Desktop--------------------------*/
--drop table ta_caribbean_desktop
Create table ta_caribbean_desktop 
as 
(
Select *,Case when seller_rank>=5 then '>=5' else cast(seller_rank as varchar(50)) end as seller_rank_bucket
 from caribbean
 where Device_Type='DESKTOP'
);

/*-------------------------AD for Caribbean Mobile--------------------------*/
 --drop table ta_caribbean_mobile
 Create table ta_caribbean_mobile
 as
 (
 Select *,Case when seller_rank>=5 then '>=5' else cast(seller_rank as varchar(50)) end as seller_rank_bucket
 from caribbean
 where Device_Type='MOBILE'
);

/*---------------------Creating RF Analytical dataset for Model_name - Mexico-----------------------------------*/
--drop table mexico
Create temporary table mexico
as
(
SELECT hotel_id
      ,Region
      ,Region_Bucket
      ,Market_Bucket
      ,Market
      ,Model_Name
      ,City_Bucket
      ,City
      ,Hotel_Type
      ,Hotel_Type_Bucket
      ,Star_Rating
      ,Star_Rating_Bucket
      ,LOS_Bucket
      ,BW_Bucket
      ,Device_Type
      ,Activity_Date
      ,Traffic
      ,Booking
      ,total_cost
      ,Gross_Profit
      ,case when seller_Rank is null then 3 else seller_rank end as seller_rank
  FROM rank_ad
  where Model_Name='Mexico'
  Union 
  (SELECT a.Hotel_ID
      ,a.Region
      ,a.Region_Bucket
      ,a.Market_Bucket
      ,a.Market
      ,a.Model_Name
      ,a.City_Bucket
      ,a.City
      ,a.Hotel_Type
      ,a.Hotel_Type_Bucket
      ,a.Star_Rating
      ,a.Star_Rating_Bucket
      ,a.LOS_Bucket
      ,a.BW_Bucket
      ,a.Device_Type
      ,a.Activity_Date
      ,a.Traffic
      ,a.Booking
      ,a.Cost as total_cost
      ,a.Gross_Profit
      ,case when (a.Cost*1.0/a.Traffic)>2.0*(cast(b.final_bid_value_cpc as numeric)) then 1
	 when (a.Cost*1.0/a.Traffic)>1.0*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=2.0*(cast(b.final_bid_value_cpc as numeric)) then 2
	 when (a.Cost*1.0/a.Traffic)>0.6*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=1.0*(cast(b.final_bid_value_cpc as numeric)) then 3
	 when (a.Cost*1.0/a.Traffic)>0.2*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=0.6*(cast(b.final_bid_value_cpc as numeric)) then 4
	 else 5
	 end as seller_Rank
 FROM 
 (Select * from canada_raw_ad
 where Activity_Date>='2014-07-20' and Activity_Date<='2014-07-26'
 and Model_Name='Mexico') a
 join 
 (Select * from new_cpc_values_may25 WHERE partner_org='TRIPADVISOR' and pos='CA') b
 on a.Hotel_ID=b.hotel_ID ) 
);

/*-------------------------AD for Mexico Desktop--------------------------*/
--drop table ta_mexico_desktop
Create table ta_mexico_desktop 
as 
(
Select *,Case when seller_rank>=5 then '>=5' else cast(seller_rank as varchar(50)) end as seller_rank_bucket
 from mexico
 where Device_Type='DESKTOP'
);

/*-------------------------AD for Mexico Mobile--------------------------*/
--drop table ta_mexico_mobile
 Create table ta_mexico_mobile
 as
 (
 Select *,Case when seller_rank>=5 then '>=5' else cast(seller_rank as varchar(50)) end as seller_rank_bucket
 from mexico
 where Device_Type='MOBILE'
);

/*---------------------Creating RF Analytical dataset for Model_name - North America-----------------------------------*/
--drop table north_america
Create temporary table north_america
as
(
SELECT hotel_id
      ,Region
      ,Region_Bucket
      ,Market_Bucket
      ,Market
      ,Model_Name
      ,City_Bucket
      ,City
      ,Hotel_Type
      ,Hotel_Type_Bucket
      ,Star_Rating
      ,Star_Rating_Bucket
      ,LOS_Bucket
      ,BW_Bucket
      ,Device_Type
      ,Activity_Date
      ,Traffic
      ,Booking
      ,total_cost
      ,Gross_Profit
      ,case when seller_Rank is null then 3 else seller_rank end as seller_rank
  FROM rank_ad
  where Model_Name='North America'
  Union 
  (SELECT a.Hotel_ID
      ,a.Region
      ,a.Region_Bucket
      ,a.Market_Bucket
      ,a.Market
      ,a.Model_Name
      ,a.City_Bucket
      ,a.City
      ,a.Hotel_Type
      ,a.Hotel_Type_Bucket
      ,a.Star_Rating
      ,a.Star_Rating_Bucket
      ,a.LOS_Bucket
      ,a.BW_Bucket
      ,a.Device_Type
      ,a.Activity_Date
      ,a.Traffic
      ,a.Booking
      ,a.Cost as total_cost
      ,a.Gross_Profit
      ,case when (a.Cost*1.0/a.Traffic)>2.0*(cast(b.final_bid_value_cpc as numeric)) then 1
	 when (a.Cost*1.0/a.Traffic)>1.0*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=2.0*(cast(b.final_bid_value_cpc as numeric)) then 2
	 when (a.Cost*1.0/a.Traffic)>0.6*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=1.0*(cast(b.final_bid_value_cpc as numeric)) then 3
	 when (a.Cost*1.0/a.Traffic)>0.2*(cast(b.final_bid_value_cpc as numeric)) and (a.Cost*1.0/a.Traffic)<=0.6*(cast(b.final_bid_value_cpc as numeric)) then 4
	 else 5
	 end as seller_Rank
 FROM 
 (Select * from canada_raw_ad
 where Activity_Date>='2014-07-20' and Activity_Date<='2014-07-26'
 and Model_Name='North America') a
 join 
 (Select * from new_cpc_values_may25 WHERE partner_org='TRIPADVISOR' and pos='CA') b
 on a.Hotel_ID=b.hotel_ID ) 
);

/*-------------------------AD for North America Desktop--------------------------*/
--drop table ta_north_america_desktop
Create table ta_north_america_desktop 
as 
(
Select *,Case when seller_rank>=5 then '>=5' else cast(seller_rank as varchar(50)) end as seller_rank_bucket
 from north_america
 where Device_Type='DESKTOP'
);

/*-------------------------AD for North America Mobile--------------------------*/
 --drop table ta_north_america_mobile
 Create table ta_north_america_mobile
 as
 (
 Select *,Case when seller_rank>=5 then '>=5' else cast(seller_rank as varchar(50)) end as seller_rank_bucket
 from north_america
 where Device_Type='MOBILE'
);