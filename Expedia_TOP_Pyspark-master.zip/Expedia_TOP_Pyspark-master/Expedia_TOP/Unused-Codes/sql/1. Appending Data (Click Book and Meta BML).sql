﻿/*-----------------------------------------------------------------------------------------------------------------------------*/
/*-------------------------------------------------------Click data Append-----------------------------------------------------*/
/*-----------------------------------------------------------------------------------------------------------------------------*/

copy new_ytd_feb14to23jun15 FROM '/data/HOTEL_CLICK_BOOK_AGG_20150624.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/6-30/HOTEL_CLICK_BOOK_AGG_20150628.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/7-1/HOTEL_CLICK_BOOK_AGG_20150629.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/7-2/HOTEL_CLICK_BOOK_AGG_20150630.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/7-6/HOTEL_CLICK_BOOK_AGG_20150701.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/7-6/HOTEL_CLICK_BOOK_AGG_20150702.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/7-6/HOTEL_CLICK_BOOK_AGG_20150703.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/7-6/HOTEL_CLICK_BOOK_AGG_20150704.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/7-7/HOTEL_CLICK_BOOK_AGG_20150705.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/4July_2_11July/HOTEL_CLICK_BOOK_AGG_20150706.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/4July_2_11July/HOTEL_CLICK_BOOK_AGG_20150707.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/4July_2_11July/HOTEL_CLICK_BOOK_AGG_20150708.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/4July_2_11July/HOTEL_CLICK_BOOK_AGG_20150709.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/4July_2_11July/HOTEL_CLICK_BOOK_AGG_20150710.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/4July_2_11July/HOTEL_CLICK_BOOK_AGG_20150711.tab' DELIMITER E'\t' CSV HEADER;
-------------------------------------------
copy new_ytd_feb14to23jun15 FROM '/data/07-14/HOTEL_CLICK_BOOK_AGG_20150712.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/07-15/HOTEL_CLICK_BOOK_AGG_20150713.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/07-16/HOTEL_CLICK_BOOK_AGG_20150714.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/07-17/HOTEL_CLICK_BOOK_AGG_20150715.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/07-18/HOTEL_CLICK_BOOK_AGG_20150716.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/07-19/HOTEL_CLICK_BOOK_AGG_20150717.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/07-20/HOTEL_CLICK_BOOK_AGG_20150718.tab' DELIMITER E'\t' CSV HEADER;

-----------------------------------------------------------
copy new_ytd_feb14to23jun15 FROM '/data/07-28/HOTEL_CLICK_BOOK_AGG_20150726.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/07-29/HOTEL_CLICK_BOOK_AGG_20150727.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/07-30/HOTEL_CLICK_BOOK_AGG_20150728.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/07-31/HOTEL_CLICK_BOOK_AGG_20150729.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-01/HOTEL_CLICK_BOOK_AGG_20150730.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-02/HOTEL_CLICK_BOOK_AGG_20150731.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-03/HOTEL_CLICK_BOOK_AGG_20150801.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/HOTEL_CLICK_BOOK_AGG_20150802.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/HOTEL_CLICK_BOOK_AGG_20150803.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/HOTEL_CLICK_BOOK_AGG_20150804.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-10/HOTEL_CLICK_BOOK_AGG_20150808.tab' DELIMITER E'\t' CSV HEADER;


DELETE FROM new_ytd_feb14to23jun15
  WHERE local_date in ('2015-09-17','2015-09-18','2015-09-19','2015-09-20')        

select distinct local_date from new_ytd_feb14to23jun15 order by 1

---------------------------------------------------------------------------------------------------------
copy new_ytd_feb14to23jun15 FROM '/data/08-12/HOTEL_CLICK_BOOK_AGG_20150731.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-12/HOTEL_CLICK_BOOK_AGG_20150801.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-12/HOTEL_CLICK_BOOK_AGG_20150802.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-12/HOTEL_CLICK_BOOK_AGG_20150803.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-12/HOTEL_CLICK_BOOK_AGG_20150804.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-12/HOTEL_CLICK_BOOK_AGG_20150805.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-12/HOTEL_CLICK_BOOK_AGG_20150806.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-12/HOTEL_CLICK_BOOK_AGG_20150807.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-12/HOTEL_CLICK_BOOK_AGG_20150808.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-12/HOTEL_CLICK_BOOK_AGG_20150809.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-12/HOTEL_CLICK_BOOK_AGG_20150810.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-15/HOTEL_CLICK_BOOK_AGG_20150811.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-15/HOTEL_CLICK_BOOK_AGG_20150812.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-15/HOTEL_CLICK_BOOK_AGG_20150813.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-16/HOTEL_CLICK_BOOK_AGG_20150814.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-17/HOTEL_CLICK_BOOK_AGG_20150815.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-20/HOTEL_CLICK_BOOK_AGG_20150818.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-21/HOTEL_CLICK_BOOK_AGG_20150819.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-22/HOTEL_CLICK_BOOK_AGG_20150820.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-23/HOTEL_CLICK_BOOK_AGG_20150821.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/08-24/HOTEL_CLICK_BOOK_AGG_20150822.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/09-01/HOTEL_CLICK_BOOK_AGG_20150823.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/09-01/HOTEL_CLICK_BOOK_AGG_20150824.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-01/HOTEL_CLICK_BOOK_AGG_20150825.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-01/HOTEL_CLICK_BOOK_AGG_20150826.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-01/HOTEL_CLICK_BOOK_AGG_20150827.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-01/HOTEL_CLICK_BOOK_AGG_20150828.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-01/HOTEL_CLICK_BOOK_AGG_20150829.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-01/HOTEL_CLICK_BOOK_AGG_20150830.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/09-02/HOTEL_CLICK_BOOK_AGG_20150831.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-09/HOTEL_CLICK_BOOK_AGG_20150901.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-09/HOTEL_CLICK_BOOK_AGG_20150902.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-09/HOTEL_CLICK_BOOK_AGG_20150903.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-09/HOTEL_CLICK_BOOK_AGG_20150904.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-09/HOTEL_CLICK_BOOK_AGG_20150905.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-09/HOTEL_CLICK_BOOK_AGG_20150906.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-09/HOTEL_CLICK_BOOK_AGG_20150907.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/09-11/HOTEL_CLICK_BOOK_AGG_20150907.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-11/HOTEL_CLICK_BOOK_AGG_20150908.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-11/HOTEL_CLICK_BOOK_AGG_20150909.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-11/HOTEL_CLICK_BOOK_AGG_20150910.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-11/HOTEL_CLICK_BOOK_AGG_20150911.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-11/HOTEL_CLICK_BOOK_AGG_20150912.tab' DELIMITER E'\t' CSV HEADER;
copy new_ytd_feb14to23jun15 FROM '/data/09-11/HOTEL_CLICK_BOOK_AGG_20150913.tab' DELIMITER E'\t' CSV HEADER;

copy new_ytd_feb14to23jun15 FROM '/data/10-05/HOTEL_CLICK_BOOK_AGG_20151004.tab' DELIMITER E'\t' CSV HEADER;



select max(local_date) from new_ytd_feb14to23jun15
-----------------------------Hotel Dim------------------------

create table hotel_dim_20150809 as select * from hotel_dim where 1=2

select * from hotel_dim_20150809

copy hotel_dim_20150809 FROM '/data/08-11/HOTEL_DIM_20150809.tab' DELIMITER E'\t' CSV HEADER;

---------------------------------------------------
create table dummy as select * from new_ytd_feb14to23jun15 where 1=2

copy dummy FROM '/data/09-28/HOTEL_CLICK_BOOK_AGG_20150927.tab' DELIMITER E'\t' CSV HEADER;

drop table dummy
/*-----------------------------------------------------------------------------------------------------------------------------*/
/*----------------------------------------------------Meta BML data Append-----------------------------------------------------*/
/*-----------------------------------------------------------------------------------------------------------------------------*/

create table meta23 as select * from new_meta_bml_0315_0623 where 1=2
ALTER TABLE meta23 DROP COLUMN "Activity_Date" RESTRICT;
copy meta23 FROM '/data/META_BML_20150624.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta23 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-06-24';

-----------------------------------------

create table meta27 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta27 DROP COLUMN activity_date RESTRICT;
copy meta27 FROM '/data/META_BML_20150627.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta27 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-06-27';

------------------------------------------
create table meta25 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta25 DROP COLUMN activity_date RESTRICT;
copy meta25 FROM '/data/6-30/META_BML_20150625.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta25 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-06-25';

-----------------------------------
create table meta26 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta26 DROP COLUMN activity_date RESTRICT;
copy meta26 FROM '/data/6-30/META_BML_20150626.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta26 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-06-26';

-----------------------------------------
create table meta28 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta28 DROP COLUMN activity_date RESTRICT;
copy meta28 FROM '/data/6-30/META_BML_20150628.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta28 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-06-28';

-----------------------------------------
create table meta29 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta29 DROP COLUMN activity_date RESTRICT;
copy meta29 FROM '/data/7-1/META_BML_20150629.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta29 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-06-29';

-----------------------------------------
create table meta30 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta30 DROP COLUMN activity_date RESTRICT;
copy meta30 FROM '/data/7-2/META_BML_20150630.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta30 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-06-30';

-----------------------------------------
create table meta0701 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0701 DROP COLUMN activity_date RESTRICT;
copy meta0701 FROM '/data/7-6/META_BML_20150701.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0701 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-01';

-----------------------------------------
create table meta0702 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0702 DROP COLUMN activity_date RESTRICT;
copy meta0702 FROM '/data/7-6/META_BML_20150702.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0702 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-02';

-----------------------------------------
create table meta0703 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0703 DROP COLUMN activity_date RESTRICT;
copy meta0703 FROM '/data/7-6/META_BML_20150703.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0703 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-03';

-----------------------------------------
create table meta0704 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0704 DROP COLUMN activity_date RESTRICT;
copy meta0704 FROM '/data/7-6/META_BML_20150704.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0704 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-04';

-----------------------------------------
create table meta0705 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0705 DROP COLUMN activity_date RESTRICT;
copy meta0705 FROM '/data/7-7/META_BML_20150705.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0705 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-05';

-----------------------------------------
create table meta0706 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0706 DROP COLUMN activity_date RESTRICT;
copy meta0706 FROM '/data/4July_2_11July/META_BML_20150706.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0706 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-06';

-----------------------------------------
create table meta0707 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0707 DROP COLUMN activity_date RESTRICT;
copy meta0707 FROM '/data/4July_2_11July/META_BML_20150707.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0707 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-07';

-----------------------------------------
create table meta0708 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0708 DROP COLUMN activity_date RESTRICT;
copy meta0708 FROM '/data/4July_2_11July/META_BML_20150708.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0708 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-08';

-----------------------------------------
create table meta0709 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0709 DROP COLUMN activity_date RESTRICT;
copy meta0709 FROM '/data/4July_2_11July/META_BML_20150709.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0709 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-09';

-----------------------------------------
create table meta0710 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0710 DROP COLUMN activity_date RESTRICT;
copy meta0710 FROM '/data/4July_2_11July/META_BML_20150710.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0710 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-10';

-----------------------------------------
create table meta0711 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0711 DROP COLUMN activity_date RESTRICT;
copy meta0711 FROM '/data/4July_2_11July/META_BML_20150711.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0711 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-11';

-----------------------------------------
create table meta0712 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0712 DROP COLUMN activity_date RESTRICT;
copy meta0712 FROM '/data/07-14/META_BML_20150712.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0712 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-12';

-----------------------------------------
create table meta0713 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0713 DROP COLUMN activity_date RESTRICT;
copy meta0713 FROM '/data/07-15/META_BML_20150713.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0713 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-13';

-----------------------------------------
create table meta0714 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0714 DROP COLUMN activity_date RESTRICT;
copy meta0714 FROM '/data/07-16/META_BML_20150714.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0714 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-14';

-----------------------------------------
create table meta0715 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0715 DROP COLUMN activity_date RESTRICT;
copy meta0715 FROM '/data/07-17/META_BML_20150715.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0715 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-15';

-----------------------------------------
create table meta0716 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0716 DROP COLUMN activity_date RESTRICT;
copy meta0716 FROM '/data/07-18/META_BML_20150716.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0716 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-16';

-----------------------------------------
create table meta0717 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0717 DROP COLUMN activity_date RESTRICT;
copy meta0717 FROM '/data/07-19/META_BML_20150717.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0717 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-17';

-----------------------------------------
create table meta0718 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0718 DROP COLUMN activity_date RESTRICT;
copy meta0718 FROM '/data/07-20/META_BML_20150718.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0718 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-18';

-----------------------------------------
create table meta0726 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0726 DROP COLUMN activity_date RESTRICT;
copy meta0726 FROM '/data/07-28/META_BML_20150726.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0726 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-26';

-----------------------------------------
create table meta0727 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0727 DROP COLUMN activity_date RESTRICT;
copy meta0727 FROM '/data/07-29/META_BML_20150727.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0727 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-27';

-----------------------------------------
create table meta0728 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0728 DROP COLUMN activity_date RESTRICT;
copy meta0728 FROM '/data/07-30/META_BML_20150728.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0728 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-28';

-----------------------------------------
create table meta0729 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0729 DROP COLUMN activity_date RESTRICT;
copy meta0729 FROM '/data/07-31/META_BML_20150729.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0729 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-29';

-----------------------------------------
create table meta0730 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0730 DROP COLUMN activity_date RESTRICT;
copy meta0730 FROM '/data/08-01/META_BML_20150730.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0730 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-30';

-----------------------------------------
create table meta0731 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0731 DROP COLUMN activity_date RESTRICT;
copy meta0731 FROM '/data/08-02/META_BML_20150731.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0731 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-07-31';

-----------------------------------------
create table meta0801 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0801 DROP COLUMN activity_date RESTRICT;
copy meta0801 FROM '/data/08-03/META_BML_20150801.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0801 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-01';

-----------------------------------------
create table meta0803 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0803 DROP COLUMN activity_date RESTRICT;
copy meta0803 FROM '/data/08-05/META_BML_20150803.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0803 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-03';

-----------------------------------------
create table meta0804 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0804 DROP COLUMN activity_date RESTRICT;
copy meta0804 FROM '/data/08-06/META_BML_20150804.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0804 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-04';

-----------------------------------------
create table meta0805 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0805 DROP COLUMN activity_date RESTRICT;
copy meta0805 FROM '/data/08-07/META_BML_20150805.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0805 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-05';

-----------------------------------------
create table meta0806 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0806 DROP COLUMN activity_date RESTRICT;
copy meta0806 FROM '/data/08-08/META_BML_20150806.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0806 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-06';

-----------------------------------------
create table meta0807 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0807 DROP COLUMN activity_date RESTRICT;
copy meta0807 FROM '/data/08-09/META_BML_20150807.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0807 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-07';

-----------------------------------------
create table meta0808 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0808 DROP COLUMN activity_date RESTRICT;
copy meta0808 FROM '/data/08-10/META_BML_20150808.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0808 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-08';

-----------------------------------------
create table meta0809 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0809 DROP COLUMN activity_date RESTRICT;
copy meta0809 FROM '/data/08-11/META_BML_20150809.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0809 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-09';

-----------------------------------------
create table meta0810 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0810 DROP COLUMN activity_date RESTRICT;
copy meta0810 FROM '/data/08-12/META_BML_20150810.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0810 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-10';

-----------------------------------------
create table meta0802 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0802 DROP COLUMN activity_date RESTRICT;
copy meta0802 FROM '/data/08-12/META_BML_20150802.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0802 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-02';

-----------------------------------------
create table meta0811 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0811 DROP COLUMN activity_date RESTRICT;
copy meta0811 FROM '/data/08-13/META_BML_20150811.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0811 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-11';

-----------------------------------------
create table meta0812 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0812 DROP COLUMN activity_date RESTRICT;
copy meta0812 FROM '/data/08-14/META_BML_20150812.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0812 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-12';

-----------------------------------------
create table meta0813 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0813 DROP COLUMN activity_date RESTRICT;
copy meta0813 FROM '/data/08-15/META_BML_20150813.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0813 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-13';

-----------------------------------------
create table meta0814 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0814 DROP COLUMN activity_date RESTRICT;
copy meta0814 FROM '/data/08-16/META_BML_20150814.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0814 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-14';

-----------------------------------------
create table meta0815 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0815 DROP COLUMN activity_date RESTRICT;
copy meta0815 FROM '/data/08-17/META_BML_20150815.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0815 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-15';

-----------------------------------------
create table meta0816 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0816 DROP COLUMN activity_date RESTRICT;
copy meta0816 FROM '/data/08-25/META_BML_20150816.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0816 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-16';

-----------------------------------------
create table meta0817 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0817 DROP COLUMN activity_date RESTRICT;
copy meta0817 FROM '/data/08-25/META_BML_20150817.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0817 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-17';

-----------------------------------------
create table meta0818 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0818 DROP COLUMN activity_date RESTRICT;
copy meta0818 FROM '/data/08-25/META_BML_20150818.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0818 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-18';

-----------------------------------------
create table meta0819 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0819 DROP COLUMN activity_date RESTRICT;
copy meta0819 FROM '/data/08-25/META_BML_20150819.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0819 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-19';

-----------------------------------------
create table meta0820 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0820 DROP COLUMN activity_date RESTRICT;
copy meta0820 FROM '/data/08-25/META_BML_20150820.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0820 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-20';

-----------------------------------------
create table meta0821 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0821 DROP COLUMN activity_date RESTRICT;
copy meta0821 FROM '/data/08-25/META_BML_20150821.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0821 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-21';

-----------------------------------------
create table meta0822 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0822 DROP COLUMN activity_date RESTRICT;
copy meta0822 FROM '/data/08-25/META_BML_20150822.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0822 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-22';
-----------------------------------------
create table meta0823 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0823 DROP COLUMN activity_date RESTRICT;
copy meta0823 FROM '/data/08-25/META_BML_20150823.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0823 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-23';

-----------------------------------------
create table meta0824 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0824 DROP COLUMN activity_date RESTRICT;
copy meta0824 FROM '/data/09-01/META_BML_20150824.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0824 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-24';

-----------------------------------------
create table meta0825 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0825 DROP COLUMN activity_date RESTRICT;
copy meta0825 FROM '/data/08-27/META_BML_20150825.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0825 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-25';

create table meta0826 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0826 DROP COLUMN activity_date RESTRICT;
copy meta0826 FROM '/data/08-28/META_BML_20150826.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0826 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-26';

create table meta0827 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0827 DROP COLUMN activity_date RESTRICT;
copy meta0827 FROM '/data/08-29/META_BML_20150827.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0827 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-27';

create table meta0828 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0828 DROP COLUMN activity_date RESTRICT;
copy meta0828 FROM '/data/08-30/META_BML_20150828.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0828 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-28';

create table meta0829 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0829 DROP COLUMN activity_date RESTRICT;
copy meta0829 FROM '/data/08-31/META_BML_20150829.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0829 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-29';

create table meta0830 as select * from new_meta_bml_0315_0623 where 1=2;
ALTER TABLE meta0830 DROP COLUMN activity_date RESTRICT;
copy meta0830 FROM '/data/09-01/META_BML_20150830.tab' DELIMITER E'\t' CSV HEADER;
ALTER TABLE meta0830 ADD COLUMN activity_date character varying(500) NOT NULL DEFAULT '2015-08-30';



/*---------------------------------------------------------------------------*/
/*----------Creating the meta BML table by appending the Day level data-------*/
/*---------------------------------------------------------------------------*/

--drop table meta_bml
select * into meta_bml from new_meta_bml
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta23
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta27
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta25
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta26
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta28
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta29
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta30
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0701
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0702
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0703
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0704
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0705
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0706
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0707
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0708
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0709
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0710
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0711
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0712
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0713
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0714
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0715
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0716
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0717
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0718
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0719
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0720
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0721
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0722
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0723
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0724
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0725
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0726
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0727
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0728
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0729
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0730
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0731
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0801
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0802
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0803
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0804
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0805
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0806
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0807
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0808
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0809
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0810
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0811
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0812
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0813
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0814
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0815
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0816
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0817
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0818
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0819
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0820
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0821
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0822
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0823
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0824
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0825
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0826
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0827
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0828
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0829
union all
select activity_date, point_of_sale, device_type, shop_datetime, run_id, shop_source_biz_unit, expedia_hotel_id, hotel_page, 
hotel_position, seller_rate_usd, seller, seller_rate_rank, seller_rank, meta_site, checkin_date, checkout_date, occupancy, 
booking_window, length_of_stay from meta0830

/*---------------------------------------------------------------------------*/
/*----------------------------Check for the Dates----------------------------*/
/*---------------------------------------------------------------------------*/

select distinct activity_date from meta_bml order by 1
select distinct local_date from new_ytd_feb14to23jun15 order by 1

select * from new_ytd_feb14to23jun15 limit 10

select local_date, sum(cast(xcost as float)) from new_ytd_feb14to23jun15 
where partner_pos='FR'
group by local_date
order by 1