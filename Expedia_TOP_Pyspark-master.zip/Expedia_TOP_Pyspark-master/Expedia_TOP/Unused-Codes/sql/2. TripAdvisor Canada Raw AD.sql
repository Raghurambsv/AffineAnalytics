﻿/*------------------------------------------------------------------------------------------------------------------------------*/
/*-----------------------------TripAdvisor Canada - Selecting required variables and creating buckets---------------------------*/
/*------------------------------------------------------------------------------------------------------------------------------*/


/*-------------------Creating LOS, BW Buckets and filtering out the Outliers-------------------------*/

--drop table temp
Create temporary table temp as 
(
select cast(local_date as date) activity_date
,partner_org
,partner_pos
,device_type
,clicked_hotel_id
,cast(srch_window as int) srch_booking_window
,cast(srch_los as int) srch_los
,cast(xclick as int) traffic
,cast(xcost as float) as cost
,booked_flag
,booked_hotel_id
,cast(booked_bkg_window as int) booked_booking_window
,cast(booked_los as int) booked_los
,cast(case 
when cast(srch_los as int) = 1 then '1'
when cast(srch_los as int) = 2 then '2'
when cast(srch_los as int) = 3 then '3'
when cast(srch_los as int) = 4 then '4'
when cast(srch_los as int) = 5 then '5'
when cast(srch_los as int) = 6 then '6'
when cast(srch_los as int) = 7 then '7'
when cast(srch_los as int) >=8 and cast(srch_los as int) <=14  then '8-14'
else '>14'
end  as varchar(50)) as srch_los_bucket
, cast(case when cast(srch_window as int) <= 0 then '<=0'
when cast(srch_window as int) = 1 then '1'
when cast(srch_window as int) = 2 then '2'
when cast(srch_window as int) >=3 and cast(srch_window as int) <=4  then '3-4'
when cast(srch_window as int) >=5 and cast(srch_window as int) <=7  then '5-7'
when cast(srch_window as int) >=8 and cast(srch_window as int) <=14  then '8-14'
when cast(srch_window as int) >=15 and cast(srch_window as int) <=20  then '15-20'
when cast(srch_window as int) >=21 and cast(srch_window as int) <=30  then '21-30'
when cast(srch_window as int) >=31 and cast(srch_window as int) <=40  then '31-40'
when cast(srch_window as int) >=41 and cast(srch_window as int) <=60  then '41-60'
when cast(srch_window as int) >=61 and cast(srch_window as int) <=90  then '61-90'
when cast(srch_window as int) >=91 and cast(srch_window as int) <=120  then '91-120'
when cast(srch_window as int) >=121 and cast(srch_window as int) <=180  then '121-180'
when cast(srch_window as int) >=181 and cast(srch_window as int) <=240  then '181-240'
else '>240'
end as varchar(50)) as srch_bw_bucket
,cast(case when cast(booked_los as int) = 1 then '1'
when cast(booked_los as int) = 2 then '2'
when cast(booked_los as int) = 3 then '3'
when cast(booked_los as int) = 4 then '4'
when cast(booked_los as int) = 5 then '5'
when cast(booked_los as int) = 6 then '6'
when cast(booked_los as int) = 7 then '7'
when cast(booked_los as int) >=8 and cast(booked_los as int) <=14  then '8-14'
else '>14'
end  as varchar(50)) as booked_los_bucket
,cast(case when cast(booked_bkg_window as int) <= 0 then '<=0'
when cast(booked_bkg_window as int) = 1 then '1'
when cast(booked_bkg_window as int) = 2 then '2'
when cast(booked_bkg_window as int) >=3 and cast(booked_bkg_window as int) <=4  then '3-4'
when cast(booked_bkg_window as int) >=5 and cast(booked_bkg_window as int) <=7  then '5-7'
when cast(booked_bkg_window as int) >=8 and cast(booked_bkg_window as int) <=14  then '8-14'
when cast(booked_bkg_window as int) >=15 and cast(booked_bkg_window as int) <=20  then '15-20'
when cast(booked_bkg_window as int) >=21 and cast(booked_bkg_window as int) <=30  then '21-30'
when cast(booked_bkg_window as int) >=31 and cast(booked_bkg_window as int) <=40  then '31-40'
when cast(booked_bkg_window as int) >=41 and cast(booked_bkg_window as int) <=60  then '41-60'
when cast(booked_bkg_window as int) >=61 and cast(booked_bkg_window as int) <=90  then '61-90'
when cast(booked_bkg_window as int) >=91 and cast(booked_bkg_window as int) <=120  then '91-120'
when cast(booked_bkg_window as int) >=121 and cast(booked_bkg_window as int) <=180  then '121-180'
when cast(booked_bkg_window as int) >=181 and cast(booked_bkg_window as int) <=240  then '181-240'
else '>240'
end as varchar(50)) as booked_bw_bucket
,cast(lt_true_up_gp_usd as float) as gross_profit
,cast(lt_true_up_gbv_usd as float) as  gross_booking_value
,cast(lt_true_up_net_rev_usd as float) as  net_revenue
from new_ytd_feb14to23jun15
where cast(xclick as int) <> 0
and cast(clicked_hotel_id as int) <> 0
and partner_pos='CA'
);

/*---------------Replacing the rows with negative Booking Window and LOS search parameters with the Booking Parameters-------------*/

---drop table temp1
Create temporary table temp1 as
(
select activity_date
,partner_org
,partner_pos
,device_type
,booked_hotel_id as hotel_id
,Booked_Booking_window as booking_window
,Booked_BW_bucket as bw_bucket
,Booked_LOS as los
,Booked_LOS_Bucket as los_bucket
,traffic
,cost
,1 as booking
,booked_flag
,gross_profit
,gross_booking_value
,net_revenue
from temp
where booked_flag='Y' and 
(srch_Booking_window<-1
or srch_los <= 0)
);

/*-------------------------------------Selecting all the non convereted rows---------------------------------*/

---drop table temp2
Create temporary table temp2
as
(
select activity_date
,partner_org
,partner_pos
,device_type
,clicked_hotel_id as hotel_id
,srch_booking_window as booking_window
,srch_bw_bucket as bw_bucket
,srch_LOS as los
,Srch_LOS_Bucket as los_bukcet
,traffic
,cost
,0 as booking
,booked_flag 
,gross_profit
,gross_booking_value
,Net_revenue
from temp
where 
booked_flag ='N'
and srch_booking_window >=-1
and srch_los > 0
and cast(gross_profit as float)=0.0
and cast(gross_booking_value as float)=0.0
);

/*----------------------------------Selecting all converted rows-------------------------------------*/

---drop table temp3
Create temporary table temp3
as
(select activity_date
,partner_org
,partner_pos
,device_type
,clicked_hotel_id as hotel_id
,Srch_Booking_window as booking_window
,Srch_BW_bucket as bw_bucket
,srch_LOS as los
,Srch_LOS_Bucket as los_bucket
,traffic
,cost
,1 as booking
,booked_flag 
,gross_profit
,gross_booking_value
,net_revenue
from temp 
where booked_flag ='Y'
and Srch_Booking_window>=-1
and srch_los > 0
);

/*-----------------------unionall - Union of all the above 3 tables temp1, temp2, temp3------------------------ */

Create temporary table unionall as 
(select *  from temp1 
union all select * from temp2
union all select * from temp3
);

/*------------------Creating required columns and merging with hotel dim table to get hotel attributes--------------*/

Create temporary table ad_canada
as
(
Select a.*
,city
,region
,b.market
,booking_window+activity_date as checkin_date
--,datepart(dw,Activity_Date) as activity_day
--,datename(dw,dateadd(dd,Booking_window,Activity_Date)) as checkin_day
,extract(Week from activity_date) as activity_week
,extract(WEEK from activity_date+booking_window) as checkin_week
,extract(Month from activity_date)  as activity_month
,extract(Month from activity_date+booking_window) as checkin_month
,extract(Year from activity_date) as activity_year
,extract(Year from activity_date+booking_window) as checkin_year
-- ,case when datename(dw,Activity_Date)='Saturday' then 1
-- when datename(dw,Activity_Date)='Sunday' then 1
-- else 0 end as activity_weekend_flag
-- ,case when datename(dw,dateadd(dd,Booking_window,Activity_Date))='Saturday' then 1
-- when datename(dw,dateadd(dd,Booking_window,Activity_Date))='Sunday' then 1
-- when datename(dw,dateadd(dd,Booking_window,Activity_Date))='Friday' then 1
-- else 0 end as checkin_weekend_flag
,b.star_rating
,b.brand
,b.trvlr_recmnd_cnt
,b.hotel_type
from 
unionall a 
left join hotel_dim b on a.Hotel_ID=b.hotel_id
where b.hotel_id is not null 
);

/*-----------------------------------------------------------------------------------------------------*/
/*----------creating region/city/market, hotel-type, star rating bucket for individual Models----------*/
/*-----------------------------------------------------------------------------------------------------*/

/*---------------------Creating buckets for Model_name - Canada-----------------------------------*/
--drop table canada
Create temporary table canada
as
(
select *
,case when city= 'TORONTO' then 'TORONTO'
when city='NIAGARA FALLS' then 'NIAGARA FALLS'
when city='MONTREAL' then 'MONTREAL'
when city='VANCOUVER' then 'VANCOUVER'
when city='QUEBEC' then 'QUEBEC'
when city='BANFF' then 'BANFF'
when city='OTTAWA' then 'OTTAWA'
when city='EDMONTON' then 'EDMONTON'
when city='VICTORIA' then 'VICTORIA'
when city='CALGARY' then 'CALGARY'
when city='WHISTLER' then 'WHISTLER'
when city in ('NIAGARA-ON-THE-LAKE','CANMORE','JASPER','KELOWNA','HALIFAX','MISSISSAUGA','LAKE LOUISE','COLLINGWOOD','VERNON','PENTICTON','GATINEAU','DORVAL','MARKHAM') then 'G12'
when city in ('MONT-TREMBLANT','TOFINO','BLUE MOUNTAINS','OSOYOOS','UCLUELET','SAINT-SAUVEUR','WEST KELOWNA','LA MALBAIE','SAINTE-ADELE') then 'G13'
when city in ('WINNIPEG','LONDON','RICHMOND','BARRIE','REVELSTOKE','VAUGHAN','ORILLIA','BURNABY','SURREY') then 'G14'
else 'Others'
end as city_bucket
,case when star_rating in ('1.0','1.5') then '1-1.5'
when star_rating in('4.5','5.0') then '4.5-5'
when star_rating = '2.0' then '2'
when star_rating = '2.5' then '2.5'
when star_rating = '3.0' then '3'
when star_rating = '3.5' then '3.5'
when star_rating = '4.0' then '4'
else '0'
end as star_rating_bucket
,case when Hotel_type='HOTEL' then 'HOTEL'
when Hotel_type='HOTEL RESORT' then 'HOTEL_RESORT'
when Hotel_type='MOTEL' then 'MOTEL'
when hotel_type in('CONDOMINIUM RESORT','CONDO') then 'CONDO'
when hotel_type in ('LODGE','BED & BREAKFAST','HOSTEL/BACKPACKER ACCOMMODATION','CABIN','GUEST HOUSE') then 'Budget_hotel'
when hotel_type in('APART-HOTEL','INN') then 'Family_Premium'
else 'Others'
end as hotel_type_bucket
,case when market='TORONTO, ON, CAN' then 'TORONTO, ON, CAN'
when market='NIAGARA FALLS, ON, CAN' then 'NIAGARA FALLS, ON, CAN'
when market='MONTREAL, QC, CAN' then 'MONTREAL, QC, CAN'
when market='BANFF AREA, AB, CAN' then 'BANFF AREA, AB, CAN'
when market='VANCOUVER, BC, CAN' then 'VANCOUVER, BC, CAN'
when market='QUEBEC CITY, QC, CAN' then 'QUEBEC CITY, QC, CAN'
when market='EDMONTON, AB, CAN' then 'EDMONTON, AB, CAN'
when market='OTTAWA, ON, CAN' then 'OTTAWA, ON, CAN'
when market='OKANAGAN VALLEY, BC, CAN' then 'OKANAGAN VALLEY, BC, CAN'
when market in ('VICTORIA, BC, CAN','CALGARY, AB, CAN','JASPER AREA, AB, CAN') then 'G10'
when market in ('WHISTLER, BC, CAN','NIAGARA-ON-THE-LAKE, ON, CAN','MONT TREMBLANT, QC, CAN','TOFINO - UCLUELET, BC, CAN') then 'G11'
when market in ('COLLINGWOOD, ON, CAN','BC INTERIOR SKI, BC, CAN','HALIFAX, NS, CAN','WINNIPEG, MB, CAN','LONDON, ON, CAN','KAMLOOPS, BC, CAN') then 'G12'
else 'Others' end as market_bucket
,cast('NA' as varchar(250)) as region_bucket
,cast('Canada' as varchar(250)) as model_name
from ad_canada
where region ='CANADA'
);

/*---------------------Creating buckets for Model_name - US-----------------------------------*/

--drop table us
Create temporary table us
as
(
select *
,cast('NA' as varchar(250)) as city_bucket
,case when star_rating in ('1.0','1.5') then '1-1.5'
when star_rating in('4.5','5.0') then '4.5-5'
when star_rating = '2.0' then '2'
when star_rating = '2.5' then '2.5'
when star_rating = '3.0' then '3'
when star_rating = '3.5' then '3.5'
when star_rating = '4.0' then '4'
else '0'
end as star_rating_bucket
,case when Hotel_type='HOTEL' then 'HOTEL'
when Hotel_type='HOTEL RESORT' then 'HOTEL_RESORT'
when Hotel_type='MOTEL' then 'MOTEL'
when hotel_type in('CONDOMINIUM RESORT','CONDO') then 'CONDO'
when hotel_type in ('LODGE','BED & BREAKFAST','HOSTEL/BACKPACKER ACCOMMODATION','COTTAGE','CABIN','GUEST HOUSE') then 'Budget_hotel'
when hotel_type in('APART-HOTEL','APARTMENT','VILLA','PRIVATE VACATION HOME','INN') then 'Family_Premium'
else 'Others'
end as hotel_type_bucket
,cast('NA' as varchar(250)) as market_bucket
,cast('NA' as varchar(250)) as region_bucket
,cast('US' as varchar(250)) as model_name
from ad_canada
where region in ('FLORIDA (USA)','NEW YORK CITY','CALIFORNIA','GAMING (USA)','NORTHEAST (USA)','MOUNTAIN (USA)'
,'MIDWEST (USA)','CENTRAL (USA)','SF PACNW','ORLANDO','HAWAII')
);


/*-----------------------------Creating buckets for Model_name - Mexico-----------------------------------*/

--drop table mexico
Create temporary table mexico
as
(
select *
,cast('NA' as varchar(250)) as city_bucket
,case when star_rating in ('1.0','1.5') then '1-1.5'
when star_rating in('4.5','5.0') then '4.5-5'
when star_rating = '2.0' then '2'
when star_rating = '2.5' then '2.5'
when star_rating = '3.0' then '3'
when star_rating = '3.5' then '3.5'
when star_rating = '4.0' then '4'
else '0'
end as star_rating_bucket
,case when Hotel_type='HOTEL' then 'HOTEL'
when Hotel_type='HOTEL RESORT' then 'HOTEL_RESORT'
when Hotel_type='ALL-INCLUSIVE' then 'ALL-INCLUSIVE'
when hotel_type in('CONDOMINIUM RESORT','CONDO') then 'CONDO'
when hotel_type in ('BED & BREAKFAST','LODGE','HOSTEL/BACKPACKER ACCOMMODATION') then 'Budget_hotel'
when hotel_type in('APART-HOTEL','INN','VILLA','APARTMENT') then 'Family_Premium'
else 'Others'
end as hotel_type_bucket
,case when market='MEXICO - RIVIERA MAYA, PLAYA DEL CARMEN & TULUM' then 'MEXICO - RIVIERA MAYA, PLAYA DEL CARMEN & TULUM'
when market='MEXICO - CANCUN & ISLA MUJERES' then 'MEXICO - CANCUN & ISLA MUJERES'
when market='MEXICO - PUERTO VALLARTA, NUEVO VALLARTA & RIVIERA NAYARIT' then 'MEXICO - PUERTO VALLARTA, NUEVO VALLARTA & RIVIERA NAYARIT'
when market='MEXICO - LOS CABOS' then 'MEXICO - LOS CABOS'
when market='CENTRAL AMERICA - COSTA RICA - GUANACASTE' then 'CENTRAL AMERICA - COSTA RICA - GUANACASTE'
when market='CENTRAL AMERICA - BELIZE' then 'CENTRAL AMERICA - BELIZE'
when market='CENTRAL AMERICA - COSTA RICA - PUNTARENAS' then 'CENTRAL AMERICA - COSTA RICA - PUNTARENAS'
when market='CENTRAL AMERICA - COSTA RICA - OTHER' then 'CENTRAL AMERICA - COSTA RICA - OTHER'
when market='MEXICO - COZUMEL' then 'MEXICO - COZUMEL'
when market='MEXICO - HUATULCO' then 'MEXICO - HUATULCO'
when market='MEXICO - IXTAPA & ZIHUATANEJO' then 'MEXICO - IXTAPA & ZIHUATANEJO'
when market='CENTRAL AMERICA - HONDURAS' then 'CENTRAL AMERICA - HONDURAS'
when market='CENTRAL AMERICA - PANAMA - OTHER' then 'CENTRAL AMERICA - PANAMA - OTHER'
when market in('CENTRAL AMERICA - COSTA RICA - SAN JOSE'
,'CENTRAL AMERICA - PANAMA - PANAMA CITY'
,'MEXICO - MEXICO CITY'
,'MEXICO - MERIDA & YUCATAN STATE') then 'hclt'
when market in ('CENTRAL AMERICA - NICARAGUA'
,'MEXICO - MAZATLAN'
,'MEXICO - MANZANILLO'
,'CENTRAL AMERICA - EL SALVADOR'
,'MEXICO - ACAPULCO') then 'lclt'
else 'Low_traffic'
end as market_bucket
,cast('NA' as varchar(250)) as region_bucket
,cast('Mexico' as varchar(250)) as model_name
from ad_canada
where region= 'MEXICO & CENTRAL AMERICA'
);

/*--------------------------------Creating buckets for Model_name - Caribbean-----------------------------------*/

--drop table caribbean
Create temporary table caribbean 
as
(
select *
,cast('NA' as varchar(250)) as city_bucket
,case when star_rating in ('1.0','1.5') then '1-1.5'
when star_rating in('4.5','5.0') then '4.5-5'
when star_rating = '2.0' then '2'
when star_rating = '2.5' then '2.5'
when star_rating = '3.0' then '3'
when star_rating = '3.5' then '3.5'
when star_rating = '4.0' then '4'
else '0'
end as star_rating_bucket
,case when Hotel_type='ALL-INCLUSIVE' then 'ALL-INCLUSIVE'
when Hotel_type='HOTEL' then 'HOTEL'
when Hotel_type='HOTEL RESORT' then 'HOTEL_RESORT'
when hotel_type in('CONDOMINIUM RESORT','CONDO') then 'CONDO'
when hotel_type in('APART-HOTEL','APARTMENT','VILLA','INN') then 'Family_Premium'
else 'Others'
end as hotel_type_bucket
,case when market='PUNTA CANA, DOMINICAN REPUBLIC' then 'PUNTA CANA, DOMINICAN REPUBLIC'
when market='TURKS AND CAICOS' then 'TURKS AND CAICOS'
when market='MONTEGO BAY, JAMAICA' then 'MONTEGO BAY, JAMAICA'
when market='ST. LUCIA' then 'ST. LUCIA'
when market='OCHO RIOS, JAMAICA' then 'OCHO RIOS, JAMAICA'
when market='NEGRIL, JAMAICA' then 'NEGRIL, JAMAICA'
when market='BARBADOS' then 'BARBADOS'
when market in ('ARUBA','PUERTO PLATA, DOMINICAN REPUBLIC','ANTIGUA AND BARBUDA') then 'G8'
when market in ('NASSAU, BAHAMAS','DOMINICAN REPUBLIC ALL OTHER','BERMUDA','BAHAMAS, OUT ISLANDS') then 'G9'
when market in ('SAN JUAN, PUERTO RICO','PARADISE ISLAND, BAHAMAS','CAYMAN ISLANDS','SINT MAARTEN, DUTCH','CURACAO','ST. MARTIN, FRENCH') then 'G10'
else 'Others' end as market_bucket
,cast('NA' as varchar(250)) as region_bucket
,cast('CARIBBEAN' as varchar(250)) as model_name
from ad_canada
where region ='CARIBBEAN'
);

/*-------------------------------------Creating buckets for Model_name - Other Region-----------------------------------*/

--drop table other_region
Create temporary table other_region
as
(
select *
,cast('NA' as varchar(250)) as city_bucket
,case when star_rating in ('1.0','1.5') then '1-1.5'
when star_rating in('4.5','5.0') then '4.5-5'
when star_rating = '2.0' then '2'
when star_rating = '2.5' then '2.5'
when star_rating = '3.0' then '3'
when star_rating = '3.5' then '3.5'
when star_rating = '4.0' then '4'
else '0'
end as star_rating_bucket
,case when Hotel_type='HOTEL' then 'HOTEL'
when Hotel_type='HOTEL RESORT' then 'HOTEL_RESORT'
when Hotel_type='APART-HOTEL' then 'APART_HOTEL'
when hotel_type in ('GUEST HOUSE','BED & BREAKFAST','MOTEL','HOSTEL/BACKPACKER ACCOMMODATION','HOSTAL (BUDGET HOTEL)') then 'Budget_hotel'
when hotel_type in('APARTMENT','RESIDENCE','TOWNHOUSE','INN') then 'Family_Premium'
else 'Others'
end as hotel_type_bucket
,cast('NA' as varchar(250)) as market_bucket
,case when region = 'SPAIN & PORTUGAL' then 'SPAIN & PORTUGAL'
when region ='ROME & ITALY RESORTS' then 'ROME & ITALY RESORTS'
when region ='MID-ATLANTIC' then 'MID-ATLANTIC'
when region ='GREECE & TURKEY' then 'GREECE & TURKEY'
when region ='OCEANIA' then 'OCEANIA'
when region ='ITALY NORTH' then 'ITALY NORTH'
when region ='THAILAND' then 'THAILAND'
when region ='MIDDLE EAST AND INDIAN OCEAN' then 'MIDDLE EAST AND INDIAN OCEAN'
when region in ('PARIS','LONDON, ENGLAND') then 'G9'
when region in ('EUROPE REGIONAL TERRITORIES','UK & IRELAND') then 'G10'
when region in ('SOUTH AMERICA','AFRICA AND EAST MED') then 'G11'
when region in ('EASTERN EUROPE','GERMANY, AUSTRIA & SWITZERLAND','BENELUX','FRANCE','NORDIC') then 'G12'
when region in ('JAPAN & MICRONESIA','HONG KONG & MACAU','SOUTHEAST ASIA EMERGING','MAINLAND CHINA') then 'G13'
else 'Others'
end as region_bucket
,cast('Other Region' as varchar(250)) as model_name
from ad_canada
where region in('SPAIN & PORTUGAL','ROME & ITALY RESORTS','MID-ATLANTIC','GREECE & TURKEY','PARIS'
,'OCEANIA','ITALY NORTH','LONDON, ENGLAND','THAILAND'
,'MIDDLE EAST AND INDIAN OCEAN','EUROPE REGIONAL TERRITORIES','UK & IRELAND','AFRICA AND EAST MED','EASTERN EUROPE'
,'GERMANY, AUSTRIA & SWITZERLAND','JAPAN & MICRONESIA','PHILIPPINES','BENELUX'
,'FRANCE','INDONESIA','INDIAN SUBCONTINENT','HONG KONG & MACAU','SOUTHEAST ASIA EMERGING'
,'NORDIC','MAINLAND CHINA','SOUTH KOREA','SINGAPORE (REGION)','MALAYSIA','TAIWAN','UNKNOWN','SOUTH AMERICA')
);


/*---------------------------------Creating buckets for Model_name - North America-----------------------------------*/

--drop table north_america
Create temporary table north_america
as
(
select *
,cast('NA' as varchar(250)) as city_bucket
,case when star_rating in ('1.0','1.5') then '1-1.5'
when star_rating in('4.5','5.0') then '4.5-5'
when star_rating = '2.0' then '2'
when star_rating = '2.5' then '2.5'
when star_rating = '3.0' then '3'
when star_rating = '3.5' then '3.5'
when star_rating = '4.0' then '4'
else '0'
end as star_rating_bucket
,case when Hotel_type='HOTEL' then 'HOTEL'
when Hotel_type='MOTEL' then 'MOTEL'
when hotel_type in ('BED & BREAKFAST','LODGE','COTTAGE','GUEST HOUSE','CABIN') then 'Budget_hotel'
when hotel_type in('HOTEL RESORT','INN','CONDO','APART-HOTEL','APARTMENT','CARAVAN PARK') then 'Family_Premium'
else 'Others'
end as hotel_type_bucket
,case
when market in ('GRAVENHURST - BRACEBRIDGE - HUNTSVILLE, ON, CAN','ONTARIO WEST, ON, CAN','ABBOTSFORD - CHILLIWACK, BC, CAN','MAINE - COAST','ONTARIO EAST, ON, CAN','VANCOUVER ISLAND, BC, CAN','BURLINGTON, VT','CHARLOTTETOWN, PEI, CAN') then 'G1'
when market in ('ALBERTA EAST, AB, CAN','REGINA, SK, CAN','KINGSTON, ON, CAN','SASKATOON, SK, CAN','MONCTON, NB, CAN','TRI-CITIES (KW-GUELPH-CAMBRIDGE), ON, CAN') then 'G2'
when market in ('WINDSOR, ON, CAN','RED DEER, AB, CAN','BRITISH COLUMBIA SOUTH, BC, CAN','GRAND FORKS, ND','SUDBURY, ON, CAN','ONTARIO NORTH, ON, CAN','BANGOR, ME','HAMILTON - BRANTFORD, ON, CAN','BELLEVILLE - TRENTON - COBOURG, ON, CAN','FARGO, ND') then 'G3'
when market in ('LAKE PLACID, NY','PARKSVILLE, VANCOUVER ISLAND, BC, CAN','LAKE GEORGE, NY','OGUNQUIT, ME','EVERETT, WA','COASTAL, BC, CAN','GROVE CITY, PA','BELLINGHAM, WA','NORTH CONWAY, NH','NEWFOUNDLAND OTHER, NL, CAN','NOVA SCOTIA SOUTH, NS, CAN','PORTSMOUTH, NH') then 'G4'
when market in ('LETHBRIDGE, AB, CAN','FREDERICTON, NB, CAN','BRANDON, MB, CAN','ERIE, PA','NANAIMO, VANCOUVER ISLAND, BC, CAN','SASKATCHEWAN SOUTH, SK, CAN','PRINCE GEORGE - QUESNEL, BC, CAN','MEDICINE HAT, AB, CAN','GRANDE PRAIRIE, AB, CAN','ALBERTA NORTH, AB, CAN','DURHAM, ON, CAN','BRITISH COLUMBIA CENTRAL, BC, CAN','ONTARIO SOUTHWEST, ON, CAN','SAULT STE. MARIE, ON, CAN','THUNDER BAY, ON, CAN','SAINT JOHN, NB, CAN','GREAT FALLS, MT','MINOT, ND (AREA)','BRITISH COLUMBIA NORTH, BC, CAN','NORTH BAY, ON, CAN','PETERBOROUGH, ON, CAN','CAPE BRETON ISLAND, NS, CAN','ALBERTA WEST, AB, CAN','HUDSON VALLEY - POUGHKEEPSIE, NY','FORT MCMURRAY, AB, CAN','NOVA SCOTIA NORTH, NS, CAN','WATERTOWN, NY','EDMUNSTON, NB, CAN','OLYMPIC NATIONAL PARK AREA, WA','CEDAR CITY - BRYCE CANYON NATIONAL PARK, UT','SUMMERSIDE, PEI, CAN','SALEM, OR (AREA)','BUTTE - HELENA, MT','BECKLEY, WV') then 'G5'
when market in ('SAGINAW, MI','WHITE MOUNTAINS, NH','FINGER LAKES NEW YORK','NEW YORK - WEST','NEW BRUNSWICK NORTH, NB, CAN','SASKATCHEWAN NORTH, SK, CAN','MANITOBA SOUTH, MB, CAN','BAR HARBOR, ME','WASHINGTON NORTHWEST','VERMONT CENTRAL','ALBERTA SOUTH, AB, CAN','WENATCHEE-LEAVENWORTH,WA','GANANOQUE, ON, CAN','PLATTSBURGH, (NY)','STRAITS OF MACKINAC, MI','SANDUSKY, OH','MANCHESTER, NH','ITHACA, NY','MINNESOTA NORTHWEST','MISSOULA, MT (AREA)','YELLOWKNIFE, NT, CAN','PEI OTHER, PEI, CAN','BILLINGS, MT (AREA)','RAPID CITY - MOUNT RUSHMORE, SD','ANDOVER, MA','YUMA, AZ','PORT HURON, MI','LANCASTER, PA','FORT LEE - PARAMUS, NJ','LEXINGTON, KY','MANITOBA NORTH, MB, CAN','ABERDEEN - OCEAN SHORES, WA','CANADA TERRITORIES, YT, CAN','KNOXVILLE, TN','BURLINGTON - MOUNT VERNON, WA','FREDERICKSBURG, VA','ARIZONA SOUTHEAST','WINDHAM COUNTY, VT','KENAI PENINSULA, AK','COLUMBIA, SC','CALIFORNIA DESERTS SOUTH') then 'G6'
when market in ('ROME-UTICA, NY','SANDPOINT, ID (AREA)','MOAB - GREEN RIVER, UT','WHITEHORSE, YT, CAN','NEW YORK - NORTHEAST','SARNIA, ON, CAN','AUGUSTA, ME','LAKE POWELL - GLEN CANYON NATIONAL PARK, AZ','NEW YORK - SOUTH','BISMARK, ND','ALABAMA NORTH','ASHLAND - MEDFORD, OR','WASHINGTON NORTHEAST','THE BERKSHIRES, MA','EUGENE, OR (AREA)','GRAND RAPIDS, MI','WASHINGTON SOUTHWEST','LAKE HAVASU CITY, AZ','SARATOGA, NY','WYTHEVILLE - VA','ARCATA - EUREKA, CA','SOUTH CAROLINA EAST','CHATTANOOGA, TN','TOLEDO, OH','IDAHO FALLS, ID','WEST VIRGINIA SOUTH','SPRINGFIELD, MA','OLYMPIA, WA','GETTYSBURG - PA') then 'G7'
else 'Others' end as market_bucket
,cast('NA' as varchar(250)) as region_bucket
,cast('North America' as varchar(250)) as model_name
from ad_canada
where region='NORTH AMERICA REGIONAL TERRITORIES'
);


/*---------------------------------Creating Final Table by combining all the above regions - Trip Advisor Canada-----------------------------------*/

--drop table canada_raw_ad
Create table canada_raw_ad
as
(
select * 
from canada
union all select * from us
union all select * from mexico
union all select * from caribbean
union all select * from other_region
union all select * from north_america
);

