﻿/*------------------------------------------------------------------------------------------------------------------------------------------------*/
/*--------------------------------------------Creating ADs for Optimization - Tripadvisor CA----------------------------------*/
/*-------------------------------------------------------------------------------------------------------------------------------------------------*/

/*-----------------------------Drop All the tables before recreating---------------------------------*/
drop table ta_canada_lookup_desktop;
drop table ta_other_region_lookup_desktop;
drop table ta_north_america_lookup_desktop;
drop table ta_caribbean_lookup_desktop;
drop table ta_mexico_lookup_desktop;
drop table ta_us_lookup_desktop;

/*--------------Create a Temporary Table for the required model and required dates----------------*/
/*---------------Note:- Change the model name and dates below as per requirement-------------------*/

--drop table model
Create temporary table model
as
(
Select cast('Other Region' as varchar(50)) as model_name
);

--drop table date1
create temporary table date1
as
(
Select cast('2015-09-26' as date) as date1
);


/*-------------------------Create universe by considering the distinct hotels appeared in last 4 weeks data and populate seller Rank----------------*/
--drop table look_up1
set statement_timeout to 1999999999;
create temporary table look_up1
as
(
Select distinct c.* 
 ,coalesce(R0.seller_Rank,R1.seller_Rank,R2.seller_Rank,R3.seller_Rank,R4.seller_Rank,R5.seller_Rank,R6.seller_Rank,R7.seller_Rank,W2.seller_Rank
 ,W3.seller_Rank,W4.seller_Rank) as seller_rank
from 
( Select * from 
	(Select distinct hotel_id,region,region_bucket,
	market_bucket,market,model_name,
	city_bucket,city,hotel_type,hotel_type_bucket,star_Rating,star_rating_bucket
	from canada_raw_ad
	where Model_Name in (Select model_name from model) and device_type='DESKTOP'
	activity_date<=(Select date1 from date1) and activity_date>(Select date1-28 from date1)) c
	cross join
	(Select distinct BW_Bucket from canada_raw_ad)b
	cross join 
	(Select distinct LOS_Bucket from canada_raw_ad) a
) C
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE)in (select date1 from date1)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R0
on C.Hotel_ID=R0.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE) in (select date1-1 from date1)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R1
on C.Hotel_ID=R1.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE) in (select date1-2 from date1)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R2
on C.Hotel_ID=R2.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE) in (select date1-3 from date1)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R3
on C.Hotel_ID=R3.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE) in (select date1-4 from date1)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R4
on C.Hotel_ID=R4.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE) in (select date1-5 from date1)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R5
on C.Hotel_ID=R5.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE) in (select date1-6 from date1)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R6
on C.Hotel_ID=R6.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				 from META_BML 
				where CAST(Activity_Date as DATE) in (select date1-7 from date1)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) R7
on C.Hotel_ID=R7.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				from META_BML 
				where CAST(Activity_Date as DATE) >= (select date1-14 from date1) and 
				cast(activity_date as date)<= (select date1-8 from date1)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) W2
on C.Hotel_ID=W2.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				from META_BML 
				where CAST(Activity_Date as DATE) >= (select date1-21 from date1) and 
				cast(activity_date as date)<= (select date1-15 from date1)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) W3
on C.Hotel_ID=W3.Expedia_Hotel_ID
left join 
(
	Select expedia_hotel_id,seller_rank
	from
	(
	   Select *, rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by seller_rank asc) as Higher_Rank_Tie
		from 
			(
			Select * ,rank() over(Partition by meta_site,point_of_sale,expedia_hotel_id Order by Frequency desc) as Max_Freq
			 from 
				(
				Select meta_site,point_of_sale,expedia_hotel_id,cast(seller_rank as int) as seller_rank, COUNT(*) as Frequency
				from META_BML 
				where cast(activity_date as date)<= (select date1-22 from date1)
				and meta_site='TRIPADVISOR' and point_of_sale='CA' and seller='EXPEDIA'
				group by meta_site,point_of_sale,expedia_hotel_id,seller_rank
				) a
			) b
		where Max_Freq=1
	) c
	where Higher_Rank_Tie=1
) W4
on C.Hotel_ID=W4.Expedia_Hotel_ID
);


/*----------------------Getting the missing Seller rank------------------------*/

--drop table look_up
set statement_timeout to 1999999999;
Create temporary table look_up
as
(
Select L.hotel_id,region,region_bucket,
	market_bucket,market,model_name,
	city_bucket,city,hotel_type,hotel_type_bucket,star_rating,star_rating_bucket,L.los_bucket,
	L.bw_bucket
	,case when L.seller_rank is null then e.seller_rank else L.seller_rank end as seller_rank 
	,e.seller_rank_bucket
 from look_up1 L
join 
(
Select hotel_id,seller_rank_1 as seller_rank
,case when seller_rank_1>=5 then '>=5' else cast(seller_rank_1 as varchar(50)) end as seller_rank_bucket
from 
(
	Select distinct L.hotel_id, a.Traffic,a.cost,(a.cost)*1.0/a.Traffic as cpc,c.final_bid_value_cpc,
	case when L.seller_rank is Null then
		(case when (a.Cost*1.0/a.Traffic)>1.2*cast((c.final_bid_value_cpc) as numeric) then 1
		 when (a.Cost*1.0/a.Traffic)>0.7*cast((c.final_bid_value_cpc) as numeric) and (a.Cost*1.0/a.Traffic)<=1.2*cast((c.final_bid_value_cpc) as numeric) then 2
		 when (a.Cost*1.0/a.Traffic)>0.4*cast((c.final_bid_value_cpc) as numeric) and (a.Cost*1.0/a.Traffic)<=0.7*cast((c.final_bid_value_cpc) as numeric) then 3
		 when (a.Cost*1.0/a.Traffic)>0.2*cast((c.final_bid_value_cpc) as numeric) and (a.Cost*1.0/a.Traffic)<=0.4*cast((c.final_bid_value_cpc) as numeric) then 4
		 else 5 end) else L.seller_rank end as seller_rank_1
	from look_up1 L
	join
		(Select hotel_id
		,sum(Traffic) Traffic,sum(Booking) Booking ,sum(Cost) as  Cost ,sum(Gross_Profit) Gross_Profit
		from canada_raw_ad 
		where Model_Name in (Select model_name from model) and device_type='DESKTOP'
		group by hotel_id
		) a 
	on L.Hotel_ID=a.Hotel_ID
	left join 
		(Select * from new_cpc_values_may25
		where partner_org='TRIPADVISOR' and pos='CA' and placement_name='HOTEL - CORE SEARCH') C
		on l.Hotel_ID=C.hotel_id
	) d
) e
on L.HOTEL_ID=e.hotel_Id
);


/*-------------------------Getting Traffic and Booking, EPB, CPC and creating the final AD for Optimization-------------------------------*/

--drop table ta_canada_lookup_desktop_4
set statement_timeout to 1999999999;
Create table ta_other_region_lookup_desktop
as
(
Select L.*,case when a.Traffic is null then 0 else a.Traffic end as traffic
,Coalesce(a.total_cost,0) as cost
,coalesce(a.CPC,0) as cpc
,coalesce(a.Average_Weekly_Traffic,0)as average_weekly_traffic
,coalesce(b.Booking,0) as booking
,coalesce(b.Gross_Profit,0) as gross_profit
,coalesce(b.EPB,c.EPB,d.EPB,e.EPB,f.EPB,g.EPB,h.EPB,i.EPB,j.EPB,k.EPB,m.EPB,n.EPB,0.0) as epb
from look_up L
left join
(Select hotel_id,LOS_Bucket,BW_Bucket
,sum(Traffic) Traffic,sum(Cost) as total_cost
,count(distinct Activity_Week) as Count_of_Week,
Round(cast(sum(Traffic)*1.0/count(distinct Activity_Week) as numeric),2) as Average_Weekly_Traffic
,sum(Cost)*1.0/sum(Traffic) as CPC
from canada_raw_ad 
where Model_Name in (Select model_name from model) and Activity_Date>=(Select date1-14 from date1)
and Activity_Date<=(Select date1 from date1) and device_type='DESKTOP'
group by hotel_id,LOS_Bucket,BW_Bucket) a
on L.Hotel_ID=a.Hotel_ID
and L.BW_Bucket=a.BW_Bucket
and L.LOS_Bucket=a.LOS_Bucket
left join 
(Select hotel_id,LOS_Bucket,BW_Bucket
,sum(Booking) Booking,sum(Gross_Profit) Gross_Profit,
Round(cast(sum(Gross_Profit)*1.0/sum(Booking) as numeric),2) as EPB
from canada_raw_ad 
where Model_Name in (Select model_name from model) and Activity_Date>=(Select date1-14 from date1)
and Activity_Date<=(Select date1 from date1) and Booking>=1
group by hotel_id,LOS_Bucket,BW_Bucket) b
on L.Hotel_ID=b.Hotel_ID
and L.BW_Bucket=b.BW_Bucket
and L.LOS_Bucket=b.LOS_Bucket
left join
(Select hotel_id,LOS_Bucket,BW_Bucket
,sum(Booking) Booking,sum(Gross_Profit) Gross_Profit,
Round(cast(sum(Gross_Profit)*1.0/sum(Booking) as numeric),2) as EPB
from canada_raw_ad 
where Model_Name in (Select model_name from model) and Activity_Date>='2015-01-01'and 
Activity_Date<=(Select date1-14 from date1) and Booking>=1
group by hotel_id,LOS_Bucket,BW_Bucket) c
on L.Hotel_ID=c.Hotel_ID
and L.BW_Bucket=c.BW_Bucket
and L.LOS_Bucket=c.LOS_Bucket
left join
(Select hotel_id,LOS_Bucket
,sum(Booking) Booking,sum(Gross_Profit) Gross_Profit,
Round(cast(sum(Gross_Profit)*1.0/sum(Booking) as numeric),2) as EPB
from canada_raw_ad 
where Model_Name in (Select model_name from model) and Activity_Date>=(Select date1-14 from date1)
and Activity_Date<=(Select date1 from date1) and Booking>=1
group by hotel_id,LOS_Bucket) d
on L.Hotel_ID=d.Hotel_ID
and L.LOS_Bucket=d.LOS_Bucket
left join
(Select hotel_id,LOS_Bucket
,sum(Booking) Booking,sum(Gross_Profit) Gross_Profit,
Round(cast(sum(Gross_Profit)*1.0/sum(Booking) as numeric),2) as EPB
from canada_raw_ad 
where Model_Name in (Select model_name from model) and Activity_Date>='2015-01-01'and Activity_Date<=(Select date1-14 from date1) and Booking>=1
group by hotel_id,LOS_Bucket) e
on L.Hotel_ID=e.Hotel_ID
and L.LOS_Bucket=e.LOS_Bucket
left join 
(Select hotel_id,LOS_Bucket,BW_Bucket
,sum(Booking) Booking,sum(Gross_Profit) Gross_Profit,
Round(cast(sum(Gross_Profit)*1.0/sum(Booking) as numeric),2) as EPB
from canada_raw_ad 
where Model_Name in (Select model_name from model) and  Activity_Date<'2015-01-01' and Booking>=1
group by hotel_id,LOS_Bucket,BW_Bucket) f
on L.Hotel_ID=f.Hotel_ID
and L.BW_Bucket=f.BW_Bucket
and L.LOS_Bucket=f.LOS_Bucket
left join
(Select hotel_id,LOS_Bucket
,sum(Booking) Booking,sum(Gross_Profit) Gross_Profit,
Round(cast(sum(Gross_Profit)*1.0/sum(Booking) as numeric),2) as EPB
from canada_raw_ad 
where Model_Name in (Select model_name from model) and  Activity_Date<'2015-01-01' and Booking>=1
group by hotel_id,LOS_Bucket) g
on L.Hotel_ID=g.Hotel_ID
and L.LOS_Bucket=g.LOS_Bucket
left join 
(Select hotel_id
,sum(Booking) Booking,sum(Gross_Profit) Gross_Profit,
Round(cast(sum(Gross_Profit)*1.0/sum(Booking) as numeric),2) as EPB
from canada_raw_ad 
where Model_Name in (Select model_name from model) and  Activity_Date>='2015-01-01' and Activity_Date<=(Select date1 from date1) and Booking>=1
group by hotel_id) h
on L.Hotel_ID=h.Hotel_ID
left join 
(Select hotel_id
,sum(Booking) Booking,sum(Gross_Profit) Gross_Profit,
Round(cast(sum(Gross_Profit)*1.0/sum(Booking) as numeric),2) as EPB
from canada_raw_ad 
where Model_Name in (Select model_name from model) and  Activity_Date<'2015-01-01'  and Booking>=1
group by hotel_id) i
on L.Hotel_ID=i.Hotel_ID
left join 
(Select Market,Star_Rating,Hotel_Type,LOS_Bucket,sum(Gross_Profit) Gross_Profit,
Round(cast(sum(Gross_Profit)*1.0/sum(Booking) as numeric),2) as EPB
from canada_raw_ad
where Model_Name in (Select model_name from model) and Activity_Date>='2015-01-01' and Activity_Date<=(Select date1 from date1) and Booking>=1
group by Market,Star_Rating,Hotel_Type,LOS_Bucket)j
on L.Market=j.Market
and L.Star_Rating=j.Star_Rating
and L.Hotel_Type=j.Hotel_Type
and L.LOS_Bucket=j.LOS_Bucket
left join 
(Select Market,Star_Rating,Hotel_Type,LOS_Bucket,sum(Gross_Profit) Gross_Profit,
Round(cast(sum(Gross_Profit)*1.0/sum(Booking) as numeric),2) as EPB
from canada_raw_ad
where Model_Name in (Select model_name from model)and Activity_Date<'2015-01-01' and Booking>=1
group by Market,Star_Rating,Hotel_Type,LOS_Bucket)k
on L.Market=k.Market
and L.Star_Rating=k.Star_Rating
and L.Hotel_Type=k.Hotel_Type
and L.LOS_Bucket=k.LOS_Bucket
left join 
(Select Market,Star_Rating,Hotel_Type,sum(Gross_Profit) Gross_Profit,
Round(cast(sum(Gross_Profit)*1.0/sum(Booking) as numeric),2) as EPB
from canada_raw_ad
where Model_Name in (Select model_name from model) and Activity_Date>='2015-01-01' and Activity_Date<=(Select date1 from date1) and Booking>=1
group by Market,Star_Rating,Hotel_Type)m
on L.Market=m.Market
and L.Star_Rating=m.Star_Rating
and L.Hotel_Type=m.Hotel_Type
left join 
(Select Market,Star_Rating,Hotel_Type,sum(Gross_Profit) Gross_Profit,
Round(cast(sum(Gross_Profit)*1.0/sum(Booking) as numeric),2) as EPB
from canada_raw_ad
where Model_Name in (Select model_name from model) and Activity_Date<'2015-01-01' and Booking>=1 
group by Market,Star_Rating,Hotel_Type)n
on L.Market=n.Market
and L.Star_Rating=n.Star_Rating
and L.Hotel_Type=n.Hotel_Type
);