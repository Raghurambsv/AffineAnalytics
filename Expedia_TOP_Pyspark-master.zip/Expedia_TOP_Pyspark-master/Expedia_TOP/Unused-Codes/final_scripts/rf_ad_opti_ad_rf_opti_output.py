##IMPORTING THE REQUIRED LIBRARIES

from datetime import timedelta, date
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql import *
import time


#star rating buckets
def srch_region_star_rating(star_rating):
    if star_rating == '2.0':
        return '2'
    elif star_rating == '2.5':
        return '2.5'
    elif star_rating == '3.0':
        return '3'
    elif star_rating == '3.5':
        return '3.5'
    elif star_rating == '4.0':
        return '4'
    elif star_rating == '1.0' or star_rating == '1.5':
        return '1-1.5'
    elif star_rating == '4.5' or star_rating == '5.0':
        return '4.5-5'
    else:
        return '0'

#udf for creating city buckets
def srch_region_city(city,model_name):
	if model_name == 'CANADA':
		if city == 'TORONTO':
			return 'TORONTO'
		elif city == 'NIAGARA FALLS':
			return 'NIAGARA FALLS'
		elif city == 'MONTREAL':
			return 'MONTREAL'
		elif city == 'VANCOUVER':
			return 'VANCOUVER'
		elif city == 'QUEBEC':
			return 'QUEBEC'
		elif city == 'BANFF':
			return 'BANFF'
		elif city == 'OTTAWA':
			return 'OTTAWA'
		elif city == 'EDMONTON':
			return 'EDMONTON'
		elif city == 'VICTORIA':
			return 'VICTORIA'
		elif city == 'CALGARY':
			return 'CALGARY'
		elif city == 'WHISTLER':
			return 'WHISTLER'
		elif city in ('NIAGARA-ON-THE-LAKE','CANMORE','JASPER','KELOWNA','HALIFAX','MISSISSAUGA','LAKELOUISE','COLLINGWOOD','VERNON','PENTICTON','GATINEAU','DORVAL','MARKHAM'):
			return'G12'
		elif city in ('MONT-TREMBLANT','TOFINO','BLUEMOUNTAINS','OSOYOOS','UCLUELET','SAINT-SAUVEUR','WESTKELOWNA','LAMALBAIE','SAINTE-ADELE'):
			return'G13'
		elif city in ('WINNIPEG','LONDON','RICHMOND','BARRIE','REVELSTOKE','VAUGHAN','ORILLIA','BURNABY','SURREY'):
			return 'G14'
		else:
			return 'others'
	else:
		return 'NA'

#udf for hotel type
def srch_region_Hotel_type(Hotel_type,model_name):
	if model_name == 'CANADA':
		if Hotel_type == 'HOTEL':
			return 'HOTEL'
		elif Hotel_type == 'HOTEL RESORT':
			return 'HOTEL RESORT'
		elif Hotel_type == 'MOTEL':
			return 'MOTEL'
		elif Hotel_type == 'CONDOMINIUM RESORT' or Hotel_type == 'CONDO':
			return 'CONDO'
		elif Hotel_type in ('LODGE' , 'BED & BREAKFAST' , 'HOSTEL/BACKPACKER ACCOMMODATION' , 'CABIN' , 'GUEST HOUSE'):
			return 'Budget_hotel'
		elif Hotel_type in ('APART-HOTEL', 'INN'):
			return 'Family_Premium'
		else:
			return 'Others'
	
	elif model_name == 'US':
		if Hotel_type == 'HOTEL':
			return 'HOTEL'
		elif Hotel_type == 'HOTEL RESORT':
			return 'HOTEL RESORT'
		elif Hotel_type == 'MOTEL':
			return 'MOTEL'
		elif Hotel_type in ('CONDOMINIUM RESORT' ,'CONDO'):
			return 'CONDO'
		elif Hotel_type in ('LODGE' , 'BED & BREAKFAST' , 'HOSTEL/BACKPACKER ACCOMMODATION' , 'CABIN' , 'GUEST HOUSE'):
			return 'Budget_hotel'
		elif Hotel_type in ('APART-HOTEL' ,  'INN' , 'APARTMENT', 'VILLA', 'PRIVATE VACATION HOME'):
			return 'Family_Premium'
		else:
			return 'others'
		
	elif model_name == 'Mexico':
		if Hotel_type == 'HOTEL':
			return 'HOTEL'
		elif Hotel_type == 'HOTEL RESORT':
			return 'HOTEL RESORT'
		elif Hotel_type == 'ALL-INCLUSIVE':
			return 'ALL-INCLUSIVE'
		elif Hotel_type in ('CONDOMINIUM RESORT' ,'CONDO'):
			return 'CONDO'
		elif Hotel_type in ('LODGE' , 'BED & BREAKFAST' , 'HOSTEL/BACKPACKER ACCOMMODATION'):
			return 'Budget_hotel'
		elif Hotel_type in ('APART-HOTEL' ,'INN' , 'VILLA' , 'APARTMENT'):
			return 'Family_Premium'
		else:
			return 'others'
		
	elif model_name=="CARIBBEAN":
		if Hotel_type == 'HOTEL':
			return 'HOTEL'
		elif Hotel_type == 'HOTEL RESORT':
			return 'HOTEL RESORT'
		elif Hotel_type == 'ALL-INCLUSIVE':
			return 'ALL-INCLUSIVE'
		elif Hotel_type in ('CONDOMINIUM RESORT' ,'CONDO'):
			return 'CONDO'
		elif Hotel_type in ('APART-HOTEL' ,'INN' , 'VILLA' , 'APARTMENT'):
			return 'Family_Premium'
		else:
			return 'others'
		
	elif model_name == 'Other Region':
		if Hotel_type == 'HOTEL':
			return 'HOTEL'
		elif Hotel_type == 'HOTEL RESORT':
			return 'HOTEL RESORT'
		elif Hotel_type == 'APART-HOTEL':
			return 'APART-HOTEL'
		elif Hotel_type in ('GUEST HOUSE' ,'BED & BREAKFAST', 'HOSTEL/BACKPACKER ACCOMMODATION', 'MOTEL' , 'HOSTAL (BUDGET HOTEL)'):
			return 'Budget_hotel'
		elif Hotel_type in ('APARTMENT','RESIDENCE','TOWNHOUSE','INN'):
			return 'Budget_hotel'
		else:
			return 'others'
	
	elif model_name=="North America":
		if Hotel_type == 'HOTEL':
			return 'HOTEL'
		elif Hotel_type == 'MOTEL':
			return 'MOTEL'
		elif Hotel_type in ('LODGE' ,  'BED & BREAKFAST' ,  'COTTAGE' ,  'GUEST HOUSE' ,  'CABIN'):
			return 'Budget_hotel'
		elif Hotel_type in ( 'APARTMENT' ,  'HOTEL RESORT' ,  'CONDO' ,  'INN' ,  'APART-HOTEL' ,  'CARAVAN PARK'):
			return 'Family_Premium'
		else:
			'others'
	else:
		return 'NOT APPLICABLE'

##udf for market bucket
def srch_region_market(market,model_name):
	if model_name == 'CANADA':
		if market == 'TORONTO, ON, CAN':
			return 'TORONTO, ON, CAN'
		elif market == 'NIAGARA FALLS, ON, CAN':
			return 'NIAGARA FALLS, ON, CAN'
		elif market == 'MONTREAL, QC, CAN':
			return 'MONTREAL, QC, CAN'
		elif market == 'BANFF AREA, AB, CAN':
			return 'BANFF AREA, AB, CAN'
		elif market == 'VANCOUVER, BC, CAN':
			return 'VANCOUVER, BC, CAN'
		elif market == 'QUEBEC CITY, QC, CAN':
			return 'QUEBEC CITY, QC, CAN'
		elif market == 'EDMONTON, AB, CAN':
			return 'EDMONTON, AB, CAN'
		elif market == 'OTTAWA, ON, CAN':
			return 'OTTAWA, ON, CAN'
		elif market == 'OKANAGAN VALLEY, BC, CAN':
			return 'OKANAGAN VALLEY, BC, CAN'
		elif market in ('VICTORIA, BC, CAN' ,'CALGARY, AB, CAN' ,'JASPER AREA, AB, CAN'):
			return 'G10'
		elif market in ('WHISTLER, BC, CAN' ,'NIAGARA-ON-THE-LAKE, ON, CAN' ,'MONT TREMBLANT, QC, CAN' , 'UCLUELET, BC, CAN'):
			return 'G11'
		elif market in ('COLLINGWOOD, ON, CAN' , 'BC INTERIOR SKI, BC, CAN' ,'HALIFAX, NS, CAN','WINNIPEG, MB, CAN' ,'LONDON, ON, CAN' ,'KAMLOOPS, BC, CAN'):
			return 'G12'
		else:
			return 'others'
	
	elif model_name == 'US':
		return 'NA'
		
	elif model_name == 'Mexico':
		if market == 'MEXICO - RIVIERA MAYA, PLAYA DEL CARMEN & TULUM':
			return 'MEXICO - RIVIERA MAYA, PLAYA DEL CARMEN & TULUM'
		elif market == 'MEXICO - CANCUN & ISLA MUJERES':
			return 'MEXICO - CANCUN & ISLA MUJERES'
		elif market == 'MEXICO - PUERTO VALLARTA, NUEVO VALLARTA & RIVIERA NAYARIT':
			return 'MEXICO - PUERTO VALLARTA, NUEVO VALLARTA & RIVIERA NAYARIT'
		elif market == 'MEXICO - LOS CABOS':
			return 'MEXICO - LOS CABOS'
		elif market == 'CENTRAL AMERICA - COSTA RICA - GUANACASTE':
			return 'CENTRAL AMERICA - COSTA RICA - GUANACASTE'
		elif market == 'CENTRAL AMERICA - BELIZE':
			return 'CENTRAL AMERICA - BELIZE'
		elif market == 'CENTRAL AMERICA - COSTA RICA - PUNTARENAS':
			return 'CENTRAL AMERICA - COSTA RICA - PUNTARENAS'
		elif market == 'CENTRAL AMERICA - COSTA RICA - OTHER':
			return 'CENTRAL AMERICA - COSTA RICA - OTHER'
		elif market == 'MEXICO - COZUMEL':
			return 'MEXICO - COZUMEL'
		elif market == 'MEXICO - HUATULCO':
			return 'MEXICO - HUATULCO'
		elif market == 'MEXICO - IXTAPA & ZIHUATANEJO':
			return 'MEXICO - IXTAPA & ZIHUATANEJO'
		elif market == 'CENTRAL AMERICA - HONDURAS':
			return 'CENTRAL AMERICA - HONDURAS'
		elif market == 'CENTRAL AMERICA - PANAMA - OTHER':
			return 'CENTRAL AMERICA - PANAMA - OTHER'
		elif market in ( 'CENTRAL AMERICA - COSTA RICA - SAN JOSE' , 'CENTRAL AMERICA - PANAMA - PANAMA CITY' ,'MEXICO - MEXICO CITY' ,'MEXICO - MEXICO CITY'\
						,'CENTRAL AMERICA - NICARAGUA','MEXICO - MAZATLAN','MEXICO - MANZANILLO','CENTRAL AMERICA - EL SALVADOR','MEXICO - ACAPULCO'):
			return 'hclt'
		else:
			return 'others'
		
	elif model_name=="CARIBBEAN":
		if market == 'PUNTA CANA, DOMINICAN REPUBLIC':
			return 'PUNTA CANA, DOMINICAN REPUBLIC'
		elif market == 'TURKS AND CAICOS':
			return 'TURKS AND CAICOS'
		elif market == 'MONTEGO BAY, JAMAICA':
			return 'MONTEGO BAY, JAMAICA'
		elif market == 'ST. LUCIA':
			return 'ST. LUCIA'
		elif market == 'OCHO RIOS, JAMAICA':
			return 'OCHO RIOS, JAMAICA'
		elif market == 'NEGRIL, JAMAICA':
			return 'NEGRIL, JAMAICA'
		elif market == 'BARBADOS':
			return 'BARBADOS'
		elif market in ('ARUBA' , 'PUERTO PLATA, DOMINICAN REPUBLIC' , 'ANTIGUA AND BARBUDA'):
			return 'G8'
		elif market in ('NASSAU, BAHAMAS', 'DOMINICAN REPUBLIC ALL OTHER' , 'BERMUDA','BAHAMAS, OUT ISLANDS'):
			return 'G9'
		elif market in ('SAN JUAN, PUERTO RICO' ,'PARADISE ISLAND, BAHAMAS' ,'CAYMAN ISLANDS','SINT MAARTEN, DUTCH' ,'CURACAO','ST. MARTIN, FRENCH'):
			return 'G10'
		else:
			return 'others'
		
	elif model_name == 'Other Region':
		return 'NA'
	
	elif model_name=="North America":
		if  market in ('GRAVENHURST - BRACEBRIDGE - HUNTSVILLE, ON, CAN' ,  'ONTARIO WEST, ON, CAN' ,  'ABBOTSFORD - CHILLIWACK, BC, CAN' \
						, 'MAINE - COAST' ,  'ONTARIO EAST, ON, CAN' ,'VANCOUVER ISLAND, BC, CAN' ,  'BURLINGTON, VT' ,'CHARLOTTETOWN, PEI, CAN'): 
			return 'G1'
		elif market in ( 'ALBERTA EAST, AB, CAN' ,  'REGINA, SK, CAN' ,  'KINGSTON, ON, CAN' , 'SASKATOON, SK, CAN' ,'MONCTON, NB, CAN' \
						,'TRI-CITIES (KW-GUELPH-CAMBRIDGE), ON, CAN'): 
			return 'G2'
		elif market in ('WINDSOR, ON, CAN' ,  'RED DEER, AB, CAN' ,  'BRITISH COLUMBIA SOUTH, BC, CAN' ,  'GRAND FORKS, ND' ,  'SUDBURY, ON, CAN' , \
						'ONTARIO NORTH, ON, CAN','BANGOR, ME' ,  'HAMILTON - BRANTFORD, ON, CAN' ,  'BELLEVILLE - TRENTON - COBOURG, ON, CAN' ,'FARGO, ND'): 
			return 'G3'
		elif market in ('LAKE PLACID, NY' ,  'PARKSVILLE, VANCOUVER ISLAND, BC, CAN' ,  'LAKE GEORGE, NY','OGUNQUIT, ME' , 'EVERETT, WA' , \
						'COASTAL, BC, CAN' ,  'GROVE CITY, PA','BELLINGHAM, WA' ,  'NORTH CONWAY, NH' ,  'NEWFOUNDLAND OTHER, NL, CAN' \
						,  'NOVA SCOTIA SOUTH, NS, CAN' ,  'PORTSMOUTH, NH'): 
			return 'G4'
		elif market in ('LETHBRIDGE, AB, CAN' ,  'FREDERICTON, NB, CAN' ,  'BRANDON, MB, CAN',  'ERIE, PA' ,'NANAIMO, VANCOUVER ISLAND, BC, CAN' ,\
						'SASKATCHEWAN SOUTH, SK, CAN' ,  'PRINCE GEORGE - QUESNEL, BC, CAN' ,  'MEDICINE HAT, AB, CAN' ,  'GRANDE PRAIRIE, AB, CAN' \
						,  'ALBERTA NORTH, AB, CAN' ,  'DURHAM, ON, CAN' ,  'BRITISH COLUMBIA CENTRAL, BC, CAN' , 'ONTARIO SOUTHWEST, ON, CAN' ,\
						'SAULT STE. MARIE, ON, CAN' ,  'THUNDER BAY, ON, CAN' ,  'SAINT JOHN, NB, CAN' ,  'GREAT FALLS, MT' ,  'MINOT, ND (AREA)' \
						,  'BRITISH COLUMBIA NORTH, BC, CAN' ,  'NORTH BAY, ON, CAN' ,  'PETERBOROUGH, ON, CAN' \
						,  'CAPE BRETON ISLAND, NS, CAN' ,  'ALBERTA WEST, AB, CAN' ,  'HUDSON VALLEY - POUGHKEEPSIE, NY' \
						,  'FORT MCMURRAY, AB, CAN' ,  'NOVA SCOTIA NORTH, NS, CAN' ,  'WATERTOWN, NY' \
						,  'EDMUNSTON, NB, CAN' ,  'OLYMPIC NATIONAL PARK AREA, WA' ,  'CEDAR CITY - BRYCE CANYON NATIONAL PARK, UT' \
						,  'SUMMERSIDE, PEI, CAN' ,  'SALEM, OR (AREA)' ,  'BUTTE - HELENA, MT' ,  'BECKLEY, WV'): 
			return 'G5'
		elif market in ( 'SAGINAW, MI' ,  'WHITE MOUNTAINS, NH' ,  'FINGER LAKES NEW YORK' ,  'NEW YORK - WEST' , 'NEW BRUNSWICK NORTH, NB, CAN'  \
						,  'SASKATCHEWAN NORTH, SK, CAN' ,  'MANITOBA SOUTH, MB, CAN' ,  'BAR HARBOR, ME' \
						,  'WASHINGTON NORTHWEST' ,  'VERMONT CENTRAL' ,  'ALBERTA SOUTH, AB, CAN' \
						,  'WENATCHEE-LEAVENWORTH,WA' ,  'GANANOQUE, ON, CAN' ,  'PLATTSBURGH, (NY)' \
						,  'STRAITS OF MACKINAC, MI' ,  'SANDUSKY, OH' ,  'MANCHESTER, NH' \
						,  'ITHACA, NY' ,  'MINNESOTA NORTHWEST' ,  'MISSOULA, MT (AREA)' \
						,  'YELLOWKNIFE, NT, CAN' ,  'PEI OTHER, PEI, CAN' ,  'BILLINGS, MT (AREA)' \
						,  'RAPID CITY - MOUNT RUSHMORE, SD' ,  'ANDOVER, MA', 'YUMA, AZ' ,  'PORT HURON, MI' \
						,  'LANCASTER, PA' ,  'FORT LEE - PARAMUS, NJ' ,  'LEXINGTON, KY' \
						,  'MANITOBA NORTH, MB, CAN' ,  'ABERDEEN - OCEAN SHORES, WA' ,  'CANADA TERRITORIES, YT, CAN' \
						,  'KNOXVILLE, TN' ,  'BURLINGTON - MOUNT VERNON, WA' ,  'FREDERICKSBURG, VA' \
						,  'ARIZONA SOUTHEAST' ,  'WINDHAM COUNTY, VT' ,  'KENAI PENINSULA, AK' \
						,  'COLUMBIA, SC' ,  'CALIFORNIA DESERTS SOUTH'): 
			return 'G6'
		elif  market in ('ROME-UTICA, NY' ,  'SANDPOINT, ID (AREA)' ,  'MOAB - GREEN RIVER, UT' ,  'WHITEHORSE, YT, CAN' , 'NEW YORK - NORTHEAST'  \
							,  'SARNIA, ON, CAN' ,  'AUGUSTA, ME' ,  'LAKE POWELL - GLEN CANYON NATIONAL PARK, AZ' \
							,  'NEW YORK - SOUTH' ,  'BISMARK, ND' ,  'ALABAMA NORTH' \
							,  'ASHLAND - MEDFORD, OR' ,  'WASHINGTON NORTHEAST' ,  'THE BERKSHIRES, MA' \
							,  'EUGENE, OR (AREA)' ,  'GRAND RAPIDS, MI' ,  'WASHINGTON SOUTHWEST' \
							,  'LAKE HAVASU CITY, AZ' ,  'SARATOGA, NY' ,  'WYTHEVILLE - VA' \
							,  'ARCATA - EUREKA, CA' ,  'SOUTH CAROLINA EAST' ,  'CHATTANOOGA, TN' \
							,  'TOLEDO, OH' ,  'IDAHO FALLS, ID' ,  'WEST VIRGINIA SOUTH' \
							,  'SPRINGFIELD, MA' ,  'OLYMPIA, WA' ,  'GETTYSBURG - PA'): 
			return 'G7'
		else:return 'Others'
	else:return 'NOT APPLICABLE'		
		
def srch_model_name(region):
	if region == 'CANADA':
		return region
		
	elif region in   ('FLORIDA (USA)','NEW YORK CITY','CALIFORNIA','GAMING (USA)','NORTHEAST (USA)','MOUNTAIN (USA)','MIDWEST (USA)','CENTRAL (USA)','SF PACNW','ORLANDO','HAWAII'):
		return 'US'
		
	elif region in ("MEXICO - DOMESTIC REGION",'MEXICO - RESORTS REGION','CENTRAL AMERICA REGION'):
		return 'Mexico'
		
	elif region=="CARIBBEAN":
		return 'CARIBBEAN'
		
	elif region in ('SPAIN & PORTUGAL' , 'ROME & ITALY RESORTS', 'MID-ATLANTIC' , 'GREECE & TURKEY', 'PARIS' , 'OCEANIA' ,'ITALY NORTH' , 'LONDON, ENGLAND', 'TAIWAN' \
					,'THAILAND' , 'MIDDLE EAST AND INDIAN OCEAN' ,'EUROPE REGIONAL TERRITORIES' , 'UK & IRELAND' ,'AFRICA AND EAST MED' , 'EASTERN EUROPE' \
					,'GERMANY, AUSTRIA & SWITZERLAND' , 'JAPAN & MICRONESIA' ,'PHILIPPINES' , 'BENELUX' , 'FRANCE' ,'INDONESIA' , 'INDIAN SUBCONTINENT'  ,'SOUTH AMERICA'\
					'HONG KONG & MACAU','SOUTHEAST ASIA EMERGING' , 'NORDIC' ,'MAINLAND CHINA' , 'SOUTH KOREA', 'SINGAPORE (REGION)','MALAYSIA', 'UNKNOWN'):
		return 'Other Region'
	
	elif region=="NORTH AMERICA REGIONAL TERRITORIES":
		return 'North America'
		
	else :
		return "NOT APPLICABLE"

def srch_region_bucket(region):
	if region == 'Other Region':
		if region == 'SPAIN & PORTUGAL':
			return 'SPAIN & PORTUGAL'
		elif region == 'ROME & ITALY RESORTS':
			return 'ROME & ITALY RESORTS'
		elif region == 'MID-ATLANTIC':
			return 'MID-ATLANTIC'
		elif region == 'GREECE & TURKEY':
			return 'GREECE & TURKEY'
		elif region == 'OCEANIA':
			return 'OCEANIA'
		elif region == 'ITALY NORTH':
			return 'ITALY NORTH'
		elif region == 'THAILAND':
			return 'THAILAND'
		elif region == 'MIDDLE EAST AND INDIAN OCEAN':
			return 'MIDDLE EAST AND INDIAN OCEAN'
		elif region == 'PARIS' or region == 'LONDON' or region == 'ENGLAND':
			return 'G9'
		elif region == 'EUROPE REGIONAL TERRITORIES' or region == 'UK & IRELAND':
			return 'G10'
		elif region == 'SOUTH AMERICA' or region == 'AFRICA AND EAST MED':
			return 'G11'
		elif region == 'EASTERN EUROPE' or region == 'GERMANY, AUSTRIA & SWITZERLAND' or region == 'BENELUX' or region == 'FRANCE' or region == 'NORDIC':
			return 'G12'
		elif region == 'JAPAN & MICRONESIA' or region == 'HONG KONG & MACAU' or region == 'SOUTHEAST ASIA EMERGING' or region == 'MAINLAND CHINA':
			return 'G13'
		else:
			return 'others'
	else :
		return 'NA'


udfsrch_region_star_rating=udf(srch_region_star_rating, StringType())
udfsrch_region_city=udf(srch_region_city, StringType())
udfsrch_region_hotel_type=udf(srch_region_Hotel_type, StringType())
udfsrch_region_market=udf(srch_region_market, StringType())
udfsrch_model_name= udf(srch_model_name,StringType())
udfsrch_region_bucket = udf (srch_region_bucket,StringType())


#code for reading and defining distinct hotel_dim
path_hotel_dim = 's3n://ewe-core-meta-prod/CORE/HOTEL_DIM/*'
hotel_dim = sqlCtx.read.format("com.databricks.spark.csv").\
			options(header = False, inferSchema = True, delimiter = "\t", nullValue= '\\N').\
			load(path_hotel_dim)
hotel_dim = hotel_dim.distinct()
hotel_dim = hotel_dim.filter(hotel_dim.C12 == 'BOOKABLE')
hotel_dim = hotel_dim.select("C0","C7","C25","C26","C4","C13","C3")
hotel_dim = hotel_dim.cache()

hotel_dim = hotel_dim.withColumnRenamed("C0","hotel_id").withColumnRenamed("C7" , "city").withColumnRenamed("C25","region").withColumnRenamed("C26","market").\
			withColumnRenamed("C4","brand").withColumnRenamed("C13","star_rating").withColumnRenamed("C3","hotel_type")

#removing the records with hotel id 0
hotel_dim = hotel_dim.filter((hotel_dim['hotel_id'].isNotNull()))
hotel_dim = hotel_dim.withColumnRenamed('hotel_id','HOTEL_ID')
hotel_dim = hotel_dim.cache()

hotel_dim_model_name = hotel_dim.withColumn("MODEL_NAME", udfsrch_model_name("region"))
hotel_dim_bkts = hotel_dim_model_name.withColumn("STAR_RATING_BUCKET", udfsrch_region_star_rating("star_rating")).\
                    withColumn("HOTEL_TYPE_BUCKET", udfsrch_region_hotel_type("hotel_type","MODEL_NAME")).\
                    withColumn("MARKET_BUCKET",udfsrch_region_market("market","MODEL_NAME")).\
                    withColumn("REGION_BUCKET", udfsrch_region_bucket("region"))\
                    .withColumn("CITY_BUCKET", udfsrch_region_city("city","MODEL_NAME"))
					
hotel_dim_final = hotel_dim_bkts.filter(hotel_dim_bkts.MODEL_NAME!='NOT APPLICABLE').drop('city').drop('market').drop('brand').drop('star_rating').drop('hotel_type')

hotel_dim_final = hotel_dim_final.cache()
hotel_dim.unpersist()

#####udfs for hcba Table
##CHANGING THE DATA TYPE 
def data_type_change_int(df,cols):
    temp = df
    for col in cols:
        temp = temp.withColumn(col+'_1',df[col].cast(IntegerType())).drop(col).withColumnRenamed(col+'_1',col)
    return temp

def data_type_change_float(df,cols):
    temp = df
    for col in cols:
        temp = temp.withColumn(col+'_1',df[col].cast(DoubleType())).drop(col).withColumnRenamed(col+'_1',col)
    return temp

def searchToCategory(srch_los,):
    if srch_los == 0:
        return '0'
    elif srch_los == 1:
        return '1'
    elif srch_los == 2:
        return '2'
    elif srch_los == 3:
        return '3'
    elif srch_los == 4:
        return '4'
    elif srch_los == 5:
        return '5'
    elif srch_los == 6:
        return '6'
    elif srch_los == 7:
        return '7'
    elif srch_los >= 8 and srch_los <= 14:
        return '8-14'
    else:
        return '>14'


def searchbucketToCategory(SRCH_WINDOW):
    if SRCH_WINDOW <= 0:
        return '<=0'
    elif SRCH_WINDOW == 1:
        return '1'
    elif SRCH_WINDOW == 2:
        return '2'
    elif SRCH_WINDOW >= 3 and SRCH_WINDOW <= 4:
        return '3-4'
    elif SRCH_WINDOW >= 5 and SRCH_WINDOW <= 7:
        return '5-7'
    elif SRCH_WINDOW >= 8 and SRCH_WINDOW <= 14:
        return '8-14'
    elif SRCH_WINDOW >= 15 and SRCH_WINDOW <= 20:
        return '15-20'
    elif SRCH_WINDOW >= 21 and SRCH_WINDOW <= 30:
        return '21-30'
    elif SRCH_WINDOW >= 31 and SRCH_WINDOW <= 40:
        return '31-40'
    elif SRCH_WINDOW >= 41 and SRCH_WINDOW <= 60:
        return '41-60'
    elif SRCH_WINDOW >= 61 and SRCH_WINDOW <= 90:
        return '61-90'
    elif SRCH_WINDOW >= 91 and SRCH_WINDOW <= 120:
        return '91-120'
    elif SRCH_WINDOW >= 121 and SRCH_WINDOW <= 180:
        return '121-180'
    elif SRCH_WINDOW >= 181 and SRCH_WINDOW <= 240:
        return '181-240'
    else:
        return '>240'


def srchBookedLosBucket(booked_los):
    if booked_los is None:
        return '0'
    elif booked_los == 0:
        return '0'
    elif booked_los == 1:
        return '1'
    elif booked_los == 2:
        return '2'
    elif booked_los == 3:
        return '3'
    elif booked_los == 4:
        return '4'
    elif booked_los == 5:
        return '5'
    elif booked_los == 6:
        return '6'
    elif booked_los == 7:
        return '7'
    elif booked_los >= 8 and booked_los <= 14:
        return '8-14'
    else:
        return '>14'


def srchBookedBwBucket(BOOKED_BKG_WINDOW):
    if BOOKED_BKG_WINDOW is None:
        return '0'
    elif BOOKED_BKG_WINDOW <= 0:
        return '<= 0'
    elif BOOKED_BKG_WINDOW == 1:
        return '1'
    elif BOOKED_BKG_WINDOW == 2:
        return '2'
    elif BOOKED_BKG_WINDOW >= 3 or BOOKED_BKG_WINDOW <= 4:
        return '3-4'
    elif BOOKED_BKG_WINDOW >= 5 or BOOKED_BKG_WINDOW <= 7:
        return '5-7'
    elif BOOKED_BKG_WINDOW >= 8 or BOOKED_BKG_WINDOW <= 14:
        return '8-14'
    elif BOOKED_BKG_WINDOW >= 15 or BOOKED_BKG_WINDOW <= 20:
        return '15-20'
    elif BOOKED_BKG_WINDOW >= 21 or BOOKED_BKG_WINDOW <= 30:
        return '21-30'
    elif BOOKED_BKG_WINDOW >= 31 or BOOKED_BKG_WINDOW <= 40:
        return '31-40'
    elif BOOKED_BKG_WINDOW >= 41 or BOOKED_BKG_WINDOW <= 60:
        return '41-60'
    elif BOOKED_BKG_WINDOW >= 61 or BOOKED_BKG_WINDOW <= 90:
        return '61-90'
    elif BOOKED_BKG_WINDOW >= 91 or BOOKED_BKG_WINDOW <= 120:
        return '91-120'
    elif BOOKED_BKG_WINDOW >= 121 or BOOKED_BKG_WINDOW <= 180:
        return '121-180'
    elif BOOKED_BKG_WINDOW >= 181 or BOOKED_BKG_WINDOW <= 240:
        return '181-240'
    else:
        return '>240'


def booking_flag(booked_flag):
    if booked_flag == 'Y':
        return 1
    else:
        return 0
		
# Registering Functions as UDF's

udfsearchToCategory=udf(searchToCategory, StringType())
udfsearchbucketToCategory=udf(searchbucketToCategory, StringType())
udfsrchBookedLosBucket=udf(srchBookedLosBucket, StringType())
udfsrchsrchBookedBwBucket=udf(srchBookedBwBucket, StringType())
booking_flag_udf=udf(booking_flag, IntegerType())


##CREATE THE LIST OF DATES FOR WHICH DATA IS REQUIRED 
from datetime import *
import time
start_date = datetime.strptime(time.strftime("%Y-%m-%d"), "%Y-%m-%d") #STARTING DATE
no_days = 29  #NO. OF DAYS FOR WHICH DATA IS REQUIRED
date_list = []
for i in range(no_days):
    x = (start_date - timedelta(i))
    x = x.strftime("%Y-%m-%d")
    date_list.append(x)
	
start_date_last = start_date.replace(year=start_date.year - 1)
for i in range(1,8):
    x = (start_date_last - timedelta(i))  ##need to change this while giving for final recommendations
    x = x.strftime("%Y-%m-%d")
    date_list.append(x)
	
##SCHEMA FOR hcba TABLE
hcba_schema = StructType([	StructField('PARTNER_POS',StringType(), True),
							StructField('DEVICE_TYPE',StringType(), True),
							StructField('CLICKED_HOTEL_ID',IntegerType(), True),
							StructField('SRCH_WINDOW',IntegerType(), True),
							StructField('SRCH_LOS',IntegerType(), True),
							StructField('TRAFFIC',IntegerType(), True),
							StructField('COST',DoubleType(), True),
							StructField('BOOKED_FLAG',StringType(), True),
							StructField('BOOKED_HOTEL_ID',IntegerType(), True),
							StructField('BOOKED_LOS',IntegerType(), True),
							StructField('BOOKED_BKG_WINDOW',IntegerType(), True),
							StructField('GROSS_PROFIT',DoubleType(), True),
							StructField('PARTNER_ORG',StringType(), True),
							StructField('ACTIVITY_DATE',StringType(), True)
						])
 

##CREATE EMPTY DATAFRAME 
hcba = sqlContext.createDataFrame(sc.emptyRDD(), hcba_schema)

##APPENDING THE DATA IN ABOVE CREATED hcba TABLE 
for dates in date_list:
	path_hcba = 's3n://ewe-core-meta-prod/CORE/HOTEL_CLICK_BOOK_AGG/local_date='+dates+'/*'  
	print (path_hcba)
	try :
		temp_hcba = sqlCtx.read.format("com.databricks.spark.csv").options(header = False, inferschema = True, delimiter = "\t",nullValue= '\\N').load(path_hcba)
		print('file exist')
		temp_hcba = temp_hcba.select('C1','C3','C7','C8','C9','C13','C14','C19','C20','C21','C22','C45','C65')
		temp_hcba = temp_hcba.filter((temp_hcba.C65 == 'TRIPADVISOR') & (temp_hcba.C1 == 'CA') & (temp_hcba.C7 != 0) & (temp_hcba.C13 != 0) ) 
		temp_hcba = temp_hcba.withColumn('ACTIVITY_DATE',lit(dates))
		hcba = hcba.unionAll(temp_hcba)
	except: print('file does not exist')

hcba = hcba.cache()

cols_int = ['SRCH_LOS','SRCH_WINDOW','TRAFFIC','BOOKED_BKG_WINDOW','BOOKED_LOS']
cols_float = ['COST','GROSS_PROFIT']

hcba = data_type_change_int(hcba,cols_int)
hcba = data_type_change_float(hcba,cols_float)


hcba = hcba.withColumn("SRCH_LOS_BUCKET", udfsearchToCategory("SRCH_LOS")).withColumn("SRCH_BW_BUCKET", udfsearchbucketToCategory("SRCH_WINDOW")).withColumn("BOOKED_LOS_BUCKET", udfsrchBookedLosBucket("BOOKED_LOS")).withColumn("BOOKED_BW_BUCKET", udfsrchsrchBookedBwBucket("BOOKED_BKG_WINDOW")).withColumn("BOOKING", booking_flag_udf("BOOKED_FLAG"))

hcba_los_bw_negative_conv = hcba.filter((hcba['BOOKED_FLAG'] == 'Y') & ((hcba['SRCH_WINDOW'] < -1) | (hcba['SRCH_LOS'] <= 0)))
hcba_los_bw_negative_conv = hcba_los_bw_negative_conv.withColumnRenamed('BOOKED_BKG_WINDOW', 'BOOKING_WINDOW').withColumnRenamed('BOOKED_BW_BUCKET', 'BW_BUCKET').withColumnRenamed('BOOKED_LOS_BUCKET', 'LOS_BUCKET').withColumnRenamed('BOOKED_HOTEL_ID', 'HOTEL_ID').withColumnRenamed('BOOKED_LOS', 'LOS')
hcba_los_bw_negative_conv=hcba_los_bw_negative_conv.select('PARTNER_POS','DEVICE_TYPE','HOTEL_ID','PARTNER_ORG','ACTIVITY_DATE','TRAFFIC','BOOKING_WINDOW','LOS','COST','GROSS_PROFIT','LOS_BUCKET','BW_BUCKET','BOOKING')

#-------------------------------------Selecting all the non converted rows---------------------#
#Selecting the required data
hcba_non_conv = hcba.filter((hcba['BOOKED_FLAG'] == 'N') & (hcba['SRCH_WINDOW'] >= -1) & (hcba['SRCH_LOS'] > 0) & (hcba['GROSS_PROFIT'] == 0.0) )

#Renaming the columns as required
hcba_non_conv = hcba_non_conv.withColumnRenamed('CLICKED_HOTEL_ID', 'HOTEL_ID').withColumnRenamed('SRCH_WINDOW', 'BOOKING_WINDOW').withColumnRenamed('SRCH_BW_BUCKET', 'BW_BUCKET').withColumnRenamed('SRCH_LOS', 'LOS').withColumnRenamed('SRCH_LOS_BUCKET', 'LOS_BUCKET')
hcba_non_conv=hcba_non_conv.select('PARTNER_POS','DEVICE_TYPE','HOTEL_ID','PARTNER_ORG','ACTIVITY_DATE','TRAFFIC','BOOKING_WINDOW','LOS','COST','GROSS_PROFIT','LOS_BUCKET','BW_BUCKET','BOOKING')

#----------------------------------Selecting all converted rows-------------------------------------#
#Selecting the required data
hcba_conv = hcba.filter((hcba['BOOKED_FLAG'] == 'Y') & (hcba['SRCH_WINDOW'] >= -1) & (hcba['SRCH_LOS'] > 0))

#Renaming the columns as required
hcba_conv = hcba_conv.withColumnRenamed('CLICKED_HOTEL_ID', 'HOTEL_ID').withColumnRenamed('SRCH_WINDOW', 'BOOKING_WINDOW').withColumnRenamed('SRCH_BW_BUCKET', 'BW_BUCKET').withColumnRenamed('SRCH_LOS', 'LOS').withColumnRenamed('SRCH_LOS_BUCKET', 'LOS_BUCKET')
hcba_conv=hcba_conv.select('PARTNER_POS','DEVICE_TYPE','HOTEL_ID','PARTNER_ORG','ACTIVITY_DATE','TRAFFIC','BOOKING_WINDOW','LOS','COST','GROSS_PROFIT','LOS_BUCKET','BW_BUCKET','BOOKING')


#---Union of all the above 3 tables hcba_non_conv,hcba_conv,hcba_los_bw_negative_conv----------#
hcba_union = hcba_los_bw_negative_conv.unionAll(hcba_non_conv).unionAll(hcba_conv)
hcba_union = hcba_union.cache()
hcba.unpersist()

#####################subset data for optimization
opti_strt_date = start_date.strftime("%Y-%m-%d")

end_date = (start_date - timedelta(15))
opti_end_date = end_date.strftime("%Y-%m-%d")

hcba_opti_union = hcba_union.filter((hcba_union.ACTIVITY_DATE <= opti_strt_date) & (hcba_union.ACTIVITY_DATE >=opti_end_date))

##populating week column
hcba_opti_union = hcba_opti_union.withColumn('WEEK',weekofyear(hcba_opti_union.ACTIVITY_DATE))


##populating average weekly traffic
import pyspark.sql.functions as func
hcba_opti_union_agg = hcba_opti_union.groupBy('HOTEL_ID','LOS_BUCKET','BW_BUCKET')
hcba_opti_union_agg1 = hcba_opti_union_agg.agg({'TRAFFIC':'sum'}).withColumnRenamed('sum(TRAFFIC)','TOTAL_TRAFFIC')
hcba_opti_union_agg2 = hcba_opti_union_agg.agg(func.countDistinct('WEEK')).withColumnRenamed('count(WEEK)','NO_WEEKS')

hcba_opti_union = hcba_opti_union.join(hcba_opti_union_agg1,['HOTEL_ID','LOS_BUCKET','BW_BUCKET'],'inner')
hcba_opti_union = hcba_opti_union.join(hcba_opti_union_agg2,['HOTEL_ID','LOS_BUCKET','BW_BUCKET'],'inner')

hcba_opti_union = hcba_opti_union.withColumn('AVERAGE_WEEKLY_TRAFFIC',hcba_opti_union.TOTAL_TRAFFIC/hcba_opti_union.NO_WEEKS)
hcba_opti_union = hcba_opti_union.select('HOTEL_ID','LOS_BUCKET','BW_BUCKET','AVERAGE_WEEKLY_TRAFFIC','DEVICE_TYPE')
hcba_opti_union = hcba_opti_union.cache()

###########################subset HCBA for random forest
hcba_rf_union = hcba_union[~((hcba_union.ACTIVITY_DATE <= opti_strt_date) & (hcba_union.ACTIVITY_DATE >=opti_end_date))]
hcba_rf_union = hcba_rf_union.cache()

hcba_union.unpersist()
###########################mbap Table data

def seller_rank_bucket(seller_rank):
	seller_rank = int(seller_rank)
	if seller_rank <=3 :
		return str(seller_rank)
	else:
		return ">=4"

seller_rank_bucket_udf = udf(seller_rank_bucket,StringType())

##CREATE EMPTY DATAFRAME
mbap_schema = StructType([StructField('ACTIVITY_DATE',StringType(),True),
                          StructField('DEVICE_TYPE',StringType(),True),
                          StructField('HOTEL_ID',IntegerType(),True),
                          StructField('CPC',DoubleType(),True),
                          StructField('SELLER_RANK',DoubleType(),True)
                         ])
mbap = sqlContext.createDataFrame(sc.emptyRDD(),mbap_schema)

##APPENDING THE DATA IN ABOVE CREATED HCBA TABLE 
from datetime import *
import time
start_date = datetime.strptime(time.strftime("%Y-%m-%d"), "%Y-%m-%d") #STARTING DATE
no_days = 7  #NO. OF DAYS FOR WHICH DATA IS REQUIRED
date_list_mbap = []
for i in range(no_days):
    x = (start_date - timedelta(i))
    x = x.strftime("%Y-%m-%d")
    date_list_mbap.append(x)
	
start_date_last = start_date.replace(year=start_date.year - 1)
for i in range(1,8):
    x = (start_date_last - timedelta(i))  ##need to change this while giving for final recommendations
    x = x.strftime("%Y-%m-%d")
    date_list_mbap.append(x)

for dates in date_list_mbap:
	path_mbap =  's3n://ewe-meta-prod/EXPEDIA/ARCHIVE/bidding/TRIPADVISOR_mBAP_bidoutput_'+dates.replace("-","")+'.tab.gz'   
	print (path_mbap)
	try :
		temp_mbap = sqlCtx.read.format("com.databricks.spark.csv").options(header = True, inferschema = True, delimiter = "\t",nullValue= '\\N').load(path_mbap)
		print('file exist')
		temp_mbap = temp_mbap.filter(temp_mbap.posa == 'CA')
		temp_mbap = temp_mbap.select('snapshot_day','device','hotelid','final_bid_value_cpc','expected_rank')
		mbap = mbap.unionAll(temp_mbap)
	except: print('file does not exist')

mbap = mbap.cache()

#####subsetting mbap data for optimization 
mbap_opti = mbap.filter((mbap.ACTIVITY_DATE <= opti_strt_date) & (mbap.ACTIVITY_DATE >= opti_end_date))
#mbap_opti = mbap
mbap1 = mbap_opti.groupBy('HOTEL_ID','DEVICE_TYPE').agg({"SELLER_RANK":"avg","CPC":"avg"}).withColumnRenamed("avg(SELLER_RANK)","SELLER_RANK").\
		withColumnRenamed("avg(CPC)","CPC")
mbap1_opti = mbap1.withColumn('SELLER_RANK_BUCKET',seller_rank_bucket_udf(mbap1.SELLER_RANK)).select('HOTEL_ID','DEVICE_TYPE','SELLER_RANK','CPC','SELLER_RANK_BUCKET')
mbap1_opti = mbap1_opti.cache()

####subsetting mbap data for random forest
mbap_rf = mbap[~((mbap.ACTIVITY_DATE <= opti_strt_date) & (mbap.ACTIVITY_DATE >= opti_end_date))]
#mbap_rf = mbap
mbap_rf = mbap_rf.cache()

mbap.unpersist()

####rf ad collation
tripadvisor_ad_final = hcba_rf_union.join(hotel_dim_final,"HOTEL_ID","left_outer")
tripadvisor_ad_final = tripadvisor_ad_final.cache()
hcba_rf_union.unpersist()

tripadvisor_ad_final1 = tripadvisor_ad_final.join(mbap_rf,['ACTIVITY_DATE','HOTEL_ID','DEVICE_TYPE'],'left_outer')
tripadvisor_ad_final1 = tripadvisor_ad_final1.cache()
tripadvisor_ad_final.unpersist()



###Seller rank for previous year data
seller_rank_look_up = mbap_rf[mbap_rf.SELLER_RANK.isNotNull()]
seller_rank_look_up = seller_rank_look_up.groupBy('HOTEL_ID','SELLER_RANK').count()
seller_rank_look_up = seller_rank_look_up.withColumn("Rank",rank().over(Window.partitionBy('HOTEL_ID').orderBy(seller_rank_look_up["count"].desc())))
seller_rank_look_up = seller_rank_look_up.filter(seller_rank_look_up.Rank == 1).drop('Rank').drop('count').withColumnRenamed('SELLER_RANK','Rank_Freq')

seller_rank_look_up = seller_rank_look_up.cache()

###Seller rank for missing values in current year data
tripadvisor_ad_final2 = tripadvisor_ad_final1.join(seller_rank_look_up,'HOTEL_ID','inner')
tripadvisor_ad_final3 = tripadvisor_ad_final2.withColumnRenamed('SELLER_RANK','seller_rank_0').withColumnRenamed('ACTIVITY_DATE','ACTIVITY_DATE_ACT')

tripadvisor_ad_final3 = tripadvisor_ad_final3.cache()
tripadvisor_ad_final1.unpersist()

mbap_rf_without_cpc = mbap_rf.select('HOTEL_ID','SELLER_RANK','ACTIVITY_DATE','DEVICE_TYPE').distinct()
mbap_rf_without_cpc = mbap_rf_without_cpc.cache()

mbap_rf.unpersist()

days = [1,2,3,4,5,6,7]
rank_col_name=['seller_rank_1','seller_rank_2','seller_rank_3','seller_rank_4','seller_rank_5','seller_rank_6','seller_rank_7']

for day in days:
	d = day
	def date_change(date):
		date = datetime.strptime(date,'%Y-%m-%d') - timedelta(d)
		date = date.strftime("%Y-%m-%d")
	
	date_change_udf = udf(date_change,StringType())
		
	tripadvisor_ad_final3 = tripadvisor_ad_final3.withColumn('ACTIVITY_DATE',date_change_udf('ACTIVITY_DATE_ACT'))
	tripadvisor_ad_final3 = tripadvisor_ad_final3.join(mbap_rf_without_cpc,['ACTIVITY_DATE','HOTEL_ID','DEVICE_TYPE'],'left_outer').\
							withColumnRenamed('SELLER_RANK',rank_col_name[day-1]).drop('ACTIVITY_DATE')
	tripadvisor_ad_final3 = tripadvisor_ad_final3.cache()
    
    
							
tripadvisor_ad_final4=tripadvisor_ad_final3.withColumn("SELLER_RANK",coalesce('Rank_Freq','seller_rank_0','seller_rank_1','seller_rank_2','seller_rank_3','seller_rank_4','seller_rank_5','seller_rank_6','seller_rank_7'))
tripadvisor_ad_final5 = tripadvisor_ad_final4.select([col for col in tripadvisor_ad_final4.columns if col not in ('Rank_Freq','seller_rank_0','seller_rank_1','seller_rank_2','seller_rank_3','seller_rank_4','seller_rank_5','seller_rank_6','seller_rank_7')])

tripadvisor_ad_final6 = tripadvisor_ad_final5.withColumnRenamed('ACTIVITY_DATE_ACT','ACTIVITY_DATE')


tripadvisor_ad_final7 = data_type_change_int(tripadvisor_ad_final6,["SELLER_RANK"])
tripadvisor_ad_final_rf = tripadvisor_ad_final7.withColumn('SELLER_RANK_BUCKET',seller_rank_bucket_udf("SELLER_RANK"))

tripadvisor_ad_final_rf = tripadvisor_ad_final_rf.cache()
tripadvisor_ad_final3.unpersist()

#################top hotel price aggregate table for optimization ad
####net revenue columns
##CREATE THE LIST OF DATES FOR WHICH DATA IS REQUIRED
from datetime import *
import time
start_date = datetime.strptime(time.strftime("%Y-%m-%d"), "%Y-%m-%d") #STARTING DATE

no_days = 2  #NO. OF DAYS FOR WHICH DATA IS REQUIRED
date_list_thpa = []
for i in range(no_days):
    x = (start_date - timedelta(i))
    x = x.strftime("%Y-%m-%d")
    date_list_thpa.append(x)

TOP_schema = StructType([
						   StructField('DEVICE_TYPE',StringType(), True),
						   StructField('HOTEL_ID',IntegerType(), True),
						   StructField('BOOKING_WINDOW',IntegerType(), True),
						   StructField('LOS',IntegerType(), True),
						   StructField('ADULT_COUNT',DoubleType(), True), 
						   StructField('BASE_RATE_MIN',DoubleType(), True),
						   StructField('COMMISION_AVG',DoubleType(), True),
						   StructField('VARIABLE_MARGIN_AVG',DoubleType(), True),
						   StructField('LOCAL_DATE',StringType(), True),
						 
						 ])

thpa = sqlContext.createDataFrame(sc.emptyRDD(), TOP_schema)

for dates in date_list_thpa:
	path_thpa = 's3n://ewe-core-meta-prod/CORE/TOP_HOTEL_PRICE_AGG/local_date='+dates+'/*'  
	print (path_thpa)
	try :
		temp_thpa = sqlCtx.read.format("com.databricks.spark.csv").options(header = False, inferschema = True, delimiter = "\t",nullValue= '\\N').load(path_thpa)
		temp_thpa = temp_thpa.select('C2','C3','C9','C8','C10','C14','C29','C31','C32')  
		print('file exist')
		thpa = thpa.unionAll(temp_thpa)
	except: print('file does not exist')
	
thpa = thpa.distinct()
thpa = data_type_change_float(thpa, ['BASE_RATE_MIN','COMMISION_AVG','VARIABLE_MARGIN_AVG'])
thpa = data_type_change_int(thpa, ['LOS','BOOKING_WINDOW'])
thpa_opti = thpa.cache()

def Net_rev(commission_avg, variable_margin_avg):
    x = float(commission_avg) + float(variable_margin_avg)
    return x
	
Net_revenue_udf = udf(Net_rev, DoubleType())

thpa_opti1 = thpa_opti.withColumn("NET_REVENUE",Net_revenue_udf(thpa_opti.COMMISION_AVG,thpa_opti.VARIABLE_MARGIN_AVG))
thpa_opti2 = thpa_opti1.groupBy("HOTEL_ID","LOS","BOOKING_WINDOW","LOCAL_DATE","BASE_RATE_MIN").agg({'NET_REVENUE':'avg'}).withColumnRenamed('avg(NET_REVENUE)','NET_REVENUE_0')
thpa_opti3  = thpa_opti2.withColumn("LOS_BUCKET", udfsearchToCategory("LOS")).withColumn("BW_BUCKET", udfsearchbucketToCategory("BOOKING_WINDOW"))

thpa_opti3 = thpa_opti3.cache()

thpa_opti.unpersist()

######optimization ad collation
los_bucket = ['1','2','3','4','5','6','7','8-14','>14']
bw_bucket =  ['0','1','2','3-4','5-7','8-14','15-20','21-30','31-40','41-60','61-90','91-120','121-180','181-240','>240']

import pandas as pd
los = pd.DataFrame(los_bucket)
bw = pd.DataFrame(bw_bucket)
los_bucket_df = sqlContext.createDataFrame(los).withColumnRenamed('0','LOS_BUCKET')
bw_bucket_df = sqlContext.createDataFrame(bw).withColumnRenamed('0','BW_BUCKET')

bkts = los_bucket_df.join(bw_bucket_df)
bkts = bkts.cache()

hotel_dim_final = hotel_dim_final.repartition(300)

optimization_ad_sq_univ = hotel_dim_final.join(bkts)

optimization_ad_sq_univ = optimization_ad_sq_univ.cache()

hotel_dim_final.unpersist()
bkts.unpersist()

optimization_ad_sq_univ_traffic = optimization_ad_sq_univ.join(hcba_opti_union,['HOTEL_ID','LOS_BUCKET','BW_BUCKET'],'left_outer')

optimization_ad_sq_univ_traffic = optimization_ad_sq_univ_traffic.cache()
optimization_ad_sq_univ.unpersist()

optimization_ad_sq_univ_traffic_mbap = optimization_ad_sq_univ_traffic.join(mbap1_opti,['HOTEL_ID','DEVICE_TYPE'],'left_outer')

optimization_ad_sq_univ_traffic_mbap = optimization_ad_sq_univ_traffic_mbap.cache()

optimization_ad_sq_univ_traffic.unpersist()

optimization_ad = optimization_ad_sq_univ_traffic_mbap.join(thpa_opti3,["HOTEL_ID","LOS_BUCKET","BW_BUCKET"],'left_outer')


optimization_ad = data_type_change_float(optimization_ad,["BASE_RATE_MIN","NET_REVENUE_0"])

optimization_ad = optimization_ad.cache()

optimization_ad_sq_univ_traffic_mbap.unpersist()
thpa_opti3.unpersist()


optimization_ad_Hotel_Agg = optimization_ad.groupBy("HOTEL_ID").agg({'BASE_RATE_MIN':'sum','NET_REVENUE_0':'sum'})
optimization_ad_Hotel_Agg = optimization_ad_Hotel_Agg.withColumn('NET_REVENUE_1',optimization_ad_Hotel_Agg['sum(NET_REVENUE_0)']/optimization_ad_Hotel_Agg['sum(BASE_RATE_MIN)']).\
							drop('sum(NET_REVENUE_0)').drop('sum(BASE_RATE_MIN)')

optimization_ad_Region_Agg = optimization_ad.groupBy("MODEL_NAME").agg({'BASE_RATE_MIN':'sum','NET_REVENUE_0':'sum'})
optimization_ad_Region_Agg = optimization_ad_Region_Agg.withColumn('NET_REVENUE_2',optimization_ad_Region_Agg['sum(NET_REVENUE_0)']/optimization_ad_Region_Agg['sum(BASE_RATE_MIN)']).\
							drop('sum(NET_REVENUE_0)').drop('sum(BASE_RATE_MIN)')

optimization_ad1 = optimization_ad.join(optimization_ad_Hotel_Agg,'HOTEL_ID','inner')
optimization_ad2 = optimization_ad1.join(optimization_ad_Region_Agg,'MODEL_NAME','inner')

optimization_ad2 = optimization_ad2.cache()

optimization_ad.unpersist()


def net_revenue_missing(net_revenue1,net_revenue2,net_revenue3):
	net_revenue1_temp = round(net_revenue1,2)
	net_revenue2_temp = round(net_revenue2,2)
    
	if (net_revenue1_temp == 0.00) and (net_revenue2_temp != 0.00):
		return net_revenue2
	elif (net_revenue1_temp == 0.00) and (net_revenue2_temp == 0.00):
		return net_revenue3
	else :
		return net_revenue1
		
net_revenue_missing_udf = udf(net_revenue_missing,DoubleType())

optimization_ad_final = optimization_ad2.withColumn('NET_REVENUE',net_revenue_missing_udf('NET_REVENUE_0','NET_REVENUE_1','NET_REVENUE_2')).drop('NET_REVENUE_1').drop('NET_REVENUE_0').drop("BASE_RATE_MIN").drop('NET_REVENUE_2')

optimization_ad_final = optimization_ad_final.cache()

optimization_ad2.unpersist()


####AD for generating rf model
import numpy
from pyspark.ml.feature import *
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.mllib.linalg import *
from pyspark.sql.functions import *
from pyspark.ml import Pipeline
from pyspark.ml.regression import RandomForestRegressor
from pyspark.ml.feature import StringIndexer, VectorIndexer



counter = 1
models = ('Canada', 'US', 'Mexico', 'CARIBBEAN',
          'Other Region', 'North America')

for name in models:
    if name == 'Canada':
        region_level = 'CITY_BUCKET'
    elif name == 'US':
        region_level = 'region'
    elif name in ['Mexico', 'CARIBBEAN', 'North America']:
        region_level = 'MARKET_BUCKET'
    else:
        region_level = 'REGION_BUCKET'

    training_ad = tripadvisor_ad_final_rf.filter(tripadvisor_ad_final_rf.MODEL_NAME == name).filter(tripadvisor_ad_final_rf.DEVICE_TYPE=='DESKTOP')\
        .select("TRAFFIC", "BOOKING", "BW_BUCKET", "LOS_BUCKET", "HOTEL_TYPE_BUCKET", "STAR_RATING_BUCKET", region_level, "SELLER_RANK_BUCKET").\
        withColumnRenamed(region_level, 'REGION_LEVEL_BUCKET')
    
    training_ad = training_ad.cache()

    optimization_test = optimization_ad_final.filter(optimization_ad.MODEL_NAME == name).filter(optimization_ad.DEVICE_TYPE=='DESKTOP')\
        .withColumnRenamed(region_level, 'REGION_LEVEL_BUCKET')

    optimization_test = optimization_test.cache()
    
    # for training the data
    # Aggregating the data to the required level
    training_ad_T = training_ad.groupBy("BW_BUCKET", "LOS_BUCKET", "HOTEL_TYPE_BUCKET", "STAR_RATING_BUCKET", "REGION_LEVEL_BUCKET", "SELLER_RANK_BUCKET").sum("TRAFFIC", "BOOKING")

    training_ad_T1 = training_ad_T.withColumnRenamed('sum(TRAFFIC)', 'TRAFFIC')
    training_ad_T1 = training_ad_T1.withColumnRenamed(
        'sum(BOOKING)', 'BOOKING')
    
    training_ad_T1 = training_ad_T1.cache()
    training_ad.unpersist()
    
    # Filtering out the TRAFFIC (Outliers) from data
    training_ad_T1 = training_ad_T1[
        ~((training_ad_T1.TRAFFIC <= 4) & (training_ad_T1.BOOKING > 0))]
    training_ad_T1 = training_ad_T1[
        ~((training_ad_T1.TRAFFIC == 5) & (training_ad_T1.BOOKING == 2))]
    training_ad_T1 = training_ad_T1[
        ~((training_ad_T1.TRAFFIC == 6) & (training_ad_T1.BOOKING == 2))]

    # Converting the data type of required columns to factor
    def indexStringColumns(df, cols):
        tempdf = df
        for col in cols:
            stringIndexer = StringIndexer(inputCol=col, outputCol=col + "-num")
            si_model = stringIndexer.fit(tempdf)
            tempdf = si_model.transform(tempdf)
        return tempdf

    cols = {"BW_BUCKET", "LOS_BUCKET", "HOTEL_TYPE_BUCKET",
            "STAR_RATING_BUCKET", "REGION_LEVEL_BUCKET", "SELLER_RANK_BUCKET"}
    dfnumeric = indexStringColumns(training_ad_T1, cols)
    dfnumeric = dfnumeric.cache()
    training_ad_T1.unpersist()
    

    def oneHotEncodeColumns(df, cols):
        tempdf = df
        for col in cols:
            onehotenc = OneHotEncoder(
                inputCol=col + "-num", outputCol=col + "-onehot")
            tempdf = onehotenc.transform(tempdf).drop(col + "-num")
        return tempdf
    training_ad_T1_Class = oneHotEncodeColumns(dfnumeric, {
                                               "BW_BUCKET", "LOS_BUCKET", "HOTEL_TYPE_BUCKET", "STAR_RATING_BUCKET", "REGION_LEVEL_BUCKET", "SELLER_RANK_BUCKET"})
    
    training_ad_T1_Class = training_ad_T1_Class.cache()
    dfnumeric.unpersist()
    
    # Transforming the training dataset
    # Defining function for the same
    def genRows(row):
        TRAFFIC = row[6]
        BOOKING = row[7]
        BOOKINGcounter = 0
        rowList = []

        for i in range(TRAFFIC):
            row1 = row[:]
            # row1[6]=1
            row1 = list(row1)
            row1[6] = 1
            row1 = tuple(row1)
            if BOOKINGcounter < int(BOOKING):
                # row1[7]=1
                row1 = list(row1)
                row1[7] = 1
                row1 = tuple(row1)
            else:
                # row1[7]=0
                row1 = list(row1)
                row1[7] = 0
                row1 = tuple(row1)
            BOOKINGcounter += 1
            rowList.append(row1)
        return rowList

    # Applying function on the complete dataset (after converting to rdd)
    training_ad_T1_Class_rdd = training_ad_T1_Class.rdd
    training_ad_T1_Class_rdd = training_ad_T1_Class_rdd.flatMap(
        lambda x: genRows(x))
     
    training_ad_T1_Class_rdd = training_ad_T1_Class_rdd.cache()    
    training_ad_T1_Class.unpersist()
    
    # Reconverting to dataframe

    from pyspark.sql import SQLContext
    from pyspark.sql.types import *
    from pyspark.mllib.linalg import SparseVector, VectorUDT

    schema = StructType([StructField('BW_BUCKET', StringType(), True),
                         StructField('LOS_BUCKET', StringType(), True),
                         StructField('HOTEL_TYPE_BUCKET', StringType(), True),
                         StructField('STAR_RATING_BUCKET', StringType(), True),
                         StructField('REGION_LEVEL_BUCKET',
                                     StringType(), True),
                         StructField('SELLER_RANK_BUCKET', StringType(), True),
                         StructField('TRAFFIC', IntegerType(), True),
                         StructField('BOOKING', IntegerType(), True),
                         StructField('HOTEL_TYPE_BUCKET-onehot',
                                     VectorUDT(), True),
                         StructField('BW_BUCKET-onehot',  VectorUDT(), True),
                         StructField('region_bucket-onehot',
                                     VectorUDT(), True),
                         StructField('LOS_BUCKET-onehot',  VectorUDT(), True),
                         StructField('SELLER_RANK_BUCKET-onehot',
                                     VectorUDT(), True),
                         StructField('STAR_RATING_BUCKET-onehot',  VectorUDT(), True)])
    training_ad_T1_Class_df = sqlContext.createDataFrame(
        training_ad_T1_Class_rdd, schema)

    # Converting label to double datatype
    toDouble = udf(lambda x: float(x * 1.00), DoubleType())
    training_ad_T1_Class_df = training_ad_T1_Class_df.withColumn(
        'BOOKING', toDouble(training_ad_T1_Class_df.BOOKING))
    
    training_ad_T1_Class_df = training_ad_T1_Class_df.cache()
    training_ad_T1_Class_rdd.unpersist()
    

    # Taking only relevant columns as features
    colList = training_ad_T1_Class_df.columns
    colList.remove('BOOKING')
    colList.remove('TRAFFIC')
    colList.remove('BW_BUCKET')
    colList.remove('LOS_BUCKET')
    colList.remove('HOTEL_TYPE_BUCKET')
    colList.remove('STAR_RATING_BUCKET')
    colList.remove('REGION_LEVEL_BUCKET')
    colList.remove('SELLER_RANK_BUCKET')
    vecAssembler = VectorAssembler(inputCols=colList, outputCol="features")
    train_ad = vecAssembler.transform(training_ad_T1_Class_df).select("BOOKING", "TRAFFIC", "BW_BUCKET", "LOS_BUCKET", "HOTEL_TYPE_BUCKET",
                                                                      "STAR_RATING_BUCKET", "REGION_LEVEL_BUCKET", "SELLER_RANK_BUCKET", "features").withColumnRenamed("BOOKING", "label")

    
    train_ad = train_ad.cache()
    training_ad_T1_Class_df.unpersist()
    
    # Creating AD for Optimization for prediction of conversion rate
    cols = {"BW_BUCKET", "LOS_BUCKET", "HOTEL_TYPE_BUCKET",
            "STAR_RATING_BUCKET", "REGION_LEVEL_BUCKET", "SELLER_RANK_BUCKET"}
    dfnumeric_opti = indexStringColumns(optimization_test, cols)
    dfnumeric_opti = dfnumeric_opti.cache()
    optimization_test.unpersist()
    
    optimization_onehot = oneHotEncodeColumns(dfnumeric_opti, cols)
    optimization_onehot = optimization_onehot.cache()
    dfnumeric_opti.unpersist()
    
    
    col = ['STAR_RATING_BUCKET-onehot','REGION_LEVEL_BUCKET-onehot','BW_BUCKET-onehot','HOTEL_TYPE_BUCKET-onehot','LOS_BUCKET-onehot','SELLER_RANK_BUCKET-onehot']
    vecAssembler = VectorAssembler(inputCols=col, outputCol="indexedFeatures")
    optimization_df = vecAssembler.transform(optimization_onehot).select(
        "BW_BUCKET", "LOS_BUCKET", "HOTEL_TYPE_BUCKET", "STAR_RATING_BUCKET", "REGION_LEVEL_BUCKET", "SELLER_RANK_BUCKET", "indexedFeatures")
    optimization_df = optimization_df.cache()
    optimization_onehot.unpersist()
    
    

    # Random Forest model building
    from pyspark.ml import Pipeline
    from pyspark.ml.regression import RandomForestRegressor
    from pyspark.ml.feature import StringIndexer, VectorIndexer

    labelIndexer = StringIndexer(
        inputCol="label", outputCol="indexedLabel").fit(train_ad)
    featureIndexer = VectorIndexer(
        inputCol="features", outputCol="indexedFeatures").fit(train_ad)
    rf = RandomForestRegressor(labelCol="indexedLabel", featuresCol="indexedFeatures", featureSubsetStrategy="onethird",
                               numTrees=1000, impurity="variance", maxBins=32)
    pipeline = Pipeline(stages=[labelIndexer, featureIndexer, rf])
    model = pipeline.fit(train_ad)
    RF_Model = model.stages[2]
    optimization_df_predict = RF_Model.transform(optimization_df).drop(
        "indexedFeatures").withColumnRenamed("prediction", "CONVERSION_RATE")
    
    optimization_df_predict = optimization_df_predict.cache()
    
    if counter == 1:
        optimization_rf = optimization_df_predict
        optimization_rf = optimization_rf.cache()
        optimization_df_predict.unpersist()
    else:
        optimization_rf = optimization_rf.unionAll(optimization_df_predict)
        optimization_rf = optimization_rf.cache()
        optimization_df_predict.unpersist()
        
    counter = counter+1

####optimization algorithm
from pyspark.sql.functions import udf
from pyspark.sql.types import *
from pyspark.sql.functions import monotonicallyIncreasingId
import pandas

##Pulp package for Linear Programming Optimization algorithm
import pulp
from pulp import *


optimization_rf = optimization_rf.cache()

def predicted(predicted):
    if predicted < 0.0005:
        predicted = 0.0
    else:
        predicted
    return predicted


##If Net revenue is negative then making it positive 
def net_revenue(net_revenue):
    if net_revenue < 0.0 :
        net_revenue = net_revenue*(-1)
    else:
        net_revenue
    return net_revenue

##Creating the objective function at search query level, combining it while running lp_solve algorithm
def objective_fun(net_revenue,predicted):
    return net_revenue * predicted

##Lower limit for the average weekly Traffic
def lower_limit_fun(net_revenue,average_weekly_traffic):
    if net_revenue >= 100.0:
        limit=0.5*average_weekly_traffic
    elif net_revenue>=50.0 and net_revenue <100.0:
        limit=0.2*average_weekly_traffic
    else:
        limit=0.2*average_weekly_traffic
    return limit 

##creating unique id for each search query
def var_name(id):
    return "T_" + str(id)

##registering the above defined functions as uoptimization_rf
objective_fun_udf = udf(objective_fun, DoubleType())
lower_limit_fun_udf = udf(lower_limit_fun, DoubleType())
var_name_udf= udf(var_name,StringType())
net_revenue_udf = udf(net_revenue, DoubleType())
predicted_udf = udf(predicted , DoubleType())

##creating new column predicted_new by capping the predicted conversion rate
optimization_t_predict = optimization_rf.withColumn("predicted_new",predicted_udf(optimization_rf.CONVERSION_RATE))
optimization_t_predict = optimization_t_predict.cache()
optimization_rf.unpersist()

##removing the searech queries with 0 Traffic , for such queries we will giving rule base throttle value
optimization_t_Traffic =  optimization_t_predict.filter(optimization_t_predict.TRAFFIC!=0)

##creating new column net_revenue_new by making -ve values of net revenue +ve
optimization_t = optimization_t_Traffic.withColumn("net_revenue_new",net_revenue_udf(optimization_t_Traffic.NET_REVENUE))

##creating three columns having objective function coefficients,lower limit of Average weekly Traffic and Unique id for each search query
optimization_t_temp = optimization_t.withColumn("objective_fun",objective_fun_udf(optimization_t.net_revenue_new ,optimization_t.predicted_new)).\
                      withColumn("Lower_Limit", lower_limit_fun_udf(optimization_t.net_revenue_new , optimization_t.AVERAGE_WEEKLY_TRAFFIC)).\
					  withColumn("id", monotonicallyIncreasingId())
optimization_t_final = optimization_t_temp.withColumn("var_name" ,var_name_uoptimization_rf(optimization_t_temp.id))

optimization_t_final = optimization_t_final.cache()

def lp_solve(df):
    import pulp
    from pulp import LpProblem,LpVariable,lpSum,LpStatus,solvers
    df = list(df)
    df_count = len (df)
    region_name = [df[i][1][4] for i in range(df_count) if i == 0]
    t_list = [df[i][1][29] for i in range(df_count)]
    objective_list = [df[i][1][26] for i in range(df_count)]
    final_objective = {t_list[i]: objective_list[i] for i in range(0, df_count)}
    lower_limit_list = [df[i][1][27] for i in range(df_count)]
    upper_limit_list = [df[i][1][16] for i in range(df_count)]
    lower_limit_final = {t_list[i]: lower_limit_list[i] for i in range(0, df_count)}
    upper_limit_final = {t_list[i]: upper_limit_list[i] for i in range(0, df_count)}
    cnt =0.3
    lp_status = 'Start'
    while ((lp_status != "Optimal")  & (cnt <=2.0)):
        a = cnt
        last_row =  [(df[i][1][17] - a*df[i][1][26]) for i in range(df_count)]
        final_constraint = {t_list[i]: last_row[i] for i in range(0, df_count)}
        prob = LpProblem("The Optimization Problem", LpMaximize)
        lp_var = {}
        for variable in t_list:

            variable1 = LpVariable(variable,lower_limit_final[variable],upper_limit_final[variable])
            lp_var[str(variable)] = variable1
        prob += lpSum([final_objective[i]*lp_var[i] for i in t_list]) 
        prob += lpSum([final_constraint[i]*lp_var[i] for i in t_list]) == 0
        prob.solve()
        var_values = {"start":0}
        for v in prob.variables():
            var_values.update({v.name[2:]:v.varValue})
        lp_status = LpStatus[prob.status]
        results={"region_name":region_name,"lp_status":LpStatus[prob.status],"cnt":(cnt), "gp":value(prob.objective),"var_list":var_values}
        cnt = cnt+.01
    yield  results

def part_id(x):
    if x == "Canada":
        return 1.0
    elif x == "Mexico":
        return 2.0
    elif x == "CARIBBEAN":
        return 3.0
    elif x == "US":
        return 4.0
    elif x == "North America":
        return 5.0
    elif x == "Other Region":
        return 6.0


part_id_udf = udf(part_id,DoubleType())

optimization_t_final_temp = optimization_t_final.withColumn("part_id",part_id_udf(optimization_t_final.MODEL_NAME))
optimization_t_final_temp = optimization_t_final_temp.cache()


pairs = optimization_t_final_temp.rdd.map(lambda x : (x[30],x))
pairs_part = pairs.partitionBy(6)

pairs_part = pairs_part.cache()
optimization_t_final_temp.unpersist()

final_results = pairs_part.mapPartitions(lp_solve).collect()
final_results = final_results.cache()
pairs_part.unpersist()

def df_create(x):
    mydictionary = x['var_list']
    Efficiency =  x['cnt']
    Model_Name = x['region_name'][0]
    
    var_list = []
    for key in mydictionary:
        var_list.append((key, mydictionary[key],Efficiency,Model_Name))
          
    df = pandas.DataFrame(var_list, columns=['var_id', 'var_value','Efficiency','Model'])
    df_final = sqlContext.createDataFrame(df)
    
    return df_final 

field = [StructField("var_id", StringType(), True),StructField("var_value", DoubleType(), True),StructField("Efficiency", FloatType(), True),StructField("Model", StringType(), True)]
schema = StructType(field)

optimization_df_algo1 = sqlContext.createDataFrame(sc.emptyRDD(), schema)

for i in range(len(final_results)):
    optimization_df_algo1 = optimization_df_algo1.unionAll(df_create(final_results[i]))

optimization_df_algo1 = optimization_df_algo1.cache()
final_results.unpersist()

optimization_df_algo1 = optimization_df_algo1.withColumn("id",optimization_df_algo1["var_id"].cast(LongType()))
optimization_df_algo2 = optimization_t_final_temp.select([col for col in optimization_t_final_temp.columns if col not in {"predicted_new","net_revenue_new","objective_fun","Lower_Limit","var_name","part_id"}]).join(optimization_df_algo1,"id","inner")
	
def threshold(conv_rate,avg_weekly_traffic):
    z = conv_rate/avg_weekly_traffic 
    return (1-z)

threshold_udf = udf(threshold,DoubleType())

optimization_df_algo3 = optimization_df_algo2.withColumn("threshold",threshold_udf("var_value","AVERAGE_WEEKLY_TRAFFIC"))

optimization_df_algo3 = optimization_df_algo3.select([col for col in optimization_df_algo3.columns if col not in {"id","var_id","Model"}])
optimization_df_algo3 = optimization_df_algo3.withColumnRenamed("var_value","Lp_solution")
optimization_df_algo_final = optimization_df_algo3.select("HOTEL_ID","LOS_BUCKET","BW_BUCKET","threshold","BASE_RATE_MIN")

optimization_df_algo_final = optimization_df_algo_final.cache()
optimization_df_algo1.unpersist()

####rule base throttle values
optimization_traffic_missing =  optimization_t_predict.filter(Optimization_T_predict.TRAFFIC==0)
optimization_traffic_score =  optimization_traffic_missing.withColumn("SCORE",(optimization_traffic_missing.BASE_RATE_MIN*optimization_traffic_missing.CONVERSION_RATE))

optimization_traffic_score = optimization_traffic_score.cache()
optimization_t_predict.unpersist()


def throttle(score):
	score = round(score,3)
	if score >= 1.000:
		return 0
	elif (score > 1.000) and (score <=0.700):
		return 0.06
	elif (score > 0.700) and (score <=0.500):
		return 0.11
	elif (score > 0.500) and (score <=0.250):
		return 0.17
	elif (score > 0.250) and (score <=0.050):
		return 0.23
	elif (score > 0.050) and (score <=0.025):
		return 0.27
	else :
		return 0.33

throttle_udf = udf(throttle.DoubleType())

optimization_traffic_throttle  = optimization_traffic_score.withColumn("threshold",throttle_udf(optimization_traffic_score.SCORE))
optimization_traffic_throttle_final = optimization_traffic_throttle.select("HOTEL_ID","LOS_BUCKET","BW_BUCKET","threshold","BASE_RATE_MIN")

optimization_traffic_throttle_final = optimization_traffic_throttle_final.cache()
optimization_traffic_score.unpersist()

###collating the final optimization result
optimization_throttle_final = optimization_traffic_throttle_final.unionAll(optimization_df_algo_final)

optimization_throttle_final = optimization_throttle_final.cache()
optimization_traffic_throttle_final.unpersist()
optimization_df_algo_final.unpersist()

## Splitting BW_buckets into upper and lower values.

def minRemainingDays(bwBucket):
     if bwBucket == "<=0":
         return "0"
     elif bwBucket == "1":
         return "1"
     elif bwBucket == "2":
         return "2"
     elif bwBucket == ">240":
         return "240"
     else:
         string_list = bwBucket.split("-")
         return str(string_list[0])
        
def maxRemainingDays(bwBucket):
     if bwBucket == "<=0":
         return "0"
     elif bwBucket == "1":
         return "1"
     elif bwBucket == "2":
         return "2"
     elif bwBucket == ">240":
         return "240"
     else:
         string_list = bwBucket.split("-")
         return str(string_list[1])

minRemainingDays_udf = udf(minRemainingDays,StringType())
maxRemainingDays_udf = udf(maxRemainingDays,StringType())

opti_output = optimization_throttle_final.withColumn("minRemainingDays",minRemainingDays_udf("BW_BUCKET")).
			  withColumn("maxRemainingDays",maxRemainingDays_udf("BW_BUCKET"))

## Adding ruleStart and ruleEnd Date
rule_strt_date = (start_date - timedelta(1))
rule_strt_date = rule_strt_date.strftime("%Y-%m-%d")

rule_end_date = (start_date - timedelta(8))
rule_end_date = rule_end_date.strftime("%Y-%m-%d")

opti_output1 = opti_output.withColumn("ruleStartDate", lit(rule_strt_date))
opti_output2 = opti_output1.withColumn("ruleEndDate", lit(rule_end_date))


# add startDay column 
from_pattern = 'yyyy-mm-dd'
to_pattern = 'EEEEE'
opti_output3 = opti_output2.withColumn('startDay', from_unixtime(unix_timestamp(opti_output2['ruleStartDate'], from_pattern), to_pattern))

opti_output3.cache()
optimization_throttle_final.unpersist()

opti_output3_agg = opti_output3.groupBy(["LOS_BUCKET","BW_BUCKET","threshold"]).count()
opti_output3_agg.cache()

opti_output3_temp = opti_output3.groupBy(["LOS_BUCKET","BW_BUCKET","threshold"])

import pandas
row_no = list(range(opti_output3_agg.count()))
row_df = pandas.DataFrame(row_no)
row_df = sqlContext.createDataFrame(row_df)
row_df = row_df.withColumn("join",lit(1))

from pyspark.sql.functions import lit

def hotel_grp(id):
    return ("HO"+str(id))
hotel_grp_udf = udf(hotel_grp,StringType())

opti_output3_agg1 = opti_output3_agg.withColumn("join",lit(1))

opti_output3_agg2 = opti_output3_agg1.join(row_df,"join","inner").drop("id").withColumnRenamed("0","id").withColumn("hotel_group",hotel_grp_udf("id")).drop("id").drop("count")
opti_output3_agg2.cache()

opti_output4 = opti_output3.join(opti_output3_agg2,["LOS_BUCKET","BW_BUCKET","threshold"],"inner").drop("join")
opti_output4.cache()
opti_output3_agg2.unpersist()
opti_output3.unpersist()


df_los_8 = opti_output4.filter(opti_output4.LOS_Bucket == '8-14')
df_los_8.cache()

df_los_other = opti_output4.filter(opti_output4.LOS_Bucket != '8-14')
df_los_other.cache()

opti_output4.cache()

los = list(range(8,15,1))
los_df = pandas.DataFrame(los)
los_df = sqlContext.createDataFrame(los_df)
los_df.cache()

df_los_8 = df_los_8.join(los_df).drop("LOS_Bucket").withColumnRenamed("0","LOS_BUCKET")

def replace(los):
    if los == '>14':
        return '15'
    else:
        return los

replace_udf = udf(replace,StringType())
df_los_all = df_los_8.unionAll(df_los_other)
df_los_8.unpersist()
df_los_other.unpersist()

opti_output5 = df_los_all.withColumn("lengthOfStay",replace_udf("LOS_BUCKET")).withColumn("lengthOfStay",replace_udf("LOS_BUCKET")).drop("LOS_BUCKET")
opti_output5.cache()
df_los_all.unpersist()


## UDF to split AvgBV column
def floor_percentile_bucket(val):
    if (val>=0) & (val<=62.95):
        return 0
    elif (val>=62.96) & (val<=86.32):
        return 62.96
    elif (val>=86.33) & (val<=110.36):
        return 86.33
    elif (val>=110.37) & (val<=142.01):
        return 110.37
    elif (val>=142.02) & (val<=188.92):
        return 142.02
    elif (val>=188.93) & (val<=241.96):
        return 188.93
    elif (val>=241.97) & (val<=324.25):
        return 241.97
    elif (val>=324.26) & (val<=453.64):
        return 324.26
    elif (val>=453.65) & (val<=726.35):
        return 453.65
    elif (val>=726.36) & (val<=7409.94):
        return 726.36
    elif val>=7409.95:
        return 7409.94
    else:
        print("EXCEPTION")
        
def ceiling_percentile_bucket(val):
    if (val>=0) & (val<=62.95):
        return 62.95
    elif (val>=62.96) & (val<=86.32):
        return 86.32
    elif (val>=86.33) & (val<=110.36):
        return 110.36
    elif (val>=110.37) & (val<=142.01):
        return 142.01
    elif (val>=142.02) & (val<=188.92):
        return 188.92
    elif (val>=188.93) & (val<=241.96):
        return 241.96
    elif (val>=241.97) & (val<=324.25):
        return 324.25
    elif (val>=324.26) & (val<=453.64):
        return 453.64
    elif (val>=453.65) & (val<=726.35):
        return 726.35
    elif (val>=726.36) & (val<=7409.94):
        return 7409.94
    elif val>=7409.95:
        return 10000.00
    else:
        return 1
        
udf_floor_percentile_bucket = udf(floor_percentile_bucket,FloatType())
udf_ceiling_percentile_bucket = udf(ceiling_percentile_bucket,FloatType())

opti_output6 = opti_output5.withColumn("floor_percentile",udf_floor_percentile_bucket("BASE_RATE_MIN")).withColumn("ceiling_percentile",udf_ceiling_percentile_bucket("BASE_RATE_MIN"))

def hotelGroupsOrHotelIds(RSD,LOS,MinRD,MaxRD):
    str = "CampignName" + "TACA" + "HotelGroup" + RSD + LOS + MinRD + MaxRD 
    return str

udf_hotelGroupsOrHotelIds = udf(hotelGroupsOrHotelIds, StringType())



opti_output7 = opti_output6.withColumn("ruleStartTime",lit("00:00")).withColumn("ruleEndTime",lit("00:00")).withColumn("recurrence",lit("NA"))\
				.withColumn("minRemainingRooms",lit("NA")).withColumn("maxRemainingRooms",lit("NA")).withColumn("eventStartDate",lit("NA"))\
				.withColumn("eventEndDate",lit("NA")).withColumn("sourceType",lit("browser")).withColumn("stepUpPercentage",lit("NA"))\
				.withColumn("deeplinkType",lit("NA")).withColumn("ruleType",lit("bl")).\
				.withColumn("hotelGroupsOrHotelIDs",udf_hotelGroupsOrHotelIds("ruleStartDate","lengthOfStay","minRemainingDays","maxRemainingDays"))


opti_output8= opti_output7.withColumn("ruleName",opti_output7.hotelGroupsOrHotelIDs)

opti_output_final = opti_output8.select("ruleName","lengthOfStay","startDay","minRemainingDays","maxRemainingDays","ruleStartDate","ruleExpiryDate","ruleStartTime","ruleEndTime","recurrence","hotelGroupsOrHotelIds","minRemainingRooms","maxRemainingRooms","eventStartDate","eventEndDate","sourceType","adults","minAvgBookingValue","maxAvgBookingValue","threshold","stepUpPercentage","deeplinkType","ruleType")

path_save = "/home/vireddy/output.csv"
opti_output_final.toPandas().to_csv(path_save)

























