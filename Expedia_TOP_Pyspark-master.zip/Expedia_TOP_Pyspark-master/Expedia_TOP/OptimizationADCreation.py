from pyspark.sql import SQLContext
from pyspark import SparkConf, SparkContext
import time
from pyspark.sql.functions import *

start_time = time.time()

# set the spark context
sc = SparkContext('local', 'pyspark')
sqlContext = SQLContext(sc)
sqlContext.setConf('spark.sql.shuffle.partitions', '5')

# load csv to dataframe
Raw_AD = '/home/neyre/TOP/SampleRawADV02.csv'
CPC_Raw = '/home/neyre/Documents/CPCCaribbeanSample.csv'

# TODO: add to parse through CPC file for Partner POS combo.
# could build a module/function that takes as arguments which model and partner and POS

# Raw_AD = '/home/neyre/Downloads/newSampleRaw1.csv' # smaller file for testing
# CPC_Raw = '/home/neyre/Downloads/CPCSample.csv'

Opt_Raw_Data = sqlContext.read.format('com.databricks.spark.csv').\
	options(header='true', inferschema='true',delimiter=',').load(Raw_AD)
CPC_Data = sqlContext.read.format('com.databricks.spark.csv').\
	options(header='true', inferschema='true', delimiter=',').load(CPC_Raw)

# previous code was run on each individual model, can we distribute
# so that each model is run in parallel?
modelnm = 'CARIBBEAN'
device = 'DESKTOP'
DeviceModel = Opt_Raw_Data.select('hotel_id','region','market_bucket',\
	'market','hotel_type','hotel_type_bucket','star_rating','device_type',\
	'star_rating_bucket','region_bucket','model_name','city_bucket'\
	,'los_bucket','bw_bucket','traffic')\
	.filter(Opt_Raw_Data['device_type'] == device)\
	.filter(Opt_Raw_Data['model_name'] == modelnm)
	# .distinct()\ # does this need to be distict TODO: ask Rohit

filterbuckets = DeviceModel.select('hotel_id','region','market_bucket',\
	'market','hotel_type','hotel_type_bucket','star_rating','device_type',\
	'star_rating_bucket','region_bucket','model_name','city_bucket')

# create mini tables that are the distinct bw and los buckets
# and then cross join to create all possible combos
LOSbucket = Opt_Raw_Data.select('los_bucket').distinct()
BWbucket = Opt_Raw_Data.select('bw_bucket').distinct()
bucketjoin = LOSbucket.join(BWbucket)
fullcross = filterbuckets.join(bucketjoin)
# fullcross.show()
# print fullcross.count()

CPCjoin = fullcross.join(CPC_Data.select('hotelid','final_bid_value_cpc'),\
	fullcross.hotel_id == CPC_Data.hotelid,'inner')
CPCjoin.show()
# CPCjoin.select('hotel_id','los_bucket','bw_bucket','final_bid_value_cpc')\
# 	.orderBy('hotel_id','los_bucket','bw_bucket').show()

SumTraffic = CPCjoin.join(DeviceModel,['hotel_id','los_bucket','bw_bucket'],'left_outer')
# SumTraffic.groupBy(['hotel_id','los_bucket','bw_bucket']).sum('traffic')\
# 	.orderBy('hotel_id','los_bucket','bw_bucket').show(200)

# join the original table back to get sum of traffic, cost, booking, net rev
# TODO: speak with Rohit to get the actual calcuations necessary here
# EPBcalc = fullcross.join(DeviceModel,['hotel_id','los_bucket','bw_bucket'], "leftouter")
# sums = EPBcalc.groupBy('hotel_id','los_bucket','bw_bucket').sum('booking')
# sums.show(20)
# print EPBcalc.count()

# including these lines to make sure the code is running correct
# TODO: remove these lines when code is production ready
print "CODE RAN SUCCESSFULLY"
print "CODE RAN SUCCESSFULLY"
print "CODE RAN SUCCESSFULLY"
print "CODE RAN SUCCESSFULLY"
print "CODE RAN SUCCESSFULLY"
print "CODE RAN SUCCESSFULLY"
print "CODE RAN SUCCESSFULLY"
print "CODE RAN SUCCESSFULLY"
print "CODE RAN SUCCESSFULLY"
print "CODE RAN SUCCESSFULLY"
print "CODE RAN SUCCESSFULLY"
print "CODE RAN SUCCESSFULLY"
print("--- %s seconds ---" % (time.time() - start_time))
