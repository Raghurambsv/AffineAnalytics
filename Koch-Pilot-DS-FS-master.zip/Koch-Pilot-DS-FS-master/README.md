# Koch-Pilot-DS-FS

Development of Data Agnostic Feature refuction algorithm for Koch. Contracted to Affine India Pvt Ltd

The project contains the following folder structure 

(1) Data Scraping - Datasets and Jupyter notebooks used to scrape TICKR data, Index variables are considered as the DV

(2) Sanity Checks and Data split - Jupyter notebooks used to remove variables not meeting data requirements. i.e. Low variablity, high         missing values etc

(3) Feature Selection - Jupyter Notebook used to reduce features by carrying out a VIF followed by Transformation and GBM module.

(4) Experiments - Jupyter Notepook used to check the diffrence in output using following two different approaches: 
                   1. VIF followed by Transformation and GBM
                   2. Transformation followed by VIF and GBM

(5) Validation and checks - Jupyter notebooks for validation of Feature Selection module on three different datasets. Linear regression 
    and GBM outputs are compared against auto.arima output.

(6) Final Codes - Jupyter Notebook to call different functions to implement the Feature Selection in a single notebook.

(7) Documentation - Flowcharts,powerpoint presentation and Research documents are uploaded.

(8) Brute Force Implementation - Jupyter Notebook used to implement BruteForce algorithm i.e Adding most signifiant variables iteratively     on the basis of MAPE using a Linear Regression, capped to number of iterations coming from Feature Selection module.  

