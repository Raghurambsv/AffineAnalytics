## Import libraries
import numpy as np
import pandas as pd
from sklearn.feature_selection import VarianceThreshold
from sklearn.preprocessing import StandardScaler

def remove_na_feature(df,threshold=50):
    """
    Function to generate report of features with NaN and their corresponding %
    and remove features with null value % greater than or equal to a threshold
    
    # Arguments
        df: Input dataframe
        threshold: Threshold value % to remove columns with Nan. Default is 50%
        
    # Returns
        dataframe: Dataframe with NaN columns removed
    """
    mis_val = df.isnull().sum()
    mis_val_percent = 100 * df.isnull().sum() / len(df)
    mis_val_table = pd.concat([mis_val, mis_val_percent], axis=1)
    report = mis_val_table.rename(
    columns = {0 : 'Missing Values', 1 : '% of Total Values'})
    report = report[report.iloc[:,1] != 0].sort_values(
    '% of Total Values', ascending=False).round(1).reset_index()
    report.columns=['Feature','Missing Values','% of Total Values']
    print(f'Data has {df.shape[1]} columns.\n'
          f'There are {report.shape[0]} columns that have missing values')
    report.to_csv('Null_values_report.csv',index=False)
    print('Null value report saved as Null_values_report.csv!! \n')
    
    feature_nan= report.loc[report['% of Total Values']>=threshold,:]['Feature']
    print(f'{len(feature_nan)} features have nulls greater than the threshold and will be dropped')
    dropped= pd.DataFrame(feature_nan.values,columns=['Dropped_features']) 
    dropped.to_csv('Null_dropped_report.csv',index=False)
    print('Dropped features saved in report Null_Dropped_Report.csv!! \n')
    df.drop(columns=feature_nan,inplace=True)
    
    return df

def impute_na(df,impute_method='median'):
    """
    Function to impute missing values with mean, first seen, last seen 
    or avg of first seen and last seen of column values
    
    # Arguments
        df: Input dataframe
        impute_method: Method to impute NaN in columns. Default is 'median'
        
    # Returns
        dataframe: Dataframe with NaN in columns imputed
    """
    if impute_method == 'median':
        df.fillna(df.median(), inplace=True) 
    
    elif impute_method == 'mean':
        df.fillna(df.mean(), inplace=True) 
    
    elif impute_method=='fill_forward':
        df.fillna(method='ffill',inplace=True)
    
    elif impute_method=='fill_backward':
        df.fillna(method='bfill',inplace=True)

    elif impute_method=='fill_fb_mean':
        df=(df.ffill()+df.bfill())/2
    
    print(f'Imputation performed using {impute_method}\n')
        
    return df.bfill().ffill()

def outlier_count_standard_deviation(df,num_of_std=3):
    """
    Function to treat outlier
    
    # Arguments
        df: Input dataframe
        num_of_std: Number of standard deviations
        
    # Returns
        dataframe: dataframe with outliers treated
    """
    print('Outliers are capped between [upper-lower] bound using standard deviation method.\n')
    
    for col in df.columns:
        if df.loc[:,[col]].dtypes.values != 'object':
            data = df[col]
            data_mean, data_std = np.mean(data), np.std(data)
            # identify outliers
            cut_off = data_std * num_of_std
            lower, upper = data_mean - cut_off, data_mean + cut_off
            # Impute Outliers
            df[col] = np.where((df[col]<lower),lower,np.where((df[col]>upper),upper,df[col]))
            
    return df


def remove_low_variance(df,threshold=0):
    """
    Function to remove features with low variance
    
    # Arguments
        df: Input dataframe
        threshold: Low variance threshold
        
    # Returns
        dataframe: Dataframe with low variance columns removed
    """
    normalized_df=(df-df.mean())/df.std()
    normalized_df=normalized_df.fillna(0)
    constant_filter = VarianceThreshold(threshold=threshold)  
    constant_filter.fit(normalized_df)
    columns_with_variance= normalized_df.columns[constant_filter.get_support()]
    constant_columns = [column for column in normalized_df.columns  
                        if column not in columns_with_variance]
    report= pd.DataFrame(constant_columns,columns=['Low_Variance_Feature']) 
    report.to_csv('Low_Variance_Features_Report.csv',index=False)
    print(f'{len(constant_columns)} features with {threshold} variance found and dropped')
    print('Dropped Low variance features saved in Low_Variance_Features_Report.csv!!\n')
    df = df.drop(labels=constant_columns, axis=1)
    
    return df

def sanity_checks(df,null_threshold,impute_method,num_of_std,variance_threshold):
    """
    Function to perform preliminary data cleaning and sanity checks
    
    # Arguments
        df: Input dataframe
        null_threshold: Threshold value % to remove columns with NaN
        impute_method: Method to impute NaN in data
        num_of_std: Number of standard deviations
        variance_threshold:Low variance threshold
        
    # Returns
        dataframe: data with sanity checks treated
    """
    df=remove_na_feature(df,null_threshold)
    df=impute_na(df,impute_method)
    df=outlier_count_standard_deviation(df,num_of_std)
    final_df=remove_low_variance(df,variance_threshold)
    print(f'Number of features remaining: {final_df.shape[1]}')
    return final_df