#import libraries
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

def vif_rem(df,r_square_threshold=0.9):
    
    """
    Function to  remove variables iteratively that are multicollinear with other 
    variables in the dataset
    
    # Arguments
        df: Input dataframe
        r_square_threshold: R-Square-Threshold to remove variables
                            0.9 r-square corresponds to a VIF of 10
                            0.8 r-square corresponds to a VIF of 5     
    # Returns
        dataframe: Return a dataframe with non collinear variables
    """
    dropped=[]
    lr = LinearRegression()
    for col in df.columns:
        lr.fit(df.drop([col],axis=1),df[col])
        if lr.score(df.drop([col],axis=1),df[col]) >= r_square_threshold:  # R-square - 0.9 corresponds to a VIF of 5
            df=df.drop([col],axis=1)
            dropped.append(col)
            
    vif_df = pd.DataFrame(dropped, columns=['Feature'])
    vif_df.to_csv('VIF_Dropped_Report.csv',index=False)
    print(f'{len(dropped)} features dropped after VIF')
    print('Dropped variables saved in VIF_Dropped_Report.csv!!')
    
    return(df) 