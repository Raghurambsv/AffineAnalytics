#import libraries
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor  
from sklearn.grid_search import GridSearchCV


def gbm(max_depth_l,min_samples_split_l,n_estimators_l,learning_rate_l,x,y):
    
    """
    Function to generate Variable Importance Plot using GBM.
    
    # Arguments
        x: Input dataframe - Independent features
        y: Input dataframe - Target feature
        max_depth_l: list of max_depth hyperparameter
        min_samples_split_l: list of min_samples_split hyperparameter
        n_estimators_l: list of n_estimators_l hyperparameter
        learning_rate_l: list of learning_rate_l hyperparameter
        
    # Returns
        dataframe: Return a dataframe with Transformed Variables
    """
    
    #default parameters for GBM from documentation
    default_params = {'max_depth' : 3, 'min_samples_split':2, 'n_estimators':100, 'learning_rate':0.1}
    
    #if default parameters are not included in user input, add them to the list
    if default_params['max_depth'] not in max_depth_l:
        max_depth_l.append(default_params['max_depth'])
        
    if default_params['min_samples_split'] not in min_samples_split_l:    
        min_samples_split_l.append(default_params['min_samples_split'])
        
    if default_params['n_estimators'] not in n_estimators_l:     
        n_estimators_l.append(default_params['n_estimators'])
        
    if default_params['learning_rate'] not in learning_rate_l: 
        learning_rate_l.append(default_params['learning_rate'])
    
    #run grid search
    param_test = {'max_depth':max_depth_l, 'min_samples_split':min_samples_split_l,
                   'n_estimators': n_estimators_l, 'learning_rate': learning_rate_l}
    gsearch = GridSearchCV(estimator = GradientBoostingRegressor(max_features='sqrt', subsample=0.8, random_state=10), 
    param_grid = param_test, scoring='r2',n_jobs=4,iid=False, cv=5,verbose=1)
    gsearch.fit(x,y)


    gbm = GradientBoostingRegressor(learning_rate = gsearch.best_params_['learning_rate'] , min_samples_split =gsearch.best_params_['min_samples_split'],
                                   n_estimators = gsearch.best_params_['n_estimators'], max_depth = gsearch.best_params_['max_depth'])
    gbm.fit(x,y)
    features_df = pd.DataFrame({'Feature': x.columns,'GBM Feature Importance':gbm.feature_importances_,}).sort_values('GBM Feature Importance',ascending=False).reset_index(drop=True)

    #saving features with their importance scores
    features_df.to_csv('Best_Features.csv',index=False)
    print('Final best features with their relative importance saved as Best_Features.csv!!')  
    
    return(features_df)