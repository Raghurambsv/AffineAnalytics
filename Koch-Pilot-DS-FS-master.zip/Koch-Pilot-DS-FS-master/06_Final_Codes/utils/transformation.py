#import libraries
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

def transformations(df,y):
    """
    Function to perform feature transformaions
    
    # Arguments
        df: Input dataframe
        y: Dependent feature
        
    # Returns
        dataframe: Returns dataframe of features with best transformations
    """

    ### Transformations
    transf=["never","_sq","_sq_root","_inv"]
    lr = LinearRegression()
    
    for col in df.columns:
        
        sq = np.square(df[col])
        sq_root = np.sqrt(df[col])
        inv = np.where( (df[col]!=0), np.reciprocal(df[col]),  0)
        l=[df[col],sq,sq_root,inv]

        r2_list = []  # To store r-square for each variable present in the list
        for var in l:

            lr.fit(np.array(var).reshape(-1,1),y)
            r2_list.append(lr.score(np.array(var).reshape(-1,1),y))

        ind = np.argmax(r2_list) 

        #Keeping only best transformations
        if ind !=0:
            df_transformed=df.drop([col],axis=1)
            df_transformed[col+transf[ind]] = l[ind]
    
    return df_transformed