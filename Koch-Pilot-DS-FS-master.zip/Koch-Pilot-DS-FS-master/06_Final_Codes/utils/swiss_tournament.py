#import libraries
import numpy as np
import pandas as pd
from tqdm import tqdm

from sklearn.ensemble import RandomForestRegressor

def generate_report(df):
    """
    Function to generate report of feature importance based on different metrics
    
    # Arguments
        df: Input dataframe
        
    # Returns
        dataframe: Final report dataframe
    """
    
    #Compute feature importance metrices
    group_df = df.groupby('feature').agg(
            {'feature_imp':['sum','median','mean'],'rank':['sum','median','mean','min','max'],
            'feature': 'count'})
    group_df.columns = ["_".join(x) for x in group_df.columns.ravel()]
    group_df.reset_index(inplace=True)
    #Get top 3 buckets
    df['bucket_first_3'] = [1 if x >= 0 and x <= 3 else 0 for x in df['rank']]
    df2 = df.groupby('feature').agg({'bucket_first_3':'sum'}).reset_index()
    
    #Get count and percetage of occurences of each feature in the random forests
    final_df = pd.merge(group_df, df2, on='feature',how='inner')

    final_df['percent_first_3_bucket']=final_df['bucket_first_3']/final_df['feature_count']
    
    #Get count of number of times a feature got its best rank
    grouped = df[['feature','rank']].groupby(['feature']).agg({'rank': 'min'}).reset_index()

    grouped['min_flag'] = [1 for x in range(grouped.shape[0])]

    df3 = pd.merge(df, grouped, how='left', left_on=['feature', 'rank'],
                            right_on= ['feature', 'rank'])

    df3.sort_values(['feature', 'rank'], ascending = [True, False], inplace=True)
    df3.dropna(inplace=True)
    df4 = df3[['feature', 'min_flag']].groupby(['feature']).agg({'min_flag': 'sum'}).reset_index()
    df4.columns = ['feature', 'best_in_num_games']
    final_df = final_df.merge(df4, on='feature', how='left')

    return final_df


def Swiss_tourney(x,y,no_of_rf,feature_each_rf,max_depth,n_estimators):
    """
    Function to carry out swiss tournament algorithm on features and get
    feature importance reports
    
    # Arguments
        x: Dataframe with dependent features
        y: Independent feature
        no_of_rf: Number of Random forests for swiss tournament iterations
        feature_each_rf: Number of features in a bucket sent to each Random Forest
        max_depth: Depth of Random Forest tree
        n_estimators: Number of trees in each Random Forest
        
    # Returns
        dataframe: Dataframe with NaN columns removed
    """
    print(f'Running {no_of_rf} Random Forests with {feature_each_rf} features each!')
    
    #create buckets of features
    list_of_features =[]
    for i in range(no_of_rf):
        local_list=[]
        ind = list(np.random.choice(range(x.shape[1]),feature_each_rf,replace=False))
        list_of_features.append(x.columns[ind])
    
    #list to hold random forest results on feature buckets
    l=[]

    for i in tqdm(range(len(list_of_features))):
        rf = RandomForestRegressor(max_features='sqrt',max_depth=max_depth,n_estimators=n_estimators, random_state=0)
        rf.fit(x.loc[:,list_of_features[i]], y)

        df_2 = pd.DataFrame({'feature': x.loc[:,list_of_features[i]].columns, 'feature_imp':rf.feature_importances_,}).sort_values('feature_imp',ascending=False)
        df_2['rank']  = [(i+1) for i in range(feature_each_rf)]
        l.append(df_2)
    
    rank_df = pd.concat(l, ignore_index=True)
    report_df = generate_report(rank_df.copy())
    
    rank_df.to_csv('rank.csv',index=False)
    
    report_df.sort_values(by=['feature_imp_mean'],ascending=False,inplace=True)
    report_df.reset_index(drop=True,inplace=True)
    report_df.to_csv('Feature_Importace_Report.csv',index=False)
    print('Feature importance reports generated and saved as rank.csv and Feature_Importance_Report.csv!')
    
    return (report_df,rank_df)


def low_high_imp_grouping(df,percentile):
    """
    Function to classify features into high and low importance based on percentile (user input)
    
    
    # Arguments
        df: Input dataframe
        percentile: Percentile value above which feature will be classified as high
                    importance feature
        
    # Returns
        dataframe: Final report dataframe
    """
    df['Group'] = np.where(df['feature_imp_sum'] <= np.percentile(df['feature_imp_sum'],percentile),'Low','High')
    
    df= df.sort_values('feature_imp_sum',ascending=False).reset_index(drop=True)
    df.to_csv('Feature_Importace_Report.csv',index=False)
    print('Feature Importance Report saved as Feature_Importance_Report.csv!! ')
    
    return(df)
