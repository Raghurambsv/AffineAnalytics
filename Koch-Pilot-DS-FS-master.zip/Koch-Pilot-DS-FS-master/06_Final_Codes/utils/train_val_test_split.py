#import libraries
import numpy as np
import pandas as pd

def train_valid_test_split(df,train_size=0.9,val_size=0.05):
    """
    Function to split data into train, validation and test sets
    
    # Arguments
        df: Input dataframe
        train_size: Percentage of rows to keep in train. Default is 0.9
        val_size: Percentage of rows to keep in validation. Default is 0.05
        
    # Returns
        3 dataframe: Returns the training, validation and test datasets
    """
    train, validate, test = np.split(df, [int(train_size*len(df)), int((train_size+val_size)*len(df))])
    return train, validate, test