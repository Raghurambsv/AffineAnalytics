#import libraries
import numpy as np
import pandas as pd

def create_lags(df,n_lags=3):
    """
    Function to create lags of features
    
    # Arguments
        df: Input dataframe
        n_lags: Number of lags to create. Default is 5
        
    # Returns
        dataframe: Dataframe with lags
    """
    lag_range = [x for x in range(1,n_lags+1,1)]    
    L = list(map(lambda y: df.apply(lambda x: x.shift(y), axis=0), 
                 lag_range))

    list_str_lags = ['_lag_'+str(x) for x in lag_range]
    list_of_column_names = list(map(lambda x: x.columns, L))

    column_names_df = [i+j for i, j in zip(list_of_column_names, list_str_lags)]

    for i in range(len(L)):
        L[i].columns = column_names_df[i]

    # return 
    final = pd.concat([df,pd.concat(L, axis=1)],axis=1)
    return df  