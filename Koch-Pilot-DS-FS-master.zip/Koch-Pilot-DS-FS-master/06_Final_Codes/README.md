# Feature selection for the case of p, number of predictors >> n, number of observations

> **NOTE: This procedure was tried out on stock market data and simulated data**

This repository contain resources (except images) to assess the importance of feature through the performance of 
large number of iterations. These iterations are performed using uniform random sampling, RF, VIF, Transformations and GBM.


## Folder Structure for running the model

```
│───README.md
│───Utils
│   │───gbm_rel_feature_importance.py
│   │───lag.py
│   │───sanity_check.py
│   │───swiss_tournament.py
│   │───train_val_test_split.py
│   │───transformations.py
│   │───train_val_test_split.py
│   └───vif.py
│───Final_Code.ipynb
│───Finance_Final_data.csv
└───params.yml
```
## Running the model

- Execute the Feature_Selection.ipynb
- Steps of execution
	- Update Parameters inside the params.yml file
	- Import requisite libraries
	- Call Sanity Checks Module
	- Call Train, Validation and Test Module
	- Call Swiss Tournament
	- Evalute Important Features with sum of Feature Importance threshold(decided from the frequency distribution)
	- Running VIF to remove multicollinearity among the Features selected above
	- Transformation are applied based on R-square metric
	- Relative Feature Importance plot of Features using GBM
